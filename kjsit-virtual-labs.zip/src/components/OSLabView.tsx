import React, { useState } from 'react';
import {
  Terminal,
  ArrowLeft,
  ArrowRight,
  Search,
  BookOpen,
  CheckCircle2,
  GraduationCap,
  Award,
  Layers,
  Code,
  Cpu,
  HardDrive,
  ShieldAlert,
  GitMerge,
  Clock,
  Sparkles
} from 'lucide-react';
import { OS_EXPERIMENTS } from '../data/osExperiments';
import { UserSession } from '../types';
import { LaunchLabArrow } from './LaunchLabArrow';

interface OSLabViewProps {
  onSelectExperiment: (experimentId: string) => void;
  onBackToLabs: () => void;
  userSession: UserSession | null;
}

export const OSLabView: React.FC<OSLabViewProps> = ({
  onSelectExperiment,
  onBackToLabs,
  userSession
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [search, setSearch] = useState<string>('');

  const categories = [
    'All',
    'Process Management & Syscalls',
    'CPU Scheduling',
    'IPC & Synchronization',
    'Deadlock Avoidance',
    'Memory Management & Paging',
    'Storage & Concurrency'
  ];

  const filteredExperiments = OS_EXPERIMENTS.filter((exp) => {
    if (selectedCategory !== 'All') {
      if (selectedCategory === 'Process Management & Syscalls' && !exp.category.includes('Process Management') && !exp.category.includes('Syscalls')) return false;
      if (selectedCategory === 'CPU Scheduling' && !exp.category.includes('CPU Scheduling')) return false;
      if (selectedCategory === 'IPC & Synchronization' && !exp.category.includes('IPC') && !exp.category.includes('Synchronization') && !exp.category.includes('Semaphores')) return false;
      if (selectedCategory === 'Deadlock Avoidance' && !exp.category.includes('Deadlock')) return false;
      if (selectedCategory === 'Memory Management & Paging' && !exp.category.includes('Memory') && !exp.category.includes('Page Replacement')) return false;
      if (selectedCategory === 'Storage & Concurrency' && !exp.category.includes('Disk') && !exp.category.includes('Threads') && !exp.category.includes('Concurrency')) return false;
    }

    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        exp.title.toLowerCase().includes(q) ||
        exp.subtitle.toLowerCase().includes(q) ||
        exp.category.toLowerCase().includes(q) ||
        exp.aim.toLowerCase().includes(q) ||
        (exp.iitReference && exp.iitReference.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const getCategoryBadgeColor = (category: string) => {
    if (category.includes('Process') || category.includes('Syscalls')) return 'bg-amber-100 text-amber-900 border-amber-200';
    if (category.includes('CPU Scheduling')) return 'bg-blue-100 text-blue-900 border-blue-200';
    if (category.includes('IPC') || category.includes('Synchronization')) return 'bg-emerald-100 text-emerald-900 border-emerald-200';
    if (category.includes('Deadlock')) return 'bg-rose-100 text-rose-900 border-rose-200';
    if (category.includes('Memory') || category.includes('Page')) return 'bg-purple-100 text-purple-900 border-purple-200';
    if (category.includes('Disk') || category.includes('Threads')) return 'bg-teal-100 text-teal-900 border-teal-200';
    return 'bg-slate-100 text-slate-800 border-slate-200';
  };

  return (
    <div className="py-10 bg-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb & Navigation */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <button
            onClick={onBackToLabs}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-white border border-zinc-300 rounded-xl text-xs font-bold text-zinc-800 hover:bg-zinc-100 transition-colors shadow-2xs cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to All Laboratories</span>
          </button>

          <div className="flex items-center gap-2 text-xs text-zinc-500">
            <span>Home</span>
            <span>/</span>
            <span>Virtual Labs</span>
            <span>/</span>
            <span className="font-bold text-red-700">Operating Systems Laboratory (CSC404)</span>
          </div>
        </div>

        {/* Subject Header Banner */}
        <div className="bg-black text-white rounded-2xl p-6 sm:p-8 shadow-sm mb-8 relative overflow-hidden border border-zinc-900">
          <div className="max-w-3xl relative z-10">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight mb-3">
              Operating Systems (OS) Virtual Laboratory
            </h1>

            <p className="text-sm sm:text-base text-zinc-300 leading-relaxed mb-6">
              Explore UNIX kernel architecture, process lifecycle hierarchies via <code className="text-red-400 font-mono text-xs">fork()</code> & <code className="text-red-400 font-mono text-xs">exec()</code>, preemptive CPU scheduling, inter-process communication pipelines, Dijkstra’s Banker’s deadlock avoidance algorithm, dynamic memory partition placement, page replacement anomalies, disk arm traversal, and POSIX multithreading (pthreads) referenced from Autonomous Curriculum StandardsAutonomous Curriculum Standards Virtual Labs.
            </p>

            {/* KJSIT Virtual Lab Alignment & Lab Stats Bar */}
            <div className="flex flex-wrap items-center gap-4 text-xs font-medium text-zinc-300 pt-4 border-t border-zinc-900">
              <div className="flex items-center gap-1.5 bg-zinc-900 px-3 py-1.5 rounded-lg border border-zinc-800">
                <GraduationCap className="w-4 h-4 text-red-400" />
                <span>KJSIT Autonomous & MU Aligned</span>
              </div>
              <div className="flex items-center gap-1.5 bg-zinc-900 px-3 py-1.5 rounded-lg border border-zinc-800">
                <Cpu className="w-4 h-4 text-red-400" />
                <span>10 Interactive Simulator Experiments</span>
              </div>
              <div className="flex items-center gap-1.5 bg-zinc-900 px-3 py-1.5 rounded-lg border border-zinc-800">
                <Code className="w-4 h-4 text-red-400" />
                <span>C, C++, POSIX & Bash Code Examples</span>
              </div>
            </div>
          </div>
        </div>

        {/* Filter and Search Bar */}
        <div className="bg-white rounded-2xl p-4 border border-zinc-200 shadow-2xs mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
          {/* Category Tabs */}
          <div className="flex flex-wrap items-center gap-1.5">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-red-700 text-white shadow-xs'
                    : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Search Input */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search OS experiments, syscalls..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-zinc-50 border border-zinc-300 rounded-lg focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-600 transition-all placeholder:text-zinc-400"
            />
          </div>
        </div>

        {/* Experiment Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {filteredExperiments.map((exp) => (
            <div
              key={exp.id}
              onClick={() => onSelectExperiment(exp.id)}
              className="bg-red-900/90 backdrop-blur-md border border-red-500/30 rounded-xl flex flex-col justify-between hover:border-red-400 hover:shadow-[0_8px_32px_rgba(185,28,28,0.4)] transition-all group cursor-pointer relative overflow-hidden"
            >
              {/* Optional glassy reflection layer */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
              
              <div className="p-3.5 relative z-10">
                {/* Exp Number + Title beside it */}
                <div className="flex items-start gap-2.5">
                  <span className="w-6 h-6 rounded-md bg-white/20 text-white font-mono text-[11px] font-bold flex items-center justify-center shrink-0 mt-0.5 border border-white/20 shadow-inner">
                    #{exp.num}
                  </span>
                  <div className="min-w-0 flex-1">
                    <h3 className="text-sm font-extrabold text-white group-hover:text-red-100 transition-colors leading-tight drop-shadow-sm">
                      {exp.title}
                    </h3>
                  </div>
                </div>
              </div>

              {/* Card Footer */}
              <div className="px-3.5 py-2.5 bg-red-950/60 border-t border-red-800/50 flex items-center justify-end mt-auto relative z-10">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectExperiment(exp.id);
                  }}
                  className="launch-lab-btn w-full sm:w-auto px-3.5 py-2 sm:py-1.5 bg-white/15 hover:bg-white/25 active:bg-white/35 text-white text-xs font-bold rounded-lg border border-white/20 hover:border-white/35 shadow-xs hover:shadow-md transition-all duration-200 flex items-center justify-center gap-2 active:scale-95 cursor-pointer backdrop-blur-sm select-none"
                  title={`Launch Lab: ${exp.title}`}
                >
                  <span>Launch Lab</span>
                  <LaunchLabArrow />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
