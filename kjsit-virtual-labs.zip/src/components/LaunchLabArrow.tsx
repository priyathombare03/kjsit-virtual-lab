import React from 'react';

interface LaunchLabArrowProps {
  className?: string;
}

/**
 * Animated Arrow for the "Launch Lab" button.
 * When the parent `.launch-lab-btn` is hovered, the tail line elongates
 * smoothly to 185% length while the arrow glides forward.
 */
export const LaunchLabArrow: React.FC<LaunchLabArrowProps> = ({ className = 'w-3.5 h-3.5' }) => {
  return (
    <svg
      className={`launch-lab-arrow ${className} text-white overflow-visible shrink-0`}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {/* The arrow tail line that elongates on hover */}
      <line
        x1="5"
        y1="12"
        x2="19"
        y2="12"
        className="launch-lab-arrow-tail"
      />
      {/* Arrowhead */}
      <polyline points="12 5 19 12 12 19" />
    </svg>
  );
};
