import React, { useState, useEffect, useRef } from 'react';
import {
  Printer,
  X,
  Download,
  Copy,
  Check,
  BookOpen,
  FileText,
  Code2,
  HelpCircle,
  Award,
  ExternalLink,
  ChevronDown,
  Gamepad2
} from 'lucide-react';
import { LabExperiment, UserSession } from '../types';
import { SomaiyaEmblem } from './SomaiyaLogo';
import { getExperimentLaboratoryObjectives } from '../utils/experimentObjectives';
import { getExperimentCodingamePuzzles } from '../data/dsaCodingamePuzzles';

interface PrintLabManualModalProps {
  isOpen: boolean;
  onClose: () => void;
  experiment: LabExperiment;
  userSession: UserSession | null;
  subjectName?: string;
}

export const PrintLabManualModal: React.FC<PrintLabManualModalProps> = ({
  isOpen,
  onClose,
  experiment,
  userSession,
  subjectName
}) => {
  const [selectedLanguage, setSelectedLanguage] = useState<'python' | 'cpp' | 'c' | 'java' | 'sql' | 'bash'>('python');
  const [copied, setCopied] = useState(false);
  const [isPrinting, setIsPrinting] = useState(false);
  const printIframeRef = useRef<HTMLIFrameElement | null>(null);

  const codingamePuzzles = experiment.codingamePuzzles || getExperimentCodingamePuzzles(experiment.id);
  const hasCodingame = codingamePuzzles && codingamePuzzles.length > 0;

  // Auto-pick available language
  useEffect(() => {
    if (experiment.code) {
      if (experiment.code.python) setSelectedLanguage('python');
      else if (experiment.code.cpp) setSelectedLanguage('cpp');
      else if (experiment.code.c) setSelectedLanguage('c');
      else if (experiment.code.java) setSelectedLanguage('java');
      else if (experiment.code.sql) setSelectedLanguage('sql');
      else if (experiment.code.bash) setSelectedLanguage('bash');
    }
  }, [experiment]);

  // Handle ESC key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const currentCode = experiment.code?.[selectedLanguage] || 
    experiment.code?.python || 
    experiment.code?.cpp || 
    experiment.code?.c || 
    experiment.code?.java || 
    '// Implementation available in online simulator';

  const generatePrintableHTML = () => {
    const studentName = userSession?.name || '__________________________';
    const studentId = userSession?.studentId || userSession?.idNumber || '__________________________';
    const studentEmail = userSession?.email || '__________________________';
    const currentDate = new Date().toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });

    const complexityRows = (experiment.theory.complexityTable || [])
      .map(
        (c) => `
        <tr>
          <td style="padding: 6px 12px; border: 1px solid #d1d5db; font-weight: 600; background: #f9fafb;">${c.parameter}</td>
          <td style="padding: 6px 12px; border: 1px solid #d1d5db; font-family: monospace; color: #991b1b; font-weight: bold;">${c.value}</td>
        </tr>
      `
      )
      .join('');

    const theoryPoints = (experiment.theory.overview || [])
      .map((p) => `<p style="margin-bottom: 8px; line-height: 1.6; text-align: justify;">${p}</p>`)
      .join('');

    const keyPoints = (experiment.theory.keyPoints || [])
      .map((k) => `<li style="margin-bottom: 4px;">${k}</li>`)
      .join('');

    const applications = (experiment.theory.realWorldApplications || [])
      .map((a) => `<li style="margin-bottom: 4px;">${a}</li>`)
      .join('');

    const algorithmSteps = (experiment.algorithm || [])
      .map((step, idx) => `<li style="margin-bottom: 6px; line-height: 1.5;"><strong style="color: #991b1b;">Step ${idx + 1}:</strong> ${step}</li>`)
      .join('');

    const procedureSteps = (experiment.procedure || [])
      .map((step) => `<li style="margin-bottom: 6px; line-height: 1.5;">${step}</li>`)
      .join('');

    const quizQuestions = (experiment.quiz || [])
      .map(
        (q, idx) => `
        <div style="margin-bottom: 14px; page-break-inside: avoid;">
          <p style="font-weight: 600; margin-bottom: 4px;">${idx + 1}. ${q.question}</p>
          <div style="padding-left: 16px; font-size: 11pt; color: #374151;">
            ${q.options.map((opt, optIdx) => `<div style="margin-bottom: 2px;">(${String.fromCharCode(65 + optIdx)}) ${opt} ${optIdx === q.correctAnswer ? '<span style="color: #16a34a; font-weight: bold; margin-left: 8px;">[✓ Answer]</span>' : ''}</div>`).join('')}
          </div>
          ${q.explanation ? `<p style="font-size: 10pt; color: #6b7280; margin-top: 4px; font-style: italic; padding-left: 16px;">Explanation: ${q.explanation}</p>` : ''}
        </div>
      `
      )
      .join('');

    const referencesList = (experiment.references || [])
      .map((ref) => `<li style="margin-bottom: 4px; font-size: 10.5pt; color: #4b5563;">${ref}</li>`)
      .join('');

    const laboratoryObjectives = getExperimentLaboratoryObjectives(experiment)
      .map((obj) => `<li style="margin-bottom: 4px; line-height: 1.4;">${obj}</li>`)
      .join('');

    const puzzles = experiment.codingamePuzzles || getExperimentCodingamePuzzles(experiment.id);
    const hasPuzzles = puzzles && puzzles.length > 0;
    const puzzlesHtml = hasPuzzles
      ? `
      <h2 class="section-header">6. In-Built Algorithmic Game & CodinGame Challenges</h2>
      <div class="content-box">
        <p style="font-size: 10pt; color: #000000; margin-bottom: 8px; font-weight: 500;">
          Interactive in-built algorithmic games and curated competitive programming puzzles aligned with this experiment's topic (Multi-language solvable in C, C++, Java, Python, and JavaScript):
        </p>
        ${puzzles
          .map(
            (p, i) => `
          <div style="margin-bottom: 8px; padding: 8px 12px; background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 4px; page-break-inside: avoid;">
            <div style="font-weight: bold; color: #000000; font-size: 10pt;">
              Challenge ${i + 1}: ${p.title} 
              <span style="font-size: 8.5pt; background: #fee2e2; color: #991b1b; padding: 1px 6px; border-radius: 3px; margin-left: 6px; font-weight: bold;">${p.difficulty.toUpperCase()}</span>
            </div>
            <div style="font-size: 9pt; color: #000000; margin-top: 2px;"><strong>Topic:</strong> ${p.topic}</div>
            <div style="font-size: 8.5pt; color: #000000; margin-top: 4px; line-height: 1.4;">${p.statement}</div>
            <div style="font-size: 8.5pt; color: #0369a1; margin-top: 3px;"><strong>Training & Game Link:</strong> ${p.codingameUrl}</div>
          </div>
        `
          )
          .join('')}
      </div>
      `
      : '';

    return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Lab Manual - Experiment ${experiment.num}: ${experiment.title}</title>
  <style>
    @page {
      size: A4 portrait;
      margin: 18mm 15mm 18mm 15mm;
    }
    body {
      font-family: 'Segoe UI', Arial, Helvetica, sans-serif;
      color: #1f2937;
      background: #ffffff;
      margin: 0;
      padding: 0;
      font-size: 11pt;
      line-height: 1.5;
    }
    .header-table {
      width: 100%;
      border-bottom: 2px solid #991b1b;
      padding-bottom: 12px;
      margin-bottom: 16px;
    }
    .inst-title {
      font-size: 14pt;
      font-weight: bold;
      color: #991b1b;
      margin: 0;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .dept-title {
      font-size: 10.5pt;
      font-weight: 600;
      color: #374151;
      margin: 2px 0 0 0;
    }
    .portal-tag {
      font-size: 9pt;
      color: #6b7280;
      margin-top: 2px;
    }
    .student-info-box {
      background: #fdf2f2;
      border: 1px solid #fecaca;
      border-radius: 6px;
      padding: 10px 14px;
      margin-bottom: 18px;
      display: flex;
      justify-content: space-between;
      flex-wrap: wrap;
      font-size: 10.5pt;
    }
    .student-info-item {
      margin-right: 18px;
      margin-bottom: 4px;
    }
    .student-info-item strong {
      color: #991b1b;
    }
    .exp-title-banner {
      background: #991b1b;
      color: #ffffff;
      padding: 8px 14px;
      border-radius: 4px;
      margin-bottom: 14px;
    }
    .exp-title-banner h1 {
      margin: 0;
      font-size: 13pt;
      font-weight: bold;
    }
    .exp-title-banner p {
      margin: 2px 0 0 0;
      font-size: 9.5pt;
      opacity: 0.9;
    }
    h2.section-header {
      font-size: 11.5pt;
      color: #991b1b;
      border-bottom: 1.5px solid #e5e7eb;
      padding-bottom: 4px;
      margin-top: 18px;
      margin-bottom: 8px;
      font-weight: bold;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .content-box {
      margin-bottom: 14px;
    }
    .code-block {
      background: #f8fafc;
      border: 1px solid #cbd5e1;
      border-radius: 4px;
      padding: 10px;
      font-family: 'Consolas', 'Courier New', monospace;
      font-size: 9.5pt;
      line-height: 1.4;
      white-space: pre-wrap;
      word-break: break-word;
      color: #0f172a;
    }
    .rubric-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 14px;
      margin-bottom: 14px;
      font-size: 10pt;
    }
    .rubric-table th, .rubric-table td {
      border: 1px solid #d1d5db;
      padding: 6px 10px;
      text-align: left;
    }
    .rubric-table th {
      background: #f3f4f6;
      color: #111827;
      font-weight: bold;
    }
    .sign-section {
      margin-top: 24px;
      padding-top: 14px;
      border-top: 1px dashed #9ca3af;
      display: flex;
      justify-content: space-between;
      page-break-inside: avoid;
    }
    .sign-box {
      width: 45%;
      text-align: center;
    }
    .sign-line {
      border-bottom: 1px solid #000;
      margin-top: 40px;
      margin-bottom: 4px;
    }
    @media print {
      body {
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }
      .no-print {
        display: none !important;
      }
    }
  </style>
</head>
<body>
  <table class="header-table">
    <tr>
      <td style="width: 70px; vertical-align: middle;">
        <div style="width: 56px; height: 56px; border-radius: 50%; background: #991b1b; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 16pt;">
          SVV
        </div>
      </td>
      <td style="vertical-align: middle; padding-left: 12px;">
        <h1 class="inst-title">K. J. Somaiya Institute of Technology</h1>
        <p class="dept-title">Autonomous College Affiliated to University of Mumbai • Department of ${userSession?.department || 'Artificial Intelligence & Data Science'}</p>
        <p class="portal-tag">KJSIT Virtual Laboratory Learning Portal • Academic Lab Manual</p>
      </td>
    </tr>
  </table>

  <div class="student-info-box">
    <div class="student-info-item"><strong>Student Name:</strong> ${studentName}</div>
    <div class="student-info-item"><strong>Roll / SVVNet ID:</strong> ${studentId}</div>
    <div class="student-info-item"><strong>Email:</strong> ${studentEmail}</div>
    <div class="student-info-item"><strong>Date:</strong> ${currentDate}</div>
    ${subjectName ? `<div class="student-info-item"><strong>Course / Lab:</strong> ${subjectName}</div>` : ''}
  </div>

  <div class="exp-title-banner">
    <h1>EXPERIMENT NO. ${experiment.num}: ${experiment.title}</h1>
    <p>${experiment.subtitle} ${experiment.iitReference ? `• Reference: ${experiment.iitReference}` : ''}</p>
  </div>

  <h2 class="section-header">1. Objective / Aim</h2>
  <div class="content-box" style="padding: 10px 14px; background: #f9fafb; border-left: 4px solid #991b1b;">
    <div style="font-weight: 600; color: #111827; margin-bottom: 4px;"><strong>Aim:</strong> ${experiment.aim}</div>
    ${experiment.objective ? `<div style="margin-top: 4px; margin-bottom: 6px; color: #374151; font-size: 10pt;"><strong>Primary Objective:</strong> ${experiment.objective}</div>` : ''}
    ${
      laboratoryObjectives
        ? `<div style="margin-top: 8px;">
            <div style="font-weight: 600; color: #111827; font-size: 10pt; margin-bottom: 4px;">Laboratory Learning Objectives:</div>
            <ul style="margin: 0 0 0 18px; padding: 0; font-size: 10pt; color: #374151;">
              ${laboratoryObjectives}
            </ul>
          </div>`
        : ''
    }
  </div>

  <h2 class="section-header">2. Theoretical Background & Complexity Analysis</h2>
  <div class="content-box">
    ${theoryPoints}
    ${
      experiment.theory.complexityTable?.length
        ? `
      <table style="width: 100%; border-collapse: collapse; margin-top: 10px; margin-bottom: 10px; font-size: 10pt;">
        <thead>
          <tr style="background: #991b1b; color: white;">
            <th style="padding: 6px 12px; border: 1px solid #d1d5db; text-align: left;">Complexity Parameter</th>
            <th style="padding: 6px 12px; border: 1px solid #d1d5db; text-align: left;">Asymptotic Bound</th>
          </tr>
        </thead>
        <tbody>
          ${complexityRows}
        </tbody>
      </table>
    `
        : ''
    }

    ${keyPoints ? `<p style="font-weight: 600; margin-top: 10px; margin-bottom: 4px;">Key Concepts:</p><ul style="padding-left: 20px; margin: 0;">${keyPoints}</ul>` : ''}
    ${applications ? `<p style="font-weight: 600; margin-top: 10px; margin-bottom: 4px;">Real-World Engineering Applications:</p><ul style="padding-left: 20px; margin: 0;">${applications}</ul>` : ''}
  </div>

  <h2 class="section-header">3. Algorithm & Step-by-Step Procedure</h2>
  <div class="content-box">
    ${algorithmSteps ? `<ol style="padding-left: 20px; margin-bottom: 12px;">${algorithmSteps}</ol>` : ''}
    ${procedureSteps ? `<p style="font-weight: 600; margin-bottom: 4px;">Laboratory Execution Procedure:</p><ol style="padding-left: 20px;">${procedureSteps}</ol>` : ''}
  </div>

  <h2 class="section-header">4. Source Code Implementation (${selectedLanguage.toUpperCase()})</h2>
  <div class="content-box">
    <div class="code-block">${currentCode.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</div>
  </div>

  ${
    experiment.sampleInput || experiment.expectedOutput
      ? `
    <h2 class="section-header">5. Sample Input & Expected Output</h2>
    <div class="content-box">
      ${experiment.sampleInput ? `<p style="font-weight: 600; margin-bottom: 2px;">Input:</p><div class="code-block" style="margin-bottom: 8px;">${experiment.sampleInput}</div>` : ''}
      ${experiment.expectedOutput ? `<p style="font-weight: 600; margin-bottom: 2px;">Output:</p><div class="code-block">${experiment.expectedOutput}</div>` : ''}
    </div>
  `
      : ''
  }

  ${puzzlesHtml}

  ${
    quizQuestions
      ? `
    <h2 class="section-header">${hasPuzzles ? '7. Viva-Voce & Review Questions' : '6. Viva-Voce & Review Questions'}</h2>
    <div class="content-box">
      ${quizQuestions}
    </div>
  `
      : ''
  }

  <h2 class="section-header">${hasPuzzles ? '8. Conclusion' : '7. Conclusion'}</h2>
  <div class="content-box" style="padding: 8px 12px; background: #f9fafb; border-left: 4px solid #16a34a;">
    ${experiment.conclusion || 'The experiment was executed and verified successfully against standard test vectors and algorithmic bounds.'}
  </div>

  ${
    referencesList
      ? `
    <h2 class="section-header">${hasPuzzles ? '9. Standard References & Textbooks' : '8. Standard References & Textbooks'}</h2>
    <div class="content-box">
      <ul style="padding-left: 20px;">${referencesList}</ul>
    </div>
  `
      : ''
  }

  <div style="page-break-inside: avoid; margin-top: 24px;">
    <h2 class="section-header">Continuous Assessment & Evaluation Rubric</h2>
    <table class="rubric-table">
      <thead>
        <tr>
          <th>Performance Indicator</th>
          <th style="width: 100px; text-align: center;">Max Marks</th>
          <th style="width: 120px; text-align: center;">Marks Obtained</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Understanding of Aim, Theory & Algorithm</td>
          <td style="text-align: center;">05</td>
          <td></td>
        </tr>
        <tr>
          <td>Laboratory Simulation, Execution & Output Analysis</td>
          <td style="text-align: center;">10</td>
          <td></td>
        </tr>
        <tr>
          <td>Viva-Voce & Lab Manual Documentation</td>
          <td style="text-align: center;">05</td>
          <td></td>
        </tr>
        <tr style="font-weight: bold; background: #fdf2f2;">
          <td>Total Continuous Internal Assessment Marks</td>
          <td style="text-align: center;">20</td>
          <td></td>
        </tr>
      </tbody>
    </table>

    <div class="sign-section">
      <div class="sign-box">
        <div class="sign-line"></div>
        <p style="margin: 0; font-weight: 600; font-size: 10pt;">Student's Signature with Date</p>
      </div>
      <div class="sign-box">
        <div class="sign-line"></div>
        <p style="margin: 0; font-weight: 600; font-size: 10pt;">Faculty In-Charge / Examiner's Signature</p>
      </div>
    </div>
  </div>
</body>
</html>
    `;
  };

  const handlePrint = () => {
    setIsPrinting(true);
    const html = generatePrintableHTML();

    try {
      // Approach 1: Use hidden iframe for clean sandbox-safe printing
      let iframe = printIframeRef.current;
      if (!iframe) {
        iframe = document.createElement('iframe');
        iframe.style.position = 'fixed';
        iframe.style.right = '0';
        iframe.style.bottom = '0';
        iframe.style.width = '0';
        iframe.style.height = '0';
        iframe.style.border = '0';
        document.body.appendChild(iframe);
        printIframeRef.current = iframe;
      }

      const doc = iframe.contentWindow?.document || iframe.contentDocument;
      if (doc) {
        doc.open();
        doc.write(html);
        doc.close();

        setTimeout(() => {
          try {
            iframe?.contentWindow?.focus();
            iframe?.contentWindow?.print();
            setIsPrinting(false);
          } catch (e) {
            console.warn('Iframe print restricted, triggering fallback window', e);
            fallbackPrint(html);
          }
        }, 300);
      } else {
        fallbackPrint(html);
      }
    } catch (err) {
      console.warn('Print error, falling back', err);
      fallbackPrint(html);
    }
  };

  const fallbackPrint = (html: string) => {
    try {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.open();
        printWindow.document.write(html);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
          setIsPrinting(false);
        }, 400);
      } else {
        // Fallback: download html file directly
        handleDownloadHTML();
      }
    } catch (err) {
      console.error('Fallback print error', err);
      handleDownloadHTML();
    }
  };

  const handleDownloadHTML = () => {
    const html = generatePrintableHTML();
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `KJSIT_Lab_Manual_Exp_${experiment.num}_${experiment.title.replace(/[^a-zA-Z0-9]/g, '_')}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setIsPrinting(false);
  };

  const handleCopyText = () => {
    const textContent = `
=====================================================
K. J. SOMAIYA INSTITUTE OF TECHNOLOGY (AUTONOMOUS)
DEPARTMENT OF ARTIFICIAL INTELLIGENCE & DATA SCIENCE
VIRTUAL LAB MANUAL - EXPERIMENT ${experiment.num}
=====================================================

STUDENT DETAILS:
Name: ${userSession?.name || 'Student'}
Roll / ID: ${userSession?.studentId || userSession?.idNumber || 'N/A'}
Email: ${userSession?.email || 'N/A'}
Date: ${new Date().toLocaleDateString()}

-----------------------------------------------------
EXPERIMENT TITLE: ${experiment.title}
SUBTITLE: ${experiment.subtitle}
-----------------------------------------------------

1. AIM / OBJECTIVE:
${experiment.aim}

2. THEORETICAL BACKGROUND:
${experiment.theory.overview.join('\n\n')}

3. ALGORITHM:
${experiment.algorithm.map((s, i) => `Step ${i + 1}: ${s}`).join('\n')}

4. CODE IMPLEMENTATION (${selectedLanguage.toUpperCase()}):
${currentCode}

5. SAMPLE INPUT & OUTPUT:
Input:
${experiment.sampleInput || 'N/A'}

Output:
${experiment.expectedOutput || 'N/A'}

6. CONCLUSION:
${experiment.conclusion || 'Experiment executed and validated successfully.'}
    `;

    navigator.clipboard.writeText(textContent.trim());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/70 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto cursor-pointer"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-3xl max-w-4xl w-full shadow-[0_25px_60px_-15px_rgba(0,0,0,0.4)] border border-zinc-200 overflow-hidden relative my-auto max-h-[92vh] flex flex-col animate-in zoom-in-95 duration-200 cursor-default"
      >
        {/* Header Ribbon with Red Glassmorphic look */}
        <div className="bg-linear-to-r from-red-950/95 via-red-900/90 to-rose-950/95 backdrop-blur-2xl text-white p-5 sm:p-6 relative border-b border-red-500/20 shrink-0 overflow-hidden">
          <div className="absolute inset-x-0 top-0 h-[1.5px] bg-linear-to-r from-red-500/20 via-white/40 to-red-500/20 pointer-events-none" />
          <div className="absolute -top-10 right-1/4 w-60 h-32 bg-red-500/25 rounded-full blur-2xl pointer-events-none" />

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onClose();
            }}
            className="absolute top-4 right-4 text-white/90 hover:text-white p-2.5 rounded-full bg-white/10 hover:bg-white/25 border border-white/20 backdrop-blur-md transition-all cursor-pointer shadow-sm z-30 hover:scale-105 active:scale-95"
            title="Close Print Preview"
            aria-label="Close"
          >
            <X className="w-4 h-4 pointer-events-none" />
          </button>

          <div className="flex items-center gap-3.5 relative z-10 pr-14">
            <div className="p-2.5 bg-white/10 backdrop-blur-md rounded-2xl border border-white/25 shadow-[0_4px_20px_rgba(0,0,0,0.25)] shrink-0 ring-1 ring-white/10">
              <SomaiyaEmblem size={40} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-white/15 backdrop-blur-md text-white text-[10px] font-bold uppercase tracking-wider border border-white/25">
                  Academic Lab Manual
                </span>
                <span className="text-xs text-red-200 font-mono">Exp {experiment.num}</span>
              </div>
              <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight mt-0.5">
                {experiment.title}
              </h2>
              <p className="text-xs text-red-200/90 mt-0.5">
                Formatted for Somaiya Continuous Internal Evaluation & Journal Submissions
              </p>
            </div>
          </div>
        </div>

        {/* Toolbar Bar */}
        <div className="px-5 py-3 bg-zinc-50 border-b border-zinc-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
          {/* Language Selector for Code */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-zinc-600">Print Code In:</span>
            <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-zinc-200">
              {experiment.code?.python && (
                <button
                  type="button"
                  onClick={() => setSelectedLanguage('python')}
                  className={`px-2.5 py-1 rounded text-xs font-bold transition-all cursor-pointer ${
                    selectedLanguage === 'python' ? 'bg-red-700 text-white shadow-2xs' : 'text-zinc-600 hover:bg-zinc-100'
                  }`}
                >
                  Python
                </button>
              )}
              {experiment.code?.cpp && (
                <button
                  type="button"
                  onClick={() => setSelectedLanguage('cpp')}
                  className={`px-2.5 py-1 rounded text-xs font-bold transition-all cursor-pointer ${
                    selectedLanguage === 'cpp' ? 'bg-red-700 text-white shadow-2xs' : 'text-zinc-600 hover:bg-zinc-100'
                  }`}
                >
                  C++
                </button>
              )}
              {experiment.code?.c && (
                <button
                  type="button"
                  onClick={() => setSelectedLanguage('c')}
                  className={`px-2.5 py-1 rounded text-xs font-bold transition-all cursor-pointer ${
                    selectedLanguage === 'c' ? 'bg-red-700 text-white shadow-2xs' : 'text-zinc-600 hover:bg-zinc-100'
                  }`}
                >
                  C
                </button>
              )}
              {experiment.code?.java && (
                <button
                  type="button"
                  onClick={() => setSelectedLanguage('java')}
                  className={`px-2.5 py-1 rounded text-xs font-bold transition-all cursor-pointer ${
                    selectedLanguage === 'java' ? 'bg-red-700 text-white shadow-2xs' : 'text-zinc-600 hover:bg-zinc-100'
                  }`}
                >
                  Java
                </button>
              )}
              {experiment.code?.sql && (
                <button
                  type="button"
                  onClick={() => setSelectedLanguage('sql')}
                  className={`px-2.5 py-1 rounded text-xs font-bold transition-all cursor-pointer ${
                    selectedLanguage === 'sql' ? 'bg-red-700 text-white shadow-2xs' : 'text-zinc-600 hover:bg-zinc-100'
                  }`}
                >
                  SQL
                </button>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopyText}
              className="px-3 py-1.5 bg-white hover:bg-zinc-100 border border-zinc-300 text-zinc-700 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs"
              title="Copy formatted manual text"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-zinc-500" />}
              <span>{copied ? 'Copied!' : 'Copy Text'}</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadHTML}
              className="px-3 py-1.5 bg-white hover:bg-zinc-100 border border-zinc-300 text-zinc-700 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs"
              title="Download standalone HTML document"
            >
              <Download className="w-3.5 h-3.5 text-zinc-500" />
              <span>Download HTML / PDF</span>
            </button>

            <button
              type="button"
              onClick={handlePrint}
              disabled={isPrinting}
              className="px-4 py-1.5 bg-linear-to-r from-red-700 via-red-600 to-rose-700 hover:from-red-600 hover:to-rose-600 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm border border-red-500/30 hover:scale-[1.02] active:scale-95 disabled:opacity-50"
            >
              <Printer className="w-3.5 h-3.5 text-white" />
              <span>{isPrinting ? 'Preparing...' : 'Print Document'}</span>
            </button>
          </div>
        </div>

        {/* Formatted Manual Preview Scrollable Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6 text-zinc-900 bg-white font-sans text-sm leading-relaxed">
          {/* Institutional Header */}
          <div className="border-b-2 border-red-800 pb-4 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-50 rounded-xl border border-red-200 shrink-0">
                <SomaiyaEmblem size={44} />
              </div>
              <div>
                <h3 className="font-bold text-red-900 text-base tracking-tight uppercase">
                  K. J. Somaiya Institute of Technology
                </h3>
                <p className="text-xs text-zinc-600 font-medium">
                  Autonomous College Affiliated to University of Mumbai • Dept. of {userSession?.department || 'Artificial Intelligence & Data Science'}
                </p>
                <p className="text-[11px] text-zinc-400">
                  KJSIT Virtual Laboratory Academic Manual • Continuous Evaluation
                </p>
              </div>
            </div>
            <div className="text-right hidden sm:block">
              <span className="inline-block px-2.5 py-1 bg-red-100 text-red-900 font-mono font-bold text-xs rounded-md border border-red-300">
                EXP NO. {experiment.num}
              </span>
            </div>
          </div>

          {/* Student Info Box */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 bg-red-50/70 border border-red-200/80 rounded-xl text-xs">
            <div>
              <span className="block text-red-800 font-bold">Student Name</span>
              <span className="font-semibold text-zinc-900">{userSession?.name || 'Somaiya Student'}</span>
            </div>
            <div>
              <span className="block text-red-800 font-bold">Roll / SVVNet ID</span>
              <span className="font-mono font-semibold text-zinc-900">
                {userSession?.studentId || userSession?.idNumber || '16010123045'}
                {userSession?.year ? ` (${userSession.year})` : ''}
              </span>
            </div>
            <div>
              <span className="block text-red-800 font-bold">Email</span>
              <span className="font-mono text-zinc-700 truncate block">{userSession?.email || 'student@somaiya.edu'}</span>
            </div>
            <div>
              <span className="block text-red-800 font-bold">Date of Print</span>
              <span className="font-semibold text-zinc-900">{new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
            </div>
          </div>

          {/* Experiment Title Banner */}
          <div className="bg-red-900 text-white p-4 rounded-xl shadow-xs">
            <h4 className="font-bold text-base">
              Experiment {experiment.num}: {experiment.title}
            </h4>
            <p className="text-xs text-red-200 mt-0.5">{experiment.subtitle}</p>
          </div>

          {/* 1. Aim */}
          <div>
            <h5 className="font-bold text-red-900 uppercase tracking-wide text-xs border-b border-zinc-200 pb-1 mb-2 flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-red-700" />
              <span>1. Aim / Objective</span>
            </h5>
            <p className="p-3 bg-zinc-50 border-l-4 border-red-700 rounded-r-lg font-medium text-zinc-800 text-xs sm:text-sm">
              {experiment.aim}
            </p>
          </div>

          {/* 2. Theory & Complexity */}
          <div>
            <h5 className="font-bold text-red-900 uppercase tracking-wide text-xs border-b border-zinc-200 pb-1 mb-2 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-red-700" />
              <span>2. Theoretical Background & Complexity</span>
            </h5>
            <div className="space-y-2 text-xs sm:text-sm text-black">
              {experiment.theory.overview.map((para, i) => (
                <p key={i}>{para}</p>
              ))}
            </div>

            {experiment.theory.complexityTable?.length > 0 && (
              <div className="mt-3 overflow-hidden rounded-lg border border-zinc-200">
                <table className="w-full text-xs text-left">
                  <thead className="bg-red-900 text-white font-bold">
                    <tr>
                      <th className="p-2">Complexity Parameter</th>
                      <th className="p-2">Asymptotic Bound</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-200 bg-white">
                    {experiment.theory.complexityTable.map((c, i) => (
                      <tr key={i} className="hover:bg-zinc-50">
                        <td className="p-2 font-medium text-zinc-900">{c.parameter}</td>
                        <td className="p-2 font-mono font-bold text-red-700">{c.value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* 3. Algorithm */}
          <div>
            <h5 className="font-bold text-red-900 uppercase tracking-wide text-xs border-b border-zinc-200 pb-1 mb-2 flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-red-700" />
              <span>3. Algorithm & Procedure</span>
            </h5>
            <ol className="list-decimal pl-5 space-y-1 text-xs sm:text-sm text-zinc-700">
              {experiment.algorithm.map((step, i) => (
                <li key={i}>
                  <strong className="text-red-900">Step {i + 1}:</strong> {step}
                </li>
              ))}
            </ol>
          </div>

          {/* 4. Code */}
          <div>
            <h5 className="font-bold text-red-900 uppercase tracking-wide text-xs border-b border-zinc-200 pb-1 mb-2 flex items-center gap-1.5">
              <Code2 className="w-3.5 h-3.5 text-red-700" />
              <span>4. Source Code Implementation ({selectedLanguage.toUpperCase()})</span>
            </h5>
            <pre className="p-4 bg-zinc-900 text-zinc-100 rounded-xl text-xs font-mono overflow-x-auto border border-zinc-800 leading-relaxed">
              <code>{currentCode}</code>
            </pre>
          </div>

          {/* 5. Sample I/O */}
          {(experiment.sampleInput || experiment.expectedOutput) && (
            <div>
              <h5 className="font-bold text-red-900 uppercase tracking-wide text-xs border-b border-zinc-200 pb-1 mb-2">
                5. Sample Input & Expected Output
              </h5>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                {experiment.sampleInput && (
                  <div className="p-3 bg-zinc-50 border border-zinc-200 rounded-xl">
                    <span className="font-bold text-zinc-800 block mb-1">Sample Input:</span>
                    <pre className="font-mono text-zinc-700 whitespace-pre-wrap">{experiment.sampleInput}</pre>
                  </div>
                )}
                {experiment.expectedOutput && (
                  <div className="p-3 bg-zinc-50 border border-zinc-200 rounded-xl">
                    <span className="font-bold text-zinc-800 block mb-1">Expected Output:</span>
                    <pre className="font-mono text-emerald-800 font-bold whitespace-pre-wrap">{experiment.expectedOutput}</pre>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 6. CodinGame Training Puzzles (if present) */}
          {hasCodingame && (
            <div>
              <h5 className="font-bold text-black uppercase tracking-wide text-xs border-b border-zinc-200 pb-1 mb-2 flex items-center gap-1.5">
                <Gamepad2 className="w-3.5 h-3.5 text-red-700" />
                <span>6. In-Built Algorithmic Game & CodinGame Challenges</span>
              </h5>
              <div className="space-y-2">
                {codingamePuzzles.map((p, i) => (
                  <div key={p.id} className="p-3 bg-zinc-50 border border-zinc-200 rounded-xl text-xs space-y-1">
                    <div className="flex items-center justify-between font-bold text-black">
                      <span>{i + 1}. {p.title}</span>
                      <span className="px-2 py-0.5 bg-red-100 text-red-800 rounded font-mono text-[10px] font-bold">
                        {p.difficulty}
                      </span>
                    </div>
                    <div className="text-black text-[11px]"><strong>Topic:</strong> {p.topic}</div>
                    <div className="text-black text-[11px] leading-relaxed line-clamp-2">{p.statement}</div>
                    <div className="text-sky-700 font-mono text-[10px]">{p.codingameUrl}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Viva Questions */}
          {experiment.quiz?.length > 0 && (
            <div>
              <h5 className="font-bold text-red-900 uppercase tracking-wide text-xs border-b border-zinc-200 pb-1 mb-2 flex items-center gap-1.5">
                <HelpCircle className="w-3.5 h-3.5 text-red-700" />
                <span>{hasCodingame ? '7. Viva-Voce & Review Questions' : '6. Viva-Voce & Review Questions'}</span>
              </h5>
              <div className="space-y-3">
                {experiment.quiz.map((q, i) => (
                  <div key={i} className="p-3 bg-zinc-50 border border-zinc-200 rounded-xl text-xs">
                    <p className="font-bold text-zinc-900 mb-1">
                      {i + 1}. {q.question}
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 text-zinc-600 pl-2">
                      {q.options.map((opt, optIdx) => (
                        <div key={optIdx} className={optIdx === q.correctAnswer ? 'font-bold text-emerald-700' : ''}>
                          ({String.fromCharCode(65 + optIdx)}) {opt} {optIdx === q.correctAnswer && '✓'}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Conclusion */}
          <div>
            <h5 className="font-bold text-red-900 uppercase tracking-wide text-xs border-b border-zinc-200 pb-1 mb-2">
              {hasCodingame ? '8. Conclusion' : '7. Conclusion'}
            </h5>
            <p className="p-3 bg-emerald-50/60 border border-emerald-200 rounded-xl text-xs sm:text-sm text-zinc-800">
              {experiment.conclusion || 'The experiment was executed and verified successfully against standard test vectors and algorithmic bounds.'}
            </p>
          </div>

          {/* Continuous Assessment Table */}
          <div className="pt-4 border-t border-zinc-200">
            <h5 className="font-bold text-zinc-900 text-xs uppercase tracking-wide mb-2">
              Continuous Assessment Rubric (Total: 20 Marks)
            </h5>
            <table className="w-full text-xs text-left border border-zinc-300">
              <thead className="bg-zinc-100 text-zinc-800 font-bold">
                <tr>
                  <th className="p-2 border border-zinc-300">Performance Criteria</th>
                  <th className="p-2 border border-zinc-300 text-center w-24">Max Marks</th>
                  <th className="p-2 border border-zinc-300 text-center w-28">Marks Obtained</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200">
                <tr>
                  <td className="p-2 border border-zinc-300">Aim, Theory & Algorithm Understanding</td>
                  <td className="p-2 border border-zinc-300 text-center">05</td>
                  <td className="p-2 border border-zinc-300 text-center"></td>
                </tr>
                <tr>
                  <td className="p-2 border border-zinc-300">Code Simulation & Result Verification</td>
                  <td className="p-2 border border-zinc-300 text-center">10</td>
                  <td className="p-2 border border-zinc-300 text-center"></td>
                </tr>
                <tr>
                  <td className="p-2 border border-zinc-300">Viva-Voce & Journal Documentation</td>
                  <td className="p-2 border border-zinc-300 text-center">05</td>
                  <td className="p-2 border border-zinc-300 text-center"></td>
                </tr>
              </tbody>
            </table>

            <div className="mt-8 pt-4 flex justify-between items-center text-xs text-zinc-600">
              <div className="text-center w-48 border-t border-zinc-400 pt-2 font-medium">
                Student Signature
              </div>
              <div className="text-center w-48 border-t border-zinc-400 pt-2 font-medium">
                Faculty In-Charge Signature
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 bg-zinc-100 border-t border-zinc-200 flex items-center justify-between shrink-0">
          <span className="text-xs text-zinc-500 font-mono">
            KJSIT Autonomous Virtual Lab Manual Export
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white hover:bg-zinc-200 border border-zinc-300 text-zinc-800 text-xs font-bold rounded-xl transition-all cursor-pointer"
            >
              Close
            </button>
            <button
              type="button"
              onClick={handlePrint}
              className="px-5 py-2 bg-linear-to-r from-red-700 via-red-600 to-rose-700 hover:from-red-600 hover:to-rose-600 text-white text-xs font-bold rounded-xl border border-white/30 backdrop-blur-md shadow-[0_4px_16px_-2px_rgba(220,38,38,0.4)] hover:shadow-[0_6px_20px_rgba(220,38,38,0.55)] active:scale-[0.98] transition-all cursor-pointer flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Export PDF</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
