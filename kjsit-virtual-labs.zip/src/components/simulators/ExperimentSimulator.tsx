import React from 'react';
import { findExperimentById } from '../../data/allExperiments';
import { UniversalExecutionTracer } from './common/UniversalExecutionTracer';
import { SimulationProvider } from './common/SimulationContext';
// DAA Simulators
import { BubbleSortSimulator } from './BubbleSortSimulator';
import { SelectionSortSimulator } from './SelectionSortSimulator';
import { InsertionSortSimulator } from './InsertionSortSimulator';
import { MergeSortSimulator } from './MergeSortSimulator';
import { QuickSortSimulator } from './QuickSortSimulator';
import { FractionalKnapsackSimulator } from './FractionalKnapsackSimulator';
import { KruskalsSimulator } from './KruskalsSimulator';
import { TSPSimulator } from './TSPSimulator';
import { NQueensSimulator } from './NQueensSimulator';
import { KMPSimulator } from './KMPSimulator';
import { SumOfSubsetsSimulator } from './SumOfSubsetsSimulator';
import { Knapsack01Simulator } from './Knapsack01Simulator';
import { GraphColoringSimulator } from './GraphColoringSimulator';
import { DijkstraSimulator } from './DijkstraSimulator';
import { FloydWarshallSimulator } from './FloydWarshallSimulator';

// DSA KJSIT Virtual Lab Simulators
import { LinkedListSimulator } from './dsa/LinkedListSimulator';
import { StackSimulator } from './dsa/StackSimulator';
import { QueueSimulator } from './dsa/QueueSimulator';
import { BSTSimulator } from './dsa/BSTSimulator';
import { AVLSimulator } from './dsa/AVLSimulator';
import { HeapSimulator } from './dsa/HeapSimulator';
import { GraphTraversalSimulator } from './dsa/GraphTraversalSimulator';
import { HashTableSimulator } from './dsa/HashTableSimulator';
import { SearchSimulator } from './dsa/SearchSimulator';
import { PolynomialSimulator } from './dsa/PolynomialSimulator';
import { SortingApplicationSimulator } from './dsa/SortingApplicationSimulator';

// Machine Learning KJSIT Virtual Lab Simulators
import { LinearRegressionSimulator } from './ml/LinearRegressionSimulator';
import { LogisticRegressionSimulator } from './ml/LogisticRegressionSimulator';
import { KNNSimulator } from './ml/KNNSimulator';
import { KMeansSimulator } from './ml/KMeansSimulator';
import { DecisionTreeSimulator } from './ml/DecisionTreeSimulator';
import { NaiveBayesSimulator } from './ml/NaiveBayesSimulator';
import { PerceptronSimulator } from './ml/PerceptronSimulator';
import { SVMSimulator } from './ml/SVMSimulator';
import { PCASimulator } from './ml/PCASimulator';

// DBMS KJSIT Virtual Lab Simulators
import { ERModelingSimulator } from './dbms/ERModelingSimulator';
import { SQLPlaygroundSimulator } from './dbms/SQLPlaygroundSimulator';
import { RelationalAlgebraSimulator } from './dbms/RelationalAlgebraSimulator';
import { RelationalJoinsSimulator } from './dbms/RelationalJoinsSimulator';
import { NormalizationSimulator } from './dbms/NormalizationSimulator';
import { TransactionConcurrencySimulator } from './dbms/TransactionConcurrencySimulator';
import { BPlusTreeSimulator } from './dbms/BPlusTreeSimulator';
import { PLSQLTriggerSimulator } from './dbms/PLSQLTriggerSimulator';
import { QueryOptimizerSimulator } from './dbms/QueryOptimizerSimulator';
import { RecoveryWALSimulator } from './dbms/RecoveryWALSimulator';
import { FrontendConnectivitySimulator } from './dbms/FrontendConnectivitySimulator';
import { CapstoneProjectSimulator } from './dbms/CapstoneProjectSimulator';

// Operating Systems KJSIT Virtual Lab Simulators
import { ProcessForkSimulator } from './os/ProcessForkSimulator';
import { CPUSchedulingSJFFCFSSimulator } from './os/CPUSchedulingSJFFCFSSimulator';
import { CPUSchedulingRRPrioritySimulator } from './os/CPUSchedulingRRPrioritySimulator';
import { IPCPipeSimulator } from './os/IPCPipeSimulator';
import { DiningPhilosophersSimulator } from './os/DiningPhilosophersSimulator';
import { BankersAlgorithmSimulator } from './os/BankersAlgorithmSimulator';
import { MemoryAllocationSimulator } from './os/MemoryAllocationSimulator';
import { PageReplacementSimulator } from './os/PageReplacementSimulator';
import { DiskSchedulingSimulator } from './os/DiskSchedulingSimulator';
import { PthreadsSimulator } from './os/PthreadsSimulator';

// Computer Networks KJSIT Virtual Lab Simulators
import { CRCSimulator } from './cn/CRCSimulator';
import { StopAndWaitSimulator } from './cn/StopAndWaitSimulator';
import { GoBackNSimulator } from './cn/GoBackNSimulator';
import { SelectiveRepeatSimulator } from './cn/SelectiveRepeatSimulator';
import { DistanceVectorSimulator } from './cn/DistanceVectorSimulator';
import { LinkStateOSPFSimulator } from './cn/LinkStateOSPFSimulator';
import { IPv4SubnettingSimulator } from './cn/IPv4SubnettingSimulator';
import { SocketProgrammingSimulator } from './cn/SocketProgrammingSimulator';
import { TCPCongestionControlSimulator } from './cn/TCPCongestionControlSimulator';
import { FramingStuffingSimulator } from './cn/FramingStuffingSimulator';

// Cryptography & Network Security KJSIT Virtual Lab Simulators
import { ClassicalCipherSimulator } from './cns/ClassicalCipherSimulator';
import { VigenereHillSimulator } from './cns/VigenereHillSimulator';
import { DESSimulator } from './cns/DESSimulator';
import { AESSimulator } from './cns/AESSimulator';
import { RSASimulator } from './cns/RSASimulator';
import { DiffieHellmanSimulator } from './cns/DiffieHellmanSimulator';
import { SHA256HashSimulator } from './cns/SHA256HashSimulator';
import { DigitalSignatureSimulator } from './cns/DigitalSignatureSimulator';
import { ECCSimulator } from './cns/ECCSimulator';
import { FirewallACLSimulator } from './cns/FirewallACLSimulator';

// Full Stack Web Computing KJSIT Virtual Lab Simulators
import { DOMBoxModelSimulator } from './fswc/DOMBoxModelSimulator';
import { DOMEventPropagationSimulator } from './fswc/DOMEventPropagationSimulator';
import { V8EventLoopSimulator } from './fswc/V8EventLoopSimulator';
import { RESTAPIPipelineSimulator } from './fswc/RESTAPIPipelineSimulator';
import { ExpressMiddlewareSimulator } from './fswc/ExpressMiddlewareSimulator';
import { MongoDBAggregationSimulator } from './fswc/MongoDBAggregationSimulator';
import { ReactVirtualDOMSimulator } from './fswc/ReactVirtualDOMSimulator';
import { JWTAuthSimulator } from './fswc/JWTAuthSimulator';
import { WebSocketRealtimeSimulator } from './fswc/WebSocketRealtimeSimulator';
import { OWASPSecuritySimulator } from './fswc/OWASPSecuritySimulator';

// Deep Reinforcement Learning (AIL 702) Simulators
import { DRLSimulator } from './dl/DRLSimulator';

// Natural Language Processing (CSC701) Simulators
import { NLPSimulator } from './nlp/NLPSimulator';

interface Props {
  experimentId: string;
  onSimulationComplete?: () => void;
}

export const ExperimentSimulator: React.FC<Props> = ({ experimentId, onSimulationComplete }) => {
  const renderContent = () => {
    switch (experimentId) {
      // ==========================================
      // DAA (Design & Analysis of Algorithms) Experiments
      // ==========================================
      case 'bubble-sort':
        return <BubbleSortSimulator onSimulationComplete={onSimulationComplete} />;
      case 'selection-sort':
        return <SelectionSortSimulator onSimulationComplete={onSimulationComplete} />;
      case 'insertion-sort':
        return <InsertionSortSimulator onSimulationComplete={onSimulationComplete} />;
      case 'merge-sort':
        return <MergeSortSimulator onSimulationComplete={onSimulationComplete} />;
      case 'quick-sort':
        return <QuickSortSimulator onSimulationComplete={onSimulationComplete} />;
      case 'fractional-knapsack':
      case 'knapsack-fractional':
        return <FractionalKnapsackSimulator onSimulationComplete={onSimulationComplete} />;
      case 'tsp':
      case 'travelling-salesperson':
      case 'traveling-salesperson':
        return <TSPSimulator onSimulationComplete={onSimulationComplete} />;
      case 'kruskals':
      case 'kruskal':
      case 'mst-kruskal':
        return <KruskalsSimulator onSimulationComplete={onSimulationComplete} />;
      case 'dijkstra':
        return <DijkstraSimulator onSimulationComplete={onSimulationComplete} />;

      // ==========================================
      // DSA (Data Structures & Algorithms - AIL302) Experiments
      // ==========================================
      case 'stack-adt-linked-list':
      case 'stack-operations':
      case 'stack':
        return <StackSimulator initialMode="stack" allowedMode="stack" onSimulationComplete={onSimulationComplete} />;
      case 'linear-queue-adt':
      case 'queue-circular-queue':
      case 'queue':
      case 'circular-queue':
        return <QueueSimulator onSimulationComplete={onSimulationComplete} />;
      case 'infix-to-postfix':
      case 'infix-postfix':
        return <StackSimulator initialMode="infix" allowedMode="infix" onSimulationComplete={onSimulationComplete} />;
      case 'polynomial-arithmetic':
      case 'singly-linked-list':
      case 'linked-list':
        return <LinkedListSimulator onSimulationComplete={onSimulationComplete} />;
      case 'binary-tree-traversals':
      case 'binary-tree':
      case 'avl-tree':
      case 'avl':
        return <BSTSimulator onSimulationComplete={onSimulationComplete} />;
      case 'binary-search-tree-operations':
      case 'binary-search-tree':
      case 'bst':
        return <BSTSimulator onSimulationComplete={onSimulationComplete} />;
      case 'graph-traversals-dfs-bfs':
      case 'graph-traversals':
      case 'bfs-dfs':
        return <GraphTraversalSimulator onSimulationComplete={onSimulationComplete} />;
    case 'sorting-algorithms-application':
    case 'sorting-application':
    case 'binary-heap':
    case 'heap':
    case 'hash-table':
    case 'hashing':
    case 'search-analysis':
    case 'linear-binary-search':
      return <SortingApplicationSimulator onSimulationComplete={onSimulationComplete} />;

    // ==========================================
    // Machine Learning & Pattern Recognition Experiments
    // ==========================================
    case 'linear-regression':
      return <LinearRegressionSimulator />;
    case 'logistic-regression':
      return <LogisticRegressionSimulator />;
    case 'knn-classifier':
    case 'knn-classification':
    case 'knn':
      return <KNNSimulator />;
    case 'kmeans-clustering':
    case 'kmeans':
      return <KMeansSimulator />;
    case 'decision-tree':
      return <DecisionTreeSimulator />;
    case 'naive-bayes':
      return <NaiveBayesSimulator />;
    case 'perceptron-neural-net':
    case 'perceptron-learning':
    case 'perceptron':
      return <PerceptronSimulator />;
    case 'svm-classifier':
    case 'svm':
      return <SVMSimulator />;
    case 'pca-reduction':
    case 'pca-dimension-reduction':
    case 'pca':
      return <PCASimulator />;

    // ==========================================
    // DBMS (Database Management Systems) Experiments - KJSIT Lab Manual
    // ==========================================
    // Practical 1: ER Model Design
    case 'er-model-design':
    case 'er-modeling':
    case 'er-diagram':
      return <ERModelingSimulator />;
      
    // Practical 2: Table Constraints
    case 'table-constraints':
    case 'constraints':
    case 'sql-constraints':
      return <SQLPlaygroundSimulator />;
      
    // Practical 3: DML Operations
    case 'dml-operations':
    case 'dml':
    case 'ddl-dml-sql':
    case 'ddl-dml-fundamentals':
    case 'sql-fundamentals':
      return <SQLPlaygroundSimulator />;
      
    // Practical 4: SELECT Queries
    case 'select-queries':
    case 'select-query':
    case 'select-filtering':
      return <SQLPlaygroundSimulator />;
      
    // Practical 5: Aggregate Functions
    case 'aggregate-functions':
    case 'group-by-having':
    case 'aggregates':
      return <SQLPlaygroundSimulator />;
      
    // Practical 6: Joins and Subqueries
    case 'joins-and-subqueries':
    case 'sql-joins-subqueries':
    case 'sql-joins':
    case 'relational-algebra':
      return <RelationalJoinsSimulator />;
      
    // Practical 7: Views and Indexes
    case 'views-and-indexes':
    case 'bplus-tree-indexing':
    case 'b-plus-tree-indexing':
    case 'normalization-lossless':
    case 'normalization':
      return <BPlusTreeSimulator />;
      
    // Practical 8: Transactions and DCL
    case 'transactions-and-dcl':
    case 'dcl':
    case 'transactions-dcl':
    case 'transaction-concurrency':
    case 'transactions-concurrency':
      return <TransactionConcurrencySimulator />;
      
    // Practical 9: Front-end Connectivity
    case 'frontend-connectivity':
    case 'front-end-connectivity':
    case 'db-frontend-connectivity':
      return <FrontendConnectivitySimulator />;
      
    // Practical 10: Capstone Project
    case 'capstone-project':
    case 'dbms-capstone-project':
    case 'capstone':
      return <CapstoneProjectSimulator />;

    case 'plsql-stored-procedures-triggers':
    case 'plsql-procedures-triggers':
      return <PLSQLTriggerSimulator />;
    case 'query-optimization-cost':
    case 'query-optimization':
      return <QueryOptimizerSimulator />;
    case 'db-recovery-logging':
    case 'crash-recovery-aries':
      return <RecoveryWALSimulator />;

    // ==========================================
    // Operating Systems Experiments
    // ==========================================
    case 'process-system-calls':
    case 'process-creation-fork-exec':
    case 'fork-exec':
      return <ProcessForkSimulator />;
    case 'cpu-scheduling-sjf-fcfs':
    case 'cpu-scheduling-fcfs-sjf':
      return <CPUSchedulingSJFFCFSSimulator />;
    case 'cpu-scheduling-rr-priority':
    case 'cpu-scheduling-priority-rr':
      return <CPUSchedulingRRPrioritySimulator />;
    case 'ipc-pipes-shared-memory':
    case 'ipc-pipes':
      return <IPCPipeSimulator />;
    case 'process-synchronization-semaphores':
    case 'dining-philosophers':
      return <DiningPhilosophersSimulator />;
    case 'bankers-deadlock-avoidance':
    case 'bankers-algorithm':
      return <BankersAlgorithmSimulator />;
    case 'memory-allocation-strategies':
    case 'memory-allocation':
      return <MemoryAllocationSimulator />;
    case 'page-replacement-algorithms':
    case 'page-replacement':
      return <PageReplacementSimulator />;
    case 'disk-scheduling-algorithms':
    case 'disk-scheduling':
      return <DiskSchedulingSimulator />;
    case 'thread-concurrency-pthreads':
    case 'pthread-multithreading-concurrency':
    case 'pthreads':
      return <PthreadsSimulator />;

    // ==========================================
    // Computer Networks Experiments
    // ==========================================
    case 'crc-error-detection':
    case 'crc':
      return <CRCSimulator />;
    case 'stop-and-wait-arq':
    case 'stop-and-wait-protocol':
    case 'stop-and-wait':
      return <StopAndWaitSimulator />;
    case 'sliding-window-gbn':
    case 'sliding-window-gobackn':
    case 'gobackn':
      return <GoBackNSimulator />;
    case 'sliding-window-sr':
    case 'sliding-window-selective-repeat':
    case 'selective-repeat':
      return <SelectiveRepeatSimulator />;
    case 'distance-vector-routing':
    case 'distance-vector':
      return <DistanceVectorSimulator />;
    case 'link-state-routing':
    case 'link-state-ospf-routing':
    case 'link-state-ospf':
      return <LinkStateOSPFSimulator />;
    case 'ipv4-subnetting-vlsm':
    case 'subnetting':
      return <IPv4SubnettingSimulator />;
    case 'socket-programming-tcp-udp':
    case 'socket-programming':
      return <SocketProgrammingSimulator />;
    case 'tcp-congestion-control':
      return <TCPCongestionControlSimulator />;
    case 'framing-bit-byte-stuffing':
    case 'framing-stuffing':
      return <FramingStuffingSimulator />;

    // ==========================================
    // Cryptography & Network Security Experiments
    // ==========================================
    case 'classical-ciphers':
    case 'cns-exp1':
      return <ClassicalCipherSimulator />;
    case 'polyalphabetic-transposition':
    case 'cns-exp2':
      return <VigenereHillSimulator />;
    case 'des-feistel-cipher':
    case 'cns-exp3':
      return <DESSimulator />;
    case 'aes-rijndael-cipher':
    case 'cns-exp4':
      return <AESSimulator />;
    case 'rsa-cryptosystem':
    case 'cns-exp5':
      return <RSASimulator />;
    case 'diffie-hellman-key-exchange':
    case 'cns-exp6':
      return <DiffieHellmanSimulator />;
    case 'sha256-hash-avalanche':
    case 'cns-exp7':
      return <SHA256HashSimulator />;
    case 'digital-signatures-rsa-dsa':
    case 'cns-exp8':
      return <DigitalSignatureSimulator />;
    case 'elliptic-curve-cryptography-ecc':
    case 'cns-exp9':
      return <ECCSimulator />;
    case 'network-security-firewall-tls':
    case 'cns-exp10':
      return <FirewallACLSimulator />;

    // ==========================================
    // Full Stack Web Computing Experiments
    // ==========================================
    case 'fswc-exp1':
    case 'dom-box-model':
      return <DOMBoxModelSimulator />;
    case 'fswc-exp2':
    case 'dom-event-propagation':
      return <DOMEventPropagationSimulator />;
    case 'fswc-exp3':
    case 'v8-event-loop':
      return <V8EventLoopSimulator />;
    case 'fswc-exp4':
    case 'rest-api-pipeline':
      return <RESTAPIPipelineSimulator />;
    case 'fswc-exp5':
    case 'express-middleware':
      return <ExpressMiddlewareSimulator />;
    case 'fswc-exp6':
    case 'mongodb-aggregation':
      return <MongoDBAggregationSimulator />;
    case 'fswc-exp7':
    case 'react-virtual-dom':
      return <ReactVirtualDOMSimulator />;
    case 'fswc-exp8':
    case 'jwt-auth-security':
      return <JWTAuthSimulator />;
    case 'fswc-exp9':
    case 'websocket-realtime':
      return <WebSocketRealtimeSimulator />;
    case 'fswc-exp10':
    case 'owasp-security':
      return <OWASPSecuritySimulator />;

    // ==========================================
    // Deep Reinforcement Learning (AIL 702) Experiments
    // ==========================================
    case 'dl-exp1':
    case 'dl-exp2':
    case 'dl-exp3':
    case 'dl-exp4':
    case 'dl-exp5':
    case 'dl-exp6':
    case 'dl-exp7':
    case 'dl-exp8':
    case 'dl-exp9':
    case 'teachable-machine':
    case 'xor-backprop':
    case 'cnn-multiclass':
    case 'rnn-lstm-gru':
    case 'multi-armed-bandit':
    case 'mdp-discount-factor':
    case 'dynamic-programming-mdp':
    case 'monte-carlo-mdp':
      return <DRLSimulator experimentId={experimentId} onSimulationComplete={onSimulationComplete} />;

    // ==========================================
    // Natural Language Processing (CSC701) Experiments
    // ==========================================
    case 'nlp-exp1':
    case 'nlp-exp2':
    case 'nlp-exp3':
    case 'nlp-exp4':
    case 'nlp-exp5':
    case 'nlp-exp6':
    case 'nlp-exp7':
    case 'nlp-exp8':
    case 'text-preprocessing':
    case 'ngram-language-model':
    case 'spacy-pos-ner':
    case 'naive-bayes-text':
    case 'vader-sentiment':
    case 'word2vec-embeddings':
    case 'bert-transformer':
    case 'lstm-next-word':
      return <NLPSimulator experimentId={experimentId} onSimulationComplete={onSimulationComplete} />;

    default: {
      const found = findExperimentById(experimentId);
      if (found?.experiment) {
        return (
          <UniversalExecutionTracer
            experiment={found.experiment}
            onSimulationComplete={onSimulationComplete}
          />
        );
      }
      return (
        <div className="bg-white border border-slate-200 rounded-xl p-8 shadow-sm text-center">
          <h3 className="text-lg font-bold text-slate-800 mb-2">Interactive Algorithm Simulator</h3>
          <p className="text-sm text-slate-500 max-w-md mx-auto mb-4">
            Select a specific experiment simulation or test your algorithm directly in the Monaco IDE Code tab.
          </p>
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-100 border border-slate-200 text-xs font-mono text-slate-600">
            Experiment ID: <span className="font-bold text-red-600">{experimentId}</span>
          </div>
        </div>
      );
    }
    }
  };

  return (
    <SimulationProvider onSimulationComplete={onSimulationComplete}>
      {renderContent()}
    </SimulationProvider>
  );
};
