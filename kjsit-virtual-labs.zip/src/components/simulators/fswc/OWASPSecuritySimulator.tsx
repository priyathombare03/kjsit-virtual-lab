import React, { useState } from 'react';
import { ShieldAlert, ShieldCheck, AlertTriangle, Bug, Lock, Terminal, RefreshCw, CheckCircle2, Code, Play } from 'lucide-react';

export const OWASPSecuritySimulator: React.FC = () => {
  const [activeVector, setActiveVector] = useState<'xss' | 'csrf' | 'nosql' | 'csp'>('xss');

  // XSS Sandbox State
  const [xssPayload, setXssPayload] = useState<string>("<script>alert('XSS Compromise: Document Cookie stolen!')</script><img src=x onerror=\"alert('Reflected XSS Execution')\" />");
  const [enableXSSPurify, setEnableXSSPurify] = useState<boolean>(false);
  const [xssExecutionLog, setXssExecutionLog] = useState<string[]>([]);

  // CSRF Sandbox State
  const [enableSameSite, setEnableSameSite] = useState<boolean>(false);
  const [enableAntiCsrfToken, setEnableAntiCsrfToken] = useState<boolean>(false);
  const [csrfAttackStatus, setCsrfAttackStatus] = useState<string | null>(null);

  // NoSQL Injection State
  const [nosqlInput, setNosqlInput] = useState<string>('{ "$ne": null }');
  const [enableSanitize, setEnableSanitize] = useState<boolean>(false);
  const [nosqlResult, setNosqlResult] = useState<string | null>(null);

  // CSP State
  const [cspHeader, setCspHeader] = useState<string>("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; object-src 'none';");
  const [testScriptOrigin, setTestScriptOrigin] = useState<string>('https://malicious-cdn.com/evil.js');
  const [cspCheckResult, setCspCheckResult] = useState<string | null>(null);

  const handleTestXSS = () => {
    if (enableXSSPurify) {
      // Escape script tags
      const sanitized = xssPayload
        .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
        .replace(/onerror\s*=\s*"[^"]*"/gi, '')
        .replace(/onerror\s*=\s*'[^']*'/gi, '');
      setXssExecutionLog([
        `[DOMPurify]: Stripped malicious tags and event listeners.`,
        `[Rendered Clean Output]: "${sanitized}"`,
        `[Defense Status]: SECURE. No inline script execution occurred.`
      ]);
    } else {
      setXssExecutionLog([
        `[VULNERABLE raw innerHTML]: Script payload injected directly into DOM.`,
        `[BROWSER EXECUTION]: Reflected XSS triggered! Attacker acquired document.cookie / localStorage session keys.`,
        `[Security Warning]: OWASP A03:2021 Injection detected!`
      ]);
    }
  };

  const handleTestCSRF = () => {
    if (enableSameSite || enableAntiCsrfToken) {
      setCsrfAttackStatus('PROTECTED: Cross-origin forged POST request rejected. SameSite=Strict blocked session cookies and Anti-CSRF token verification failed.');
    } else {
      setCsrfAttackStatus('VULNERABLE: Forged cross-site request successfully executed state change (Fund Transfer / Password Reset) using browser ambient session cookie!');
    }
  };

  const handleTestNoSQL = () => {
    if (enableSanitize) {
      setNosqlResult('PROTECTED: mongo-sanitize stripped operator keys starting with "$". Query executed safely as literal string matching zero accounts.');
    } else {
      setNosqlResult('VULNERABLE: Query `db.users.find({ username: "admin", password: { $ne: null } })` evaluated to true for all records! Attacker authenticated without valid credentials.');
    }
  };

  const handleTestCSP = () => {
    if (cspHeader.includes(testScriptOrigin) || cspHeader.includes('*')) {
      setCspCheckResult(`PERMITTED: Origin ${testScriptOrigin} matches active CSP policy.`);
    } else {
      setCspCheckResult(`BLOCKED by Browser CSP Engine: Refused to load script from '${testScriptOrigin}' because it violates Directive 'script-src 'self''.`);
    }
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-zinc-200">
        <div>
          <span className="text-xs font-bold font-mono uppercase tracking-wider text-red-700 bg-red-50 px-2.5 py-1 rounded-md border border-red-100">
            FSWC Lab Exp #10 Interactive Simulator
          </span>
          <h2 className="text-xl font-black text-zinc-900 mt-1">OWASP Top 10 Web Application Vulnerability & Defense Sandbox</h2>
          <p className="text-xs text-zinc-500">Interactive exploit simulation & mitigation tests for XSS, CSRF, NoSQL Injection, and Content Security Policy (CSP)</p>
        </div>

        <div className="flex bg-zinc-100 p-1 rounded-xl">
          {[
            { key: 'xss', label: '1. XSS' },
            { key: 'csrf', label: '2. CSRF' },
            { key: 'nosql', label: '3. NoSQL Injection' },
            { key: 'csp', label: '4. CSP Headers' }
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveVector(tab.key as any)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                activeVector === tab.key ? 'bg-white text-red-700 shadow-xs' : 'text-zinc-600 hover:text-zinc-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* 1. XSS Sandbox */}
      {activeVector === 'xss' && (
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6 text-xs">
          <div className="lg:col-span-6 bg-zinc-50 border border-zinc-200 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-bold text-zinc-900 flex items-center gap-2">
              <Bug className="w-4 h-4 text-red-700" />
              Cross-Site Scripting (XSS) Exploit Lab
            </h3>

            <div>
              <label className="font-bold text-zinc-700 block mb-1">Malicious HTML/JS Payload:</label>
              <textarea
                rows={3}
                value={xssPayload}
                onChange={(e) => setXssPayload(e.target.value)}
                className="w-full bg-zinc-900 text-red-300 border border-zinc-700 rounded-lg p-2.5 font-mono text-xs"
              />
            </div>

            <div className="bg-white p-3.5 rounded-lg border border-zinc-200 flex items-center justify-between">
              <div>
                <span className="font-bold text-zinc-800 block">Enable DOMPurify / Context Sanitization</span>
                <span className="text-[11px] text-zinc-500 font-mono">sanitizeHtml(dirtyPayload)</span>
              </div>
              <input
                type="checkbox"
                checked={enableXSSPurify}
                onChange={(e) => setEnableXSSPurify(e.target.checked)}
                className="accent-red-700 w-4 h-4"
              />
            </div>

            <button
              onClick={handleTestXSS}
              className="w-full py-2.5 bg-red-700 hover:bg-red-800 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition cursor-pointer shadow-xs"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Simulate DOM Rendering</span>
            </button>
          </div>

          <div className="lg:col-span-6 bg-zinc-900 text-zinc-100 rounded-xl p-5 font-mono flex flex-col border border-zinc-800">
            <div className="text-[11px] font-sans font-bold uppercase tracking-wider text-zinc-400 pb-3 border-b border-zinc-800 mb-3">
              Browser Execution Telemetry & Security Alert
            </div>

            <div className="space-y-2 flex-1">
              {xssExecutionLog.length === 0 ? (
                <div className="text-zinc-500 font-sans text-xs italic">
                  Click "Simulate DOM Rendering" to evaluate injection payload with or without DOMPurify protection.
                </div>
              ) : (
                xssExecutionLog.map((log, idx) => (
                  <div
                    key={idx}
                    className={`p-2.5 rounded-lg border text-xs ${
                      log.includes('VULNERABLE') || log.includes('Reflected XSS')
                        ? 'bg-rose-950/60 border-rose-500/50 text-rose-300'
                        : 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300'
                    }`}
                  >
                    {log}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* 2. CSRF Sandbox */}
      {activeVector === 'csrf' && (
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6 text-xs">
          <div className="lg:col-span-6 bg-zinc-50 border border-zinc-200 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-bold text-zinc-900 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-red-700" />
              Cross-Site Request Forgery (CSRF) Sandbox
            </h3>

            <div className="bg-white p-3 rounded-lg border border-zinc-200 space-y-1 font-mono text-[11px] text-zinc-600">
              <div className="font-bold text-zinc-900 font-sans">Simulated Forged Exploit Form:</div>
              <div>&lt;form action="http://bank.vlab/api/transfer" method="POST"&gt;</div>
              <div>&nbsp;&nbsp;&lt;input name="recipient" value="attacker_id" /&gt;</div>
              <div>&nbsp;&nbsp;&lt;input name="amount" value="50000" /&gt;</div>
              <div>&lt;/form&gt;&lt;script&gt;document.forms[0].submit();&lt;/script&gt;</div>
            </div>

            <div className="space-y-2">
              <div className="bg-white p-3 rounded-lg border border-zinc-200 flex items-center justify-between">
                <div>
                  <span className="font-bold text-zinc-800 block">Cookie SameSite=Strict & HttpOnly</span>
                  <span className="text-[11px] text-zinc-500">Blocks ambient browser credential attachment on cross-origin POST</span>
                </div>
                <input
                  type="checkbox"
                  checked={enableSameSite}
                  onChange={(e) => setEnableSameSite(e.target.checked)}
                  className="accent-red-700 w-4 h-4"
                />
              </div>

              <div className="bg-white p-3 rounded-lg border border-zinc-200 flex items-center justify-between">
                <div>
                  <span className="font-bold text-zinc-800 block">Anti-CSRF Synchronizer Token Check</span>
                  <span className="text-[11px] text-zinc-500">Requires secret per-session token in custom X-CSRF-Token header</span>
                </div>
                <input
                  type="checkbox"
                  checked={enableAntiCsrfToken}
                  onChange={(e) => setEnableAntiCsrfToken(e.target.checked)}
                  className="accent-red-700 w-4 h-4"
                />
              </div>
            </div>

            <button
              onClick={handleTestCSRF}
              className="w-full py-2.5 bg-red-700 hover:bg-red-800 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition cursor-pointer shadow-xs"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Simulate Attacker Cross-Origin Attack</span>
            </button>
          </div>

          <div className="lg:col-span-6 bg-zinc-900 text-zinc-100 rounded-xl p-5 font-mono flex flex-col border border-zinc-800">
            <div className="text-[11px] font-sans font-bold uppercase tracking-wider text-zinc-400 pb-3 border-b border-zinc-800 mb-3">
              Server Defense Verification
            </div>

            <div className="flex-1 flex flex-col justify-center">
              {csrfAttackStatus ? (
                <div className={`p-4 rounded-xl border ${
                  csrfAttackStatus.startsWith('PROTECTED')
                    ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300'
                    : 'bg-rose-950/60 border-rose-500/50 text-rose-300'
                }`}>
                  <div className="font-bold text-xs mb-1 font-sans">
                    {csrfAttackStatus.startsWith('PROTECTED') ? 'Defense Active: CSRF Prevented' : 'Exploit Succeeded: CSRF Vulnerability'}
                  </div>
                  <p className="text-[11px] leading-relaxed opacity-90">{csrfAttackStatus}</p>
                </div>
              ) : (
                <div className="text-zinc-500 font-sans text-xs italic text-center">
                  Configure defenses and test the simulated forged request.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 3. NoSQL Injection */}
      {activeVector === 'nosql' && (
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6 text-xs">
          <div className="lg:col-span-6 bg-zinc-50 border border-zinc-200 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-bold text-zinc-900 flex items-center gap-2">
              <Lock className="w-4 h-4 text-red-700" />
              NoSQL Operator Injection Lab
            </h3>

            <div>
              <label className="font-bold text-zinc-700 block mb-1">Injected Password Payload (BSON Operator):</label>
              <input
                type="text"
                value={nosqlInput}
                onChange={(e) => setNosqlInput(e.target.value)}
                className="w-full bg-zinc-900 text-red-300 border border-zinc-700 rounded-lg p-2.5 font-mono text-xs"
              />
            </div>

            <div className="bg-white p-3.5 rounded-lg border border-zinc-200 flex items-center justify-between">
              <div>
                <span className="font-bold text-zinc-800 block">Enable mongo-sanitize Middleware</span>
                <span className="text-[11px] text-zinc-500">Strips '$' and '.' from request body keys</span>
              </div>
              <input
                type="checkbox"
                checked={enableSanitize}
                onChange={(e) => setEnableSanitize(e.target.checked)}
                className="accent-red-700 w-4 h-4"
              />
            </div>

            <button
              onClick={handleTestNoSQL}
              className="w-full py-2.5 bg-red-700 hover:bg-red-800 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition cursor-pointer shadow-xs"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Execute Auth Query</span>
            </button>
          </div>

          <div className="lg:col-span-6 bg-zinc-900 text-zinc-100 rounded-xl p-5 font-mono flex flex-col border border-zinc-800">
            <div className="text-[11px] font-sans font-bold uppercase tracking-wider text-zinc-400 pb-3 border-b border-zinc-800 mb-3">
              Database Evaluation & Authentication Result
            </div>

            <div className="flex-1 flex flex-col justify-center">
              {nosqlResult ? (
                <div className={`p-4 rounded-xl border ${
                  nosqlResult.startsWith('PROTECTED')
                    ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300'
                    : 'bg-rose-950/60 border-rose-500/50 text-rose-300'
                }`}>
                  <div className="font-bold text-xs mb-1 font-sans">
                    {nosqlResult.startsWith('PROTECTED') ? 'NoSQL Query Sanitized' : 'Auth Bypass via $ne: null'}
                  </div>
                  <p className="text-[11px] leading-relaxed opacity-90">{nosqlResult}</p>
                </div>
              ) : (
                <div className="text-zinc-500 font-sans text-xs italic text-center">
                  Click "Execute Auth Query" to test BSON query operator behavior.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 4. CSP Headers */}
      {activeVector === 'csp' && (
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6 text-xs">
          <div className="lg:col-span-6 bg-zinc-50 border border-zinc-200 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-bold text-zinc-900 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-red-700" />
              Content-Security-Policy (CSP) Header Formulator
            </h3>

            <div>
              <label className="font-bold text-zinc-700 block mb-1">Server Content-Security-Policy Header:</label>
              <textarea
                rows={3}
                value={cspHeader}
                onChange={(e) => setCspHeader(e.target.value)}
                className="w-full bg-white border border-zinc-300 rounded-lg p-2.5 font-mono text-xs"
              />
            </div>

            <div>
              <label className="font-bold text-zinc-700 block mb-1">Candidate External Script URL:</label>
              <input
                type="text"
                value={testScriptOrigin}
                onChange={(e) => setTestScriptOrigin(e.target.value)}
                className="w-full bg-white border border-zinc-300 rounded-lg p-2 font-mono text-xs"
              />
            </div>

            <button
              onClick={handleTestCSP}
              className="w-full py-2.5 bg-red-700 hover:bg-red-800 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition cursor-pointer shadow-xs"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Validate Origin Against CSP Directives</span>
            </button>
          </div>

          <div className="lg:col-span-6 bg-zinc-900 text-zinc-100 rounded-xl p-5 font-mono flex flex-col border border-zinc-800">
            <div className="text-[11px] font-sans font-bold uppercase tracking-wider text-zinc-400 pb-3 border-b border-zinc-800 mb-3">
              Browser CSP Enforcement Engine
            </div>

            <div className="flex-1 flex flex-col justify-center">
              {cspCheckResult ? (
                <div className={`p-4 rounded-xl border ${
                  cspCheckResult.startsWith('PERMITTED')
                    ? 'bg-amber-950/60 border-amber-500/50 text-amber-300'
                    : 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300'
                }`}>
                  <div className="font-bold text-xs mb-1 font-sans">
                    {cspCheckResult.startsWith('PERMITTED') ? 'Origin Allowed by Whitelist' : 'External Asset Blocked by Strict CSP'}
                  </div>
                  <p className="text-[11px] leading-relaxed opacity-90">{cspCheckResult}</p>
                </div>
              ) : (
                <div className="text-zinc-500 font-sans text-xs italic text-center">
                  Enter script origin and click validate to check against policy directives.
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
