import React, { useState } from 'react';
import { KeyRound, Shield, Lock, Unlock, AlertTriangle, CheckCircle2, Copy, RefreshCw, Layers } from 'lucide-react';

export const JWTAuthSimulator: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'jwt' | 'bcrypt'>('jwt');

  // JWT State
  const [userId, setUserId] = useState<string>('usr_9921');
  const [role, setRole] = useState<'student' | 'instructor' | 'admin'>('student');
  const [secretKey, setSecretKey] = useState<string>('vlab-fullstack-secret-key-2025');
  const [tamperedRole, setTamperedRole] = useState<'student' | 'instructor' | 'admin'>('student');
  const [isTampered, setIsTampered] = useState<boolean>(false);

  // Bcrypt State
  const [plainPassword, setPlainPassword] = useState<string>('VLabSecure@2025');
  const [saltRounds, setSaltRounds] = useState<number>(10);
  const [generatedHash, setGeneratedHash] = useState<string>('$2b$10$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lW');
  const [verifyPasswordInput, setVerifyPasswordInput] = useState<string>('VLabSecure@2025');
  const [verifyResult, setVerifyResult] = useState<boolean | null>(true);

  // Base64 helpers
  const encodeB64 = (obj: any) => btoa(unescape(encodeURIComponent(JSON.stringify(obj)))).replace(/=/g, '');
  
  const headerObj = { alg: 'HS256', typ: 'JWT' };
  const payloadObj = {
    sub: userId,
    role: isTampered ? tamperedRole : role,
    iat: 1740124800,
    exp: 1740132000,
    iss: 'kjsit-vlab-auth'
  };

  const headerB64 = encodeB64(headerObj);
  const payloadB64 = encodeB64(payloadObj);
  const signatureRaw = `${headerB64}.${payloadB64}.${secretKey}`;
  const signatureHash = 'dBjftJeZ4CVP-mB92Kx7NqL8sTuPvW1Y_' + signatureRaw.length;

  const fullJWT = `${headerB64}.${payloadB64}.${signatureHash}`;

  const handleBcryptHash = () => {
    const randomSalt = Math.random().toString(36).substring(2, 12);
    setGeneratedHash(`$2b$${saltRounds}$${randomSalt}X3OXePaWxn96p36WQoeG6Lruj3vjPG`);
    setVerifyResult(null);
  };

  const handleVerifyPassword = () => {
    setVerifyResult(verifyPasswordInput === plainPassword);
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-zinc-200">
        <div>
          <span className="text-xs font-bold font-mono uppercase tracking-wider text-red-700 bg-red-50 px-2.5 py-1 rounded-md border border-red-100">
            FSWC Lab Exp #8 Interactive Simulator
          </span>
          <h2 className="text-xl font-black text-zinc-900 mt-1">JSON Web Token (JWT) Anatomy & Bcrypt Password Hashing Sandbox</h2>
          <p className="text-xs text-zinc-500">Inspect Header/Payload/HMAC-SHA256 signature, simulate client token tampering & test bcrypt adaptive hashing cost</p>
        </div>

        <div className="flex bg-zinc-100 p-1 rounded-xl">
          <button
            onClick={() => setActiveTab('jwt')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              activeTab === 'jwt' ? 'bg-white text-red-700 shadow-xs' : 'text-zinc-600 hover:text-zinc-900'
            }`}
          >
            JWT Token Architecture
          </button>
          <button
            onClick={() => setActiveTab('bcrypt')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              activeTab === 'bcrypt' ? 'bg-white text-red-700 shadow-xs' : 'text-zinc-600 hover:text-zinc-900'
            }`}
          >
            Bcrypt Salting & Cost
          </button>
        </div>
      </div>

      {/* Tab 1: JWT */}
      {activeTab === 'jwt' && (
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Token Configuration */}
          <div className="lg:col-span-5 bg-zinc-50 border border-zinc-200 rounded-xl p-5 space-y-4 text-xs">
            <h3 className="text-sm font-bold text-zinc-900 flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-red-700" />
              Token Claim Configurator
            </h3>

            <div>
              <label className="font-bold text-zinc-700 block mb-1">Subject (User ID):</label>
              <input
                type="text"
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                className="w-full bg-white border border-zinc-300 rounded-lg p-2 font-mono text-xs"
              />
            </div>

            <div>
              <label className="font-bold text-zinc-700 block mb-1">Assigned Role:</label>
              <select
                value={role}
                onChange={(e: any) => setRole(e.target.value)}
                className="w-full bg-white border border-zinc-300 rounded-lg p-2 font-mono text-xs font-semibold"
              >
                <option value="student">student (Default User)</option>
                <option value="instructor">instructor (Lab Evaluator)</option>
                <option value="admin">admin (Full System Root)</option>
              </select>
            </div>

            <div>
              <label className="font-bold text-zinc-700 block mb-1">Server HMAC Secret Key:</label>
              <input
                type="text"
                value={secretKey}
                onChange={(e) => setSecretKey(e.target.value)}
                className="w-full bg-white border border-zinc-300 rounded-lg p-2 font-mono text-xs text-red-700"
              />
            </div>

            {/* Tampering Simulation */}
            <div className="bg-rose-50 border border-rose-200 p-3.5 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-rose-900 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                  Client-side Tampering Attack
                </span>
                <input
                  type="checkbox"
                  id="tamper-check"
                  checked={isTampered}
                  onChange={(e) => setIsTampered(e.target.checked)}
                  className="accent-rose-700"
                />
              </div>

              {isTampered && (
                <div className="space-y-1.5 pt-1">
                  <label className="text-[11px] text-rose-800 font-semibold block">
                    Tamper Payload Role to:
                  </label>
                  <select
                    value={tamperedRole}
                    onChange={(e: any) => setTamperedRole(e.target.value)}
                    className="w-full bg-white border border-rose-300 rounded p-1.5 font-mono text-xs font-bold text-rose-700"
                  >
                    <option value="admin">admin (Privilege Escalation Attempt)</option>
                    <option value="instructor">instructor</option>
                  </select>
                  <p className="text-[10px] text-rose-700 font-mono">
                    Modifying payload without re-signing causes HMAC-SHA256 signature verification to fail!
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Right: JWT Structure Breakdown */}
          <div className="lg:col-span-7 flex flex-col space-y-4">
            {/* Raw Encoded JWT */}
            <div className="bg-zinc-900 rounded-xl p-4 text-xs font-mono border border-zinc-800">
              <div className="text-[11px] text-zinc-400 font-sans font-bold uppercase tracking-wider mb-2 flex justify-between">
                <span>Encoded JWT String (RFC 7519)</span>
                <span className="text-zinc-500">Authorization: Bearer ...</span>
              </div>
              <div className="p-3 bg-zinc-950 rounded-lg break-all leading-relaxed">
                <span className="text-red-400 font-bold">{headerB64}</span>
                <span className="text-zinc-400 font-bold">.</span>
                <span className="text-purple-400 font-bold">{payloadB64}</span>
                <span className="text-zinc-400 font-bold">.</span>
                <span className="text-emerald-400 font-bold">{signatureHash}</span>
              </div>
            </div>

            {/* Decoded Sections */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
              {/* Header */}
              <div className="bg-red-50 border border-red-200 p-3 rounded-lg">
                <div className="font-bold text-red-900 font-sans mb-1 text-[11px]">1. Header (Algorithm)</div>
                <pre className="text-red-800 text-[10px]">{JSON.stringify(headerObj, null, 2)}</pre>
              </div>

              {/* Payload */}
              <div className="bg-purple-50 border border-purple-200 p-3 rounded-lg">
                <div className="font-bold text-purple-900 font-sans mb-1 text-[11px]">2. Payload (Claims)</div>
                <pre className="text-purple-800 text-[10px]">{JSON.stringify(payloadObj, null, 2)}</pre>
              </div>

              {/* Signature */}
              <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-lg">
                <div className="font-bold text-emerald-900 font-sans mb-1 text-[11px]">3. HMAC Signature</div>
                <p className="text-emerald-800 text-[10px] font-mono leading-tight">
                  HMACSHA256(<br/>
                  &nbsp;&nbsp;base64Url(header) + "." +<br/>
                  &nbsp;&nbsp;base64Url(payload),<br/>
                  &nbsp;&nbsp;secretKey<br/>
                  )
                </p>
              </div>
            </div>

            {/* Server Verification Outcome */}
            <div className={`p-4 rounded-xl border flex items-center justify-between ${
              isTampered
                ? 'bg-rose-50 border-rose-300 text-rose-950'
                : 'bg-emerald-50 border-emerald-300 text-emerald-950'
            }`}>
              <div className="flex items-center gap-3">
                {isTampered ? (
                  <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
                ) : (
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                )}
                <div>
                  <div className="font-bold text-xs font-sans">
                    {isTampered ? 'Signature Verification FAILED (HTTP 403 Forbidden)' : 'Signature Validated Successfully (HTTP 200 OK)'}
                  </div>
                  <div className="text-[11px] text-zinc-600 font-mono mt-0.5">
                    {isTampered ? 'Payload hash mismatch with HMAC signature.' : `Verified role: ${role}. Access granted to protected route.`}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Bcrypt */}
      {activeTab === 'bcrypt' && (
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6 text-xs">
          <div className="lg:col-span-6 bg-zinc-50 border border-zinc-200 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-bold text-zinc-900 flex items-center gap-2">
              <Lock className="w-4 h-4 text-red-700" />
              Bcrypt Password Hasher
            </h3>

            <div>
              <label className="font-bold text-zinc-700 block mb-1">Plaintext Password:</label>
              <input
                type="text"
                value={plainPassword}
                onChange={(e) => setPlainPassword(e.target.value)}
                className="w-full bg-white border border-zinc-300 rounded-lg p-2 font-mono text-xs"
              />
            </div>

            <div>
              <div className="flex justify-between font-bold text-zinc-700 mb-1">
                <span>Salt Rounds (Work Factor Cost: 2^{saltRounds}):</span>
                <span className="font-mono text-red-700">{saltRounds} iterations (~{(Math.pow(2, saltRounds) / 10).toFixed(0)}ms)</span>
              </div>
              <input
                type="range"
                min="8"
                max="14"
                value={saltRounds}
                onChange={(e) => setSaltRounds(Number(e.target.value))}
                className="w-full accent-red-700"
              />
            </div>

            <button
              onClick={handleBcryptHash}
              className="w-full py-2.5 bg-red-700 hover:bg-red-800 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition cursor-pointer shadow-xs"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Generate bcrypt.hash(password, {saltRounds})</span>
            </button>
          </div>

          <div className="lg:col-span-6 space-y-4">
            {/* Hash breakdown */}
            <div className="bg-zinc-900 text-zinc-200 rounded-xl p-4 font-mono text-xs border border-zinc-800 space-y-2">
              <div className="text-[11px] text-zinc-400 font-sans font-bold uppercase tracking-wider">
                Bcrypt Hash Anatomy:
              </div>
              <div className="p-2.5 bg-zinc-950 rounded text-emerald-400 break-all font-bold">
                {generatedHash}
              </div>
              <div className="text-[10px] text-zinc-400 space-y-0.5 pt-1">
                <div><span className="text-amber-400">$2b$</span>: Algorithm ID (Bcrypt rev b)</div>
                <div><span className="text-amber-400">${saltRounds}$</span>: Cost Factor (2^{saltRounds} rounds)</div>
                <div><span className="text-amber-400">22 characters</span>: 128-bit Cryptographic Salt</div>
                <div><span className="text-amber-400">31 characters</span>: 184-bit Password Hash</div>
              </div>
            </div>

            {/* Test verify */}
            <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-4 space-y-3">
              <div className="font-bold text-zinc-900 font-sans text-xs">
                Test bcrypt.compare(inputPassword, hash):
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={verifyPasswordInput}
                  onChange={(e) => setVerifyPasswordInput(e.target.value)}
                  placeholder="Enter candidate password..."
                  className="flex-1 bg-white border border-zinc-300 rounded-lg px-3 py-2 text-xs font-mono"
                />
                <button
                  onClick={handleVerifyPassword}
                  className="px-4 py-2 bg-zinc-900 text-white rounded-lg font-bold hover:bg-zinc-800 cursor-pointer"
                >
                  Verify
                </button>
              </div>

              {verifyResult !== null && (
                <div className={`p-3 rounded-lg border flex items-center gap-2 ${
                  verifyResult ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-bold' : 'bg-rose-50 border-rose-300 text-rose-900 font-bold'
                }`}>
                  {verifyResult ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <AlertTriangle className="w-4 h-4 text-rose-600" />}
                  <span>{verifyResult ? 'bcrypt.compare() RETURNED TRUE: Authentication Successful' : 'bcrypt.compare() RETURNED FALSE: Invalid Password'}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
