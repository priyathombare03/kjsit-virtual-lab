import React, { useState } from 'react';
import { Database, Search, ArrowRight, Play, RotateCcw, Filter, Layers, Zap, Gauge } from 'lucide-react';

interface StudentDoc {
  _id: string;
  name: string;
  department: string;
  semester: number;
  gpa: number;
  credits: number;
  status: 'active' | 'graduated';
}

const initialDataset: StudentDoc[] = [
  { _id: '64f1a01', name: 'Aarav Sharma', department: 'CSE', semester: 6, gpa: 9.2, credits: 120, status: 'active' },
  { _id: '64f1a02', name: 'Diya Patel', department: 'CSE', semester: 6, gpa: 8.8, credits: 118, status: 'active' },
  { _id: '64f1a03', name: 'Rohan Verma', department: 'IT', semester: 4, gpa: 7.6, credits: 82, status: 'active' },
  { _id: '64f1a04', name: 'Ananya Iyer', department: 'IT', semester: 6, gpa: 9.5, credits: 122, status: 'active' },
  { _id: '64f1a05', name: 'Vikram Mehta', department: 'ECE', semester: 8, gpa: 8.1, credits: 156, status: 'graduated' },
  { _id: '64f1a06', name: 'Priya Joshi', department: 'CSE', semester: 4, gpa: 9.0, credits: 80, status: 'active' },
  { _id: '64f1a07', name: 'Kabir Singh', department: 'ECE', semester: 6, gpa: 7.2, credits: 114, status: 'active' },
  { _id: '64f1a08', name: 'Sneha Roy', department: 'IT', semester: 8, gpa: 8.9, credits: 160, status: 'graduated' }
];

export const MongoDBAggregationSimulator: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'pipeline' | 'indexing'>('pipeline');

  // Aggregation Pipeline Stage Controls
  const [matchDept, setMatchDept] = useState<string>('ALL');
  const [minGPA, setMinGPA] = useState<number>(7.0);
  const [groupByDept, setGroupByDept] = useState<boolean>(true);
  const [sortBy, setSortBy] = useState<'avgGPA' | 'studentCount'>('avgGPA');

  // Indexing Benchmark Controls
  const [hasCompoundIndex, setHasCompoundIndex] = useState<boolean>(false);
  const [datasetSize, setDatasetSize] = useState<number>(100000);
  const [explainResult, setExplainResult] = useState<{
    stage: string;
    docsExamined: number;
    docsReturned: number;
    executionTimeMs: number;
    indexUsed: string;
  } | null>(null);

  // Filter stage
  const filtered = initialDataset.filter(doc => {
    const deptMatch = matchDept === 'ALL' || doc.department === matchDept;
    const gpaMatch = doc.gpa >= minGPA;
    return deptMatch && gpaMatch;
  });

  // Group stage
  const groupedResult: Record<string, { count: number; totalGpa: number; avgGpa: number; totalCredits: number }> = {};
  filtered.forEach(doc => {
    const key = groupByDept ? doc.department : 'All Departments';
    if (!groupedResult[key]) {
      groupedResult[key] = { count: 0, totalGpa: 0, avgGpa: 0, totalCredits: 0 };
    }
    groupedResult[key].count += 1;
    groupedResult[key].totalGpa += doc.gpa;
    groupedResult[key].totalCredits += doc.credits;
    groupedResult[key].avgGpa = Number((groupedResult[key].totalGpa / groupedResult[key].count).toFixed(2));
  });

  const finalPipelineOutput = Object.entries(groupedResult).map(([dept, data]) => ({
    _id: dept,
    studentCount: data.count,
    avgGPA: data.avgGpa,
    totalCreditsEarned: data.totalCredits
  })).sort((a, b) => (sortBy === 'avgGPA' ? b.avgGPA - a.avgGPA : b.studentCount - a.studentCount));

  const runExplainBenchmark = () => {
    if (hasCompoundIndex) {
      setExplainResult({
        stage: 'IXSCAN (B-Tree Index Scan)',
        docsExamined: 412,
        docsReturned: 412,
        executionTimeMs: 1.4,
        indexUsed: '{ department: 1, gpa: -1 }'
      });
    } else {
      setExplainResult({
        stage: 'COLLSCAN (Full Collection Table Scan)',
        docsExamined: datasetSize,
        docsReturned: 412,
        executionTimeMs: 48.6,
        indexUsed: 'None (Unindexed Sequential Scan)'
      });
    }
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-zinc-200">
        <div>
          <span className="text-xs font-bold font-mono uppercase tracking-wider text-red-700 bg-red-50 px-2.5 py-1 rounded-md border border-red-100">
            FSWC Lab Exp #6 Interactive Simulator
          </span>
          <h2 className="text-xl font-black text-zinc-900 mt-1">MongoDB Document Schema & Aggregation Pipeline Engine</h2>
          <p className="text-xs text-zinc-500">Construct multi-stage $match, $group, $sort aggregation pipelines & benchmark IXSCAN vs COLLSCAN indexing</p>
        </div>

        <div className="flex bg-zinc-100 p-1 rounded-xl">
          <button
            onClick={() => setActiveTab('pipeline')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              activeTab === 'pipeline' ? 'bg-white text-red-700 shadow-xs' : 'text-zinc-600 hover:text-zinc-900'
            }`}
          >
            Aggregation Pipeline
          </button>
          <button
            onClick={() => setActiveTab('indexing')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              activeTab === 'indexing' ? 'bg-white text-red-700 shadow-xs' : 'text-zinc-600 hover:text-zinc-900'
            }`}
          >
            B-Tree Index Performance
          </button>
        </div>
      </div>

      {activeTab === 'pipeline' && (
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Controls */}
          <div className="lg:col-span-5 bg-zinc-50 border border-zinc-200 rounded-xl p-5 space-y-4 text-xs">
            <h3 className="text-sm font-bold text-zinc-900 flex items-center gap-2">
              <Filter className="w-4 h-4 text-red-700" />
              Pipeline Stage Configurator
            </h3>

            {/* Stage 1: $match */}
            <div className="bg-white p-3.5 rounded-lg border border-zinc-200 space-y-2">
              <div className="flex items-center justify-between font-mono font-bold text-red-700">
                <span>Stage 1: $match</span>
                <span className="text-[10px] text-zinc-500 font-sans">Filter criteria</span>
              </div>

              <div>
                <label className="text-zinc-700 font-semibold mb-1 block">Department:</label>
                <select
                  value={matchDept}
                  onChange={(e) => setMatchDept(e.target.value)}
                  className="w-full bg-zinc-50 border border-zinc-300 rounded p-1.5 font-mono text-xs"
                >
                  <option value="ALL">ALL Departments</option>
                  <option value="CSE">CSE</option>
                  <option value="IT">IT</option>
                  <option value="ECE">ECE</option>
                </select>
              </div>

              <div>
                <div className="flex justify-between text-zinc-700 font-semibold mb-1">
                  <span>Minimum GPA ($gte):</span>
                  <span className="font-mono text-red-700 font-bold">{minGPA}</span>
                </div>
                <input
                  type="range"
                  min="6.0"
                  max="9.5"
                  step="0.5"
                  value={minGPA}
                  onChange={(e) => setMinGPA(Number(e.target.value))}
                  className="w-full accent-red-700"
                />
              </div>
            </div>

            {/* Stage 2: $group */}
            <div className="bg-white p-3.5 rounded-lg border border-zinc-200 space-y-2">
              <div className="flex items-center justify-between font-mono font-bold text-emerald-700">
                <span>Stage 2: $group</span>
                <span className="text-[10px] text-zinc-500 font-sans">Accumulators</span>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="group-dept"
                  checked={groupByDept}
                  onChange={(e) => setGroupByDept(e.target.checked)}
                  className="accent-red-700"
                />
                <label htmlFor="group-dept" className="text-zinc-700 font-semibold cursor-pointer">
                  _id: "$department" (Group by branch)
                </label>
              </div>
              <p className="text-[11px] text-zinc-500 font-mono">
                Accumulates: &#123; avgGPA: &#123; $avg: "$gpa" &#125;, count: &#123; $sum: 1 &#125; &#125;
              </p>
            </div>

            {/* Stage 3: $sort */}
            <div className="bg-white p-3.5 rounded-lg border border-zinc-200 space-y-2">
              <div className="flex items-center justify-between font-mono font-bold text-blue-700">
                <span>Stage 3: $sort</span>
                <span className="text-[10px] text-zinc-500 font-sans">Order cursor</span>
              </div>

              <select
                value={sortBy}
                onChange={(e: any) => setSortBy(e.target.value)}
                className="w-full bg-zinc-50 border border-zinc-300 rounded p-1.5 font-mono text-xs"
              >
                <option value="avgGPA">avgGPA: -1 (Highest GPA First)</option>
                <option value="studentCount">studentCount: -1 (Most Students First)</option>
              </select>
            </div>
          </div>

          {/* Pipeline Code & Output */}
          <div className="lg:col-span-7 flex flex-col space-y-4">
            {/* MongoDB Query JSON */}
            <div className="bg-zinc-900 text-zinc-200 rounded-xl p-4 font-mono text-xs border border-zinc-800">
              <div className="text-[11px] text-zinc-400 font-sans font-bold uppercase tracking-wider mb-2">
                Generated MongoDB Pipeline Query:
              </div>
              <pre className="text-emerald-400 overflow-x-auto text-[11px]">
{`db.students.aggregate([
  {
    $match: {
      ${matchDept !== 'ALL' ? `department: "${matchDept}",\n      ` : ''}gpa: { $gte: ${minGPA} }
    }
  },
  {
    $group: {
      _id: ${groupByDept ? '"$department"' : 'null'},
      studentCount: { $sum: 1 },
      avgGPA: { $avg: "$gpa" },
      totalCreditsEarned: { $sum: "$credits" }
    }
  },
  {
    $sort: { ${sortBy}: -1 }
  }
]);`}
              </pre>
            </div>

            {/* Aggregated Output Records */}
            <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-4 flex-1">
              <div className="flex items-center justify-between mb-3 text-xs font-bold text-zinc-900">
                <span>Aggregation Result Set ({finalPipelineOutput.length} documents)</span>
                <span className="text-[11px] font-mono text-zinc-500">{filtered.length} docs processed from 8</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {finalPipelineOutput.map((record, idx) => (
                  <div key={idx} className="bg-white p-3 rounded-lg border border-zinc-200 shadow-2xs font-mono text-xs">
                    <div className="flex items-center justify-between font-bold text-red-700 pb-1 border-b border-zinc-100">
                      <span>_id: "{record._id}"</span>
                      <span className="text-zinc-500 font-normal text-[10px]">Doc #{idx + 1}</span>
                    </div>
                    <div className="mt-2 space-y-1 text-zinc-700 text-[11px]">
                      <div className="flex justify-between">
                        <span className="text-zinc-500">studentCount:</span>
                        <span className="font-bold">{record.studentCount}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-zinc-500">avgGPA:</span>
                        <span className="font-bold text-emerald-700">{record.avgGPA}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-zinc-500">totalCreditsEarned:</span>
                        <span>{record.totalCreditsEarned}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Indexing */}
      {activeTab === 'indexing' && (
        <div className="mt-6 space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 bg-zinc-50 border border-zinc-200 rounded-xl p-5 space-y-4 text-xs">
              <h3 className="text-sm font-bold text-zinc-900 flex items-center gap-2">
                <Database className="w-4 h-4 text-red-700" />
                Index Optimizer & explain() Profiler
              </h3>

              <div>
                <label className="font-bold text-zinc-700 block mb-1">Simulated Collection Size:</label>
                <select
                  value={datasetSize}
                  onChange={(e) => setDatasetSize(Number(e.target.value))}
                  className="w-full bg-white border border-zinc-300 rounded-lg p-2 font-mono text-xs font-semibold"
                >
                  <option value={10000}>10,000 Documents</option>
                  <option value={100000}>100,000 Documents</option>
                  <option value={1000000}>1,000,000 Documents</option>
                </select>
              </div>

              <div className="bg-white p-3.5 rounded-lg border border-zinc-200 space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="compound-index"
                    checked={hasCompoundIndex}
                    onChange={(e) => setHasCompoundIndex(e.target.checked)}
                    className="accent-red-700"
                  />
                  <label htmlFor="compound-index" className="font-bold text-zinc-800 cursor-pointer">
                    Enable Compound Index:
                  </label>
                </div>
                <p className="font-mono text-red-700 text-[11px]">
                  db.students.createIndex(&#123; department: 1, gpa: -1 &#125;)
                </p>
              </div>

              <button
                onClick={runExplainBenchmark}
                className="w-full py-2.5 bg-red-700 hover:bg-red-800 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition cursor-pointer shadow-xs"
              >
                <Gauge className="w-4 h-4" />
                <span>Run db.students.explain("executionStats")</span>
              </button>
            </div>

            {/* Benchmark Result */}
            <div className="lg:col-span-7 bg-zinc-900 text-zinc-100 rounded-xl p-5 font-mono text-xs border border-zinc-800 flex flex-col">
              <div className="text-[11px] font-sans font-bold uppercase tracking-wider text-zinc-400 pb-3 border-b border-zinc-800 mb-3 flex justify-between">
                <span>Query Execution Plan Telemetry</span>
                <span className="text-zinc-500">MongoDB Wire Protocol 5.0</span>
              </div>

              {explainResult ? (
                <div className="space-y-4 flex-1">
                  <div className={`p-3 rounded-lg border ${
                    explainResult.stage.includes('IXSCAN')
                      ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300'
                      : 'bg-amber-950/60 border-amber-500/50 text-amber-300'
                  }`}>
                    <div className="text-[10px] uppercase font-sans font-bold tracking-wider">Winning Strategy:</div>
                    <div className="text-sm font-bold mt-0.5">{explainResult.stage}</div>
                    <div className="text-[11px] text-zinc-400 mt-1 font-mono">Index: {explainResult.indexUsed}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-3 text-center">
                    <div className="bg-zinc-800 p-3 rounded-lg border border-zinc-700">
                      <div className="text-zinc-400 text-[10px] font-sans uppercase">Docs Examined</div>
                      <div className="text-base font-bold text-white mt-1">{explainResult.docsExamined.toLocaleString()}</div>
                    </div>
                    <div className="bg-zinc-800 p-3 rounded-lg border border-zinc-700">
                      <div className="text-zinc-400 text-[10px] font-sans uppercase">Docs Returned</div>
                      <div className="text-base font-bold text-emerald-400 mt-1">{explainResult.docsReturned.toLocaleString()}</div>
                    </div>
                    <div className="bg-zinc-800 p-3 rounded-lg border border-zinc-700">
                      <div className="text-zinc-400 text-[10px] font-sans uppercase">Latency</div>
                      <div className="text-base font-bold text-amber-400 mt-1">{explainResult.executionTimeMs} ms</div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-zinc-500 font-sans text-xs text-center">
                  <Gauge className="w-8 h-8 text-zinc-600 mb-2" />
                  <span>Click "Run db.students.explain" to profile index scan efficiency vs table scan cost.</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
