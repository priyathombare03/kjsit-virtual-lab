import React, { useState } from 'react';
import { GitBranch, Play, RotateCcw, AlertTriangle, ShieldAlert, ArrowDown, ArrowUp, CheckCircle, Plus, Trash2 } from 'lucide-react';

interface DOMNode {
  id: string;
  tag: string;
  label: string;
  children?: DOMNode[];
}

export const DOMEventPropagationSimulator: React.FC = () => {
  const [stopPropagationOn, setStopPropagationOn] = useState<string | null>(null);
  const [useCapture, setUseCapture] = useState<boolean>(false);
  const [activeStep, setActiveStep] = useState<number>(-1);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [propagationLog, setPropagationLog] = useState<Array<{ phase: 'capture' | 'target' | 'bubble'; node: string; desc: string; stopped?: boolean }>>([]);

  const initialTree: DOMNode = {
    id: 'window',
    tag: 'Window',
    label: 'window (Global Context)',
    children: [
      {
        id: 'document',
        tag: 'Document',
        label: 'document (DOM Root)',
        children: [
          {
            id: 'html',
            tag: 'html',
            label: '<html> Element',
            children: [
              {
                id: 'body',
                tag: 'body',
                label: '<body> Container',
                children: [
                  {
                    id: 'wrapper',
                    tag: 'div#wrapper',
                    label: '<div id="wrapper"> Card Container',
                    children: [
                      {
                        id: 'form',
                        tag: 'form#student-form',
                        label: '<form id="student-form">',
                        children: [
                          {
                            id: 'btn-submit',
                            tag: 'button#btn-submit',
                            label: '<button id="btn-submit"> Submit Button'
                          }
                        ]
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  };

  const propagationPath = [
    { node: 'window', phase: 'capture' as const, name: 'window', desc: 'Phase 1: Descending Capturing Phase' },
    { node: 'document', phase: 'capture' as const, name: 'document', desc: 'Phase 1: Descending Capturing Phase' },
    { node: 'html', phase: 'capture' as const, name: '<html>', desc: 'Phase 1: Descending Capturing Phase' },
    { node: 'body', phase: 'capture' as const, name: '<body>', desc: 'Phase 1: Descending Capturing Phase' },
    { node: 'wrapper', phase: 'capture' as const, name: 'div#wrapper', desc: 'Phase 1: Descending Capturing Phase' },
    { node: 'form', phase: 'capture' as const, name: 'form#student-form', desc: 'Phase 1: Descending Capturing Phase' },
    { node: 'btn-submit', phase: 'target' as const, name: 'button#btn-submit', desc: 'Phase 2: Target Phase (event.target execution)' },
    { node: 'form', phase: 'bubble' as const, name: 'form#student-form', desc: 'Phase 3: Ascending Bubbling Phase' },
    { node: 'wrapper', phase: 'bubble' as const, name: 'div#wrapper', desc: 'Phase 3: Ascending Bubbling Phase' },
    { node: 'body', phase: 'bubble' as const, name: '<body>', desc: 'Phase 3: Ascending Bubbling Phase' },
    { node: 'html', phase: 'bubble' as const, name: '<html>', desc: 'Phase 3: Ascending Bubbling Phase' },
    { node: 'document', phase: 'bubble' as const, name: 'document', desc: 'Phase 3: Ascending Bubbling Phase' },
    { node: 'window', phase: 'bubble' as const, name: 'window', desc: 'Phase 3: Ascending Bubbling Phase' }
  ];

  const handleSimulateClick = () => {
    setIsPlaying(true);
    setActiveStep(0);
    setPropagationLog([]);

    let current = 0;
    const logs: typeof propagationLog = [];

    const interval = setInterval(() => {
      if (current >= propagationPath.length) {
        clearInterval(interval);
        setIsPlaying(false);
        return;
      }

      const stepInfo = propagationPath[current];
      const isStopped = stopPropagationOn === stepInfo.node;

      logs.push({
        phase: stepInfo.phase,
        node: stepInfo.name,
        desc: isStopped ? `stopPropagation() intercepted event on ${stepInfo.name}! Execution halted.` : stepInfo.desc,
        stopped: isStopped
      });

      setPropagationLog([...logs]);
      setActiveStep(current);

      if (isStopped) {
        clearInterval(interval);
        setIsPlaying(false);
      } else {
        current++;
      }
    }, 600);
  };

  const currentNodeId = activeStep >= 0 && activeStep < propagationPath.length
    ? propagationPath[activeStep].node
    : null;
  const currentPhase = activeStep >= 0 && activeStep < propagationPath.length
    ? propagationPath[activeStep].phase
    : null;

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm">
      {/* Header */}
      <div className="pb-4 border-b border-zinc-200">
        <span className="text-xs font-bold font-mono uppercase tracking-wider text-red-700 bg-red-50 px-2.5 py-1 rounded-md border border-red-100">
          FSWC Lab Exp #2 Interactive Simulator
        </span>
        <h2 className="text-xl font-black text-zinc-900 mt-1">DOM Tree Traversal & 3-Phase Event Propagation Visualizer</h2>
        <p className="text-xs text-zinc-500">Step-by-step trace of Capturing, Target, and Bubbling phases with stopPropagation() interception</p>
      </div>

      <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Controls & Tree */}
        <div className="lg:col-span-7 space-y-4">
          {/* Controls Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-zinc-50 border border-zinc-200 rounded-xl p-4">
            <div className="flex items-center gap-2">
              <button
                onClick={handleSimulateClick}
                disabled={isPlaying}
                className="px-4 py-2 bg-red-700 hover:bg-red-800 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-xs cursor-pointer disabled:opacity-50"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Simulate Click on Button</span>
              </button>
              <button
                onClick={() => {
                  setActiveStep(-1);
                  setPropagationLog([]);
                  setIsPlaying(false);
                }}
                className="p-2 border border-zinc-300 rounded-xl text-xs text-zinc-600 hover:bg-zinc-100 cursor-pointer"
                title="Reset Simulation"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center gap-2 text-xs">
              <label className="font-bold text-zinc-700">Intercept on:</label>
              <select
                value={stopPropagationOn || ''}
                onChange={(e) => setStopPropagationOn(e.target.value || null)}
                className="bg-white border border-zinc-300 rounded-lg p-1.5 font-mono text-xs font-semibold"
              >
                <option value="">None (Full Propagation)</option>
                <option value="form">form#student-form</option>
                <option value="wrapper">div#wrapper</option>
                <option value="btn-submit">button#btn-submit</option>
              </select>
            </div>
          </div>

          {/* Interactive DOM Tree Node View */}
          <div className="bg-zinc-900 text-white rounded-xl p-5 font-mono text-xs space-y-2">
            <div className="text-[11px] text-zinc-400 font-sans font-bold uppercase tracking-wider mb-2 flex justify-between">
              <span>DOM Node Hierarchy</span>
              {currentPhase && (
                <span className={`px-2 py-0.5 rounded font-bold uppercase text-[10px] ${
                  currentPhase === 'capture' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                  currentPhase === 'target' ? 'bg-red-500/20 text-red-300 border border-red-500/30' :
                  'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                }`}>
                  {currentPhase === 'capture' ? '⬇ Phase 1: Capturing' : currentPhase === 'target' ? '🎯 Phase 2: Target' : '⬆ Phase 3: Bubbling'}
                </span>
              )}
            </div>

            {[
              { id: 'window', label: 'Window', indent: 0 },
              { id: 'document', label: 'document', indent: 1 },
              { id: 'html', label: '<html>', indent: 2 },
              { id: 'body', label: '<body>', indent: 3 },
              { id: 'wrapper', label: '<div id="wrapper">', indent: 4 },
              { id: 'form', label: '<form id="student-form">', indent: 5 },
              { id: 'btn-submit', label: '<button id="btn-submit"> Submit Form </button>', indent: 6 }
            ].map((node) => {
              const isCurrent = currentNodeId === node.id;
              const hasStop = stopPropagationOn === node.id;
              return (
                <div
                  key={node.id}
                  className={`py-1.5 px-3 rounded-lg flex items-center justify-between transition-all duration-200 ${
                    isCurrent
                      ? 'bg-red-600 text-white font-bold shadow-md ring-2 ring-red-400 scale-[1.01]'
                      : 'bg-zinc-800/60 text-zinc-300 hover:bg-zinc-800'
                  }`}
                  style={{ marginLeft: `${node.indent * 14}px` }}
                >
                  <span className="flex items-center gap-2">
                    <span className="text-zinc-500">{'└─'.repeat(node.indent > 0 ? 1 : 0)}</span>
                    <span>{node.label}</span>
                  </span>

                  <div className="flex items-center gap-2 text-[10px]">
                    {hasStop && (
                      <span className="bg-amber-900/80 text-amber-300 px-1.5 py-0.5 rounded border border-amber-700">
                        stopPropagation()
                      </span>
                    )}
                    {isCurrent && (
                      <span className="animate-pulse bg-white text-zinc-900 px-1.5 py-0.5 rounded font-bold">
                        ACTIVE
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Code Reference Preview */}
          <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-4 text-xs font-mono text-zinc-700 space-y-1">
            <div className="font-bold text-zinc-900 font-sans">JavaScript Event Listener Attachment:</div>
            <p className="text-zinc-600">// Bubbling listener (Default useCapture = false):</p>
            <p className="text-red-700">document.getElementById('wrapper').addEventListener('click', (e) =&gt; &#123; ... &#125;, false);</p>
            <p className="text-zinc-600 pt-1">// Capturing listener (useCapture = true):</p>
            <p className="text-amber-700">document.addEventListener('click', (e) =&gt; &#123; ... &#125;, true);</p>
          </div>
        </div>

        {/* Right Column: Execution Log */}
        <div className="lg:col-span-5 flex flex-col">
          <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-4 flex-1 flex flex-col">
            <h3 className="text-sm font-bold text-zinc-900 mb-3 flex items-center justify-between">
              <span>Event Propagation Telemetry</span>
              <span className="text-xs font-mono font-normal text-zinc-500">{propagationLog.length} steps recorded</span>
            </h3>

            <div className="space-y-2 flex-1 overflow-y-auto max-h-[380px] pr-1">
              {propagationLog.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-48 text-center text-zinc-400 text-xs">
                  <Play className="w-6 h-6 mb-2 opacity-50" />
                  <span>Click "Simulate Click on Button" to initiate W3C event propagation sequence.</span>
                </div>
              ) : (
                propagationLog.map((log, idx) => (
                  <div
                    key={idx}
                    className={`p-2.5 rounded-lg border text-xs font-mono transition-all ${
                      log.stopped
                        ? 'bg-rose-50 border-rose-300 text-rose-900'
                        : log.phase === 'capture'
                        ? 'bg-amber-50 border-amber-200 text-amber-900'
                        : log.phase === 'target'
                        ? 'bg-red-50 border-red-300 text-red-900 font-bold'
                        : 'bg-blue-50 border-blue-200 text-blue-900'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-bold uppercase tracking-wider">
                        {log.phase === 'capture' ? '⬇ Capturing' : log.phase === 'target' ? '🎯 Target' : '⬆ Bubbling'}
                      </span>
                      <span className="text-zinc-500">#{idx + 1}</span>
                    </div>
                    <div className="mt-1 font-semibold">{log.node}</div>
                    <div className="text-[10px] text-zinc-600 mt-0.5">{log.desc}</div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
