import React, { useState } from 'react';
import { Layers, ArrowRight, Play, RotateCcw, ShieldCheck, CheckCircle2, AlertTriangle, FileText, Lock, Activity } from 'lucide-react';

interface MiddlewareBlock {
  id: string;
  name: string;
  type: 'builtin' | 'custom' | 'auth' | 'route' | 'error';
  enabled: boolean;
  codeSnippet: string;
  desc: string;
}

export const ExpressMiddlewareSimulator: React.FC = () => {
  const [middlewares, setMiddlewares] = useState<MiddlewareBlock[]>([
    {
      id: 'body-parser',
      name: 'express.json()',
      type: 'builtin',
      enabled: true,
      desc: 'Parses incoming raw JSON buffer into req.body object',
      codeSnippet: 'app.use(express.json());'
    },
    {
      id: 'logger',
      name: 'morganLogger(req, res, next)',
      type: 'custom',
      enabled: true,
      desc: 'Logs HTTP method, path, and timestamp to stdout',
      codeSnippet: 'console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`); next();'
    },
    {
      id: 'auth',
      name: 'verifyAuthToken(req, res, next)',
      type: 'auth',
      enabled: true,
      desc: 'Extracts Bearer token, verifies JWT signature, attaches req.user',
      codeSnippet: 'if(!token) return res.status(401).json(...); req.user = decoded; next();'
    },
    {
      id: 'rate-limit',
      name: 'rateLimiter(req, res, next)',
      type: 'custom',
      enabled: true,
      desc: 'Enforces 100 requests per 15-minute sliding window per IP',
      codeSnippet: 'if(count > 100) return next(new Error("Rate Limit Exceeded")); next();'
    },
    {
      id: 'route',
      name: 'POST /api/vlab/submit Handler',
      type: 'route',
      enabled: true,
      desc: 'Primary business logic controller writing experiment grade to DB',
      codeSnippet: 'res.status(201).json({ success: true, submissionId: 4081 });'
    },
    {
      id: 'error-handler',
      name: 'errorHandler(err, req, res, next)',
      type: 'error',
      enabled: true,
      desc: 'Special 4-parameter error catcher sending formatted JSON errors',
      codeSnippet: 'res.status(err.status || 500).json({ error: err.message });'
    }
  ]);

  const [requestType, setRequestType] = useState<'valid' | 'missing-token' | 'rate-exceeded' | 'syntax-error'>('valid');
  const [activeStep, setActiveStep] = useState<number>(-1);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [executionTrace, setExecutionTrace] = useState<string[]>([]);
  const [finalResponse, setFinalResponse] = useState<{ status: number; body: any } | null>(null);

  const toggleMiddleware = (id: string) => {
    setMiddlewares(prev => prev.map(m => m.id === id ? { ...m, enabled: !m.enabled } : m));
  };

  const handleSimulatePipeline = () => {
    setIsProcessing(true);
    setActiveStep(0);
    setExecutionTrace([]);
    setFinalResponse(null);

    const logs: string[] = [];
    let step = 0;
    const enabledPipeline = middlewares.filter(m => m.enabled);

    const interval = setInterval(() => {
      if (step >= enabledPipeline.length) {
        clearInterval(interval);
        setIsProcessing(false);
        return;
      }

      const current = enabledPipeline[step];
      logs.push(`Passed through: ${current.name} -> next()`);
      setExecutionTrace([...logs]);
      setActiveStep(step);

      // Simulation branching
      if (current.id === 'auth' && requestType === 'missing-token') {
        logs.push(`[BLOCKED in ${current.name}]: HTTP 401 Unauthorized (No Token)`);
        setExecutionTrace([...logs]);
        setFinalResponse({ status: 401, body: { error: 'Unauthorized: Authentication token is required' } });
        clearInterval(interval);
        setIsProcessing(false);
        return;
      }

      if (current.id === 'rate-limit' && requestType === 'rate-exceeded') {
        logs.push(`[TRIGGERED ERROR]: next(new Error("Too Many Requests"))`);
        setExecutionTrace([...logs]);
        // Jump to error handler
        const errIndex = enabledPipeline.findIndex(m => m.type === 'error');
        if (errIndex !== -1) {
          setActiveStep(errIndex);
          logs.push(`[ERROR HANDLER CATCH]: errorHandler captured error! Status 429`);
          setExecutionTrace([...logs]);
          setFinalResponse({ status: 429, body: { error: 'Too Many Requests: Rate limit quota exceeded.' } });
        }
        clearInterval(interval);
        setIsProcessing(false);
        return;
      }

      if (current.id === 'route') {
        setFinalResponse({ status: 201, body: { success: true, message: 'Experiment lab data processed by controller' } });
        clearInterval(interval);
        setIsProcessing(false);
        return;
      }

      step++;
    }, 600);
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm">
      {/* Header */}
      <div className="pb-4 border-b border-zinc-200">
        <span className="text-xs font-bold font-mono uppercase tracking-wider text-red-700 bg-red-50 px-2.5 py-1 rounded-md border border-red-100">
          FSWC Lab Exp #5 Interactive Simulator
        </span>
        <h2 className="text-xl font-black text-zinc-900 mt-1">Node.js Express Middleware Pipeline & Error Interceptor</h2>
        <p className="text-xs text-zinc-500">Visual trace of request-response middleware chain execution, next() branching & 4-parameter error handler</p>
      </div>

      <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Pipeline Setup */}
        <div className="lg:col-span-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 bg-zinc-50 border border-zinc-200 rounded-xl p-4">
            <div className="text-xs">
              <label className="font-bold text-zinc-700 block mb-1">Incoming Test Scenario:</label>
              <select
                value={requestType}
                onChange={(e: any) => setRequestType(e.target.value)}
                className="bg-white border border-zinc-300 rounded-lg p-1.5 font-mono text-xs font-semibold"
              >
                <option value="valid">Valid Request (All Valid Claims)</option>
                <option value="missing-token">Unauthorized (Missing Bearer Token)</option>
                <option value="rate-exceeded">Rate Limit Quota Exceeded (Error Jump)</option>
              </select>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleSimulatePipeline}
                disabled={isProcessing}
                className="px-4 py-2 bg-red-700 hover:bg-red-800 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs cursor-pointer disabled:opacity-50"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Execute Pipeline</span>
              </button>
              <button
                onClick={() => {
                  setActiveStep(-1);
                  setExecutionTrace([]);
                  setFinalResponse(null);
                  setIsProcessing(false);
                }}
                className="p-2 border border-zinc-300 rounded-xl text-zinc-600 hover:bg-zinc-100 cursor-pointer"
                title="Reset"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Middleware Chain Visualizer */}
          <div className="space-y-2.5">
            <div className="text-[11px] font-sans font-bold uppercase tracking-wider text-zinc-500 flex justify-between">
              <span>Active Middleware Pipeline Sequence</span>
              <span>Toggle to Enable / Disable</span>
            </div>

            {middlewares.map((mw, idx) => {
              const isActive = activeStep === idx;
              return (
                <div
                  key={mw.id}
                  className={`p-3.5 rounded-xl border transition-all duration-200 ${
                    isActive
                      ? 'bg-red-700 text-white border-red-800 shadow-md ring-2 ring-red-300'
                      : mw.enabled
                      ? 'bg-zinc-50 border-zinc-200 text-zinc-800'
                      : 'bg-zinc-100/50 border-zinc-200 text-zinc-400 opacity-60'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                        isActive ? 'bg-red-900 text-red-100' : 'bg-zinc-200 text-zinc-700'
                      }`}>
                        #{idx + 1}
                      </span>
                      <span className="font-mono font-bold text-xs">{mw.name}</span>
                    </div>

                    <button
                      onClick={() => toggleMiddleware(mw.id)}
                      className={`text-[10px] font-bold px-2 py-0.5 rounded border cursor-pointer ${
                        isActive ? 'bg-red-800 text-white border-red-600' :
                        mw.enabled ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-zinc-200 text-zinc-600 border-zinc-300'
                      }`}
                    >
                      {mw.enabled ? 'Mounted' : 'Disabled'}
                    </button>
                  </div>

                  <p className={`text-[11px] mt-1 ${isActive ? 'text-red-100' : 'text-zinc-500'}`}>
                    {mw.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Execution Log & Output */}
        <div className="lg:col-span-6 flex flex-col space-y-4">
          {/* Execution Trace */}
          <div className="bg-zinc-900 text-zinc-200 rounded-xl p-4 flex-1 flex flex-col font-mono text-xs border border-zinc-800">
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800 mb-2">
              <span className="text-[11px] font-sans font-bold uppercase tracking-wider text-zinc-400">
                Pipeline Execution Trace
              </span>
              <span className="text-[10px] text-zinc-500">{executionTrace.length} events</span>
            </div>

            <div className="space-y-1.5 flex-1 overflow-y-auto max-h-[220px]">
              {executionTrace.length === 0 ? (
                <div className="text-zinc-500 italic p-4 text-center font-sans">
                  Click "Execute Pipeline" to trace request progression through middleware handlers.
                </div>
              ) : (
                executionTrace.map((log, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-[11px]">
                    <span className="text-red-400">&gt;</span>
                    <span className={log.includes('BLOCKED') || log.includes('ERROR') ? 'text-amber-400 font-bold' : 'text-emerald-300'}>
                      {log}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Final HTTP Response Box */}
          {finalResponse && (
            <div className={`p-4 rounded-xl border text-xs font-mono animate-fadeIn ${
              finalResponse.status >= 200 && finalResponse.status < 300
                ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                : 'bg-amber-50 border-amber-300 text-amber-950'
            }`}>
              <div className="flex items-center justify-between font-sans font-bold mb-2">
                <span>Final Dispatched HTTP Response:</span>
                <span className="px-2 py-0.5 rounded bg-white border font-mono">
                  HTTP {finalResponse.status}
                </span>
              </div>
              <pre className="bg-white/80 p-2.5 rounded border border-current/20 overflow-x-auto">
                {JSON.stringify(finalResponse.body, null, 2)}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
