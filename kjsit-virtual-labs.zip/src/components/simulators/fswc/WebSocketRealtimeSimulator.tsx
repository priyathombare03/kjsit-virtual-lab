import React, { useState, useEffect, useRef } from 'react';
import { Wifi, Send, CheckCircle2, Radio, Server, MessageSquare, Clock, Zap, ArrowDownUp } from 'lucide-react';

interface WsMessage {
  id: string;
  sender: 'client' | 'server' | 'peer';
  room: string;
  payload: string;
  timestamp: string;
  frameType: 'TEXT' | 'PING' | 'PONG' | 'BINARY';
}

export const WebSocketRealtimeSimulator: React.FC = () => {
  const [isConnected, setIsConnected] = useState<boolean>(true);
  const [selectedRoom, setSelectedRoom] = useState<string>('lab-experiments');
  const [inputMsg, setInputMsg] = useState<string>('');
  const [latency, setLatency] = useState<number>(18);
  const [messages, setMessages] = useState<WsMessage[]>([
    {
      id: '1',
      sender: 'server',
      room: 'system',
      payload: 'HTTP/1.1 101 Switching Protocols (Upgrade: websocket)',
      timestamp: '12:00:01',
      frameType: 'TEXT'
    },
    {
      id: '2',
      sender: 'server',
      room: 'lab-experiments',
      payload: 'Connected to KJSIT Virtual Lab Full Stack WebSocket Channel',
      timestamp: '12:00:02',
      frameType: 'TEXT'
    }
  ]);

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMsg.trim() || !isConnected) return;

    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const userMsg: WsMessage = {
      id: Date.now().toString(),
      sender: 'client',
      room: selectedRoom,
      payload: inputMsg.trim(),
      timestamp: time,
      frameType: 'TEXT'
    };

    setMessages(prev => [...prev, userMsg]);
    setInputMsg('');

    // Simulate peer/server broadcast reply
    setTimeout(() => {
      if (isConnected) {
        const replyTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        const serverAck: WsMessage = {
          id: (Date.now() + 1).toString(),
          sender: 'server',
          room: selectedRoom,
          payload: `[BROADCAST to room '${selectedRoom}']: Acknowledged payload "${userMsg.payload}"`,
          timestamp: replyTime,
          frameType: 'TEXT'
        };
        setMessages(prev => [...prev, serverAck]);
      }
    }, 450);
  };

  const handleSendPing = () => {
    if (!isConnected) return;
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const pingMsg: WsMessage = {
      id: Date.now().toString(),
      sender: 'client',
      room: 'system',
      payload: '0x9 (PING Heartbeat Frame)',
      timestamp: time,
      frameType: 'PING'
    };
    setMessages(prev => [...prev, pingMsg]);

    setTimeout(() => {
      const pongTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      const pongMsg: WsMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'server',
        room: 'system',
        payload: '0xA (PONG Heartbeat ACK)',
        timestamp: pongTime,
        frameType: 'PONG'
      };
      setMessages(prev => [...prev, pongMsg]);
      setLatency(Math.floor(12 + Math.random() * 10));
    }, 25);
  };

  const toggleConnection = () => {
    setIsConnected(prev => !prev);
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    if (!isConnected) {
      setMessages(prev => [
        ...prev,
        {
          id: Date.now().toString(),
          sender: 'server',
          room: 'system',
          payload: 'WebSocket Handshake Completed (Sec-WebSocket-Accept verified)',
          timestamp: time,
          frameType: 'TEXT'
        }
      ]);
    } else {
      setMessages(prev => [
        ...prev,
        {
          id: Date.now().toString(),
          sender: 'server',
          room: 'system',
          payload: 'WebSocket TCP Socket Disconnected (Code 1000 Normal Closure)',
          timestamp: time,
          frameType: 'TEXT'
        }
      ]);
    }
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm">
      {/* Header */}
      <div className="pb-4 border-b border-zinc-200">
        <span className="text-xs font-bold font-mono uppercase tracking-wider text-red-700 bg-red-50 px-2.5 py-1 rounded-md border border-red-100">
          FSWC Lab Exp #9 Interactive Simulator
        </span>
        <h2 className="text-xl font-black text-zinc-900 mt-1">Full-Duplex WebSocket Protocol & Real-Time Channel Simulator</h2>
        <p className="text-xs text-zinc-500">Live RFC 6455 bidirectional socket frame inspector, HTTP 101 upgrade handshake & multi-room event dispatcher</p>
      </div>

      {/* Connection State Bar */}
      <div className="mt-4 p-3.5 bg-zinc-900 text-white rounded-xl flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
        <div className="flex items-center gap-3">
          <span className={`w-3 h-3 rounded-full ${isConnected ? 'bg-emerald-400 animate-pulse' : 'bg-red-500'}`} />
          <span className="font-bold">{isConnected ? 'STATUS: OPEN (ws://localhost:3000/socket.io)' : 'STATUS: CLOSED'}</span>
        </div>

        <div className="flex items-center gap-4 text-[11px]">
          <span className="text-zinc-400 flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-amber-400" /> RTT Latency: <strong className="text-white">{latency}ms</strong>
          </span>
          <button
            onClick={handleSendPing}
            disabled={!isConnected}
            className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 rounded text-emerald-400 border border-zinc-700 cursor-pointer disabled:opacity-40"
          >
            Send PING Heartbeat
          </button>
          <button
            onClick={toggleConnection}
            className={`px-2.5 py-1 rounded font-bold cursor-pointer ${
              isConnected ? 'bg-red-700 text-white hover:bg-red-800' : 'bg-emerald-700 text-white hover:bg-emerald-800'
            }`}
          >
            {isConnected ? 'Disconnect' : 'Connect'}
          </button>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Room Selector & Client Controls */}
        <div className="lg:col-span-5 bg-zinc-50 border border-zinc-200 rounded-xl p-5 space-y-4 text-xs">
          <h3 className="text-sm font-bold text-zinc-900 flex items-center gap-2">
            <Radio className="w-4 h-4 text-red-700" />
            Socket.IO Room & Channel
          </h3>

          <div>
            <label className="font-bold text-zinc-700 block mb-1">Subscribed Room Channel:</label>
            <div className="grid grid-cols-2 gap-2">
              {['lab-experiments', 'collaborative-editor', 'system'].map((room) => (
                <button
                  key={room}
                  onClick={() => setSelectedRoom(room)}
                  className={`p-2 rounded-lg border font-mono font-bold text-left cursor-pointer transition ${
                    selectedRoom === room ? 'bg-red-700 text-white border-red-800 shadow-xs' : 'bg-white text-zinc-700 border-zinc-300'
                  }`}
                >
                  #{room}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-white p-3 rounded-lg border border-zinc-200 space-y-1 text-zinc-600 font-mono text-[11px]">
            <div className="text-zinc-900 font-bold font-sans">Socket Handshake Protocol:</div>
            <div>Upgrade: websocket</div>
            <div>Connection: Upgrade</div>
            <div>Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==</div>
            <div>Sec-WebSocket-Version: 13</div>
          </div>

          {/* Message Dispatch Form */}
          <form onSubmit={handleSendMessage} className="space-y-2 pt-2">
            <label className="font-bold text-zinc-700 block">Emit Event Payload:</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={inputMsg}
                onChange={(e) => setInputMsg(e.target.value)}
                disabled={!isConnected}
                placeholder={`Emit message to #${selectedRoom}...`}
                className="flex-1 bg-white border border-zinc-300 rounded-lg px-3 py-2 text-xs text-zinc-800 focus:outline-red-700 disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={!isConnected || !inputMsg.trim()}
                className="px-4 py-2 bg-red-700 hover:bg-red-800 text-white rounded-lg font-bold flex items-center gap-1 cursor-pointer disabled:opacity-50 shadow-xs"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Emit</span>
              </button>
            </div>
          </form>
        </div>

        {/* Right: Live Full-Duplex Frame Stream */}
        <div className="lg:col-span-7 flex flex-col">
          <div className="bg-zinc-900 text-zinc-100 rounded-xl p-4 flex-1 flex flex-col font-mono text-xs border border-zinc-800">
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800 mb-2">
              <span className="text-[11px] font-sans font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
                <ArrowDownUp className="w-3.5 h-3.5 text-emerald-400" />
                Bidirectional WebSocket Frame Stream
              </span>
              <span className="text-[10px] text-zinc-500">{messages.length} frames logged</span>
            </div>

            <div className="space-y-2 flex-1 overflow-y-auto max-h-[340px] pr-1">
              {messages.map((m) => {
                const isClient = m.sender === 'client';
                const isPingPong = m.frameType === 'PING' || m.frameType === 'PONG';
                return (
                  <div
                    key={m.id}
                    className={`p-2.5 rounded-lg border text-xs ${
                      isPingPong
                        ? 'bg-amber-950/40 border-amber-500/40 text-amber-300'
                        : isClient
                        ? 'bg-zinc-800/90 border-zinc-700 text-red-200'
                        : 'bg-zinc-950 border-zinc-800 text-emerald-300'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[10px] text-zinc-400 pb-1 mb-1 border-b border-zinc-800">
                      <span className="font-bold uppercase tracking-wider flex items-center gap-1">
                        {isClient ? '⬆ CLIENT OUTBOUND' : '⬇ SERVER INBOUND'} ({m.frameType})
                      </span>
                      <span className="text-zinc-500">{m.timestamp}</span>
                    </div>
                    <div className="flex items-start justify-between gap-2">
                      <span className="font-semibold break-all">{m.payload}</span>
                      <span className="text-[9px] bg-zinc-800 text-zinc-400 px-1 rounded shrink-0">
                        #{m.room}
                      </span>
                    </div>
                  </div>
                );
              })}
              <div ref={chatEndRef} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
