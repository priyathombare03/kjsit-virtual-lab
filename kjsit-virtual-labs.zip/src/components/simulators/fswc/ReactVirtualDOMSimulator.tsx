import React, { useState } from 'react';
import { Cpu, RotateCcw, Plus, Minus, CheckCircle, RefreshCw, GitCommit, Layers } from 'lucide-react';

interface TodoItem {
  id: number;
  text: string;
  completed: boolean;
}

export const ReactVirtualDOMSimulator: React.FC = () => {
  const [todos, setTodos] = useState<TodoItem[]>([
    { id: 1, text: 'Study HTML5 Semantic Elements', completed: true },
    { id: 2, text: 'Master React Virtual DOM Reconciliation', completed: false },
    { id: 3, text: 'Configure Express REST API Endpoints', completed: false }
  ]);
  const [newText, setNewText] = useState<string>('');
  const [renderCount, setRenderCount] = useState<number>(1);
  const [lastDiffDetails, setLastDiffDetails] = useState<{
    type: 'ADD' | 'TOGGLE' | 'DELETE' | 'INITIAL';
    nodeId?: number;
    description: string;
    vDomDiffCount: number;
    realDomPatches: number;
  }>({
    type: 'INITIAL',
    description: 'Initial component mount. Virtual DOM generated tree and committed initial HTML to real DOM.',
    vDomDiffCount: 3,
    realDomPatches: 3
  });

  const handleToggle = (id: number) => {
    setTodos(prev => prev.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
    setRenderCount(c => c + 1);
    setLastDiffDetails({
      type: 'TOGGLE',
      nodeId: id,
      description: `State change on item #${id}. React diffed VDOM tree, identified single changed className / checkbox attribute, and patched ONLY that specific Real DOM node (O(1) commit).`,
      vDomDiffCount: todos.length,
      realDomPatches: 1
    });
  };

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newText.trim()) return;
    const newItem: TodoItem = {
      id: Date.now(),
      text: newText.trim(),
      completed: false
    };
    setTodos(prev => [...prev, newItem]);
    setNewText('');
    setRenderCount(c => c + 1);
    setLastDiffDetails({
      type: 'ADD',
      nodeId: newItem.id,
      description: `Appended new Fiber node. Key-based reconciliation matched previous items and executed a single 'appendChild' on the Real DOM container.`,
      vDomDiffCount: todos.length + 1,
      realDomPatches: 1
    });
  };

  const handleDelete = (id: number) => {
    setTodos(prev => prev.filter(t => t.id !== id));
    setRenderCount(c => c + 1);
    setLastDiffDetails({
      type: 'DELETE',
      nodeId: id,
      description: `Unmounted Fiber node #${id}. React reconciler detached the element from VDOM and performed a surgical 'removeChild' on the host DOM.`,
      vDomDiffCount: todos.length,
      realDomPatches: 1
    });
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm">
      {/* Header */}
      <div className="pb-4 border-b border-zinc-200">
        <span className="text-xs font-bold font-mono uppercase tracking-wider text-red-700 bg-red-50 px-2.5 py-1 rounded-md border border-red-100">
          FSWC Lab Exp #7 Interactive Simulator
        </span>
        <h2 className="text-xl font-black text-zinc-900 mt-1">React Fiber Component Lifecycle & Virtual DOM Diffing Reconciliation</h2>
        <p className="text-xs text-zinc-500">Live visualization of component state transitions, Fiber tree diffing algorithm & selective Real DOM batch mutations</p>
      </div>

      {/* Render Counter Banner */}
      <div className="mt-4 p-3.5 bg-zinc-900 text-white rounded-xl flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
        <div className="flex items-center gap-3">
          <span className="bg-red-700 text-white px-2.5 py-1 rounded font-bold">
            Component Render #{renderCount}
          </span>
          <span className="text-zinc-300">Fiber Reconciler: Active</span>
        </div>
        <div className="flex items-center gap-4 text-[11px]">
          <span className="text-zinc-400">VDOM Nodes Diffed: <strong className="text-amber-400">{lastDiffDetails.vDomDiffCount}</strong></span>
          <span className="text-zinc-400">Real DOM Patches: <strong className="text-emerald-400">{lastDiffDetails.realDomPatches}</strong></span>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Interactive React App */}
        <div className="lg:col-span-6 bg-zinc-50 border border-zinc-200 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-zinc-900 flex items-center gap-2">
              <Cpu className="w-4 h-4 text-red-700" />
              Active React Component UI
            </h3>
            <span className="text-[11px] font-mono text-zinc-500">useState(todos)</span>
          </div>

          {/* Form */}
          <form onSubmit={handleAdd} className="flex gap-2">
            <input
              type="text"
              value={newText}
              onChange={(e) => setNewText(e.target.value)}
              placeholder="Add new lab task..."
              className="flex-1 bg-white border border-zinc-300 rounded-lg px-3 py-2 text-xs text-zinc-800 focus:outline-red-700"
            />
            <button
              type="submit"
              className="px-3.5 py-2 bg-red-700 hover:bg-red-800 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add</span>
            </button>
          </form>

          {/* Todo items */}
          <div className="space-y-2">
            {todos.map((todo) => {
              const isTarget = lastDiffDetails.nodeId === todo.id;
              return (
                <div
                  key={todo.id}
                  className={`p-3 rounded-lg border flex items-center justify-between transition-all duration-300 ${
                    isTarget
                      ? 'bg-amber-50 border-amber-400 shadow-xs ring-2 ring-amber-200'
                      : 'bg-white border-zinc-200'
                  }`}
                >
                  <div
                    onClick={() => handleToggle(todo.id)}
                    className="flex items-center gap-2.5 flex-1 cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      checked={todo.completed}
                      onChange={() => {}}
                      className="accent-red-700"
                    />
                    <span className={`text-xs ${todo.completed ? 'line-through text-zinc-400' : 'text-zinc-800 font-medium'}`}>
                      {todo.text}
                    </span>
                  </div>

                  <button
                    onClick={() => handleDelete(todo.id)}
                    className="text-zinc-400 hover:text-red-700 p-1 text-xs cursor-pointer"
                    title="Delete item"
                  >
                    ✕
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Virtual DOM vs Real DOM Tree Diff Visualizer */}
        <div className="lg:col-span-6 flex flex-col space-y-4">
          <div className="bg-zinc-900 text-zinc-200 rounded-xl p-4 flex-1 flex flex-col font-mono text-xs border border-zinc-800">
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800 mb-2">
              <span className="text-[11px] font-sans font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
                <GitCommit className="w-3.5 h-3.5 text-red-400" />
                Virtual DOM Reconciliation Telemetry
              </span>
              <span className="text-[10px] text-emerald-400">Diff Engine O(n)</span>
            </div>

            <div className="space-y-3 flex-1">
              <div className="bg-zinc-950 p-3 rounded-lg border border-zinc-800">
                <div className="text-[10px] uppercase font-sans font-bold tracking-wider text-zinc-400 mb-1">
                  Diff Action & Patch Summary:
                </div>
                <p className="text-zinc-300 font-sans text-xs leading-relaxed">
                  {lastDiffDetails.description}
                </p>
              </div>

              {/* VDOM vs Real DOM side-by-side comparison */}
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div className="bg-zinc-800/80 p-2.5 rounded border border-zinc-700">
                  <div className="font-bold text-amber-400 mb-1 flex items-center gap-1">
                    <Layers className="w-3 h-3" /> Virtual DOM Fiber
                  </div>
                  <div className="text-zinc-400 space-y-0.5">
                    <div>type: "TodoList"</div>
                    <div>props.children: {todos.length}</div>
                    <div className="text-zinc-500">In-Memory Lightweight JS Object Tree</div>
                  </div>
                </div>

                <div className="bg-zinc-800/80 p-2.5 rounded border border-zinc-700">
                  <div className="font-bold text-emerald-400 mb-1 flex items-center gap-1">
                    <Cpu className="w-3 h-3" /> Browser Real DOM
                  </div>
                  <div className="text-zinc-400 space-y-0.5">
                    <div>HTMLUListElement</div>
                    <div>childNodes: {todos.length}</div>
                    <div className="text-zinc-500">Heavyweight C++ Browser Layout Tree</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
