import React, { useState } from 'react';
import { Cpu, Play, FastForward, RotateCcw, CheckCircle, Terminal, Layers, Clock, Zap } from 'lucide-react';

interface StepState {
  step: number;
  description: string;
  callStack: string[];
  webAPIs: string[];
  microtasks: string[];
  macrotasks: string[];
  consoleLogs: string[];
  activeUnit: 'stack' | 'webapi' | 'microtask' | 'macrotask' | 'loop' | 'done';
}

export const V8EventLoopSimulator: React.FC = () => {
  const [activeSnippet, setActiveSnippet] = useState<'standard' | 'asyncawait' | 'starvation'>('standard');
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState<boolean>(false);

  const standardSteps: StepState[] = [
    {
      step: 0,
      description: 'Initial state: Script begins execution. Call stack is ready.',
      callStack: ['main() global'],
      webAPIs: [],
      microtasks: [],
      macrotasks: [],
      consoleLogs: [],
      activeUnit: 'stack'
    },
    {
      step: 1,
      description: 'Executing console.log("1. Start Sync") synchronously.',
      callStack: ['main()', 'console.log("1. Start Sync")'],
      webAPIs: [],
      microtasks: [],
      macrotasks: [],
      consoleLogs: ['1. Start Sync'],
      activeUnit: 'stack'
    },
    {
      step: 2,
      description: 'Encountered setTimeout(cb, 0). Web API registers timer.',
      callStack: ['main()', 'setTimeout(cb, 0)'],
      webAPIs: ['Timer (0ms) -> Macrotask cb'],
      microtasks: [],
      macrotasks: [],
      consoleLogs: ['1. Start Sync'],
      activeUnit: 'webapi'
    },
    {
      step: 3,
      description: 'Encountered Promise.resolve().then(cb). Callback pushed into Microtask Queue.',
      callStack: ['main()', 'Promise.resolve().then()'],
      webAPIs: ['Timer (0ms) -> complete'],
      microtasks: ['Promise cb ("3. Microtask Promise")'],
      macrotasks: ['setTimeout cb ("2. Macrotask Timer")'],
      consoleLogs: ['1. Start Sync'],
      activeUnit: 'microtask'
    },
    {
      step: 4,
      description: 'Encountered queueMicrotask(cb). Enqueued into Microtask Queue.',
      callStack: ['main()', 'queueMicrotask()'],
      webAPIs: [],
      microtasks: ['Promise cb ("3. Microtask Promise")', 'queueMicrotask cb ("4. Microtask Queue")'],
      macrotasks: ['setTimeout cb ("2. Macrotask Timer")'],
      consoleLogs: ['1. Start Sync'],
      activeUnit: 'microtask'
    },
    {
      step: 5,
      description: 'Executing console.log("5. End Sync") synchronously. Global main() script finishes.',
      callStack: ['main()', 'console.log("5. End Sync")'],
      webAPIs: [],
      microtasks: ['Promise cb ("3. Microtask Promise")', 'queueMicrotask cb ("4. Microtask Queue")'],
      macrotasks: ['setTimeout cb ("2. Macrotask Timer")'],
      consoleLogs: ['1. Start Sync', '5. End Sync'],
      activeUnit: 'stack'
    },
    {
      step: 6,
      description: 'Call Stack is EMPTY! Event loop checks Microtask Queue and pops highest-priority Promise callback.',
      callStack: ['Promise cb()', 'console.log("3. Microtask Promise")'],
      webAPIs: [],
      microtasks: ['queueMicrotask cb ("4. Microtask Queue")'],
      macrotasks: ['setTimeout cb ("2. Macrotask Timer")'],
      consoleLogs: ['1. Start Sync', '5. End Sync', '3. Microtask Promise'],
      activeUnit: 'microtask'
    },
    {
      step: 7,
      description: 'Event loop flushes next microtask from queue (queueMicrotask callback).',
      callStack: ['queueMicrotask cb()', 'console.log("4. Microtask Queue")'],
      webAPIs: [],
      microtasks: [],
      macrotasks: ['setTimeout cb ("2. Macrotask Timer")'],
      consoleLogs: ['1. Start Sync', '5. End Sync', '3. Microtask Promise', '4. Microtask Queue'],
      activeUnit: 'microtask'
    },
    {
      step: 8,
      description: 'Microtask Queue is completely DRAINED! Event loop takes ONE task from Macrotask Queue (setTimeout).',
      callStack: ['setTimeout cb()', 'console.log("2. Macrotask Timer")'],
      webAPIs: [],
      microtasks: [],
      macrotasks: [],
      consoleLogs: ['1. Start Sync', '5. End Sync', '3. Microtask Promise', '4. Microtask Queue', '2. Macrotask Timer'],
      activeUnit: 'macrotask'
    },
    {
      step: 9,
      description: 'All queues drained. Call Stack empty. Event Loop tick cycle complete!',
      callStack: [],
      webAPIs: [],
      microtasks: [],
      macrotasks: [],
      consoleLogs: ['1. Start Sync', '5. End Sync', '3. Microtask Promise', '4. Microtask Queue', '2. Macrotask Timer'],
      activeUnit: 'done'
    }
  ];

  const steps = standardSteps;
  const currentStep = steps[currentStepIndex] || steps[0];

  const handleNext = () => {
    if (currentStepIndex < steps.length - 1) {
      setCurrentStepIndex(prev => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex(prev => prev - 1);
    }
  };

  const handleReset = () => {
    setCurrentStepIndex(0);
    setIsAutoPlaying(false);
  };

  const handleAutoPlay = () => {
    if (isAutoPlaying) {
      setIsAutoPlaying(false);
      return;
    }
    setIsAutoPlaying(true);
    let idx = currentStepIndex;
    const interval = setInterval(() => {
      idx++;
      if (idx >= steps.length) {
        clearInterval(interval);
        setIsAutoPlaying(false);
      } else {
        setCurrentStepIndex(idx);
      }
    }, 1200);
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-zinc-200">
        <div>
          <span className="text-xs font-bold font-mono uppercase tracking-wider text-red-700 bg-red-50 px-2.5 py-1 rounded-md border border-red-100">
            FSWC Lab Exp #3 Interactive Simulator
          </span>
          <h2 className="text-xl font-black text-zinc-900 mt-1">JavaScript V8 Runtime & Event Loop Microtask Simulator</h2>
          <p className="text-xs text-zinc-500">Visual breakdown of Call Stack frames, Web APIs, Microtask vs. Macrotask priorities & Event Loop ticks</p>
        </div>

        {/* Step Navigation */}
        <div className="flex items-center gap-2">
          <button
            onClick={handlePrev}
            disabled={currentStepIndex === 0 || isAutoPlaying}
            className="px-3 py-1.5 bg-white border border-zinc-300 rounded-lg text-xs font-bold text-zinc-700 hover:bg-zinc-100 disabled:opacity-40 cursor-pointer"
          >
            Previous
          </button>
          <button
            onClick={handleNext}
            disabled={currentStepIndex === steps.length - 1 || isAutoPlaying}
            className="px-3 py-1.5 bg-red-700 hover:bg-red-800 text-white rounded-lg text-xs font-bold transition disabled:opacity-40 cursor-pointer"
          >
            Next Step
          </button>
          <button
            onClick={handleAutoPlay}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition cursor-pointer flex items-center gap-1.5 ${
              isAutoPlaying ? 'bg-amber-600 text-white border-amber-700' : 'bg-white text-zinc-700 border-zinc-300 hover:bg-zinc-100'
            }`}
          >
            <Play className="w-3 h-3 fill-current" />
            {isAutoPlaying ? 'Pause' : 'Auto Play'}
          </button>
          <button
            onClick={handleReset}
            className="p-1.5 border border-zinc-300 rounded-lg text-zinc-600 hover:bg-zinc-100 cursor-pointer"
            title="Reset"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Description Banner */}
      <div className="mt-4 p-3.5 bg-zinc-900 text-white rounded-xl flex items-center justify-between text-xs font-mono">
        <div className="flex items-center gap-3">
          <span className="bg-red-700 text-white px-2 py-0.5 rounded font-bold">
            Step {currentStep.step + 1}/{steps.length}
          </span>
          <span className="text-zinc-200">{currentStep.description}</span>
        </div>
        <div className="text-zinc-400 text-[11px] hidden sm:block">
          Tick Rate: ~1.2s per frame
        </div>
      </div>

      {/* Grid: Call Stack, Web API, Microtask, Macrotask, Console */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. Call Stack */}
        <div className={`p-4 rounded-xl border flex flex-col min-h-[220px] transition-all ${
          currentStep.activeUnit === 'stack'
            ? 'bg-red-50/70 border-red-400 shadow-md ring-2 ring-red-200'
            : 'bg-zinc-50 border-zinc-200'
        }`}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-zinc-900 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-red-700" />
              Call Stack (LIFO)
            </span>
            <span className="text-[10px] font-mono bg-zinc-200 text-zinc-700 px-1.5 py-0.5 rounded">
              {currentStep.callStack.length} frames
            </span>
          </div>

          <div className="flex-1 flex flex-col-reverse gap-2 font-mono text-xs">
            {currentStep.callStack.length === 0 ? (
              <div className="flex-1 flex items-center justify-center text-zinc-400 text-[11px] italic">
                Stack is Empty
              </div>
            ) : (
              currentStep.callStack.map((frame, idx) => (
                <div
                  key={idx}
                  className="bg-white border border-red-300 text-red-900 p-2 rounded-lg font-bold shadow-2xs animate-fadeIn"
                >
                  {frame}
                </div>
              ))
            )}
          </div>
        </div>

        {/* 2. Web APIs */}
        <div className={`p-4 rounded-xl border flex flex-col min-h-[220px] transition-all ${
          currentStep.activeUnit === 'webapi'
            ? 'bg-amber-50/70 border-amber-400 shadow-md ring-2 ring-amber-200'
            : 'bg-zinc-50 border-zinc-200'
        }`}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-zinc-900 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-amber-600" />
              Web APIs / libuv
            </span>
            <span className="text-[10px] font-mono bg-zinc-200 text-zinc-700 px-1.5 py-0.5 rounded">
              {currentStep.webAPIs.length} active
            </span>
          </div>

          <div className="flex-1 flex flex-col gap-2 font-mono text-xs">
            {currentStep.webAPIs.length === 0 ? (
              <div className="flex-1 flex items-center justify-center text-zinc-400 text-[11px] italic">
                No active timers / I/O
              </div>
            ) : (
              currentStep.webAPIs.map((api, idx) => (
                <div
                  key={idx}
                  className="bg-white border border-amber-300 text-amber-900 p-2 rounded-lg font-semibold shadow-2xs"
                >
                  {api}
                </div>
              ))
            )}
          </div>
        </div>

        {/* 3. Microtask Queue */}
        <div className={`p-4 rounded-xl border flex flex-col min-h-[220px] transition-all ${
          currentStep.activeUnit === 'microtask'
            ? 'bg-emerald-50/70 border-emerald-400 shadow-md ring-2 ring-emerald-200'
            : 'bg-zinc-50 border-zinc-200'
        }`}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-zinc-900 flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-emerald-600" />
              Microtask Queue (FIFO)
            </span>
            <span className="text-[10px] font-mono bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded">
              High Priority
            </span>
          </div>

          <div className="flex-1 flex flex-col gap-2 font-mono text-xs">
            {currentStep.microtasks.length === 0 ? (
              <div className="flex-1 flex items-center justify-center text-zinc-400 text-[11px] italic">
                Queue Drained
              </div>
            ) : (
              currentStep.microtasks.map((task, idx) => (
                <div
                  key={idx}
                  className="bg-white border border-emerald-300 text-emerald-900 p-2 rounded-lg font-bold shadow-2xs animate-fadeIn"
                >
                  {task}
                </div>
              ))
            )}
          </div>
        </div>

        {/* 4. Macrotask Queue */}
        <div className={`p-4 rounded-xl border flex flex-col min-h-[220px] transition-all ${
          currentStep.activeUnit === 'macrotask'
            ? 'bg-blue-50/70 border-blue-400 shadow-md ring-2 ring-blue-200'
            : 'bg-zinc-50 border-zinc-200'
        }`}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-zinc-900 flex items-center gap-1.5">
              <Cpu className="w-4 h-4 text-blue-600" />
              Macrotask Queue (Task)
            </span>
            <span className="text-[10px] font-mono bg-blue-100 text-blue-800 font-bold px-1.5 py-0.5 rounded">
              Low Priority
            </span>
          </div>

          <div className="flex-1 flex flex-col gap-2 font-mono text-xs">
            {currentStep.macrotasks.length === 0 ? (
              <div className="flex-1 flex items-center justify-center text-zinc-400 text-[11px] italic">
                Queue Drained
              </div>
            ) : (
              currentStep.macrotasks.map((task, idx) => (
                <div
                  key={idx}
                  className="bg-white border border-blue-300 text-blue-900 p-2 rounded-lg font-bold shadow-2xs animate-fadeIn"
                >
                  {task}
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Bottom Row: Source Code & Live Console */}
      <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Source Code View */}
        <div className="lg:col-span-6 bg-zinc-900 text-zinc-200 p-4 rounded-xl font-mono text-xs">
          <div className="text-[11px] text-zinc-400 font-sans font-bold uppercase tracking-wider mb-2">
            Executed JavaScript Source Code:
          </div>
          <pre className="overflow-x-auto leading-relaxed text-zinc-300">
            {`console.log('1. Start Sync');

setTimeout(() => {
  console.log('2. Macrotask Timer');
}, 0);

Promise.resolve().then(() => {
  console.log('3. Microtask Promise');
});

queueMicrotask(() => {
  console.log('4. Microtask Queue');
});

console.log('5. End Sync');`}
          </pre>
        </div>

        {/* Live Console Output */}
        <div className="lg:col-span-6 bg-zinc-950 text-emerald-400 p-4 rounded-xl font-mono text-xs flex flex-col border border-zinc-800">
          <div className="flex items-center justify-between pb-2 border-b border-zinc-800 mb-2">
            <span className="text-[11px] font-sans font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-emerald-500" />
              Standard Output (Console)
            </span>
            <span className="text-[10px] text-zinc-500">{currentStep.consoleLogs.length} logs printed</span>
          </div>

          <div className="flex-1 space-y-1.5 overflow-y-auto max-h-[140px]">
            {currentStep.consoleLogs.length === 0 ? (
              <span className="text-zinc-600 italic">No output printed yet...</span>
            ) : (
              currentStep.consoleLogs.map((log, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <span className="text-zinc-500 text-[10px]">&gt;</span>
                  <span className="text-emerald-300 font-semibold">{log}</span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
