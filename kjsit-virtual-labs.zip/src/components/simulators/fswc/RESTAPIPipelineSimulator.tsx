import React, { useState } from 'react';
import { Send, Globe, Shield, RefreshCw, CheckCircle2, AlertCircle, Clock, Server, Code } from 'lucide-react';

export const RESTAPIPipelineSimulator: React.FC = () => {
  const [method, setMethod] = useState<'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE'>('POST');
  const [endpoint, setEndpoint] = useState<string>('/api/v1/students');
  const [authToken, setAuthToken] = useState<string>('valid-bearer-token-123');
  const [requestBody, setRequestBody] = useState<string>(
    JSON.stringify({ name: 'Aarav Sharma', rollNo: '16010123001', department: 'IT', semester: 5 }, null, 2)
  );

  const [loading, setLoading] = useState<boolean>(false);
  const [corsPreflight, setCorsPreflight] = useState<boolean>(true);
  const [responseLog, setResponseLog] = useState<{
    status: number;
    statusText: string;
    duration: number;
    headers: Record<string, string>;
    data: any;
    corsCheck: string;
  } | null>(null);

  const handleSendRequest = () => {
    setLoading(true);
    setResponseLog(null);

    setTimeout(() => {
      let status = 200;
      let statusText = 'OK';
      let data: any = {};

      if (!authToken.trim()) {
        status = 401;
        statusText = 'Unauthorized';
        data = { error: 'Authentication credentials are missing or invalid.' };
      } else if (method === 'POST') {
        try {
          const parsed = JSON.parse(requestBody);
          status = 201;
          statusText = 'Created';
          data = {
            id: 'std_' + Math.floor(1000 + Math.random() * 9000),
            ...parsed,
            createdAt: new Date().toISOString(),
            status: 'Enrolled'
          };
        } catch (e) {
          status = 400;
          statusText = 'Bad Request';
          data = { error: 'Malformed JSON payload.' };
        }
      } else if (method === 'DELETE') {
        status = 204;
        statusText = 'No Content';
        data = null;
      } else if (method === 'GET') {
        status = 200;
        statusText = 'OK';
        data = {
          total: 2,
          records: [
            { id: 'std_101', name: 'Aarav Sharma', rollNo: '16010123001', department: 'IT' },
            { id: 'std_102', name: 'Diya Patel', rollNo: '16010123002', department: 'CE' }
          ]
        };
      } else {
        status = 200;
        statusText = 'OK';
        data = { message: `Resource at ${endpoint} updated successfully.`, timestamp: Date.now() };
      }

      setResponseLog({
        status,
        statusText,
        duration: Math.floor(35 + Math.random() * 45),
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
          'X-Powered-By': 'Express.js',
          'ETag': 'W/"7a-K9x1b..."'
        },
        data,
        corsCheck: corsPreflight ? 'Preflight OPTIONS 204 Passed (Allowed Origin: *)' : 'Direct Simple Request'
      });
      setLoading(false);
    }, 600);
  };

  const getStatusBadgeColor = (status: number) => {
    if (status >= 200 && status < 300) return 'bg-emerald-100 text-emerald-800 border-emerald-300';
    if (status >= 300 && status < 400) return 'bg-blue-100 text-blue-800 border-blue-300';
    if (status >= 400 && status < 500) return 'bg-amber-100 text-amber-800 border-amber-300';
    return 'bg-red-100 text-red-800 border-red-300';
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm">
      {/* Header */}
      <div className="pb-4 border-b border-zinc-200">
        <span className="text-xs font-bold font-mono uppercase tracking-wider text-red-700 bg-red-50 px-2.5 py-1 rounded-md border border-red-100">
          FSWC Lab Exp #4 Interactive Simulator
        </span>
        <h2 className="text-xl font-black text-zinc-900 mt-1">AJAX & RESTful API Request-Response Lifecycle Explorer</h2>
        <p className="text-xs text-zinc-500">Formulate HTTP methods, request headers, payload serialization, CORS preflight checks & status response parsing</p>
      </div>

      <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Request Builder */}
        <div className="lg:col-span-6 bg-zinc-50 border border-zinc-200 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-bold text-zinc-900 flex items-center gap-2">
            <Globe className="w-4 h-4 text-red-700" />
            HTTP Request Formulator
          </h3>

          {/* Method & URL Bar */}
          <div className="flex gap-2">
            <select
              value={method}
              onChange={(e: any) => setMethod(e.target.value)}
              className={`px-3 py-2 rounded-lg font-mono font-bold text-xs border ${
                method === 'GET' ? 'bg-blue-50 text-blue-800 border-blue-300' :
                method === 'POST' ? 'bg-emerald-50 text-emerald-800 border-emerald-300' :
                method === 'PUT' ? 'bg-amber-50 text-amber-800 border-amber-300' :
                'bg-red-50 text-red-800 border-red-300'
              }`}
            >
              <option value="GET">GET</option>
              <option value="POST">POST</option>
              <option value="PUT">PUT</option>
              <option value="PATCH">PATCH</option>
              <option value="DELETE">DELETE</option>
            </select>

            <input
              type="text"
              value={endpoint}
              onChange={(e) => setEndpoint(e.target.value)}
              className="flex-1 bg-white border border-zinc-300 rounded-lg px-3 py-2 text-xs font-mono font-semibold text-zinc-800 focus:outline-red-700"
              placeholder="/api/v1/resource"
            />

            <button
              onClick={handleSendRequest}
              disabled={loading}
              className="px-4 py-2 bg-red-700 hover:bg-red-800 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-xs cursor-pointer disabled:opacity-50"
            >
              {loading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
              <span>Send</span>
            </button>
          </div>

          {/* Headers Configuration */}
          <div className="space-y-2 text-xs">
            <label className="font-bold text-zinc-700 block">Authorization Header (Bearer Token):</label>
            <input
              type="text"
              value={authToken}
              onChange={(e) => setAuthToken(e.target.value)}
              className="w-full bg-white border border-zinc-300 rounded-lg p-2 font-mono text-xs text-zinc-700"
              placeholder="Bearer <jwt_token>"
            />
            <div className="flex items-center gap-2 pt-1">
              <input
                type="checkbox"
                id="cors-check"
                checked={corsPreflight}
                onChange={(e) => setCorsPreflight(e.target.checked)}
                className="accent-red-700"
              />
              <label htmlFor="cors-check" className="text-zinc-600 cursor-pointer">
                Simulate Browser CORS Preflight (OPTIONS Request)
              </label>
            </div>
          </div>

          {/* Request Body (For POST/PUT/PATCH) */}
          {method !== 'GET' && method !== 'DELETE' && (
            <div className="space-y-1.5 text-xs">
              <label className="font-bold text-zinc-700 block">Request Payload (JSON):</label>
              <textarea
                rows={5}
                value={requestBody}
                onChange={(e) => setRequestBody(e.target.value)}
                className="w-full bg-zinc-900 text-zinc-200 border border-zinc-700 rounded-lg p-3 font-mono text-xs focus:outline-red-600 leading-relaxed"
              />
            </div>
          )}
        </div>

        {/* Right Column: Response Inspector */}
        <div className="lg:col-span-6 flex flex-col">
          <div className="bg-zinc-900 text-zinc-100 rounded-xl p-5 flex-1 flex flex-col font-mono text-xs border border-zinc-800">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800 mb-3">
              <span className="font-sans font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
                <Server className="w-3.5 h-3.5 text-red-400" />
                HTTP Server Response Inspector
              </span>
              {responseLog && (
                <span className={`px-2 py-0.5 rounded font-bold border ${getStatusBadgeColor(responseLog.status)}`}>
                  {responseLog.status} {responseLog.statusText}
                </span>
              )}
            </div>

            {loading ? (
              <div className="flex-1 flex flex-col items-center justify-center text-zinc-400 gap-2">
                <RefreshCw className="w-6 h-6 animate-spin text-red-500" />
                <span className="font-sans text-xs">Executing HTTP Request Cycle...</span>
              </div>
            ) : responseLog ? (
              <div className="space-y-3 flex-1 overflow-y-auto max-h-[360px]">
                {/* Meta stats */}
                <div className="flex items-center justify-between text-[11px] text-zinc-400 bg-zinc-800/80 p-2 rounded">
                  <span className="flex items-center gap-1"><Clock className="w-3 h-3 text-emerald-400" /> Latency: {responseLog.duration}ms</span>
                  <span className="text-zinc-300 font-sans">{responseLog.corsCheck}</span>
                </div>

                {/* Response Headers */}
                <div>
                  <div className="text-zinc-500 uppercase font-sans font-bold text-[10px] tracking-wider mb-1">Response Headers:</div>
                  <div className="bg-zinc-950 p-2.5 rounded border border-zinc-800 space-y-0.5 text-zinc-400 text-[11px]">
                    {Object.entries(responseLog.headers).map(([k, v]) => (
                      <div key={k} className="flex">
                        <span className="text-red-400 w-44">{k}:</span>
                        <span className="text-zinc-200">{v}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Response Body */}
                <div>
                  <div className="text-zinc-500 uppercase font-sans font-bold text-[10px] tracking-wider mb-1">Response Body:</div>
                  <pre className="bg-zinc-950 p-3 rounded border border-zinc-800 text-emerald-400 overflow-x-auto leading-relaxed text-[11px]">
                    {responseLog.data ? JSON.stringify(responseLog.data, null, 2) : '/* HTTP 204 No Content - Empty Body */'}
                  </pre>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-zinc-500 font-sans text-xs text-center p-6">
                <Send className="w-8 h-8 text-zinc-600 mb-2" />
                <span>Configure your request and click "Send" to inspect raw HTTP status headers and JSON payloads.</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
