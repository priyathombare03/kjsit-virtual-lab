import React, { useState } from 'react';
import { Layout, Box, Sliders, CheckCircle2, RotateCcw, Monitor, Smartphone, Tablet } from 'lucide-react';

export const DOMBoxModelSimulator: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'boxmodel' | 'flexbox' | 'grid'>('boxmodel');

  // Box Model States
  const [margin, setMargin] = useState<number>(20);
  const [border, setBorder] = useState<number>(4);
  const [padding, setPadding] = useState<number>(24);
  const [contentWidth, setContentWidth] = useState<number>(240);
  const [contentHeight, setContentHeight] = useState<number>(120);
  const [boxSizing, setBoxSizing] = useState<'content-box' | 'border-box'>('border-box');

  // Flexbox States
  const [flexDirection, setFlexDirection] = useState<'row' | 'column' | 'row-reverse'>('row');
  const [justifyContent, setJustifyContent] = useState<'flex-start' | 'center' | 'space-between' | 'space-around' | 'space-evenly'>('space-between');
  const [alignItems, setAlignItems] = useState<'stretch' | 'center' | 'flex-start' | 'flex-end'>('center');
  const [flexWrap, setFlexWrap] = useState<'nowrap' | 'wrap'>('wrap');
  const [itemCount, setItemCount] = useState<number>(4);

  // Grid States
  const [gridColumns, setGridColumns] = useState<number>(3);
  const [gridGap, setGridGap] = useState<number>(16);
  const [deviceView, setDeviceView] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');

  // Box calculations
  const totalRenderedWidth = boxSizing === 'border-box'
    ? contentWidth
    : contentWidth + padding * 2 + border * 2;
  const totalRenderedHeight = boxSizing === 'border-box'
    ? contentHeight
    : contentHeight + padding * 2 + border * 2;
  const totalOccupiedWidth = totalRenderedWidth + margin * 2;
  const totalOccupiedHeight = totalRenderedHeight + margin * 2;

  const actualContentW = boxSizing === 'border-box'
    ? Math.max(20, contentWidth - padding * 2 - border * 2)
    : contentWidth;
  const actualContentH = boxSizing === 'border-box'
    ? Math.max(20, contentHeight - padding * 2 - border * 2)
    : contentHeight;

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-zinc-200">
        <div>
          <span className="text-xs font-bold font-mono uppercase tracking-wider text-red-700 bg-red-50 px-2.5 py-1 rounded-md border border-red-100">
            FSWC Lab Exp #1 Interactive Simulator
          </span>
          <h2 className="text-xl font-black text-zinc-900 mt-1">HTML5 Semantic Layout, Box Model & CSS Flex/Grid Engine</h2>
          <p className="text-xs text-zinc-500">Interactive geometrical Box Model calculator and 1D/2D responsive layout axis visualizer</p>
        </div>

        {/* Tab switcher */}
        <div className="flex bg-zinc-100 p-1 rounded-xl">
          <button
            onClick={() => setActiveTab('boxmodel')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'boxmodel' ? 'bg-white text-red-700 shadow-xs' : 'text-zinc-600 hover:text-zinc-900'
            }`}
          >
            Box Model Geometry
          </button>
          <button
            onClick={() => setActiveTab('flexbox')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'flexbox' ? 'bg-white text-red-700 shadow-xs' : 'text-zinc-600 hover:text-zinc-900'
            }`}
          >
            Flexbox Axis Alignment
          </button>
          <button
            onClick={() => setActiveTab('grid')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'grid' ? 'bg-white text-red-700 shadow-xs' : 'text-zinc-600 hover:text-zinc-900'
            }`}
          >
            2D CSS Grid Tracks
          </button>
        </div>
      </div>

      {/* Tab 1: Box Model */}
      {activeTab === 'boxmodel' && (
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Controls */}
          <div className="lg:col-span-5 bg-zinc-50 border border-zinc-200 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-zinc-900 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-red-700" />
                Box Model Parameters
              </h3>
              <button
                onClick={() => {
                  setMargin(20);
                  setBorder(4);
                  setPadding(24);
                  setContentWidth(240);
                  setContentHeight(120);
                  setBoxSizing('border-box');
                }}
                className="text-xs text-zinc-500 hover:text-zinc-900 flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" /> Reset
              </button>
            </div>

            {/* Box Sizing Toggle */}
            <div>
              <label className="text-xs font-bold text-zinc-700 mb-1.5 block">box-sizing Property:</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setBoxSizing('border-box')}
                  className={`py-2 px-3 rounded-lg text-xs font-bold border text-center cursor-pointer transition ${
                    boxSizing === 'border-box'
                      ? 'bg-red-700 text-white border-red-800'
                      : 'bg-white text-zinc-700 border-zinc-300 hover:bg-zinc-100'
                  }`}
                >
                  border-box (Modern Standard)
                </button>
                <button
                  onClick={() => setBoxSizing('content-box')}
                  className={`py-2 px-3 rounded-lg text-xs font-bold border text-center cursor-pointer transition ${
                    boxSizing === 'content-box'
                      ? 'bg-red-700 text-white border-red-800'
                      : 'bg-white text-zinc-700 border-zinc-300 hover:bg-zinc-100'
                  }`}
                >
                  content-box (W3C Legacy)
                </button>
              </div>
            </div>

            {/* Sliders */}
            <div className="space-y-3 pt-2 text-xs">
              <div>
                <div className="flex justify-between font-semibold text-zinc-700 mb-1">
                  <span>Margin (Outer Clearance)</span>
                  <span className="font-mono text-amber-700">{margin}px</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="50"
                  value={margin}
                  onChange={(e) => setMargin(Number(e.target.value))}
                  className="w-full accent-amber-600"
                />
              </div>

              <div>
                <div className="flex justify-between font-semibold text-zinc-700 mb-1">
                  <span>Border (Stroke Width)</span>
                  <span className="font-mono text-yellow-700">{border}px</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="20"
                  value={border}
                  onChange={(e) => setBorder(Number(e.target.value))}
                  className="w-full accent-yellow-600"
                />
              </div>

              <div>
                <div className="flex justify-between font-semibold text-zinc-700 mb-1">
                  <span>Padding (Inner Clearance)</span>
                  <span className="font-mono text-emerald-700">{padding}px</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="60"
                  value={padding}
                  onChange={(e) => setPadding(Number(e.target.value))}
                  className="w-full accent-emerald-600"
                />
              </div>

              <div>
                <div className="flex justify-between font-semibold text-zinc-700 mb-1">
                  <span>Declared Width</span>
                  <span className="font-mono text-blue-700">{contentWidth}px</span>
                </div>
                <input
                  type="range"
                  min="160"
                  max="360"
                  value={contentWidth}
                  onChange={(e) => setContentWidth(Number(e.target.value))}
                  className="w-full accent-blue-600"
                />
              </div>

              <div>
                <div className="flex justify-between font-semibold text-zinc-700 mb-1">
                  <span>Declared Height</span>
                  <span className="font-mono text-blue-700">{contentHeight}px</span>
                </div>
                <input
                  type="range"
                  min="80"
                  max="200"
                  value={contentHeight}
                  onChange={(e) => setContentHeight(Number(e.target.value))}
                  className="w-full accent-blue-600"
                />
              </div>
            </div>

            {/* Calculations Box */}
            <div className="bg-white p-3 rounded-lg border border-zinc-200 text-xs space-y-1 font-mono">
              <div className="text-zinc-500 text-[11px] uppercase font-bold tracking-wider mb-1">Live Box Dimensions:</div>
              <div className="flex justify-between">
                <span className="text-zinc-600">Rendered Box Size:</span>
                <span className="font-bold text-zinc-900">{totalRenderedWidth}px × {totalRenderedHeight}px</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-600">Total Layout Footprint:</span>
                <span className="font-bold text-red-700">{totalOccupiedWidth}px × {totalOccupiedHeight}px</span>
              </div>
              <div className="flex justify-between text-zinc-500 pt-1 border-t border-zinc-100">
                <span>Inner Content Area:</span>
                <span>{actualContentW}px × {actualContentH}px</span>
              </div>
            </div>
          </div>

          {/* Interactive Box Visualizer */}
          <div className="lg:col-span-7 flex flex-col items-center justify-center p-6 bg-zinc-900 rounded-xl overflow-hidden min-h-[380px]">
            {/* Margin Box */}
            <div
              className="bg-amber-900/40 border border-dashed border-amber-400/80 rounded-lg flex flex-col items-center justify-center relative transition-all duration-200"
              style={{
                padding: `${margin}px`,
                maxWidth: '100%'
              }}
            >
              <span className="absolute top-1 left-2 text-[10px] font-mono font-bold text-amber-300">
                MARGIN: {margin}px
              </span>

              {/* Border Box */}
              <div
                className="bg-yellow-900/50 border border-yellow-400 rounded-md flex flex-col items-center justify-center relative transition-all duration-200"
                style={{
                  borderWidth: `${border}px`,
                  borderStyle: 'solid',
                  borderColor: '#facc15'
                }}
              >
                {/* Padding Box */}
                <div
                  className="bg-emerald-900/50 border border-dashed border-emerald-400/80 flex flex-col items-center justify-center relative transition-all duration-200"
                  style={{
                    padding: `${padding}px`
                  }}
                >
                  <span className="absolute top-1 left-2 text-[10px] font-mono font-bold text-emerald-300">
                    PADDING: {padding}px
                  </span>

                  {/* Content Box */}
                  <div
                    className="bg-blue-600 text-white rounded flex flex-col items-center justify-center text-center p-2 shadow-inner transition-all duration-200"
                    style={{
                      width: `${actualContentW}px`,
                      height: `${actualContentH}px`
                    }}
                  >
                    <span className="text-xs font-black tracking-wide">CONTENT</span>
                    <span className="text-[11px] font-mono opacity-90">{actualContentW} × {actualContentH} px</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Legend */}
            <div className="flex flex-wrap items-center justify-center gap-4 mt-6 text-xs text-zinc-300">
              <span className="flex items-center gap-1.5"><span className="w-3 h-3 bg-amber-600 rounded"></span> Margin</span>
              <span className="flex items-center gap-1.5"><span className="w-3 h-3 bg-yellow-400 rounded"></span> Border</span>
              <span className="flex items-center gap-1.5"><span className="w-3 h-3 bg-emerald-600 rounded"></span> Padding</span>
              <span className="flex items-center gap-1.5"><span className="w-3 h-3 bg-blue-600 rounded"></span> Content Area</span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Flexbox */}
      {activeTab === 'flexbox' && (
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-4 bg-zinc-50 border border-zinc-200 rounded-xl p-5 space-y-4 text-xs">
            <h3 className="text-sm font-bold text-zinc-900 flex items-center gap-2">
              <Layout className="w-4 h-4 text-red-700" />
              Flex Container Properties
            </h3>

            <div>
              <label className="font-bold text-zinc-700 mb-1 block">flex-direction (Main Axis):</label>
              <select
                value={flexDirection}
                onChange={(e: any) => setFlexDirection(e.target.value)}
                className="w-full bg-white border border-zinc-300 rounded-lg p-2 font-mono font-medium"
              >
                <option value="row">row (Left to Right)</option>
                <option value="column">column (Top to Bottom)</option>
                <option value="row-reverse">row-reverse (Right to Left)</option>
              </select>
            </div>

            <div>
              <label className="font-bold text-zinc-700 mb-1 block">justify-content (Main Axis Alignment):</label>
              <select
                value={justifyContent}
                onChange={(e: any) => setJustifyContent(e.target.value)}
                className="w-full bg-white border border-zinc-300 rounded-lg p-2 font-mono font-medium"
              >
                <option value="flex-start">flex-start</option>
                <option value="center">center</option>
                <option value="space-between">space-between</option>
                <option value="space-around">space-around</option>
                <option value="space-evenly">space-evenly</option>
              </select>
            </div>

            <div>
              <label className="font-bold text-zinc-700 mb-1 block">align-items (Cross Axis Alignment):</label>
              <select
                value={alignItems}
                onChange={(e: any) => setAlignItems(e.target.value)}
                className="w-full bg-white border border-zinc-300 rounded-lg p-2 font-mono font-medium"
              >
                <option value="stretch">stretch</option>
                <option value="center">center</option>
                <option value="flex-start">flex-start</option>
                <option value="flex-end">flex-end</option>
              </select>
            </div>

            <div>
              <label className="font-bold text-zinc-700 mb-1 block">flex-wrap:</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setFlexWrap('nowrap')}
                  className={`py-1.5 rounded-lg border font-bold ${flexWrap === 'nowrap' ? 'bg-red-700 text-white border-red-800' : 'bg-white text-zinc-700 border-zinc-300'}`}
                >
                  nowrap
                </button>
                <button
                  onClick={() => setFlexWrap('wrap')}
                  className={`py-1.5 rounded-lg border font-bold ${flexWrap === 'wrap' ? 'bg-red-700 text-white border-red-800' : 'bg-white text-zinc-700 border-zinc-300'}`}
                >
                  wrap
                </button>
              </div>
            </div>

            <div>
              <div className="flex justify-between font-bold text-zinc-700 mb-1">
                <span>Child Items Count:</span>
                <span className="text-red-700 font-mono">{itemCount}</span>
              </div>
              <input
                type="range"
                min="2"
                max="8"
                value={itemCount}
                onChange={(e) => setItemCount(Number(e.target.value))}
                className="w-full accent-red-700"
              />
            </div>
          </div>

          <div className="lg:col-span-8 flex flex-col">
            <div className="bg-zinc-100 border border-zinc-300 rounded-xl p-4 flex-1 min-h-[340px] flex flex-col">
              <div className="text-[11px] font-mono text-zinc-500 mb-2 flex justify-between items-center">
                <span>.container &#123; display: flex; flex-direction: {flexDirection}; justify-content: {justifyContent}; align-items: {alignItems}; &#125;</span>
              </div>

              {/* Flex Container Playground */}
              <div
                className="bg-white border-2 border-dashed border-red-300 rounded-xl p-4 flex-1 transition-all duration-300 overflow-hidden"
                style={{
                  display: 'flex',
                  flexDirection: flexDirection,
                  justifyContent: justifyContent,
                  alignItems: alignItems,
                  flexWrap: flexWrap,
                  gap: '12px'
                }}
              >
                {Array.from({ length: itemCount }).map((_, idx) => (
                  <div
                    key={idx}
                    className="bg-gradient-to-br from-red-700 to-red-900 text-white p-4 rounded-xl shadow-md min-w-[80px] min-h-[70px] flex flex-col items-center justify-center font-bold text-xs"
                  >
                    <span>Item #{idx + 1}</span>
                    <span className="text-[10px] font-mono opacity-80 mt-1">grow: 0, shrink: 1</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: CSS Grid */}
      {activeTab === 'grid' && (
        <div className="mt-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 bg-zinc-50 border border-zinc-200 rounded-xl p-4">
            <div className="flex items-center gap-4 text-xs">
              <span className="font-bold text-zinc-700">Columns:</span>
              {[1, 2, 3, 4].map((col) => (
                <button
                  key={col}
                  onClick={() => setGridColumns(col)}
                  className={`px-3 py-1.5 rounded-lg border font-bold cursor-pointer ${
                    gridColumns === col ? 'bg-red-700 text-white border-red-800' : 'bg-white text-zinc-700 border-zinc-300'
                  }`}
                >
                  {col} {col === 1 ? 'Column' : 'Columns'}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2 text-xs">
              <span className="font-bold text-zinc-700">Gap:</span>
              <input
                type="range"
                min="8"
                max="32"
                value={gridGap}
                onChange={(e) => setGridGap(Number(e.target.value))}
                className="w-24 accent-red-700"
              />
              <span className="font-mono text-red-700 font-bold">{gridGap}px</span>
            </div>

            <div className="flex items-center gap-1 bg-white border border-zinc-300 rounded-lg p-1">
              <button
                onClick={() => setDeviceView('desktop')}
                className={`p-1.5 rounded ${deviceView === 'desktop' ? 'bg-zinc-200 text-red-700' : 'text-zinc-600'}`}
                title="Desktop View"
              >
                <Monitor className="w-4 h-4" />
              </button>
              <button
                onClick={() => setDeviceView('tablet')}
                className={`p-1.5 rounded ${deviceView === 'tablet' ? 'bg-zinc-200 text-red-700' : 'text-zinc-600'}`}
                title="Tablet View"
              >
                <Tablet className="w-4 h-4" />
              </button>
              <button
                onClick={() => setDeviceView('mobile')}
                className={`p-1.5 rounded ${deviceView === 'mobile' ? 'bg-zinc-200 text-red-700' : 'text-zinc-600'}`}
                title="Mobile View"
              >
                <Smartphone className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Grid Playground */}
          <div className="flex justify-center p-4 bg-zinc-900 rounded-xl">
            <div
              className={`bg-zinc-800 p-6 rounded-xl border border-zinc-700 transition-all duration-300 w-full ${
                deviceView === 'mobile' ? 'max-w-sm' : deviceView === 'tablet' ? 'max-w-2xl' : 'max-w-5xl'
              }`}
            >
              <div className="text-[11px] font-mono text-zinc-400 mb-3">
                display: grid; grid-template-columns: repeat({deviceView === 'mobile' ? 1 : gridColumns}, 1fr); gap: {gridGap}px;
              </div>

              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: deviceView === 'mobile' ? '1fr' : `repeat(${gridColumns}, 1fr)`,
                  gap: `${gridGap}px`
                }}
              >
                {[
                  { title: '<header>', desc: 'Semantic branding & navigation' },
                  { title: '<main>', desc: 'Primary application content' },
                  { title: '<section class="analytics">', desc: 'Real-time telemetry cards' },
                  { title: '<article class="post">', desc: 'Self-contained blog item' },
                  { title: '<aside>', desc: 'Contextual sidebar links' },
                  { title: '<footer>', desc: 'Copyright & metadata footer' }
                ].map((item, idx) => (
                  <div
                    key={idx}
                    className="bg-zinc-900 border border-zinc-700 rounded-lg p-4 text-white hover:border-red-500 transition shadow-sm"
                  >
                    <span className="font-mono text-xs text-red-400 font-bold">{item.title}</span>
                    <p className="text-xs text-zinc-400 mt-1">{item.desc}</p>
                    <div className="mt-3 flex items-center justify-between text-[10px] text-zinc-500 font-mono">
                      <span>Grid Area #{idx + 1}</span>
                      <span className="text-emerald-400">1fr Auto-sized</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
