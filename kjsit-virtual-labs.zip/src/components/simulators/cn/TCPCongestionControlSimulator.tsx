import React, { useState } from 'react';
import { Play, RotateCcw, TrendingUp, AlertTriangle, FastForward, CheckCircle2, ShieldAlert } from 'lucide-react';

interface DataPoint {
  rtt: number;
  cwnd: number;
  ssthresh: number;
  state: 'Slow Start' | 'Congestion Avoidance' | 'Fast Recovery' | 'Timeout';
}

export const TCPCongestionControlSimulator: React.FC = () => {
  const INITIAL_SSTHRESH = 16;
  const [cwnd, setCwnd] = useState(1);
  const [ssthresh, setSsthresh] = useState(INITIAL_SSTHRESH);
  const [rtt, setRtt] = useState(1);
  const [state, setState] = useState<'Slow Start' | 'Congestion Avoidance' | 'Fast Recovery' | 'Timeout'>('Slow Start');
  const [history, setHistory] = useState<DataPoint[]>([
    { rtt: 1, cwnd: 1, ssthresh: INITIAL_SSTHRESH, state: 'Slow Start' }
  ]);
  const [logs, setLogs] = useState<string[]>([
    'TCP Tahoe/Reno state initialized with cwnd = 1 MSS, ssthresh = 16 MSS.'
  ]);

  const addLog = (msg: string) => {
    setLogs(prev => [msg, ...prev.slice(0, 15)]);
  };

  const handleNextRTT = () => {
    let nextCwnd = cwnd;
    let nextState = state;

    if (state === 'Slow Start') {
      nextCwnd = cwnd * 2;
      if (nextCwnd >= ssthresh) {
        nextState = 'Congestion Avoidance';
        addLog(`[AIMD] cwnd (${nextCwnd}) reached ssthresh (${ssthresh}). Transitioning to Congestion Avoidance (Additive Increase).`);
      } else {
        addLog(`[SLOW START] RTT ${rtt + 1}: Doubled cwnd from ${cwnd} to ${nextCwnd} MSS.`);
      }
    } else if (state === 'Congestion Avoidance') {
      nextCwnd = cwnd + 1;
      addLog(`[CONGESTION AVOIDANCE] RTT ${rtt + 1}: Additively incremented cwnd to ${nextCwnd} MSS (+1 MSS/RTT).`);
    } else if (state === 'Fast Recovery') {
      nextState = 'Congestion Avoidance';
      nextCwnd = ssthresh + 1;
      addLog(`[FAST RECOVERY] New ACK received. Exiting Fast Recovery into Congestion Avoidance with cwnd = ${nextCwnd}.`);
    }

    const nextRtt = rtt + 1;
    setCwnd(nextCwnd);
    setState(nextState);
    setRtt(nextRtt);

    setHistory(prev => [
      ...prev,
      { rtt: nextRtt, cwnd: nextCwnd, ssthresh, state: nextState }
    ]);
  };

  const handleTripleDupACK = () => {
    const newSsthresh = Math.max(2, Math.floor(cwnd / 2));
    const newCwnd = newSsthresh + 3;
    const nextRtt = rtt + 1;

    setSsthresh(newSsthresh);
    setCwnd(newCwnd);
    setState('Fast Recovery');
    setRtt(nextRtt);

    addLog(`*** 3 DUPLICATE ACKs (TCP Reno Fast Retransmit) *** ssthresh set to ${newSsthresh} MSS. cwnd set to ${newCwnd} MSS.`);

    setHistory(prev => [
      ...prev,
      { rtt: nextRtt, cwnd: newCwnd, ssthresh: newSsthresh, state: 'Fast Recovery' }
    ]);
  };

  const handleTimeoutLoss = () => {
    const newSsthresh = Math.max(2, Math.floor(cwnd / 2));
    const newCwnd = 1;
    const nextRtt = rtt + 1;

    setSsthresh(newSsthresh);
    setCwnd(newCwnd);
    setState('Slow Start');
    setRtt(nextRtt);

    addLog(`*** RETRANSMISSION TIMEOUT (RTO EXPIRED) *** ssthresh halved to ${newSsthresh} MSS. cwnd collapsed back to 1 MSS!`);

    setHistory(prev => [
      ...prev,
      { rtt: nextRtt, cwnd: newCwnd, ssthresh: newSsthresh, state: 'Timeout' }
    ]);
  };

  const handleReset = () => {
    setCwnd(1);
    setSsthresh(INITIAL_SSTHRESH);
    setRtt(1);
    setState('Slow Start');
    setHistory([{ rtt: 1, cwnd: 1, ssthresh: INITIAL_SSTHRESH, state: 'Slow Start' }]);
    setLogs(['Congestion control state reset.']);
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-xl p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-zinc-200">
        <div>
          <h3 className="text-lg font-bold text-zinc-900 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-red-600" />
            <span>TCP Congestion Control Simulator (AIMD / Reno)</span>
          </h3>
          <p className="text-xs text-zinc-500 mt-0.5">
            Slow Start (exponential), Congestion Avoidance (additive increase), Multiplicative Decrease, Fast Retransmit/Recovery
          </p>
        </div>
        <button
          onClick={handleReset}
          className="px-3 py-1.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset</span>
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        <div className="p-4 bg-zinc-50 border border-zinc-200 rounded-xl">
          <span className="text-[11px] font-bold text-zinc-500 uppercase">Congestion Window (cwnd)</span>
          <span className="text-2xl font-mono font-bold text-red-600 block mt-1">
            {cwnd} <span className="text-xs text-zinc-500 font-normal">MSS</span>
          </span>
        </div>

        <div className="p-4 bg-zinc-50 border border-zinc-200 rounded-xl">
          <span className="text-[11px] font-bold text-zinc-500 uppercase">Slow Start Threshold</span>
          <span className="text-2xl font-mono font-bold text-zinc-900 block mt-1">
            {ssthresh} <span className="text-xs text-zinc-500 font-normal">MSS</span>
          </span>
        </div>

        <div className="p-4 bg-zinc-50 border border-zinc-200 rounded-xl">
          <span className="text-[11px] font-bold text-zinc-500 uppercase">Current Phase</span>
          <span className="text-sm font-bold text-red-700 block mt-2">
            {state}
          </span>
        </div>

        <div className="p-4 bg-zinc-50 border border-zinc-200 rounded-xl">
          <span className="text-[11px] font-bold text-zinc-500 uppercase">Transmission Round</span>
          <span className="text-2xl font-mono font-bold text-zinc-800 block mt-1">
            RTT #{rtt}
          </span>
        </div>
      </div>

      {/* Interactive Window Visual Chart */}
      <div className="border border-zinc-200 rounded-xl p-5 bg-zinc-50 mb-6">
        <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider block mb-3">
          Congestion Window Growth Curve (cwnd vs RTT):
        </span>

        <div className="h-44 flex items-end gap-1 p-3 bg-white border border-zinc-200 rounded-xl overflow-x-auto">
          {history.map((point, index) => {
            const heightPercent = Math.min(100, (point.cwnd / 36) * 100);
            return (
              <div key={index} className="flex flex-col items-center min-w-[24px] group relative">
                <div
                  style={{ height: `${heightPercent}%` }}
                  className={`w-4 rounded-t transition-all ${
                    point.state === 'Slow Start'
                      ? 'bg-blue-600'
                      : point.state === 'Congestion Avoidance'
                      ? 'bg-emerald-600'
                      : point.state === 'Fast Recovery'
                      ? 'bg-amber-500'
                      : 'bg-red-600'
                  }`}
                />
                <span className="text-[9px] font-mono text-zinc-400 mt-1">{point.rtt}</span>

                {/* Hover Tooltip */}
                <div className="absolute bottom-full mb-1 hidden group-hover:block bg-zinc-900 text-white text-[10px] p-1.5 rounded whitespace-nowrap z-10 shadow-lg">
                  RTT {point.rtt}: cwnd = {point.cwnd}, ssthresh = {point.ssthresh} ({point.state})
                </div>
              </div>
            );
          })}
        </div>

        <div className="flex flex-wrap items-center gap-4 mt-3 text-xs text-zinc-600">
          <span className="flex items-center gap-1.5">
            <span className="w-3 h-3 bg-blue-600 rounded-xs"></span> Slow Start (x2)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-3 h-3 bg-emerald-600 rounded-xs"></span> Congestion Avoidance (+1)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-3 h-3 bg-amber-500 rounded-xs"></span> Fast Recovery
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-3 h-3 bg-red-600 rounded-xs"></span> Timeout Drop
          </span>
        </div>
      </div>

      {/* Simulation Controls */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
        <button
          onClick={handleNextRTT}
          className="px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-lg shadow-sm flex items-center justify-center gap-2 cursor-pointer transition-colors"
        >
          <Play className="w-4 h-4" />
          <span>Advance 1 RTT (ACKs Received)</span>
        </button>

        <button
          onClick={handleTripleDupACK}
          className="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-lg shadow-sm flex items-center justify-center gap-2 cursor-pointer transition-colors"
        >
          <FastForward className="w-4 h-4" />
          <span>Simulate 3-Dup ACKs (Fast Retransmit)</span>
        </button>

        <button
          onClick={handleTimeoutLoss}
          className="px-4 py-2.5 bg-zinc-900 hover:bg-black text-white font-bold text-xs rounded-lg shadow-sm flex items-center justify-center gap-2 cursor-pointer transition-colors"
        >
          <AlertTriangle className="w-4 h-4 text-red-400" />
          <span>Simulate RTO Timeout (Heavy Loss)</span>
        </button>
      </div>

      {/* Log console */}
      <div className="border border-zinc-200 rounded-xl p-4 bg-zinc-50">
        <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider block mb-2">
          TCP State Transition Log:
        </span>
        <div className="bg-white border border-zinc-200 rounded-lg p-3 max-h-36 overflow-y-auto font-mono text-xs text-zinc-800 space-y-1">
          {logs.map((l, i) => (
            <div key={i} className="border-b border-zinc-100 pb-0.5">{l}</div>
          ))}
        </div>
      </div>
    </div>
  );
};
