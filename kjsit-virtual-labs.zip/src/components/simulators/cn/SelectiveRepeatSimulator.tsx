import React, { useState } from 'react';
import { Play, RotateCcw, ShieldCheck, CheckCircle2, AlertOctagon } from 'lucide-react';

interface SRPacket {
  id: number;
  txStatus: 'unsent' | 'sent' | 'acked' | 'lost';
  rxStatus: 'unreceived' | 'buffered' | 'delivered';
}

export const SelectiveRepeatSimulator: React.FC = () => {
  const TOTAL = 10;
  const WINDOW = 4;

  const [txBase, setTxBase] = useState(0);
  const [rxBase, setRxBase] = useState(0);
  const [packets, setPackets] = useState<SRPacket[]>(
    Array.from({ length: TOTAL }, (_, i) => ({
      id: i,
      txStatus: 'unsent',
      rxStatus: 'unreceived'
    }))
  );
  const [logs, setLogs] = useState<string[]>([
    'Selective Repeat ARQ initialized (Ws = Wr = 4).'
  ]);

  const addLog = (msg: string) => {
    setLogs(prev => [msg, ...prev.slice(0, 15)]);
  };

  const handleSendPacket = (pktId: number) => {
    if (pktId >= txBase + WINDOW || pktId >= TOTAL) return;

    setPackets(prev => prev.map(p => p.id === pktId ? { ...p, txStatus: 'sent' } : p));
    addLog(`[TX] Transmitted Packet #${pktId}. Individual timer started.`);

    // Simulated channel delivery
    setTimeout(() => {
      setPackets(prev => {
        const target = prev.find(p => p.id === pktId);
        if (!target || target.txStatus === 'lost') return prev;

        const updated = prev.map(p => {
          if (p.id === pktId) {
            return { ...p, txStatus: 'acked' as const, rxStatus: 'buffered' as const };
          }
          return p;
        });

        // Check if rxBase can slide
        let newRxBase = rxBase;
        while (newRxBase < TOTAL && updated[newRxBase]?.rxStatus === 'buffered') {
          updated[newRxBase].rxStatus = 'delivered';
          newRxBase++;
        }
        setRxBase(newRxBase);

        // Check if txBase can slide
        let newTxBase = txBase;
        while (newTxBase < TOTAL && updated[newTxBase]?.txStatus === 'acked') {
          newTxBase++;
        }
        setTxBase(newTxBase);

        return updated;
      });

      addLog(`[RX] Packet #${pktId} arrived safely! Buffered & Selective ACK #${pktId} sent.`);
    }, 700);
  };

  const handleDropPacket = (pktId: number) => {
    setPackets(prev => prev.map(p => p.id === pktId ? { ...p, txStatus: 'lost' } : p));
    addLog(`*** PACKET LOSS *** Packet #${pktId} was lost in transmission!`);
  };

  const handleRetransmitOnly = (pktId: number) => {
    addLog(`*** TIMEOUT on Packet #${pktId} *** Retransmitting ONLY missing Packet #${pktId}!`);
    handleSendPacket(pktId);
  };

  const handleReset = () => {
    setTxBase(0);
    setRxBase(0);
    setPackets(Array.from({ length: TOTAL }, (_, i) => ({ id: i, txStatus: 'unsent', rxStatus: 'unreceived' })));
    setLogs(['Selective Repeat simulator reset.']);
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-xl p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-zinc-200">
        <div>
          <h3 className="text-lg font-bold text-zinc-900 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-red-600" />
            <span>Selective Repeat (SR) ARQ Protocol Simulator</span>
          </h3>
          <p className="text-xs text-zinc-500 mt-0.5">
            Independent sender/receiver windows (Ws = Wr = {WINDOW}), selective buffering, and selective retransmission
          </p>
        </div>
        <button
          onClick={handleReset}
          className="px-3 py-1.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset</span>
        </button>
      </div>

      {/* Dual Windows: Sender & Receiver */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Sender Window */}
        <div className="border border-zinc-200 rounded-xl p-5 bg-zinc-50">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider">
              Sender Pipeline (Base: #{txBase})
            </span>
            <span className="text-xs text-zinc-500">
              Window: [{txBase} .. {Math.min(txBase + WINDOW - 1, TOTAL - 1)}]
            </span>
          </div>

          <div className="grid grid-cols-5 gap-2 p-3 bg-white border border-zinc-200 rounded-xl">
            {packets.map((p) => {
              const inTxWindow = p.id >= txBase && p.id < txBase + WINDOW;
              return (
                <div
                  key={p.id}
                  className={`relative flex flex-col items-center justify-center p-3 rounded-lg border font-mono transition-all ${
                    p.txStatus === 'acked'
                      ? 'bg-emerald-50 border-emerald-400 text-emerald-900'
                      : p.txStatus === 'sent'
                      ? 'bg-blue-50 border-blue-400 text-blue-900 animate-pulse'
                      : p.txStatus === 'lost'
                      ? 'bg-red-100 border-red-500 text-red-900'
                      : inTxWindow
                      ? 'bg-zinc-100 border-zinc-400 text-zinc-800'
                      : 'bg-zinc-50 border-zinc-200 text-zinc-400 opacity-60'
                  } ${inTxWindow ? 'ring-2 ring-red-500/50' : ''}`}
                >
                  <span className="text-xs font-bold">#{p.id}</span>
                  <span className="text-[9px] uppercase mt-1">{p.txStatus}</span>

                  {p.txStatus === 'sent' && (
                    <button
                      onClick={() => handleDropPacket(p.id)}
                      title="Simulate Drop"
                      className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-red-600 text-white rounded-full text-[9px] flex items-center justify-center cursor-pointer shadow-xs"
                    >
                      x
                    </button>
                  )}

                  {p.txStatus === 'lost' && (
                    <button
                      onClick={() => handleRetransmitOnly(p.id)}
                      title="Retransmit Lost Frame"
                      className="mt-1 text-[8px] bg-red-700 text-white px-1.5 py-0.5 rounded cursor-pointer"
                    >
                      Resend
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Receiver Window */}
        <div className="border border-zinc-200 rounded-xl p-5 bg-zinc-50">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider">
              Receiver Window (Base: #{rxBase})
            </span>
            <span className="text-xs text-zinc-500">
              Accepting: [{rxBase} .. {Math.min(rxBase + WINDOW - 1, TOTAL - 1)}]
            </span>
          </div>

          <div className="grid grid-cols-5 gap-2 p-3 bg-white border border-zinc-200 rounded-xl">
            {packets.map((p) => {
              const inRxWindow = p.id >= rxBase && p.id < rxBase + WINDOW;
              return (
                <div
                  key={p.id}
                  className={`flex flex-col items-center justify-center p-3 rounded-lg border font-mono transition-all ${
                    p.rxStatus === 'delivered'
                      ? 'bg-emerald-50 border-emerald-400 text-emerald-900'
                      : p.rxStatus === 'buffered'
                      ? 'bg-amber-100 border-amber-500 text-amber-900 ring-2 ring-amber-400'
                      : inRxWindow
                      ? 'bg-zinc-100 border-zinc-400 text-zinc-800'
                      : 'bg-zinc-50 border-zinc-200 text-zinc-400 opacity-60'
                  } ${inRxWindow ? 'ring-2 ring-emerald-500/50' : ''}`}
                >
                  <span className="text-xs font-bold">#{p.id}</span>
                  <span className="text-[9px] uppercase mt-1">
                    {p.rxStatus === 'buffered' ? 'Buffered' : p.rxStatus === 'delivered' ? 'Delivered' : 'Waiting'}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Send Actions */}
      <div className="flex flex-wrap items-center gap-3 p-4 bg-zinc-50 border border-zinc-200 rounded-xl mb-6">
        <span className="text-xs font-bold text-zinc-700 uppercase tracking-wider">
          Transmit In-Window Frames:
        </span>
        <div className="flex flex-wrap gap-2">
          {packets.slice(txBase, txBase + WINDOW).map(p => (
            <button
              key={p.id}
              onClick={() => handleSendPacket(p.id)}
              disabled={p.txStatus === 'acked' || p.txStatus === 'sent'}
              className="px-3 py-1.5 bg-red-600 hover:bg-red-700 disabled:opacity-40 text-white font-bold text-xs rounded-lg shadow-sm flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Play className="w-3.5 h-3.5" />
              <span>Send #{p.id}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Protocol Log */}
      <div className="border border-zinc-200 rounded-xl p-4 bg-zinc-50">
        <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider block mb-2">
          Selective Repeat Log Console:
        </span>
        <div className="bg-white border border-zinc-200 rounded-lg p-3 max-h-36 overflow-y-auto font-mono text-xs text-zinc-800 space-y-1">
          {logs.map((m, i) => (
            <div key={i} className="border-b border-zinc-100 pb-0.5">{m}</div>
          ))}
        </div>
      </div>
    </div>
  );
};
