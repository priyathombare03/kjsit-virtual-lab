import React, { useState } from 'react';
import { Play, RotateCcw, AlertOctagon, CheckCircle2, Clock, ArrowRight, ShieldAlert } from 'lucide-react';

interface EventLog {
  id: number;
  time: string;
  sender: string;
  receiver: string;
  status: 'sent' | 'ack' | 'dropped' | 'timeout' | 'dup';
  message: string;
}

export const StopAndWaitSimulator: React.FC = () => {
  const [currentFrame, setCurrentFrame] = useState(0);
  const [senderSeq, setSenderSeq] = useState(0);
  const [receiverExp, setReceiverExp] = useState(0);
  const [inFlight, setInFlight] = useState<'frame' | 'ack' | null>(null);
  const [channelCondition, setChannelCondition] = useState<'normal' | 'drop_frame' | 'drop_ack'>('normal');
  const [logs, setLogs] = useState<EventLog[]>([
    { id: 1, time: '0.00s', sender: 'Sender Ready (Seq: 0)', receiver: 'Receiver Ready (Exp: 0)', status: 'sent', message: 'Channel initialized in idle state.' }
  ]);
  const [timerRunning, setTimerRunning] = useState(false);

  const handleSendFrame = () => {
    if (inFlight) return;
    const frameNum = currentFrame + 1;
    setInFlight('frame');
    setTimerRunning(true);

    setLogs(prev => [
      ...prev,
      {
        id: Date.now(),
        time: `${(prev.length * 0.5).toFixed(1)}s`,
        sender: `Transmitting Frame #${frameNum} [Seq: ${senderSeq}]`,
        receiver: 'Listening on wire...',
        status: 'sent',
        message: `Sender started Retransmission Timer (2.0s). Frame in flight.`
      }
    ]);

    setTimeout(() => {
      if (channelCondition === 'drop_frame') {
        setInFlight(null);
        setLogs(prev => [
          ...prev,
          {
            id: Date.now() + 1,
            time: `${(prev.length * 0.5).toFixed(1)}s`,
            sender: `Timer ticking for Frame #${frameNum}...`,
            receiver: 'No frame detected (Noise/Drop)',
            status: 'dropped',
            message: `*** PACKET LOSS *** Frame #${frameNum} was dropped by channel.`
          }
        ]);
        setChannelCondition('normal');
      } else {
        // Frame reaches receiver
        setInFlight('ack');
        const isExpected = senderSeq === receiverExp;
        if (isExpected) {
          const nextExp = 1 - receiverExp;
          setReceiverExp(nextExp);
          setLogs(prev => [
            ...prev,
            {
              id: Date.now() + 2,
              time: `${(prev.length * 0.5).toFixed(1)}s`,
              sender: `Timer active`,
              receiver: `Frame #${frameNum} (Seq: ${senderSeq}) Accepted! Sending ACK [Seq: ${nextExp}]`,
              status: 'ack',
              message: `Receiver delivered Frame #${frameNum} to Network Layer.`
            }
          ]);
        } else {
          setLogs(prev => [
            ...prev,
            {
              id: Date.now() + 2,
              time: `${(prev.length * 0.5).toFixed(1)}s`,
              sender: `Timer active`,
              receiver: `Duplicate Frame (Seq: ${senderSeq})! Discarding. Resending ACK [Seq: ${receiverExp}]`,
              status: 'dup',
              message: `Duplicate frame discarded.`
            }
          ]);
        }

        setTimeout(() => {
          if (channelCondition === 'drop_ack') {
            setInFlight(null);
            setLogs(prev => [
              ...prev,
              {
                id: Date.now() + 3,
                time: `${(prev.length * 0.5).toFixed(1)}s`,
                sender: `Waiting for ACK...`,
                receiver: `ACK lost on return path!`,
                status: 'dropped',
                message: `*** ACK LOSS *** ACK frame was dropped before reaching sender.`
              }
            ]);
            setChannelCondition('normal');
          } else {
            setInFlight(null);
            setTimerRunning(false);
            setSenderSeq(1 - senderSeq);
            setCurrentFrame(prev => prev + 1);
            setLogs(prev => [
              ...prev,
              {
                id: Date.now() + 4,
                time: `${(prev.length * 0.5).toFixed(1)}s`,
                sender: `ACK received! Stopped Timer. Sequence advanced to ${1 - senderSeq}`,
                receiver: `Ready for next frame`,
                status: 'ack',
                message: `Frame transaction completed successfully.`
              }
            ]);
          }
        }, 1200);
      }
    }, 1200);
  };

  const handleTriggerTimeout = () => {
    setInFlight(null);
    setTimerRunning(false);
    setLogs(prev => [
      ...prev,
      {
        id: Date.now(),
        time: `${(prev.length * 0.5).toFixed(1)}s`,
        sender: `*** SENDER TIMEOUT (2.0s expired) *** Retransmitting Frame #${currentFrame + 1} [Seq: ${senderSeq}]`,
        receiver: `Awaiting frame`,
        status: 'timeout',
        message: `Timeout event triggered retransmission of the unacknowledged frame.`
      }
    ]);
  };

  const handleReset = () => {
    setCurrentFrame(0);
    setSenderSeq(0);
    setReceiverExp(0);
    setInFlight(null);
    setTimerRunning(false);
    setChannelCondition('normal');
    setLogs([
      { id: 1, time: '0.00s', sender: 'Sender Ready (Seq: 0)', receiver: 'Receiver Ready (Exp: 0)', status: 'sent', message: 'Simulator reset to initial state.' }
    ]);
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-xl p-6 shadow-sm">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-zinc-200">
        <div>
          <h3 className="text-lg font-bold text-zinc-900 flex items-center gap-2">
            <Clock className="w-5 h-5 text-red-600" />
            <span>Stop-and-Wait ARQ Protocol Simulator</span>
          </h3>
          <p className="text-xs text-zinc-500 mt-0.5">
            Alternating 1-bit sequence numbers, transmission timers, and channel packet loss injection
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleReset}
            className="px-3 py-1.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        </div>
      </div>

      {/* Visual Transmission Pipe */}
      <div className="bg-zinc-950 text-white rounded-xl p-6 mb-6 shadow-inner relative overflow-hidden">
        <div className="grid grid-cols-3 items-center gap-4 text-center">
          {/* Sender Node */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 flex flex-col items-center">
            <div className="w-12 h-12 rounded-full bg-red-600/20 border border-red-500 flex items-center justify-center mb-2">
              <span className="font-mono font-bold text-red-400">TX</span>
            </div>
            <span className="text-sm font-bold text-white">Sender Station</span>
            <span className="text-xs text-zinc-400 mt-1">
              Current Seq: <strong className="text-red-400 font-mono">{senderSeq}</strong>
            </span>
            <div className="mt-2 flex items-center gap-1 text-[11px] text-zinc-400">
              <Clock className={`w-3 h-3 ${timerRunning ? 'text-amber-400 animate-spin' : 'text-zinc-600'}`} />
              <span>Timer: {timerRunning ? 'Active (2.0s)' : 'Idle'}</span>
            </div>
          </div>

          {/* Channel / Pipe */}
          <div className="flex flex-col items-center justify-center px-4 relative">
            <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-2">
              Physical Medium (Duplex Wire)
            </span>
            <div className="w-full h-1 bg-zinc-800 rounded-full relative my-4">
              {inFlight === 'frame' && (
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 px-3 py-1 bg-red-600 text-white text-xs font-mono font-bold rounded-full animate-pulse shadow-lg flex items-center gap-1">
                  <span>Frame #{currentFrame + 1} [Seq: {senderSeq}]</span>
                  <ArrowRight className="w-3 h-3" />
                </div>
              )}
              {inFlight === 'ack' && (
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 px-3 py-1 bg-emerald-600 text-white text-xs font-mono font-bold rounded-full animate-pulse shadow-lg flex items-center gap-1">
                  <span>ACK [Seq: {receiverExp}]</span>
                </div>
              )}
            </div>
            <span className="text-[11px] text-zinc-500">
              {inFlight === 'frame' ? 'Frame in transit ->' : inFlight === 'ack' ? '<- ACK in transit' : 'Channel Idle'}
            </span>
          </div>

          {/* Receiver Node */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 flex flex-col items-center">
            <div className="w-12 h-12 rounded-full bg-emerald-600/20 border border-emerald-500 flex items-center justify-center mb-2">
              <span className="font-mono font-bold text-emerald-400">RX</span>
            </div>
            <span className="text-sm font-bold text-white">Receiver Station</span>
            <span className="text-xs text-zinc-400 mt-1">
              Expected Seq: <strong className="text-emerald-400 font-mono">{receiverExp}</strong>
            </span>
            <span className="text-[11px] text-zinc-400 mt-2">
              Frames Delivered: <strong className="text-white">{currentFrame}</strong>
            </span>
          </div>
        </div>
      </div>

      {/* Control Panel */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-4">
          <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider block mb-3">
            Simulation Actions:
          </span>
          <div className="flex flex-wrap gap-3">
            <button
              onClick={handleSendFrame}
              disabled={inFlight !== null}
              className="px-5 py-2.5 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white font-bold text-xs rounded-lg shadow-sm flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Play className="w-4 h-4" />
              <span>Send Frame #{currentFrame + 1}</span>
            </button>
            <button
              onClick={handleTriggerTimeout}
              disabled={!timerRunning}
              className="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 disabled:opacity-40 text-white font-bold text-xs rounded-lg shadow-sm flex items-center gap-2 transition-colors cursor-pointer"
            >
              <AlertOctagon className="w-4 h-4" />
              <span>Force Timeout</span>
            </button>
          </div>
        </div>

        <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-4">
          <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider block mb-3">
            Channel Error Injection:
          </span>
          <div className="flex gap-2">
            <button
              onClick={() => setChannelCondition('normal')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition-colors cursor-pointer ${
                channelCondition === 'normal' ? 'bg-zinc-900 text-white border-zinc-900' : 'bg-white text-zinc-700 border-zinc-300'
              }`}
            >
              Normal Wire
            </button>
            <button
              onClick={() => setChannelCondition('drop_frame')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition-colors cursor-pointer ${
                channelCondition === 'drop_frame' ? 'bg-red-600 text-white border-red-600' : 'bg-white text-red-700 border-red-300'
              }`}
            >
              Drop Next Frame
            </button>
            <button
              onClick={() => setChannelCondition('drop_ack')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition-colors cursor-pointer ${
                channelCondition === 'drop_ack' ? 'bg-amber-600 text-white border-amber-600' : 'bg-white text-amber-700 border-amber-300'
              }`}
            >
              Drop Next ACK
            </button>
          </div>
        </div>
      </div>

      {/* Protocol Event Logs */}
      <div className="border border-zinc-200 rounded-xl p-4 bg-zinc-50">
        <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider block mb-2">
          Protocol Transmission Log:
        </span>
        <div className="bg-white border border-zinc-200 rounded-lg p-3 max-h-48 overflow-y-auto font-mono text-xs space-y-1.5">
          {logs.slice().reverse().map((log) => (
            <div key={log.id} className="flex items-start gap-2 border-b border-zinc-100 pb-1">
              <span className="text-zinc-400 shrink-0">{log.time}</span>
              <span
                className={`font-semibold shrink-0 ${
                  log.status === 'sent'
                    ? 'text-blue-600'
                    : log.status === 'ack'
                    ? 'text-emerald-600'
                    : log.status === 'dropped'
                    ? 'text-red-600'
                    : 'text-amber-600'
                }`}
              >
                [{log.status.toUpperCase()}]
              </span>
              <span className="text-zinc-800">{log.message}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
