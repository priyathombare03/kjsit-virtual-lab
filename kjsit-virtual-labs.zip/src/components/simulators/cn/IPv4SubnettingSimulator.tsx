import React, { useState } from 'react';
import { Binary, Calculator, CheckCircle2, Layers, Cpu, Hash } from 'lucide-react';

export const IPv4SubnettingSimulator: React.FC = () => {
  const [ipAddress, setIpAddress] = useState('192.168.10.65');
  const [cidr, setCidr] = useState(26);
  const [numSubnetsReq, setNumSubnetsReq] = useState(4);

  // Helper to parse IP
  const parseIP = (ip: string): number[] => {
    return ip.split('.').map(x => parseInt(x, 10) || 0);
  };

  const toBinaryString = (octets: number[]): string => {
    return octets.map(o => o.toString(2).padStart(8, '0')).join('.');
  };

  const getSubnetMaskOctets = (prefix: number): number[] => {
    const mask = [];
    for (let i = 0; i < 4; i++) {
      const bitsInOctet = Math.max(0, Math.min(8, prefix - i * 8));
      mask.push(bitsInOctet === 0 ? 0 : 256 - Math.pow(2, 8 - bitsInOctet));
    }
    return mask;
  };

  const octets = parseIP(ipAddress);
  const maskOctets = getSubnetMaskOctets(cidr);
  const netOctets = octets.map((o, i) => o & maskOctets[i]);
  const hostBits = 32 - cidr;
  const totalHosts = Math.pow(2, hostBits);
  const usableHosts = hostBits > 1 ? totalHosts - 2 : 0;

  // Broadcast
  const bcastOctets = netOctets.map((o, i) => o | (~maskOctets[i] & 255));
  
  // First and Last usable host
  const firstHost = [...netOctets];
  if (usableHosts > 0) firstHost[3] += 1;
  const lastHost = [...bcastOctets];
  if (usableHosts > 0) lastHost[3] -= 1;

  // Binary representation breakdown
  const binaryIpStr = octets.map(o => o.toString(2).padStart(8, '0')).join('');
  const netBitsStr = binaryIpStr.slice(0, cidr);
  const hostBitsStr = binaryIpStr.slice(cidr);

  return (
    <div className="bg-white border border-zinc-200 rounded-xl p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-zinc-200">
        <div>
          <h3 className="text-lg font-bold text-zinc-900 flex items-center gap-2">
            <Calculator className="w-5 h-5 text-red-600" />
            <span>IPv4 Subnetting & CIDR Address Calculator</span>
          </h3>
          <p className="text-xs text-zinc-500 mt-0.5">
            Bitwise network/host partitioning, subnet masking, broadcast address, and host capacity
          </p>
        </div>
      </div>

      {/* Input Form */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-4">
          <label className="block text-xs font-bold text-zinc-700 uppercase tracking-wider mb-2">
            IPv4 Host Address
          </label>
          <input
            type="text"
            value={ipAddress}
            onChange={(e) => setIpAddress(e.target.value)}
            className="w-full px-3 py-2 border border-zinc-300 rounded-lg text-sm font-mono focus:outline-hidden focus:border-red-600"
            placeholder="192.168.1.1"
          />
          <div className="flex gap-2 mt-2">
            <button
              onClick={() => { setIpAddress('192.168.10.65'); setCidr(26); }}
              className="text-[11px] font-semibold text-zinc-600 bg-white border border-zinc-200 px-2 py-0.5 rounded hover:bg-zinc-100 cursor-pointer"
            >
              Class C (/26)
            </button>
            <button
              onClick={() => { setIpAddress('172.16.50.100'); setCidr(22); }}
              className="text-[11px] font-semibold text-zinc-600 bg-white border border-zinc-200 px-2 py-0.5 rounded hover:bg-zinc-100 cursor-pointer"
            >
              Class B (/22)
            </button>
            <button
              onClick={() => { setIpAddress('10.20.30.40'); setCidr(16); }}
              className="text-[11px] font-semibold text-zinc-600 bg-white border border-zinc-200 px-2 py-0.5 rounded hover:bg-zinc-100 cursor-pointer"
            >
              Class A (/16)
            </button>
          </div>
        </div>

        <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-4">
          <label className="block text-xs font-bold text-zinc-700 uppercase tracking-wider mb-2">
            CIDR Prefix Length: /{cidr} (Subnet Mask: {maskOctets.join('.')})
          </label>
          <input
            type="range"
            min={8}
            max={30}
            value={cidr}
            onChange={(e) => setCidr(parseInt(e.target.value))}
            className="w-full accent-red-600 cursor-pointer"
          />
          <div className="flex justify-between text-[11px] text-zinc-500 font-mono mt-1">
            <span>/8 (Class A)</span>
            <span>/16 (Class B)</span>
            <span>/24 (Class C)</span>
            <span>/30 (P2P Link)</span>
          </div>
        </div>
      </div>

      {/* Bitwise Visual Representation */}
      <div className="border border-zinc-200 rounded-xl p-5 bg-zinc-50 mb-6">
        <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider block mb-3">
          32-Bit Binary Allocation Breakdown:
        </span>

        <div className="p-4 bg-zinc-950 text-white rounded-xl font-mono text-sm overflow-x-auto">
          <div className="flex flex-wrap items-center gap-1">
            <span className="text-emerald-400 font-bold">
              {netBitsStr.match(/.{1,8}/g)?.join(' ') || netBitsStr}
            </span>
            <span className="text-red-400 font-bold">
              {hostBitsStr}
            </span>
          </div>
          <div className="flex items-center gap-4 mt-2 text-xs text-zinc-400">
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 bg-emerald-500 rounded-xs"></span>
              Network ID Bits ({cidr} bits)
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 bg-red-500 rounded-xs"></span>
              Host ID Bits ({hostBits} bits)
            </span>
          </div>
        </div>
      </div>

      {/* Calculated Parameters Table */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="p-4 bg-zinc-50 border border-zinc-200 rounded-xl">
          <span className="text-[11px] font-bold text-zinc-500 uppercase">Network Address (Subnet ID)</span>
          <span className="text-base font-mono font-bold text-zinc-900 block mt-1">
            {netOctets.join('.')}
          </span>
          <span className="text-[10px] text-zinc-400 font-mono mt-0.5 block">
            {toBinaryString(netOctets)}
          </span>
        </div>

        <div className="p-4 bg-zinc-50 border border-zinc-200 rounded-xl">
          <span className="text-[11px] font-bold text-zinc-500 uppercase">Subnet Mask (Dotted Decimal)</span>
          <span className="text-base font-mono font-bold text-zinc-900 block mt-1">
            {maskOctets.join('.')}
          </span>
          <span className="text-[10px] text-zinc-400 font-mono mt-0.5 block">
            {toBinaryString(maskOctets)}
          </span>
        </div>

        <div className="p-4 bg-zinc-50 border border-zinc-200 rounded-xl">
          <span className="text-[11px] font-bold text-zinc-500 uppercase">Directed Broadcast Address</span>
          <span className="text-base font-mono font-bold text-zinc-900 block mt-1">
            {bcastOctets.join('.')}
          </span>
          <span className="text-[10px] text-zinc-400 font-mono mt-0.5 block">
            {toBinaryString(bcastOctets)}
          </span>
        </div>

        <div className="p-4 bg-zinc-50 border border-zinc-200 rounded-xl">
          <span className="text-[11px] font-bold text-zinc-500 uppercase">Usable Host Range & Total</span>
          <span className="text-sm font-mono font-bold text-red-600 block mt-1">
            {firstHost.join('.')} - {lastHost.join('.')}
          </span>
          <span className="text-xs text-zinc-600 font-semibold mt-0.5 block">
            {usableHosts.toLocaleString()} Usable (2^{hostBits} - 2)
          </span>
        </div>
      </div>
    </div>
  );
};
