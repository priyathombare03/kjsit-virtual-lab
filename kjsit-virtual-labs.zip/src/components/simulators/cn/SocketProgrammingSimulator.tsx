import React, { useState } from 'react';
import { Terminal, Play, RotateCcw, Send, CheckCircle2, Shield, RefreshCw } from 'lucide-react';

interface ConsoleMessage {
  id: number;
  time: string;
  source: 'client' | 'server' | 'system';
  text: string;
  flag?: string;
}

export const SocketProgrammingSimulator: React.FC = () => {
  const [protocol, setProtocol] = useState<'tcp' | 'udp'>('tcp');
  const [handshakeStep, setHandshakeStep] = useState<number>(0); // 0: None, 1: SYN, 2: SYN-ACK, 3: ESTABLISHED, 4: CLOSED
  const [clientInput, setClientInput] = useState('');
  const [logs, setLogs] = useState<ConsoleMessage[]>([
    { id: 1, time: '00:00.1', source: 'server', text: 'Server socket() -> bind(0.0.0.0, 8080) -> listen(BACKLOG=5)' },
    { id: 2, time: '00:00.2', source: 'server', text: 'Server blocked on accept(). Awaiting client connections...' }
  ]);

  const addLog = (source: 'client' | 'server' | 'system', text: string, flag?: string) => {
    const time = new Date().toISOString().substring(14, 21);
    setLogs(prev => [...prev, { id: Date.now() + Math.random(), time, source, text, flag }]);
  };

  const handleStartTCPHandshake = () => {
    if (handshakeStep > 0) return;

    // Step 1: SYN
    setHandshakeStep(1);
    addLog('client', 'Client connect(127.0.0.1, 8080) invoked. Sending [SYN] Seq=1000, MSS=1460', 'SYN');

    setTimeout(() => {
      // Step 2: SYN-ACK
      setHandshakeStep(2);
      addLog('server', 'Server received [SYN]. Allocating TCB buffer. Responding [SYN, ACK] Seq=5000, Ack=1001', 'SYN-ACK');

      setTimeout(() => {
        // Step 3: ACK
        setHandshakeStep(3);
        addLog('client', 'Client received [SYN, ACK]. Sending final [ACK] Seq=1001, Ack=5001. TCP Handshake Complete!', 'ACK');
        addLog('system', 'Connection Established. Socket FD 4 opened for read/write.');
      }, 900);
    }, 900);
  };

  const handleSendMessage = () => {
    if (!clientInput.trim()) return;
    const msg = clientInput;
    setClientInput('');

    if (protocol === 'tcp' && handshakeStep !== 3) {
      addLog('client', 'Error: Cannot send data before TCP 3-Way Handshake completes!', 'ERR');
      return;
    }

    if (protocol === 'tcp') {
      addLog('client', `write(sock_fd, "${msg}", ${msg.length}) -> [PSH, ACK] Payload: "${msg}"`);
      setTimeout(() => {
        addLog('server', `read() unblocked. Received: "${msg}". Echoing back reversed payload: "${msg.split('').reverse().join('')}"`);
      }, 600);
    } else {
      addLog('client', `sendto(sockfd, "${msg}", dest_addr: 8080) [UDP Datagram - No Connection Overhead]`);
      setTimeout(() => {
        addLog('server', `recvfrom(sockfd) unblocked. Received UDP Datagram: "${msg}"`);
      }, 500);
    }
  };

  const handleCloseConnection = () => {
    if (protocol !== 'tcp' || handshakeStep !== 3) return;
    setHandshakeStep(4);
    addLog('client', 'Client close() -> Sending [FIN, ACK] Seq=1050, Ack=5020', 'FIN');
    setTimeout(() => {
      addLog('server', 'Server received [FIN]. Sending [ACK] Ack=1051. Server enter CLOSE_WAIT.', 'ACK');
      setTimeout(() => {
        addLog('server', 'Server close() -> Sending [FIN, ACK] Seq=5020, Ack=1051. Server LAST_ACK.', 'FIN');
        setTimeout(() => {
          addLog('client', 'Client enters TIME_WAIT (2MSL timer). Connection Terminated cleanly.', 'CLOSED');
        }, 700);
      }, 700);
    }, 700);
  };

  const handleReset = () => {
    setHandshakeStep(0);
    setLogs([
      { id: 1, time: '00:00.1', source: 'server', text: `Server socket(${protocol.toUpperCase()}) -> bind(0.0.0.0:8080)` },
      { id: 2, time: '00:00.2', source: 'server', text: 'Server awaiting packets...' }
    ]);
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-xl p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-zinc-200">
        <div>
          <h3 className="text-lg font-bold text-zinc-900 flex items-center gap-2">
            <Terminal className="w-5 h-5 text-red-600" />
            <span>Socket Programming & 3-Way Handshake Simulator</span>
          </h3>
          <p className="text-xs text-zinc-500 mt-0.5">
            Berkeley Socket API (socket, bind, listen, accept, connect, send, recv) & TCP State Machine
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="bg-zinc-100 p-1 rounded-lg flex">
            <button
              onClick={() => { setProtocol('tcp'); handleReset(); }}
              className={`px-3 py-1 text-xs font-bold rounded-md transition-colors cursor-pointer ${
                protocol === 'tcp' ? 'bg-red-600 text-white shadow-xs' : 'text-zinc-600'
              }`}
            >
              TCP Stream (SOCK_STREAM)
            </button>
            <button
              onClick={() => { setProtocol('udp'); handleReset(); }}
              className={`px-3 py-1 text-xs font-bold rounded-md transition-colors cursor-pointer ${
                protocol === 'udp' ? 'bg-red-600 text-white shadow-xs' : 'text-zinc-600'
              }`}
            >
              UDP Datagram (SOCK_DGRAM)
            </button>
          </div>
          <button
            onClick={handleReset}
            className="p-1.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 rounded-lg cursor-pointer"
            title="Reset"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Protocol Diagram / State */}
      {protocol === 'tcp' && (
        <div className="border border-zinc-200 rounded-xl p-5 bg-zinc-50 mb-6">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider">
              TCP 3-Way Handshake Connection State:
            </span>
            <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
              handshakeStep === 3
                ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                : handshakeStep === 4
                ? 'bg-zinc-200 text-zinc-700'
                : 'bg-amber-100 text-amber-800 border border-amber-300'
            }`}>
              {handshakeStep === 0 ? 'SYN_SENT / IDLE' : handshakeStep === 1 ? 'SYN IN FLIGHT' : handshakeStep === 2 ? 'SYN_RCVD' : handshakeStep === 3 ? 'ESTABLISHED' : 'CLOSED'}
            </span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 py-2">
            <button
              onClick={handleStartTCPHandshake}
              disabled={handshakeStep > 0}
              className="px-4 py-2 bg-red-600 hover:bg-red-700 disabled:opacity-40 text-white font-bold text-xs rounded-lg shadow-sm flex items-center gap-2 cursor-pointer"
            >
              <Play className="w-4 h-4" />
              <span>Initiate 3-Way Handshake (SYN)</span>
            </button>
            <button
              onClick={handleCloseConnection}
              disabled={handshakeStep !== 3}
              className="px-4 py-2 bg-zinc-800 hover:bg-black disabled:opacity-30 text-white font-bold text-xs rounded-lg shadow-sm flex items-center gap-2 cursor-pointer"
            >
              <span>Graceful 4-Way Teardown (FIN)</span>
            </button>
          </div>
        </div>
      )}

      {/* Dual Terminal Layout */}
      <div className="border border-zinc-900 rounded-xl bg-zinc-950 text-zinc-100 p-4 font-mono text-xs mb-6 shadow-inner">
        <div className="flex items-center justify-between pb-2 mb-3 border-b border-zinc-800 text-zinc-400">
          <span className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
            <span className="ml-2 font-bold text-white">Socket I/O Stream Terminal (Port 8080)</span>
          </span>
          <span className="text-[11px] text-zinc-500">{protocol.toUpperCase()} PROTOCOL</span>
        </div>

        <div className="space-y-1.5 max-h-56 overflow-y-auto pr-2">
          {logs.map((log) => (
            <div key={log.id} className="flex items-start gap-2 leading-relaxed">
              <span className="text-zinc-600 shrink-0">{log.time}</span>
              <span
                className={`font-bold shrink-0 ${
                  log.source === 'client'
                    ? 'text-cyan-400'
                    : log.source === 'server'
                    ? 'text-emerald-400'
                    : 'text-amber-400'
                }`}
              >
                [{log.source.toUpperCase()}]
              </span>
              <span className="text-zinc-200">{log.text}</span>
            </div>
          ))}
        </div>

        {/* Message Input Box */}
        <div className="mt-4 pt-3 border-t border-zinc-800 flex gap-2">
          <input
            type="text"
            value={clientInput}
            onChange={(e) => setClientInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Type application payload message (e.g. 'GET / HTTP/1.1' or 'Hello KJSIT')..."
            className="flex-1 px-3 py-1.5 bg-zinc-900 border border-zinc-700 rounded text-xs text-white focus:outline-hidden focus:border-red-500"
          />
          <button
            onClick={handleSendMessage}
            className="px-4 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded flex items-center gap-1.5 cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Send</span>
          </button>
        </div>
      </div>
    </div>
  );
};
