import React, { useState } from 'react';
import { Play, RotateCcw, FastForward, AlertTriangle, Layers, CheckCircle2, ArrowRight } from 'lucide-react';

interface FrameState {
  id: number;
  status: 'unsent' | 'in_flight' | 'acked' | 'lost' | 'discarded';
}

export const GoBackNSimulator: React.FC = () => {
  const TOTAL_FRAMES = 12;
  const WINDOW_SIZE = 4;

  const [base, setBase] = useState(0); // Sf
  const [nextSeqNum, setNextSeqNum] = useState(0); // Sn
  const [frames, setFrames] = useState<FrameState[]>(
    Array.from({ length: TOTAL_FRAMES }, (_, i) => ({ id: i, status: 'unsent' }))
  );
  const [rxExpected, setRxExpected] = useState(0); // Rn
  const [logMessages, setLogMessages] = useState<string[]>([
    'Go-Back-N initialized with Sender Window Size N = 4.'
  ]);

  const addLog = (msg: string) => {
    setLogMessages(prev => [msg, ...prev.slice(0, 15)]);
  };

  const handleSendNext = () => {
    if (nextSeqNum >= base + WINDOW_SIZE || nextSeqNum >= TOTAL_FRAMES) {
      addLog(`[SENDER] Cannot send. Window full [${base} .. ${Math.min(base + WINDOW_SIZE - 1, TOTAL_FRAMES - 1)}].`);
      return;
    }

    const frameId = nextSeqNum;
    setFrames(prev => prev.map(f => f.id === frameId ? { ...f, status: 'in_flight' } : f));
    setNextSeqNum(prev => prev + 1);
    addLog(`[SENDER] Transmitted Frame ${frameId}. Window: [${base} .. ${base + WINDOW_SIZE - 1}]`);

    // Simulate arrival
    setTimeout(() => {
      if (frameId === rxExpected) {
        setRxExpected(prev => prev + 1);
        setBase(prev => prev + 1);
        setFrames(prev => prev.map(f => f.id === frameId ? { ...f, status: 'acked' } : f));
        addLog(`[RECEIVER] Received in-order Frame ${frameId}! Sent Cumulative ACK ${frameId + 1}. Window slides.`);
      } else {
        setFrames(prev => prev.map(f => f.id === frameId ? { ...f, status: 'discarded' } : f));
        addLog(`[RECEIVER] Out-of-order Frame ${frameId} arrived (Expected ${rxExpected}). DISCARDED! Resent ACK ${rxExpected}.`);
      }
    }, 800);
  };

  const handleDropFrame = (frameId: number) => {
    setFrames(prev => prev.map(f => f.id === frameId ? { ...f, status: 'lost' } : f));
    addLog(`*** PACKET LOSS *** Frame ${frameId} was dropped in the transmission pipe.`);
  };

  const handleTimeoutRetransmit = () => {
    addLog(`*** SENDER TIMEOUT on Frame ${base} *** Executing GO-BACK-N retransmission from Frame ${base} to ${nextSeqNum - 1}!`);
    setNextSeqNum(base);
    setFrames(prev => prev.map(f => (f.id >= base && f.id < nextSeqNum) ? { ...f, status: 'unsent' } : f));
  };

  const handleReset = () => {
    setBase(0);
    setNextSeqNum(0);
    setRxExpected(0);
    setFrames(Array.from({ length: TOTAL_FRAMES }, (_, i) => ({ id: i, status: 'unsent' })));
    setLogMessages(['Go-Back-N simulator reset to initial state.']);
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-xl p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-zinc-200">
        <div>
          <h3 className="text-lg font-bold text-zinc-900 flex items-center gap-2">
            <Layers className="w-5 h-5 text-red-600" />
            <span>Sliding Window: Go-Back-N (GBN) Protocol Simulator</span>
          </h3>
          <p className="text-xs text-zinc-500 mt-0.5">
            Pipelining transmission with sender window [Sf .. Sn-1] and cumulative acknowledgments
          </p>
        </div>
        <button
          onClick={handleReset}
          className="px-3 py-1.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset</span>
        </button>
      </div>

      {/* Sliding Window Visualizer */}
      <div className="border border-zinc-200 rounded-xl p-5 bg-zinc-50 mb-6">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider">
            Sender Window & Packet Sequence Space (N = {WINDOW_SIZE}):
          </span>
          <span className="text-xs font-mono text-zinc-600">
            Window Base (Sf): <strong className="text-red-600">{base}</strong> | Next Seq (Sn): <strong className="text-blue-600">{nextSeqNum}</strong>
          </span>
        </div>

        <div className="grid grid-cols-6 sm:grid-cols-12 gap-2 p-3 bg-white border border-zinc-200 rounded-xl">
          {frames.map((f) => {
            const inWindow = f.id >= base && f.id < base + WINDOW_SIZE;
            return (
              <div
                key={f.id}
                className={`relative flex flex-col items-center justify-center p-3 rounded-lg border font-mono transition-all ${
                  f.status === 'acked'
                    ? 'bg-emerald-50 border-emerald-400 text-emerald-900'
                    : f.status === 'in_flight'
                    ? 'bg-blue-50 border-blue-400 text-blue-900 animate-pulse'
                    : f.status === 'lost'
                    ? 'bg-red-100 border-red-500 text-red-900'
                    : f.status === 'discarded'
                    ? 'bg-amber-50 border-amber-400 text-amber-900'
                    : inWindow
                    ? 'bg-zinc-100 border-zinc-400 text-zinc-800'
                    : 'bg-zinc-50 border-zinc-200 text-zinc-400 opacity-60'
                } ${inWindow ? 'ring-2 ring-red-500/50' : ''}`}
              >
                <span className="text-xs font-bold">#{f.id}</span>
                <span className="text-[9px] uppercase mt-1 tracking-tighter">
                  {f.status === 'in_flight' ? 'Flight' : f.status}
                </span>

                {f.status === 'in_flight' && (
                  <button
                    onClick={() => handleDropFrame(f.id)}
                    title="Simulate Drop"
                    className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-red-600 hover:bg-red-700 text-white rounded-full text-[9px] flex items-center justify-center cursor-pointer shadow-xs"
                  >
                    x
                  </button>
                )}
              </div>
            );
          })}
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center justify-between gap-3 mt-4 text-xs text-zinc-600">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 bg-emerald-100 border border-emerald-400 rounded-xs"></span> ACKed
            </span>
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 bg-blue-100 border border-blue-400 rounded-xs"></span> In-Flight
            </span>
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 bg-red-100 border border-red-400 rounded-xs"></span> Dropped
            </span>
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 bg-amber-100 border border-amber-400 rounded-xs"></span> Discarded by RX
            </span>
          </div>

          <span className="text-zinc-500">
            Receiver Expected Seq (Rn): <strong className="text-emerald-700 font-mono">#{rxExpected}</strong>
          </span>
        </div>
      </div>

      {/* Action Controls */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-4 flex gap-3 items-center">
          <button
            onClick={handleSendNext}
            disabled={nextSeqNum >= base + WINDOW_SIZE || nextSeqNum >= TOTAL_FRAMES}
            className="px-5 py-2.5 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white font-bold text-xs rounded-lg shadow-sm flex items-center gap-2 transition-colors cursor-pointer"
          >
            <Play className="w-4 h-4" />
            <span>Send Next Frame (#{nextSeqNum})</span>
          </button>
          <span className="text-xs text-zinc-500">
            {nextSeqNum < base + WINDOW_SIZE ? `${base + WINDOW_SIZE - nextSeqNum} slots free in window` : 'Window is full'}
          </span>
        </div>

        <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-4 flex gap-3 items-center">
          <button
            onClick={handleTimeoutRetransmit}
            className="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-lg shadow-sm flex items-center gap-2 transition-colors cursor-pointer"
          >
            <AlertTriangle className="w-4 h-4" />
            <span>Trigger Timeout & Go-Back-N</span>
          </button>
          <span className="text-xs text-zinc-500">
            Retransmits all frames from #{base} to #{Math.max(base, nextSeqNum - 1)}
          </span>
        </div>
      </div>

      {/* Event Console */}
      <div className="border border-zinc-200 rounded-xl p-4 bg-zinc-50">
        <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider block mb-2">
          Protocol Transmission Log:
        </span>
        <div className="bg-white border border-zinc-200 rounded-lg p-3 max-h-40 overflow-y-auto font-mono text-xs text-zinc-800 space-y-1">
          {logMessages.map((msg, idx) => (
            <div key={idx} className="border-b border-zinc-100 pb-0.5">
              {msg}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
