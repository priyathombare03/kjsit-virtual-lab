import React, { useState } from 'react';
import { RefreshCw, Play, AlertTriangle, CheckCircle, Shield, Cpu, ArrowRight } from 'lucide-react';

export const CRCSimulator: React.FC = () => {
  const [dataBits, setDataBits] = useState('11010011101100');
  const [generator, setGenerator] = useState('1011'); // CRC-3 (x^3 + x + 1)
  const [activeTab, setActiveTab] = useState<'crc' | 'hamming'>('crc');
  
  // Transmitted codeword
  const [transmittedCodeword, setTransmittedCodeword] = useState<string>('');
  const [channelBits, setChannelBits] = useState<string[]>([]);
  const [verificationResult, setVerificationResult] = useState<{
    valid: boolean;
    remainder: string;
    steps: string[];
  } | null>(null);

  // Hamming 7,4 state
  const [hammingData, setHammingData] = useState('1011');
  const [hammingEncoded, setHammingEncoded] = useState<string[]>([]);
  const [hammingSyndrome, setHammingSyndrome] = useState<{
    syndromeBits: string;
    errorPos: number;
    correctedBits: string[];
  } | null>(null);

  // Modulo-2 polynomial division
  const performCRC = (data: string, gen: string) => {
    const r = gen.length - 1;
    const dividend = (data + '0'.repeat(r)).split('');
    const genArr = gen.split('');
    const steps: string[] = [];

    steps.push(`Dividend with ${r} appended zeros: ${dividend.join('')}`);
    steps.push(`Divisor Polynomial G(x): ${gen}`);

    for (let i = 0; i <= dividend.length - gen.length; i++) {
      if (dividend[i] === '1') {
        steps.push(`Step ${i + 1}: MSB is 1 -> XOR with ${gen}`);
        for (let j = 0; j < genArr.length; j++) {
          dividend[i + j] = dividend[i + j] === genArr[j] ? '0' : '1';
        }
      }
    }

    const remainder = dividend.slice(-r).join('');
    steps.push(`Final Remainder FCS: ${remainder}`);
    const codeword = data + remainder;
    return { remainder, codeword, steps };
  };

  const handleComputeCRC = () => {
    if (!/^[01]+$/.test(dataBits) || !/^[01]+$/.test(generator) || generator.length < 2) {
      alert('Please enter valid binary strings (0s and 1s only). Generator must be at least 2 bits.');
      return;
    }
    const { remainder, codeword, steps } = performCRC(dataBits, generator);
    setTransmittedCodeword(codeword);
    setChannelBits(codeword.split(''));
    setVerificationResult({
      valid: true,
      remainder,
      steps
    });
  };

  const handleToggleChannelBit = (index: number) => {
    const updated = [...channelBits];
    updated[index] = updated[index] === '1' ? '0' : '1';
    setChannelBits(updated);
  };

  const handleVerifyAtReceiver = () => {
    const receivedStr = channelBits.join('');
    const gen = generator;
    const r = gen.length - 1;
    const dividend = receivedStr.split('');
    const genArr = gen.split('');
    const steps: string[] = [];

    steps.push(`Receiver received: ${receivedStr}`);

    for (let i = 0; i <= dividend.length - gen.length; i++) {
      if (dividend[i] === '1') {
        for (let j = 0; j < genArr.length; j++) {
          dividend[i + j] = dividend[i + j] === genArr[j] ? '0' : '1';
        }
      }
    }

    const remainder = dividend.slice(-r).join('');
    const isValid = remainder.split('').every((b) => b === '0');
    steps.push(`Receiver Division Remainder: ${remainder}`);
    steps.push(isValid ? 'Result: 000... -> FRAME ACCEPTED (NO ERROR)' : `Result: ${remainder} -> ERROR DETECTED (FRAME REJECTED)`);

    setVerificationResult({
      valid: isValid,
      remainder,
      steps
    });
  };

  // Hamming 7,4 Code: data d3 d2 d1 d0 -> 7-bit codeword [p1, p2, d3, p3, d2, d1, d0] at indices [1,2,3,4,5,6,7]
  const handleEncodeHamming = () => {
    if (!/^[01]{4}$/.test(hammingData)) {
      alert('Please enter exactly 4 data bits (e.g. 1011).');
      return;
    }
    const d3 = parseInt(hammingData[0]);
    const d2 = parseInt(hammingData[1]);
    const d1 = parseInt(hammingData[2]);
    const d0 = parseInt(hammingData[3]);

    // Parity bits (Even Parity)
    const p1 = (d3 ^ d2 ^ d0); // positions 1, 3, 5, 7
    const p2 = (d3 ^ d1 ^ d0); // positions 2, 3, 6, 7
    const p3 = (d2 ^ d1 ^ d0); // positions 4, 5, 6, 7

    const codeword = [
      p1.toString(), // pos 1
      p2.toString(), // pos 2
      d3.toString(), // pos 3
      p3.toString(), // pos 4
      d2.toString(), // pos 5
      d1.toString(), // pos 6
      d0.toString()  // pos 7
    ];
    setHammingEncoded(codeword);
    setHammingSyndrome(null);
  };

  const handleToggleHammingBit = (index: number) => {
    const updated = [...hammingEncoded];
    updated[index] = updated[index] === '1' ? '0' : '1';
    setHammingEncoded(updated);
  };

  const handleVerifyHamming = () => {
    if (hammingEncoded.length !== 7) return;
    const b = hammingEncoded.map(x => parseInt(x));
    // 1-indexed: b[0]=p1, b[1]=p2, b[2]=d3, b[3]=p3, b[4]=d2, b[5]=d1, b[6]=d0
    const s1 = b[0] ^ b[2] ^ b[4] ^ b[6]; // checks 1, 3, 5, 7
    const s2 = b[1] ^ b[2] ^ b[5] ^ b[6]; // checks 2, 3, 6, 7
    const s3 = b[3] ^ b[4] ^ b[5] ^ b[6]; // checks 4, 5, 6, 7

    const errorPos = (s3 << 2) | (s2 << 1) | s1; // decimal position 0..7
    const corrected = [...hammingEncoded];
    if (errorPos > 0 && errorPos <= 7) {
      corrected[errorPos - 1] = corrected[errorPos - 1] === '1' ? '0' : '1';
    }

    setHammingSyndrome({
      syndromeBits: `s3s2s1 = ${s3}${s2}${s1}`,
      errorPos,
      correctedBits: corrected
    });
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-xl p-6 shadow-sm">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-zinc-200">
        <div>
          <h3 className="text-lg font-bold text-zinc-900 flex items-center gap-2">
            <Shield className="w-5 h-5 text-red-600" />
            <span>CRC & Hamming Error Detection/Correction Simulator</span>
          </h3>
          <p className="text-xs text-zinc-500 mt-0.5">
            Polynomial division with Modulo-2 arithmetic and Hamming (7,4) single-bit auto-correction
          </p>
        </div>
        <div className="flex items-center gap-2 bg-zinc-100 p-1 rounded-lg">
          <button
            onClick={() => setActiveTab('crc')}
            className={`px-3 py-1.5 text-xs font-bold rounded-md transition-colors cursor-pointer ${
              activeTab === 'crc' ? 'bg-red-600 text-white shadow-xs' : 'text-zinc-600 hover:text-zinc-900'
            }`}
          >
            CRC Polynomial Division
          </button>
          <button
            onClick={() => setActiveTab('hamming')}
            className={`px-3 py-1.5 text-xs font-bold rounded-md transition-colors cursor-pointer ${
              activeTab === 'hamming' ? 'bg-red-600 text-white shadow-xs' : 'text-zinc-600 hover:text-zinc-900'
            }`}
          >
            Hamming (7,4) Code
          </button>
        </div>
      </div>

      {activeTab === 'crc' ? (
        <div className="space-y-6">
          {/* Inputs */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-zinc-50 border border-zinc-200 rounded-lg p-4">
              <label className="block text-xs font-bold text-zinc-700 uppercase tracking-wider mb-2">
                Data Bitstream (D)
              </label>
              <input
                type="text"
                value={dataBits}
                onChange={(e) => setDataBits(e.target.value)}
                placeholder="e.g. 11010011101100"
                className="w-full px-3 py-2 border border-zinc-300 rounded-lg text-sm font-mono focus:outline-hidden focus:border-red-600"
              />
              <div className="flex gap-2 mt-2">
                <button
                  onClick={() => setDataBits('100100')}
                  className="text-[11px] font-semibold text-zinc-600 bg-white border border-zinc-200 px-2 py-0.5 rounded hover:bg-zinc-100 cursor-pointer"
                >
                  Simple (100100)
                </button>
                <button
                  onClick={() => setDataBits('1101011011')}
                  className="text-[11px] font-semibold text-zinc-600 bg-white border border-zinc-200 px-2 py-0.5 rounded hover:bg-zinc-100 cursor-pointer"
                >
                  Standard (1101011011)
                </button>
                <button
                  onClick={() => setDataBits('11010011101100')}
                  className="text-[11px] font-semibold text-zinc-600 bg-white border border-zinc-200 px-2 py-0.5 rounded hover:bg-zinc-100 cursor-pointer"
                >
                  KJSIT Example (14-bit)
                </button>
              </div>
            </div>

            <div className="bg-zinc-50 border border-zinc-200 rounded-lg p-4">
              <label className="block text-xs font-bold text-zinc-700 uppercase tracking-wider mb-2">
                Generator Polynomial Divisor G(x)
              </label>
              <input
                type="text"
                value={generator}
                onChange={(e) => setGenerator(e.target.value)}
                placeholder="e.g. 1011 (x^3 + x + 1)"
                className="w-full px-3 py-2 border border-zinc-300 rounded-lg text-sm font-mono focus:outline-hidden focus:border-red-600"
              />
              <div className="flex gap-2 mt-2">
                <button
                  onClick={() => setGenerator('1011')}
                  className="text-[11px] font-semibold text-zinc-600 bg-white border border-zinc-200 px-2 py-0.5 rounded hover:bg-zinc-100 cursor-pointer"
                >
                  CRC-3 (1011)
                </button>
                <button
                  onClick={() => setGenerator('10011')}
                  className="text-[11px] font-semibold text-zinc-600 bg-white border border-zinc-200 px-2 py-0.5 rounded hover:bg-zinc-100 cursor-pointer"
                >
                  CRC-4 (10011)
                </button>
                <button
                  onClick={() => setGenerator('110101')}
                  className="text-[11px] font-semibold text-zinc-600 bg-white border border-zinc-200 px-2 py-0.5 rounded hover:bg-zinc-100 cursor-pointer"
                >
                  CRC-5 (110101)
                </button>
              </div>
            </div>
          </div>

          {/* Action Button */}
          <div className="flex justify-center">
            <button
              onClick={handleComputeCRC}
              className="px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-sm rounded-lg shadow-sm flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Cpu className="w-4 h-4" />
              <span>Compute CRC & Transmit Codeword</span>
            </button>
          </div>

          {/* Channel Simulation */}
          {channelBits.length > 0 && (
            <div className="border border-zinc-200 rounded-xl p-5 bg-zinc-50">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider">
                  Physical Channel Transmission (Click any bit to flip/inject noise):
                </span>
                <span className="text-xs text-zinc-500 font-mono">
                  Length: {channelBits.length} bits (Data: {dataBits.length} + FCS: {generator.length - 1})
                </span>
              </div>

              <div className="flex flex-wrap gap-1.5 p-3 bg-white border border-zinc-200 rounded-lg justify-center">
                {channelBits.map((bit, idx) => {
                  const isFCS = idx >= dataBits.length;
                  const isFlipped = bit !== transmittedCodeword[idx];
                  return (
                    <button
                      key={idx}
                      onClick={() => handleToggleChannelBit(idx)}
                      title={`Bit ${idx + 1} (${isFCS ? 'FCS' : 'Data'}). Click to flip.`}
                      className={`w-9 h-11 rounded font-mono font-bold text-sm flex flex-col items-center justify-center transition-all cursor-pointer border ${
                        isFlipped
                          ? 'bg-amber-100 border-amber-500 text-amber-900 ring-2 ring-amber-400'
                          : isFCS
                          ? 'bg-red-50 border-red-300 text-red-700'
                          : 'bg-zinc-100 border-zinc-300 text-zinc-800'
                      }`}
                    >
                      <span>{bit}</span>
                      <span className="text-[9px] text-zinc-400 font-normal">{idx + 1}</span>
                    </button>
                  );
                })}
              </div>

              <div className="flex items-center justify-between mt-4">
                <div className="flex items-center gap-3 text-xs text-zinc-600">
                  <span className="flex items-center gap-1">
                    <span className="w-3 h-3 bg-zinc-200 rounded-xs border border-zinc-300"></span> Data Bits
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-3 h-3 bg-red-100 rounded-xs border border-red-300"></span> FCS Checksum
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-3 h-3 bg-amber-200 rounded-xs border border-amber-400"></span> Corrupted Bit
                  </span>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => setChannelBits(transmittedCodeword.split(''))}
                    className="px-3 py-1.5 bg-white border border-zinc-300 text-xs font-semibold text-zinc-700 rounded-lg hover:bg-zinc-100 cursor-pointer"
                  >
                    Reset Channel Bits
                  </button>
                  <button
                    onClick={handleVerifyAtReceiver}
                    className="px-4 py-1.5 bg-zinc-900 hover:bg-black text-white text-xs font-bold rounded-lg shadow-sm flex items-center gap-1.5 cursor-pointer"
                  >
                    <CheckCircle className="w-3.5 h-3.5 text-red-400" />
                    <span>Receiver Verification</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Verification Result */}
          {verificationResult && (
            <div
              className={`border rounded-xl p-5 ${
                verificationResult.valid
                  ? 'bg-emerald-50/70 border-emerald-300 text-emerald-950'
                  : 'bg-red-50/70 border-red-300 text-red-950'
              }`}
            >
              <div className="flex items-center gap-2 mb-2 font-bold text-sm">
                {verificationResult.valid ? (
                  <>
                    <CheckCircle className="w-5 h-5 text-emerald-600" />
                    <span>CRC Verification Passed! Remainder is {verificationResult.remainder} (No error detected).</span>
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-5 h-5 text-red-600" />
                    <span>CRC Error Detected! Non-zero Remainder: {verificationResult.remainder}. Frame Rejected!</span>
                  </>
                )}
              </div>

              <div className="mt-3 bg-white/90 border border-zinc-200 rounded-lg p-3 max-h-48 overflow-y-auto font-mono text-xs text-zinc-800 space-y-1">
                {verificationResult.steps.map((st, i) => (
                  <div key={i}>{st}</div>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Hamming Code Tab */
        <div className="space-y-6">
          <div className="bg-zinc-50 border border-zinc-200 rounded-lg p-4">
            <label className="block text-xs font-bold text-zinc-700 uppercase tracking-wider mb-2">
              4-Bit Data Word (d3 d2 d1 d0)
            </label>
            <div className="flex items-center gap-3">
              <input
                type="text"
                maxLength={4}
                value={hammingData}
                onChange={(e) => setHammingData(e.target.value)}
                placeholder="1011"
                className="w-48 px-3 py-2 border border-zinc-300 rounded-lg text-sm font-mono focus:outline-hidden focus:border-red-600"
              />
              <button
                onClick={handleEncodeHamming}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-lg cursor-pointer"
              >
                Encode to Hamming (7,4)
              </button>
            </div>
            <p className="text-xs text-zinc-500 mt-2">
              Parity positions: p1 (bit 1), p2 (bit 2), p3 (bit 4). Data positions: d3 (3), d2 (5), d1 (6), d0 (7).
            </p>
          </div>

          {hammingEncoded.length === 7 && (
            <div className="border border-zinc-200 rounded-xl p-5 bg-zinc-50">
              <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider block mb-3">
                Transmitted 7-Bit Codeword (Click one bit to flip and test error correction):
              </span>

              <div className="flex gap-2 justify-center">
                {hammingEncoded.map((bit, idx) => {
                  const pos = idx + 1;
                  const isParity = pos === 1 || pos === 2 || pos === 4;
                  return (
                    <button
                      key={idx}
                      onClick={() => handleToggleHammingBit(idx)}
                      className={`w-12 h-14 rounded-lg font-mono font-bold text-base flex flex-col items-center justify-center border transition-all cursor-pointer ${
                        isParity
                          ? 'bg-red-50 border-red-300 text-red-700'
                          : 'bg-zinc-100 border-zinc-300 text-zinc-900'
                      }`}
                    >
                      <span>{bit}</span>
                      <span className="text-[10px] text-zinc-400 font-normal">
                        {isParity ? `p${pos === 1 ? '1' : pos === 2 ? '2' : '3'}` : `d${pos === 3 ? '3' : pos === 5 ? '2' : pos === 6 ? '1' : '0'}`} ({pos})
                      </span>
                    </button>
                  );
                })}
              </div>

              <div className="flex justify-center mt-4">
                <button
                  onClick={handleVerifyHamming}
                  className="px-5 py-2 bg-zinc-900 hover:bg-black text-white text-xs font-bold rounded-lg shadow-sm flex items-center gap-2 cursor-pointer"
                >
                  <Cpu className="w-4 h-4 text-red-400" />
                  <span>Calculate Syndrome & Auto-Correct</span>
                </button>
              </div>
            </div>
          )}

          {hammingSyndrome && (
            <div className="border border-zinc-200 rounded-xl p-5 bg-zinc-50">
              <div className="flex items-center gap-3 font-bold text-sm mb-3">
                {hammingSyndrome.errorPos === 0 ? (
                  <span className="text-emerald-700 flex items-center gap-2">
                    <CheckCircle className="w-5 h-5" />
                    Syndrome is 000: No bit errors detected!
                  </span>
                ) : (
                  <span className="text-red-700 flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5" />
                    Error located at Bit Position #{hammingSyndrome.errorPos}! ({hammingSyndrome.syndromeBits})
                  </span>
                )}
              </div>

              {hammingSyndrome.errorPos > 0 && (
                <div className="bg-white border border-zinc-200 rounded-lg p-3">
                  <span className="text-xs font-bold text-zinc-700 block mb-2">Auto-Corrected Bitstream:</span>
                  <div className="flex gap-2">
                    {hammingSyndrome.correctedBits.map((b, i) => (
                      <span
                        key={i}
                        className={`w-9 h-9 rounded font-mono font-bold text-sm flex items-center justify-center border ${
                          i + 1 === hammingSyndrome.errorPos
                            ? 'bg-emerald-100 border-emerald-500 text-emerald-900'
                            : 'bg-zinc-100 border-zinc-200 text-zinc-700'
                        }`}
                      >
                        {b}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
