import React, { useState } from 'react';
import { Play, RotateCcw, Share2, GitCommit, CheckCircle2, ArrowRight } from 'lucide-react';

interface Node {
  id: string;
  name: string;
}

interface Edge {
  u: string;
  v: string;
  cost: number;
}

const NODES: Node[] = [
  { id: 'u', name: 'Node U' },
  { id: 'v', name: 'Node V' },
  { id: 'w', name: 'Node W' },
  { id: 'x', name: 'Node X' },
  { id: 'y', name: 'Node Y' },
  { id: 'z', name: 'Node Z' },
];

const EDGES: Edge[] = [
  { u: 'u', v: 'v', cost: 2 },
  { u: 'u', v: 'x', cost: 1 },
  { u: 'u', v: 'w', cost: 5 },
  { u: 'v', v: 'w', cost: 3 },
  { u: 'v', v: 'x', cost: 2 },
  { u: 'w', v: 'x', cost: 3 },
  { u: 'w', v: 'y', cost: 1 },
  { u: 'w', v: 'z', cost: 5 },
  { u: 'x', v: 'y', cost: 1 },
  { u: 'y', v: 'z', cost: 2 },
];

export const LinkStateOSPFSimulator: React.FC = () => {
  const [sourceNode, setSourceNode] = useState('u');
  const [currentStep, setCurrentStep] = useState(0);
  const [settledSet, setSettledSet] = useState<string[]>(['u']);
  const [distances, setDistances] = useState<Record<string, number>>({
    u: 0, v: 2, w: 5, x: 1, y: 999, z: 999
  });
  const [predecessors, setPredecessors] = useState<Record<string, string>>({
    u: '-', v: 'u', w: 'u', x: 'u', y: '-', z: '-'
  });
  const [stepLogs, setStepLogs] = useState<string[]>([
    'Initialized Link-State Database (LSDB) at source router U.'
  ]);

  const handleStepDijkstra = () => {
    // Find unvisited node with minimum distance
    const unvisited = NODES.filter(n => !settledSet.includes(n.id));
    if (unvisited.length === 0) {
      setStepLogs(prev => ['Shortest Path Tree (SPT) computation completed for all nodes!', ...prev]);
      return;
    }

    let minNode = unvisited[0];
    let minDist = distances[minNode.id];

    for (const node of unvisited) {
      if (distances[node.id] < minDist) {
        minDist = distances[node.id];
        minNode = node;
      }
    }

    if (minDist === 999) {
      setStepLogs(prev => ['Remaining unvisited nodes are unreachable.', ...prev]);
      return;
    }

    const newSettled = [...settledSet, minNode.id];
    const newDist = { ...distances };
    const newPred = { ...predecessors };

    // Relax neighbors
    const neighbors = EDGES.filter(e => e.u === minNode.id || e.v === minNode.id);
    for (const edge of neighbors) {
      const neighborId = edge.u === minNode.id ? edge.v : edge.u;
      if (!newSettled.includes(neighborId)) {
        const alt = newDist[minNode.id] + edge.cost;
        if (alt < newDist[neighborId]) {
          newDist[neighborId] = alt;
          newPred[neighborId] = minNode.id;
        }
      }
    }

    setSettledSet(newSettled);
    setDistances(newDist);
    setPredecessors(newPred);
    setCurrentStep(prev => prev + 1);

    setStepLogs(prev => [
      `Step ${currentStep + 1}: Settled node ${minNode.id.toUpperCase()} with total cost ${minDist}. Relaxed adjacent link-state vectors.`,
      ...prev
    ]);
  };

  const handleReset = () => {
    setCurrentStep(0);
    setSettledSet([sourceNode]);
    setDistances({ u: 0, v: 2, w: 5, x: 1, y: 999, z: 999 });
    setPredecessors({ u: '-', v: 'u', w: 'u', x: 'u', y: '-', z: '-' });
    setStepLogs(['Dijkstra Link-State computation reset.']);
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-xl p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-zinc-200">
        <div>
          <h3 className="text-lg font-bold text-zinc-900 flex items-center gap-2">
            <Share2 className="w-5 h-5 text-red-600" />
            <span>Link State (OSPF / Dijkstra) Protocol Simulator</span>
          </h3>
          <p className="text-xs text-zinc-500 mt-0.5">
            Link-State Advertisement (LSA) flooding & Shortest Path First (SPF) tree construction
          </p>
        </div>
        <button
          onClick={handleReset}
          className="px-3 py-1.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset</span>
        </button>
      </div>

      {/* Visual SPT and Node Settled Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div className="lg:col-span-2 border border-zinc-200 rounded-xl p-5 bg-zinc-50">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider">
              Network Topology & SPT Settlement Set N': &#123; {settledSet.map(s => s.toUpperCase()).join(', ')} &#125;
            </span>
            <span className="text-xs text-zinc-500">
              Source: <strong className="text-red-600 uppercase font-mono">{sourceNode}</strong>
            </span>
          </div>

          <div className="grid grid-cols-3 gap-3 p-4 bg-white border border-zinc-200 rounded-xl">
            {NODES.map((n) => {
              const isSettled = settledSet.includes(n.id);
              const isSource = n.id === sourceNode;
              return (
                <div
                  key={n.id}
                  className={`p-3 rounded-lg border flex flex-col items-center justify-center transition-all ${
                    isSource
                      ? 'bg-red-600 text-white border-red-700 shadow-sm'
                      : isSettled
                      ? 'bg-emerald-50 border-emerald-400 text-emerald-950'
                      : 'bg-zinc-50 border-zinc-200 text-zinc-700'
                  }`}
                >
                  <span className="font-bold text-base">{n.id.toUpperCase()}</span>
                  <span className="text-xs mt-1 font-mono">
                    D({n.id}) = {distances[n.id] >= 999 ? '∞' : distances[n.id]}
                  </span>
                  <span className="text-[10px] opacity-80 mt-0.5">
                    Pred: {predecessors[n.id]?.toUpperCase() || '-'}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Shortest Path Forwarding Table */}
        <div className="border border-zinc-200 rounded-xl p-5 bg-zinc-50 flex flex-col">
          <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider mb-3">
            Computed OSPF Forwarding Table:
          </span>

          <div className="bg-white border border-zinc-200 rounded-lg overflow-hidden flex-1">
            <table className="w-full text-xs text-left">
              <thead className="bg-zinc-100 border-b border-zinc-200 text-zinc-600 uppercase text-[10px]">
                <tr>
                  <th className="p-2">Dest</th>
                  <th className="p-2">Min Cost</th>
                  <th className="p-2">Next-Hop Out</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100 font-mono">
                {NODES.map((node) => (
                  <tr key={node.id}>
                    <td className="p-2 font-bold">{node.id.toUpperCase()}</td>
                    <td className="p-2 text-red-600 font-bold">
                      {distances[node.id] >= 999 ? '∞' : distances[node.id]}
                    </td>
                    <td className="p-2">
                      {node.id === sourceNode ? 'LOCAL' : predecessors[node.id]?.toUpperCase() || '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Action Controls */}
      <div className="flex flex-wrap items-center gap-3 p-4 bg-zinc-50 border border-zinc-200 rounded-xl mb-6">
        <button
          onClick={handleStepDijkstra}
          disabled={settledSet.length === NODES.length}
          className="px-5 py-2.5 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white font-bold text-xs rounded-lg shadow-sm flex items-center gap-2 transition-colors cursor-pointer"
        >
          <Play className="w-4 h-4" />
          <span>Step Dijkstra SPF (Relax Neighbors)</span>
        </button>
        <span className="text-xs text-zinc-500">
          {settledSet.length < NODES.length ? `${NODES.length - settledSet.length} nodes remaining to settle` : 'All nodes permanently settled!'}
        </span>
      </div>

      {/* Execution Log */}
      <div className="border border-zinc-200 rounded-xl p-4 bg-zinc-50">
        <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider block mb-2">
          SPF Execution Trace:
        </span>
        <div className="bg-white border border-zinc-200 rounded-lg p-3 max-h-36 overflow-y-auto font-mono text-xs text-zinc-800 space-y-1">
          {stepLogs.map((l, i) => (
            <div key={i} className="border-b border-zinc-100 pb-0.5">{l}</div>
          ))}
        </div>
      </div>
    </div>
  );
};
