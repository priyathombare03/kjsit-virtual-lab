import React, { useState } from 'react';
import { AlignLeft, Play, RotateCcw, CheckCircle2, ArrowRight, Shield } from 'lucide-react';

export const FramingStuffingSimulator: React.FC = () => {
  const [mode, setMode] = useState<'bit' | 'byte'>('bit');
  const [bitInput, setBitInput] = useState('011111101111110');
  const [byteInput, setByteInput] = useState('A ESC B FLAG C');

  // Bit stuffing: After five consecutive 1s, insert a '0'
  const performBitStuffing = (input: string) => {
    let stuffed = '';
    let count = 0;
    const insertedIndices: number[] = [];

    for (let i = 0; i < input.length; i++) {
      const bit = input[i];
      stuffed += bit;
      if (bit === '1') {
        count++;
        if (count === 5) {
          stuffed += '0';
          insertedIndices.push(stuffed.length - 1);
          count = 0;
        }
      } else {
        count = 0;
      }
    }
    const framed = `01111110 ${stuffed} 01111110`;
    return { stuffed, framed, insertedIndices };
  };

  // Byte stuffing
  const performByteStuffing = (input: string) => {
    const tokens = input.trim().split(/\s+/);
    const stuffedTokens: string[] = [];
    const insertedTokens: number[] = [];

    tokens.forEach((t) => {
      if (t === 'FLAG' || t === 'ESC') {
        stuffedTokens.push('ESC');
        insertedTokens.push(stuffedTokens.length - 1);
        stuffedTokens.push(t);
      } else {
        stuffedTokens.push(t);
      }
    });

    const framed = `[FLAG] ${stuffedTokens.join(' ')} [FLAG]`;
    return { stuffed: stuffedTokens.join(' '), framed, insertedTokens };
  };

  const bitResult = performBitStuffing(bitInput);
  const byteResult = performByteStuffing(byteInput);

  return (
    <div className="bg-white border border-zinc-200 rounded-xl p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-zinc-200">
        <div>
          <h3 className="text-lg font-bold text-zinc-900 flex items-center gap-2">
            <AlignLeft className="w-5 h-5 text-red-600" />
            <span>Framing: Bit Stuffing & Byte Stuffing Simulator</span>
          </h3>
          <p className="text-xs text-zinc-500 mt-0.5">
            HDLC 01111110 Flag delimiter with 5-consecutive-ones bit stuffing & ESC character byte stuffing
          </p>
        </div>
        <div className="flex items-center gap-2 bg-zinc-100 p-1 rounded-lg">
          <button
            onClick={() => setMode('bit')}
            className={`px-3 py-1 text-xs font-bold rounded-md transition-colors cursor-pointer ${
              mode === 'bit' ? 'bg-red-600 text-white shadow-xs' : 'text-zinc-600'
            }`}
          >
            Bit Stuffing (HDLC)
          </button>
          <button
            onClick={() => setMode('byte')}
            className={`px-3 py-1 text-xs font-bold rounded-md transition-colors cursor-pointer ${
              mode === 'byte' ? 'bg-red-600 text-white shadow-xs' : 'text-zinc-600'
            }`}
          >
            Byte (Character) Stuffing
          </button>
        </div>
      </div>

      {mode === 'bit' ? (
        <div className="space-y-6">
          <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-4">
            <label className="block text-xs font-bold text-zinc-700 uppercase tracking-wider mb-2">
              Raw Payload Bitstream:
            </label>
            <input
              type="text"
              value={bitInput}
              onChange={(e) => setBitInput(e.target.value.replace(/[^01]/g, ''))}
              placeholder="011111101111110"
              className="w-full px-3 py-2 border border-zinc-300 rounded-lg text-sm font-mono focus:outline-hidden focus:border-red-600"
            />
            <div className="flex gap-2 mt-2">
              <button
                onClick={() => setBitInput('011111101111110')}
                className="text-[11px] font-semibold text-zinc-600 bg-white border border-zinc-200 px-2 py-0.5 rounded hover:bg-zinc-100 cursor-pointer"
              >
                Standard Pattern (011111101111110)
              </button>
              <button
                onClick={() => setBitInput('111111111111')}
                className="text-[11px] font-semibold text-zinc-600 bg-white border border-zinc-200 px-2 py-0.5 rounded hover:bg-zinc-100 cursor-pointer"
              >
                Consecutive Ones (111111111111)
              </button>
            </div>
          </div>

          {/* Stuffed Stream Visual */}
          <div className="border border-zinc-200 rounded-xl p-5 bg-zinc-50">
            <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider block mb-3">
              Stuffed & Framed Output Frame:
            </span>

            <div className="p-4 bg-zinc-950 text-white rounded-xl font-mono text-sm overflow-x-auto space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-xs text-zinc-500 uppercase w-28 shrink-0">1. Raw Input:</span>
                <span className="text-zinc-300 font-bold">{bitInput}</span>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-zinc-500 uppercase w-28 shrink-0">2. Stuffed:</span>
                <span className="text-zinc-200 font-bold">
                  {bitResult.stuffed.split('').map((b, i) => (
                    <span
                      key={i}
                      className={bitResult.insertedIndices.includes(i) ? 'text-amber-400 font-black bg-amber-950/80 px-1 py-0.5 rounded border border-amber-600' : ''}
                    >
                      {b}
                    </span>
                  ))}
                </span>
              </div>

              <div className="flex items-center gap-2 pt-2 border-t border-zinc-800">
                <span className="text-xs text-zinc-500 uppercase w-28 shrink-0">3. Transmitted:</span>
                <span className="text-red-400 font-bold">01111110</span>
                <span className="text-zinc-200 font-bold mx-1">
                  {bitResult.stuffed.split('').map((b, i) => (
                    <span
                      key={i}
                      className={bitResult.insertedIndices.includes(i) ? 'text-amber-400 font-black bg-amber-950/80 px-1 py-0.5 rounded border border-amber-600' : ''}
                    >
                      {b}
                    </span>
                  ))}
                </span>
                <span className="text-red-400 font-bold">01111110</span>
              </div>
            </div>

            <div className="flex items-center gap-4 mt-3 text-xs text-zinc-600">
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 bg-red-500 rounded-xs"></span> HDLC Frame Flags (01111110)
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 bg-amber-400 rounded-xs"></span> Stuffed '0' (After 5 consecutive 1s)
              </span>
            </div>
          </div>
        </div>
      ) : (
        /* Byte Stuffing Tab */
        <div className="space-y-6">
          <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-4">
            <label className="block text-xs font-bold text-zinc-700 uppercase tracking-wider mb-2">
              Payload Characters (space-separated tokens):
            </label>
            <input
              type="text"
              value={byteInput}
              onChange={(e) => setByteInput(e.target.value)}
              placeholder="A ESC B FLAG C"
              className="w-full px-3 py-2 border border-zinc-300 rounded-lg text-sm font-mono focus:outline-hidden focus:border-red-600"
            />
            <div className="flex gap-2 mt-2">
              <button
                onClick={() => setByteInput('DATA ESC DATA FLAG PACKET')}
                className="text-[11px] font-semibold text-zinc-600 bg-white border border-zinc-200 px-2 py-0.5 rounded hover:bg-zinc-100 cursor-pointer"
              >
                Sample 1 (DATA ESC DATA FLAG PACKET)
              </button>
              <button
                onClick={() => setByteInput('HEADER ESC ESC FLAG TAIL')}
                className="text-[11px] font-semibold text-zinc-600 bg-white border border-zinc-200 px-2 py-0.5 rounded hover:bg-zinc-100 cursor-pointer"
              >
                Sample 2 (Consecutive Escapes)
              </button>
            </div>
          </div>

          <div className="border border-zinc-200 rounded-xl p-5 bg-zinc-50">
            <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider block mb-3">
              Byte-Stuffed Framed Stream:
            </span>

            <div className="p-4 bg-zinc-950 text-white rounded-xl font-mono text-sm overflow-x-auto space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-xs text-zinc-500 uppercase w-28 shrink-0">Raw Tokens:</span>
                <span className="text-zinc-300">{byteInput}</span>
              </div>
              <div className="flex items-center gap-2 pt-2 border-t border-zinc-800">
                <span className="text-xs text-zinc-500 uppercase w-28 shrink-0">Transmitted:</span>
                <span className="text-red-400 font-bold">[FLAG]</span>
                <span className="text-zinc-200 font-bold mx-1">
                  {byteResult.stuffed.split(' ').map((t, idx) => (
                    <span
                      key={idx}
                      className={`inline-block mx-1 px-1 py-0.5 rounded ${
                        t === 'ESC' ? 'bg-amber-950 border border-amber-500 text-amber-300' : 'bg-zinc-800 text-zinc-100'
                      }`}
                    >
                      {t}
                    </span>
                  ))}
                </span>
                <span className="text-red-400 font-bold">[FLAG]</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
