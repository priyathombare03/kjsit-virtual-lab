import React, { useState } from 'react';
import { Play, RotateCcw, Network, ArrowRight, Activity, AlertTriangle } from 'lucide-react';

const NODES = ['A', 'B', 'C', 'D', 'E'];
const INF = 999;

const INITIAL_TOPOLOGY = [
  [0, 2, INF, 1, INF],     // A
  [2, 0, 3, INF, 7],       // B
  [INF, 3, 0, 1, 2],       // C
  [1, INF, 1, 0, 8],       // D
  [INF, 7, 2, 8, 0]        // E
];

export const DistanceVectorSimulator: React.FC = () => {
  const [costMatrix, setCostMatrix] = useState<number[][]>(INITIAL_TOPOLOGY);
  const [distanceTables, setDistanceTables] = useState<number[][]>(INITIAL_TOPOLOGY);
  const [nextHopTables, setNextHopTables] = useState<string[][]>(
    INITIAL_TOPOLOGY.map((row, i) =>
      row.map((c, j) => (c !== INF && i !== j ? NODES[j] : '-'))
    )
  );
  const [iteration, setIteration] = useState(0);
  const [converged, setConverged] = useState(false);
  const [selectedNode, setSelectedNode] = useState(0); // Node A
  const [splitHorizon, setSplitHorizon] = useState(true);
  const [logs, setLogs] = useState<string[]>([
    'Initialized 5-Node Distance Vector network (Bellman-Ford algorithm).'
  ]);

  const addLog = (msg: string) => {
    setLogs(prev => [msg, ...prev.slice(0, 15)]);
  };

  const handleStepIteration = () => {
    if (converged) {
      addLog('Distance Vector has already converged to optimal steady-state!');
      return;
    }

    let updated = false;
    const newDist = distanceTables.map(row => [...row]);
    const newNext = nextHopTables.map(row => [...row]);

    for (let i = 0; i < NODES.length; i++) {
      for (let j = 0; j < NODES.length; j++) {
        if (i === j) continue;

        for (let k = 0; k < NODES.length; k++) {
          if (costMatrix[i][k] !== INF && i !== k) {
            const costViaK = costMatrix[i][k] + distanceTables[k][j];
            if (costViaK < newDist[i][j]) {
              newDist[i][j] = costViaK;
              newNext[i][j] = nextHopTables[i][k] !== '-' ? nextHopTables[i][k] : NODES[k];
              updated = true;
              addLog(`[UPDATE] Router ${NODES[i]} found shorter path to ${NODES[j]} via ${NODES[k]} (Cost: ${costViaK}).`);
            }
          }
        }
      }
    }

    setDistanceTables(newDist);
    setNextHopTables(newNext);
    setIteration(prev => prev + 1);

    if (!updated) {
      setConverged(true);
      addLog(`*** CONVERGENCE REACHED *** All routing tables stable at Iteration ${iteration + 1}.`);
    }
  };

  const handleFailLink = (u: number, v: number) => {
    const newCost = costMatrix.map(row => [...row]);
    newCost[u][v] = INF;
    newCost[v][u] = INF;
    setCostMatrix(newCost);
    setConverged(false);
    addLog(`*** LINK SEVERED *** Link (${NODES[u]} <-> ${NODES[v]}) cost set to INFINITY. Re-running Bellman-Ford.`);
  };

  const handleReset = () => {
    setCostMatrix(INITIAL_TOPOLOGY);
    setDistanceTables(INITIAL_TOPOLOGY);
    setNextHopTables(
      INITIAL_TOPOLOGY.map((row, i) =>
        row.map((c, j) => (c !== INF && i !== j ? NODES[j] : '-'))
      )
    );
    setIteration(0);
    setConverged(false);
    setLogs(['Distance Vector simulation reset.']);
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-xl p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-zinc-200">
        <div>
          <h3 className="text-lg font-bold text-zinc-900 flex items-center gap-2">
            <Network className="w-5 h-5 text-red-600" />
            <span>Distance Vector Routing Algorithm Simulator (RIP / Bellman-Ford)</span>
          </h3>
          <p className="text-xs text-zinc-500 mt-0.5">
            Distributed Bellman-Ford equation Dx(y) = min_v &#123; c(x,v) + Dv(y) &#125; with convergence tracking
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleReset}
            className="px-3 py-1.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        </div>
      </div>

      {/* Network Graph Visualizer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div className="lg:col-span-2 border border-zinc-200 rounded-xl p-5 bg-zinc-50 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider">
              Network Topology Graph:
            </span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-zinc-200 text-zinc-800">
              Iteration #{iteration} ({converged ? 'Converged' : 'Updating'})
            </span>
          </div>

          <div className="flex flex-wrap justify-around items-center gap-4 py-8 bg-white border border-zinc-200 rounded-xl">
            {NODES.map((node, idx) => (
              <button
                key={node}
                onClick={() => setSelectedNode(idx)}
                className={`w-14 h-14 rounded-2xl flex flex-col items-center justify-center font-bold text-sm transition-all cursor-pointer border ${
                  selectedNode === idx
                    ? 'bg-red-600 border-red-700 text-white shadow-md scale-105 ring-4 ring-red-100'
                    : 'bg-zinc-900 border-zinc-800 text-zinc-100 hover:bg-zinc-800'
                }`}
              >
                <span>{node}</span>
                <span className="text-[9px] opacity-80 font-normal">Router</span>
              </button>
            ))}
          </div>

          {/* Link controls */}
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-xs">
            <span className="font-semibold text-zinc-600">Simulate Link Failure:</span>
            <div className="flex gap-2">
              <button
                onClick={() => handleFailLink(1, 2)}
                className="px-2.5 py-1 bg-red-50 text-red-700 border border-red-200 rounded-lg hover:bg-red-100 font-semibold cursor-pointer"
              >
                Cut B &lt;-&gt; C Link
              </button>
              <button
                onClick={() => handleFailLink(2, 4)}
                className="px-2.5 py-1 bg-red-50 text-red-700 border border-red-200 rounded-lg hover:bg-red-100 font-semibold cursor-pointer"
              >
                Cut C &lt;-&gt; E Link
              </button>
            </div>
          </div>
        </div>

        {/* Selected Router Table */}
        <div className="border border-zinc-200 rounded-xl p-5 bg-zinc-50 flex flex-col">
          <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider mb-3">
            Routing Table: Router {NODES[selectedNode]}
          </span>

          <div className="bg-white border border-zinc-200 rounded-lg overflow-hidden flex-1">
            <table className="w-full text-xs text-left">
              <thead className="bg-zinc-100 border-b border-zinc-200 text-zinc-600 uppercase text-[10px]">
                <tr>
                  <th className="p-2">Dest</th>
                  <th className="p-2">Cost</th>
                  <th className="p-2">Next Hop</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100 font-mono">
                {NODES.map((dest, j) => (
                  <tr key={dest} className={selectedNode === j ? 'bg-zinc-50 text-zinc-400' : ''}>
                    <td className="p-2 font-bold">{dest}</td>
                    <td className="p-2 text-red-600 font-bold">
                      {distanceTables[selectedNode][j] >= INF ? 'INF' : distanceTables[selectedNode][j]}
                    </td>
                    <td className="p-2">{nextHopTables[selectedNode][j]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Control Actions */}
      <div className="flex flex-wrap items-center gap-3 p-4 bg-zinc-50 border border-zinc-200 rounded-xl mb-6">
        <button
          onClick={handleStepIteration}
          disabled={converged}
          className="px-5 py-2.5 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white font-bold text-xs rounded-lg shadow-sm flex items-center gap-2 transition-colors cursor-pointer"
        >
          <Play className="w-4 h-4" />
          <span>Step Bellman-Ford Iteration</span>
        </button>

        <label className="flex items-center gap-2 text-xs font-semibold text-zinc-700 ml-4 cursor-pointer">
          <input
            type="checkbox"
            checked={splitHorizon}
            onChange={(e) => setSplitHorizon(e.target.checked)}
            className="rounded text-red-600 focus:ring-red-500"
          />
          <span>Enable Split Horizon Loop Mitigation</span>
        </label>
      </div>

      {/* Log console */}
      <div className="border border-zinc-200 rounded-xl p-4 bg-zinc-50">
        <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider block mb-2">
          Bellman-Ford Execution Trace:
        </span>
        <div className="bg-white border border-zinc-200 rounded-lg p-3 max-h-36 overflow-y-auto font-mono text-xs text-zinc-800 space-y-1">
          {logs.map((l, i) => (
            <div key={i} className="border-b border-zinc-100 pb-0.5">{l}</div>
          ))}
        </div>
      </div>
    </div>
  );
};
