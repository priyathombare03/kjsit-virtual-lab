import React, { useState } from 'react';
import {
  Layers,
  Plus,
  Search,
  RotateCcw,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  HardDrive,
  Database
} from 'lucide-react';

interface LeafNode {
  id: string;
  keys: number[];
}

export const BPlusTreeSimulator: React.FC = () => {
  const [order, setOrder] = useState<number>(3); // Max 2 keys per leaf for Order 3
  const [keys, setKeys] = useState<number[]>([10, 20, 30, 40, 50, 60]);
  const [newKey, setNewKey] = useState<string>('');
  const [rangeStart, setRangeStart] = useState<number>(20);
  const [rangeEnd, setRangeEnd] = useState<number>(50);
  const [rangeResults, setRangeResults] = useState<number[] | null>([20, 30, 40, 50]);

  // Insert Key
  const handleInsertKey = () => {
    const val = parseInt(newKey.trim(), 10);
    if (isNaN(val) || keys.includes(val)) return;
    const updated = [...keys, val].sort((a, b) => a - b);
    setKeys(updated);
    setNewKey('');
  };

  // Range Query
  const handleRangeQuery = () => {
    const filtered = keys.filter((k) => k >= rangeStart && k <= rangeEnd);
    setRangeResults(filtered);
  };

  // Group Keys into B+ Tree Leaf Nodes based on Order
  const maxLeafKeys = order - 1; // e.g. Order 3 => max 2 keys per leaf
  const leafNodes: LeafNode[] = [];
  for (let i = 0; i < keys.length; i += maxLeafKeys) {
    leafNodes.push({
      id: `leaf-${Math.floor(i / maxLeafKeys)}`,
      keys: keys.slice(i, i + maxLeafKeys)
    });
  }

  // Root internal routing keys (smallest key of each leaf except first)
  const rootRoutingKeys = leafNodes.slice(1).map((l) => l.keys[0]);

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
      {/* Header */}
      <div className="bg-slate-900 text-white p-5 sm:p-6 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-semibold uppercase tracking-wider mb-2">
            <HardDrive className="w-3.5 h-3.5" />
            <span>Physical Storage Indexing & B+ Tree Organization</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white">
            B+ Tree Index Architecture & Sequential Leaf Range Scanner
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Simulate B+ Tree root routing splits, internal node fanouts, and doubly linked leaf traversals for O(log N) point search and O(1) range queries.
          </p>
        </div>

        <button
          onClick={() => {
            setKeys([10, 20, 30, 40, 50, 60]);
            setRangeResults([20, 30, 40, 50]);
          }}
          className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold border border-slate-700 transition-colors cursor-pointer self-start sm:self-center"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Tree</span>
        </button>
      </div>

      <div className="p-5 sm:p-6 space-y-6">
        {/* Controls Bar */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 text-xs">
          {/* Tree Order */}
          <div className="md:col-span-3 p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
            <span className="font-bold text-slate-800">Tree Order (M):</span>
            <select
              value={order}
              onChange={(e) => setOrder(Number(e.target.value))}
              className="px-2 py-1 bg-white border border-slate-200 rounded font-bold text-emerald-700 focus:outline-none"
            >
              <option value={3}>Order 3 (Max 2 keys/node)</option>
              <option value={4}>Order 4 (Max 3 keys/node)</option>
            </select>
          </div>

          {/* Insert Key */}
          <div className="md:col-span-4 p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center gap-2">
            <input
              type="number"
              value={newKey}
              onChange={(e) => setNewKey(e.target.value)}
              placeholder="Insert Key (e.g. 25)"
              className="flex-1 px-2.5 py-1 bg-white border border-slate-200 rounded text-xs font-mono focus:outline-none"
            />
            <button
              onClick={handleInsertKey}
              className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-bold flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Insert</span>
            </button>
          </div>

          {/* Range Query */}
          <div className="md:col-span-5 p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center gap-2">
            <span className="font-bold text-slate-800">Range:</span>
            <input
              type="number"
              value={rangeStart}
              onChange={(e) => setRangeStart(Number(e.target.value))}
              className="w-16 px-2 py-1 bg-white border border-slate-200 rounded text-xs font-mono"
            />
            <span className="text-slate-400">to</span>
            <input
              type="number"
              value={rangeEnd}
              onChange={(e) => setRangeEnd(Number(e.target.value))}
              className="w-16 px-2 py-1 bg-white border border-slate-200 rounded text-xs font-mono"
            />
            <button
              onClick={handleRangeQuery}
              className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded font-bold flex items-center gap-1 cursor-pointer"
            >
              <Search className="w-3 h-3" />
              <span>Scan</span>
            </button>
          </div>
        </div>

        {/* Visual B+ Tree Structure Canvas */}
        <div className="p-6 bg-slate-950 rounded-2xl border border-slate-800 space-y-6 text-white font-mono shadow-sm">
          {/* Level 1: Root Node */}
          <div className="flex flex-col items-center space-y-2">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
              Level 0: Root Internal Node (Search Routing Keys)
            </span>
            <div className="px-5 py-2.5 bg-slate-900 border-2 border-emerald-500 rounded-xl flex items-center gap-3 shadow-md">
              {rootRoutingKeys.length > 0 ? (
                rootRoutingKeys.map((k, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-1 bg-emerald-950 text-emerald-300 font-black rounded border border-emerald-600/50"
                  >
                    {k}
                  </span>
                ))
              ) : (
                <span className="text-slate-500 text-xs">Root is Leaf</span>
              )}
            </div>
            <div className="w-px h-6 bg-slate-700"></div>
          </div>

          {/* Level 2: Leaf Nodes (Sequential Doubly Linked List) */}
          <div className="space-y-2">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block text-center">
              Level 1: Leaf Nodes (Data Record Pointers & Sequential Links)
            </span>

            <div className="flex flex-wrap items-center justify-center gap-3">
              {leafNodes.map((leaf, idx) => (
                <React.Fragment key={leaf.id}>
                  <div className="p-3 bg-slate-900 border border-slate-700 rounded-xl flex flex-col items-center gap-1.5 shadow-sm min-w-[100px]">
                    <span className="text-[9px] text-slate-500 font-sans font-semibold">Leaf Block {idx + 1}</span>
                    <div className="flex items-center gap-1.5">
                      {leaf.keys.map((k) => {
                        const inRange = rangeResults && rangeResults.includes(k);
                        return (
                          <span
                            key={k}
                            className={`px-2 py-1 rounded font-bold text-xs transition-all ${
                              inRange
                                ? 'bg-amber-400 text-slate-950 scale-110 shadow-xs'
                                : 'bg-slate-800 text-white border border-slate-700'
                            }`}
                          >
                            {k}
                          </span>
                        );
                      })}
                    </div>
                  </div>

                  {idx < leafNodes.length - 1 && (
                    <span className="text-emerald-400 font-bold text-lg">──▶</span>
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>

        {/* Range Scan Results Display */}
        {rangeResults && (
          <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-emerald-900 font-bold">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Range Query [{rangeStart} .. {rangeEnd}] Results ({rangeResults.length} tuples):</span>
            </div>
            <div className="flex items-center gap-1.5 font-mono">
              {rangeResults.map((k) => (
                <span key={k} className="px-2 py-1 bg-emerald-200 text-emerald-900 font-black rounded text-xs">
                  {k}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
