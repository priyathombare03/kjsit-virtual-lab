import React, { useState } from 'react';
import {
  GitCommit,
  GitBranch,
  ShieldCheck,
  AlertOctagon,
  RefreshCw,
  Play,
  ArrowRight,
  CheckCircle2,
  Lock,
  Layers
} from 'lucide-react';

interface Operation {
  step: number;
  tx: 'T1' | 'T2' | 'T3';
  type: 'READ' | 'WRITE' | 'COMMIT';
  item: 'A' | 'B' | 'C';
}

const PRESET_SCHEDULES = [
  {
    name: 'Serializable Schedule (Acyclic Graph)',
    ops: [
      { step: 1, tx: 'T1', type: 'READ', item: 'A' },
      { step: 2, tx: 'T1', type: 'WRITE', item: 'A' },
      { step: 3, tx: 'T2', type: 'READ', item: 'A' },
      { step: 4, tx: 'T2', type: 'WRITE', item: 'A' },
      { step: 5, tx: 'T1', type: 'COMMIT', item: 'A' },
      { step: 6, tx: 'T2', type: 'COMMIT', item: 'A' }
    ] as Operation[]
  },
  {
    name: 'Non-Serializable (Cycle T1 <-> T2)',
    ops: [
      { step: 1, tx: 'T1', type: 'READ', item: 'A' },
      { step: 2, tx: 'T2', type: 'WRITE', item: 'A' },
      { step: 3, tx: 'T1', type: 'WRITE', item: 'A' },
      { step: 4, tx: 'T2', type: 'COMMIT', item: 'A' },
      { step: 5, tx: 'T1', type: 'COMMIT', item: 'A' }
    ] as Operation[]
  },
  {
    name: '3-Transaction Serial Conflict (T1 -> T2 -> T3)',
    ops: [
      { step: 1, tx: 'T1', type: 'WRITE', item: 'A' },
      { step: 2, tx: 'T2', type: 'READ', item: 'A' },
      { step: 3, tx: 'T2', type: 'WRITE', item: 'B' },
      { step: 4, tx: 'T3', type: 'READ', item: 'B' },
      { step: 5, tx: 'T1', type: 'COMMIT', item: 'A' },
      { step: 6, tx: 'T2', type: 'COMMIT', item: 'B' },
      { step: 7, tx: 'T3', type: 'COMMIT', item: 'B' }
    ] as Operation[]
  }
];

export const TransactionConcurrencySimulator: React.FC = () => {
  const [selectedScheduleIdx, setSelectedScheduleIdx] = useState<number>(0);
  const [lockMode, setLockMode] = useState<'2PL' | 'Strict2PL'>('Strict2PL');

  const currentSchedule = PRESET_SCHEDULES[selectedScheduleIdx].ops;

  // Detect Conflicting Pairs & Build Precedence Graph
  const analyzeConflicts = () => {
    const conflicts: { from: string; to: string; item: string; reason: string; step1: number; step2: number }[] = [];
    const edges = new Set<string>();

    for (let i = 0; i < currentSchedule.length; i++) {
      const op1 = currentSchedule[i];
      for (let j = i + 1; j < currentSchedule.length; j++) {
        const op2 = currentSchedule[j];

        if (op1.tx !== op2.tx && op1.item === op2.item && op1.type !== 'COMMIT' && op2.type !== 'COMMIT') {
          if (op1.type === 'WRITE' || op2.type === 'WRITE') {
            const edgeKey = `${op1.tx}->${op2.tx}`;
            edges.add(edgeKey);
            conflicts.push({
              from: op1.tx,
              to: op2.tx,
              item: op1.item,
              reason: `${op1.tx} ${op1.type}(${op1.item}) [step ${op1.step}] precedes ${op2.tx} ${op2.type}(${op2.item}) [step ${op2.step}]`,
              step1: op1.step,
              step2: op2.step
            });
          }
        }
      }
    }

    // Check Cycle
    const hasT1T2 = edges.has('T1->T2');
    const hasT2T1 = edges.has('T2->T1');
    const isCycle = hasT1T2 && hasT2T1;

    return { conflicts, edges: Array.from(edges), isConflictSerializable: !isCycle };
  };

  const { conflicts, edges, isConflictSerializable } = analyzeConflicts();

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
      {/* Header */}
      <div className="bg-slate-900 text-white p-5 sm:p-6 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-semibold uppercase tracking-wider mb-2">
            <Lock className="w-3.5 h-3.5" />
            <span>Transaction Serializability & Concurrency Control</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white">
            Precedence Graph & Conflict Serializability Analyzer
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Evaluate concurrent read/write operations, identify RW/WR/WW conflicts, generate directed serialization graphs, and test for cycle-free serializability.
          </p>
        </div>
      </div>

      <div className="p-5 sm:p-6 space-y-6">
        {/* Preset Selector */}
        <div className="flex flex-wrap gap-2">
          {PRESET_SCHEDULES.map((sched, idx) => (
            <button
              key={idx}
              onClick={() => setSelectedScheduleIdx(idx)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                selectedScheduleIdx === idx
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-slate-50 text-slate-700 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              {sched.name}
            </button>
          ))}
        </div>

        {/* 2-Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Schedule Timeline Matrix (6 Cols) */}
          <div className="lg:col-span-6 space-y-4">
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                Concurrent Schedule Execution Timeline
              </span>

              <div className="overflow-x-auto border border-slate-200 rounded-lg bg-white">
                <table className="w-full text-center text-xs font-mono">
                  <thead className="bg-slate-800 text-emerald-300 uppercase text-[10px]">
                    <tr>
                      <th className="p-2 border-r border-slate-700">Time</th>
                      <th className="p-2 border-r border-slate-700">Transaction T1</th>
                      <th className="p-2 border-r border-slate-700">Transaction T2</th>
                      <th className="p-2">Transaction T3</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {currentSchedule.map((op) => (
                      <tr key={op.step} className="hover:bg-slate-50">
                        <td className="p-2 font-bold text-slate-400 border-r border-slate-100">
                          t{op.step}
                        </td>
                        <td className="p-2 border-r border-slate-100">
                          {op.tx === 'T1' && (
                            <span className="px-2 py-1 bg-emerald-100 text-emerald-800 font-bold rounded">
                              {op.type === 'COMMIT' ? 'COMMIT' : `${op.type}(${op.item})`}
                            </span>
                          )}
                        </td>
                        <td className="p-2 border-r border-slate-100">
                          {op.tx === 'T2' && (
                            <span className="px-2 py-1 bg-blue-100 text-blue-800 font-bold rounded">
                              {op.type === 'COMMIT' ? 'COMMIT' : `${op.type}(${op.item})`}
                            </span>
                          )}
                        </td>
                        <td className="p-2">
                          {op.tx === 'T3' && (
                            <span className="px-2 py-1 bg-purple-100 text-purple-800 font-bold rounded">
                              {op.type === 'COMMIT' ? 'COMMIT' : `${op.type}(${op.item})`}
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Conflict List */}
            <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-2 shadow-2xs">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                Detected Conflicting Operation Pairs ({conflicts.length})
              </span>
              <div className="space-y-1.5 text-xs font-mono">
                {conflicts.map((c, idx) => (
                  <div key={idx} className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700">
                    <span className="font-bold text-emerald-700">{c.from}</span>
                    <span className="text-slate-400"> ---&gt; </span>
                    <span className="font-bold text-blue-700">{c.to}</span>
                    <span className="text-slate-500 text-[10px] block mt-0.5">{c.reason}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Precedence Graph & Serial Order (6 Cols) */}
          <div className="lg:col-span-6 space-y-4">
            <div className="p-5 bg-slate-900 text-white rounded-xl space-y-4 shadow-sm">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <GitBranch className="w-4 h-4" />
                  <span>Precedence (Serialization) Graph</span>
                </span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    isConflictSerializable
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                      : 'bg-rose-950 text-rose-300 border border-rose-500/40'
                  }`}
                >
                  {isConflictSerializable ? 'ACYCLIC (Serializable)' : 'CYCLIC (Inconsistent)'}
                </span>
              </div>

              {/* Graphical ASCII Directed Graph */}
              <div className="p-4 bg-slate-950 rounded-lg border border-slate-800 text-center font-mono text-sm space-y-3">
                <div className="flex justify-around items-center">
                  <div className="w-12 h-12 rounded-full bg-emerald-900 border-2 border-emerald-400 flex items-center justify-center font-black text-emerald-300">
                    T1
                  </div>

                  {edges.includes('T1->T2') && !edges.includes('T2->T1') && (
                    <span className="text-emerald-400 font-bold">────────▶</span>
                  )}
                  {edges.includes('T1->T2') && edges.includes('T2->T1') && (
                    <span className="text-rose-400 font-bold animate-pulse">◀───────▶ (CYCLE)</span>
                  )}

                  <div className="w-12 h-12 rounded-full bg-blue-900 border-2 border-blue-400 flex items-center justify-center font-black text-blue-300">
                    T2
                  </div>

                  {edges.includes('T2->T3') && (
                    <span className="text-purple-400 font-bold">────────▶</span>
                  )}

                  {edges.includes('T2->T3') && (
                    <div className="w-12 h-12 rounded-full bg-purple-900 border-2 border-purple-400 flex items-center justify-center font-black text-purple-300">
                      T3
                    </div>
                  )}
                </div>
              </div>

              {/* Result Summary */}
              <div className="p-3 rounded-lg border text-xs font-mono leading-relaxed" style={{ backgroundColor: isConflictSerializable ? 'rgba(6, 78, 59, 0.4)' : 'rgba(136, 19, 55, 0.4)', borderColor: isConflictSerializable ? 'rgba(16, 185, 129, 0.3)' : 'rgba(244, 63, 94, 0.3)' }}>
                {isConflictSerializable ? (
                  <div className="text-emerald-300">
                    <span className="font-bold block mb-1">✓ Conflict Serializable:</span>
                    Topological Sort yields equivalent serial schedule order: <strong className="text-white">T1 → T2 {edges.includes('T2->T3') ? '→ T3' : ''}</strong>
                  </div>
                ) : (
                  <div className="text-rose-300">
                    <span className="font-bold block mb-1">⚠ Conflict Inconsistent (Non-Serializable):</span>
                    Graph contains a directed cycle between T1 and T2. No equivalent serial transaction schedule exists!
                  </div>
                )}
              </div>
            </div>

            {/* 2PL Note */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-700 space-y-1">
              <span className="font-bold text-slate-900 block">Two-Phase Locking (2PL) Rule:</span>
              <p className="text-[11px] text-slate-600">
                To guarantee conflict serializability, transactions must follow the Growing Phase (lock acquisition) and Shrinking Phase (lock release). Strict 2PL holds exclusive locks until commit/abort to eliminate cascading rollbacks.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
