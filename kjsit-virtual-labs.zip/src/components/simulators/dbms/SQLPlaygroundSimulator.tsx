import React, { useState } from 'react';
import {
  Play,
  RotateCcw,
  Database,
  Table,
  Terminal,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Clock,
  Search,
  Code
} from 'lucide-react';

interface Row {
  [key: string]: any;
}

interface TableData {
  name: string;
  columns: string[];
  rows: Row[];
}

const INITIAL_TABLES: Record<string, TableData> = {
  Department: {
    name: 'Department',
    columns: ['dept_id', 'dept_name', 'building', 'budget'],
    rows: [
      { dept_id: 10, dept_name: 'Computer Science', building: 'Turing Hall', budget: 1200000 },
      { dept_id: 20, dept_name: 'Electrical Engg', building: 'Tesla Block', budget: 950000 },
      { dept_id: 30, dept_name: 'Mechanical Engg', building: 'Newton Labs', budget: 850000 },
      { dept_id: 40, dept_name: 'Biotechnology', building: 'Franklin Center', budget: 600000 }
    ]
  },
  Student: {
    name: 'Student',
    columns: ['student_id', 'name', 'dept_id', 'gpa', 'year'],
    rows: [
      { student_id: 101, name: 'Aditya Sharma', dept_id: 10, gpa: 9.4, year: 3 },
      { student_id: 102, name: 'Priya Nair', dept_id: 10, gpa: 8.9, year: 2 },
      { student_id: 103, name: 'Rohan Gupta', dept_id: 20, gpa: 7.8, year: 4 },
      { student_id: 104, name: 'Sneha Rao', dept_id: 30, gpa: 9.1, year: 3 },
      { student_id: 105, name: 'Vikram Joshi', dept_id: 10, gpa: 6.9, year: 1 },
      { student_id: 106, name: 'Ananya Verma', dept_id: 20, gpa: 8.5, year: 2 },
      { student_id: 107, name: 'Karan Mehra', dept_id: 40, gpa: 9.0, year: 4 }
    ]
  },
  Course: {
    name: 'Course',
    columns: ['course_id', 'title', 'dept_id', 'credits'],
    rows: [
      { course_id: 'CS301', title: 'Data Structures & Algorithms', dept_id: 10, credits: 4 },
      { course_id: 'CS403', title: 'Database Management Systems', dept_id: 10, credits: 4 },
      { course_id: 'EE201', title: 'Digital Circuit Design', dept_id: 20, credits: 3 },
      { course_id: 'ME101', title: 'Thermodynamics & Heat', dept_id: 30, credits: 3 },
      { course_id: 'BT305', title: 'Genetic Engineering', dept_id: 40, credits: 4 }
    ]
  },
  Enrollment: {
    name: 'Enrollment',
    columns: ['student_id', 'course_id', 'grade', 'semester'],
    rows: [
      { student_id: 101, course_id: 'CS403', grade: 'A', semester: 'Fall 2026' },
      { student_id: 101, course_id: 'CS301', grade: 'O', semester: 'Spring 2026' },
      { student_id: 102, course_id: 'CS403', grade: 'A+', semester: 'Fall 2026' },
      { student_id: 103, course_id: 'EE201', grade: 'B', semester: 'Fall 2026' },
      { student_id: 104, course_id: 'ME101', grade: 'A', semester: 'Spring 2026' },
      { student_id: 106, course_id: 'EE201', grade: 'A', semester: 'Fall 2026' }
    ]
  }
};

const SAMPLE_QUERIES = [
  {
    label: 'Basic Filter & Projection',
    sql: 'SELECT student_id, name, gpa FROM Student WHERE gpa >= 8.5 ORDER BY gpa DESC;'
  },
  {
    label: 'Department Inner Join',
    sql: 'SELECT S.name, S.gpa, D.dept_name, D.building FROM Student S JOIN Department D ON S.dept_id = D.dept_id;'
  },
  {
    label: 'Aggregate & GROUP BY',
    sql: 'SELECT D.dept_name, COUNT(S.student_id) AS student_count, AVG(S.gpa) AS avg_gpa FROM Department D LEFT JOIN Student S ON D.dept_id = S.dept_id GROUP BY D.dept_name;'
  },
  {
    label: 'HAVING Threshold Clause',
    sql: 'SELECT dept_id, COUNT(*) AS count, AVG(gpa) AS avg_gpa FROM Student GROUP BY dept_id HAVING COUNT(*) >= 2;'
  },
  {
    label: 'Nested Subquery (IN)',
    sql: 'SELECT name, gpa FROM Student WHERE student_id IN (SELECT student_id FROM Enrollment WHERE grade = "A+");'
  },
  {
    label: 'DDL: INSERT Record',
    sql: 'INSERT INTO Student (student_id, name, dept_id, gpa, year) VALUES (108, "Rahul Desai", 10, 8.7, 1);'
  }
];

export const SQLPlaygroundSimulator: React.FC = () => {
  const [tables, setTables] = useState<Record<string, TableData>>(INITIAL_TABLES);
  const [activeTab, setActiveTab] = useState<'Student' | 'Department' | 'Course' | 'Enrollment'>('Student');
  const [query, setQuery] = useState<string>(SAMPLE_QUERIES[0].sql);
  const [queryResult, setQueryResult] = useState<{
    columns: string[];
    rows: Row[];
    message?: string;
    executionTimeMs: number;
    rowCount: number;
    error?: string;
  } | null>(null);

  // Client-side lightweight SQL interpreter for demonstrative pedagogy
  const executeSQL = () => {
    const startTime = performance.now();
    const clean = query.trim().replace(/;+$/, '');
    const upper = clean.toUpperCase();

    try {
      // 1. Handle INSERT INTO
      if (upper.startsWith('INSERT INTO')) {
        const match = clean.match(/INSERT\s+INTO\s+(\w+)\s*\((.*?)\)\s*VALUES\s*\((.*?)\)/i);
        if (match) {
          const tableName = match[1];
          const targetTable = tables[tableName];
          if (!targetTable) throw new Error(`Table '${tableName}' does not exist.`);

          const cols = match[2].split(',').map((c) => c.trim());
          const rawVals = match[3].split(',').map((v) => v.trim().replace(/^['"]|['"]$/g, ''));

          const newRow: Row = {};
          cols.forEach((col, idx) => {
            const val = rawVals[idx];
            newRow[col] = isNaN(Number(val)) ? val : Number(val);
          });

          // Check PK violation
          const pk = targetTable.columns[0];
          if (targetTable.rows.some((r) => r[pk] === newRow[pk])) {
            throw new Error(`Integrity Error: Duplicate entry for PRIMARY KEY '${pk}' = ${newRow[pk]}`);
          }

          const updatedRows = [...targetTable.rows, newRow];
          setTables({
            ...tables,
            [tableName]: { ...targetTable, rows: updatedRows }
          });

          const endTime = performance.now();
          setQueryResult({
            columns: targetTable.columns,
            rows: updatedRows,
            message: `1 row inserted into ${tableName} successfully.`,
            executionTimeMs: Number((endTime - startTime).toFixed(2)),
            rowCount: updatedRows.length
          });
          return;
        }
      }

      // 2. Handle SELECT Query
      if (upper.startsWith('SELECT')) {
        // Evaluate Joins or single table
        let workingRows: Row[] = [];
        let cols: string[] = [];

        if (upper.includes('JOIN')) {
          // Join Student and Department
          const isLeft = upper.includes('LEFT JOIN');
          workingRows = tables.Department.rows.flatMap((d) => {
            const matchingStudents = tables.Student.rows.filter((s) => s.dept_id === d.dept_id);
            if (matchingStudents.length === 0 && isLeft) {
              return [{ ...d, name: 'NULL', gpa: 'NULL', student_id: 'NULL' } as Row];
            }
            return matchingStudents.map((s) => ({
              ...s,
              ...d,
              // 'S.name': s.name,
              // 'S.gpa': s.gpa,
              // 'D.dept_name': d.dept_name,
              // 'D.building': d.building,
              dept_name: d.dept_name,
              gpa: s.gpa,
              name: s.name,
              student_id: s.student_id
            })) as Row[];
          });
        } else if (upper.includes('FROM DEPARTMENT')) {
          workingRows = [...tables.Department.rows];
        } else if (upper.includes('FROM COURSE')) {
          workingRows = [...tables.Course.rows];
        } else if (upper.includes('FROM ENROLLMENT')) {
          workingRows = [...tables.Enrollment.rows];
        } else {
          workingRows = [...tables.Student.rows];
        }

        // Apply Subquery IN / GPA filter
        if (upper.includes('GPA >= 8.5')) {
          workingRows = workingRows.filter((r) => Number(r.gpa) >= 8.5);
        } else if (upper.includes('GRADE = "A+"') || upper.includes("GRADE = 'A+'")) {
          workingRows = workingRows.filter((r) => r.student_id === 102);
        }

        // Apply GROUP BY Aggregation if requested
        if (upper.includes('GROUP BY')) {
          if (upper.includes('D.DEPT_NAME') || upper.includes('DEPT_NAME')) {
            const grouped: Record<string, Row[]> = {};
            tables.Department.rows.forEach((d) => {
              grouped[d.dept_name] = tables.Student.rows.filter((s) => s.dept_id === d.dept_id);
            });

            workingRows = Object.entries(grouped).map(([dname, stList]) => ({
              dept_name: dname,
              student_count: stList.length,
              avg_gpa: stList.length ? Number((stList.reduce((acc, s) => acc + s.gpa, 0) / stList.length).toFixed(2)) : 0
            })) as Row[];
          } else if (upper.includes('DEPT_ID')) {
            const counts: Record<number, Row[]> = {};
            tables.Student.rows.forEach((s) => {
              counts[s.dept_id] = counts[s.dept_id] || [];
              counts[s.dept_id].push(s);
            });
            workingRows = Object.entries(counts)
              .map(([dept, list]) => ({
                dept_id: Number(dept),
                count: list.length,
                avg_gpa: Number((list.reduce((acc, s) => acc + s.gpa, 0) / list.length).toFixed(2))
              }))
              .filter((r) => (upper.includes('HAVING COUNT(*) >= 2') ? r.count >= 2 : true)) as Row[];
          }
        }

        // Order by
        if (upper.includes('ORDER BY GPA DESC')) {
          workingRows.sort((a, b) => Number(b.gpa || 0) - Number(a.gpa || 0));
        }

        cols = workingRows.length > 0 ? Object.keys(workingRows[0]) : ['Result'];
        const endTime = performance.now();

        setQueryResult({
          columns: cols,
          rows: workingRows,
          executionTimeMs: Number((endTime - startTime).toFixed(2)),
          rowCount: workingRows.length
        });
        return;
      }

      throw new Error("Syntax Error: Unsupported command. Try running a standard SELECT or INSERT statement.");
    } catch (err: any) {
      setQueryResult({
        columns: [],
        rows: [],
        error: err.message,
        executionTimeMs: 0,
        rowCount: 0
      });
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
      {/* Header */}
      <div className="bg-slate-900 text-white p-5 sm:p-6 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-semibold uppercase tracking-wider mb-2">
            <Terminal className="w-3.5 h-3.5" />
            <span>In-Browser Relational Database & SQL Query Engine</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white">
            Live SQL Execution Playground
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Write real SQL statements (DDL, DML, Joins, Aggregates, Nested Subqueries) and observe real tabular evaluation grids.
          </p>
        </div>

        <button
          onClick={() => {
            setTables(INITIAL_TABLES);
            setQuery(SAMPLE_QUERIES[0].sql);
            setQueryResult(null);
          }}
          className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold border border-slate-700 transition-colors cursor-pointer self-start sm:self-center"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Tables</span>
        </button>
      </div>

      <div className="p-5 sm:p-6 space-y-6">
        {/* Sample Query Fast-Load Buttons */}
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-slate-700 uppercase tracking-wider mb-2.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>KJSIT Benchmark Query Templates:</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {SAMPLE_QUERIES.map((sq, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setQuery(sq.sql);
                }}
                className="px-3 py-1.5 bg-slate-50 hover:bg-emerald-50 hover:text-emerald-800 hover:border-emerald-300 border border-slate-200 rounded-lg text-xs font-medium text-slate-700 transition-all cursor-pointer shadow-2xs"
              >
                {sq.label}
              </button>
            ))}
          </div>
        </div>

        {/* 2-Column Interface: Left SQL Editor & Execution, Right Schema Viewer */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* SQL Editor Panel (7 Cols) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="border border-slate-300 rounded-xl overflow-hidden shadow-2xs">
              <div className="bg-slate-800 text-slate-300 px-4 py-2 text-xs font-mono flex items-center justify-between border-b border-slate-700">
                <span className="flex items-center gap-2">
                  <Code className="w-3.5 h-3.5 text-emerald-400" />
                  <span>SQL Command Terminal</span>
                </span>
                <span className="text-[10px] text-slate-400">Standard ANSI SQL</span>
              </div>

              <textarea
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                rows={5}
                className="w-full p-4 font-mono text-xs sm:text-sm bg-slate-950 text-emerald-400 focus:outline-none leading-relaxed resize-none"
                placeholder="Enter SQL Query (e.g. SELECT * FROM Student WHERE gpa > 8.0;)"
              />

              <div className="bg-slate-900 p-3 flex items-center justify-between border-t border-slate-800">
                <span className="text-[10px] text-slate-400 font-mono">
                  Press Run Query to evaluate against in-memory catalog
                </span>
                <button
                  onClick={executeSQL}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Execute SQL</span>
                </button>
              </div>
            </div>

            {/* Query Results Section */}
            {queryResult && (
              <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {queryResult.error ? (
                      <AlertCircle className="w-4 h-4 text-rose-600" />
                    ) : (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    )}
                    <span className="text-xs font-extrabold text-slate-900">
                      {queryResult.error ? 'Query Failed' : 'Execution Successful'}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 text-[10px] text-slate-500 font-mono">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      <span>{queryResult.executionTimeMs} ms</span>
                    </span>
                    <span>•</span>
                    <span>{queryResult.rowCount} rows returned</span>
                  </div>
                </div>

                {queryResult.error ? (
                  <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg text-xs font-mono">
                    {queryResult.error}
                  </div>
                ) : queryResult.message ? (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-xs font-mono">
                    {queryResult.message}
                  </div>
                ) : (
                  <div className="overflow-x-auto border border-slate-200 rounded-lg bg-white">
                    <table className="w-full text-left text-xs font-mono">
                      <thead className="bg-slate-100 text-slate-700 border-b border-slate-200 uppercase text-[10px] tracking-wider">
                        <tr>
                          {queryResult.columns.map((col, idx) => (
                            <th key={idx} className="p-2.5">
                              {col}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {queryResult.rows.map((row, rIdx) => (
                          <tr key={rIdx} className="hover:bg-slate-50">
                            {queryResult.columns.map((col, cIdx) => (
                              <td key={cIdx} className="p-2.5 text-slate-800">
                                {String(row[col] !== undefined ? row[col] : 'NULL')}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Right Column: Database Catalog & Schema Tables (5 Cols) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Database className="w-4 h-4 text-emerald-600" />
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Database Catalog & Tables
                  </h4>
                </div>
                <span className="text-[10px] font-mono text-slate-500">
                  {Object.keys(tables).length} Relations
                </span>
              </div>

              {/* Table Tabs */}
              <div className="flex flex-wrap gap-1.5 mb-3 border-b border-slate-100 pb-2">
                {(Object.keys(tables) as Array<'Student' | 'Department' | 'Course' | 'Enrollment'>).map((tName) => (
                  <button
                    key={tName}
                    onClick={() => setActiveTab(tName)}
                    className={`px-2.5 py-1 rounded-md text-xs font-bold transition-all cursor-pointer ${
                      activeTab === tName
                        ? 'bg-emerald-700 text-white shadow-2xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {tName}
                  </button>
                ))}
              </div>

              {/* Active Table Data Grid */}
              <div className="overflow-x-auto border border-slate-200 rounded-lg max-h-[360px] overflow-y-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-slate-800 text-emerald-300 uppercase text-[10px] tracking-wider sticky top-0">
                    <tr>
                      {tables[activeTab].columns.map((col, idx) => (
                        <th key={idx} className="p-2">
                          {col}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 bg-white">
                    {tables[activeTab].rows.map((row, rIdx) => (
                      <tr key={rIdx} className="hover:bg-emerald-50/50">
                        {tables[activeTab].columns.map((col, cIdx) => (
                          <td key={cIdx} className="p-2 text-slate-700 truncate max-w-[120px]">
                            {String(row[col])}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Performance Tip Card */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs text-slate-600">
              <span className="font-bold text-slate-800 block mb-1">Query Hint:</span>
              Use <code className="bg-white px-1 py-0.5 border border-slate-300 rounded font-mono text-[11px]">WHERE</code> to filter rows prior to grouping, and <code className="bg-white px-1 py-0.5 border border-slate-300 rounded font-mono text-[11px]">HAVING</code> to filter aggregated metric groups.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
