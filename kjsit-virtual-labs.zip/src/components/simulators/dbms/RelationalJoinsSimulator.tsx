import React, { useState } from 'react';
import {
  GitMerge,
  Table,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  RefreshCw,
  Layers,
  Search
} from 'lucide-react';

interface Employee {
  emp_id: number;
  emp_name: string;
  dept_id: number | null;
  salary: number;
}

interface Department {
  dept_id: number;
  dept_name: string;
  location: string;
}

const EMPLOYEES: Employee[] = [
  { emp_id: 101, emp_name: 'Aditya', dept_id: 10, salary: 85000 },
  { emp_id: 102, emp_name: 'Priya', dept_id: 20, salary: 92000 },
  { emp_id: 103, emp_name: 'Rohan', dept_id: 10, salary: 64000 },
  { emp_id: 104, emp_name: 'Sneha', dept_id: 30, salary: 78000 },
  { emp_id: 105, emp_name: 'Vikram', dept_id: null, salary: 55000 } // Unassigned dept
];

const DEPARTMENTS: Department[] = [
  { dept_id: 10, dept_name: 'Engineering', location: 'Block A' },
  { dept_id: 20, dept_name: 'Research & AI', location: 'Block C' },
  { dept_id: 30, dept_name: 'Finance', location: 'Block B' },
  { dept_id: 40, dept_name: 'Human Resources', location: 'Block D' } // No employees assigned
];

export const RelationalJoinsSimulator: React.FC = () => {
  const [joinType, setJoinType] = useState<'INNER' | 'LEFT' | 'RIGHT' | 'FULL' | 'CROSS'>('INNER');
  const [hoveredDeptId, setHoveredDeptId] = useState<number | null>(null);

  // Compute Joined Rows
  const getJoinedData = () => {
    switch (joinType) {
      case 'INNER': {
        const res: any[] = [];
        EMPLOYEES.forEach((e) => {
          const d = DEPARTMENTS.find((dept) => dept.dept_id === e.dept_id);
          if (d) {
            res.push({
              emp_id: e.emp_id,
              emp_name: e.emp_name,
              dept_id: e.dept_id,
              dept_name: d.dept_name,
              location: d.location,
              salary: `$${e.salary.toLocaleString()}`
            });
          }
        });
        return res;
      }
      case 'LEFT': {
        return EMPLOYEES.map((e) => {
          const d = DEPARTMENTS.find((dept) => dept.dept_id === e.dept_id);
          return {
            emp_id: e.emp_id,
            emp_name: e.emp_name,
            dept_id: e.dept_id !== null ? e.dept_id : 'NULL',
            dept_name: d ? d.dept_name : 'NULL',
            location: d ? d.location : 'NULL',
            salary: `$${e.salary.toLocaleString()}`
          };
        });
      }
      case 'RIGHT': {
        const res: any[] = [];
        DEPARTMENTS.forEach((d) => {
          const matchedEmps = EMPLOYEES.filter((e) => e.dept_id === d.dept_id);
          if (matchedEmps.length === 0) {
            res.push({
              emp_id: 'NULL',
              emp_name: 'NULL',
              dept_id: d.dept_id,
              dept_name: d.dept_name,
              location: d.location,
              salary: 'NULL'
            });
          } else {
            matchedEmps.forEach((e) => {
              res.push({
                emp_id: e.emp_id,
                emp_name: e.emp_name,
                dept_id: d.dept_id,
                dept_name: d.dept_name,
                location: d.location,
                salary: `$${e.salary.toLocaleString()}`
              });
            });
          }
        });
        return res;
      }
      case 'FULL': {
        const leftResults: any[] = EMPLOYEES.map((e) => {
          const d = DEPARTMENTS.find((dept) => dept.dept_id === e.dept_id);
          return {
            emp_id: e.emp_id,
            emp_name: e.emp_name,
            dept_id: e.dept_id !== null ? e.dept_id : 'NULL',
            dept_name: d ? d.dept_name : 'NULL',
            location: d ? d.location : 'NULL',
            salary: `$${e.salary.toLocaleString()}`
          };
        });
        // Add unmatched departments
        DEPARTMENTS.forEach((d) => {
          const hasEmps = EMPLOYEES.some((e) => e.dept_id === d.dept_id);
          if (!hasEmps) {
            leftResults.push({
              emp_id: 'NULL',
              emp_name: 'NULL',
              dept_id: d.dept_id,
              dept_name: d.dept_name,
              location: d.location,
              salary: 'NULL'
            });
          }
        });
        return leftResults;
      }
      case 'CROSS': {
        const res: any[] = [];
        EMPLOYEES.slice(0, 3).forEach((e) => {
          DEPARTMENTS.slice(0, 2).forEach((d) => {
            res.push({
              emp_id: e.emp_id,
              emp_name: e.emp_name,
              dept_id: d.dept_id,
              dept_name: d.dept_name,
              location: d.location,
              salary: `$${e.salary.toLocaleString()}`
            });
          });
        });
        return res;
      }
      default:
        return [];
    }
  };

  const joinedData = getJoinedData();

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
      {/* Header */}
      <div className="bg-slate-900 text-white p-5 sm:p-6 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-semibold uppercase tracking-wider mb-2">
            <GitMerge className="w-3.5 h-3.5" />
            <span>Relational Joins & Set Operations Visualizer</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white">
            Relational Joins & Tuple Matching Explorer
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Compare INNER, LEFT OUTER, RIGHT OUTER, FULL OUTER, and CROSS JOIN mechanics with live tuple pairing highlights.
          </p>
        </div>
      </div>

      <div className="p-5 sm:p-6 space-y-6">
        {/* Join Selector Pills */}
        <div className="flex flex-wrap gap-2">
          {(['INNER', 'LEFT', 'RIGHT', 'FULL', 'CROSS'] as const).map((type) => (
            <button
              key={type}
              onClick={() => setJoinType(type)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                joinType === type
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-slate-50 text-slate-700 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              {type} JOIN
            </button>
          ))}
        </div>

        {/* Source Tables Grid: Table A (Employee) & Table B (Department) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
          {/* Table A */}
          <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
            <div className="bg-slate-800 text-emerald-300 p-2.5 font-bold flex justify-between">
              <span>Table A: Employee (Left)</span>
              <span className="text-[10px] text-slate-400">{EMPLOYEES.length} Rows</span>
            </div>
            <table className="w-full text-left">
              <thead className="bg-slate-100 text-slate-600 text-[10px] uppercase">
                <tr>
                  <th className="p-2">emp_id</th>
                  <th className="p-2">emp_name</th>
                  <th className="p-2">dept_id (FK)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {EMPLOYEES.map((e) => (
                  <tr
                    key={e.emp_id}
                    onMouseEnter={() => setHoveredDeptId(e.dept_id)}
                    onMouseLeave={() => setHoveredDeptId(null)}
                    className={`transition-colors cursor-pointer ${
                      hoveredDeptId === e.dept_id && e.dept_id !== null ? 'bg-emerald-100 font-bold' : 'hover:bg-slate-50'
                    }`}
                  >
                    <td className="p-2 text-slate-500">{e.emp_id}</td>
                    <td className="p-2 font-bold text-slate-900">{e.emp_name}</td>
                    <td className="p-2 text-emerald-700">
                      {e.dept_id !== null ? e.dept_id : <span className="text-rose-500 font-bold">NULL</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Table B */}
          <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
            <div className="bg-slate-800 text-blue-300 p-2.5 font-bold flex justify-between">
              <span>Table B: Department (Right)</span>
              <span className="text-[10px] text-slate-400">{DEPARTMENTS.length} Rows</span>
            </div>
            <table className="w-full text-left">
              <thead className="bg-slate-100 text-slate-600 text-[10px] uppercase">
                <tr>
                  <th className="p-2">dept_id (PK)</th>
                  <th className="p-2">dept_name</th>
                  <th className="p-2">location</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {DEPARTMENTS.map((d) => (
                  <tr
                    key={d.dept_id}
                    onMouseEnter={() => setHoveredDeptId(d.dept_id)}
                    onMouseLeave={() => setHoveredDeptId(null)}
                    className={`transition-colors cursor-pointer ${
                      hoveredDeptId === d.dept_id ? 'bg-emerald-100 font-bold' : 'hover:bg-slate-50'
                    }`}
                  >
                    <td className="p-2 text-emerald-700 font-bold">{d.dept_id}</td>
                    <td className="p-2 font-bold text-slate-900">{d.dept_name}</td>
                    <td className="p-2 text-slate-600">{d.location}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Join Results */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
              <Table className="w-4 h-4 text-emerald-600" />
              <span>Result of {joinType} JOIN (Tuple Cardinality: {joinedData.length})</span>
            </span>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-xl bg-white shadow-2xs">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-900 text-emerald-400 uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="p-2.5">emp_id</th>
                  <th className="p-2.5">emp_name</th>
                  <th className="p-2.5">dept_id</th>
                  <th className="p-2.5">dept_name</th>
                  <th className="p-2.5">location</th>
                  <th className="p-2.5">salary</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {joinedData.map((row, idx) => (
                  <tr key={idx} className="hover:bg-emerald-50/50">
                    <td className="p-2.5 text-slate-500">{String(row.emp_id)}</td>
                    <td className="p-2.5 font-bold text-slate-900">
                      {row.emp_name === 'NULL' ? <span className="text-rose-500 font-bold">NULL</span> : row.emp_name}
                    </td>
                    <td className="p-2.5 text-emerald-700">{String(row.dept_id)}</td>
                    <td className="p-2.5 text-slate-800">
                      {row.dept_name === 'NULL' ? <span className="text-rose-500 font-bold">NULL</span> : row.dept_name}
                    </td>
                    <td className="p-2.5 text-slate-600">{String(row.location)}</td>
                    <td className="p-2.5 text-slate-700">{String(row.salary)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
