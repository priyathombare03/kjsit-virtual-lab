import React, { useState } from 'react';
import {
  Database,
  ArrowRight,
  Plus,
  Trash2,
  Layers,
  Key,
  Link,
  Code,
  CheckCircle2,
  RefreshCw,
  Sparkles,
  Table,
  Cpu
} from 'lucide-react';

interface Entity {
  id: string;
  name: string;
  isWeak: boolean;
  attributes: { name: string; isPrimary: boolean; isMulti: boolean; type: string }[];
}

interface Relationship {
  id: string;
  name: string;
  entity1Id: string;
  entity2Id: string;
  cardinality: '1:1' | '1:N' | 'M:N';
}

export const ERModelingSimulator: React.FC = () => {
  const [entities, setEntities] = useState<Entity[]>([
    {
      id: 'e1',
      name: 'Department',
      isWeak: false,
      attributes: [
        { name: 'dept_id', isPrimary: true, isMulti: false, type: 'INT' },
        { name: 'dept_name', isPrimary: false, isMulti: false, type: 'VARCHAR(100)' },
        { name: 'building', isPrimary: false, isMulti: false, type: 'VARCHAR(50)' }
      ]
    },
    {
      id: 'e2',
      name: 'Student',
      isWeak: false,
      attributes: [
        { name: 'student_id', isPrimary: true, isMulti: false, type: 'INT' },
        { name: 'student_name', isPrimary: false, isMulti: false, type: 'VARCHAR(100)' },
        { name: 'email', isPrimary: false, isMulti: false, type: 'VARCHAR(100)' },
        { name: 'phone_numbers', isPrimary: false, isMulti: true, type: 'VARCHAR(15)' }
      ]
    },
    {
      id: 'e3',
      name: 'Course',
      isWeak: false,
      attributes: [
        { name: 'course_id', isPrimary: true, isMulti: false, type: 'VARCHAR(10)' },
        { name: 'title', isPrimary: false, isMulti: false, type: 'VARCHAR(100)' },
        { name: 'credits', isPrimary: false, isMulti: false, type: 'INT' }
      ]
    }
  ]);

  const [relationships, setRelationships] = useState<Relationship[]>([
    { id: 'r1', name: 'Belongs_To', entity1Id: 'e1', entity2Id: 'e2', cardinality: '1:N' },
    { id: 'r2', name: 'Enrollment', entity1Id: 'e2', entity2Id: 'e3', cardinality: 'M:N' }
  ]);

  const [selectedEntityId, setSelectedEntityId] = useState<string>('e1');
  const [newAttrName, setNewAttrName] = useState('');
  const [newAttrType, setNewAttrType] = useState('VARCHAR(50)');
  const [newAttrIsPrimary, setNewAttrIsPrimary] = useState(false);
  const [newAttrIsMulti, setNewAttrIsMulti] = useState(false);

  // Generate Relational Tables DDL
  const generateRelationalSchema = () => {
    const tables: { name: string; columns: string[]; primaryKeys: string[]; foreignKeys: string[] }[] = [];

    // 1. Map strong entities
    entities.forEach((ent) => {
      const regularAttrs = ent.attributes.filter((a) => !a.isMulti);
      const multiAttrs = ent.attributes.filter((a) => a.isMulti);
      const pks = regularAttrs.filter((a) => a.isPrimary).map((a) => a.name);

      const cols = regularAttrs.map((a) => `${a.name} ${a.type}${a.isPrimary ? ' PRIMARY KEY' : ''}`);

      // Check 1:N relationships where this entity is the 'N' side
      relationships.forEach((rel) => {
        if (rel.cardinality === '1:N' && rel.entity2Id === ent.id) {
          const parentEnt = entities.find((e) => e.id === rel.entity1Id);
          if (parentEnt) {
            const parentPk = parentEnt.attributes.find((a) => a.isPrimary);
            if (parentPk) {
              cols.push(`${parentPk.name} ${parentPk.type} /* FK -> ${parentEnt.name} */`);
            }
          }
        }
      });

      tables.push({
        name: ent.name,
        columns: cols,
        primaryKeys: pks,
        foreignKeys: []
      });

      // Multivalued attributes become separate tables
      multiAttrs.forEach((ma) => {
        const parentPk = ent.attributes.find((a) => a.isPrimary);
        if (parentPk) {
          tables.push({
            name: `${ent.name}_${ma.name}`,
            columns: [
              `${parentPk.name} ${parentPk.type}`,
              `${ma.name} ${ma.type}`
            ],
            primaryKeys: [parentPk.name, ma.name],
            foreignKeys: [`${parentPk.name} REFERENCES ${ent.name}(${parentPk.name})`]
          });
        }
      });
    });

    // 2. Map M:N relationships into junction tables
    relationships.forEach((rel) => {
      if (rel.cardinality === 'M:N') {
        const ent1 = entities.find((e) => e.id === rel.entity1Id);
        const ent2 = entities.find((e) => e.id === rel.entity2Id);
        if (ent1 && ent2) {
          const pk1 = ent1.attributes.find((a) => a.isPrimary);
          const pk2 = ent2.attributes.find((a) => a.isPrimary);
          if (pk1 && pk2) {
            tables.push({
              name: `${rel.name}_Junction`,
              columns: [
                `${pk1.name} ${pk1.type}`,
                `${pk2.name} ${pk2.type}`,
                'created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP'
              ],
              primaryKeys: [pk1.name, pk2.name],
              foreignKeys: [
                `${pk1.name} REFERENCES ${ent1.name}(${pk1.name})`,
                `${pk2.name} REFERENCES ${ent2.name}(${pk2.name})`
              ]
            });
          }
        }
      }
    });

    return tables;
  };

  const currentEntity = entities.find((e) => e.id === selectedEntityId);

  const handleAddAttribute = () => {
    if (!newAttrName.trim() || !currentEntity) return;
    const updated = entities.map((e) => {
      if (e.id === currentEntity.id) {
        return {
          ...e,
          attributes: [
            ...e.attributes,
            {
              name: newAttrName.trim().toLowerCase().replace(/\s+/g, '_'),
              type: newAttrType,
              isPrimary: newAttrIsPrimary,
              isMulti: newAttrIsMulti
            }
          ]
        };
      }
      return e;
    });
    setEntities(updated);
    setNewAttrName('');
    setNewAttrIsPrimary(false);
    setNewAttrIsMulti(false);
  };

  const handleDeleteAttribute = (attrName: string) => {
    if (!currentEntity) return;
    const updated = entities.map((e) => {
      if (e.id === currentEntity.id) {
        return {
          ...e,
          attributes: e.attributes.filter((a) => a.name !== attrName)
        };
      }
      return e;
    });
    setEntities(updated);
  };

  const schemaTables = generateRelationalSchema();

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
      {/* Header Banner */}
      <div className="bg-slate-900 text-white p-5 sm:p-6 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-semibold uppercase tracking-wider mb-2">
            <Database className="w-3.5 h-3.5" />
            <span>Interactive ER Modeler & Relational Schema Compiler</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white">
            Entity-Relationship to Relational Table Mapper
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Design conceptual ER models, customize cardinalities, and observe automated translation into 1NF/2NF relational tables with primary and foreign key constraints.
          </p>
        </div>

        <button
          onClick={() => {
            setEntities([
              {
                id: 'e1',
                name: 'Department',
                isWeak: false,
                attributes: [
                  { name: 'dept_id', isPrimary: true, isMulti: false, type: 'INT' },
                  { name: 'dept_name', isPrimary: false, isMulti: false, type: 'VARCHAR(100)' }
                ]
              },
              {
                id: 'e2',
                name: 'Student',
                isWeak: false,
                attributes: [
                  { name: 'student_id', isPrimary: true, isMulti: false, type: 'INT' },
                  { name: 'name', isPrimary: false, isMulti: false, type: 'VARCHAR(100)' }
                ]
              }
            ]);
            setRelationships([
              { id: 'r1', name: 'Belongs_To', entity1Id: 'e1', entity2Id: 'e2', cardinality: '1:N' }
            ]);
          }}
          className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold border border-slate-700 transition-colors cursor-pointer self-start sm:self-center"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Reset Model</span>
        </button>
      </div>

      <div className="p-5 sm:p-6 space-y-6">
        {/* Workspace: 2-Column Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: ER Entity & Relationship Modeler (7 cols) */}
          <div className="lg:col-span-7 space-y-5">
            <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4 text-emerald-600" />
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Entities in Conceptual Model
                  </h4>
                </div>
                <span className="text-[10px] text-slate-500 font-mono">
                  {entities.length} Entities Defined
                </span>
              </div>

              {/* Entity Selector Tabs */}
              <div className="flex flex-wrap gap-2 mb-4">
                {entities.map((ent) => (
                  <button
                    key={ent.id}
                    onClick={() => setSelectedEntityId(ent.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      selectedEntityId === ent.id
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <Table className="w-3 h-3" />
                    <span>{ent.name}</span>
                    <span className="text-[9px] opacity-80 font-mono">({ent.attributes.length} attrs)</span>
                  </button>
                ))}
              </div>

              {/* Selected Entity Attribute Inspector */}
              {currentEntity && (
                <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-2 mb-3">
                    <span className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                      Entity: <span className="text-emerald-700 font-mono">{currentEntity.name}</span>
                    </span>
                    <span className="text-[10px] px-2 py-0.5 bg-slate-100 text-slate-600 rounded font-medium">
                      Strong Entity Set
                    </span>
                  </div>

                  {/* Attribute List */}
                  <div className="space-y-1.5 mb-4">
                    {currentEntity.attributes.map((attr) => (
                      <div
                        key={attr.name}
                        className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100 text-xs"
                      >
                        <div className="flex items-center gap-2">
                          {attr.isPrimary ? (
                            <span className="px-1.5 py-0.5 bg-amber-100 text-amber-800 border border-amber-300 rounded text-[9px] font-black flex items-center gap-0.5">
                              <Key className="w-2.5 h-2.5" /> PK
                            </span>
                          ) : attr.isMulti ? (
                            <span className="px-1.5 py-0.5 bg-purple-100 text-purple-800 border border-purple-300 rounded text-[9px] font-bold">
                              Multi-Valued
                            </span>
                          ) : (
                            <span className="w-4 h-4 rounded-full bg-slate-200 text-slate-600 text-[9px] flex items-center justify-center font-bold">
                              •
                            </span>
                          )}
                          <span className="font-mono font-bold text-slate-800">{attr.name}</span>
                          <span className="text-[10px] font-mono text-slate-500">({attr.type})</span>
                        </div>

                        <button
                          onClick={() => handleDeleteAttribute(attr.name)}
                          className="text-slate-400 hover:text-rose-600 p-1 transition-colors cursor-pointer"
                          title="Delete Attribute"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>

                  {/* Add Attribute Form */}
                  <div className="pt-3 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-12 gap-2 text-xs">
                    <input
                      type="text"
                      placeholder="Attribute Name (e.g. gpa)"
                      value={newAttrName}
                      onChange={(e) => setNewAttrName(e.target.value)}
                      className="sm:col-span-4 px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                    />
                    <select
                      value={newAttrType}
                      onChange={(e) => setNewAttrType(e.target.value)}
                      className="sm:col-span-3 px-2 py-1.5 border border-slate-200 rounded-lg text-xs bg-white focus:outline-none"
                    >
                      <option value="INT">INT</option>
                      <option value="VARCHAR(50)">VARCHAR(50)</option>
                      <option value="VARCHAR(100)">VARCHAR(100)</option>
                      <option value="DECIMAL(10,2)">DECIMAL(10,2)</option>
                      <option value="DATE">DATE</option>
                    </select>

                    <div className="sm:col-span-3 flex items-center gap-2">
                      <label className="flex items-center gap-1 text-[10px] text-slate-700 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={newAttrIsPrimary}
                          onChange={(e) => setNewAttrIsPrimary(e.target.checked)}
                          className="rounded text-emerald-600"
                        />
                        <span>PK</span>
                      </label>
                      <label className="flex items-center gap-1 text-[10px] text-slate-700 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={newAttrIsMulti}
                          onChange={(e) => setNewAttrIsMulti(e.target.checked)}
                          className="rounded text-purple-600"
                        />
                        <span>Multi</span>
                      </label>
                    </div>

                    <button
                      onClick={handleAddAttribute}
                      className="sm:col-span-2 px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold flex items-center justify-center gap-1 transition-colors cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Relationships Config */}
            <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50">
              <div className="flex items-center gap-2 mb-3">
                <Link className="w-4 h-4 text-blue-600" />
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Relationships & Cardinalities
                </h4>
              </div>

              <div className="space-y-2">
                {relationships.map((rel) => {
                  const ent1 = entities.find((e) => e.id === rel.entity1Id);
                  const ent2 = entities.find((e) => e.id === rel.entity2Id);
                  return (
                    <div
                      key={rel.id}
                      className="p-3 bg-white rounded-xl border border-slate-200 flex items-center justify-between gap-3 text-xs shadow-2xs"
                    >
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono font-bold text-slate-900">{ent1?.name}</span>
                        <span className="px-2 py-0.5 bg-blue-100 text-blue-800 rounded font-mono font-bold text-[10px]">
                          [{rel.cardinality}]
                        </span>
                        <span className="text-slate-400">---( {rel.name} )---&gt;</span>
                        <span className="font-mono font-bold text-slate-900">{ent2?.name}</span>
                      </div>

                      <select
                        value={rel.cardinality}
                        onChange={(e) => {
                          const val = e.target.value as '1:1' | '1:N' | 'M:N';
                          setRelationships(
                            relationships.map((r) => (r.id === rel.id ? { ...r, cardinality: val } : r))
                          );
                        }}
                        className="px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-slate-700 cursor-pointer focus:outline-none"
                      >
                        <option value="1:1">1 : 1 (One to One)</option>
                        <option value="1:N">1 : N (One to Many)</option>
                        <option value="M:N">M : N (Many to Many)</option>
                      </select>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Column: Generated Relational Tables & DDL Code (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-slate-900 text-white rounded-xl p-4 border border-slate-800 shadow-sm">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  <h4 className="text-xs font-bold text-emerald-300 uppercase tracking-wider">
                    Compiled Relational Schema
                  </h4>
                </div>
                <span className="text-[10px] font-mono text-slate-400">
                  {schemaTables.length} Tables Generated
                </span>
              </div>

              {/* Table Schema Cards */}
              <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
                {schemaTables.map((tbl, idx) => (
                  <div
                    key={idx}
                    className="bg-slate-800/80 rounded-xl p-3.5 border border-slate-700/80 text-xs font-mono space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-black text-emerald-400 text-sm">
                        TABLE {tbl.name}
                      </span>
                      {tbl.name.includes('Junction') && (
                        <span className="px-1.5 py-0.5 bg-purple-900/60 text-purple-300 text-[9px] rounded font-bold border border-purple-700">
                          M:N Bridge
                        </span>
                      )}
                    </div>

                    <div className="space-y-1 text-slate-300 text-[11px] pl-2 border-l-2 border-emerald-500/40">
                      {tbl.columns.map((col, cIdx) => (
                        <div key={cIdx} className="truncate">
                          {col}
                        </div>
                      ))}
                    </div>

                    {tbl.primaryKeys.length > 0 && (
                      <div className="text-[10px] text-amber-300 bg-amber-950/40 px-2 py-1 rounded border border-amber-800/40">
                        PRIMARY KEY ({tbl.primaryKeys.join(', ')})
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Theoretical Rule Note */}
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 text-xs text-emerald-900">
              <span className="font-bold block mb-1">Mapping Principles Applied:</span>
              <ul className="list-disc list-inside space-y-1 text-[11px] text-emerald-800">
                <li>Binary 1:N relations embed the 1-side Primary Key as a Foreign Key in the N-side table.</li>
                <li>Binary M:N relations synthesize an independent junction table with composite Primary Keys.</li>
                <li>Multi-valued attributes generate distinct 1NF normalized tables referencing parent ID.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
