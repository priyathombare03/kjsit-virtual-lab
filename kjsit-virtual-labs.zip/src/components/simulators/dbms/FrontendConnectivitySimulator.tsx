import React, { useState } from 'react';
import {
  Database,
  Terminal,
  Play,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Server,
  Layers,
  Code,
  ShieldCheck,
  Zap,
  HardDrive,
  Users,
  Plus,
  Trash2,
  Edit2,
  Search
} from 'lucide-react';

interface StudentRecord {
  id: number;
  name: string;
  email: string;
  dept: string;
  gpa: number;
}

export const FrontendConnectivitySimulator: React.FC = () => {
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'disconnected' | 'connecting'>('connected');
  const [activeTab, setActiveTab] = useState<'ui' | 'code' | 'pool' | 'lifecycle'>('ui');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Form state
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [dept, setDept] = useState('AI & Data Science');
  const [gpa, setGpa] = useState('8.8');
  
  // Database records
  const [records, setRecords] = useState<StudentRecord[]>([
    { id: 101, name: 'Aarav Mehta', email: 'aarav.m@somaiya.edu', dept: 'AI & Data Science', gpa: 9.2 },
    { id: 102, name: 'Ananya Iyer', email: 'ananya.i@somaiya.edu', dept: 'Computer Engg', gpa: 8.9 },
    { id: 103, name: 'Rohan Sharma', email: 'rohan.s@somaiya.edu', dept: 'Information Tech', gpa: 7.8 },
    { id: 104, name: 'Tanvi Joshi', email: 'tanvi.j@somaiya.edu', dept: 'AI & Data Science', gpa: 9.5 }
  ]);

  // Activity logs
  const [logs, setLogs] = useState<Array<{ time: string; query: string; duration: string; status: 'SUCCESS' | 'ERROR' }>>([
    {
      time: '08:15:22',
      query: 'SELECT * FROM students ORDER BY id ASC;',
      duration: '1.2ms',
      status: 'SUCCESS'
    }
  ]);

  const [currentExecutingCode, setCurrentExecutingCode] = useState<string>(`# Python MySQL Connector Client
import mysql.connector

# 1. Establish secure pooled connection
conn = mysql.connector.connect(
    host="localhost",
    user="kjsit_app_user",
    password="SecureStudentDBPassword!2025",
    database="student_management_db",
    pool_name="mypool",
    pool_size=5
)
cursor = conn.cursor(dictionary=True)

# 2. Execute parameterized query (Prevents SQL Injection)
query = "SELECT id, name, email, dept, gpa FROM students ORDER BY id ASC"
cursor.execute(query)
results = cursor.fetchall()
print(f"Retrieved {len(results)} student records successfully.")

cursor.close()
conn.close()`);

  const handleAddRecord = (e: React.FormEvent) => {
    e.preventDefault();
    if (connectionStatus !== 'connected') {
      alert('Database connection is disconnected! Reconnect first.');
      return;
    }
    if (!name.trim() || !email.trim()) return;

    const newId = records.length > 0 ? Math.max(...records.map(r => r.id)) + 1 : 101;
    const newRecord: StudentRecord = {
      id: newId,
      name,
      email,
      dept,
      gpa: parseFloat(gpa) || 8.0
    };

    setRecords([...records, newRecord]);
    const now = new Date().toTimeString().split(' ')[0];
    setLogs(prev => [
      {
        time: now,
        query: `INSERT INTO students (id, name, email, dept, gpa) VALUES (${newId}, '${name}', '${email}', '${dept}', ${gpa});`,
        duration: '2.4ms',
        status: 'SUCCESS'
      },
      ...prev.slice(0, 7)
    ]);

    setCurrentExecutingCode(`# Python Front-end Connector: INSERT Operation
import mysql.connector

try:
    conn = mysql.connector.connect(host="localhost", user="kjsit_app_user", password="***", database="student_management_db")
    cursor = conn.cursor()
    
    # Secure parameterized query with tuples
    sql = "INSERT INTO students (id, name, email, dept, gpa) VALUES (%s, %s, %s, %s, %s)"
    val = (${newId}, "${name}", "${email}", "${dept}", ${gpa})
    
    cursor.execute(sql, val)
    conn.commit()  # Commit transaction to persist in MySQL storage engine
    print(f"Successfully inserted record ID: {cursor.lastrowid}")
except mysql.connector.Error as err:
    print(f"Database Error: {err}")
    conn.rollback()
finally:
    cursor.close()
    conn.close()`);

    setName('');
    setEmail('');
  };

  const handleDelete = (id: number) => {
    if (connectionStatus !== 'connected') return;
    setRecords(records.filter(r => r.id !== id));
    const now = new Date().toTimeString().split(' ')[0];
    setLogs(prev => [
      {
        time: now,
        query: `DELETE FROM students WHERE id = ${id};`,
        duration: '1.8ms',
        status: 'SUCCESS'
      },
      ...prev.slice(0, 7)
    ]);

    setCurrentExecutingCode(`# Python Front-end Connector: DELETE Operation
try:
    conn = mysql.connector.connect(host="localhost", user="kjsit_app_user", password="***", database="student_management_db")
    cursor = conn.cursor()
    
    sql = "DELETE FROM students WHERE id = %s"
    cursor.execute(sql, (${id},))
    conn.commit()
    print(f"Record {id} deleted. Affected rows: {cursor.rowcount}")
except Exception as e:
    conn.rollback()
finally:
    cursor.close()
    conn.close()`);
  };

  const handleToggleConnection = () => {
    if (connectionStatus === 'connected') {
      setConnectionStatus('disconnected');
    } else {
      setConnectionStatus('connecting');
      setTimeout(() => setConnectionStatus('connected'), 500);
    }
  };

  const filteredRecords = records.filter(r =>
    r.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    r.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    r.dept.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-white rounded-2xl border border-zinc-200 shadow-sm overflow-hidden text-zinc-900">
      {/* Header Bar */}
      <div className="bg-zinc-900 text-white p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4 border-b border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-red-600/20 border border-red-500/30 flex items-center justify-center text-red-400">
            <Server className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              Front-End Database Connectivity Simulator
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-mono border border-emerald-500/30">
                Python 3.11 + MySQL Connector
              </span>
            </h3>
            <p className="text-xs text-zinc-400">
              Interactive client-server interface demonstrating GUI CRUD operations, connection pooling, and cursor parameter binding
            </p>
          </div>
        </div>

        {/* Connection Status Pill */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleToggleConnection}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              connectionStatus === 'connected'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 hover:bg-emerald-900'
                : 'bg-red-950 text-red-300 border border-red-800 hover:bg-red-900'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${connectionStatus === 'connected' ? 'bg-emerald-400 animate-pulse' : 'bg-red-400'}`}></span>
            <span>{connectionStatus === 'connected' ? 'MySQL Connected' : 'Disconnected'}</span>
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex border-b border-zinc-200 bg-zinc-50 px-4 pt-2 gap-2 text-xs font-bold">
        <button
          onClick={() => setActiveTab('ui')}
          className={`px-3.5 py-2 border-b-2 transition-colors flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'ui' ? 'border-red-600 text-red-700 bg-white' : 'border-transparent text-zinc-600 hover:text-zinc-900'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Interactive GUI & Live Table</span>
        </button>
        <button
          onClick={() => setActiveTab('code')}
          className={`px-3.5 py-2 border-b-2 transition-colors flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'code' ? 'border-red-600 text-red-700 bg-white' : 'border-transparent text-zinc-600 hover:text-zinc-900'
          }`}
        >
          <Code className="w-3.5 h-3.5" />
          <span>Python Driver Code Execution</span>
        </button>
        <button
          onClick={() => setActiveTab('pool')}
          className={`px-3.5 py-2 border-b-2 transition-colors flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'pool' ? 'border-red-600 text-red-700 bg-white' : 'border-transparent text-zinc-600 hover:text-zinc-900'
          }`}
        >
          <HardDrive className="w-3.5 h-3.5" />
          <span>Connection Pool & Telemetry</span>
        </button>
        <button
          onClick={() => setActiveTab('lifecycle')}
          className={`px-3.5 py-2 border-b-2 transition-colors flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'lifecycle' ? 'border-red-600 text-red-700 bg-white' : 'border-transparent text-zinc-600 hover:text-zinc-900'
          }`}
        >
          <Zap className="w-3.5 h-3.5" />
          <span>Query Lifecycle Pipeline</span>
        </button>
      </div>

      {/* Main Simulator Content */}
      <div className="p-5">
        {activeTab === 'ui' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Interactive Front-End Form */}
            <div className="lg:col-span-5 bg-zinc-50 p-4 rounded-xl border border-zinc-200">
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-xs font-bold text-zinc-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Plus className="w-4 h-4 text-red-600" />
                  Front-End Form (GUI Input)
                </h4>
                <span className="text-[11px] text-zinc-500 font-mono">Tkinter / React / Flask Client</span>
              </div>

              <form onSubmit={handleAddRecord} className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-zinc-700 mb-1">Student Full Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder="e.g. Diya Sengupta"
                    className="w-full px-3 py-1.5 text-xs bg-white border border-zinc-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-red-600"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-700 mb-1">Institutional Email</label>
                  <input
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="e.g. diya.s@somaiya.edu"
                    className="w-full px-3 py-1.5 text-xs bg-white border border-zinc-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-red-600"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-zinc-700 mb-1">Department</label>
                    <select
                      value={dept}
                      onChange={e => setDept(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-zinc-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-red-600"
                    >
                      <option>AI & Data Science</option>
                      <option>Computer Engg</option>
                      <option>Information Tech</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-zinc-700 mb-1">CGPA (0.0 - 10.0)</label>
                    <input
                      type="number"
                      step="0.1"
                      min="0"
                      max="10"
                      value={gpa}
                      onChange={e => setGpa(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs bg-white border border-zinc-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-red-600"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={connectionStatus !== 'connected'}
                  className="w-full py-2 bg-red-700 hover:bg-red-800 disabled:bg-zinc-400 text-white text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Submit to Database (cursor.execute)</span>
                </button>
              </form>

              {/* Live execution code snippet preview */}
              <div className="mt-4 pt-3 border-t border-zinc-200 text-xs">
                <span className="text-[11px] font-bold text-zinc-500 block mb-1">Last Executed SQL Pipeline:</span>
                <div className="bg-zinc-900 text-zinc-200 p-2.5 rounded-lg font-mono text-[11px] overflow-x-auto">
                  {logs[0]?.query || 'Awaiting query...'}
                </div>
              </div>
            </div>

            {/* Right: Live MySQL Table & Filter */}
            <div className="lg:col-span-7 space-y-4">
              <div className="flex items-center justify-between gap-3">
                <div className="relative flex-1">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-zinc-400" />
                  <input
                    type="text"
                    placeholder="Filter records (simulating WHERE query)..."
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 text-xs bg-zinc-50 border border-zinc-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-red-600"
                  />
                </div>
                <div className="text-xs font-bold text-zinc-600">
                  Total Records: <span className="text-red-700 font-mono">{filteredRecords.length}</span>
                </div>
              </div>

              {/* Table */}
              <div className="border border-zinc-200 rounded-xl overflow-hidden shadow-2xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-zinc-100 text-zinc-700 border-b border-zinc-200 font-mono">
                    <tr>
                      <th className="p-2.5">id (PK)</th>
                      <th className="p-2.5">name</th>
                      <th className="p-2.5">email</th>
                      <th className="p-2.5">dept</th>
                      <th className="p-2.5">gpa</th>
                      <th className="p-2.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-200 bg-white">
                    {filteredRecords.map(rec => (
                      <tr key={rec.id} className="hover:bg-zinc-50 transition-colors">
                        <td className="p-2.5 font-mono font-bold text-zinc-900">{rec.id}</td>
                        <td className="p-2.5 font-semibold text-zinc-800">{rec.name}</td>
                        <td className="p-2.5 text-zinc-600 font-mono text-[11px]">{rec.email}</td>
                        <td className="p-2.5">
                          <span className="px-2 py-0.5 bg-blue-50 text-blue-700 border border-blue-200 rounded text-[10px] font-bold">
                            {rec.dept}
                          </span>
                        </td>
                        <td className="p-2.5 font-mono font-bold text-emerald-700">{rec.gpa.toFixed(1)}</td>
                        <td className="p-2.5 text-right">
                          <button
                            onClick={() => handleDelete(rec.id)}
                            className="text-red-600 hover:text-red-800 p-1 rounded hover:bg-red-50 transition-colors cursor-pointer"
                            title="DELETE record"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Logs */}
              <div className="bg-zinc-950 text-zinc-300 p-3 rounded-xl font-mono text-[11px] border border-zinc-800">
                <div className="flex items-center justify-between mb-2 text-zinc-400 font-sans font-bold text-xs">
                  <span>Server Connection Activity Log:</span>
                  <span className="text-[10px] text-emerald-400">STATUS: 200 OK</span>
                </div>
                <div className="space-y-1 max-h-24 overflow-y-auto">
                  {logs.map((log, idx) => (
                    <div key={idx} className="flex items-center justify-between text-zinc-300 border-b border-zinc-900 pb-1">
                      <span className="text-zinc-500">[{log.time}]</span>
                      <span className="truncate max-w-md text-zinc-200">{log.query}</span>
                      <span className="text-emerald-400">{log.duration}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'code' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-zinc-800 uppercase tracking-wider flex items-center gap-2">
                <Code className="w-4 h-4 text-red-600" />
                Active Python Connector Script
              </h4>
              <span className="text-xs text-zinc-500 font-mono">PEP 249 Python Database API Specification v2.0</span>
            </div>
            <div className="bg-zinc-950 text-zinc-100 p-4 rounded-xl font-mono text-xs leading-relaxed border border-zinc-900 overflow-x-auto whitespace-pre">
              {currentExecutingCode}
            </div>
          </div>
        )}

        {activeTab === 'pool' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-zinc-50 p-4 rounded-xl border border-zinc-200">
              <div className="text-xs font-bold text-zinc-500 uppercase tracking-wider mb-1">Active Connections</div>
              <div className="text-2xl font-black text-emerald-700 font-mono">1 / 5</div>
              <div className="text-[11px] text-zinc-500 mt-2">1 worker thread handling front-end web client session.</div>
            </div>
            <div className="bg-zinc-50 p-4 rounded-xl border border-zinc-200">
              <div className="text-xs font-bold text-zinc-500 uppercase tracking-wider mb-1">Average Latency</div>
              <div className="text-2xl font-black text-blue-700 font-mono">1.8 ms</div>
              <div className="text-[11px] text-zinc-500 mt-2">Local socket IPC connection to MySQL 8.0 Daemon.</div>
            </div>
            <div className="bg-zinc-50 p-4 rounded-xl border border-zinc-200">
              <div className="text-xs font-bold text-zinc-500 uppercase tracking-wider mb-1">Transaction Isolation</div>
              <div className="text-2xl font-black text-purple-700 font-mono">REPEATABLE READ</div>
              <div className="text-[11px] text-zinc-500 mt-2">InnoDB default isolation preventing dirty reads.</div>
            </div>
          </div>
        )}

        {activeTab === 'lifecycle' && (
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-zinc-800 uppercase tracking-wider">
              5-Stage Python to MySQL Query Execution Lifecycle
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
              <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200 text-center">
                <span className="w-6 h-6 rounded-full bg-red-100 text-red-700 font-bold text-xs flex items-center justify-center mx-auto mb-2 font-mono">1</span>
                <div className="text-xs font-bold text-zinc-900">Get Connection</div>
                <p className="text-[11px] text-zinc-600 mt-1">Acquire connection from connection pool</p>
              </div>
              <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200 text-center">
                <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center mx-auto mb-2 font-mono">2</span>
                <div className="text-xs font-bold text-zinc-900">Create Cursor</div>
                <p className="text-[11px] text-zinc-600 mt-1">cursor = conn.cursor(dictionary=True)</p>
              </div>
              <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200 text-center">
                <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-700 font-bold text-xs flex items-center justify-center mx-auto mb-2 font-mono">3</span>
                <div className="text-xs font-bold text-zinc-900">Bind Params</div>
                <p className="text-[11px] text-zinc-600 mt-1">Escape strings to prevent SQL Injection</p>
              </div>
              <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200 text-center">
                <span className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 font-bold text-xs flex items-center justify-center mx-auto mb-2 font-mono">4</span>
                <div className="text-xs font-bold text-zinc-900">Execute & Commit</div>
                <p className="text-[11px] text-zinc-600 mt-1">Write to WAL & commit InnoDB transaction</p>
              </div>
              <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200 text-center">
                <span className="w-6 h-6 rounded-full bg-purple-100 text-purple-700 font-bold text-xs flex items-center justify-center mx-auto mb-2 font-mono">5</span>
                <div className="text-xs font-bold text-zinc-900">Release & Close</div>
                <p className="text-[11px] text-zinc-600 mt-1">Return connection back to pool cleanly</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
