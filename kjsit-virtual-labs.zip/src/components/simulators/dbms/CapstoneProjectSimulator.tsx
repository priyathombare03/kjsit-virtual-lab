import React, { useState } from 'react';
import {
  Layers,
  Database,
  ShieldCheck,
  LayoutDashboard,
  ShoppingCart,
  CheckCircle2,
  Play,
  Key,
  Users,
  Code,
  ArrowRight,
  Sparkles,
  Search,
  Package,
  FileCheck
} from 'lucide-react';

export const CapstoneProjectSimulator: React.FC = () => {
  const [activeStage, setActiveStage] = useState<'architecture' | 'schema' | 'security' | 'app'>('app');
  const [activeRole, setActiveRole] = useState<'admin' | 'staff' | 'student'>('student');
  const [cart, setCart] = useState<Array<{ id: number; name: string; price: number; quantity: number }>>([]);
  const [orderPlaced, setOrderPlaced] = useState<string | null>(null);

  // Live Inventory
  const [inventory, setInventory] = useState([
    { id: 1, name: 'Smart IoT Soil Sensor Node', category: 'Precision Agriculture', price: 1200, stock: 15 },
    { id: 2, name: 'Automated Drip Solenoid Valve', category: 'Smart Irrigation', price: 850, stock: 22 },
    { id: 3, name: 'LoRaWAN Gateway Receiver 868MHz', category: 'Telemetry', price: 4500, stock: 6 },
    { id: 4, name: 'Solar Telemetry Battery Unit 12V', category: 'Power Systems', price: 2100, stock: 12 }
  ]);

  const addToCart = (item: typeof inventory[0]) => {
    if (item.stock <= 0) return;
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { id: item.id, name: item.name, price: item.price, quantity: 1 }];
    });
    setInventory(prev => prev.map(i => i.id === item.id ? { ...i, stock: i.stock - 1 } : i));
  };

  const handleCheckout = () => {
    if (cart.length === 0) return;
    const orderId = `ORD-2025-${Math.floor(1000 + Math.random() * 9000)}`;
    setOrderPlaced(orderId);
    setCart([]);
  };

  const cartTotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);

  return (
    <div className="bg-white rounded-2xl border border-zinc-200 shadow-sm overflow-hidden text-zinc-900">
      {/* Header */}
      <div className="bg-zinc-900 text-white p-5 flex flex-wrap items-center justify-between gap-4 border-b border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-red-600/20 border border-red-500/30 flex items-center justify-center text-red-400">
            <LayoutDashboard className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              Full-Stack Capstone Project Simulator
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 font-mono border border-blue-500/30">
                Practical 10 • Any DB + Frontend
              </span>
            </h3>
            <p className="text-xs text-zinc-400">
              End-to-End Enterprise System: ER Architecture, Relational DDL, Access Control (DCL), and Live UI
            </p>
          </div>
        </div>

        {/* Stage Pills */}
        <div className="flex items-center gap-1.5 bg-zinc-950 p-1 rounded-xl border border-zinc-800 text-xs font-semibold">
          <button
            onClick={() => setActiveStage('architecture')}
            className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
              activeStage === 'architecture' ? 'bg-red-700 text-white shadow-xs' : 'text-zinc-400 hover:text-white'
            }`}
          >
            1. Architecture
          </button>
          <button
            onClick={() => setActiveStage('schema')}
            className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
              activeStage === 'schema' ? 'bg-red-700 text-white shadow-xs' : 'text-zinc-400 hover:text-white'
            }`}
          >
            2. SQL Schema
          </button>
          <button
            onClick={() => setActiveStage('security')}
            className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
              activeStage === 'security' ? 'bg-red-700 text-white shadow-xs' : 'text-zinc-400 hover:text-white'
            }`}
          >
            3. DCL Security
          </button>
          <button
            onClick={() => setActiveStage('app')}
            className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
              activeStage === 'app' ? 'bg-red-700 text-white shadow-xs' : 'text-zinc-400 hover:text-white'
            }`}
          >
            4. Live Web App
          </button>
        </div>
      </div>

      {/* Stage 1: Architecture & Conceptual ER */}
      {activeStage === 'architecture' && (
        <div className="p-6 space-y-6">
          <div>
            <h4 className="text-sm font-bold text-zinc-900 uppercase tracking-wider mb-2 flex items-center gap-2">
              <Layers className="w-4 h-4 text-red-600" />
              Stage 1: Multi-Tier Enterprise Architecture & Conceptual Design
            </h4>
            <p className="text-xs text-zinc-600">
              The application integrates a 3-tier architecture: Presentation Layer (React/HTML5 frontend), Application Logic (Python REST API), and Relational Database Tier (MySQL 8.0 Engine).
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-zinc-50 p-4 rounded-xl border border-zinc-200">
              <div className="text-xs font-bold text-red-700 font-mono mb-1">TIER 1: FRONTEND</div>
              <h5 className="font-bold text-sm text-zinc-900 mb-1">Client Interface</h5>
              <p className="text-xs text-zinc-600">
                Responsive UI with product catalog, cart state, order placement forms, and authenticated role views.
              </p>
            </div>
            <div className="bg-zinc-50 p-4 rounded-xl border border-zinc-200">
              <div className="text-xs font-bold text-blue-700 font-mono mb-1">TIER 2: BACKEND</div>
              <h5 className="font-bold text-sm text-zinc-900 mb-1">RESTful Business API</h5>
              <p className="text-xs text-zinc-600">
                Python Flask / FastAPI service enforcing business validations, JWT authentication, and connection pooling.
              </p>
            </div>
            <div className="bg-zinc-50 p-4 rounded-xl border border-zinc-200">
              <div className="text-xs font-bold text-emerald-700 font-mono mb-1">TIER 3: DATABASE</div>
              <h5 className="font-bold text-sm text-zinc-900 mb-1">MySQL Relational Engine</h5>
              <p className="text-xs text-zinc-600">
                ACID transactional tables with InnoDB engine, B+ Tree primary/foreign indexes, and strict integrity constraints.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Stage 2: Schema & DDL */}
      {activeStage === 'schema' && (
        <div className="p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-zinc-900 uppercase tracking-wider flex items-center gap-2">
              <Database className="w-4 h-4 text-red-600" />
              Stage 2: Production Relational Schema & Constraints (DDL)
            </h4>
            <span className="text-xs text-zinc-500 font-mono">InnoDB Engine • 3NF Normalized</span>
          </div>

          <div className="bg-zinc-950 text-zinc-100 p-4 rounded-xl font-mono text-xs leading-relaxed overflow-x-auto border border-zinc-900 whitespace-pre">
{`-- Smart AgriTech Enterprise Capstone Schema
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    role ENUM('admin', 'staff', 'student') DEFAULT 'student',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    category VARCHAR(80) NOT NULL,
    price DECIMAL(10, 2) NOT NULL CHECK (price >= 0),
    stock INT NOT NULL CHECK (stock >= 0)
);

CREATE TABLE orders (
    order_id VARCHAR(30) PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    status ENUM('PENDING', 'CONFIRMED', 'DELIVERED') DEFAULT 'CONFIRMED',
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE RESTRICT
);

CREATE TABLE order_items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id VARCHAR(30) NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    unit_price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE RESTRICT
);`}
          </div>
        </div>
      )}

      {/* Stage 3: Security & Access Control */}
      {activeStage === 'security' && (
        <div className="p-6 space-y-4">
          <h4 className="text-sm font-bold text-zinc-900 uppercase tracking-wider flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-red-600" />
            Stage 3: Role-Based Access Control (DCL: GRANT & REVOKE)
          </h4>
          <p className="text-xs text-zinc-600">
            Enforcing principle of least privilege. Different database roles have distinct CRUD grants.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-red-50 p-4 rounded-xl border border-red-200">
              <div className="text-xs font-bold text-red-800 font-mono mb-2">ROLE: ADMIN</div>
              <p className="text-xs text-zinc-700 mb-3">Full schema management & user auditing</p>
              <div className="bg-zinc-900 text-zinc-100 p-2 rounded text-[10px] font-mono whitespace-pre">
                {`GRANT ALL PRIVILEGES\nON agritech_db.* \nTO 'admin_user'@'%';`}
              </div>
            </div>

            <div className="bg-blue-50 p-4 rounded-xl border border-blue-200">
              <div className="text-xs font-bold text-blue-800 font-mono mb-2">ROLE: STAFF / MANAGER</div>
              <p className="text-xs text-zinc-700 mb-3">Inventory management & order dispatch</p>
              <div className="bg-zinc-900 text-zinc-100 p-2 rounded text-[10px] font-mono whitespace-pre">
                {`GRANT SELECT, INSERT, UPDATE\nON agritech_db.products\nTO 'staff_user'@'%';`}
              </div>
            </div>

            <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-200">
              <div className="text-xs font-bold text-emerald-800 font-mono mb-2">ROLE: STUDENT / CUSTOMER</div>
              <p className="text-xs text-zinc-700 mb-3">Browse catalog & place personal orders</p>
              <div className="bg-zinc-900 text-zinc-100 p-2 rounded text-[10px] font-mono whitespace-pre">
                {`GRANT SELECT ON products\nGRANT INSERT ON orders\nTO 'customer_user'@'%';`}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Stage 4: Live Interactive Front-End App */}
      {activeStage === 'app' && (
        <div className="p-6">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-5 pb-4 border-b border-zinc-200">
            <div>
              <h4 className="text-sm font-bold text-zinc-900">
                AgriTech Precision Hardware Portal
              </h4>
              <p className="text-xs text-zinc-500">Live Client Application connected to MySQL Database</p>
            </div>

            {/* Role Switcher */}
            <div className="flex items-center gap-2 text-xs">
              <span className="font-semibold text-zinc-600">Simulate Role:</span>
              <div className="flex bg-zinc-100 p-0.5 rounded-lg border border-zinc-200">
                {(['student', 'staff', 'admin'] as const).map(role => (
                  <button
                    key={role}
                    onClick={() => setActiveRole(role)}
                    className={`px-2.5 py-1 rounded-md capitalize font-bold transition-all cursor-pointer ${
                      activeRole === role ? 'bg-white text-zinc-900 shadow-2xs' : 'text-zinc-500 hover:text-zinc-800'
                    }`}
                  >
                    {role}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {orderPlaced && (
            <div className="mb-5 p-4 rounded-xl bg-emerald-50 border border-emerald-300 flex items-center justify-between animate-fade-in">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <div>
                  <div className="text-xs font-bold text-emerald-900">
                    Order Placed Successfully! (Database Transaction Committed)
                  </div>
                  <div className="text-[11px] text-emerald-700 font-mono">
                    Tracking ID: {orderPlaced} • SQL: INSERT INTO orders VALUES (...) & COMMIT;
                  </div>
                </div>
              </div>
              <button
                onClick={() => setOrderPlaced(null)}
                className="text-xs text-emerald-800 font-bold underline cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Products List */}
            <div className="lg:col-span-8 space-y-3">
              <h5 className="text-xs font-bold text-zinc-700 uppercase tracking-wider flex items-center gap-1.5">
                <Package className="w-4 h-4 text-zinc-500" />
                Product Catalog (SELECT * FROM products)
              </h5>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {inventory.map(item => (
                  <div key={item.id} className="p-3.5 rounded-xl border border-zinc-200 bg-zinc-50 flex flex-col justify-between">
                    <div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-100 text-red-800">
                        {item.category}
                      </span>
                      <h6 className="font-bold text-xs text-zinc-900 mt-2">{item.name}</h6>
                      <div className="text-[11px] text-zinc-500 mt-1">
                        Stock remaining: <span className="font-mono font-bold text-zinc-700">{item.stock}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between mt-4 pt-3 border-t border-zinc-200">
                      <span className="font-mono font-bold text-sm text-zinc-900">₹{item.price}</span>
                      <button
                        onClick={() => addToCart(item)}
                        disabled={item.stock <= 0}
                        className="px-3 py-1 bg-red-700 hover:bg-red-800 disabled:bg-zinc-300 text-white text-xs font-bold rounded-lg transition-colors cursor-pointer"
                      >
                        {item.stock > 0 ? '+ Add to Cart' : 'Out of Stock'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Shopping Cart / Order Panel */}
            <div className="lg:col-span-4 bg-zinc-50 p-4 rounded-xl border border-zinc-200 flex flex-col justify-between">
              <div>
                <h5 className="text-xs font-bold text-zinc-800 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                  <ShoppingCart className="w-4 h-4 text-red-600" />
                  Order Cart ({cart.length} items)
                </h5>

                {cart.length === 0 ? (
                  <div className="py-8 text-center text-zinc-400 text-xs">
                    Your cart is currently empty. Select items to test full transaction flow.
                  </div>
                ) : (
                  <div className="space-y-2 mb-4 max-h-48 overflow-y-auto">
                    {cart.map(item => (
                      <div key={item.id} className="flex items-center justify-between text-xs bg-white p-2 rounded-lg border border-zinc-200">
                        <div>
                          <div className="font-semibold text-zinc-900 truncate max-w-[150px]">{item.name}</div>
                          <div className="text-[10px] text-zinc-500">Qty: {item.quantity} × ₹{item.price}</div>
                        </div>
                        <span className="font-mono font-bold text-zinc-800">₹{item.price * item.quantity}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="pt-3 border-t border-zinc-200 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-zinc-600">Subtotal</span>
                  <span className="font-mono font-bold text-zinc-900">₹{cartTotal}</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-zinc-600">GST (18%)</span>
                  <span className="font-mono font-bold text-zinc-900">₹{Math.round(cartTotal * 0.18)}</span>
                </div>
                <div className="flex items-center justify-between text-sm font-bold pt-2 border-t border-zinc-200">
                  <span>Total Amount</span>
                  <span className="text-red-700 font-mono">₹{Math.round(cartTotal * 1.18)}</span>
                </div>

                <button
                  onClick={handleCheckout}
                  disabled={cart.length === 0}
                  className="w-full py-2 bg-red-700 hover:bg-red-800 disabled:bg-zinc-300 text-white text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <FileCheck className="w-4 h-4" />
                  <span>Execute Checkout Transaction</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
