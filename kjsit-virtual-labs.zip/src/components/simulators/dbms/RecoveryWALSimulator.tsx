import React, { useState } from 'react';
import {
  ShieldAlert,
  RotateCcw,
  Play,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Database,
  Layers,
  Sparkles,
  Activity
} from 'lucide-react';

interface LogRecord {
  lsn: number;
  prevLsn: number;
  txId: string;
  type: 'START' | 'UPDATE' | 'COMMIT' | 'CHECKPOINT' | 'CLR';
  pageId?: string;
  undoNextLsn?: number;
}

export const RecoveryWALSimulator: React.FC = () => {
  const [logs] = useState<LogRecord[]>([
    { lsn: 101, prevLsn: 0, txId: 'T1', type: 'START' },
    { lsn: 102, prevLsn: 101, txId: 'T1', type: 'UPDATE', pageId: 'P1' },
    { lsn: 103, prevLsn: 0, txId: 'T2', type: 'START' },
    { lsn: 104, prevLsn: 103, txId: 'T2', type: 'UPDATE', pageId: 'P2' },
    { lsn: 105, prevLsn: 0, txId: 'SYS', type: 'CHECKPOINT' },
    { lsn: 106, prevLsn: 102, txId: 'T1', type: 'COMMIT' },
    { lsn: 107, prevLsn: 0, txId: 'T3', type: 'START' },
    { lsn: 108, prevLsn: 107, txId: 'T3', type: 'UPDATE', pageId: 'P3' }
    // CRASH OCCURS HERE! T2 and T3 were uncommitted. T1 was committed.
  ]);

  const [currentPhase, setCurrentPhase] = useState<'IDLE' | 'ANALYSIS' | 'REDO' | 'UNDO'>('IDLE');
  const [analysisResult, setAnalysisResult] = useState<{
    loserTxs: string[];
    winnerTxs: string[];
    dirtyPages: string[];
  } | null>(null);

  const [undoSteps, setUndoSteps] = useState<string[]>([]);

  // Simulate ARIES 3 Phases
  const handleRunRecovery = () => {
    // Phase 1: Analysis
    setCurrentPhase('ANALYSIS');
    const winners = ['T1'];
    const losers = ['T2', 'T3'];
    const dirty = ['P1', 'P2', 'P3'];
    setAnalysisResult({ loserTxs: losers, winnerTxs: winners, dirtyPages: dirty });

    // Phase 2: REDO (Repeating History forward from Checkpoint LSN 105)
    setTimeout(() => {
      setCurrentPhase('REDO');

      // Phase 3: UNDO (Rolling back Loser transactions T2, T3 backward)
      setTimeout(() => {
        setCurrentPhase('UNDO');
        setUndoSteps([
          'LSN 109: CLR generated for T3 (undo LSN 108 on P3)',
          'LSN 110: CLR generated for T2 (undo LSN 104 on P2)',
          'LSN 111: T3 END record written',
          'LSN 112: T2 END record written',
          'Database returned to consistent ACID state.'
        ]);
      }, 1500);
    }, 1500);
  };

  const handleReset = () => {
    setCurrentPhase('IDLE');
    setAnalysisResult(null);
    setUndoSteps([]);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
      {/* Header */}
      <div className="bg-slate-900 text-white p-5 sm:p-6 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-semibold uppercase tracking-wider mb-2">
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Database Crash Recovery & Write-Ahead Logging</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white">
            ARIES Crash Recovery Protocol & WAL Analyzer
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Simulate the 3-phase ARIES recovery algorithm (Analysis, Repeating-History REDO, and Loser-Transaction UNDO with Compensation Log Records).
          </p>
        </div>

        <button
          onClick={handleReset}
          className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold border border-slate-700 transition-colors cursor-pointer self-start sm:self-center"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset</span>
        </button>
      </div>

      <div className="p-5 sm:p-6 space-y-6">
        {/* Phase Progress Tracker */}
        <div className="grid grid-cols-3 gap-3 text-center text-xs font-bold">
          <div
            className={`p-3 rounded-xl border transition-all ${
              currentPhase === 'ANALYSIS' || currentPhase === 'REDO' || currentPhase === 'UNDO'
                ? 'bg-blue-50 border-blue-300 text-blue-900'
                : 'bg-slate-50 border-slate-200 text-slate-400'
            }`}
          >
            <span className="text-[10px] uppercase block tracking-wider">Phase 1</span>
            <span>Analysis Scan</span>
          </div>

          <div
            className={`p-3 rounded-xl border transition-all ${
              currentPhase === 'REDO' || currentPhase === 'UNDO'
                ? 'bg-amber-50 border-amber-300 text-amber-900'
                : 'bg-slate-50 border-slate-200 text-slate-400'
            }`}
          >
            <span className="text-[10px] uppercase block tracking-wider">Phase 2</span>
            <span>REDO (Repeating History)</span>
          </div>

          <div
            className={`p-3 rounded-xl border transition-all ${
              currentPhase === 'UNDO'
                ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                : 'bg-slate-50 border-slate-200 text-slate-400'
            }`}
          >
            <span className="text-[10px] uppercase block tracking-wider">Phase 3</span>
            <span>UNDO (Rollback Losers)</span>
          </div>
        </div>

        {/* Action Trigger */}
        <div className="flex items-center justify-between p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs">
          <div>
            <span className="font-bold text-slate-900 block">Simulate Power Outage / DBMS Crash</span>
            <span className="text-slate-500">
              System crashed immediately after writing LSN 108. Launch ARIES recovery.
            </span>
          </div>

          <button
            onClick={handleRunRecovery}
            disabled={currentPhase !== 'IDLE'}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-lg font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Launch ARIES Recovery</span>
          </button>
        </div>

        {/* 2-Column: Left Log Stream, Right Recovery Status */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* WAL Log Table (6 Cols) */}
          <div className="lg:col-span-6 space-y-3">
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
              Persistent Disk Write-Ahead Log (WAL)
            </span>

            <div className="overflow-x-auto border border-slate-200 rounded-xl bg-white shadow-2xs">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-800 text-emerald-300 uppercase text-[10px]">
                  <tr>
                    <th className="p-2.5">LSN</th>
                    <th className="p-2.5">PrevLSN</th>
                    <th className="p-2.5">Tx</th>
                    <th className="p-2.5">Type</th>
                    <th className="p-2.5">Page</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {logs.map((l) => (
                    <tr
                      key={l.lsn}
                      className={l.type === 'CHECKPOINT' ? 'bg-amber-50 font-bold' : 'hover:bg-slate-50'}
                    >
                      <td className="p-2.5 font-bold text-slate-800">{l.lsn}</td>
                      <td className="p-2.5 text-slate-400">{l.prevLsn}</td>
                      <td className="p-2.5 font-bold text-emerald-700">{l.txId}</td>
                      <td className="p-2.5">
                        <span
                          className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            l.type === 'COMMIT'
                              ? 'bg-emerald-100 text-emerald-800'
                              : l.type === 'CHECKPOINT'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {l.type}
                        </span>
                      </td>
                      <td className="p-2.5 text-slate-600">{l.pageId || '-'}</td>
                    </tr>
                  ))}
                  <tr className="bg-rose-50 text-rose-800 font-bold">
                    <td colSpan={5} className="p-2.5 text-center text-xs">
                      ⚡ SYSTEM CRASH & POWER FAILURE OCCURRED HERE ⚡
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Recovery Diagnostic Panel (6 Cols) */}
          <div className="lg:col-span-6 space-y-4">
            {analysisResult ? (
              <div className="space-y-4">
                {/* Transaction Table State */}
                <div className="p-4 bg-slate-900 text-white rounded-xl space-y-3 font-mono text-xs shadow-sm">
                  <span className="text-emerald-400 font-bold text-xs uppercase tracking-wider block">
                    Analysis Phase Diagnostics:
                  </span>

                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <div className="p-2.5 bg-slate-800 rounded-lg border border-slate-700">
                      <span className="text-slate-400 block text-[10px]">COMMITTED WINNERS (REDO):</span>
                      <span className="text-emerald-400 font-bold">{analysisResult.winnerTxs.join(', ')}</span>
                    </div>

                    <div className="p-2.5 bg-slate-800 rounded-lg border border-slate-700">
                      <span className="text-slate-400 block text-[10px]">ACTIVE LOSERS (UNDO):</span>
                      <span className="text-rose-400 font-bold">{analysisResult.loserTxs.join(', ')}</span>
                    </div>
                  </div>
                </div>

                {/* Undo Log CLRs */}
                {undoSteps.length > 0 && (
                  <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2 text-xs font-mono">
                    <div className="flex items-center gap-1.5 text-emerald-900 font-bold">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>UNDO Phase Compensation Records (CLRs)</span>
                    </div>
                    <div className="space-y-1 text-slate-700 text-[11px] pl-3 border-l-2 border-emerald-400">
                      {undoSteps.map((step, idx) => (
                        <div key={idx}>{step}</div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-8 text-center bg-slate-50 border border-slate-200 rounded-xl text-slate-400 text-xs">
                Click "Launch ARIES Recovery" above to start the log analyzer and observe transaction recovery in action.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
