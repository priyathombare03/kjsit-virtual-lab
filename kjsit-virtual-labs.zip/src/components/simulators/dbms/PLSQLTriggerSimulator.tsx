import React, { useState } from 'react';
import {
  Code,
  ShieldCheck,
  AlertTriangle,
  Play,
  RotateCcw,
  Sparkles,
  Terminal,
  Database,
  Table
} from 'lucide-react';

interface Account {
  account_id: number;
  owner_name: string;
  balance: number;
}

interface AuditLog {
  log_id: number;
  account_id: number;
  action: string;
  old_balance: number;
  new_balance: number;
  timestamp: string;
}

const INITIAL_ACCOUNTS: Account[] = [
  { account_id: 1001, owner_name: 'Aditya Sharma', balance: 50000 },
  { account_id: 1002, owner_name: 'Priya Nair', balance: 75000 },
  { account_id: 1003, owner_name: 'Rohan Gupta', balance: 20000 }
];

export const PLSQLTriggerSimulator: React.FC = () => {
  const [accounts, setAccounts] = useState<Account[]>(INITIAL_ACCOUNTS);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [selectedAccountId, setSelectedAccountId] = useState<number>(1001);
  const [withdrawAmount, setWithdrawAmount] = useState<number>(15000);
  const [executionMessage, setExecutionMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Trigger Simulation: BEFORE UPDATE (Checks balance >= 5000 minimum) and AFTER UPDATE (writes to AuditLog)
  const handleExecuteTransaction = () => {
    const target = accounts.find((a) => a.account_id === selectedAccountId);
    if (!target) return;

    // 1. BEFORE TRIGGER: Minimum Balance Enforcer
    const calculatedNewBalance = target.balance - withdrawAmount;
    if (calculatedNewBalance < 5000) {
      setExecutionMessage({
        type: 'error',
        text: `[ORA-20001: Trigger Check Failed] Minimum balance threshold ($5,000) violated! Transaction rolled back.`
      });
      return;
    }

    // 2. Perform Account Balance Update
    const updated = accounts.map((a) =>
      a.account_id === selectedAccountId ? { ...a, balance: calculatedNewBalance } : a
    );
    setAccounts(updated);

    // 3. AFTER TRIGGER: Insert into Audit Trail
    const newLog: AuditLog = {
      log_id: auditLogs.length + 1,
      account_id: selectedAccountId,
      action: `WITHDRAWAL (-$${withdrawAmount.toLocaleString()})`,
      old_balance: target.balance,
      new_balance: calculatedNewBalance,
      timestamp: new Date().toLocaleTimeString()
    };
    setAuditLogs([newLog, ...auditLogs]);

    setExecutionMessage({
      type: 'success',
      text: `[PL/SQL Success] Transaction committed. BEFORE trigger validated balance, AFTER trigger recorded audit entry #${newLog.log_id}.`
    });
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
      {/* Header */}
      <div className="bg-slate-900 text-white p-5 sm:p-6 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-semibold uppercase tracking-wider mb-2">
            <Code className="w-3.5 h-3.5" />
            <span>Procedural SQL Engine & Trigger State Manager</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white">
            PL/SQL Stored Procedures & Row-Level Triggers
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Experience real-time BEFORE/AFTER row triggers, cursor loops, integrity constraints, and automated audit logging.
          </p>
        </div>

        <button
          onClick={() => {
            setAccounts(INITIAL_ACCOUNTS);
            setAuditLogs([]);
            setExecutionMessage(null);
          }}
          className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold border border-slate-700 transition-colors cursor-pointer self-start sm:self-center"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset State</span>
        </button>
      </div>

      <div className="p-5 sm:p-6 space-y-6">
        {/* 2-Column Interface: Left PL/SQL Code & Trigger Controls, Right Accounts & Audit Tables */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: PL/SQL Definition & Execution Form (6 Cols) */}
          <div className="lg:col-span-6 space-y-4">
            {/* PL/SQL Trigger Definition Card */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 text-xs font-mono text-white shadow-sm space-y-2">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2 text-emerald-400 font-bold">
                <span>TRIGGER trg_account_balance_audit</span>
                <span className="text-[10px] text-slate-400">BEFORE & AFTER UPDATE</span>
              </div>
              <pre className="text-[11px] text-slate-300 overflow-x-auto leading-relaxed">
{`CREATE OR REPLACE TRIGGER trg_verify_audit
BEFORE UPDATE ON Accounts
FOR EACH ROW
BEGIN
  IF :NEW.balance < 5000 THEN
    RAISE_APPLICATION_ERROR(-20001, 'Min balance $5000 required');
  END IF;
  
  INSERT INTO Audit_Log VALUES (
    :OLD.account_id, 'UPDATE', :OLD.balance, :NEW.balance, SYSDATE
  );
END;`}
              </pre>
            </div>

            {/* Transaction Execution Form */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                Execute Bank Account Withdrawal Procedure
              </span>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Target Account:</label>
                  <select
                    value={selectedAccountId}
                    onChange={(e) => setSelectedAccountId(Number(e.target.value))}
                    className="w-full p-2 bg-white border border-slate-200 rounded-lg font-bold text-slate-800 focus:outline-none"
                  >
                    {accounts.map((a) => (
                      <option key={a.account_id} value={a.account_id}>
                        {a.account_id} - {a.owner_name} (${a.balance.toLocaleString()})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-600 font-medium mb-1">Withdrawal ($):</label>
                  <input
                    type="number"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(Number(e.target.value))}
                    step={5000}
                    className="w-full p-2 bg-white border border-slate-200 rounded-lg font-mono font-bold text-slate-800 focus:outline-none"
                  />
                </div>
              </div>

              <button
                onClick={handleExecuteTransaction}
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Execute Stored Procedure & Fire Triggers</span>
              </button>

              {executionMessage && (
                <div
                  className={`p-3 rounded-lg text-xs font-mono flex items-start gap-2 ${
                    executionMessage.type === 'success'
                      ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
                      : 'bg-rose-50 border border-rose-200 text-rose-800'
                  }`}
                >
                  {executionMessage.type === 'success' ? (
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  )}
                  <span>{executionMessage.text}</span>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Database State & Audit Log Table (6 Cols) */}
          <div className="lg:col-span-6 space-y-4">
            {/* Accounts Table */}
            <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
              <div className="bg-slate-800 text-emerald-300 p-2.5 text-xs font-bold flex justify-between">
                <span>TABLE Accounts (Master Ledger)</span>
                <span className="text-[10px] text-slate-400">{accounts.length} Records</span>
              </div>
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-100 text-slate-600 text-[10px] uppercase">
                  <tr>
                    <th className="p-2">Acc ID</th>
                    <th className="p-2">Owner</th>
                    <th className="p-2">Balance ($)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {accounts.map((a) => (
                    <tr
                      key={a.account_id}
                      className={a.account_id === selectedAccountId ? 'bg-emerald-50 font-bold' : ''}
                    >
                      <td className="p-2 text-slate-500">{a.account_id}</td>
                      <td className="p-2 text-slate-800">{a.owner_name}</td>
                      <td className="p-2 text-emerald-700 font-bold">${a.balance.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Audit Trail Table */}
            <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
              <div className="bg-slate-800 text-purple-300 p-2.5 text-xs font-bold flex justify-between">
                <span>TABLE Audit_Log (Trigger-Generated Trail)</span>
                <span className="text-[10px] text-slate-400">{auditLogs.length} Events</span>
              </div>
              {auditLogs.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-400 bg-white">
                  No trigger events fired yet. Perform a withdrawal to generate audit entries.
                </div>
              ) : (
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-slate-100 text-slate-600 text-[10px] uppercase">
                    <tr>
                      <th className="p-2">Log ID</th>
                      <th className="p-2">Action</th>
                      <th className="p-2">Old → New</th>
                      <th className="p-2">Time</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 bg-white">
                    {auditLogs.map((l) => (
                      <tr key={l.log_id} className="hover:bg-purple-50/50">
                        <td className="p-2 text-slate-500">#{l.log_id}</td>
                        <td className="p-2 font-bold text-slate-800">{l.action}</td>
                        <td className="p-2 text-slate-600">
                          ${l.old_balance.toLocaleString()} →{' '}
                          <span className="text-emerald-600 font-bold">${l.new_balance.toLocaleString()}</span>
                        </td>
                        <td className="p-2 text-slate-400">{l.timestamp}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
