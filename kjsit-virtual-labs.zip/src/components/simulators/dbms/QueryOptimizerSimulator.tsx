import React, { useState } from 'react';
import {
  Cpu,
  Zap,
  TrendingDown,
  Layers,
  ArrowRight,
  CheckCircle2,
  HardDrive,
  BarChart3
} from 'lucide-react';

export const QueryOptimizerSimulator: React.FC = () => {
  const [tableSize, setTableSize] = useState<number>(100000); // 100,000 tuples
  const [selectivity, setSelectivity] = useState<number>(2); // 2% matches
  const [joinMethod, setJoinMethod] = useState<'nested_loop' | 'hash_join' | 'merge_join'>('hash_join');
  const [hasIndex, setHasIndex] = useState<boolean>(true);

  // Cost Computations (I/O block transfers)
  const tuplesPerPage = 50;
  const numPages = Math.ceil(tableSize / tuplesPerPage); // e.g. 2000 pages for 100k tuples
  const matchedTuples = Math.ceil((tableSize * selectivity) / 100);

  // Sequential Full Table Scan Cost:
  const seqScanCost = numPages; // Reads every block once

  // Index Scan Cost (B+ Tree Height 3 + leaf lookups):
  const indexScanCost = hasIndex ? Math.ceil(3 + matchedTuples) : Infinity;

  // Selected Filter Access Method:
  const optimalScan = (hasIndex && indexScanCost < seqScanCost) ? 'B+ Tree Index Scan' : 'Sequential Table Scan';

  // Join Costs with another Table S of 20,000 tuples (400 pages)
  const tableS_Pages = 400;
  const nestedLoopCost = numPages * tableS_Pages; // Block nested loops
  const hashJoinCost = 3 * (numPages + tableS_Pages); // Partition & Probe
  const sortMergeCost = 2 * numPages * 2 + 2 * tableS_Pages * 2 + (numPages + tableS_Pages);

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
      {/* Header */}
      <div className="bg-slate-900 text-white p-5 sm:p-6 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-semibold uppercase tracking-wider mb-2">
            <Cpu className="w-3.5 h-3.5" />
            <span>Cost-Based Query Optimization & Physical Execution Plan</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white">
            Access Path & Join Cost Estimator
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Analyze physical execution plans (Sequential Scan vs B+ Index Scan, Hash Join vs Nested Loops) using disk I/O page transfer models.
          </p>
        </div>
      </div>

      <div className="p-5 sm:p-6 space-y-6">
        {/* Sliders and Parameters */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          {/* Table Cardinality */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
            <div className="flex justify-between font-bold text-slate-800">
              <span>Relation R Cardinality:</span>
              <span className="text-emerald-700 font-mono">{tableSize.toLocaleString()} rows</span>
            </div>
            <input
              type="range"
              min={10000}
              max={500000}
              step={10000}
              value={tableSize}
              onChange={(e) => setTableSize(Number(e.target.value))}
              className="w-full accent-emerald-600 cursor-pointer"
            />
            <span className="text-[10px] text-slate-500 font-mono block">
              Disk Blocks: {numPages.toLocaleString()} pages (50 rows/page)
            </span>
          </div>

          {/* Predicate Selectivity */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
            <div className="flex justify-between font-bold text-slate-800">
              <span>Predicate Selectivity:</span>
              <span className="text-blue-700 font-mono">{selectivity}%</span>
            </div>
            <input
              type="range"
              min={1}
              max={50}
              step={1}
              value={selectivity}
              onChange={(e) => setSelectivity(Number(e.target.value))}
              className="w-full accent-blue-600 cursor-pointer"
            />
            <span className="text-[10px] text-slate-500 font-mono block">
              Matching Tuples: {matchedTuples.toLocaleString()}
            </span>
          </div>

          {/* Index Existence */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2 flex flex-col justify-between">
            <div className="flex justify-between font-bold text-slate-800">
              <span>B+ Tree Index on Predicate:</span>
              <span className={hasIndex ? 'text-emerald-600 font-bold' : 'text-rose-600 font-bold'}>
                {hasIndex ? 'AVAILABLE' : 'NONE'}
              </span>
            </div>
            <button
              onClick={() => setHasIndex(!hasIndex)}
              className={`w-full py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                hasIndex ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-700'
              }`}
            >
              {hasIndex ? 'Disable Index' : 'Enable B+ Tree Index'}
            </button>
          </div>
        </div>

        {/* 2-Column Evaluation */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Filter Access Path Comparison (6 Cols) */}
          <div className="lg:col-span-6 space-y-4">
            <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-3 shadow-2xs">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                1. Single-Table Access Path Cost Comparison (Disk I/O Transfers)
              </span>

              <div className="space-y-3">
                {/* Seq Scan Bar */}
                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-slate-700 font-bold">Sequential Full Table Scan:</span>
                    <span className="font-black text-slate-900">{seqScanCost.toLocaleString()} I/Os</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
                    <div className="bg-slate-600 h-full rounded-full w-full"></div>
                  </div>
                </div>

                {/* Index Scan Bar */}
                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span className="text-slate-700 font-bold">B+ Tree Secondary Index Scan:</span>
                    <span className="font-black text-emerald-700">
                      {hasIndex ? `${indexScanCost.toLocaleString()} I/Os` : 'N/A'}
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
                    <div
                      className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                      style={{
                        width: hasIndex ? `${Math.min(100, (indexScanCost / seqScanCost) * 100)}%` : '0%'
                      }}
                    ></div>
                  </div>
                </div>
              </div>

              <div className="p-3 bg-slate-900 text-white rounded-lg text-xs font-mono flex items-center justify-between">
                <span>Optimizer Choice:</span>
                <span className="text-emerald-400 font-black">{optimalScan}</span>
              </div>
            </div>
          </div>

          {/* Right Column: Physical Join Algorithm Comparison (6 Cols) */}
          <div className="lg:col-span-6 space-y-4">
            <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-3 shadow-2xs">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                2. Physical Join Algorithms Cost (R ⋈ S)
              </span>

              <div className="space-y-2.5 text-xs font-mono">
                <div className="p-3 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-slate-900 block">Grace Hash Join</span>
                    <span className="text-[10px] text-slate-500">Cost: 3 * (B_R + B_S)</span>
                  </div>
                  <span className="text-emerald-700 font-black text-sm">{hashJoinCost.toLocaleString()} I/Os</span>
                </div>

                <div className="p-3 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-slate-900 block">Sort-Merge Join</span>
                    <span className="text-[10px] text-slate-500">2-Pass External Sort + Merge</span>
                  </div>
                  <span className="text-blue-700 font-black text-sm">{sortMergeCost.toLocaleString()} I/Os</span>
                </div>

                <div className="p-3 rounded-lg border border-rose-200 bg-rose-50 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-rose-900 block">Block Nested Loop Join</span>
                    <span className="text-[10px] text-rose-600">Cost: B_R * B_S (Exhaustive)</span>
                  </div>
                  <span className="text-rose-700 font-black text-sm">{nestedLoopCost.toLocaleString()} I/Os</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
