import React, { useState } from 'react';
import {
  Sparkles,
  Key,
  ShieldCheck,
  AlertTriangle,
  ArrowRight,
  GitMerge,
  Layers,
  CheckCircle2,
  RefreshCw,
  HelpCircle
} from 'lucide-react';

interface FD {
  lhs: string[];
  rhs: string[];
}

export const NormalizationSimulator: React.FC = () => {
  const [schemaAttrs, setSchemaAttrs] = useState<string[]>(['A', 'B', 'C', 'D', 'E']);
  const [fds, setFds] = useState<FD[]>([
    { lhs: ['A'], rhs: ['B'] },
    { lhs: ['B', 'C'], rhs: ['D'] },
    { lhs: ['D'], rhs: ['E'] }
  ]);

  const [testClosureInput, setTestClosureInput] = useState<string>('A, C');
  const [computedClosure, setComputedClosure] = useState<string[] | null>(['A', 'B', 'C', 'D', 'E']);

  // Compute Attribute Closure X+
  const computeClosureFor = (targetAttrs: string[], fdList: FD[]): string[] => {
    const closure = new Set<string>(targetAttrs);
    let changed = true;
    while (changed) {
      changed = false;
      for (const fd of fdList) {
        const lhsInClosure = fd.lhs.every((attr) => closure.has(attr));
        if (lhsInClosure) {
          for (const r of fd.rhs) {
            if (!closure.has(r)) {
              closure.add(r);
              changed = true;
            }
          }
        }
      }
    }
    return Array.from(closure).sort();
  };

  // Find all Candidate Keys
  const findCandidateKeys = () => {
    const allAttrs = [...schemaAttrs];
    const n = allAttrs.length;
    const candidateKeys: string[][] = [];

    // Check powerset of attributes sorted by size (minimal first)
    const combinations: string[][] = [];
    for (let i = 1; i < 1 << n; i++) {
      const combo: string[] = [];
      for (let j = 0; j < n; j++) {
        if (i & (1 << j)) combo.push(allAttrs[j]);
      }
      combinations.push(combo);
    }
    combinations.sort((a, b) => a.length - b.length);

    for (const combo of combinations) {
      const closure = computeClosureFor(combo, fds);
      if (closure.length === allAttrs.length) {
        // Check minimality (is any subset already a candidate key?)
        const isSuperKeyOfExisting = candidateKeys.some((ck) => ck.every((a) => combo.includes(a)));
        if (!isSuperKeyOfExisting) {
          candidateKeys.push(combo);
        }
      }
    }

    return candidateKeys;
  };

  const candidateKeys = findCandidateKeys();
  const primeAttributes = new Set<string>(candidateKeys.flat());
  const nonPrimeAttributes = schemaAttrs.filter((a) => !primeAttributes.has(a));

  // Determine Normal Form
  const analyzeNormalForms = () => {
    const results = {
      is1NF: true,
      is2NF: true,
      violations2NF: [] as string[],
      is3NF: true,
      violations3NF: [] as string[],
      isBCNF: true,
      violationsBCNF: [] as string[]
    };

    fds.forEach((fd) => {
      const lhsStr = fd.lhs.join('');
      const rhsStr = fd.rhs.join('');
      const lhsClosure = computeClosureFor(fd.lhs, fds);
      const isSuperKey = lhsClosure.length === schemaAttrs.length;

      // 2NF Check: No non-prime attribute dependent on proper subset of candidate key
      candidateKeys.forEach((ck) => {
        const isProperSubset = fd.lhs.every((a) => ck.includes(a)) && fd.lhs.length < ck.length;
        const hasNonPrimeRHS = fd.rhs.some((a) => nonPrimeAttributes.includes(a));
        if (isProperSubset && hasNonPrimeRHS) {
          results.is2NF = false;
          results.violations2NF.push(`Partial Dependency: {${lhsStr}} -> {${rhsStr}} where {${lhsStr}} is proper subset of Candidate Key {${ck.join('')}}`);
        }
      });

      // 3NF Check: For X -> Y, either X is SuperKey OR Y is Prime Attribute
      const allRHSPrime = fd.rhs.every((a) => primeAttributes.has(a));
      if (!isSuperKey && !allRHSPrime) {
        results.is3NF = false;
        results.violations3NF.push(`Transitive Dependency: {${lhsStr}} -> {${rhsStr}} (LHS is not SuperKey and RHS is not Prime)`);
      }

      // BCNF Check: For X -> Y, X must strictly be SuperKey
      if (!isSuperKey) {
        results.isBCNF = false;
        results.violationsBCNF.push(`BCNF Violation: {${lhsStr}} -> {${rhsStr}} (LHS {${lhsStr}} is not a SuperKey)`);
      }
    });

    return results;
  };

  const nfAnalysis = analyzeNormalForms();

  const handleComputeCustomClosure = () => {
    const raw = testClosureInput.split(',').map((s) => s.trim().toUpperCase()).filter(Boolean);
    const res = computeClosureFor(raw, fds);
    setComputedClosure(res);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
      {/* Header */}
      <div className="bg-slate-900 text-white p-5 sm:p-6 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-semibold uppercase tracking-wider mb-2">
            <Key className="w-3.5 h-3.5" />
            <span>Relational Normalization & Functional Dependency Engine</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white">
            Attribute Closure & Normal Form (1NF to BCNF) Analyzer
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Compute Armstrong Axiom closures, discover Candidate Keys, detect partial/transitive anomalies, and verify Lossless Decomposition.
          </p>
        </div>
      </div>

      <div className="p-5 sm:p-6 space-y-6">
        {/* Preset Schema Pickers */}
        <div className="flex flex-wrap gap-2 items-center text-xs">
          <span className="font-bold text-slate-700">Curated Academic Schemas:</span>
          <button
            onClick={() => {
              setSchemaAttrs(['A', 'B', 'C', 'D', 'E']);
              setFds([
                { lhs: ['A'], rhs: ['B'] },
                { lhs: ['B', 'C'], rhs: ['D'] },
                { lhs: ['D'], rhs: ['E'] }
              ]);
            }}
            className="px-2.5 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg font-mono font-bold hover:bg-emerald-100 cursor-pointer"
          >
            R(A,B,C,D,E) [Partial 2NF Violation]
          </button>
          <button
            onClick={() => {
              setSchemaAttrs(['Student', 'Course', 'Instructor', 'Grade']);
              setFds([
                { lhs: ['Student', 'Course'], rhs: ['Grade'] },
                { lhs: ['Course'], rhs: ['Instructor'] }
              ]);
            }}
            className="px-2.5 py-1 bg-blue-50 text-blue-800 border border-blue-200 rounded-lg font-mono font-bold hover:bg-blue-100 cursor-pointer"
          >
            University Enrollment (2NF Violation)
          </button>
          <button
            onClick={() => {
              setSchemaAttrs(['EmpID', 'DeptID', 'DeptName', 'Location']);
              setFds([
                { lhs: ['EmpID'], rhs: ['DeptID'] },
                { lhs: ['DeptID'], rhs: ['DeptName', 'Location'] }
              ]);
            }}
            className="px-2.5 py-1 bg-purple-50 text-purple-800 border border-purple-200 rounded-lg font-mono font-bold hover:bg-purple-100 cursor-pointer"
          >
            Employee Dept (3NF Transitive Violation)
          </button>
        </div>

        {/* 2-Column Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Schema, FDs and Closure Calculator (6 Cols) */}
          <div className="lg:col-span-6 space-y-4">
            {/* Schema Summary */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                Relational Schema & Functional Dependencies
              </span>
              <div className="font-mono text-sm font-black text-slate-900">
                R({schemaAttrs.join(', ')})
              </div>
              <div className="space-y-1 font-mono text-xs text-slate-700 bg-white p-2.5 rounded-lg border border-slate-200">
                {fds.map((fd, idx) => (
                  <div key={idx} className="flex items-center gap-1.5">
                    <span className="text-emerald-700 font-bold">{fd.lhs.join(', ')}</span>
                    <span className="text-slate-400">---&gt;</span>
                    <span className="text-blue-700 font-bold">{fd.rhs.join(', ')}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Custom Attribute Closure Calculator */}
            <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-3 shadow-2xs">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                Compute Attribute Closure (X+)
              </span>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={testClosureInput}
                  onChange={(e) => setTestClosureInput(e.target.value)}
                  placeholder="e.g. A, C"
                  className="flex-1 px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
                <button
                  onClick={handleComputeCustomClosure}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
                >
                  Compute X+
                </button>
              </div>

              {computedClosure && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs font-mono">
                  <span className="text-slate-600 font-bold">({testClosureInput})+ = </span>
                  <span className="text-emerald-800 font-black">
                    {`{ ${computedClosure.join(', ')} }`}
                  </span>
                  {computedClosure.length === schemaAttrs.length && (
                    <span className="ml-2 px-1.5 py-0.5 bg-emerald-200 text-emerald-900 rounded text-[10px] font-bold">
                      SUPERKEY
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* Candidate Keys & Prime Attributes */}
            <div className="p-4 bg-slate-900 text-white rounded-xl space-y-3 shadow-sm">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Key className="w-3.5 h-3.5" />
                  <span>Candidate Keys Discovered</span>
                </span>
                <span className="text-[10px] font-mono text-slate-400">
                  {candidateKeys.length} Minimal Keys
                </span>
              </div>

              <div className="flex flex-wrap gap-2">
                {candidateKeys.map((ck, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1.5 bg-amber-950/80 border border-amber-500/40 text-amber-300 rounded-lg font-mono text-xs font-black flex items-center gap-1"
                  >
                    <Key className="w-3 h-3" />
                    {`{ ${ck.join(', ')} }`}
                  </span>
                ))}
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px] font-mono pt-2 border-t border-slate-800">
                <div>
                  <span className="text-slate-400 block text-[10px]">PRIME ATTRIBUTES:</span>
                  <span className="text-emerald-400 font-bold">{Array.from(primeAttributes).join(', ') || 'None'}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">NON-PRIME ATTRIBUTES:</span>
                  <span className="text-rose-400 font-bold">{nonPrimeAttributes.join(', ') || 'None'}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Normal Form Status & Lossless Decomposition (6 Cols) */}
          <div className="lg:col-span-6 space-y-4">
            <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-3 shadow-2xs">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                Normal Form Verification Status
              </span>

              {/* Normal Form Badges */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div className="p-2.5 rounded-lg border text-center bg-emerald-50 border-emerald-200 text-emerald-900">
                  <span className="text-[10px] font-bold block">1NF</span>
                  <span className="text-xs font-black">Passed</span>
                </div>
                <div
                  className={`p-2.5 rounded-lg border text-center ${
                    nfAnalysis.is2NF
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                      : 'bg-rose-50 border-rose-200 text-rose-900'
                  }`}
                >
                  <span className="text-[10px] font-bold block">2NF</span>
                  <span className="text-xs font-black">{nfAnalysis.is2NF ? 'Passed' : 'Violated'}</span>
                </div>
                <div
                  className={`p-2.5 rounded-lg border text-center ${
                    nfAnalysis.is3NF
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                      : 'bg-rose-50 border-rose-200 text-rose-900'
                  }`}
                >
                  <span className="text-[10px] font-bold block">3NF</span>
                  <span className="text-xs font-black">{nfAnalysis.is3NF ? 'Passed' : 'Violated'}</span>
                </div>
                <div
                  className={`p-2.5 rounded-lg border text-center ${
                    nfAnalysis.isBCNF
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                      : 'bg-rose-50 border-rose-200 text-rose-900'
                  }`}
                >
                  <span className="text-[10px] font-bold block">BCNF</span>
                  <span className="text-xs font-black">{nfAnalysis.isBCNF ? 'Passed' : 'Violated'}</span>
                </div>
              </div>

              {/* Violation Details */}
              <div className="space-y-2 pt-2 text-xs">
                {nfAnalysis.violations2NF.map((v, idx) => (
                  <div key={idx} className="p-2.5 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                    <span>{v}</span>
                  </div>
                ))}
                {nfAnalysis.violations3NF.map((v, idx) => (
                  <div key={idx} className="p-2.5 bg-amber-50 border border-amber-200 text-amber-800 rounded-lg flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <span>{v}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Lossless Decomposition Tree */}
            <div className="p-4 bg-slate-900 text-white rounded-xl space-y-3 shadow-sm font-mono text-xs">
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider block">
                Recommended Lossless Decomposition (3NF / BCNF)
              </span>

              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-2 text-[11px]">
                <div className="text-amber-400 font-bold">Original: R({schemaAttrs.join(', ')})</div>
                <div className="text-slate-400 pl-3 border-l-2 border-slate-700 space-y-1">
                  <div>├── R1({fds[0]?.lhs.join('') + fds[0]?.rhs.join('')}) [PK: {fds[0]?.lhs.join('')}]</div>
                  <div>├── R2({fds[1]?.lhs.join('') + fds[1]?.rhs.join('')}) [PK: {fds[1]?.lhs.join('')}]</div>
                  <div>└── R3({schemaAttrs.filter((a) => !fds[0]?.rhs.includes(a)).join(', ')})</div>
                </div>
              </div>

              <div className="text-[11px] text-emerald-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Lossless Join Guaranteed: (R1 ∩ R2) → R1 or R2 in F+</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
