import React, { useState } from 'react';
import {
  Layers,
  Filter,
  Sparkles,
  ArrowRight,
  GitBranch,
  RefreshCw,
  CheckCircle2,
  Table,
  Cpu
} from 'lucide-react';

interface TupleR {
  id: number;
  name: string;
  dept_id: number;
  salary: number;
}

interface TupleS {
  dept_id: number;
  dept_name: string;
  building: string;
}

const TABLE_R: TupleR[] = [
  { id: 101, name: 'Aditya', dept_id: 10, salary: 85000 },
  { id: 102, name: 'Priya', dept_id: 20, salary: 92000 },
  { id: 103, name: 'Rohan', dept_id: 10, salary: 45000 },
  { id: 104, name: 'Sneha', dept_id: 30, salary: 78000 },
  { id: 105, name: 'Vikram', dept_id: 40, salary: 52000 }
];

const TABLE_S: TupleS[] = [
  { dept_id: 10, dept_name: 'Computer Science', building: 'Turing Hall' },
  { dept_id: 20, dept_name: 'Electrical Engg', building: 'Tesla Block' },
  { dept_id: 30, dept_name: 'Mechanical Engg', building: 'Newton Labs' }
];

export const RelationalAlgebraSimulator: React.FC = () => {
  const [operator, setOperator] = useState<'selection' | 'projection' | 'natural_join' | 'cartesian' | 'set_diff'>('selection');
  const [minSalary, setMinSalary] = useState<number>(60000);
  const [projectAttrs, setProjectAttrs] = useState<string[]>(['name', 'salary']);
  const [isOptimizedTree, setIsOptimizedTree] = useState<boolean>(true);

  // Compute Results dynamically
  const getResults = () => {
    switch (operator) {
      case 'selection':
        return TABLE_R.filter((r) => r.salary >= minSalary).map((r) => ({
          'id': r.id,
          'name': r.name,
          'dept_id': r.dept_id,
          'salary': `$${r.salary.toLocaleString()}`
        }));

      case 'projection':
        return TABLE_R.map((r: any) => {
          const row: any = {};
          projectAttrs.forEach((attr) => {
            row[attr] = attr === 'salary' ? `$${r[attr].toLocaleString()}` : r[attr];
          });
          return row;
        });

      case 'natural_join':
        const joined: any[] = [];
        TABLE_R.forEach((r) => {
          const matchingS = TABLE_S.find((s) => s.dept_id === r.dept_id);
          if (matchingS) {
            joined.push({
              'id': r.id,
              'name': r.name,
              'dept_id': r.dept_id,
              'dept_name': matchingS.dept_name,
              'building': matchingS.building,
              'salary': `$${r.salary.toLocaleString()}`
            });
          }
        });
        return joined;

      case 'cartesian':
        const cart: any[] = [];
        TABLE_R.slice(0, 3).forEach((r) => {
          TABLE_S.slice(0, 2).forEach((s) => {
            cart.push({
              'R.id': r.id,
              'R.name': r.name,
              'R.dept_id': r.dept_id,
              'S.dept_id': s.dept_id,
              'S.dept_name': s.dept_name
            });
          });
        });
        return cart;

      case 'set_diff':
        // Department IDs in R not in S
        const deptIdsInS = new Set(TABLE_S.map((s) => s.dept_id));
        return TABLE_R.filter((r) => !deptIdsInS.has(r.dept_id)).map((r) => ({
          'id': r.id,
          'name': r.name,
          'unmatched_dept_id': r.dept_id,
          'status': 'In R but NOT in S (Difference R - S)'
        }));

      default:
        return [];
    }
  };

  const results = getResults();
  const resultCols = results.length > 0 ? Object.keys(results[0]) : [];

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
      {/* Header */}
      <div className="bg-slate-900 text-white p-5 sm:p-6 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-semibold uppercase tracking-wider mb-2">
            <GitBranch className="w-3.5 h-3.5" />
            <span>Relational Algebra Formalisms & Heuristic Optimization</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white">
            Relational Algebra Operator & Query Tree Evaluator
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Execute formal relational algebraic operators (Selection σ, Projection π, Natural Join ⋈, Cartesian Product ×) and analyze query tree optimizations.
          </p>
        </div>
      </div>

      <div className="p-5 sm:p-6 space-y-6">
        {/* Operator Selector Pills */}
        <div className="flex flex-wrap gap-2">
          {[
            { id: 'selection', label: 'Selection σ_{salary ≥ X}(Employee)', symbol: 'σ' },
            { id: 'projection', label: 'Projection π_{attrs}(Employee)', symbol: 'π' },
            { id: 'natural_join', label: 'Natural Join Employee ⋈ Department', symbol: '⋈' },
            { id: 'cartesian', label: 'Cartesian Product Employee × Department', symbol: '×' },
            { id: 'set_diff', label: 'Set Difference (R − S)', symbol: '−' }
          ].map((op) => (
            <button
              key={op.id}
              onClick={() => setOperator(op.id as any)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                operator === op.id
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-slate-50 text-slate-700 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <span className="font-serif font-black text-sm">{op.symbol}</span>
              <span>{op.label}</span>
            </button>
          ))}
        </div>

        {/* Dynamic Controls based on chosen operator */}
        {operator === 'selection' && (
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-center gap-4 text-xs">
            <span className="font-bold text-slate-800">Threshold: Salary ≥ ${minSalary.toLocaleString()}</span>
            <input
              type="range"
              min={40000}
              max={95000}
              step={5000}
              value={minSalary}
              onChange={(e) => setMinSalary(Number(e.target.value))}
              className="w-48 accent-emerald-600 cursor-pointer"
            />
            <span className="text-slate-500 font-mono">({results.length} tuples satisfy condition)</span>
          </div>
        )}

        {operator === 'projection' && (
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-center gap-4 text-xs">
            <span className="font-bold text-slate-800">Projected Attributes:</span>
            {['id', 'name', 'dept_id', 'salary'].map((col) => (
              <label key={col} className="flex items-center gap-1.5 cursor-pointer font-mono font-bold text-slate-700">
                <input
                  type="checkbox"
                  checked={projectAttrs.includes(col)}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setProjectAttrs([...projectAttrs, col]);
                    } else if (projectAttrs.length > 1) {
                      setProjectAttrs(projectAttrs.filter((a) => a !== col));
                    }
                  }}
                  className="rounded text-emerald-600"
                />
                <span>{col}</span>
              </label>
            ))}
          </div>
        )}

        {/* 2-Column: Left Result Table, Right Query Tree */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Result Table (7 Cols) */}
          <div className="lg:col-span-7 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <Table className="w-4 h-4 text-emerald-600" />
                <span>Resulting Relation (Cardinality: {results.length})</span>
              </span>
              <span className="text-[10px] font-mono text-slate-500">Degree: {resultCols.length} Columns</span>
            </div>

            <div className="overflow-x-auto border border-slate-200 rounded-xl bg-white shadow-2xs">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-800 text-emerald-300 uppercase text-[10px] tracking-wider">
                  <tr>
                    {resultCols.map((col, idx) => (
                      <th key={idx} className="p-2.5">
                        {col}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {results.map((row, rIdx) => (
                    <tr key={rIdx} className="hover:bg-slate-50">
                      {resultCols.map((col, cIdx) => (
                        <td key={cIdx} className="p-2.5 text-slate-800">
                          {String(row[col])}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Right Query Tree Heuristics (5 Cols) */}
          <div className="lg:col-span-5 space-y-3">
            <div className="bg-slate-900 text-white rounded-xl p-4 border border-slate-800 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                  Relational Algebra Query Tree
                </span>
                <button
                  onClick={() => setIsOptimizedTree(!isOptimizedTree)}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-emerald-300 rounded text-[10px] font-mono font-bold border border-slate-700 cursor-pointer"
                >
                  {isOptimizedTree ? 'Optimized (Pushdown)' : 'Canonical (Unoptimized)'}
                </button>
              </div>

              {/* Tree Diagram ASCII Graphic */}
              <div className="p-4 bg-slate-950 rounded-lg font-mono text-xs text-emerald-300 border border-slate-800 leading-relaxed">
                {isOptimizedTree ? (
                  <div>
                    <div className="text-amber-400 font-bold">π (Project: name, dept_name)</div>
                    <div className="text-slate-500">│</div>
                    <div className="text-blue-400 font-bold">⋈ (Natural Join on dept_id)</div>
                    <div className="text-slate-500">├── σ (salary &gt; 60000) [Pushed Down Early!]</div>
                    <div className="text-slate-500">│   └── <span className="text-white font-bold">Employee</span> (5 tuples -&gt; 3 tuples)</div>
                    <div className="text-slate-500">└── <span className="text-white font-bold">Department</span> (3 tuples)</div>
                  </div>
                ) : (
                  <div>
                    <div className="text-amber-400 font-bold">π (Project: name, dept_name)</div>
                    <div className="text-slate-500">│</div>
                    <div className="text-rose-400 font-bold">σ (salary &gt; 60000 ∧ R.dept_id = S.dept_id)</div>
                    <div className="text-slate-500">│</div>
                    <div className="text-purple-400 font-bold">× (Cartesian Product R × S) [Costly: 15 tuples!]</div>
                    <div className="text-slate-500">├── <span className="text-white font-bold">Employee</span></div>
                    <div className="text-slate-500">└── <span className="text-white font-bold">Department</span></div>
                  </div>
                )}
              </div>

              <div className="text-[11px] text-slate-400 leading-relaxed">
                {isOptimizedTree ? (
                  <span className="text-emerald-400">
                    ✓ Selection σ is pushed down directly to Employee before Join, reducing intermediate tuple evaluations from 15 to 3.
                  </span>
                ) : (
                  <span className="text-rose-400">
                    ⚠ Canonical tree computes full Cartesian product first, generating unnecessary intermediate tuples.
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
