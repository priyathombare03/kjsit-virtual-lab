import React, { useState } from 'react';
import { ShoppingBag, ArrowRight, RotateCcw, CheckCircle2 } from 'lucide-react';
import { VisuAlgoCodePanel } from './common/VisuAlgoCodePanel';
import { ALGORITHM_CODES } from './common/algorithmCodes';

interface KnapsackItem {
  id: string;
  name: string;
  profit: number;
  weight: number;
  ratio: number;
}

export const FractionalKnapsackSimulator: React.FC<{ onSimulationComplete?: () => void }> = ({ onSimulationComplete }) => {
  const [capacity, setCapacity] = useState<number>(50);
  const [items, setItems] = useState<KnapsackItem[]>([
    { id: '1', name: 'Item A (Saffron / Powder)', profit: 60, weight: 10, ratio: 6.0 },
    { id: '2', name: 'Item B (Silver / Metal)', profit: 100, weight: 20, ratio: 5.0 },
    { id: '3', name: 'Item C (Copper / Ore)', profit: 120, weight: 30, ratio: 4.0 },
    { id: '4', name: 'Item D (Grain / Grain)', profit: 50, weight: 25, ratio: 2.0 },
  ]);

  // Compute Greedy Solution
  const sortedItems = [...items].sort((a, b) => (b.profit / b.weight) - (a.profit / a.weight));

  let remainingCap = capacity;
  let totalProfit = 0;
  const itemDecisions = sortedItems.map((item) => {
    const ratio = item.profit / item.weight;
    if (remainingCap <= 0) {
      return { ...item, ratio, fraction: 0, takenWeight: 0, takenProfit: 0 };
    }
    if (item.weight <= remainingCap) {
      remainingCap -= item.weight;
      totalProfit += item.profit;
      return { ...item, ratio, fraction: 1.0, takenWeight: item.weight, takenProfit: item.profit };
    } else {
      const frac = remainingCap / item.weight;
      const profitGain = item.profit * frac;
      const wtTaken = remainingCap;
      remainingCap = 0;
      totalProfit += profitGain;
      return { ...item, ratio, fraction: frac, takenWeight: wtTaken, takenProfit: profitGain };
    }
  });

  const totalWeightLoaded = capacity - remainingCap;
  const capacityUsedPercent = Math.min((totalWeightLoaded / capacity) * 100, 100);

  const fractionalItem = itemDecisions.find(d => d.fraction > 0 && d.fraction < 1.0);
  const activeLine = remainingCap === 0 ? (fractionalItem ? 5 : 3) : 2;

  const explanation = fractionalItem
    ? `Knapsack has reached limit ${capacity} kg. Greedily took fraction ${(fractionalItem.fraction * 100).toFixed(1)}% of ${fractionalItem.name}. Total Profit: ₹${totalProfit.toFixed(2)}.`
    : `Greedily selected items with highest Profit/Weight ratios. Loaded ${totalWeightLoaded.toFixed(1)} kg. Total Profit: ₹${totalProfit.toFixed(2)}.`;

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <ShoppingBag className="w-4 h-4 text-emerald-400" />
            Fractional Knapsack Greedy Optimizer
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Sorts items by Profit / Weight ratio in descending order and greedily loads maximum value
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono font-bold px-2.5 py-1 bg-emerald-950/80 text-emerald-300 rounded-md border border-emerald-500/30">
            Greedy Optimal Guarantee
          </span>
        </div>
      </div>

      {/* Main 12-Column Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left 7 cols: Interactive Visual Simulation */}
        <div className="lg:col-span-7 space-y-5">
          {/* Knapsack Capacity Slider */}
          <div className="bg-[#1E293B] p-4 rounded-xl border border-slate-700 shadow-md">
            <div className="flex flex-wrap items-center justify-between mb-2">
              <label className="text-xs font-bold text-white flex items-center gap-2">
                Knapsack Capacity (W):
                <span className="text-sm font-mono font-bold text-[#00D8FF] bg-black/40 px-2 py-0.5 rounded border border-[#00D8FF]/30">
                  {capacity} kg
                </span>
              </label>
              <span className="text-xs text-slate-400">
                Adjust slider for real-time calculation
              </span>
            </div>
            <input
              type="range"
              min="10"
              max="100"
              step="5"
              value={capacity}
              onChange={(e) => {
                setCapacity(Number(e.target.value));
                onSimulationComplete?.();
              }}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-[#00D8FF]"
            />
            <div className="flex justify-between text-[11px] text-slate-400 mt-1 font-mono">
              <span>10 kg</span>
              <span>50 kg (Default)</span>
              <span>100 kg</span>
            </div>
          </div>

          {/* Loading Meter & Profit Display */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-[#0F172A] border border-slate-800 text-white p-4 rounded-xl flex flex-col justify-between shadow-md">
              <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold font-mono">
                Total Profit
              </span>
              <div className="my-2">
                <span className="text-2xl font-black text-emerald-400 font-mono">
                  ₹{totalProfit.toFixed(2)}
                </span>
              </div>
              <span className="text-[11px] text-slate-400">
                Greedy optimal value
              </span>
            </div>

            <div className="bg-[#0F172A] border border-slate-800 text-white p-4 rounded-xl flex flex-col justify-between md:col-span-2 shadow-md">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400 uppercase tracking-wider font-semibold font-mono">
                  Weight Utilization
                </span>
                <span className="font-mono text-[#00D8FF] font-bold">
                  {totalWeightLoaded.toFixed(1)} / {capacity} kg ({capacityUsedPercent.toFixed(0)}%)
                </span>
              </div>
              {/* Progress bar */}
              <div className="w-full bg-slate-900 rounded-full h-3.5 my-2 overflow-hidden p-0.5 border border-slate-800">
                <div
                  className="bg-gradient-to-r from-emerald-500 to-[#00D8FF] h-full rounded-full transition-all duration-300"
                  style={{ width: `${capacityUsedPercent}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                <span>Empty</span>
                <span>{remainingCap > 0 ? `${remainingCap.toFixed(1)} kg space left` : 'Knapsack Full'}</span>
              </div>
            </div>
          </div>

          {/* Greedy Item Selection Table */}
          <div className="overflow-x-auto border border-slate-800 rounded-xl bg-[#0F172A] shadow-md">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#1E293B] text-slate-300 font-semibold border-b border-slate-800 uppercase tracking-wider font-mono">
                <tr>
                  <th className="py-2.5 px-3">Item</th>
                  <th className="py-2.5 px-3">Profit</th>
                  <th className="py-2.5 px-3">Weight</th>
                  <th className="py-2.5 px-3">Ratio</th>
                  <th className="py-2.5 px-3">Fraction</th>
                  <th className="py-2.5 px-3">Profit Earned</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-300 font-mono">
                {itemDecisions.map((item, idx) => {
                  const isFull = item.fraction === 1.0;
                  const isFractional = item.fraction > 0 && item.fraction < 1.0;
                  const isNone = item.fraction === 0;

                  return (
                    <tr
                      key={item.id}
                      className={`hover:bg-slate-800/50 transition-colors ${
                        isFull
                          ? 'bg-emerald-950/20'
                          : isFractional
                          ? 'bg-amber-950/20'
                          : 'opacity-50'
                      }`}
                    >
                      <td className="py-2.5 px-3 font-medium text-white flex items-center gap-1.5 font-sans">
                        <span className="w-4 h-4 rounded-full bg-slate-800 text-[#00D8FF] flex items-center justify-center font-mono text-[10px] font-bold border border-slate-700">
                          {idx + 1}
                        </span>
                        <span className="truncate max-w-[130px]">{item.name}</span>
                      </td>
                      <td className="py-2.5 px-3">₹{item.profit}</td>
                      <td className="py-2.5 px-3">{item.weight} kg</td>
                      <td className="py-2.5 px-3 font-bold text-[#00D8FF]">
                        {item.ratio.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 font-bold">
                        {(item.fraction * 100).toFixed(1)}%
                      </td>
                      <td className="py-2.5 px-3 font-bold text-emerald-400">
                        ₹{item.takenProfit.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3">
                        {isFull && (
                          <span className="px-2 py-0.5 bg-emerald-950 text-emerald-400 rounded font-semibold text-[10px] border border-emerald-800">
                            100%
                          </span>
                        )}
                        {isFractional && (
                          <span className="px-2 py-0.5 bg-amber-950 text-amber-400 rounded font-semibold text-[10px] border border-amber-800">
                            {(item.fraction * 100).toFixed(0)}%
                          </span>
                        )}
                        {isNone && (
                          <span className="px-2 py-0.5 bg-slate-800 text-slate-400 rounded font-semibold text-[10px]">
                            0%
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="bg-[#1E293B] border border-slate-800 rounded-lg p-3 text-xs text-slate-300 flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              <strong>Greedy Choice Property:</strong> Sorting items strictly by ratio <code>Profit / Weight</code> guarantees global optimality in $O(n \log n)$ time.
            </p>
          </div>
        </div>

        {/* Right 5 cols: Live VisuAlgo Code Panel */}
        <div className="lg:col-span-5 flex flex-col space-y-3">
          <VisuAlgoCodePanel
            title={ALGORITHM_CODES.fractionalKnapsack.title}
            explanation={explanation}
            codeLines={ALGORITHM_CODES.fractionalKnapsack.lines}
            activeLineIndex={activeLine}
          />
        </div>
      </div>
    </div>
  );
};
