import React, { useState } from 'react';
import { Plus, Trash2, RotateCcw, AlertCircle, CheckCircle2 } from 'lucide-react';

export const HashTableSimulator: React.FC = () => {
  const TABLE_SIZE = 10;
  const [method, setMethod] = useState<'linear' | 'quadratic' | 'chaining'>('linear');
  const [openTable, setOpenTable] = useState<(number | null)[]>([
    12, null, 22, 32, null, 15, null, null, null, null
  ]);
  const [chainTable, setChainTable] = useState<number[][]>([
    [], [], [12, 22, 32], [], [], [15], [], [], [], []
  ]);
  const [inputKey, setInputKey] = useState<string>('42');
  const [highlightIdx, setHighlightIdx] = useState<number | null>(null);
  const [collisionAlert, setCollisionAlert] = useState<string | null>(null);
  const [logs, setLogs] = useState<string[]>([
    'Hash Table initialized with size 10 (Hash Function: h(k) = k % 10)'
  ]);

  const addLog = (msg: string) => {
    setLogs((prev) => [msg, ...prev.slice(0, 5)]);
  };

  const handleInsert = () => {
    const key = parseInt(inputKey, 10);
    if (isNaN(key)) return;
    const baseIdx = key % TABLE_SIZE;

    if (method === 'chaining') {
      const newChain = [...chainTable];
      newChain[baseIdx] = [...newChain[baseIdx], key];
      setChainTable(newChain);
      setHighlightIdx(baseIdx);
      addLog(`INSERT(${key}) -> h(${key}) = ${baseIdx}. Appended to chain at bucket [${baseIdx}].`);
      setTimeout(() => setHighlightIdx(null), 1500);
      return;
    }

    // Open Addressing: Linear or Quadratic
    const newOpen = [...openTable];
    let i = 0;
    let placed = false;
    let collisionDetected = false;

    while (i < TABLE_SIZE) {
      const probeIdx =
        method === 'linear'
          ? (baseIdx + i) % TABLE_SIZE
          : (baseIdx + i * i) % TABLE_SIZE;

      if (newOpen[probeIdx] === null) {
        newOpen[probeIdx] = key;
        setOpenTable(newOpen);
        setHighlightIdx(probeIdx);
        placed = true;
        if (i > 0) {
          setCollisionAlert(`Collision at base index ${baseIdx}! Probed to slot ${probeIdx} (i=${i}).`);
          addLog(`Collision at ${baseIdx}! Probed ${i} steps -> placed key ${key} at slot ${probeIdx}.`);
        } else {
          setCollisionAlert(null);
          addLog(`INSERT(${key}) -> h(${key}) = ${baseIdx}. Placed directly in slot [${probeIdx}].`);
        }
        setTimeout(() => {
          setHighlightIdx(null);
          setCollisionAlert(null);
        }, 2000);
        break;
      } else {
        collisionDetected = true;
        i++;
      }
    }

    if (!placed) {
      addLog(`OVERFLOW: Hash table full or probing cycle exhausted for key ${key}.`);
    }
  };

  const handleReset = () => {
    setOpenTable([12, null, 22, 32, null, 15, null, null, null, null]);
    setChainTable([[], [], [12, 22, 32], [], [], [15], [], [], [], []]);
    setHighlightIdx(null);
    setCollisionAlert(null);
    setLogs(['Hash table reset.']);
  };

  return (
    <div className="space-y-6">
      {/* Mode Switcher & Controls */}
      <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-wrap gap-4 items-center justify-between border border-slate-800">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800">
            <button
              onClick={() => {
                setMethod('linear');
                handleReset();
              }}
              className={`px-3 py-1 text-xs font-bold rounded ${
                method === 'linear' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Linear Probing
            </button>
            <button
              onClick={() => {
                setMethod('quadratic');
                handleReset();
              }}
              className={`px-3 py-1 text-xs font-bold rounded ${
                method === 'quadratic' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Quadratic Probing
            </button>
            <button
              onClick={() => {
                setMethod('chaining');
                handleReset();
              }}
              className={`px-3 py-1 text-xs font-bold rounded ${
                method === 'chaining' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Separate Chaining
            </button>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-400 font-medium">Key:</span>
            <input
              type="number"
              value={inputKey}
              onChange={(e) => setInputKey(e.target.value)}
              className="w-16 bg-slate-950 text-white text-xs px-2 py-1 rounded border border-slate-700 text-center font-bold focus:outline-none"
            />
          </div>

          <button
            onClick={handleInsert}
            className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Insert Key</span>
          </button>
        </div>

        <button
          onClick={handleReset}
          className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors border border-slate-700"
          title="Reset Table"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {collisionAlert && (
        <div className="p-3 bg-amber-950/80 border border-amber-800 rounded-xl text-xs text-amber-300 font-mono flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{collisionAlert}</span>
        </div>
      )}

      {/* Visual Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2 text-xs font-mono">
          <span className="text-blue-400 font-bold uppercase">
            Hash Buckets [0..{TABLE_SIZE - 1}] | Formula: h(k) = k % {TABLE_SIZE}
          </span>
          <span className="text-slate-400">
            Strategy:{' '}
            {method === 'linear'
              ? '(h(k) + i) % m'
              : method === 'quadratic'
              ? '(h(k) + i²) % m'
              : 'Linked List Chains'}
          </span>
        </div>

        {method !== 'chaining' ? (
          /* Open Addressing Grid */
          <div className="grid grid-cols-2 sm:grid-cols-5 md:grid-cols-10 gap-2.5">
            {openTable.map((val, idx) => {
              const isOccupied = val !== null;
              const isHighlighted = highlightIdx === idx;

              return (
                <div key={idx} className="flex flex-col items-center">
                  <div
                    className={`w-full aspect-square rounded-xl flex flex-col items-center justify-center border-2 transition-all ${
                      isHighlighted
                        ? 'bg-amber-500 text-slate-950 border-amber-300 scale-105 ring-2 ring-amber-400'
                        : isOccupied
                        ? 'bg-slate-800 border-blue-500 text-white shadow-sm'
                        : 'bg-slate-950 border-slate-800 text-slate-600 border-dashed'
                    }`}
                  >
                    <span className="text-base font-mono font-bold">
                      {isOccupied ? val : '-'}
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500 mt-1">
                    Slot {idx}
                  </span>
                </div>
              );
            })}
          </div>
        ) : (
          /* Separate Chaining List */
          <div className="space-y-2">
            {chainTable.map((chain, idx) => (
              <div
                key={idx}
                className="flex items-center gap-3 p-2 bg-slate-950 rounded-lg border border-slate-800 font-mono text-xs"
              >
                <span className="w-16 px-2 py-1 bg-slate-900 border border-slate-700 rounded text-slate-400 font-bold text-center">
                  Bucket [{idx}]
                </span>
                <div className="flex items-center gap-2 flex-wrap">
                  {chain.length === 0 ? (
                    <span className="text-slate-600">null</span>
                  ) : (
                    chain.map((key, kIdx) => (
                      <React.Fragment key={kIdx}>
                        <span className="px-3 py-1 bg-blue-900 text-blue-200 border border-blue-700 rounded-md font-bold">
                          {key}
                        </span>
                        {kIdx < chain.length - 1 && (
                          <span className="text-slate-500">&rarr;</span>
                        )}
                      </React.Fragment>
                    ))
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
