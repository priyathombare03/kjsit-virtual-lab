import React, { useState, useEffect } from 'react';
import { ArrowUp, ArrowDown, Eye, RotateCcw, Play, CheckCircle2, Layers, Calculator } from 'lucide-react';
import { VisuAlgoCodePanel } from '../common/VisuAlgoCodePanel';
import { ALGORITHM_CODES } from '../common/algorithmCodes';

export const StackSimulator: React.FC<{
  initialMode?: 'stack' | 'infix';
  allowedMode?: 'stack' | 'infix';
  onSimulationComplete?: () => void;
}> = ({ initialMode = 'stack', allowedMode = initialMode, onSimulationComplete }) => {
  const [mode, setMode] = useState<'stack' | 'infix'>(allowedMode || initialMode);
  const effectiveMode = allowedMode || mode;

  useEffect(() => {
    if (initialMode) {
      setMode(initialMode);
    }
  }, [initialMode]);
  const MAX_CAPACITY = 6;

  // Basic Stack State
  const [stack, setStack] = useState<number[]>([10, 25, 40]);
  const [inputValue, setInputValue] = useState<string>('55');
  const [poppedVal, setPoppedVal] = useState<number | null>(null);
  const [peekHighlight, setPeekHighlight] = useState<boolean>(false);
  const [activeStackCodeLine, setActiveStackCodeLine] = useState<number>(-1);
  const [stackExplanation, setStackExplanation] = useState<string>(
    'Initialized Stack with 3 elements: [10, 25, 40], TOP = 2.'
  );
  const [logs, setLogs] = useState<string[]>([
    'Initialized Stack with 3 elements: [10, 25, 40], TOP = 2'
  ]);

  // Infix to Postfix State
  const [infixExpr, setInfixExpr] = useState<string>('A + B * (C - D)');
  const [infixStep, setInfixStep] = useState<number>(0);
  const [conversionStack, setConversionStack] = useState<string[]>([]);
  const [postfixResult, setPostfixResult] = useState<string>('');
  const [currentToken, setCurrentToken] = useState<string>('');
  const [conversionStepsList, setConversionStepsList] = useState<any[]>([]);

  const addLog = (msg: string) => {
    setLogs((prev) => [msg, ...prev.slice(0, 6)]);
  };

  const handlePush = () => {
    const val = parseInt(inputValue, 10);
    if (isNaN(val)) return;
    if (stack.length >= MAX_CAPACITY) {
      setActiveStackCodeLine(1); // if top >= MAX_CAPACITY - 1: return OVERFLOW
      const err = `STACK OVERFLOW! Stack has reached maximum capacity of ${MAX_CAPACITY}.`;
      setStackExplanation(err);
      addLog(err);
      return;
    }
    setStack([...stack, val]);
    setPoppedVal(null);
    setActiveStackCodeLine(3); // stack[top] = element
    const desc = `PUSH(${val}) -> Increment TOP = ${stack.length}, inserted element ${val} at index ${stack.length}.`;
    setStackExplanation(desc);
    addLog(desc);
    onSimulationComplete?.();
  };

  const handlePop = () => {
    if (stack.length === 0) {
      setActiveStackCodeLine(5); // if top < 0: return UNDERFLOW
      const err = 'STACK UNDERFLOW! Cannot pop from an empty stack (TOP == -1).';
      setStackExplanation(err);
      addLog(err);
      return;
    }
    const val = stack[stack.length - 1];
    setPoppedVal(val);
    setStack(stack.slice(0, -1));
    setActiveStackCodeLine(6); // val = stack[top]; top = top - 1
    const desc = `POP() -> Removed top element ${val} from index ${stack.length - 1}. New TOP = ${stack.length - 2}.`;
    setStackExplanation(desc);
    addLog(desc);
    onSimulationComplete?.();
  };

  const handlePeek = () => {
    if (stack.length === 0) {
      setActiveStackCodeLine(9); // if top < 0: return NULL
      const err = 'Stack is empty! Peek returns NULL.';
      setStackExplanation(err);
      addLog(err);
      return;
    }
    const topVal = stack[stack.length - 1];
    setPeekHighlight(true);
    setActiveStackCodeLine(10); // return stack[top]
    const desc = `PEEK() -> Current top element is ${topVal} at index #${stack.length - 1}.`;
    setStackExplanation(desc);
    addLog(desc);
    onSimulationComplete?.();
    setTimeout(() => setPeekHighlight(false), 1500);
  };

  const handleResetStack = () => {
    setStack([10, 25, 40]);
    setPoppedVal(null);
    setActiveStackCodeLine(-1);
    setStackExplanation('Reset stack to initial state: [10, 25, 40], TOP = 2.');
    setLogs(['Reset stack to initial state: [10, 25, 40]']);
  };

  // Infix to Postfix generator with VisuAlgo line mappings
  const prepareInfixSteps = () => {
    const expr = infixExpr.replace(/\s+/g, '');
    const steps: any[] = [];
    const st: string[] = [];
    let postfix = '';

    const prec = (op: string) => {
      if (op === '+' || op === '-') return 1;
      if (op === '*' || op === '/') return 2;
      if (op === '^') return 3;
      return 0;
    };

    steps.push({
      token: 'START',
      action: `Starting Infix to Postfix parsing for expression: "${expr}".`,
      stackState: [],
      postfixState: '',
      activeCodeLine: 0
    });

    for (let i = 0; i < expr.length; i++) {
      const ch = expr[i];
      if (/[A-Za-z0-9]/.test(ch)) {
        postfix += ch;
        steps.push({
          token: ch,
          action: `Operand '${ch}' encountered -> appended directly to output postfix expression.`,
          stackState: [...st],
          postfixState: postfix,
          activeCodeLine: 2 // output.append(token)
        });
      } else if (ch === '(') {
        st.push(ch);
        steps.push({
          token: ch,
          action: `Left parenthesis '(' encountered -> pushed onto operator stack.`,
          stackState: [...st],
          postfixState: postfix,
          activeCodeLine: 4 // stack.push(token)
        });
      } else if (ch === ')') {
        while (st.length > 0 && st[st.length - 1] !== '(') {
          const popped = st.pop()!;
          postfix += popped;
        }
        if (st.length > 0) st.pop(); // discard '('
        steps.push({
          token: ch,
          action: `Right parenthesis ')' encountered -> popped operators to output until matching '('.`,
          stackState: [...st],
          postfixState: postfix,
          activeCodeLine: 6 // while stack.top() != '(': output.append(stack.pop())
        });
      } else {
        // operator
        while (st.length > 0 && prec(st[st.length - 1]) >= prec(ch)) {
          const popped = st.pop()!;
          postfix += popped;
        }
        st.push(ch);
        steps.push({
          token: ch,
          action: `Operator '${ch}' encountered -> popped higher/equal precedence operators, then pushed '${ch}'.`,
          stackState: [...st],
          postfixState: postfix,
          activeCodeLine: 10 // output.append(stack.pop()); stack.push(token)
        });
      }
    }

    while (st.length > 0) {
      const popped = st.pop()!;
      postfix += popped;
      steps.push({
        token: 'EOF',
        action: `End of input string -> popped remaining operator '${popped}' to postfix output.`,
        stackState: [...st],
        postfixState: postfix,
        activeCodeLine: 13 // while not stack.isEmpty(): output.append(stack.pop())
      });
    }

    setConversionStepsList(steps);
    setInfixStep(0);
    if (steps.length > 0) {
      setCurrentToken(steps[0].token);
      setConversionStack(steps[0].stackState);
      setPostfixResult(steps[0].postfixState);
    }
  };

  useEffect(() => {
    prepareInfixSteps();
  }, [infixExpr]);

  const handleNextInfixStep = () => {
    if (infixStep + 1 < conversionStepsList.length) {
      const nextIdx = infixStep + 1;
      setInfixStep(nextIdx);
      const s = conversionStepsList[nextIdx];
      setCurrentToken(s.token);
      setConversionStack(s.stackState);
      setPostfixResult(s.postfixState);
    }
  };

  const handlePrevInfixStep = () => {
    if (infixStep > 0) {
      const prevIdx = infixStep - 1;
      setInfixStep(prevIdx);
      const s = conversionStepsList[prevIdx];
      setCurrentToken(s.token);
      setConversionStack(s.stackState);
      setPostfixResult(s.postfixState);
    }
  };

  const currentInfixStepObj = conversionStepsList[infixStep] || {
    action: 'Ready to parse expression.',
    activeCodeLine: 0
  };

  return (
    <div className="space-y-6">
      {/* Submode Switcher Tabs or Dedicated Mode Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          {allowedMode ? (
            <div className="px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 bg-[#0284C7] text-white shadow-md shadow-sky-950/40 border border-[#00D8FF]/40">
              {allowedMode === 'stack' ? (
                <>
                  <Layers className="w-3.5 h-3.5 text-[#00D8FF]" />
                  <span>Stack ADT Operations</span>
                </>
              ) : (
                <>
                  <Calculator className="w-3.5 h-3.5 text-[#00D8FF]" />
                  <span>Infix to Postfix Conversion</span>
                </>
              )}
            </div>
          ) : (
            <>
              <button
                onClick={() => setMode('stack')}
                className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  effectiveMode === 'stack'
                    ? 'bg-[#0284C7] text-white shadow-md shadow-sky-950/40 border border-[#00D8FF]/40'
                    : 'bg-[#1E293B] text-slate-300 hover:bg-[#334155] border border-slate-700/60'
                }`}
              >
                <Layers className="w-3.5 h-3.5 text-[#00D8FF]" />
                <span>Stack ADT Operations</span>
              </button>
              <button
                onClick={() => setMode('infix')}
                className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  effectiveMode === 'infix'
                    ? 'bg-[#0284C7] text-white shadow-md shadow-sky-950/40 border border-[#00D8FF]/40'
                    : 'bg-[#1E293B] text-slate-300 hover:bg-[#334155] border border-slate-700/60'
                }`}
              >
                <Calculator className="w-3.5 h-3.5 text-[#00D8FF]" />
                <span>Infix to Postfix Conversion</span>
              </button>
            </>
          )}
        </div>

        <span className="text-xs text-[#00D8FF] font-mono hidden sm:inline bg-[#1E293B] px-3 py-1 rounded-md border border-[#0EA5E9]/30">
          {effectiveMode === 'stack' ? 'Capacity: 6 Elements' : 'Dijkstra Shunting-Yard'}
        </span>
      </div>

      {effectiveMode === 'stack' ? (
        <>
          {/* Controls Bar */}
          <div className="bg-[#1E293B] text-white p-4 rounded-xl flex flex-wrap gap-4 items-center justify-between border border-slate-700 shadow-md">
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-1.5 bg-[#0F172A] px-3 py-1.5 rounded-lg border border-slate-700">
                <span className="text-xs text-slate-400 font-medium">Value:</span>
                <input
                  type="number"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  className="w-16 bg-[#0B1120] text-white text-xs px-2 py-1 rounded border border-[#0EA5E9]/40 text-center font-bold focus:outline-none focus:ring-1 focus:ring-[#00D8FF]"
                />
              </div>

              <button
                onClick={handlePush}
                disabled={stack.length >= MAX_CAPACITY}
                className="px-4 py-2 bg-[#0284C7] hover:bg-[#0369A1] disabled:bg-slate-800 disabled:opacity-50 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition-all shadow-sm cursor-pointer border border-[#00D8FF]/40"
              >
                <ArrowUp className="w-3.5 h-3.5 text-[#00D8FF]" />
                <span>Push</span>
              </button>

              <button
                onClick={handlePop}
                disabled={stack.length === 0}
                className="px-4 py-2 bg-[#BE123C] hover:bg-[#9F1239] disabled:bg-slate-800 disabled:opacity-50 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition-all shadow-sm cursor-pointer border border-rose-400/30"
              >
                <ArrowDown className="w-3.5 h-3.5" />
                <span>Pop</span>
              </button>

              <button
                onClick={handlePeek}
                disabled={stack.length === 0}
                className="px-3.5 py-2 bg-[#0F172A] hover:bg-[#1E293B] text-[#E2E8F0] hover:text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 border border-[#0EA5E9]/50 transition-all cursor-pointer"
              >
                <Eye className="w-3.5 h-3.5 text-[#00D8FF]" />
                <span>Peek</span>
              </button>
            </div>

            <button
              onClick={handleResetStack}
              className="p-2 bg-[#0F172A] hover:bg-[#334155] text-slate-300 hover:text-white rounded-lg transition-colors border border-slate-700 cursor-pointer"
              title="Reset Stack"
            >
              <RotateCcw className="w-4 h-4 text-[#00D8FF]" />
            </button>
          </div>

          {/* Stack Container & VisuAlgo Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Visual Bucket */}
            <div className="lg:col-span-4 bg-[#0F172A] border border-slate-800 rounded-2xl p-6 flex flex-col items-center justify-center min-h-[340px] shadow-lg">
              <div className="w-full max-w-[240px] flex flex-col items-center">
                <span className="text-xs font-mono font-bold text-[#00D8FF] mb-2 uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-[#00D8FF]"></span>
                  Top of Stack (LIFO)
                </span>

                {/* Stack Box Container */}
                <div className="w-full h-64 border-x-4 border-b-4 border-slate-700 rounded-b-xl flex flex-col-reverse p-2.5 gap-1.5 bg-[#0B1120] relative shadow-inner">
                  {stack.length === 0 ? (
                    <div className="h-full flex items-center justify-center text-slate-500 font-mono text-xs italic">
                      Stack is EMPTY (TOP = -1)
                    </div>
                  ) : (
                    stack.map((item, idx) => {
                      const isTop = idx === stack.length - 1;
                      return (
                        <div
                          key={idx}
                          className={`w-full py-2.5 rounded-lg font-mono font-bold text-center text-sm transition-all duration-300 flex items-center justify-between px-3 ${
                            isTop && peekHighlight
                              ? 'bg-[#00D8FF] text-slate-950 scale-105 ring-2 ring-cyan-300 shadow-[0_0_12px_rgba(0,216,255,0.6)] font-black'
                              : isTop
                              ? 'bg-[#0284C7] text-white shadow-md border border-[#00D8FF]/50'
                              : 'bg-[#1E293B] text-slate-200 border border-slate-700'
                          }`}
                        >
                          <span className="text-[10px] opacity-75 text-cyan-200">[{idx}]</span>
                          <span className="tracking-wider">{item}</span>
                          {isTop && (
                            <span className="text-[9px] bg-white/20 text-white px-1.5 py-0.5 rounded uppercase font-bold tracking-wider">
                              TOP
                            </span>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>

                <div className="w-full flex justify-between text-[11px] font-mono text-slate-400 mt-2 px-1">
                  <span>Capacity: {stack.length}/{MAX_CAPACITY}</span>
                  <span className={stack.length >= MAX_CAPACITY ? 'text-rose-400 font-bold' : 'text-[#00D8FF]'}>
                    {stack.length >= MAX_CAPACITY ? 'OVERFLOW' : stack.length === 0 ? 'UNDERFLOW' : 'NORMAL'}
                  </span>
                </div>
              </div>
            </div>

            {/* Pointer & Metrics Panel */}
            <div className="lg:col-span-3 bg-[#0F172A] border border-slate-800 rounded-2xl p-5 flex flex-col justify-between min-h-[340px] shadow-lg">
              <div>
                <h4 className="text-xs font-bold text-[#00D8FF] uppercase tracking-wider mb-3 border-b border-slate-800 pb-2">
                  Stack Metrics
                </h4>
                <div className="space-y-2.5 font-mono text-xs">
                  <div className="flex justify-between bg-[#1E293B] p-2.5 rounded-lg border border-slate-700/80">
                    <span className="text-slate-400">TOP Index:</span>
                    <span className="text-[#00D8FF] font-bold">{stack.length - 1}</span>
                  </div>
                  <div className="flex justify-between bg-[#1E293B] p-2.5 rounded-lg border border-slate-700/80">
                    <span className="text-slate-400">TOP Value:</span>
                    <span className="text-[#00D8FF] font-bold">
                      {stack.length > 0 ? stack[stack.length - 1] : 'NULL'}
                    </span>
                  </div>
                  <div className="flex justify-between bg-[#1E293B] p-2.5 rounded-lg border border-slate-700/80">
                    <span className="text-slate-400">Last Popped:</span>
                    <span className="text-amber-400 font-bold">
                      {poppedVal !== null ? poppedVal : 'None'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Execution Trace */}
              <div className="bg-[#0B1120] border border-slate-800 rounded-xl p-3 mt-3">
                <span className="text-[10px] text-[#00D8FF] uppercase font-bold block mb-1">
                  Trace Log
                </span>
                <div className="space-y-1 text-xs font-mono text-slate-300">
                  {logs.slice(0, 3).map((l, i) => (
                    <div key={i} className="truncate text-slate-300">
                      &gt; {l}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* VisuAlgo Code Panel */}
            <div className="lg:col-span-5">
              <VisuAlgoCodePanel
                title="Stack ADT Operations"
                explanation={stackExplanation}
                codeLines={ALGORITHM_CODES.stackADT.lines}
                activeLineIndex={activeStackCodeLine}
              />
            </div>
          </div>
        </>
      ) : (
        /* Infix to Postfix Submode */
        <div className="space-y-6">
          <div className="flex flex-wrap items-center gap-3 bg-[#1E293B] border border-slate-700 p-4 rounded-xl shadow-md">
            <div className="flex-1 min-w-[200px] flex items-center gap-2 bg-[#0F172A] px-3 py-2 rounded-lg border border-slate-700">
              <span className="text-xs text-slate-400 font-medium">Infix:</span>
              <input
                type="text"
                value={infixExpr}
                onChange={(e) => setInfixExpr(e.target.value)}
                className="w-full bg-transparent text-white font-mono text-xs focus:outline-none"
                placeholder="e.g. A + B * (C - D)"
              />
            </div>
            <button
              onClick={prepareInfixSteps}
              className="px-4 py-2 bg-[#0F172A] hover:bg-[#334155] text-white text-xs font-bold rounded-lg transition-colors cursor-pointer border border-slate-700"
            >
              Parse Expression
            </button>
            <div className="flex items-center gap-2">
              <button
                onClick={handlePrevInfixStep}
                disabled={infixStep <= 0}
                className="px-3.5 py-2 bg-[#0F172A] hover:bg-[#334155] disabled:opacity-40 disabled:cursor-not-allowed text-white text-xs font-bold rounded-lg transition-colors cursor-pointer border border-slate-700"
              >
                Prev
              </button>
              <button
                onClick={handleNextInfixStep}
                disabled={infixStep >= conversionStepsList.length - 1}
                className="px-4 py-2 bg-[#0284C7] hover:bg-[#0369A1] disabled:bg-slate-800 disabled:opacity-50 text-white text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer border border-[#00D8FF]/40 shadow-sm"
              >
                <Play className="w-3.5 h-3.5 fill-current text-[#00D8FF]" />
                <span>Next Step ({infixStep + 1}/{conversionStepsList.length || 1})</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Visualizer Status & Tokens */}
            <div className="lg:col-span-7 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-[#0F172A] border border-slate-800 p-4 rounded-xl">
                  <span className="text-xs text-slate-400 font-bold block mb-1 uppercase tracking-wide">
                    Current Token
                  </span>
                  <div className="text-2xl font-mono font-extrabold text-[#00D8FF]">
                    {currentToken || '-'}
                  </div>
                </div>

                <div className="bg-[#0F172A] border border-slate-800 p-4 rounded-xl">
                  <span className="text-xs text-slate-400 font-bold block mb-1 uppercase tracking-wide">
                    Operator Stack
                  </span>
                  <div className="flex items-center gap-1.5 font-mono text-sm flex-wrap">
                    {conversionStack.length === 0 ? (
                      <span className="text-slate-500">[Empty]</span>
                    ) : (
                      conversionStack.map((op, i) => (
                        <span key={i} className="px-2.5 py-1 bg-[#1E293B] text-[#00D8FF] border border-[#0EA5E9]/40 rounded font-bold">
                          {op}
                        </span>
                      ))
                    )}
                  </div>
                </div>

                <div className="bg-[#0F172A] border border-slate-800 p-4 rounded-xl">
                  <span className="text-xs text-slate-400 font-bold block mb-1 uppercase tracking-wide">
                    Postfix Output
                  </span>
                  <div className="text-lg font-mono font-bold text-[#00D8FF] truncate">
                    {postfixResult || '[Empty]'}
                  </div>
                </div>
              </div>

              {/* Step Action Detail Box */}
              <div className="p-4 bg-[#0F172A] border border-slate-800 rounded-xl text-xs text-slate-300 font-mono flex items-start gap-2.5 shadow-sm">
                <CheckCircle2 className="w-4 h-4 text-[#00D8FF] shrink-0 mt-0.5" />
                <div>
                  <span className="text-[10px] text-[#00D8FF] uppercase font-bold block mb-0.5">
                    Step {infixStep + 1} Action
                  </span>
                  <p className="text-sm font-sans text-white font-medium">
                    {currentInfixStepObj.action}
                  </p>
                </div>
              </div>

              {/* Expression Preview */}
              <div className="p-4 bg-[#0B1120] border border-slate-800 rounded-xl">
                <span className="text-[11px] font-mono text-[#00D8FF] uppercase font-bold block mb-2">
                  Input Tokens Trace:
                </span>
                <div className="flex items-center gap-2 flex-wrap font-mono text-sm">
                  {infixExpr.replace(/\s+/g, '').split('').map((c, i) => {
                    const isCurrent = c === currentToken;
                    return (
                      <span
                        key={i}
                        className={`px-2 py-1 rounded font-bold transition-all ${
                          isCurrent
                            ? 'bg-[#00D8FF] text-slate-950 scale-110 ring-2 ring-[#00D8FF] shadow-[0_0_8px_rgba(0,216,255,0.6)] font-black'
                            : 'bg-[#1E293B] text-slate-300 border border-slate-700'
                        }`}
                      >
                        {c}
                      </span>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* VisuAlgo Code Panel for Infix to Postfix */}
            <div className="lg:col-span-5">
              <VisuAlgoCodePanel
                title="Infix to Postfix Conversion"
                explanation={currentInfixStepObj.action}
                codeLines={ALGORITHM_CODES.infixToPostfix.lines}
                activeLineIndex={currentInfixStepObj.activeCodeLine ?? 0}
                stepInfo={{ current: infixStep + 1, total: conversionStepsList.length || 1 }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
