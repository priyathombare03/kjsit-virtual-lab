import React, { useState } from 'react';
import { RotateCw, RotateCcw, Plus, CheckCircle2, AlertTriangle } from 'lucide-react';

interface AVLNode {
  val: number;
  height: number;
  bf: number;
  left: AVLNode | null;
  right: AVLNode | null;
}

export const AVLSimulator: React.FC = () => {
  // Preset scenarios to demonstrate standard rotations
  const [nodes, setNodes] = useState<{ val: number; height: number; bf: number }[]>([
    { val: 20, height: 2, bf: 0 },
    { val: 10, height: 1, bf: 0 },
    { val: 30, height: 1, bf: 0 }
  ]);
  const [activeRotation, setActiveRotation] = useState<string>('Balanced (No Rotation Needed)');
  const [inputVal, setInputVal] = useState<string>('40');
  const [logs, setLogs] = useState<string[]>([
    'AVL Tree initialized: Root 20 (BF: 0), Left 10 (BF: 0), Right 30 (BF: 0)'
  ]);

  const addLog = (msg: string) => {
    setLogs((prev) => [msg, ...prev.slice(0, 5)]);
  };

  const loadScenario = (type: 'LL' | 'RR' | 'LR' | 'RL') => {
    if (type === 'RR') {
      setActiveRotation('RR Imbalance -> Left Single Rotation triggered on Root (10)');
      setNodes([
        { val: 20, height: 2, bf: 0 },
        { val: 10, height: 1, bf: 0 },
        { val: 30, height: 1, bf: 0 }
      ]);
      addLog('Triggered RR Rotation: Inserted 30 into right subtree of 20 (child of 10). LeftRotate(10) restored balance.');
    } else if (type === 'LL') {
      setActiveRotation('LL Imbalance -> Right Single Rotation triggered on Root (30)');
      setNodes([
        { val: 20, height: 2, bf: 0 },
        { val: 10, height: 1, bf: 0 },
        { val: 30, height: 1, bf: 0 }
      ]);
      addLog('Triggered LL Rotation: Inserted 10 into left subtree of 20 (child of 30). RightRotate(30) restored balance.');
    } else if (type === 'LR') {
      setActiveRotation('LR Imbalance -> LeftRotate(LeftChild) then RightRotate(Root)');
      setNodes([
        { val: 20, height: 2, bf: 0 },
        { val: 10, height: 1, bf: 0 },
        { val: 30, height: 1, bf: 0 }
      ]);
      addLog('Triggered LR Double Rotation: LeftRotate on left child followed by RightRotate on parent.');
    } else if (type === 'RL') {
      setActiveRotation('RL Imbalance -> RightRotate(RightChild) then LeftRotate(Root)');
      setNodes([
        { val: 20, height: 2, bf: 0 },
        { val: 10, height: 1, bf: 0 },
        { val: 30, height: 1, bf: 0 }
      ]);
      addLog('Triggered RL Double Rotation: RightRotate on right child followed by LeftRotate on parent.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Preset Scenarios */}
      <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-wrap gap-3 items-center justify-between border border-slate-800">
        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
          Simulate Rotation Cases:
        </span>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => loadScenario('LL')}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition-colors"
          >
            LL Case (Right Rotate)
          </button>
          <button
            onClick={() => loadScenario('RR')}
            className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg transition-colors"
          >
            RR Case (Left Rotate)
          </button>
          <button
            onClick={() => loadScenario('LR')}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg transition-colors"
          >
            LR Case (Double)
          </button>
          <button
            onClick={() => loadScenario('RL')}
            className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-lg transition-colors"
          >
            RL Case (Double)
          </button>
        </div>
      </div>

      {/* Visual Canvas */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        <div className="md:col-span-8 bg-slate-900/95 border border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col items-center justify-center min-h-[300px]">
          <div className="w-full flex items-center justify-between mb-6 border-b border-slate-800 pb-2 text-xs font-mono">
            <span className="text-blue-400 font-bold uppercase">
              Balanced AVL Tree (Height = 2)
            </span>
            <span className="text-emerald-400 font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              |BF| &lt;= 1 Maintained
            </span>
          </div>

          {/* Root Node */}
          <div className="flex flex-col items-center">
            <div className="relative group">
              <div className="w-14 h-14 rounded-full bg-slate-800 border-2 border-blue-500 flex flex-col items-center justify-center font-mono font-bold text-white shadow-lg">
                <span>{nodes[0].val}</span>
                <span className="text-[9px] text-blue-300">BF: {nodes[0].bf}</span>
              </div>
              <span className="absolute -top-5 left-1/2 -translate-x-1/2 text-[10px] font-mono text-slate-400">
                Root (h={nodes[0].height})
              </span>
            </div>

            {/* Left & Right Subtrees */}
            <div className="flex items-center gap-16 mt-8">
              {/* Left Child */}
              <div className="flex flex-col items-center">
                <div className="text-[10px] font-mono text-blue-400 mb-1">Left</div>
                <div className="w-12 h-12 rounded-full bg-slate-800 border-2 border-emerald-500 flex flex-col items-center justify-center font-mono font-bold text-white shadow-md">
                  <span>{nodes[1].val}</span>
                  <span className="text-[8px] text-emerald-300">BF: {nodes[1].bf}</span>
                </div>
              </div>

              {/* Right Child */}
              <div className="flex flex-col items-center">
                <div className="text-[10px] font-mono text-amber-400 mb-1">Right</div>
                <div className="w-12 h-12 rounded-full bg-slate-800 border-2 border-amber-500 flex flex-col items-center justify-center font-mono font-bold text-white shadow-md">
                  <span>{nodes[2].val}</span>
                  <span className="text-[8px] text-amber-300">BF: {nodes[2].bf}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Formulas and Rotation Info */}
        <div className="md:col-span-4 bg-slate-900/95 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between font-mono text-xs">
          <div>
            <h4 className="text-xs font-bold text-blue-400 uppercase tracking-wider mb-3 border-b border-slate-800 pb-2">
              Balance Factor Rules
            </h4>
            <div className="space-y-2.5">
              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                <span className="text-slate-400 block text-[11px]">Formula:</span>
                <span className="text-amber-300 font-bold">
                  BF(N) = Height(Left) - Height(Right)
                </span>
              </div>
              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                <span className="text-slate-400 block text-[11px]">Valid AVL Condition:</span>
                <span className="text-emerald-400 font-bold">
                  BF ∈ &#123;-1, 0, +1&#125;
                </span>
              </div>
              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                <span className="text-slate-400 block text-[11px]">Active State:</span>
                <span className="text-blue-300 font-bold text-[11px]">
                  {activeRotation}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 mt-4 text-slate-400">
            <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
              Latest Log
            </span>
            <div className="text-emerald-300 truncate">
              {logs[0]}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
