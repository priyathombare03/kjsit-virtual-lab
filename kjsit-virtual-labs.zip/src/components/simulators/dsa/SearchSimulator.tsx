import React, { useState } from 'react';
import { Play, RotateCcw, Search, CheckCircle2, AlertCircle } from 'lucide-react';

export const SearchSimulator: React.FC = () => {
  const sortedArray = [12, 24, 35, 48, 59, 67, 73, 85, 91];
  const [target, setTarget] = useState<string>('67');
  const [mode, setMode] = useState<'binary' | 'linear'>('binary');

  // Binary Search State
  const [low, setLow] = useState<number | null>(null);
  const [high, setHigh] = useState<number | null>(null);
  const [mid, setMid] = useState<number | null>(null);
  const [comparisons, setComparisons] = useState<number>(0);
  const [foundIndex, setFoundIndex] = useState<number | null>(null);
  const [isSearching, setIsSearching] = useState<boolean>(false);
  const [linearIdx, setLinearIdx] = useState<number | null>(null);
  const [logs, setLogs] = useState<string[]>([
    'Sorted Array of 9 elements loaded: [12, 24, 35, 48, 59, 67, 73, 85, 91]'
  ]);

  const addLog = (msg: string) => {
    setLogs((prev) => [msg, ...prev.slice(0, 5)]);
  };

  const runBinarySearch = () => {
    const t = parseInt(target, 10);
    if (isNaN(t)) return;

    setIsSearching(true);
    setFoundIndex(null);
    setComparisons(0);
    addLog(`Initiating Binary Search for target = ${t}...`);

    let l = 0;
    let h = sortedArray.length - 1;
    let count = 0;

    const stepInterval = setInterval(() => {
      if (l <= h) {
        const m = Math.floor((l + h) / 2);
        count++;
        setLow(l);
        setHigh(h);
        setMid(m);
        setComparisons(count);

        if (sortedArray[m] === t) {
          clearInterval(stepInterval);
          setFoundIndex(m);
          setIsSearching(false);
          addLog(`TARGET FOUND: ${t} located at index ${m} after ${count} comparison(s).`);
        } else if (sortedArray[m] < t) {
          addLog(`arr[${m}] = ${sortedArray[m]} < ${t} -> Search right half (low = ${m + 1}).`);
          l = m + 1;
        } else {
          addLog(`arr[${m}] = ${sortedArray[m]} > ${t} -> Search left half (high = ${m - 1}).`);
          h = m - 1;
        }
      } else {
        clearInterval(stepInterval);
        setIsSearching(false);
        setFoundIndex(-1);
        addLog(`TARGET NOT FOUND: ${t} is not present in the array (Total comparisons: ${count}).`);
      }
    }, 1000);
  };

  const runLinearSearch = () => {
    const t = parseInt(target, 10);
    if (isNaN(t)) return;

    setIsSearching(true);
    setFoundIndex(null);
    setComparisons(0);
    addLog(`Initiating Sequential Linear Search for target = ${t}...`);

    let idx = 0;
    const stepInterval = setInterval(() => {
      if (idx < sortedArray.length) {
        setLinearIdx(idx);
        setComparisons(idx + 1);

        if (sortedArray[idx] === t) {
          clearInterval(stepInterval);
          setFoundIndex(idx);
          setIsSearching(false);
          addLog(`TARGET FOUND: ${t} at index ${idx} in ${idx + 1} sequential step(s).`);
        } else {
          idx++;
        }
      } else {
        clearInterval(stepInterval);
        setIsSearching(false);
        setFoundIndex(-1);
        addLog(`TARGET NOT FOUND: Searched all ${sortedArray.length} items.`);
      }
    }, 600);
  };

  const handleReset = () => {
    setLow(null);
    setHigh(null);
    setMid(null);
    setLinearIdx(null);
    setFoundIndex(null);
    setComparisons(0);
    setLogs(['Search simulator reset.']);
  };

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-wrap gap-4 items-center justify-between border border-slate-800">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800">
            <button
              onClick={() => {
                setMode('binary');
                handleReset();
              }}
              className={`px-3 py-1 text-xs font-bold rounded ${
                mode === 'binary' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Binary Search (O(log n))
            </button>
            <button
              onClick={() => {
                setMode('linear');
                handleReset();
              }}
              className={`px-3 py-1 text-xs font-bold rounded ${
                mode === 'linear' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Linear Search (O(n))
            </button>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-400 font-medium">Target:</span>
            <input
              type="number"
              value={target}
              onChange={(e) => setTarget(e.target.value)}
              className="w-16 bg-slate-950 text-white text-xs px-2 py-1 rounded border border-slate-700 text-center font-bold focus:outline-none"
            />
          </div>

          <button
            onClick={mode === 'binary' ? runBinarySearch : runLinearSearch}
            disabled={isSearching}
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-700 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Play className="w-3.5 h-3.5" />
            <span>Search</span>
          </button>
        </div>

        <button
          onClick={handleReset}
          className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors border border-slate-700"
          title="Reset Search"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Visual Array Canvas */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        <div className="md:col-span-8 bg-slate-900/95 border border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col justify-between min-h-[260px]">
          <div>
            <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-2 text-xs font-mono">
              <span className="text-blue-400 font-bold uppercase">
                {mode === 'binary' ? 'Binary Search Interval' : 'Linear Search Pointer'}
              </span>
              <div className="flex items-center gap-4 text-slate-400">
                {mode === 'binary' && (
                  <>
                    <span className="text-emerald-400 font-bold">LOW = {low ?? '-'}</span>
                    <span className="text-amber-400 font-bold">MID = {mid ?? '-'}</span>
                    <span className="text-blue-400 font-bold">HIGH = {high ?? '-'}</span>
                  </>
                )}
              </div>
            </div>

            {/* Elements Row */}
            <div className="grid grid-cols-3 sm:grid-cols-9 gap-2 py-6">
              {sortedArray.map((val, idx) => {
                const isMid = mode === 'binary' && idx === mid;
                const isLow = mode === 'binary' && idx === low;
                const isHigh = mode === 'binary' && idx === high;
                const isLinearCurr = mode === 'linear' && idx === linearIdx;
                const isFound = idx === foundIndex;
                const inRange =
                  mode === 'binary' &&
                  low !== null &&
                  high !== null &&
                  idx >= low &&
                  idx <= high;

                return (
                  <div key={idx} className="flex flex-col items-center">
                    {/* Badge */}
                    <div className="h-5 flex items-center justify-center text-[10px] font-mono font-bold">
                      {isFound ? (
                        <span className="text-emerald-400">FOUND</span>
                      ) : isMid ? (
                        <span className="text-amber-400">MID</span>
                      ) : isLow ? (
                        <span className="text-emerald-400">LOW</span>
                      ) : isHigh ? (
                        <span className="text-blue-400">HIGH</span>
                      ) : isLinearCurr ? (
                        <span className="text-amber-400">LOOK</span>
                      ) : null}
                    </div>

                    {/* Box */}
                    <div
                      className={`w-full aspect-square rounded-xl flex items-center justify-center font-mono font-bold text-sm border-2 transition-all ${
                        isFound
                          ? 'bg-emerald-600 text-white border-emerald-300 scale-110 shadow-lg'
                          : isMid
                          ? 'bg-amber-500 text-slate-950 border-amber-300 scale-105'
                          : isLinearCurr
                          ? 'bg-blue-600 text-white border-blue-400 scale-105'
                          : inRange
                          ? 'bg-slate-800 text-white border-slate-600'
                          : 'bg-slate-950/70 text-slate-600 border-slate-800 opacity-60'
                      }`}
                    >
                      {val}
                    </div>

                    <span className="text-[10px] font-mono text-slate-500 mt-1">
                      [{idx}]
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between text-xs font-mono text-slate-300">
            <span>
              Comparisons Count: <strong className="text-amber-300">{comparisons}</strong>
            </span>
            <span>
              Result:{' '}
              <strong
                className={
                  foundIndex !== null && foundIndex >= 0
                    ? 'text-emerald-400'
                    : foundIndex === -1
                    ? 'text-red-400'
                    : 'text-slate-400'
                }
              >
                {foundIndex !== null && foundIndex >= 0
                  ? `Found at Index ${foundIndex}`
                  : foundIndex === -1
                  ? 'Not Found'
                  : 'Idle'}
              </strong>
            </span>
          </div>
        </div>

        {/* Complexity Comparison Panel */}
        <div className="md:col-span-4 bg-slate-900/95 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between font-mono text-xs">
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-blue-400 uppercase tracking-wider border-b border-slate-800 pb-2">
              Complexity Comparison
            </h4>

            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Algorithm:</span>
              <span className="text-white font-bold">
                {mode === 'binary' ? 'Binary Search (Divide & Conquer)' : 'Linear Search (Sequential)'}
              </span>
            </div>

            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Worst-Case Comparisons:</span>
              <span className="text-amber-300 font-bold">
                {mode === 'binary' ? 'ceil(log₂(N)) = 4' : 'N = 9'}
              </span>
            </div>

            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Sorting Prerequisite:</span>
              <span className="text-emerald-400 font-bold">
                {mode === 'binary' ? 'Mandatory (Array Must Be Sorted)' : 'None (Works on Any Array)'}
              </span>
            </div>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 mt-4 text-slate-400">
            <div className="text-[10px] uppercase font-bold text-slate-400 mb-1">
              Latest Log
            </div>
            <div className="text-emerald-300 truncate">
              {logs[0]}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
