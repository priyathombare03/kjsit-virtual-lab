import React, { useState, useEffect } from 'react';
import {
  ArrowUpDown,
  Play,
  RotateCcw,
  CheckCircle2,
  Table,
  Code,
  GraduationCap,
  DollarSign,
  ShoppingBag,
  Sparkles,
  Zap,
  Info
} from 'lucide-react';
import { VisuAlgoCodePanel } from '../common/VisuAlgoCodePanel';
import { ALGORITHM_CODES } from '../common/algorithmCodes';

interface DataPreset {
  name: string;
  unit: string;
  category: string;
  values: number[];
  labels: string[];
}

const PRESETS: Record<string, DataPreset> = {
  marks: {
    name: 'Student Examination Marks',
    unit: 'Marks',
    category: 'Academic Evaluation',
    values: [78, 45, 92, 88, 64, 55, 98, 71],
    labels: ['Aarav', 'Priya', 'Rohan', 'Tanvi', 'Aditya', 'Neha', 'Kabir', 'Simran']
  },
  salaries: {
    name: 'Employee Monthly Salaries',
    unit: '₹',
    category: 'Corporate Payroll',
    values: [45000, 72000, 31000, 98000, 54000, 83000, 62000],
    labels: ['Dev 1', 'Lead', 'Intern', 'Manager', 'Analyst', 'Architect', 'Dev 2']
  },
  prices: {
    name: 'E-Commerce Product Prices',
    unit: '₹',
    category: 'Retail Catalog',
    values: [1299, 499, 8999, 2499, 1599, 6999, 3499],
    labels: ['Headphones', 'Mouse', 'Monitor', 'Keyboard', 'Webcam', 'Chair', 'Speaker']
  }
};

interface SortingApplicationSimulatorProps {
  onSimulationComplete?: () => void;
}

export const SortingApplicationSimulator: React.FC<SortingApplicationSimulatorProps> = ({ onSimulationComplete }) => {
  const [activePresetKey, setActivePresetKey] = useState<string>('marks');
  const [selectedAlgo, setSelectedAlgo] = useState<'bubble' | 'selection' | 'insertion' | 'quick' | 'merge'>('bubble');
  const [items, setItems] = useState<number[]>([...PRESETS.marks.values]);
  const [labels, setLabels] = useState<string[]>([...PRESETS.marks.labels]);
  const [comparingIndices, setComparingIndices] = useState<number[]>([]);
  const [sortedIndices, setSortedIndices] = useState<number[]>([]);
  const [comparisons, setComparisons] = useState<number>(0);
  const [swaps, setSwaps] = useState<number>(0);
  const [isSorting, setIsSorting] = useState<boolean>(false);
  const [sortComplete, setSortComplete] = useState<boolean>(false);
  const [activeCodeLine, setActiveCodeLine] = useState<number>(-1);
  const [logMessage, setLogMessage] = useState<string>('Select an algorithm and click Start Sorting.');

  const currentPreset = PRESETS[activePresetKey];

  const handlePresetChange = (key: string) => {
    setActivePresetKey(key);
    setItems([...PRESETS[key].values]);
    setLabels([...PRESETS[key].labels]);
    setComparingIndices([]);
    setSortedIndices([]);
    setComparisons(0);
    setSwaps(0);
    setIsSorting(false);
    setSortComplete(false);
    setActiveCodeLine(-1);
    setLogMessage(`Loaded ${PRESETS[key].name} dataset.`);
  };

  const resetData = () => {
    setItems([...currentPreset.values]);
    setLabels([...currentPreset.labels]);
    setComparingIndices([]);
    setSortedIndices([]);
    setComparisons(0);
    setSwaps(0);
    setIsSorting(false);
    setSortComplete(false);
    setActiveCodeLine(-1);
    setLogMessage('Reset data to original unordered state.');
  };

  // Animated Bubble Sort
  const runBubbleSort = async () => {
    setIsSorting(true);
    setSortComplete(false);
    let arr = [...items];
    let n = arr.length;
    let cmp = 0;
    let swp = 0;

    setActiveCodeLine(0); // do
    await new Promise(r => setTimeout(r, 300));

    for (let i = 0; i < n - 1; i++) {
      setActiveCodeLine(1); // swapped = false
      for (let j = 0; j < n - i - 1; j++) {
        setComparingIndices([j, j + 1]);
        cmp++;
        setComparisons(cmp);
        setActiveCodeLine(3); // if leftElement > rightElement
        setLogMessage(`Checking if arr[${j}] (${arr[j]}) > arr[${j + 1}] (${arr[j + 1]}).`);
        await new Promise(r => setTimeout(r, 450));

        if (arr[j] > arr[j + 1]) {
          let temp = arr[j];
          arr[j] = arr[j + 1];
          arr[j + 1] = temp;
          swp++;
          setSwaps(swp);
          setItems([...arr]);
          setActiveCodeLine(4); // swap(leftElement, rightElement)
          setLogMessage(`Swapped arr[${j}] and arr[${j + 1}] because ${temp} > ${arr[j]}.`);
          await new Promise(r => setTimeout(r, 450));
        }
      }
      setSortedIndices(prev => [...prev, n - i - 1]);
    }
    setSortedIndices(Array.from({ length: n }, (_, i) => i));
    setComparingIndices([]);
    setIsSorting(false);
    setSortComplete(true);
    setActiveCodeLine(6); // while swapped
    setLogMessage(`Sorting complete! Total comparisons: ${cmp}, Total swaps: ${swp}.`);
    onSimulationComplete?.();
  };

  // Animated Selection Sort
  const runSelectionSort = async () => {
    setIsSorting(true);
    setSortComplete(false);
    let arr = [...items];
    let n = arr.length;
    let cmp = 0;
    let swp = 0;

    for (let i = 0; i < n - 1; i++) {
      let minIdx = i;
      setActiveCodeLine(1); // minIdx = i
      setLogMessage(`Pass ${i + 1}: Finding minimum element starting from index ${i}.`);

      for (let j = i + 1; j < n; j++) {
        setComparingIndices([minIdx, j]);
        cmp++;
        setComparisons(cmp);
        setActiveCodeLine(3); // if arr[j] < arr[minIdx]
        await new Promise(r => setTimeout(r, 400));

        if (arr[j] < arr[minIdx]) {
          minIdx = j;
          setActiveCodeLine(4); // minIdx = j
          setLogMessage(`New minimum found: ${arr[minIdx]} at index ${minIdx}.`);
        }
      }

      if (minIdx !== i) {
        let temp = arr[i];
        arr[i] = arr[minIdx];
        arr[minIdx] = temp;
        swp++;
        setSwaps(swp);
        setItems([...arr]);
        setActiveCodeLine(6); // swap(arr[i], arr[minIdx])
        setLogMessage(`Swapped minimum ${arr[i]} to index ${i}.`);
        await new Promise(r => setTimeout(r, 450));
      }
      setActiveCodeLine(7); // mark arr[i] as sorted
      setSortedIndices(prev => [...prev, i]);
    }
    setSortedIndices(Array.from({ length: n }, (_, i) => i));
    setComparingIndices([]);
    setIsSorting(false);
    setSortComplete(true);
    setLogMessage(`Selection sort complete! Comparisons: ${cmp}, Swaps: ${swp}.`);
    onSimulationComplete?.();
  };

  // Animated Insertion Sort
  const runInsertionSort = async () => {
    setIsSorting(true);
    setSortComplete(false);
    let arr = [...items];
    let n = arr.length;
    let cmp = 0;
    let swp = 0;

    for (let i = 1; i < n; i++) {
      let key = arr[i];
      let j = i - 1;
      setActiveCodeLine(1); // key = arr[i]
      setLogMessage(`Inserting key ${key} into sorted subarray.`);

      while (j >= 0) {
        setComparingIndices([j, j + 1]);
        cmp++;
        setComparisons(cmp);
        setActiveCodeLine(3); // while j >= 0 and arr[j] > key
        await new Promise(r => setTimeout(r, 400));

        if (arr[j] > key) {
          arr[j + 1] = arr[j];
          swp++;
          setSwaps(swp);
          setItems([...arr]);
          setActiveCodeLine(4); // arr[j + 1] = arr[j]
          j--;
          await new Promise(r => setTimeout(r, 400));
        } else {
          break;
        }
      }
      arr[j + 1] = key;
      setItems([...arr]);
      setActiveCodeLine(6); // arr[j + 1] = key
      setSortedIndices(Array.from({ length: i + 1 }, (_, k) => k));
    }
    setComparingIndices([]);
    setIsSorting(false);
    setSortComplete(true);
    setActiveCodeLine(7);
    setLogMessage(`Insertion sort complete! Comparisons: ${cmp}, Shifts: ${swp}.`);
    onSimulationComplete?.();
  };

  const handleStartSort = () => {
    if (selectedAlgo === 'bubble') runBubbleSort();
    else if (selectedAlgo === 'selection') runSelectionSort();
    else if (selectedAlgo === 'insertion') runInsertionSort();
    else runBubbleSort();
  };

  const maxVal = Math.max(...items, 1);

  const getActiveAlgoDef = () => {
    if (selectedAlgo === 'selection') return ALGORITHM_CODES.selectionSort;
    if (selectedAlgo === 'insertion') return ALGORITHM_CODES.insertionSort;
    if (selectedAlgo === 'quick') return ALGORITHM_CODES.quickSort;
    if (selectedAlgo === 'merge') return ALGORITHM_CODES.mergeSort;
    return ALGORITHM_CODES.bubbleSort;
  };

  const activeAlgoDef = getActiveAlgoDef();

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl overflow-hidden shadow-sm">
      {/* Top Header */}
      <div className="p-4 bg-zinc-900 text-white flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-red-700/80 text-white">
            <ArrowUpDown className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm tracking-wide">
              Real-World Sorting Visualizer & VisuAlgo Code Tracer
            </h3>
            <p className="text-xs text-zinc-400">
              Interactive State Machine & Step-by-Step Sorting
            </p>
          </div>
        </div>

        {/* Algorithm Selection Pills */}
        <div className="flex flex-wrap gap-1.5 bg-zinc-800 p-1.5 rounded-xl border border-zinc-700">
          {(['bubble', 'selection', 'insertion'] as const).map((algo) => (
            <button
              key={algo}
              onClick={() => {
                if (!isSorting) {
                  setSelectedAlgo(algo);
                  resetData();
                }
              }}
              disabled={isSorting}
              className={`px-3 py-1 text-xs font-semibold rounded-lg capitalize transition-colors cursor-pointer ${
                selectedAlgo === algo
                  ? 'bg-red-700 text-white shadow-xs'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              {algo} Sort
            </button>
          ))}
        </div>
      </div>

      {/* Domain Controls & Stats */}
      <div className="p-4 bg-zinc-50 border-b border-zinc-200 flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-2">
          <span className="font-bold text-zinc-700">Real-World Domain Application:</span>
          <div className="flex gap-2">
            <button
              onClick={() => handlePresetChange('marks')}
              disabled={isSorting}
              className={`px-2.5 py-1 rounded border transition-colors flex items-center gap-1 font-semibold cursor-pointer ${
                activePresetKey === 'marks' ? 'bg-red-50 border-red-300 text-red-800' : 'bg-white border-zinc-300 text-zinc-700'
              }`}
            >
              <GraduationCap className="w-3.5 h-3.5 text-red-600" />
              <span>Student Marks</span>
            </button>
            <button
              onClick={() => handlePresetChange('salaries')}
              disabled={isSorting}
              className={`px-2.5 py-1 rounded border transition-colors flex items-center gap-1 font-semibold cursor-pointer ${
                activePresetKey === 'salaries' ? 'bg-red-50 border-red-300 text-red-800' : 'bg-white border-zinc-300 text-zinc-700'
              }`}
            >
              <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
              <span>Employee Salaries</span>
            </button>
            <button
              onClick={() => handlePresetChange('prices')}
              disabled={isSorting}
              className={`px-2.5 py-1 rounded border transition-colors flex items-center gap-1 font-semibold cursor-pointer ${
                activePresetKey === 'prices' ? 'bg-red-50 border-red-300 text-red-800' : 'bg-white border-zinc-300 text-zinc-700'
              }`}
            >
              <ShoppingBag className="w-3.5 h-3.5 text-blue-600" />
              <span>Product Prices</span>
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="flex items-center gap-4 font-mono text-xs">
          <div>
            <span className="text-zinc-500">Comparisons: </span>
            <span className="font-bold text-red-700">{comparisons}</span>
          </div>
          <div>
            <span className="text-zinc-500">Swaps / Shifts: </span>
            <span className="font-bold text-blue-700">{swaps}</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Visualizer Canvas (Left) + VisuAlgo Code Panel (Right) */}
      <div className="p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-7 space-y-4">
          <div className="h-56 flex items-end justify-center gap-3 sm:gap-4 pt-6 px-4 bg-zinc-50 rounded-xl border border-zinc-200">
            {items.map((val, idx) => {
              const heightPct = Math.max(15, Math.round((val / maxVal) * 85));
              const isComparing = comparingIndices.includes(idx);
              const isSorted = sortedIndices.includes(idx);

              let barColor = 'bg-red-700';
              if (isComparing) barColor = 'bg-amber-500 animate-pulse';
              else if (isSorted) barColor = 'bg-emerald-600';

              return (
                <div key={idx} className="flex-1 flex flex-col items-center h-full justify-end max-w-[60px]">
                  <span className="text-[10px] font-mono font-bold text-zinc-700 mb-1">
                    {val > 999 ? `${(val / 1000).toFixed(0)}k` : val}
                  </span>
                  <div
                    style={{ height: `${heightPct}%` }}
                    className={`w-full rounded-t-lg transition-all duration-300 ${barColor} shadow-xs relative`}
                  >
                    {isComparing && (
                      <span className="absolute -top-4 left-1/2 -translate-x-1/2 text-[9px] font-bold text-amber-700 bg-amber-100 px-1 rounded border border-amber-300 font-mono">
                        cmp
                      </span>
                    )}
                  </div>
                  <span className="text-[9px] font-sans text-zinc-500 mt-1 truncate w-full text-center">
                    {labels[idx]}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Action Controls */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-zinc-200">
            <div className="flex items-center gap-3">
              <button
                onClick={handleStartSort}
                disabled={isSorting || sortComplete}
                className="px-4 py-2 bg-red-700 hover:bg-red-800 disabled:opacity-40 text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{isSorting ? 'Sorting in progress...' : 'Execute Sort'}</span>
              </button>
              <button
                onClick={resetData}
                disabled={isSorting}
                className="px-3 py-2 border border-zinc-300 hover:bg-zinc-100 disabled:opacity-40 text-zinc-700 text-xs font-bold rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Values</span>
              </button>
            </div>

            <div className="text-[11px] text-zinc-500 font-mono flex items-center gap-3">
              <span>Algorithm: <strong className="text-zinc-800 capitalize">{selectedAlgo} Sort</strong></span>
              <span>Best: <strong className="text-emerald-700">{selectedAlgo === 'bubble' || selectedAlgo === 'insertion' ? 'O(n)' : 'O(n²)'}</strong></span>
              <span>Worst: <strong className="text-red-700">O(n²)</strong></span>
            </div>
          </div>
        </div>

        {/* VisuAlgo Code Panel */}
        <div className="lg:col-span-5">
          <VisuAlgoCodePanel
            title={`${activeAlgoDef.title}`}
            explanation={logMessage}
            codeLines={activeAlgoDef.lines}
            activeLineIndex={activeCodeLine}
          />
        </div>
      </div>

      {/* Official Manual Comparison Table (Table 1 Page 37) */}
      <div className="p-6 pt-0 border-t border-zinc-200">
        <h4 className="text-xs font-bold text-zinc-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
          <Table className="w-3.5 h-3.5 text-zinc-500" />
          Table 1: Sorting Algorithm Comparison (KJSIT Lab Manual)
        </h4>
        <div className="overflow-x-auto border border-zinc-200 rounded-xl">
          <table className="w-full text-left text-xs">
            <thead className="bg-zinc-100 text-zinc-700 font-bold border-b border-zinc-200">
              <tr>
                <th className="p-2.5">Algorithm</th>
                <th className="p-2.5">Data Structure Used</th>
                <th className="p-2.5">Best Case</th>
                <th className="p-2.5">Worst Case</th>
                <th className="p-2.5">Space Complexity</th>
                <th className="p-2.5">Stability</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200 font-mono">
              <tr className={selectedAlgo === 'bubble' ? 'bg-red-50 font-bold' : ''}>
                <td className="p-2.5">Bubble Sort</td>
                <td className="p-2.5 font-sans">Array</td>
                <td className="p-2.5 text-emerald-700">O(n)</td>
                <td className="p-2.5 text-red-700">O(n²)</td>
                <td className="p-2.5">O(1)</td>
                <td className="p-2.5 text-emerald-700 font-sans">Stable</td>
              </tr>
              <tr className={selectedAlgo === 'selection' ? 'bg-red-50 font-bold' : ''}>
                <td className="p-2.5">Selection Sort</td>
                <td className="p-2.5 font-sans">Array</td>
                <td className="p-2.5 text-red-700">O(n²)</td>
                <td className="p-2.5 text-red-700">O(n²)</td>
                <td className="p-2.5">O(1)</td>
                <td className="p-2.5 text-amber-700 font-sans">Unstable</td>
              </tr>
              <tr className={selectedAlgo === 'insertion' ? 'bg-red-50 font-bold' : ''}>
                <td className="p-2.5">Insertion Sort</td>
                <td className="p-2.5 font-sans">Array</td>
                <td className="p-2.5 text-emerald-700">O(n)</td>
                <td className="p-2.5 text-red-700">O(n²)</td>
                <td className="p-2.5">O(1)</td>
                <td className="p-2.5 text-emerald-700 font-sans">Stable</td>
              </tr>
              <tr className={selectedAlgo === 'quick' ? 'bg-red-50 font-bold' : ''}>
                <td className="p-2.5">Quick Sort</td>
                <td className="p-2.5 font-sans">Array / Recursion Stack</td>
                <td className="p-2.5 text-blue-700">O(n log n)</td>
                <td className="p-2.5 text-red-700">O(n²)</td>
                <td className="p-2.5">O(log n)</td>
                <td className="p-2.5 text-amber-700 font-sans">Unstable</td>
              </tr>
              <tr className={selectedAlgo === 'merge' ? 'bg-red-50 font-bold' : ''}>
                <td className="p-2.5">Merge Sort</td>
                <td className="p-2.5 font-sans">Array / Auxiliary Array</td>
                <td className="p-2.5 text-blue-700">O(n log n)</td>
                <td className="p-2.5 text-blue-700">O(n log n)</td>
                <td className="p-2.5">O(n)</td>
                <td className="p-2.5 text-emerald-700 font-sans">Stable</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
