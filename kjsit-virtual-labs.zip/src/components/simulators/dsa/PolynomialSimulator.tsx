import React, { useState } from 'react';
import {
  Layers,
  Play,
  RotateCcw,
  Plus,
  Minus,
  CheckCircle2,
  ArrowRight,
  ArrowDown,
  Sparkles,
  Code,
  Calculator
} from 'lucide-react';

interface PolyTerm {
  coeff: number;
  expo: number;
}

export const PolynomialSimulator: React.FC = () => {
  // Preset polynomials from Lab Manual
  // P1: 5x^6 + 6x^4 + 2x^3
  // P2: 8x^6 + 3x^2 + 4x + 5
  const [poly1, setPoly1] = useState<PolyTerm[]>([
    { coeff: 5, expo: 6 },
    { coeff: 6, expo: 4 },
    { coeff: 2, expo: 3 }
  ]);

  const [poly2, setPoly2] = useState<PolyTerm[]>([
    { coeff: 8, expo: 6 },
    { coeff: 3, expo: 2 },
    { coeff: 4, expo: 1 },
    { coeff: 5, expo: 0 }
  ]);

  const [operation, setOperation] = useState<'add' | 'subtract'>('add');
  const [stepIndex, setStepIndex] = useState<number>(-1);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  // Pre-calculated steps for addition
  const generateSteps = () => {
    const steps: Array<{
      ptr1: number | null;
      ptr2: number | null;
      description: string;
      ruleCase: 'Case 1 (expo1 == expo2)' | 'Case 2 (expo1 > expo2)' | 'Case 3 (expo1 < expo2)' | 'Remainder';
      resultSoFar: PolyTerm[];
    }> = [];

    let i = 0;
    let j = 0;
    const res: PolyTerm[] = [];

    while (i < poly1.length && j < poly2.length) {
      const t1 = poly1[i];
      const t2 = poly2[j];

      if (t1.expo === t2.expo) {
        const sumCoeff = operation === 'add' ? t1.coeff + t2.coeff : t1.coeff - t2.coeff;
        if (sumCoeff !== 0) res.push({ coeff: sumCoeff, expo: t1.expo });
        steps.push({
          ptr1: i,
          ptr2: j,
          description: `Exponents match (${t1.expo} == ${t2.expo}): ${operation === 'add' ? 'Add' : 'Subtract'} coefficients (${t1.coeff} ${operation === 'add' ? '+' : '-'} ${t2.coeff} = ${sumCoeff}). Insert (${sumCoeff}x^${t1.expo}) into RESULT. Advance both pointers.`,
          ruleCase: 'Case 1 (expo1 == expo2)',
          resultSoFar: [...res]
        });
        i++;
        j++;
      } else if (t1.expo > t2.expo) {
        res.push({ coeff: t1.coeff, expo: t1.expo });
        steps.push({
          ptr1: i,
          ptr2: j,
          description: `Exponents differ: ptr1->expo (${t1.expo}) > ptr2->expo (${t2.expo}). Copy ptr1 term (${t1.coeff}x^${t1.expo}) to RESULT. Advance ptr1.`,
          ruleCase: 'Case 2 (expo1 > expo2)',
          resultSoFar: [...res]
        });
        i++;
      } else {
        const coeff = operation === 'add' ? t2.coeff : -t2.coeff;
        res.push({ coeff, expo: t2.expo });
        steps.push({
          ptr1: i,
          ptr2: j,
          description: `Exponents differ: ptr1->expo (${t1.expo}) < ptr2->expo (${t2.expo}). Copy ptr2 term (${coeff}x^${t2.expo}) to RESULT. Advance ptr2.`,
          ruleCase: 'Case 3 (expo1 < expo2)',
          resultSoFar: [...res]
        });
        j++;
      }
    }

    while (i < poly1.length) {
      res.push({ coeff: poly1[i].coeff, expo: poly1[i].expo });
      steps.push({
        ptr1: i,
        ptr2: null,
        description: `Poly 2 finished: Copy remaining term (${poly1[i].coeff}x^${poly1[i].expo}) from Poly 1 to RESULT.`,
        ruleCase: 'Remainder',
        resultSoFar: [...res]
      });
      i++;
    }

    while (j < poly2.length) {
      const coeff = operation === 'add' ? poly2[j].coeff : -poly2[j].coeff;
      res.push({ coeff, expo: poly2[j].expo });
      steps.push({
        ptr1: null,
        ptr2: j,
        description: `Poly 1 finished: Copy remaining term (${coeff}x^${poly2[j].expo}) from Poly 2 to RESULT.`,
        ruleCase: 'Remainder',
        resultSoFar: [...res]
      });
      j++;
    }

    return steps;
  };

  const steps = generateSteps();
  const currentStep = stepIndex >= 0 && stepIndex < steps.length ? steps[stepIndex] : null;
  const resultList = currentStep ? currentStep.resultSoFar : (stepIndex >= steps.length ? steps[steps.length - 1]?.resultSoFar || [] : []);

  const handleNext = () => {
    if (stepIndex < steps.length - 1) {
      setStepIndex(stepIndex + 1);
    }
  };

  const handlePrev = () => {
    if (stepIndex > 0) {
      setStepIndex(stepIndex - 1);
    } else {
      setStepIndex(-1);
    }
  };

  const handleReset = () => {
    setStepIndex(-1);
    setIsPlaying(false);
  };

  const formatPoly = (terms: PolyTerm[]) => {
    if (terms.length === 0) return '0';
    return terms
      .map((t, idx) => {
        const sign = idx > 0 && t.coeff >= 0 ? '+ ' : (t.coeff < 0 ? '- ' : '');
        const absVal = Math.abs(t.coeff);
        const coeffStr = absVal === 1 && t.expo > 0 ? '' : absVal.toString();
        if (t.expo === 0) return `${sign}${absVal}`;
        if (t.expo === 1) return `${sign}${coeffStr}x`;
        return `${sign}${coeffStr}x^${t.expo}`;
      })
      .join(' ');
  };

  return (
    <div className="bg-white rounded-2xl border border-zinc-200 shadow-sm overflow-hidden text-zinc-900">
      {/* Header */}
      <div className="bg-zinc-900 text-white p-5 flex flex-wrap items-center justify-between gap-4 border-b border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-red-600/20 border border-red-500/30 flex items-center justify-center text-red-400">
            <Calculator className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              Polynomial Arithmetic Linked List Simulator
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 font-mono border border-red-500/30">
                Experiment 4 • AIL302
              </span>
            </h3>
            <p className="text-xs text-zinc-400">
              Interactive visualization of dynamic polynomial addition and subtraction using linked lists (ptr1, ptr2, and RESULT)
            </p>
          </div>
        </div>

        {/* Operation Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => { setOperation('add'); handleReset(); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              operation === 'add' ? 'bg-red-700 text-white shadow-xs' : 'bg-zinc-800 text-zinc-400 hover:text-white'
            }`}
          >
            Addition (+)
          </button>
          <button
            onClick={() => { setOperation('subtract'); handleReset(); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              operation === 'subtract' ? 'bg-red-700 text-white shadow-xs' : 'bg-zinc-800 text-zinc-400 hover:text-white'
            }`}
          >
            Subtraction (-)
          </button>
        </div>
      </div>

      {/* Preset Selector & Formula Summary */}
      <div className="bg-zinc-50 px-5 py-3 border-b border-zinc-200 flex flex-wrap items-center justify-between gap-4 text-xs font-mono">
        <div className="flex items-center gap-4">
          <div>
            <span className="text-zinc-500 font-sans font-bold">Poly 1: </span>
            <span className="text-blue-700 font-bold">{formatPoly(poly1)}</span>
          </div>
          <div>
            <span className="text-zinc-500 font-sans font-bold">Poly 2: </span>
            <span className="text-emerald-700 font-bold">{formatPoly(poly2)}</span>
          </div>
        </div>

        <div className="flex items-center gap-2 font-sans text-xs">
          <button
            onClick={() => {
              setPoly1([{ coeff: 3, expo: 2 }, { coeff: 2, expo: 1 }, { coeff: 1, expo: 0 }]);
              setPoly2([{ coeff: 5, expo: 2 }, { coeff: -1, expo: 1 }, { coeff: 2, expo: 0 }]);
              handleReset();
            }}
            className="px-2.5 py-1 bg-white border border-zinc-300 rounded hover:bg-zinc-100 font-semibold cursor-pointer"
          >
            Load Example 2 (Page 22)
          </button>
          <button
            onClick={() => {
              setPoly1([{ coeff: 5, expo: 6 }, { coeff: 6, expo: 4 }, { coeff: 2, expo: 3 }]);
              setPoly2([{ coeff: 8, expo: 6 }, { coeff: 3, expo: 2 }, { coeff: 4, expo: 1 }, { coeff: 5, expo: 0 }]);
              handleReset();
            }}
            className="px-2.5 py-1 bg-white border border-zinc-300 rounded hover:bg-zinc-100 font-semibold cursor-pointer"
          >
            Load Example 1 (Page 23)
          </button>
        </div>
      </div>

      {/* Linked List Visualizer Arena */}
      <div className="p-6 space-y-6">
        {/* Polynomial 1 Linked List */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-blue-900 flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
              HEAD 1 &rarr; Polynomial 1 Linked List
            </span>
            <span className="text-zinc-500 font-mono text-[11px]">
              {currentStep && currentStep.ptr1 !== null ? `ptr1 at node [${currentStep.ptr1}]` : 'ptr1: NULL'}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2 overflow-x-auto p-3 bg-blue-50/50 rounded-xl border border-blue-200">
            {poly1.map((term, idx) => {
              const isPtr1Here = currentStep?.ptr1 === idx;
              return (
                <React.Fragment key={idx}>
                  <div className="relative">
                    {isPtr1Here && (
                      <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-[10px] font-bold text-red-700 bg-red-100 px-1.5 py-0.5 rounded border border-red-300 flex items-center gap-0.5 font-mono animate-bounce">
                        <ArrowDown className="w-3 h-3" />
                        ptr1
                      </div>
                    )}
                    <div className={`flex rounded-lg overflow-hidden border shadow-2xs font-mono text-xs ${
                      isPtr1Here ? 'border-red-600 ring-2 ring-red-400 bg-white' : 'border-blue-300 bg-white'
                    }`}>
                      <div className="px-3 py-2 bg-blue-100/60 font-bold text-blue-950 border-r border-blue-200 text-center">
                        <div className="text-[10px] text-blue-600 uppercase font-sans">coeff</div>
                        {term.coeff}
                      </div>
                      <div className="px-3 py-2 bg-blue-50 font-bold text-blue-900 border-r border-blue-200 text-center">
                        <div className="text-[10px] text-blue-600 uppercase font-sans">expo</div>
                        {term.expo}
                      </div>
                      <div className="px-2.5 py-2 bg-zinc-100 text-zinc-500 text-[10px] flex items-center justify-center font-sans font-bold">
                        next &bull;
                      </div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-blue-400 shrink-0" />
                </React.Fragment>
              );
            })}
            <span className="px-2.5 py-1.5 bg-zinc-200 rounded text-zinc-600 font-mono text-xs font-bold">NULL</span>
          </div>
        </div>

        {/* Polynomial 2 Linked List */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-emerald-900 flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
              HEAD 2 &rarr; Polynomial 2 Linked List
            </span>
            <span className="text-zinc-500 font-mono text-[11px]">
              {currentStep && currentStep.ptr2 !== null ? `ptr2 at node [${currentStep.ptr2}]` : 'ptr2: NULL'}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2 overflow-x-auto p-3 bg-emerald-50/50 rounded-xl border border-emerald-200">
            {poly2.map((term, idx) => {
              const isPtr2Here = currentStep?.ptr2 === idx;
              return (
                <React.Fragment key={idx}>
                  <div className="relative">
                    {isPtr2Here && (
                      <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-[10px] font-bold text-red-700 bg-red-100 px-1.5 py-0.5 rounded border border-red-300 flex items-center gap-0.5 font-mono animate-bounce">
                        <ArrowDown className="w-3 h-3" />
                        ptr2
                      </div>
                    )}
                    <div className={`flex rounded-lg overflow-hidden border shadow-2xs font-mono text-xs ${
                      isPtr2Here ? 'border-red-600 ring-2 ring-red-400 bg-white' : 'border-emerald-300 bg-white'
                    }`}>
                      <div className="px-3 py-2 bg-emerald-100/60 font-bold text-emerald-950 border-r border-emerald-200 text-center">
                        <div className="text-[10px] text-emerald-600 uppercase font-sans">coeff</div>
                        {term.coeff}
                      </div>
                      <div className="px-3 py-2 bg-emerald-50 font-bold text-emerald-900 border-r border-emerald-200 text-center">
                        <div className="text-[10px] text-emerald-600 uppercase font-sans">expo</div>
                        {term.expo}
                      </div>
                      <div className="px-2.5 py-2 bg-zinc-100 text-zinc-500 text-[10px] flex items-center justify-center font-sans font-bold">
                        next &bull;
                      </div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-emerald-400 shrink-0" />
                </React.Fragment>
              );
            })}
            <span className="px-2.5 py-1.5 bg-zinc-200 rounded text-zinc-600 font-mono text-xs font-bold">NULL</span>
          </div>
        </div>

        {/* Current Step Rule & Decision Box */}
        {currentStep && (
          <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-300 flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
            <div className="space-y-1">
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-amber-200 text-amber-900 font-mono">
                {currentStep.ruleCase}
              </span>
              <p className="text-xs text-zinc-800 font-semibold leading-relaxed">
                {currentStep.description}
              </p>
            </div>
            <div className="text-xs font-mono font-bold text-zinc-600 whitespace-nowrap">
              Step {stepIndex + 1} of {steps.length}
            </div>
          </div>
        )}

        {/* RESULT Linked List */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-purple-900 flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-purple-600"></span>
              HEAD &rarr; RESULT Linked List ({operation === 'add' ? 'P1 + P2' : 'P1 - P2'})
            </span>
            <span className="text-purple-800 font-mono font-bold">
              {formatPoly(resultList)}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2 overflow-x-auto p-3 bg-purple-50/50 rounded-xl border border-purple-200 min-h-[64px]">
            {resultList.length === 0 ? (
              <span className="text-xs text-zinc-400 italic">Result list empty. Click "Next Step" or "Compute All" to start.</span>
            ) : (
              resultList.map((term, idx) => (
                <React.Fragment key={idx}>
                  <div className="flex rounded-lg overflow-hidden border border-purple-400 bg-white shadow-2xs font-mono text-xs">
                    <div className="px-3 py-2 bg-purple-100 font-bold text-purple-950 border-r border-purple-200 text-center">
                      <div className="text-[10px] text-purple-600 uppercase font-sans">coeff</div>
                      {term.coeff}
                    </div>
                    <div className="px-3 py-2 bg-purple-50 font-bold text-purple-900 border-r border-purple-200 text-center">
                      <div className="text-[10px] text-purple-600 uppercase font-sans">expo</div>
                      {term.expo}
                    </div>
                    <div className="px-2.5 py-2 bg-zinc-100 text-zinc-500 text-[10px] flex items-center justify-center font-sans font-bold">
                      next &bull;
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-purple-400 shrink-0" />
                </React.Fragment>
              ))
            )}
            {resultList.length > 0 && (
              <span className="px-2.5 py-1.5 bg-zinc-200 rounded text-zinc-600 font-mono text-xs font-bold">NULL</span>
            )}
          </div>
        </div>

        {/* Stepper Controls */}
        <div className="pt-2 border-t border-zinc-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrev}
              disabled={stepIndex <= -1}
              className="px-3 py-1.5 bg-zinc-100 hover:bg-zinc-200 disabled:opacity-40 text-zinc-800 text-xs font-bold rounded-lg transition-colors cursor-pointer"
            >
              &larr; Prev Step
            </button>
            <button
              onClick={handleNext}
              disabled={stepIndex >= steps.length - 1}
              className="px-4 py-1.5 bg-red-700 hover:bg-red-800 disabled:opacity-40 text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <span>Next Step</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setStepIndex(steps.length - 1)}
              className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-900 text-white text-xs font-bold rounded-lg transition-colors cursor-pointer"
            >
              Compute All
            </button>
          </div>

          <button
            onClick={handleReset}
            className="px-3 py-1.5 border border-zinc-300 hover:bg-zinc-100 text-zinc-700 text-xs font-bold rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        </div>
      </div>
    </div>
  );
};
