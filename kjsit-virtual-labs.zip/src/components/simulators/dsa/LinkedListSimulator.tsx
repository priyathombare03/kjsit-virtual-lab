import React, { useState } from 'react';
import { ArrowRight, Plus, Trash2, Search, RotateCcw, Play, CheckCircle2, AlertCircle } from 'lucide-react';
import { VisuAlgoCodePanel } from '../common/VisuAlgoCodePanel';

interface ListNode {
  id: number;
  val: number;
}

const LINKED_LIST_CODE = [
  'insertHead(val):',
  '  newNode = new Node(val)',
  '  newNode.next = head; head = newNode',
  'insertTail(val):',
  '  newNode = new Node(val)',
  '  curr = head; while curr.next != null: curr = curr.next',
  '  curr.next = newNode',
  'deleteHead():',
  '  if head == null: return NULL',
  '  temp = head; head = head.next; free(temp)',
  'search(val):',
  '  curr = head; while curr != null:',
  '    if curr.data == val: return index',
  '    curr = curr.next; return -1'
];

interface LinkedListProps {
  onSimulationComplete?: () => void;
}

export const LinkedListSimulator: React.FC<LinkedListProps> = ({ onSimulationComplete }) => {
  const [nodes, setNodes] = useState<ListNode[]>([
    { id: 1, val: 10 },
    { id: 2, val: 20 },
    { id: 3, val: 30 },
    { id: 4, val: 40 }
  ]);
  const [inputValue, setInputValue] = useState<string>('50');
  const [indexValue, setIndexValue] = useState<string>('2');
  const [searchValue, setSearchValue] = useState<string>('30');
  const [activeHighlightIndex, setActiveHighlightIndex] = useState<number | null>(null);
  const [searchFoundIndex, setSearchFoundIndex] = useState<number | null>(null);
  const [activeCodeLine, setActiveCodeLine] = useState<number>(-1);
  const [explanation, setExplanation] = useState<string>(
    'Initialized Singly Linked List with 4 nodes: 10 -> 20 -> 30 -> 40 -> NULL'
  );
  const [logs, setLogs] = useState<string[]>([
    'Initialized Singly Linked List with 4 nodes: 10 -> 20 -> 30 -> 40 -> NULL'
  ]);
  const [isSearching, setIsSearching] = useState<boolean>(false);

  const addLog = (msg: string) => {
    setLogs((prev) => [msg, ...prev.slice(0, 7)]);
  };

  const handleInsertHead = () => {
    const val = parseInt(inputValue, 10);
    if (isNaN(val)) return;
    const newNode: ListNode = { id: Date.now(), val };
    setNodes([newNode, ...nodes]);
    const desc = `Inserted ${val} at HEAD (new Node->next = old head, head = new Node).`;
    addLog(desc);
    setExplanation(desc);
    setActiveCodeLine(2);
    setActiveHighlightIndex(0);
    onSimulationComplete?.();
    setTimeout(() => {
      setActiveHighlightIndex(null);
      setActiveCodeLine(-1);
    }, 1500);
  };

  const handleInsertTail = () => {
    const val = parseInt(inputValue, 10);
    if (isNaN(val)) return;
    const newNode: ListNode = { id: Date.now(), val };
    setNodes([...nodes, newNode]);
    const desc = `Inserted ${val} at TAIL (traversed to last node, last->next = new Node).`;
    addLog(desc);
    setExplanation(desc);
    setActiveCodeLine(6);
    setActiveHighlightIndex(nodes.length);
    onSimulationComplete?.();
    setTimeout(() => {
      setActiveHighlightIndex(null);
      setActiveCodeLine(-1);
    }, 1500);
  };

  const handleInsertAtIndex = () => {
    const val = parseInt(inputValue, 10);
    const idx = parseInt(indexValue, 10);
    if (isNaN(val) || isNaN(idx) || idx < 0 || idx > nodes.length) {
      addLog(`Invalid index: must be between 0 and ${nodes.length}`);
      return;
    }
    const newNode: ListNode = { id: Date.now(), val };
    const updated = [...nodes];
    updated.splice(idx, 0, newNode);
    setNodes(updated);
    const desc = `Inserted ${val} at Index ${idx} (re-wired pointers between Node[${idx - 1}] and Node[${idx}]).`;
    addLog(desc);
    setExplanation(desc);
    setActiveCodeLine(6);
    setActiveHighlightIndex(idx);
    onSimulationComplete?.();
    setTimeout(() => {
      setActiveHighlightIndex(null);
      setActiveCodeLine(-1);
    }, 1500);
  };

  const handleDeleteHead = () => {
    if (nodes.length === 0) {
      addLog('List is already empty!');
      setActiveCodeLine(8);
      return;
    }
    const deletedVal = nodes[0].val;
    setNodes(nodes.slice(1));
    const desc = `Deleted Head node (${deletedVal}). New head is ${nodes[1] ? nodes[1].val : 'NULL'}.`;
    addLog(desc);
    setExplanation(desc);
    setActiveCodeLine(9);
    onSimulationComplete?.();
    setTimeout(() => setActiveCodeLine(-1), 1500);
  };

  const handleDeleteTail = () => {
    if (nodes.length === 0) {
      addLog('List is already empty!');
      setActiveCodeLine(8);
      return;
    }
    const deletedVal = nodes[nodes.length - 1].val;
    setNodes(nodes.slice(0, -1));
    const desc = `Deleted Tail node (${deletedVal}). Traversed to second-last node and set next = NULL.`;
    addLog(desc);
    setExplanation(desc);
    setActiveCodeLine(9);
    onSimulationComplete?.();
    setTimeout(() => setActiveCodeLine(-1), 1500);
  };

  const handleDeleteByVal = (valToDelete: number) => {
    const idx = nodes.findIndex((n) => n.val === valToDelete);
    if (idx === -1) {
      addLog(`Node with value ${valToDelete} not found.`);
      return;
    }
    const updated = nodes.filter((_, i) => i !== idx);
    setNodes(updated);
    const desc = `Deleted node with value ${valToDelete} at index ${idx}.`;
    addLog(desc);
    setExplanation(desc);
    setActiveCodeLine(9);
  };

  const handleSearch = () => {
    const target = parseInt(searchValue, 10);
    if (isNaN(target)) return;
    setIsSearching(true);
    setSearchFoundIndex(null);
    setActiveCodeLine(11);
    const desc = `Starting linear search for value ${target}...`;
    addLog(desc);
    setExplanation(desc);

    let currIdx = 0;
    const interval = setInterval(() => {
      if (currIdx < nodes.length) {
        setActiveHighlightIndex(currIdx);
        setActiveCodeLine(12);
        if (nodes[currIdx].val === target) {
          clearInterval(interval);
          setSearchFoundIndex(currIdx);
          setIsSearching(false);
          setActiveCodeLine(12);
          const foundDesc = `Found target value ${target} at node index ${currIdx} (Address pointer matched).`;
          addLog(foundDesc);
          setExplanation(foundDesc);
          onSimulationComplete?.();
          setTimeout(() => {
            setActiveHighlightIndex(null);
            setActiveCodeLine(-1);
          }, 2000);
        } else {
          currIdx++;
          setActiveCodeLine(13);
        }
      } else {
        clearInterval(interval);
        setIsSearching(false);
        setActiveHighlightIndex(null);
        setActiveCodeLine(13);
        const notFoundDesc = `Value ${target} was NOT found in the linked list.`;
        addLog(notFoundDesc);
        setExplanation(notFoundDesc);
        onSimulationComplete?.();
      }
    }, 600);
  };

  const handleReset = () => {
    setNodes([
      { id: 1, val: 10 },
      { id: 2, val: 20 },
      { id: 3, val: 30 },
      { id: 4, val: 40 }
    ]);
    setActiveHighlightIndex(null);
    setSearchFoundIndex(null);
    setLogs(['Reset list to default state: 10 -> 20 -> 30 -> 40 -> NULL']);
  };

  return (
    <div className="space-y-6">
      {/* Control Toolbar */}
      <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-wrap gap-4 items-center justify-between">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-400 font-medium">Value:</span>
            <input
              type="number"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              className="w-16 bg-slate-950 text-white text-xs px-2 py-1 rounded border border-slate-700 text-center font-bold focus:outline-none focus:border-blue-500"
            />
          </div>

          <button
            onClick={handleInsertHead}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Insert Head</span>
          </button>

          <button
            onClick={handleInsertTail}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Insert Tail</span>
          </button>

          <div className="flex items-center gap-1.5 bg-slate-800 px-2 py-1 rounded-lg border border-slate-700">
            <span className="text-[10px] text-slate-400">Idx:</span>
            <input
              type="number"
              value={indexValue}
              onChange={(e) => setIndexValue(e.target.value)}
              className="w-10 bg-slate-950 text-white text-xs px-1 py-0.5 rounded border border-slate-700 text-center font-bold focus:outline-none"
            />
            <button
              onClick={handleInsertAtIndex}
              className="px-2 py-1 bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-semibold rounded"
            >
              Insert At
            </button>
          </div>

          <div className="h-4 w-px bg-slate-700 mx-1 hidden sm:block"></div>

          <button
            onClick={handleDeleteHead}
            className="px-2.5 py-1.5 bg-red-900/80 hover:bg-red-800 text-red-200 text-xs font-semibold rounded-lg flex items-center gap-1 border border-red-800"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Del Head</span>
          </button>

          <button
            onClick={handleDeleteTail}
            className="px-2.5 py-1.5 bg-red-900/80 hover:bg-red-800 text-red-200 text-xs font-semibold rounded-lg flex items-center gap-1 border border-red-800"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Del Tail</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-slate-800 px-2 py-1 rounded-lg border border-slate-700">
            <input
              type="number"
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              placeholder="Search..."
              className="w-14 bg-slate-950 text-white text-xs px-1.5 py-0.5 rounded border border-slate-700 text-center font-bold focus:outline-none"
            />
            <button
              onClick={handleSearch}
              disabled={isSearching}
              className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded flex items-center gap-1 disabled:opacity-50"
            >
              <Search className="w-3 h-3" />
              <span>Search</span>
            </button>
          </div>

          <button
            onClick={handleReset}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors border border-slate-700"
            title="Reset Linked List"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Visual Canvas */}
      <div className="bg-slate-900/95 border border-slate-800 rounded-2xl p-6 sm:p-8 min-h-[260px] flex flex-col justify-center overflow-x-auto shadow-inner">
        <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-3">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-400">
              Pointer Visualization
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Length: {nodes.length} Nodes
            </span>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono">
            <div className="flex items-center gap-1.5 text-blue-400">
              <span className="w-3 h-3 rounded-full bg-blue-500 inline-block"></span>
              <span>HEAD = {nodes[0] ? `Node(${nodes[0].val})` : 'NULL'}</span>
            </div>
            <div className="flex items-center gap-1.5 text-amber-400">
              <span className="w-3 h-3 rounded-full bg-amber-500 inline-block"></span>
              <span>TAIL = {nodes[nodes.length - 1] ? `Node(${nodes[nodes.length - 1].val})` : 'NULL'}</span>
            </div>
          </div>
        </div>

        {/* Nodes Chain */}
        <div className="py-6 flex items-center gap-3 flex-nowrap min-w-max">
          {/* Head Indicator */}
          <div className="flex flex-col items-center mr-1 text-xs text-blue-400 font-mono font-bold">
            <span className="px-2 py-0.5 bg-blue-950 border border-blue-800 rounded text-[10px]">HEAD</span>
            <ArrowRight className="w-4 h-4 text-blue-400 mt-1" />
          </div>

          {nodes.length === 0 ? (
            <div className="text-slate-500 italic text-sm font-mono py-4">
              List is EMPTY (head == NULL)
            </div>
          ) : (
            nodes.map((node, idx) => {
              const isHighlight = activeHighlightIndex === idx;
              const isFound = searchFoundIndex === idx;

              return (
                <React.Fragment key={node.id}>
                  {/* Node Box */}
                  <div
                    className={`flex rounded-xl overflow-hidden border-2 transition-all duration-300 shadow-md ${
                      isFound
                        ? 'border-emerald-400 bg-emerald-950 scale-105 ring-4 ring-emerald-500/30'
                        : isHighlight
                        ? 'border-blue-400 bg-blue-950 scale-105 ring-4 ring-blue-500/30'
                        : 'border-slate-700 bg-slate-800'
                    }`}
                  >
                    {/* Data Section */}
                    <div className="px-4 py-3 bg-slate-800/90 text-white font-mono font-bold text-base flex flex-col items-center justify-center min-w-[56px] border-r border-slate-700">
                      <span className="text-[9px] text-slate-400 font-normal uppercase">Data</span>
                      <span className={isFound ? 'text-emerald-300 text-lg' : 'text-white'}>
                        {node.val}
                      </span>
                    </div>

                    {/* Next Pointer Section */}
                    <div className="px-3 py-3 bg-slate-900 text-slate-400 font-mono text-xs flex flex-col items-center justify-center min-w-[48px]">
                      <span className="text-[9px] text-slate-500 uppercase">Next</span>
                      <span className="text-[10px] text-blue-400 font-bold">
                        {idx === nodes.length - 1 ? 'NULL' : `•`}
                      </span>
                    </div>

                    {/* Quick Delete Hover */}
                    <button
                      onClick={() => handleDeleteByVal(node.val)}
                      className="px-2 bg-slate-900/60 hover:bg-red-900/80 text-slate-500 hover:text-red-300 flex items-center justify-center transition-colors border-l border-slate-800"
                      title={`Delete Node ${node.val}`}
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>

                  {/* Pointer Arrow */}
                  <div className="flex items-center text-slate-500">
                    <ArrowRight className="w-5 h-5 text-blue-400" />
                  </div>
                </React.Fragment>
              );
            })
          )}

          {/* NULL Terminator */}
          <div className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-500 font-mono text-xs font-bold">
            NULL
          </div>
        </div>
      </div>

      {/* VisuAlgo Code Panel & Execution Trace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-6 bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs text-slate-300 min-h-[260px]">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800 text-slate-400 font-semibold mb-2">
            <Play className="w-3.5 h-3.5 text-blue-400" />
            <span>Pointer & Memory Transition Trace</span>
          </div>
          <div className="space-y-1.5 max-h-56 overflow-y-auto">
            {logs.map((log, i) => (
              <div key={i} className="flex items-start gap-2">
                <span className="text-blue-500">&gt;</span>
                <span className={i === 0 ? 'text-emerald-300 font-semibold' : 'text-slate-400'}>
                  {log}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-6">
          <VisuAlgoCodePanel
            title="Singly Linked List Operations"
            explanation={explanation}
            codeLines={LINKED_LIST_CODE}
            activeLineIndex={activeCodeLine}
          />
        </div>
      </div>
    </div>
  );
};
