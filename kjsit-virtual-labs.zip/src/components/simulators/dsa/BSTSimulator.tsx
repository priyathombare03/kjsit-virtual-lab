import React, { useState } from 'react';
import { Plus, Trash2, Search, RotateCcw, Play, CheckCircle2 } from 'lucide-react';
import { VisuAlgoCodePanel } from '../common/VisuAlgoCodePanel';
import { ALGORITHM_CODES } from '../common/algorithmCodes';

interface TreeNode {
  val: number;
  left: TreeNode | null;
  right: TreeNode | null;
}

interface BSTProps {
  onSimulationComplete?: () => void;
}

export const BSTSimulator: React.FC<BSTProps> = ({ onSimulationComplete }) => {
  // Tree state stored as root node
  const [root, setRoot] = useState<TreeNode | null>({
    val: 50,
    left: {
      val: 30,
      left: { val: 20, left: null, right: null },
      right: { val: 40, left: null, right: null }
    },
    right: {
      val: 70,
      left: { val: 60, left: null, right: null },
      right: { val: 80, left: null, right: null }
    }
  });

  const [inputVal, setInputVal] = useState<string>('65');
  const [activeNodeVal, setActiveNodeVal] = useState<number | null>(null);
  const [traversalSequence, setTraversalSequence] = useState<number[]>([]);
  const [traversalType, setTraversalType] = useState<string>('');
  const [activeCodeLine, setActiveCodeLine] = useState<number>(-1);
  const [explanation, setExplanation] = useState<string>(
    'Initialized Balanced BST with keys: [20, 30, 40, 50, 60, 70, 80]'
  );
  const [logs, setLogs] = useState<string[]>([
    'Initialized Balanced BST with keys: [20, 30, 40, 50, 60, 70, 80]'
  ]);
  const [isTraversing, setIsTraversing] = useState<boolean>(false);

  const addLog = (msg: string) => {
    setLogs((prev) => [msg, ...prev.slice(0, 6)]);
  };

  // BST Insert Helper
  const insertNode = (node: TreeNode | null, val: number): TreeNode => {
    if (!node) return { val, left: null, right: null };
    if (val < node.val) {
      node.left = insertNode(node.left, val);
    } else if (val > node.val) {
      node.right = insertNode(node.right, val);
    }
    return { ...node };
  };

  const handleInsert = () => {
    const v = parseInt(inputVal, 10);
    if (isNaN(v)) return;
    const newRoot = insertNode(root, v);
    setRoot(newRoot);
    const desc = `INSERT(${v}) -> Traversed BST (Left < Root < Right) and attached new leaf node with key ${v}.`;
    addLog(desc);
    setExplanation(desc);
    setActiveCodeLine(v < (root?.val ?? 0) ? 2 : 4);
    setActiveNodeVal(v);
    onSimulationComplete?.();
    setTimeout(() => {
      setActiveNodeVal(null);
      setActiveCodeLine(-1);
    }, 1500);
  };

  // Traversals
  const runTraversal = (type: 'inorder' | 'preorder' | 'postorder') => {
    setIsTraversing(true);
    setTraversalType(type.toUpperCase());
    setActiveCodeLine(0);
    setExplanation(`Executing ${type.toUpperCase()} traversal on Binary Search Tree.`);
    const seq: number[] = [];

    const traverse = (node: TreeNode | null) => {
      if (!node) return;
      if (type === 'preorder') seq.push(node.val);
      traverse(node.left);
      if (type === 'inorder') seq.push(node.val);
      traverse(node.right);
      if (type === 'postorder') seq.push(node.val);
    };

    traverse(root);
    setTraversalSequence([]);

    // Animate sequence
    let idx = 0;
    const interval = setInterval(() => {
      if (idx < seq.length) {
        setActiveNodeVal(seq[idx]);
        setTraversalSequence((prev) => [...prev, seq[idx]]);
        idx++;
      } else {
        clearInterval(interval);
        setIsTraversing(false);
        setActiveNodeVal(null);
        const doneDesc = `${type.toUpperCase()} Traversal complete: [ ${seq.join(' -> ')} ]`;
        addLog(doneDesc);
        setExplanation(doneDesc);
        onSimulationComplete?.();
      }
    }, 600);
  };

  const handleReset = () => {
    setRoot({
      val: 50,
      left: {
        val: 30,
        left: { val: 20, left: null, right: null },
        right: { val: 40, left: null, right: null }
      },
      right: {
        val: 70,
        left: { val: 60, left: null, right: null },
        right: { val: 80, left: null, right: null }
      }
    });
    setTraversalSequence([]);
    setTraversalType('');
    setActiveNodeVal(null);
    setLogs(['BST reset to default balanced tree.']);
  };

  // Recursive Tree Rendering
  const renderTree = (node: TreeNode | null, depth = 0, pos = 'root'): React.ReactNode => {
    if (!node) return null;
    const isActive = activeNodeVal === node.val;

    return (
      <div className="flex flex-col items-center">
        {/* Node Circle */}
        <div
          className={`w-12 h-12 rounded-full flex items-center justify-center font-mono font-bold text-sm border-2 transition-all duration-300 shadow-md ${
            isActive
              ? 'bg-amber-500 text-slate-950 border-amber-300 scale-110 ring-4 ring-amber-400/40'
              : 'bg-slate-800 text-white border-blue-500 hover:border-blue-400'
          }`}
        >
          {node.val}
        </div>

        {/* Children Row */}
        {(node.left || node.right) && (
          <div className="flex items-start gap-6 sm:gap-12 mt-4 relative">
            {/* Left Branch */}
            <div className="flex flex-col items-center">
              {node.left ? (
                <>
                  <div className="text-[10px] font-mono text-blue-400 mb-1">L</div>
                  {renderTree(node.left, depth + 1, 'left')}
                </>
              ) : (
                <div className="w-8 h-8 rounded-full border border-dashed border-slate-700 flex items-center justify-center text-slate-600 text-[10px] font-mono">
                  null
                </div>
              )}
            </div>

            {/* Right Branch */}
            <div className="flex flex-col items-center">
              {node.right ? (
                <>
                  <div className="text-[10px] font-mono text-amber-400 mb-1">R</div>
                  {renderTree(node.right, depth + 1, 'right')}
                </>
              ) : (
                <div className="w-8 h-8 rounded-full border border-dashed border-slate-700 flex items-center justify-center text-slate-600 text-[10px] font-mono">
                  null
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-wrap gap-4 items-center justify-between border border-slate-800">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-400 font-medium">Key:</span>
            <input
              type="number"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              className="w-16 bg-slate-950 text-white text-xs px-2 py-1 rounded border border-slate-700 text-center font-bold focus:outline-none"
            />
          </div>

          <button
            onClick={handleInsert}
            disabled={isTraversing}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Insert Key</span>
          </button>

          <div className="h-4 w-px bg-slate-700 mx-1 hidden sm:block"></div>

          {/* Traversal Buttons */}
          <button
            onClick={() => runTraversal('inorder')}
            disabled={isTraversing}
            className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 disabled:bg-slate-700 text-white text-xs font-semibold rounded-lg transition-colors"
          >
            Inorder (L-Root-R)
          </button>
          <button
            onClick={() => runTraversal('preorder')}
            disabled={isTraversing}
            className="px-3 py-1.5 bg-indigo-700 hover:bg-indigo-600 disabled:bg-slate-700 text-white text-xs font-semibold rounded-lg transition-colors"
          >
            Preorder (Root-L-R)
          </button>
          <button
            onClick={() => runTraversal('postorder')}
            disabled={isTraversing}
            className="px-3 py-1.5 bg-purple-700 hover:bg-purple-600 disabled:bg-slate-700 text-white text-xs font-semibold rounded-lg transition-colors"
          >
            Postorder (L-R-Root)
          </button>
        </div>

        <button
          onClick={handleReset}
          className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors border border-slate-700"
          title="Reset BST"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Tree Canvas */}
      <div className="bg-slate-900/95 border border-slate-800 rounded-2xl p-6 sm:p-8 min-h-[320px] flex flex-col items-center justify-center overflow-x-auto shadow-inner">
        <div className="w-full flex items-center justify-between mb-4 border-b border-slate-800 pb-2 text-xs font-mono">
          <span className="text-blue-400 font-bold uppercase">
            Hierarchical 2D Node Tree (Left &lt; Root &lt; Right)
          </span>
          <span className="text-slate-400">
            Active Node: {activeNodeVal !== null ? `Node(${activeNodeVal})` : 'None'}
          </span>
        </div>

        <div className="py-6 min-w-max flex justify-center">{renderTree(root)}</div>
      </div>

      {/* VisuAlgo Code Panel & Invariants Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-6 space-y-4">
          {/* Traversal Output Bar */}
          {traversalType && (
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-wrap items-center gap-3">
              <span className="text-xs font-bold text-emerald-400 font-mono">
                {traversalType} TRAVERSAL OUTPUT:
              </span>
              <div className="flex items-center gap-2 flex-wrap font-mono text-xs">
                {traversalSequence.map((v, i) => (
                  <span
                    key={i}
                    className="px-2.5 py-1 bg-emerald-950 text-emerald-300 border border-emerald-700 rounded-md font-bold"
                  >
                    {v}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Logs */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs text-slate-300 min-h-[160px]">
            <div className="text-[10px] text-slate-400 uppercase font-bold mb-2">
              Execution Log & Invariants
            </div>
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {logs.map((log, i) => (
                <div key={i} className="text-slate-400 truncate">
                  &gt; {log}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* VisuAlgo Code Panel */}
        <div className="lg:col-span-6">
          <VisuAlgoCodePanel
            title="Binary Search Tree (BST)"
            explanation={explanation}
            codeLines={ALGORITHM_CODES.bstOperations.lines}
            activeLineIndex={activeCodeLine}
          />
        </div>
      </div>
    </div>
  );
};
