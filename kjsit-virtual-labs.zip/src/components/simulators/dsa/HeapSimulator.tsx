import React, { useState } from 'react';
import { Plus, Trash2, RotateCcw, Play, ArrowDown, ArrowUp } from 'lucide-react';

export const HeapSimulator: React.FC = () => {
  const [heap, setHeap] = useState<number[]>([90, 75, 80, 45, 60, 55, 70]);
  const [isMaxHeap, setIsMaxHeap] = useState<boolean>(true);
  const [inputVal, setInputVal] = useState<string>('95');
  const [highlightIdx, setHighlightIdx] = useState<number | null>(null);
  const [logs, setLogs] = useState<string[]>([
    'Max-Heap initialized with 7 elements: [90, 75, 80, 45, 60, 55, 70]'
  ]);

  const addLog = (msg: string) => {
    setLogs((prev) => [msg, ...prev.slice(0, 5)]);
  };

  const handleInsert = () => {
    const val = parseInt(inputVal, 10);
    if (isNaN(val)) return;

    const arr = [...heap, val];
    let curr = arr.length - 1;

    // Sift up
    while (curr > 0) {
      const parent = Math.floor((curr - 1) / 2);
      if (isMaxHeap ? arr[curr] > arr[parent] : arr[curr] < arr[parent]) {
        const temp = arr[curr];
        arr[curr] = arr[parent];
        arr[parent] = temp;
        curr = parent;
      } else {
        break;
      }
    }

    setHeap(arr);
    setHighlightIdx(curr);
    addLog(`INSERT(${val}) -> Appended at index ${arr.length - 1}, sifted up to index ${curr}.`);
    setTimeout(() => setHighlightIdx(null), 1500);
  };

  const handleExtractRoot = () => {
    if (heap.length === 0) return;
    const rootVal = heap[0];
    if (heap.length === 1) {
      setHeap([]);
      addLog(`Extracted root ${rootVal}. Heap is now empty.`);
      return;
    }

    const arr = [...heap];
    arr[0] = arr.pop()!;
    let i = 0;
    const n = arr.length;

    // Sift down
    while (true) {
      let target = i;
      const left = 2 * i + 1;
      const right = 2 * i + 2;

      if (left < n && (isMaxHeap ? arr[left] > arr[target] : arr[left] < arr[target])) {
        target = left;
      }
      if (right < n && (isMaxHeap ? arr[right] > arr[target] : arr[right] < arr[target])) {
        target = right;
      }

      if (target !== i) {
        const temp = arr[i];
        arr[i] = arr[target];
        arr[target] = temp;
        i = target;
      } else {
        break;
      }
    }

    setHeap(arr);
    addLog(`EXTRACT_ROOT() -> Removed ${rootVal}, placed last element at root and executed Heapify down.`);
  };

  const handleReset = () => {
    setHeap([90, 75, 80, 45, 60, 55, 70]);
    setHighlightIdx(null);
    setLogs(['Heap reset to initial state.']);
  };

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-wrap gap-4 items-center justify-between border border-slate-800">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-400 font-medium">Value:</span>
            <input
              type="number"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              className="w-16 bg-slate-950 text-white text-xs px-2 py-1 rounded border border-slate-700 text-center font-bold focus:outline-none"
            />
          </div>

          <button
            onClick={handleInsert}
            className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Insert (Sift-Up)</span>
          </button>

          <button
            onClick={handleExtractRoot}
            disabled={heap.length === 0}
            className="px-3.5 py-1.5 bg-red-800 hover:bg-red-700 disabled:bg-slate-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Extract Root (Heapify)</span>
          </button>
        </div>

        <button
          onClick={handleReset}
          className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors border border-slate-700"
          title="Reset Heap"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Array Index Synchronizer */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
        <div>
          <span className="text-xs font-mono font-bold text-blue-400 uppercase tracking-wider block mb-3">
            Contiguous 1D Array Representation
          </span>
          <div className="flex flex-wrap items-center gap-2">
            {heap.map((val, idx) => (
              <div key={idx} className="flex flex-col items-center">
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center font-mono font-bold text-sm border transition-all ${
                    highlightIdx === idx
                      ? 'bg-amber-500 text-slate-950 border-amber-300 scale-105 ring-2 ring-amber-400'
                      : idx === 0
                      ? 'bg-blue-600 text-white border-blue-400'
                      : 'bg-slate-800 text-slate-200 border-slate-700'
                  }`}
                >
                  {val}
                </div>
                <span className="text-[10px] font-mono text-slate-500 mt-1">[{idx}]</span>
              </div>
            ))}
          </div>
        </div>

        {/* Binary Tree Visualizer */}
        <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 flex flex-col items-center">
          <span className="text-xs font-mono text-slate-400 font-bold uppercase mb-4 self-start">
            Complete Binary Tree Projection
          </span>

          {/* Level 0: Root */}
          {heap.length > 0 && (
            <div className="flex flex-col items-center">
              <div className="w-11 h-11 rounded-full bg-blue-600 border-2 border-blue-400 flex items-center justify-center font-mono font-bold text-white shadow-md">
                {heap[0]}
              </div>

              {/* Level 1 */}
              <div className="flex items-center gap-16 mt-4">
                {heap[1] !== undefined && (
                  <div className="w-10 h-10 rounded-full bg-slate-800 border-2 border-indigo-500 flex items-center justify-center font-mono font-bold text-white">
                    {heap[1]}
                  </div>
                )}
                {heap[2] !== undefined && (
                  <div className="w-10 h-10 rounded-full bg-slate-800 border-2 border-indigo-500 flex items-center justify-center font-mono font-bold text-white">
                    {heap[2]}
                  </div>
                )}
              </div>

              {/* Level 2 */}
              <div className="flex items-center gap-6 mt-4">
                {heap.slice(3, 7).map((val, i) => (
                  <div
                    key={i}
                    className="w-9 h-9 rounded-full bg-slate-800 border border-slate-600 flex items-center justify-center font-mono font-bold text-xs text-slate-300"
                  >
                    {val}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Formulas */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs text-slate-300">
          <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
            <span className="text-slate-400 text-[10px] block">Parent Index:</span>
            <span className="text-blue-300 font-bold">floor((i - 1) / 2)</span>
          </div>
          <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
            <span className="text-slate-400 text-[10px] block">Left Child Index:</span>
            <span className="text-emerald-300 font-bold">2*i + 1</span>
          </div>
          <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
            <span className="text-slate-400 text-[10px] block">Right Child Index:</span>
            <span className="text-amber-300 font-bold">2*i + 2</span>
          </div>
        </div>
      </div>
    </div>
  );
};
