import React, { useState, useRef, useEffect } from 'react';
import { Play, RotateCcw, CheckCircle2, ArrowRight } from 'lucide-react';
import { VisuAlgoCodePanel } from '../common/VisuAlgoCodePanel';
import { ALGORITHM_CODES } from '../common/algorithmCodes';

interface GraphNode {
  id: string;
  label: string;
  x: number;
  y: number;
}

const GRAPH_NODES: GraphNode[] = [
  { id: '0', label: '0 (A)', x: 60, y: 70 },
  { id: '1', label: '1 (B)', x: 180, y: 30 },
  { id: '2', label: '2 (C)', x: 180, y: 120 },
  { id: '3', label: '3 (D)', x: 300, y: 30 },
  { id: '4', label: '4 (E)', x: 300, y: 120 },
  { id: '5', label: '5 (F)', x: 420, y: 70 }
];

const EDGES: [string, string][] = [
  ['0', '1'],
  ['0', '2'],
  ['1', '3'],
  ['1', '4'],
  ['2', '4'],
  ['3', '5'],
  ['4', '5']
];

const ADJ_LIST: Record<string, string[]> = {
  '0': ['1', '2'],
  '1': ['0', '3', '4'],
  '2': ['0', '4'],
  '3': ['1', '5'],
  '4': ['1', '2', '5'],
  '5': ['3', '4']
};

interface GraphTraversalSimulatorProps {
  onSimulationComplete?: () => void;
}

export const GraphTraversalSimulator: React.FC<GraphTraversalSimulatorProps> = ({ onSimulationComplete }) => {
  const [visitedNodes, setVisitedNodes] = useState<string[]>([]);
  const [activeNode, setActiveNode] = useState<string | null>(null);
  const [frontier, setFrontier] = useState<string[]>([]);
  const [traversalType, setTraversalType] = useState<'BFS' | 'DFS'>('BFS');
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [traversalOrder, setTraversalOrder] = useState<string[]>([]);
  const [activeCodeLine, setActiveCodeLine] = useState<number>(-1);
  const [stepCount, setStepCount] = useState<number>(0);
  const [speed, setSpeed] = useState<number>(900);
  const [explanation, setExplanation] = useState<string>(
    'Select Breadth-First Search (BFS) or Depth-First Search (DFS) to begin live graph traversal tracing.'
  );
  const [logs, setLogs] = useState<string[]>([
    'Graph initialized with 6 vertices and 7 undirected edges.'
  ]);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const addLog = (msg: string) => {
    setLogs((prev) => [msg, ...prev.slice(0, 5)]);
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  const runBFS = () => {
    if (timerRef.current) clearInterval(timerRef.current);

    setIsRunning(true);
    setTraversalType('BFS');
    setVisitedNodes(['0']);
    setFrontier(['0']);
    setActiveNode('0');
    setTraversalOrder([]);
    setActiveCodeLine(2);
    setStepCount(1);
    const initialMsg = 'Starting BFS from Source Vertex 0 (A). Initialized FIFO Queue with [0].';
    setExplanation(initialMsg);
    addLog(initialMsg);

    const visited: string[] = ['0'];
    const queue: string[] = ['0'];
    const order: string[] = [];
    let step = 1;

    timerRef.current = setInterval(() => {
      if (queue.length > 0) {
        const curr = queue.shift()!;
        order.push(curr);
        setTraversalOrder([...order]);
        setActiveNode(curr);
        step += 1;
        setStepCount(step);
        setActiveCodeLine(4); // curr = Q.dequeue(); visit(curr)

        // Find unvisited neighbors
        const unvisitedNeighbors: string[] = [];
        for (const neighbor of ADJ_LIST[curr]) {
          if (!visited.includes(neighbor) && !queue.includes(neighbor)) {
            visited.push(neighbor);
            queue.push(neighbor);
            unvisitedNeighbors.push(neighbor);
          }
        }

        setVisitedNodes([...visited]);
        setFrontier([...queue]);

        if (order.length === GRAPH_NODES.length) {
          onSimulationComplete?.();
        }

        if (unvisitedNeighbors.length > 0) {
          setActiveCodeLine(7); // mark v as visited; Q.enqueue(v)
          const msg = `Dequeued vertex ${curr}. Enqueued unvisited neighbors: [${unvisitedNeighbors.join(', ')}] into FIFO Queue.`;
          setExplanation(msg);
          addLog(msg);
        } else {
          const msg = `Dequeued vertex ${curr}. No new unvisited neighbors found from vertex ${curr}.`;
          setExplanation(msg);
          addLog(msg);
        }
      } else {
        if (timerRef.current) clearInterval(timerRef.current);
        setIsRunning(false);
        setActiveNode(null);
        setActiveCodeLine(3); // while Q is not empty (False)
        const finishMsg = `BFS Traversal Completed! Level-Order: ${order.join(' -> ')}`;
        setExplanation(finishMsg);
        addLog(finishMsg);
        onSimulationComplete?.();
      }
    }, speed);
  };

  const runDFS = () => {
    if (timerRef.current) clearInterval(timerRef.current);

    setIsRunning(true);
    setTraversalType('DFS');
    setVisitedNodes([]);
    setFrontier(['0']);
    setActiveNode('0');
    setTraversalOrder([]);
    setActiveCodeLine(2);
    setStepCount(1);
    const initialMsg = 'Starting DFS from Source Vertex 0 (A). Pushed [0] onto LIFO Stack.';
    setExplanation(initialMsg);
    addLog(initialMsg);

    const visited: string[] = [];
    const stack: string[] = ['0'];
    const order: string[] = [];
    let step = 1;

    timerRef.current = setInterval(() => {
      if (stack.length > 0) {
        const curr = stack.pop()!;
        setActiveNode(curr);
        step += 1;
        setStepCount(step);
        setActiveCodeLine(4); // curr = S.pop()

        if (!visited.includes(curr)) {
          visited.push(curr);
          order.push(curr);
          setVisitedNodes([...visited]);
          setTraversalOrder([...order]);
          setActiveCodeLine(6); // mark curr as visited; visit(curr)

          if (order.length === GRAPH_NODES.length) {
            onSimulationComplete?.();
          }

          // Push unvisited neighbors in reverse for standard left-to-right exploration
          const neighbors = [...ADJ_LIST[curr]].reverse();
          const pushedNeighbors: string[] = [];
          for (const neighbor of neighbors) {
            if (!visited.includes(neighbor)) {
              stack.push(neighbor);
              pushedNeighbors.push(neighbor);
            }
          }
          setFrontier([...stack]);

          if (pushedNeighbors.length > 0) {
            setActiveCodeLine(8); // S.push(v)
            const msg = `Popped & visited vertex ${curr}. Pushed unvisited neighbors [${pushedNeighbors.join(', ')}] onto LIFO Stack.`;
            setExplanation(msg);
            addLog(msg);
          } else {
            const msg = `Popped & visited vertex ${curr}. Dead end reached, backtracking.`;
            setExplanation(msg);
            addLog(msg);
          }
        } else {
          setFrontier([...stack]);
        }
      } else {
        if (timerRef.current) clearInterval(timerRef.current);
        setIsRunning(false);
        setActiveNode(null);
        setActiveCodeLine(3); // while S is not empty (False)
        const finishMsg = `DFS Traversal Completed! Depth-First Order: ${order.join(' -> ')}`;
        setExplanation(finishMsg);
        addLog(finishMsg);
        onSimulationComplete?.();
      }
    }, speed);
  };

  const handleReset = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setVisitedNodes([]);
    setActiveNode(null);
    setFrontier([]);
    setTraversalOrder([]);
    setIsRunning(false);
    setActiveCodeLine(-1);
    setStepCount(0);
    setExplanation('Reset graph traversal. Ready for simulation.');
    setLogs(['Reset graph traversal state.']);
  };

  const activeAlgorithmDef = traversalType === 'DFS' ? ALGORITHM_CODES.dfsTraversal : ALGORITHM_CODES.bfsTraversal;

  return (
    <div className="space-y-6">
      {/* 12-Column Responsive Side-by-Side Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left 7 Columns: Interactive Simulation Controls & Canvas */}
        <div className="lg:col-span-7 space-y-4">
          {/* Controls Bar */}
          <div className="bg-[#1E293B] text-white p-3 rounded-xl flex flex-wrap gap-3 items-center justify-between border border-slate-700 shadow-md">
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={runBFS}
                disabled={isRunning}
                className={`px-3.5 py-1.5 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer ${
                  traversalType === 'BFS' && isRunning
                    ? 'bg-blue-500 ring-2 ring-blue-300'
                    : 'bg-blue-600 hover:bg-blue-700 disabled:bg-slate-700'
                }`}
              >
                <Play className="w-3.5 h-3.5" />
                <span>Run BFS (Queue / Level-by-Level)</span>
              </button>

              <button
                onClick={runDFS}
                disabled={isRunning}
                className={`px-3.5 py-1.5 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer ${
                  traversalType === 'DFS' && isRunning
                    ? 'bg-purple-500 ring-2 ring-purple-300'
                    : 'bg-purple-700 hover:bg-purple-600 disabled:bg-slate-700'
                }`}
              >
                <Play className="w-3.5 h-3.5" />
                <span>Run DFS (Stack / Depth-First)</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              {/* Speed Selector */}
              <div className="flex items-center gap-1.5 text-xs text-slate-300">
                <span className="text-slate-400">Speed:</span>
                <select
                  value={speed}
                  onChange={(e) => setSpeed(Number(e.target.value))}
                  disabled={isRunning}
                  className="bg-[#0F172A] text-white border border-slate-700 rounded px-2 py-1 text-xs font-mono cursor-pointer"
                >
                  <option value={1300}>0.75x</option>
                  <option value={900}>1.0x</option>
                  <option value={500}>2.0x</option>
                </select>
              </div>

              <button
                onClick={handleReset}
                className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors border border-slate-700 cursor-pointer"
                title="Reset Graph"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* 2D Graph Topology Canvas */}
          <div className="bg-[#0F172A] border border-slate-800 rounded-xl p-4 flex flex-col justify-center min-h-[260px] overflow-x-auto shadow-md">
            <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2 text-xs font-mono">
              <span className="text-blue-400 font-bold uppercase flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
                2D Graph Topology (6 Vertices, 7 Edges)
              </span>
              <span className="text-slate-400">
                Active: <strong className="text-amber-400">{activeNode ? `Vertex ${activeNode}` : 'Idle'}</strong>
              </span>
            </div>

            <div className="relative w-full max-w-[460px] h-[170px] mx-auto">
              {/* SVG Edges */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none">
                {EDGES.map(([u, v], i) => {
                  const nodeU = GRAPH_NODES.find((n) => n.id === u)!;
                  const nodeV = GRAPH_NODES.find((n) => n.id === v)!;
                  const isTraversed = visitedNodes.includes(u) && visitedNodes.includes(v);

                  return (
                    <line
                      key={i}
                      x1={nodeU.x}
                      y1={nodeU.y}
                      x2={nodeV.x}
                      y2={nodeV.y}
                      stroke={isTraversed ? '#3b82f6' : '#334155'}
                      strokeWidth={isTraversed ? '3' : '1.5'}
                      strokeDasharray={isTraversed ? '' : '3,3'}
                    />
                  );
                })}
              </svg>

              {/* Nodes */}
              {GRAPH_NODES.map((node) => {
                const isVisited = visitedNodes.includes(node.id);
                const isActive = activeNode === node.id;
                const inFrontier = frontier.includes(node.id);

                return (
                  <div
                    key={node.id}
                    style={{ left: `${node.x - 18}px`, top: `${node.y - 18}px` }}
                    className={`absolute w-9 h-9 rounded-full flex items-center justify-center font-mono font-bold text-xs transition-all duration-300 border-2 shadow-md ${
                      isActive
                        ? 'bg-amber-500 text-slate-950 border-amber-300 scale-125 ring-4 ring-amber-400/40 z-20'
                        : isVisited
                        ? 'bg-blue-600 text-white border-blue-400 z-10'
                        : inFrontier
                        ? 'bg-slate-800 text-amber-300 border-amber-500 animate-pulse'
                        : 'bg-slate-800 text-slate-300 border-slate-600'
                    }`}
                  >
                    {node.label.charAt(0)}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Auxiliary Buffers & Traversal Sequence */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {/* Frontier Buffer */}
            <div className="bg-[#1E293B] p-3 rounded-xl border border-slate-700 font-mono text-xs shadow-sm">
              <span className="text-slate-400 block text-[11px] font-semibold mb-1">
                {traversalType === 'BFS' ? 'Frontier Queue (FIFO):' : 'Frontier Stack (LIFO):'}
              </span>
              <div className="flex items-center gap-1.5 flex-wrap min-h-[26px]">
                {frontier.length === 0 ? (
                  <span className="text-slate-500 text-[11px]">[Empty]</span>
                ) : (
                  frontier.map((v, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 bg-amber-950 text-amber-300 border border-amber-800 rounded font-bold text-xs"
                    >
                      {v}
                    </span>
                  ))
                )}
              </div>
            </div>

            {/* Visited Sequence */}
            <div className="bg-[#1E293B] p-3 rounded-xl border border-slate-700 font-mono text-xs shadow-sm">
              <span className="text-slate-400 block text-[11px] font-semibold mb-1">
                Visited Order Sequence:
              </span>
              <div className="flex items-center gap-1.5 flex-wrap min-h-[26px]">
                {traversalOrder.length === 0 ? (
                  <span className="text-slate-500 text-[11px]">[None]</span>
                ) : (
                  traversalOrder.map((v, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 bg-blue-950 text-blue-300 border border-blue-800 rounded font-bold text-xs"
                    >
                      {v}
                    </span>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Real-Time Traversal Output Bar */}
          {traversalOrder.length > 0 && (
            <div className="bg-[#0F172A] p-3 rounded-xl border border-slate-800 flex items-center justify-between text-xs font-mono">
              <span className="text-slate-400 font-semibold">Active Visited Path:</span>
              <span className="text-emerald-400 font-bold">
                {traversalOrder.map((id) => GRAPH_NODES.find((n) => n.id === id)?.label || id).join(' \u2192 ')}
              </span>
            </div>
          )}
        </div>

        {/* Right 5 Columns: Live VisuAlgo Code Panel & Execution Logs */}
        <div className="lg:col-span-5 flex flex-col space-y-3">
          <VisuAlgoCodePanel
            title={activeAlgorithmDef.title}
            explanation={explanation}
            codeLines={activeAlgorithmDef.lines}
            activeLineIndex={activeCodeLine}
            stepInfo={{
              current: stepCount,
              total: 6
            }}
          />

          {/* Invariants & Execution Event Log */}
          <div className="bg-[#0F172A] border border-slate-800 rounded-xl p-3 font-mono text-xs text-slate-300 shadow-md">
            <div className="text-[10px] text-slate-400 uppercase font-bold mb-1.5 flex items-center justify-between">
              <span>Execution Event Stream</span>
              <span className="text-slate-500">O(V + E)</span>
            </div>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {logs.map((log, i) => (
                <div key={i} className="text-slate-400 text-[11px] leading-relaxed truncate">
                  &gt; {log}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
