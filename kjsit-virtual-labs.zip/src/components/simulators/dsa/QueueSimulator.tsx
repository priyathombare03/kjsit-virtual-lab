import React, { useState } from 'react';
import { ArrowRight, RotateCcw, Play, CheckCircle2, AlertCircle, RefreshCw } from 'lucide-react';
import { VisuAlgoCodePanel } from '../common/VisuAlgoCodePanel';
import { ALGORITHM_CODES } from '../common/algorithmCodes';

interface QueueProps {
  onSimulationComplete?: () => void;
}

export const QueueSimulator: React.FC<QueueProps> = ({ onSimulationComplete }) => {
  const [isCircular, setIsCircular] = useState<boolean>(true);
  const CAPACITY = 5;

  const [queue, setQueue] = useState<(number | null)[]>([10, 20, 30, null, null]);
  const [front, setFront] = useState<number>(0);
  const [rear, setRear] = useState<number>(2);
  const [inputValue, setInputValue] = useState<string>('45');
  const [activeCodeLine, setActiveCodeLine] = useState<number>(-1);
  const [explanation, setExplanation] = useState<string>(
    'Circular Queue initialized with 3 elements [10, 20, 30], Front: 0, Rear: 2'
  );
  const [logs, setLogs] = useState<string[]>([
    'Circular Queue initialized with 3 elements [10, 20, 30], Front: 0, Rear: 2'
  ]);

  const addLog = (msg: string) => {
    setLogs((prev) => [msg, ...prev.slice(0, 6)]);
  };

  const isFull = () => {
    if (isCircular) {
      return (rear + 1) % CAPACITY === front && queue[front] !== null;
    } else {
      return rear === CAPACITY - 1;
    }
  };

  const isEmpty = () => {
    return front === -1 || (front === rear && queue[front] === null);
  };

  const handleEnqueue = () => {
    const val = parseInt(inputValue, 10);
    if (isNaN(val)) return;

    if (isFull()) {
      setActiveCodeLine(1); // if (rear + 1) % MAX == front: return QUEUE_FULL
      const err = `OVERFLOW ERROR: Queue is Full! (rear + 1) % ${CAPACITY} == front (${front})`;
      setExplanation(err);
      addLog(err);
      return;
    }

    let newFront = front;
    let newRear = rear;
    const newQueue = [...queue];

    if (isEmpty() || front === -1) {
      newFront = 0;
      newRear = 0;
      setActiveCodeLine(2);
    } else {
      newRear = isCircular ? (rear + 1) % CAPACITY : rear + 1;
      setActiveCodeLine(3);
    }

    newQueue[newRear] = val;
    setQueue(newQueue);
    setFront(newFront);
    setRear(newRear);
    const desc = `ENQUEUE(${val}) -> Placed at index ${newRear}. Rear is now ${newRear}.`;
    setActiveCodeLine(4); // queue[rear] = item
    setExplanation(desc);
    addLog(desc);
    onSimulationComplete?.();
  };

  const handleDequeue = () => {
    if (isEmpty()) {
      setActiveCodeLine(6); // if front == -1: return QUEUE_EMPTY
      const err = 'UNDERFLOW ERROR: Queue is Empty! Front == -1.';
      setExplanation(err);
      addLog(err);
      return;
    }

    const val = queue[front];
    const newQueue = [...queue];
    newQueue[front] = null;

    let newFront = front;
    let newRear = rear;

    if (front === rear) {
      // Last element cleared
      newFront = -1;
      newRear = -1;
      setActiveCodeLine(8); // front = -1; rear = -1
    } else {
      newFront = isCircular ? (front + 1) % CAPACITY : front + 1;
      setActiveCodeLine(9); // front = (front + 1) % MAX
    }

    setQueue(newQueue);
    setFront(newFront);
    setRear(newRear);
    const desc = `DEQUEUE() -> Removed ${val} from Front index ${front}. New Front is ${newFront}.`;
    setActiveCodeLine(7); // val = queue[front]
    setExplanation(desc);
    addLog(desc);
    onSimulationComplete?.();
  };

  const handleReset = () => {
    setQueue([10, 20, 30, null, null]);
    setFront(0);
    setRear(2);
    setActiveCodeLine(-1);
    setExplanation('Queue reset to initial state.');
    setLogs(['Queue reset to initial state.']);
  };

  return (
    <div className="space-y-6">
      {/* Mode Selector & Controls */}
      <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-wrap gap-4 items-center justify-between border border-slate-800">
        <div className="flex flex-wrap items-center gap-3">
          {/* Circular / Linear Switch */}
          <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800">
            <button
              onClick={() => {
                setIsCircular(true);
                handleReset();
              }}
              className={`px-3 py-1 text-xs font-bold rounded ${
                isCircular ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Circular Queue (Ring)
            </button>
            <button
              onClick={() => {
                setIsCircular(false);
                handleReset();
              }}
              className={`px-3 py-1 text-xs font-bold rounded ${
                !isCircular ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Linear Queue
            </button>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-400 font-medium">Value:</span>
            <input
              type="number"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              className="w-16 bg-slate-950 text-white text-xs px-2 py-1 rounded border border-slate-700 text-center font-bold focus:outline-none"
            />
          </div>

          <button
            onClick={handleEnqueue}
            disabled={isFull()}
            className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <ArrowRight className="w-3.5 h-3.5" />
            <span>Enqueue</span>
          </button>

          <button
            onClick={handleDequeue}
            disabled={isEmpty()}
            className="px-3.5 py-1.5 bg-red-800 hover:bg-red-700 disabled:bg-slate-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <span>Dequeue</span>
          </button>
        </div>

        <button
          onClick={handleReset}
          className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors border border-slate-700"
          title="Reset Queue"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Visual Workspace & VisuAlgo Code Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Array / Ring Slot View */}
        <div className="lg:col-span-4 bg-slate-900/95 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between min-h-[340px] shadow-lg">
          <div>
            <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-2">
              <span className="text-xs font-bold text-blue-400 uppercase tracking-wider">
                {isCircular ? 'Circular Ring Buffer' : 'Linear Slots'} ({CAPACITY})
              </span>
              <div className="flex items-center gap-3 text-xs font-mono">
                <span className="text-emerald-400 font-bold">F={front}</span>
                <span className="text-amber-400 font-bold">R={rear}</span>
              </div>
            </div>

            {/* Slots Grid */}
            <div className="grid grid-cols-5 gap-2 py-6">
              {queue.map((val, idx) => {
                const isFront = idx === front;
                const isRear = idx === rear;
                const hasValue = val !== null;

                return (
                  <div key={idx} className="flex flex-col items-center">
                    {/* Pointer Badges */}
                    <div className="h-6 flex items-center gap-1 mb-1">
                      {isFront && (
                        <span className="px-1.5 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-700 rounded text-[9px] font-mono font-bold">
                          F
                        </span>
                      )}
                      {isRear && (
                        <span className="px-1.5 py-0.5 bg-amber-950 text-amber-300 border border-amber-700 rounded text-[9px] font-mono font-bold">
                          R
                        </span>
                      )}
                    </div>

                    {/* Slot Box */}
                    <div
                      className={`w-full aspect-square rounded-xl flex flex-col items-center justify-center border-2 transition-all duration-300 shadow-md ${
                        hasValue
                          ? 'bg-slate-800 border-blue-500/70 text-white font-bold'
                          : 'bg-slate-950/70 border-slate-800 border-dashed text-slate-600'
                      }`}
                    >
                      <span className="text-sm font-mono font-bold">
                        {hasValue ? val : '-'}
                      </span>
                    </div>

                    {/* Index Label */}
                    <span className="text-[11px] font-mono text-slate-500 mt-1.5">
                      [{idx}]
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Formula Display */}
          <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-xs font-mono flex items-center justify-between text-slate-400">
            <span>
              Wrap: <strong className="text-blue-400">(rear+1)%{CAPACITY}</strong>
            </span>
            <span>
              Status:{' '}
              <strong className={isFull() ? 'text-red-400' : isEmpty() ? 'text-amber-400' : 'text-emerald-400'}>
                {isFull() ? 'FULL' : isEmpty() ? 'EMPTY' : 'NORMAL'}
              </strong>
            </span>
          </div>
        </div>

        {/* Registers & Metrics */}
        <div className="lg:col-span-3 bg-slate-900/95 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between min-h-[340px] shadow-lg">
          <div className="space-y-2.5 font-mono text-xs">
            <h4 className="text-xs font-bold text-blue-400 uppercase tracking-wider mb-2 border-b border-slate-800 pb-2">
              Queue State Registers
            </h4>

            <div className="flex justify-between bg-slate-950 p-2 rounded-lg border border-slate-800">
              <span className="text-slate-400">Front Index:</span>
              <span className="text-emerald-400 font-bold">{front}</span>
            </div>
            <div className="flex justify-between bg-slate-950 p-2 rounded-lg border border-slate-800">
              <span className="text-slate-400">Rear Index:</span>
              <span className="text-amber-400 font-bold">{rear}</span>
            </div>
            <div className="flex justify-between bg-slate-950 p-2 rounded-lg border border-slate-800">
              <span className="text-slate-400">Occupied:</span>
              <span className="text-blue-300 font-bold">
                {queue.filter((x) => x !== null).length} / {CAPACITY}
              </span>
            </div>
            <div className="flex justify-between bg-slate-950 p-2 rounded-lg border border-slate-800">
              <span className="text-slate-400">Complexity:</span>
              <span className="text-slate-200 font-bold">O(1)</span>
            </div>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 mt-3 text-xs font-mono text-slate-400">
            <div className="text-[10px] uppercase font-bold text-slate-400 mb-1">
              Latest Log
            </div>
            <div className="text-emerald-300 truncate">
              {logs[0]}
            </div>
          </div>
        </div>

        {/* VisuAlgo Code Panel */}
        <div className="lg:col-span-5">
          <VisuAlgoCodePanel
            title="Queue ADT Operations"
            explanation={explanation}
            codeLines={ALGORITHM_CODES.queueADT.lines}
            activeLineIndex={activeCodeLine}
          />
        </div>
      </div>
    </div>
  );
};
