import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, SkipForward, SkipBack, Sparkles, Search, CheckCircle2, AlertTriangle } from 'lucide-react';

interface KMPStep {
  textIndex: number;
  patternIndex: number;
  matchedChars: number[];
  action: 'lps_compute' | 'compare_match' | 'compare_mismatch' | 'pattern_found' | 'completed';
  description: string;
  foundOccurrences: number[];
}

export const KMPSimulator: React.FC = () => {
  const [text, setText] = useState<string>('ABABDABACDABABCABAB');
  const [pattern, setPattern] = useState<string>('ABABCABAB');
  const [lps, setLps] = useState<number[]>([]);
  const [steps, setSteps] = useState<KMPStep[]>([]);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [speed, setSpeed] = useState<number>(1000);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Compute Longest Proper Prefix which is also Suffix (LPS / Pi table)
  const computeLPS = (pat: string): number[] => {
    const lpsArr = new Array(pat.length).fill(0);
    let len = 0;
    let i = 1;

    while (i < pat.length) {
      if (pat[i] === pat[len]) {
        len++;
        lpsArr[i] = len;
        i++;
      } else {
        if (len !== 0) {
          len = lpsArr[len - 1];
        } else {
          lpsArr[i] = 0;
          i++;
        }
      }
    }
    return lpsArr;
  };

  // Generate KMP search trace
  const generateSteps = (txt: string, pat: string) => {
    if (!txt || !pat) return;
    const computedLps = computeLPS(pat);
    setLps(computedLps);

    const trace: KMPStep[] = [];
    const occurrences: number[] = [];

    trace.push({
      textIndex: 0,
      patternIndex: 0,
      matchedChars: [],
      action: 'lps_compute',
      description: `Constructed LPS Table (\u03c0 array) for pattern "${pat}": [${computedLps.join(', ')}]. Ready to scan text.`,
      foundOccurrences: []
    });

    let i = 0; // index for text
    let j = 0; // index for pattern

    while (i < txt.length) {
      if (pat[j] === txt[i]) {
        trace.push({
          textIndex: i,
          patternIndex: j,
          matchedChars: Array.from({ length: j + 1 }, (_, idx) => i - j + idx),
          action: 'compare_match',
          description: `Match! text[${i}] ('${txt[i]}') == pattern[${j}] ('${pat[j]}'). Increment both text pointer i and pattern pointer j.`,
          foundOccurrences: [...occurrences]
        });
        i++;
        j++;
      }

      if (j === pat.length) {
        const startMatchIdx = i - j;
        occurrences.push(startMatchIdx);
        trace.push({
          textIndex: i - 1,
          patternIndex: j - 1,
          matchedChars: Array.from({ length: pat.length }, (_, idx) => startMatchIdx + idx),
          action: 'pattern_found',
          description: `Pattern completely matched at index ${startMatchIdx}! Utilizing LPS fallback j = lps[${j - 1}] = ${computedLps[j - 1]} for subsequent matches without rewinding i.`,
          foundOccurrences: [...occurrences]
        });
        j = computedLps[j - 1];
      } else if (i < txt.length && pat[j] !== txt[i]) {
        trace.push({
          textIndex: i,
          patternIndex: j,
          matchedChars: j > 0 ? Array.from({ length: j }, (_, idx) => i - j + idx) : [],
          action: 'compare_mismatch',
          description: `Mismatch at text[${i}] ('${txt[i]}') \u2260 pattern[${j}] ('${pat[j]}'). ${
            j !== 0
              ? `KMP skip: pattern pointer j drops to lps[${j - 1}] = ${computedLps[j - 1]} (Zero backtracking on text pointer i!).`
              : `Pattern index j is 0: advance text pointer i to ${i + 1}.`
          }`,
          foundOccurrences: [...occurrences]
        });

        if (j !== 0) {
          j = computedLps[j - 1];
        } else {
          i++;
        }
      }
    }

    trace.push({
      textIndex: txt.length - 1,
      patternIndex: j,
      matchedChars: [],
      action: 'completed',
      description: `KMP String Matching Complete! Total occurrences found: ${occurrences.length}${
        occurrences.length > 0 ? ` at starting index positions [${occurrences.join(', ')}]` : ''
      }. Time Complexity: O(N + M).`,
      foundOccurrences: [...occurrences]
    });

    setSteps(trace);
    setCurrentStepIndex(0);
  };

  useEffect(() => {
    generateSteps(text, pattern);
  }, [text, pattern]);

  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        setCurrentStepIndex(prev => {
          if (prev < steps.length - 1) {
            return prev + 1;
          } else {
            setIsPlaying(false);
            return prev;
          }
        });
      }, speed);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, steps.length, speed]);

  const currentStep = steps[currentStepIndex] || {
    textIndex: 0,
    patternIndex: 0,
    matchedChars: [],
    action: 'lps_compute',
    description: 'Ready',
    foundOccurrences: []
  };

  const handleResetExample = (preset: 'standard' | 'dna' | 'short') => {
    if (preset === 'standard') {
      setText('ABABDABACDABABCABAB');
      setPattern('ABABCABAB');
    } else if (preset === 'dna') {
      setText('AAGCTAAGCTAGCTAAGCTT');
      setPattern('AAGCT');
    } else {
      setText('AAAAABAAAAA');
      setPattern('AAAA');
    }
    setIsPlaying(false);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100 mb-6">
        <div>
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-600"></span>
            Knuth-Morris-Pratt (KMP) Pattern Matcher Visualizer
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Linear time $O(N + M)$ string search utilizing the Longest Prefix Suffix (LPS) $\pi$-table
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold px-2.5 py-1 bg-red-50 text-red-700 rounded-md border border-red-200">
            Step {currentStepIndex + 1} of {steps.length}
          </span>
        </div>
      </div>

      {/* Input controls */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3 mb-6 bg-slate-50 p-3 rounded-lg border border-slate-200">
        <div className="md:col-span-6 flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <label className="text-xs font-semibold text-slate-700 w-16">Text:</label>
            <input
              type="text"
              value={text}
              onChange={e => setText(e.target.value.toUpperCase())}
              className="w-full text-xs font-mono px-3 py-1.5 bg-white border border-slate-300 rounded focus:ring-1 focus:ring-red-500 focus:outline-none"
            />
          </div>
          <div className="flex items-center gap-2">
            <label className="text-xs font-semibold text-slate-700 w-16">Pattern:</label>
            <input
              type="text"
              value={pattern}
              onChange={e => setPattern(e.target.value.toUpperCase())}
              className="w-full text-xs font-mono px-3 py-1.5 bg-white border border-slate-300 rounded focus:ring-1 focus:ring-red-500 focus:outline-none"
            />
          </div>
        </div>
        <div className="md:col-span-6 flex flex-col justify-between items-end gap-2">
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-slate-500">Presets:</span>
            <button
              onClick={() => handleResetExample('standard')}
              className="px-2 py-1 bg-white border border-slate-300 text-slate-700 text-xs rounded hover:bg-slate-50"
            >
              Standard
            </button>
            <button
              onClick={() => handleResetExample('dna')}
              className="px-2 py-1 bg-white border border-slate-300 text-slate-700 text-xs rounded hover:bg-slate-50"
            >
              DNA Sequence
            </button>
            <button
              onClick={() => handleResetExample('short')}
              className="px-2 py-1 bg-white border border-slate-300 text-slate-700 text-xs rounded hover:bg-slate-50"
            >
              Repetitive
            </button>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <span>Speed:</span>
            <select
              value={speed}
              onChange={e => setSpeed(Number(e.target.value))}
              className="bg-white border border-slate-300 rounded px-2 py-1 text-xs"
            >
              <option value={1500}>0.75x</option>
              <option value={1000}>1.0x</option>
              <option value={500}>2.0x</option>
            </select>
          </div>
        </div>
      </div>

      {/* LPS Table Display */}
      <div className="mb-6 p-4 rounded-xl bg-slate-900 text-white border border-slate-800">
        <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center justify-between">
          <span>LPS Table ($\pi$ Array) - Preprocessed in $O(M)$</span>
          <span className="text-[11px] text-amber-400 font-normal">Controls fallback jumps on mismatch</span>
        </h4>
        <div className="overflow-x-auto">
          <div className="inline-flex gap-1.5 min-w-full">
            {pattern.split('').map((char, idx) => (
              <div key={idx} className="flex flex-col items-center">
                <span className="text-[10px] text-slate-400 font-mono">[{idx}]</span>
                <div className="w-8 h-8 rounded bg-slate-800 border border-slate-700 flex items-center justify-center font-bold font-mono text-sm text-slate-200 my-1">
                  {char}
                </div>
                <div className="w-8 h-7 rounded bg-red-950/80 border border-red-500/40 flex items-center justify-center font-bold font-mono text-xs text-red-300">
                  {lps[idx] !== undefined ? lps[idx] : 0}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main String Alignment Stage */}
      <div className="bg-slate-950 rounded-xl p-6 mb-6 text-white min-h-[220px] flex flex-col justify-between relative overflow-hidden">
        {/* Status */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-2 text-xs">
          <div className="flex items-center gap-4">
            <span className="text-slate-400">Text Pointer $i$: <strong className="text-blue-400 font-mono">{currentStep.textIndex}</strong></span>
            <span className="text-slate-400">Pattern Pointer $j$: <strong className="text-amber-400 font-mono">{currentStep.patternIndex}</strong></span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-emerald-400 font-mono font-bold">
              Matches Found: {currentStep.foundOccurrences.length}
            </span>
          </div>
        </div>

        {/* Text and Pattern Alignment Grid */}
        <div className="py-6 overflow-x-auto">
          {/* Text String Row */}
          <div className="mb-4">
            <div className="text-[11px] text-slate-400 mb-1 font-semibold">Text ($N = {text.length}$):</div>
            <div className="inline-flex gap-1.5">
              {text.split('').map((char, idx) => {
                const isCurrentI = idx === currentStep.textIndex;
                const isMatched = currentStep.matchedChars.includes(idx);
                const isFoundOccurrence = currentStep.foundOccurrences.some(o => idx >= o && idx < o + pattern.length);

                let bg = 'bg-slate-800 border-slate-700 text-slate-200';
                if (isFoundOccurrence) {
                  bg = 'bg-emerald-900 border-emerald-500 text-emerald-100 ring-1 ring-emerald-400';
                } else if (isMatched) {
                  bg = 'bg-emerald-700 border-emerald-400 text-white';
                } else if (isCurrentI) {
                  bg = 'bg-blue-600 border-blue-400 text-white ring-2 ring-blue-400';
                }

                return (
                  <div key={idx} className="flex flex-col items-center">
                    <span className="text-[9px] text-slate-400 font-mono">{idx}</span>
                    <div className={`w-8 h-8 rounded border flex items-center justify-center font-bold font-mono text-sm transition-all ${bg}`}>
                      {char}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Pattern Offset Row */}
          <div>
            <div className="text-[11px] text-slate-400 mb-1 font-semibold">Pattern ($M = {pattern.length}$) Aligned:</div>
            <div className="inline-flex gap-1.5">
              {/* Spacer boxes to shift pattern */}
              {Array.from({ length: Math.max(0, currentStep.textIndex - currentStep.patternIndex) }).map((_, sIdx) => (
                <div key={`spacer-${sIdx}`} className="w-8 h-8"></div>
              ))}
              {/* Pattern characters */}
              {pattern.split('').map((char, pIdx) => {
                const isCurrentJ = pIdx === currentStep.patternIndex;
                const isMatched = pIdx < currentStep.patternIndex || currentStep.action === 'pattern_found';
                const isMismatch = isCurrentJ && currentStep.action === 'compare_mismatch';

                let bg = 'bg-slate-800 border-slate-700 text-slate-300';
                if (isMismatch) {
                  bg = 'bg-red-600 border-red-400 text-white animate-shake';
                } else if (isMatched) {
                  bg = 'bg-emerald-600 border-emerald-400 text-white';
                } else if (isCurrentJ) {
                  bg = 'bg-amber-600 border-amber-400 text-white ring-2 ring-amber-400';
                }

                return (
                  <div key={pIdx} className="flex flex-col items-center">
                    <div className={`w-8 h-8 rounded border flex items-center justify-center font-bold font-mono text-sm transition-all ${bg}`}>
                      {char}
                    </div>
                    <span className="text-[9px] text-slate-400 font-mono mt-1">j:{pIdx}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Description */}
        <div className="bg-slate-900/90 rounded-lg p-3 border border-slate-800 text-xs">
          <p className="text-slate-200 font-medium leading-relaxed">
            {currentStep.description}
          </p>
        </div>
      </div>

      {/* Playback Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentStepIndex(0)}
            className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
            title="Reset"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <button
            onClick={() => setCurrentStepIndex(prev => Math.max(0, prev - 1))}
            disabled={currentStepIndex === 0}
            className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-40"
            title="Previous"
          >
            <SkipBack className="w-4 h-4" />
          </button>
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-semibold rounded-lg shadow-sm flex items-center gap-1.5 transition-colors"
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4" /> Pause
              </>
            ) : (
              <>
                <Play className="w-4 h-4" /> Play Simulation
              </>
            )}
          </button>
          <button
            onClick={() => setCurrentStepIndex(prev => Math.min(steps.length - 1, prev + 1))}
            disabled={currentStepIndex === steps.length - 1}
            className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-40"
            title="Next"
          >
            <SkipForward className="w-4 h-4" />
          </button>
        </div>

        {/* Legend */}
        <div className="hidden sm:flex items-center gap-4 text-xs">
          <span className="flex items-center gap-1.5 text-slate-600">
            <span className="w-3 h-3 rounded bg-emerald-600"></span> Matched
          </span>
          <span className="flex items-center gap-1.5 text-slate-600">
            <span className="w-3 h-3 rounded bg-amber-600"></span> Active Pointer
          </span>
          <span className="flex items-center gap-1.5 text-slate-600">
            <span className="w-3 h-3 rounded bg-red-600"></span> Mismatch (Jump LPS)
          </span>
        </div>
      </div>
    </div>
  );
};
