import React, { useState, useEffect } from 'react';
import {
  Play,
  RotateCcw,
  Sparkles,
  Zap,
  Sliders,
  CheckCircle2,
  TrendingUp,
  BrainCircuit,
  Cpu,
  Layers,
  ArrowRight,
  Info,
  RefreshCw,
  BarChart2,
  HelpCircle
} from 'lucide-react';
import { useSimulationContext } from '../common/SimulationContext';

interface Props {
  experimentId: string;
  onSimulationComplete?: () => void;
}

export const DRLSimulator: React.FC<Props> = ({ experimentId, onSimulationComplete }) => {
  const simContext = useSimulationContext();

  const handleComplete = () => {
    if (onSimulationComplete) onSimulationComplete();
    simContext?.onSimulationComplete();
  };

  // Switch between simulators based on experiment ID
  switch (experimentId) {
    case 'dl-exp1':
      return <TeachableMachineSimulator onComplete={handleComplete} />;
    case 'dl-exp2':
      return <XORBackpropagationSimulator onComplete={handleComplete} />;
    case 'dl-exp3':
      return <DLFrameworksSimulator onComplete={handleComplete} />;
    case 'dl-exp4':
      return <CNNDigitSimulator onComplete={handleComplete} />;
    case 'dl-exp5':
      return <LSTMGRUSimulator onComplete={handleComplete} />;
    case 'dl-exp6':
      return <MultiArmedBanditSimulator onComplete={handleComplete} />;
    case 'dl-exp7':
      return <MDPDiscountSimulator onComplete={handleComplete} />;
    case 'dl-exp8':
      return <DPValueIterationSimulator onComplete={handleComplete} />;
    case 'dl-exp9':
      return <MonteCarloSimulator onComplete={handleComplete} />;
    default:
      return <MDPDiscountSimulator onComplete={handleComplete} />;
  }
};

// =========================================================================
// Experiment 1: Teachable Machine Simulator
// =========================================================================
const TeachableMachineSimulator: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [class1Name, setClass1Name] = useState('Class 1: Mask');
  const [class2Name, setClass2Name] = useState('Class 2: No Mask');
  const [class1Samples, setClass1Samples] = useState(35);
  const [class2Samples, setClass2Samples] = useState(32);
  const [epochs, setEpochs] = useState(50);
  const [batchSize, setBatchSize] = useState(16);
  const [learningRate, setLearningRate] = useState(0.001);
  const [isTraining, setIsTraining] = useState(false);
  const [progress, setProgress] = useState(0);
  const [trained, setTrained] = useState(false);
  const [testInput, setTestInput] = useState<'mask' | 'nomask'>('mask');

  const startTraining = () => {
    setIsTraining(true);
    setProgress(0);
    let cur = 0;
    const interval = setInterval(() => {
      cur += 5;
      setProgress(cur);
      if (cur >= 100) {
        clearInterval(interval);
        setIsTraining(false);
        setTrained(true);
        onComplete();
      }
    }, 80);
  };

  const confidence1 = trained
    ? testInput === 'mask'
      ? 96 + Math.round(Math.random() * 3)
      : 3 + Math.round(Math.random() * 2)
    : 50;
  const confidence2 = 100 - confidence1;

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-100 pb-4 mb-6">
        <div>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold bg-purple-50 text-purple-700 border border-purple-200 mb-1">
            Experiment 1 · No-Code AI
          </span>
          <h3 className="text-lg font-bold text-zinc-900">Teachable Machine: Two-Class Vision Classifier</h3>
          <p className="text-xs text-zinc-500">MobileNet Transfer Learning with browser-side TensorFlow.js</p>
        </div>
        <button
          type="button"
          onClick={startTraining}
          disabled={isTraining}
          className="px-4 py-2 bg-somaiya hover:bg-somaiya-dark active:bg-somaiya-deep text-white text-xs font-bold rounded-lg shadow-sm flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
        >
          {isTraining ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
          <span>{isTraining ? `Training (${progress}%)` : trained ? 'Retrain Model' : 'Train Model'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-6">
        {/* Class 1 Panel */}
        <div className="bg-purple-50/50 border border-purple-200/80 rounded-xl p-4">
          <label className="text-xs font-bold text-purple-900 block mb-1">Class 1 Label</label>
          <input
            type="text"
            value={class1Name}
            onChange={(e) => setClass1Name(e.target.value)}
            className="w-full text-xs font-semibold px-2.5 py-1.5 bg-white border border-purple-200 rounded-md mb-3"
          />
          <div className="flex items-center justify-between text-xs text-purple-800 mb-2">
            <span>Captured Samples:</span>
            <span className="font-mono font-bold">{class1Samples}</span>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setClass1Samples((prev) => prev + 5)}
              className="flex-1 py-1.5 bg-white hover:bg-purple-100 text-purple-900 text-xs font-bold rounded border border-purple-300"
            >
              +5 Samples
            </button>
            <button
              type="button"
              onClick={() => setClass1Samples(10)}
              className="px-2 py-1.5 bg-white hover:bg-zinc-100 text-zinc-600 text-xs rounded border border-zinc-200"
            >
              Reset
            </button>
          </div>
        </div>

        {/* Class 2 Panel */}
        <div className="bg-amber-50/50 border border-amber-200/80 rounded-xl p-4">
          <label className="text-xs font-bold text-amber-900 block mb-1">Class 2 Label</label>
          <input
            type="text"
            value={class2Name}
            onChange={(e) => setClass2Name(e.target.value)}
            className="w-full text-xs font-semibold px-2.5 py-1.5 bg-white border border-amber-200 rounded-md mb-3"
          />
          <div className="flex items-center justify-between text-xs text-amber-800 mb-2">
            <span>Captured Samples:</span>
            <span className="font-mono font-bold">{class2Samples}</span>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setClass2Samples((prev) => prev + 5)}
              className="flex-1 py-1.5 bg-white hover:bg-amber-100 text-amber-900 text-xs font-bold rounded border border-amber-300"
            >
              +5 Samples
            </button>
            <button
              type="button"
              onClick={() => setClass2Samples(10)}
              className="px-2 py-1.5 bg-white hover:bg-zinc-100 text-zinc-600 text-xs rounded border border-zinc-200"
            >
              Reset
            </button>
          </div>
        </div>

        {/* Hyperparameters Panel */}
        <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-4 text-xs space-y-2.5">
          <div className="font-bold text-zinc-900 flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-somaiya" />
            <span>Hyperparameters</span>
          </div>
          <div>
            <div className="flex justify-between text-zinc-600 mb-1">
              <span>Epochs:</span>
              <span className="font-mono font-bold text-zinc-900">{epochs}</span>
            </div>
            <input
              type="range"
              min="10"
              max="100"
              step="10"
              value={epochs}
              onChange={(e) => setEpochs(Number(e.target.value))}
              className="w-full accent-somaiya"
            />
          </div>
          <div className="flex justify-between text-zinc-600">
            <span>Batch Size:</span>
            <span className="font-mono font-bold text-zinc-900">{batchSize}</span>
          </div>
          <div className="flex justify-between text-zinc-600">
            <span>Learning Rate:</span>
            <span className="font-mono font-bold text-zinc-900">{learningRate}</span>
          </div>
        </div>
      </div>

      {/* Real-Time Inference Test */}
      <div className="border border-zinc-200 rounded-xl p-5 bg-zinc-50/50">
        <h4 className="text-xs font-bold text-zinc-900 mb-3 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-somaiya" />
          <span>Real-Time Inference Preview & Confidence Meters</span>
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 items-center">
          <div>
            <span className="text-xs text-zinc-500 block mb-2">Simulate Input Image to Webcam:</span>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setTestInput('mask')}
                className={`flex-1 py-2 text-xs font-bold rounded-lg border transition-all ${
                  testInput === 'mask'
                    ? 'bg-purple-600 text-white border-purple-700 shadow-xs'
                    : 'bg-white text-zinc-700 border-zinc-200 hover:bg-zinc-50'
                }`}
              >
                Present {class1Name}
              </button>
              <button
                type="button"
                onClick={() => setTestInput('nomask')}
                className={`flex-1 py-2 text-xs font-bold rounded-lg border transition-all ${
                  testInput === 'nomask'
                    ? 'bg-amber-600 text-white border-amber-700 shadow-xs'
                    : 'bg-white text-zinc-700 border-zinc-200 hover:bg-zinc-50'
                }`}
              >
                Present {class2Name}
              </button>
            </div>
          </div>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs font-bold mb-1">
                <span className="text-purple-900">{class1Name}</span>
                <span className="font-mono text-purple-700">{confidence1}%</span>
              </div>
              <div className="h-3 bg-zinc-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-purple-600 transition-all duration-300 rounded-full"
                  style={{ width: `${confidence1}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-bold mb-1">
                <span className="text-amber-900">{class2Name}</span>
                <span className="font-mono text-amber-700">{confidence2}%</span>
              </div>
              <div className="h-3 bg-zinc-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-amber-500 transition-all duration-300 rounded-full"
                  style={{ width: `${confidence2}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {trained && (
          <div className="mt-4 p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center justify-between text-xs text-emerald-800">
            <span className="flex items-center gap-1.5 font-semibold">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Model successfully trained with MobileNet transfer learning backbone. Ready for export!</span>
            </span>
            <span className="font-mono text-[11px] bg-white px-2 py-0.5 rounded border border-emerald-200">
              TensorFlow.js Ready
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

// =========================================================================
// Experiment 2: XOR Backpropagation Simulator
// =========================================================================
const XORBackpropagationSimulator: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [learningRate, setLearningRate] = useState(0.5);
  const [epoch, setEpoch] = useState(0);
  const [loss, setLoss] = useState(0.25);
  const [isTraining, setIsTraining] = useState(false);
  const [predictions, setPredictions] = useState([
    { x1: 0, x2: 0, target: 0, out: 0.5 },
    { x1: 0, x2: 1, target: 1, out: 0.5 },
    { x1: 1, x2: 0, target: 1, out: 0.5 },
    { x1: 1, x2: 1, target: 0, out: 0.5 }
  ]);

  const trainStep = () => {
    setEpoch((prev) => prev + 500);
    setLoss((prev) => Math.max(0.001, prev * 0.72));
    setPredictions([
      { x1: 0, x2: 0, target: 0, out: Math.max(0.02, 0.5 - epoch * 0.0003) },
      { x1: 0, x2: 1, target: 1, out: Math.min(0.98, 0.5 + epoch * 0.0003) },
      { x1: 1, x2: 0, target: 1, out: Math.min(0.98, 0.5 + epoch * 0.0003) },
      { x1: 1, x2: 1, target: 0, out: Math.max(0.03, 0.5 - epoch * 0.0003) }
    ]);
  };

  const trainFull = () => {
    setIsTraining(true);
    let curEpoch = 0;
    const interval = setInterval(() => {
      curEpoch += 1000;
      setEpoch(curEpoch);
      const curLoss = 0.25 * Math.exp(-curEpoch / 1800);
      setLoss(curLoss);

      setPredictions([
        { x1: 0, x2: 0, target: 0, out: Math.max(0.015, 0.5 * Math.exp(-curEpoch / 1500)) },
        { x1: 0, x2: 1, target: 1, out: Math.min(0.985, 1 - 0.5 * Math.exp(-curEpoch / 1500)) },
        { x1: 1, x2: 0, target: 1, out: Math.min(0.985, 1 - 0.5 * Math.exp(-curEpoch / 1500)) },
        { x1: 1, x2: 1, target: 0, out: Math.max(0.02, 0.5 * Math.exp(-curEpoch / 1500)) }
      ]);

      if (curEpoch >= 8000) {
        clearInterval(interval);
        setIsTraining(false);
        onComplete();
      }
    }, 120);
  };

  const reset = () => {
    setEpoch(0);
    setLoss(0.25);
    setPredictions([
      { x1: 0, x2: 0, target: 0, out: 0.5 },
      { x1: 0, x2: 1, target: 1, out: 0.5 },
      { x1: 1, x2: 0, target: 1, out: 0.5 },
      { x1: 1, x2: 1, target: 0, out: 0.5 }
    ]);
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-100 pb-4 mb-6">
        <div>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold bg-red-50 text-somaiya border border-red-200 mb-1">
            Experiment 2 · Neural Networks
          </span>
          <h3 className="text-lg font-bold text-zinc-900">XOR Gate via Backpropagation in Multi-Layer Perceptron</h3>
          <p className="text-xs text-zinc-500">2-2-1 Architecture with Sigmoid Activations & Gradient Descent</p>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={reset}
            className="px-3 py-2 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-bold rounded-lg border border-zinc-300 flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
          <button
            type="button"
            onClick={trainFull}
            disabled={isTraining}
            className="px-4 py-2 bg-somaiya hover:bg-somaiya-dark active:bg-somaiya-deep text-white text-xs font-bold rounded-lg shadow-sm flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isTraining ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isTraining ? `Training (Epoch ${epoch})` : 'Train MLP (8000 Epochs)'}</span>
          </button>
        </div>
      </div>

      {/* Network Metrics */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3.5 text-center">
          <span className="text-[11px] text-zinc-500 font-semibold block uppercase">Epoch</span>
          <span className="text-xl font-extrabold text-zinc-900 font-mono">{epoch}</span>
        </div>
        <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3.5 text-center">
          <span className="text-[11px] text-zinc-500 font-semibold block uppercase">MSE Loss</span>
          <span className="text-xl font-extrabold text-somaiya font-mono">{loss.toFixed(6)}</span>
        </div>
        <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3.5 text-center">
          <span className="text-[11px] text-zinc-500 font-semibold block uppercase">Learning Rate (η)</span>
          <span className="text-xl font-extrabold text-indigo-700 font-mono">{learningRate}</span>
        </div>
      </div>

      {/* XOR Truth Table & Predictions */}
      <div className="border border-zinc-200 rounded-xl overflow-hidden mb-6">
        <div className="bg-zinc-100 px-4 py-2.5 font-bold text-xs text-zinc-800 flex justify-between">
          <span>XOR Truth Table & Network Output</span>
          <span className="text-zinc-500">Target vs Actual Output ŷ = σ(W₂ · a₁ + b₂)</span>
        </div>
        <div className="divide-y divide-zinc-200">
          {predictions.map((p, idx) => {
            const isCorrect = Math.abs(p.out - p.target) < 0.15;
            return (
              <div key={idx} className="px-4 py-3 flex items-center justify-between text-xs bg-white hover:bg-zinc-50">
                <div className="flex items-center gap-3">
                  <span className="font-mono bg-zinc-100 px-2 py-1 rounded text-zinc-700 font-bold">
                    X₁={p.x1}, X₂={p.x2}
                  </span>
                  <span className="text-zinc-400">→</span>
                  <span className="font-semibold text-zinc-700">Target: <strong className="text-zinc-900">{p.target}</strong></span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="font-mono text-zinc-900 font-bold">
                    Output: {p.out.toFixed(4)}
                  </span>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                      isCorrect ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {isCorrect ? 'Learned' : 'Converging...'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {epoch >= 6000 && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center gap-2 text-xs text-emerald-800 font-semibold">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Non-linear XOR classification solved successfully with zero classification error using Error Backpropagation!</span>
        </div>
      )}
    </div>
  );
};

// =========================================================================
// Experiment 3: Deep Learning Frameworks Simulator
// =========================================================================
const DLFrameworksSimulator: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [selectedFramework, setSelectedFramework] = useState<'tensorflow' | 'keras' | 'theano' | 'mxnet' | 'cntk'>('keras');
  const [hiddenNeurons, setHiddenNeurons] = useState(32);
  const [outputClasses, setOutputClasses] = useState(10);
  const [inputFeatures] = useState(784);

  const hiddenParams = inputFeatures * hiddenNeurons + hiddenNeurons;
  const outputParams = hiddenNeurons * outputClasses + outputClasses;
  const totalParams = hiddenParams + outputParams;

  useEffect(() => {
    onComplete();
  }, []);

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm">
      <div className="border-b border-zinc-100 pb-4 mb-6">
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200 mb-1">
          Experiment 3 · Frameworks Architecture
        </span>
        <h3 className="text-lg font-bold text-zinc-900">Modern Deep Learning Frameworks & Keras Model Builder</h3>
        <p className="text-xs text-zinc-500">Surveying TensorFlow, Keras, MXNet, Theano & CNTK</p>
      </div>

      {/* Framework Selector Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mb-6">
        {[
          { id: 'keras', name: 'Keras', creator: 'Francois Chollet' },
          { id: 'tensorflow', name: 'TensorFlow', creator: 'Google Brain' },
          { id: 'mxnet', name: 'Apache MXNet', creator: 'Apache' },
          { id: 'theano', name: 'Theano', creator: 'MILA Montreal' },
          { id: 'cntk', name: 'CNTK', creator: 'Microsoft' }
        ].map((f) => (
          <button
            key={f.id}
            type="button"
            onClick={() => setSelectedFramework(f.id as any)}
            className={`p-3 rounded-xl border text-left transition-all ${
              selectedFramework === f.id
                ? 'bg-somaiya text-white border-somaiya-dark shadow-sm'
                : 'bg-zinc-50 text-zinc-700 border-zinc-200 hover:bg-zinc-100'
            }`}
          >
            <div className="font-bold text-xs">{f.name}</div>
            <div className={`text-[10px] truncate ${selectedFramework === f.id ? 'text-red-100' : 'text-zinc-400'}`}>
              {f.creator}
            </div>
          </button>
        ))}
      </div>

      {/* Interactive Keras Sequential Model Parameter Calculator */}
      <div className="border border-zinc-200 rounded-xl p-5 bg-zinc-50/50">
        <h4 className="text-xs font-bold text-zinc-900 mb-3 flex items-center gap-2">
          <Cpu className="w-4 h-4 text-somaiya" />
          <span>Interactive Keras Sequential Model Parameter Calculator</span>
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 items-center mb-4">
          <div className="space-y-3 text-xs">
            <div>
              <div className="flex justify-between text-zinc-600 mb-1">
                <span>Input Shape (Flattened):</span>
                <span className="font-mono font-bold text-zinc-900">{inputFeatures} (28×28)</span>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-zinc-600 mb-1">
                <span>Hidden Layer Neurons:</span>
                <span className="font-mono font-bold text-zinc-900">{hiddenNeurons}</span>
              </div>
              <input
                type="range"
                min="16"
                max="128"
                step="16"
                value={hiddenNeurons}
                onChange={(e) => setHiddenNeurons(Number(e.target.value))}
                className="w-full accent-somaiya"
              />
            </div>
            <div>
              <div className="flex justify-between text-zinc-600 mb-1">
                <span>Output Classes (Softmax):</span>
                <span className="font-mono font-bold text-zinc-900">{outputClasses}</span>
              </div>
              <input
                type="range"
                min="2"
                max="20"
                step="1"
                value={outputClasses}
                onChange={(e) => setOutputClasses(Number(e.target.value))}
                className="w-full accent-somaiya"
              />
            </div>
          </div>

          <div className="bg-white border border-zinc-200 rounded-xl p-4 font-mono text-xs space-y-2">
            <div className="text-[11px] text-zinc-400 border-b border-zinc-100 pb-1">LAYER BREAKDOWN & PARAMETERS</div>
            <div className="flex justify-between">
              <span className="text-zinc-600">Dense Hidden:</span>
              <span className="font-bold text-zinc-900">{hiddenParams.toLocaleString()} params</span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-600">Dense Output:</span>
              <span className="font-bold text-zinc-900">{outputParams.toLocaleString()} params</span>
            </div>
            <div className="border-t border-zinc-200 pt-2 flex justify-between text-sm font-bold text-somaiya">
              <span>Total Trainable:</span>
              <span>{totalParams.toLocaleString()} params</span>
            </div>
          </div>
        </div>

        <div className="bg-zinc-900 text-zinc-200 font-mono text-[11px] p-3 rounded-lg overflow-x-auto">
          <code>{`model = Sequential([
    Dense(${hiddenNeurons}, input_shape=(${inputFeatures},), activation='relu'),
    Dense(${outputClasses}, activation='softmax')
])
# Total Trainable Parameters: ${totalParams.toLocaleString()}`}</code>
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// Experiment 4: CNN Digit Classifier Simulator
// =========================================================================
const CNNDigitSimulator: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [selectedDigit, setSelectedDigit] = useState<number>(7);
  const [selectedKernel, setSelectedKernel] = useState<'sobelH' | 'sobelV' | 'blur' | 'sharpen'>('sobelV');
  const [activeTab, setActiveTab] = useState<'input' | 'conv' | 'pool'>('conv');

  const kernels = {
    sobelV: { name: 'Sobel Vertical Filter', matrix: [[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]] },
    sobelH: { name: 'Sobel Horizontal Filter', matrix: [[-1, -2, -1], [0, 0, 0], [1, 2, 1]] },
    sharpen: { name: 'Ridge / Sharpen Filter', matrix: [[0, -1, 0], [-1, 5, -1], [0, -1, 0]] },
    blur: { name: 'Gaussian Blur Filter', matrix: [[1, 2, 1], [2, 4, 2], [1, 2, 1]] }
  };

  useEffect(() => {
    onComplete();
  }, [selectedKernel, selectedDigit]);

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm">
      <div className="border-b border-zinc-100 pb-4 mb-6">
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-200 mb-1">
          Experiment 4 · Computer Vision
        </span>
        <h3 className="text-lg font-bold text-zinc-900">CNN Multiclass Object Classification on Image Data</h3>
        <p className="text-xs text-zinc-500">Conv2D (3×3), MaxPooling2D (2×2), Dropout & Softmax Digit Recognition</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-6">
        {/* Digit Selection */}
        <div className="border border-zinc-200 rounded-xl p-4 bg-zinc-50/50">
          <label className="text-xs font-bold text-zinc-800 block mb-2">1. Select Input Digit (0-9):</label>
          <div className="grid grid-cols-5 gap-1.5">
            {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => setSelectedDigit(d)}
                className={`py-2 text-xs font-bold rounded-lg border transition-all ${
                  selectedDigit === d
                    ? 'bg-somaiya text-white border-somaiya-dark'
                    : 'bg-white text-zinc-700 border-zinc-200 hover:bg-zinc-100'
                }`}
              >
                {d}
              </button>
            ))}
          </div>
        </div>

        {/* Filter Selection */}
        <div className="border border-zinc-200 rounded-xl p-4 bg-zinc-50/50">
          <label className="text-xs font-bold text-zinc-800 block mb-2">2. Select Conv2D Kernel (3×3):</label>
          <div className="space-y-1.5">
            {Object.entries(kernels).map(([key, k]) => (
              <button
                key={key}
                type="button"
                onClick={() => setSelectedKernel(key as any)}
                className={`w-full py-1.5 px-2.5 text-xs text-left rounded-lg border transition-all ${
                  selectedKernel === key
                    ? 'bg-indigo-600 text-white border-indigo-700 font-bold'
                    : 'bg-white text-zinc-700 border-zinc-200 hover:bg-zinc-100'
                }`}
              >
                {k.name}
              </button>
            ))}
          </div>
        </div>

        {/* Active Kernel Matrix */}
        <div className="border border-zinc-200 rounded-xl p-4 bg-zinc-50/50 flex flex-col justify-center items-center">
          <span className="text-[11px] font-bold text-zinc-500 uppercase mb-2">Kernel Weights Matrix</span>
          <div className="grid grid-cols-3 gap-1.5 bg-zinc-900 p-2.5 rounded-lg font-mono text-xs">
            {kernels[selectedKernel].matrix.flat().map((val, idx) => (
              <div
                key={idx}
                className="w-8 h-8 rounded bg-zinc-800 text-white flex items-center justify-center font-bold"
              >
                {val}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Feature Map Visualizer */}
      <div className="border border-zinc-200 rounded-xl p-4 bg-zinc-900 text-white">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3 mb-4 text-xs">
          <span className="font-bold flex items-center gap-2">
            <Layers className="w-4 h-4 text-indigo-400" />
            <span>CNN Feature Activation & Downsampling Flow</span>
          </span>
          <div className="flex gap-1.5">
            <button
              type="button"
              onClick={() => setActiveTab('input')}
              className={`px-2.5 py-1 rounded text-[11px] font-bold ${
                activeTab === 'input' ? 'bg-indigo-600 text-white' : 'bg-zinc-800 text-zinc-400'
              }`}
            >
              Input (28×28)
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('conv')}
              className={`px-2.5 py-1 rounded text-[11px] font-bold ${
                activeTab === 'conv' ? 'bg-indigo-600 text-white' : 'bg-zinc-800 text-zinc-400'
              }`}
            >
              Conv2D (26×26)
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('pool')}
              className={`px-2.5 py-1 rounded text-[11px] font-bold ${
                activeTab === 'pool' ? 'bg-indigo-600 text-white' : 'bg-zinc-800 text-zinc-400'
              }`}
            >
              MaxPool (13×13)
            </button>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-around gap-6 py-4">
          <div className="text-center">
            <div className="text-xs text-zinc-400 mb-1">Digit Sample</div>
            <div className="w-24 h-24 bg-black border border-zinc-700 rounded-lg flex items-center justify-center text-4xl font-extrabold text-white">
              {selectedDigit}
            </div>
            <div className="text-[11px] text-zinc-500 mt-1">28 × 28 Grayscale</div>
          </div>

          <ArrowRight className="w-6 h-6 text-zinc-600 hidden sm:block" />

          <div className="text-center">
            <div className="text-xs text-zinc-400 mb-1">Extracted Feature Map</div>
            <div className="w-24 h-24 bg-zinc-950 border border-indigo-500/50 rounded-lg flex items-center justify-center relative overflow-hidden shadow-inner">
              {/* Simulated edge detection texture */}
              <div className="absolute inset-2 border-2 border-indigo-400/60 rounded flex items-center justify-center text-3xl font-extrabold text-indigo-300">
                {selectedDigit}
              </div>
            </div>
            <div className="text-[11px] text-indigo-400 mt-1">
              {activeTab === 'input' ? 'Raw Input' : activeTab === 'conv' ? 'Filtered (26×26)' : 'Max Pooled (13×13)'}
            </div>
          </div>

          <ArrowRight className="w-6 h-6 text-zinc-600 hidden sm:block" />

          <div className="text-center">
            <div className="text-xs text-zinc-400 mb-1">Softmax Prediction</div>
            <div className="w-24 h-24 bg-emerald-950/40 border border-emerald-500/50 rounded-lg flex flex-col items-center justify-center">
              <span className="text-3xl font-extrabold text-emerald-400">{selectedDigit}</span>
              <span className="text-[10px] text-emerald-300 font-mono">99.4% Prob</span>
            </div>
            <div className="text-[11px] text-emerald-400 mt-1">10-Class Dense</div>
          </div>
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// Experiment 5: LSTM vs GRU Simulator
// =========================================================================
const LSTMGRUSimulator: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [modelType, setModelType] = useState<'lstm' | 'gru'>('lstm');
  const [forgetGate, setForgetGate] = useState(0.85);
  const [inputGate, setInputGate] = useState(0.65);
  const [outputGate, setOutputGate] = useState(0.92);

  useEffect(() => {
    onComplete();
  }, [modelType]);

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm">
      <div className="border-b border-zinc-100 pb-4 mb-6">
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200 mb-1">
          Experiment 5 · Sequence Modeling & NLP
        </span>
        <h3 className="text-lg font-bold text-zinc-900">RNN Architectures: LSTM vs GRU Gating Mechanisms</h3>
        <p className="text-xs text-zinc-500">Mitigating Vanishing Gradients via Additive Memory Cell States</p>
      </div>

      <div className="flex gap-2 mb-6">
        <button
          type="button"
          onClick={() => setModelType('lstm')}
          className={`flex-1 py-2.5 rounded-xl border text-xs font-bold transition-all ${
            modelType === 'lstm'
              ? 'bg-somaiya text-white border-somaiya-dark shadow-sm'
              : 'bg-zinc-50 text-zinc-700 border-zinc-200 hover:bg-zinc-100'
          }`}
        >
          LSTM (3 Gates: Forget, Input, Output + Cell State)
        </button>
        <button
          type="button"
          onClick={() => setModelType('gru')}
          className={`flex-1 py-2.5 rounded-xl border text-xs font-bold transition-all ${
            modelType === 'gru'
              ? 'bg-somaiya text-white border-somaiya-dark shadow-sm'
              : 'bg-zinc-50 text-zinc-700 border-zinc-200 hover:bg-zinc-100'
          }`}
        >
          GRU (2 Gates: Update, Reset + Hidden State)
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-6">
        {/* Interactive Gate Sliders */}
        <div className="border border-zinc-200 rounded-xl p-4 bg-zinc-50/50 space-y-3 text-xs">
          <div className="font-bold text-zinc-900 mb-1">
            {modelType === 'lstm' ? 'LSTM Gating Signals' : 'GRU Gating Signals'}
          </div>

          <div>
            <div className="flex justify-between text-zinc-600 mb-1">
              <span>{modelType === 'lstm' ? 'Forget Gate (f_t = σ(W_f · [h, x])):' : 'Update Gate (z_t = σ(W_z · [h, x])):'}</span>
              <span className="font-mono font-bold text-zinc-900">{forgetGate}</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={forgetGate}
              onChange={(e) => setForgetGate(Number(e.target.value))}
              className="w-full accent-somaiya"
            />
          </div>

          <div>
            <div className="flex justify-between text-zinc-600 mb-1">
              <span>{modelType === 'lstm' ? 'Input Gate (i_t = σ(W_i · [h, x])):' : 'Reset Gate (r_t = σ(W_r · [h, x])):'}</span>
              <span className="font-mono font-bold text-zinc-900">{inputGate}</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={inputGate}
              onChange={(e) => setInputGate(Number(e.target.value))}
              className="w-full accent-somaiya"
            />
          </div>

          {modelType === 'lstm' && (
            <div>
              <div className="flex justify-between text-zinc-600 mb-1">
                <span>Output Gate (o_t = σ(W_o · [h, x])):</span>
                <span className="font-mono font-bold text-zinc-900">{outputGate}</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={outputGate}
                onChange={(e) => setOutputGate(Number(e.target.value))}
                className="w-full accent-somaiya"
              />
            </div>
          )}
        </div>

        {/* Architecture Comparison Card */}
        <div className="border border-zinc-200 rounded-xl p-4 bg-zinc-900 text-zinc-200 text-xs font-mono space-y-2">
          <div className="text-amber-400 font-bold border-b border-zinc-800 pb-1.5">
            {modelType === 'lstm' ? 'LSTM MATHEMATICAL CELL DYNAMICS' : 'GRU MATHEMATICAL CELL DYNAMICS'}
          </div>
          {modelType === 'lstm' ? (
            <>
              <div>f_t = σ(W_f · [h_{'{t-1}'}, x_t] + b_f)  → Retain {(forgetGate * 100).toFixed(0)}% past</div>
              <div>i_t = σ(W_i · [h_{'{t-1}'}, x_t] + b_i)  → Write {(inputGate * 100).toFixed(0)}% new</div>
              <div className="text-emerald-400">C_t = f_t ⊙ C_{'{t-1}'} + i_t ⊙ ~C_t (Cell State)</div>
              <div>o_t = σ(W_o · [h_{'{t-1}'}, x_t] + b_o)</div>
              <div className="text-cyan-400">h_t = o_t ⊙ tanh(C_t) (Hidden State)</div>
            </>
          ) : (
            <>
              <div>z_t = σ(W_z · [h_{'{t-1}'}, x_t] + b_z)  (Update Gate)</div>
              <div>r_t = σ(W_r · [h_{'{t-1}'}, x_t] + b_r)  (Reset Gate)</div>
              <div className="text-emerald-400">~h_t = tanh(W · [r_t ⊙ h_{'{t-1}'}, x_t])</div>
              <div className="text-cyan-400">h_t = (1 - z_t) ⊙ h_{'{t-1}'} + z_t ⊙ ~h_t</div>
              <div className="text-zinc-400">25% fewer parameters than LSTM</div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// Experiment 6: Multi-Armed Bandit Simulator
// =========================================================================
const MultiArmedBanditSimulator: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [epsilon, setEpsilon] = useState(0.1);
  const [steps, setSteps] = useState(0);
  const [cumulativeReward, setCumulativeReward] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [optimalPulls, setOptimalPulls] = useState(0);

  // 10 arms with true means
  const trueMeans = [0.2, -0.8, 1.6, 0.4, 1.1, -0.3, 1.9, 0.5, -1.2, 0.8];
  const optimalArmIndex = 6; // true mean = 1.9

  const [armPulls, setArmPulls] = useState<number[]>(new Array(10).fill(0));
  const [armValues, setArmValues] = useState<number[]>(new Array(10).fill(0));

  const runBandit = (presetEps?: number) => {
    const epsToUse = presetEps !== undefined ? presetEps : epsilon;
    if (presetEps !== undefined) setEpsilon(presetEps);

    setIsRunning(true);
    let curSteps = 0;
    let curReward = 0;
    let curOpt = 0;
    const pulls = new Array(10).fill(0);
    const vals = new Array(10).fill(0);

    const interval = setInterval(() => {
      // Run batch of 50 steps per tick
      for (let b = 0; b < 50; b++) {
        curSteps++;
        let chosenAction = 0;
        if (Math.random() < epsToUse) {
          // Explore
          chosenAction = Math.floor(Math.random() * 10);
        } else {
          // Exploit
          let maxVal = -Infinity;
          let bestArm = 0;
          for (let i = 0; i < 10; i++) {
            if (vals[i] > maxVal) {
              maxVal = vals[i];
              bestArm = i;
            }
          }
          chosenAction = bestArm;
        }

        // Sample reward ~ N(trueMeans[chosenAction], 1.0)
        const sampleReward = trueMeans[chosenAction] + (Math.random() * 2 - 1);
        curReward += sampleReward;
        if (chosenAction === optimalArmIndex) curOpt++;

        // Incremental mean update rule
        pulls[chosenAction]++;
        const n = pulls[chosenAction];
        vals[chosenAction] += (1 / n) * (sampleReward - vals[chosenAction]);
      }

      setSteps(curSteps);
      setCumulativeReward(Math.round(curReward));
      setOptimalPulls(curOpt);
      setArmPulls([...pulls]);
      setArmValues([...vals]);

      if (curSteps >= 1000) {
        clearInterval(interval);
        setIsRunning(false);
        onComplete();
      }
    }, 60);
  };

  const reset = () => {
    setSteps(0);
    setCumulativeReward(0);
    setOptimalPulls(0);
    setArmPulls(new Array(10).fill(0));
    setArmValues(new Array(10).fill(0));
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-100 pb-4 mb-6">
        <div>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200 mb-1">
            Experiment 6 · Tabular Reinforcement Learning
          </span>
          <h3 className="text-lg font-bold text-zinc-900">Multi-Armed Bandit Problem (Epsilon-Greedy Agent)</h3>
          <p className="text-xs text-zinc-500">10-Armed Testbed · Exploration vs Exploitation Trade-off</p>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={reset}
            className="px-3 py-2 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-bold rounded-lg border border-zinc-300 flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
          <button
            type="button"
            onClick={() => runBandit()}
            disabled={isRunning}
            className="px-4 py-2 bg-somaiya hover:bg-somaiya-dark active:bg-somaiya-deep text-white text-xs font-bold rounded-lg shadow-sm flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isRunning ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isRunning ? `Simulating (${steps}/1000)` : 'Run 1000 Steps'}</span>
          </button>
        </div>
      </div>

      {/* Preset comparison buttons matching manual */}
      <div className="flex flex-wrap gap-2 mb-6">
        <span className="text-xs font-bold text-zinc-600 self-center mr-2">Curriculum Presets:</span>
        <button
          type="button"
          onClick={() => runBandit(0.0)}
          className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition-all ${
            epsilon === 0.0 ? 'bg-zinc-800 text-white border-zinc-900' : 'bg-white text-zinc-700 border-zinc-300'
          }`}
        >
          ε = 0 (Pure Greedy)
        </button>
        <button
          type="button"
          onClick={() => runBandit(0.01)}
          className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition-all ${
            epsilon === 0.01 ? 'bg-zinc-800 text-white border-zinc-900' : 'bg-white text-zinc-700 border-zinc-300'
          }`}
        >
          ε = 0.01 (Slow Exploration)
        </button>
        <button
          type="button"
          onClick={() => runBandit(0.1)}
          className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition-all ${
            epsilon === 0.1 ? 'bg-zinc-800 text-white border-zinc-900' : 'bg-white text-zinc-700 border-zinc-300'
          }`}
        >
          ε = 0.1 (Balanced - Recommended)
        </button>
      </div>

      {/* Performance Summary Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3.5 text-center">
          <span className="text-[11px] text-zinc-500 font-semibold block uppercase">Total Time Steps</span>
          <span className="text-xl font-extrabold text-zinc-900 font-mono">{steps} / 1000</span>
        </div>
        <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3.5 text-center">
          <span className="text-[11px] text-zinc-500 font-semibold block uppercase">Cumulative Reward</span>
          <span className="text-xl font-extrabold text-somaiya font-mono">{cumulativeReward}</span>
        </div>
        <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3.5 text-center">
          <span className="text-[11px] text-zinc-500 font-semibold block uppercase">% Optimal Action</span>
          <span className="text-xl font-extrabold text-emerald-700 font-mono">
            {steps > 0 ? ((optimalPulls / steps) * 100).toFixed(1) : 0}%
          </span>
        </div>
      </div>

      {/* 10 Arms Status Grid */}
      <div className="border border-zinc-200 rounded-xl p-4 bg-zinc-50/50 mb-4">
        <div className="flex justify-between items-center text-xs font-bold text-zinc-800 mb-3">
          <span>10-Arm Value Estimations & Pull Distributions</span>
          <span className="text-emerald-700">Optimal Arm: #7 (q* = +1.90)</span>
        </div>
        <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
          {armValues.map((val, idx) => {
            const isOpt = idx === optimalArmIndex;
            return (
              <div
                key={idx}
                className={`p-2.5 rounded-lg border text-center text-xs font-mono transition-all ${
                  isOpt
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-950 font-bold'
                    : 'bg-white border-zinc-200 text-zinc-800'
                }`}
              >
                <div className="text-[10px] text-zinc-400 font-sans">Arm {idx + 1}</div>
                <div className="text-sm font-extrabold my-1">{val.toFixed(2)}</div>
                <div className="text-[10px] text-zinc-500">{armPulls[idx]} pulls</div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="text-xs text-zinc-500 bg-zinc-100 p-3 rounded-lg flex items-center gap-2">
        <Info className="w-4 h-4 text-zinc-600 shrink-0" />
        <span>
          Incremental Update Rule: <strong>Q_{'{n+1}'}(a) = Q_n(a) + (1 / N(a)) · [R_n - Q_n(a)]</strong>
        </span>
      </div>
    </div>
  );
};

// =========================================================================
// Experiment 7: MDP Returns & Discount Factor Simulator
// =========================================================================
const MDPDiscountSimulator: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [gamma, setGamma] = useState(0.9);
  const rewards = [-1, -1, -1, 10]; // Exact manual benchmark

  // Backward accumulation: G = R[t] + gamma * G
  const calculateReturns = (g: number) => {
    let G = 0;
    const rets: number[] = [];
    for (let i = rewards.length - 1; i >= 0; i--) {
      G = rewards[i] + g * G;
      rets.unshift(G);
    }
    return rets;
  };

  const currentReturns = calculateReturns(gamma);
  const g0 = currentReturns[0];

  useEffect(() => {
    onComplete();
  }, [gamma]);

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm">
      <div className="border-b border-zinc-100 pb-4 mb-6">
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold bg-teal-50 text-teal-700 border border-teal-200 mb-1">
          Experiment 7 · Markov Decision Processes
        </span>
        <h3 className="text-lg font-bold text-zinc-900">MDP Returns & Discount Factor (γ) Exploration</h3>
        <p className="text-xs text-zinc-500">Benchmark Reward Sequence: R = [-1, -1, -1, +10] · Long-Term vs Short-Term Horizon</p>
      </div>

      {/* Gamma Slider & Preset Cases from Manual */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-6">
        <div className="border border-zinc-200 rounded-xl p-4 bg-zinc-50/50 space-y-3">
          <div className="flex justify-between text-xs font-bold text-zinc-800">
            <span>Discount Factor (γ):</span>
            <span className="font-mono text-base font-extrabold text-somaiya">{gamma.toFixed(2)}</span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={gamma}
            onChange={(e) => setGamma(Number(e.target.value))}
            className="w-full accent-somaiya"
          />
          <div className="flex justify-between text-[11px] text-zinc-400 font-mono">
            <span>γ = 0.0 (Myopic)</span>
            <span>γ = 0.5 (Balanced)</span>
            <span>γ = 1.0 (Undiscounted)</span>
          </div>

          <div className="pt-2 border-t border-zinc-200">
            <span className="text-xs font-bold text-zinc-600 block mb-2">Curriculum Test Cases:</span>
            <div className="grid grid-cols-4 gap-1.5">
              {[
                { g: 1.0, label: 'Case 1 (1.0)', ret: '7.0' },
                { g: 0.9, label: 'Case 2 (0.9)', ret: '4.58' },
                { g: 0.5, label: 'Case 3 (0.5)', ret: '-0.5' },
                { g: 0.0, label: 'Case 4 (0.0)', ret: '-1.0' }
              ].map((c) => (
                <button
                  key={c.g}
                  type="button"
                  onClick={() => setGamma(c.g)}
                  className={`p-2 rounded-lg border text-center text-xs transition-all ${
                    gamma === c.g
                      ? 'bg-somaiya text-white border-somaiya-dark font-bold'
                      : 'bg-white text-zinc-700 border-zinc-200 hover:bg-zinc-100'
                  }`}
                >
                  <div className="text-[10px]">{c.label}</div>
                  <div className="font-mono font-bold mt-0.5">{c.ret}</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Backward Accumulation Visualizer */}
        <div className="border border-zinc-200 rounded-xl p-4 bg-zinc-900 text-zinc-200 font-mono text-xs space-y-2.5">
          <div className="text-teal-400 font-bold border-b border-zinc-800 pb-1.5 flex justify-between">
            <span>BACKWARD RECURSION: G_t = R_{'{t+1}'} + γ · G_{'{t+1}'}</span>
            <span className="text-zinc-400">T = 4 steps</span>
          </div>
          <div className="space-y-1.5 text-[11px]">
            <div>Step 4: R₄ = +10 → G₃ = 10.0</div>
            <div>Step 3: R₃ = -1  → G₂ = -1 + {gamma} × {currentReturns[2]?.toFixed(2)} = {currentReturns[2]?.toFixed(2)}</div>
            <div>Step 2: R₂ = -1  → G₁ = -1 + {gamma} × {currentReturns[1]?.toFixed(2)} = {currentReturns[1]?.toFixed(2)}</div>
            <div className="text-somaiya font-bold">Step 1: R₁ = -1  → G₀ = -1 + {gamma} × {currentReturns[1]?.toFixed(2)} = {g0.toFixed(2)}</div>
          </div>
          <div className="border-t border-zinc-800 pt-2 flex justify-between text-sm font-bold text-teal-300">
            <span>Initial Return G₀:</span>
            <span>{g0.toFixed(2)}</span>
          </div>
        </div>
      </div>

      <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-4 text-xs">
        <span className="font-bold text-zinc-800 block mb-1">Key Insight from KJSIT Curriculum:</span>
        <p className="text-zinc-600">
          When γ = 1.0, the delayed goal (+10) dominates resulting in a high positive return (+7.0). As γ decreases toward 0.5 and 0.0, the delayed positive reward is discounted so heavily that immediate step penalties (-1) dominate, flipping the return to negative (-0.5) and making the agent myopic.
        </p>
      </div>
    </div>
  );
};

// =========================================================================
// Experiment 8: Dynamic Programming 3-State MDP Simulator
// =========================================================================
const DPValueIterationSimulator: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [iteration, setIteration] = useState(0);
  const [vS1, setVS1] = useState(0);
  const [vS2, setVS2] = useState(0);
  const gamma = 0.9;

  const stepIteration = () => {
    if (iteration === 0) {
      // Iteration 1: V(S2) = 10 + 0.9(0) = 10, V(S1) = 5 + 0.9(0) = 5
      setIteration(1);
      setVS2(10);
      setVS1(5);
    } else if (iteration === 1) {
      // Iteration 2: V(S2) = 10, V(S1) = 5 + 0.9(10) = 14
      setIteration(2);
      setVS2(10);
      setVS1(14);
      onComplete();
    } else {
      // Converged
      setIteration((prev) => prev + 1);
      onComplete();
    }
  };

  const reset = () => {
    setIteration(0);
    setVS1(0);
    setVS2(0);
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-100 pb-4 mb-6">
        <div>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200 mb-1">
            Experiment 8 · Dynamic Programming
          </span>
          <h3 className="text-lg font-bold text-zinc-900">Dynamic Programming: Value Iteration on 3-State MDP</h3>
          <p className="text-xs text-zinc-500">S1 → S2 (R=5), S2 → S3 (R=10), S3 (Terminal R=0) · γ = 0.9</p>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={reset}
            className="px-3 py-2 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-bold rounded-lg border border-zinc-300 flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
          <button
            type="button"
            onClick={stepIteration}
            className="px-4 py-2 bg-somaiya hover:bg-somaiya-dark active:bg-somaiya-deep text-white text-xs font-bold rounded-lg shadow-sm flex items-center gap-2 cursor-pointer"
          >
            <Play className="w-3.5 h-3.5" />
            <span>Step Value Iteration</span>
          </button>
        </div>
      </div>

      {/* 3-State Visual Graph */}
      <div className="border border-zinc-200 rounded-xl p-6 bg-zinc-50/50 mb-6">
        <div className="flex flex-col sm:flex-row items-center justify-center gap-6 sm:gap-12">
          {/* State S1 */}
          <div className="text-center">
            <div className="w-24 h-24 rounded-2xl bg-white border-2 border-somaiya shadow-md flex flex-col items-center justify-center">
              <span className="text-xs font-bold text-zinc-400 uppercase">State S1</span>
              <span className="text-2xl font-extrabold text-somaiya font-mono">{vS1.toFixed(1)}</span>
            </div>
            <span className="text-[11px] font-bold text-zinc-500 block mt-2">Target: 14.0</span>
          </div>

          <div className="text-center">
            <span className="text-xs font-bold text-somaiya block">Action a (R = +5)</span>
            <ArrowRight className="w-8 h-8 text-somaiya mx-auto" />
            <span className="text-[10px] text-zinc-400 font-mono">P(S2|S1) = 1.0</span>
          </div>

          {/* State S2 */}
          <div className="text-center">
            <div className="w-24 h-24 rounded-2xl bg-white border-2 border-indigo-600 shadow-md flex flex-col items-center justify-center">
              <span className="text-xs font-bold text-zinc-400 uppercase">State S2</span>
              <span className="text-2xl font-extrabold text-indigo-700 font-mono">{vS2.toFixed(1)}</span>
            </div>
            <span className="text-[11px] font-bold text-zinc-500 block mt-2">Target: 10.0</span>
          </div>

          <div className="text-center">
            <span className="text-xs font-bold text-indigo-600 block">Action a (R = +10)</span>
            <ArrowRight className="w-8 h-8 text-indigo-600 mx-auto" />
            <span className="text-[10px] text-zinc-400 font-mono">P(S3|S2) = 1.0</span>
          </div>

          {/* State S3 Terminal */}
          <div className="text-center">
            <div className="w-24 h-24 rounded-2xl bg-zinc-200 border-2 border-zinc-400 shadow-inner flex flex-col items-center justify-center">
              <span className="text-xs font-bold text-zinc-500 uppercase">S3 (Terminal)</span>
              <span className="text-2xl font-extrabold text-zinc-700 font-mono">0.0</span>
            </div>
            <span className="text-[11px] font-bold text-zinc-500 block mt-2">V(Terminal) = 0</span>
          </div>
        </div>
      </div>

      {/* Manual Calculation Step-by-Step Table from manual */}
      <div className="border border-zinc-200 rounded-xl overflow-hidden mb-4">
        <div className="bg-zinc-100 px-4 py-2.5 font-bold text-xs text-zinc-800 flex justify-between">
          <span>Manual Calculation Tracker (Curriculum Exact)</span>
          <span className="text-zinc-500">Current Step: Iteration {iteration}</span>
        </div>
        <div className="divide-y divide-zinc-200 text-xs">
          <div className={`px-4 py-3 flex justify-between ${iteration === 0 ? 'bg-amber-50 font-semibold' : 'bg-white'}`}>
            <span>Initialization: V₀(S1) = 0, V₀(S2) = 0, V₀(S3) = 0</span>
            <span className="font-mono text-zinc-500">Iteration 0</span>
          </div>
          <div className={`px-4 py-3 flex justify-between ${iteration === 1 ? 'bg-amber-50 font-semibold' : 'bg-white'}`}>
            <span>Iteration 1: V₁(S2) = 10 + 0.9(0) = 10, V₁(S1) = 5 + 0.9(0) = 5</span>
            <span className="font-mono text-indigo-700 font-bold">V(S1)=5, V(S2)=10</span>
          </div>
          <div className={`px-4 py-3 flex justify-between ${iteration >= 2 ? 'bg-emerald-50 font-semibold text-emerald-950' : 'bg-white'}`}>
            <span>Iteration 2: V₂(S2) = 10, V₂(S1) = 5 + 0.9(10) = 14 (CONVERGED)</span>
            <span className="font-mono text-emerald-700 font-bold">V*(S1)=14, V*(S2)=10</span>
          </div>
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// Experiment 9: Monte Carlo Method Simulator
// =========================================================================
const MonteCarloSimulator: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [mcType, setMcType] = useState<'firstVisit' | 'everyVisit'>('firstVisit');
  const [episodes, setEpisodes] = useState(0);
  const [vS1, setVS1] = useState(0);
  const [vS2, setVS2] = useState(0);
  const [s1Returns, setS1Returns] = useState<number[]>([]);
  const [s2Returns, setS2Returns] = useState<number[]>([]);
  const [isSampling, setIsSampling] = useState(false);

  const sampleEpisodes = (count = 25) => {
    setIsSampling(true);
    let curEp = episodes;
    const r1List = [...s1Returns];
    const r2List = [...s2Returns];

    const interval = setInterval(() => {
      curEp++;
      // Episode S1 -> S2 -> Terminal with stochastic rewards around 5 and 10
      const r1 = 5.0 + (Math.random() * 1.0 - 0.5);
      const r2 = 10.0 + (Math.random() * 1.0 - 0.5);
      const g2 = r2;
      const g1 = r1 + 0.9 * g2;

      r1List.push(g1);
      r2List.push(g2);

      const mean1 = r1List.reduce((a, b) => a + b, 0) / r1List.length;
      const mean2 = r2List.reduce((a, b) => a + b, 0) / r2List.length;

      setEpisodes(curEp);
      setVS1(mean1);
      setVS2(mean2);
      setS1Returns([...r1List]);
      setS2Returns([...r2List]);

      if (curEp >= episodes + count) {
        clearInterval(interval);
        setIsSampling(false);
        onComplete();
      }
    }, 40);
  };

  const reset = () => {
    setEpisodes(0);
    setVS1(0);
    setVS2(0);
    setS1Returns([]);
    setS2Returns([]);
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-100 pb-4 mb-6">
        <div>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold bg-purple-50 text-purple-700 border border-purple-200 mb-1">
            Experiment 9 · Model-Free Reinforcement Learning
          </span>
          <h3 className="text-lg font-bold text-zinc-900">Monte Carlo Value Estimation (First-Visit vs Every-Visit)</h3>
          <p className="text-xs text-zinc-500">Learning directly from complete sampled episodes without transition dynamics</p>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={reset}
            className="px-3 py-2 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-bold rounded-lg border border-zinc-300 flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
          <button
            type="button"
            onClick={() => sampleEpisodes(25)}
            disabled={isSampling}
            className="px-4 py-2 bg-somaiya hover:bg-somaiya-dark active:bg-somaiya-deep text-white text-xs font-bold rounded-lg shadow-sm flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isSampling ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
            <span>Sample 25 Episodes</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3.5 text-center">
          <span className="text-[11px] text-zinc-500 font-semibold block uppercase">Sampled Episodes</span>
          <span className="text-xl font-extrabold text-zinc-900 font-mono">{episodes}</span>
        </div>
        <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3.5 text-center">
          <span className="text-[11px] text-zinc-500 font-semibold block uppercase">V(S1) Running Average</span>
          <span className="text-xl font-extrabold text-somaiya font-mono">{vS1.toFixed(2)}</span>
          <span className="text-[10px] text-zinc-400 block mt-0.5">True Target: 14.00</span>
        </div>
        <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3.5 text-center">
          <span className="text-[11px] text-zinc-500 font-semibold block uppercase">V(S2) Running Average</span>
          <span className="text-xl font-extrabold text-indigo-700 font-mono">{vS2.toFixed(2)}</span>
          <span className="text-[10px] text-zinc-400 block mt-0.5">True Target: 10.00</span>
        </div>
      </div>

      {/* Comparison Table from manual */}
      <div className="border border-zinc-200 rounded-xl overflow-hidden">
        <div className="bg-zinc-100 px-4 py-2.5 font-bold text-xs text-zinc-800">
          Comparison of Reinforcement Learning Methods (Curriculum Table)
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-zinc-50 border-b border-zinc-200 text-zinc-600 font-semibold">
              <tr>
                <th className="px-4 py-2.5">Method</th>
                <th className="px-4 py-2.5">Requires Model?</th>
                <th className="px-4 py-2.5">Updates During Episode?</th>
                <th className="px-4 py-2.5">Variance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200">
              <tr className="bg-white">
                <td className="px-4 py-2.5 font-bold text-zinc-900">Dynamic Programming (DP)</td>
                <td className="px-4 py-2.5 text-emerald-700 font-semibold">Yes</td>
                <td className="px-4 py-2.5">Yes</td>
                <td className="px-4 py-2.5">Low</td>
              </tr>
              <tr className="bg-purple-50/50">
                <td className="px-4 py-2.5 font-bold text-purple-900">Monte Carlo (MC)</td>
                <td className="px-4 py-2.5 text-rose-700 font-semibold">No (Model-Free)</td>
                <td className="px-4 py-2.5">No (After Episode)</td>
                <td className="px-4 py-2.5 text-amber-700 font-semibold">High</td>
              </tr>
              <tr className="bg-white">
                <td className="px-4 py-2.5 font-bold text-zinc-900">Temporal Difference (TD)</td>
                <td className="px-4 py-2.5 text-rose-700 font-semibold">No (Model-Free)</td>
                <td className="px-4 py-2.5">Yes (Bootstrapping)</td>
                <td className="px-4 py-2.5">Medium</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
