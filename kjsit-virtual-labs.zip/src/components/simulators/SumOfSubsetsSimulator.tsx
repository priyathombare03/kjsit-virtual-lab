import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  SkipForward,
  CheckCircle2,
  XCircle,
  TrendingUp,
  DollarSign,
  Radio,
  Sparkles,
  Info
} from 'lucide-react';

interface Station {
  id: number;
  name: string;
  cost: number;
  location: string;
}

const DEFAULT_STATIONS: Station[] = [
  { id: 1, name: 'Station 1 (Soil & Temp)', cost: 15, location: 'North Valley' },
  { id: 2, name: 'Station 2 (Rainfall)', cost: 10, location: 'East Orchard' },
  { id: 3, name: 'Station 3 (Wind & Humidity)', cost: 20, location: 'Central Farmland' },
  { id: 4, name: 'Station 4 (Solar & Evap)', cost: 25, location: 'West Terrace' },
  { id: 5, name: 'Station 5 (Full Agro-Station)', cost: 35, location: 'South Riverbank' },
];

interface TraceStep {
  stationIndex: number;
  decision: 'include' | 'exclude' | 'backtrack' | 'solution';
  currentSubset: number[]; // indices of included stations
  currentSum: number;
  targetBudget: number;
  message: string;
  isPruned?: boolean;
}

export const SumOfSubsetsSimulator: React.FC = () => {
  const [stations, setStations] = useState<Station[]>(DEFAULT_STATIONS);
  const [targetBudget, setTargetBudget] = useState<number>(45);
  const [steps, setSteps] = useState<TraceStep[]>([]);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [speed, setSpeed] = useState<number>(800);
  const [solutions, setSolutions] = useState<number[][]>([]);

  // Generate trace steps via backtracking
  const generateSteps = () => {
    const trace: TraceStep[] = [];
    const foundSolutions: number[][] = [];
    const n = stations.length;
    const costs = stations.map((s) => s.cost);
    const x: number[] = new Array(n).fill(0);

    const backtrack = (s: number, k: number) => {
      // Current subset indices
      const currentIndices: number[] = [];
      for (let i = 0; i < k; i++) {
        if (x[i] === 1) currentIndices.push(i);
      }

      if (s === targetBudget) {
        foundSolutions.push([...currentIndices]);
        trace.push({
          stationIndex: k - 1,
          decision: 'solution',
          currentSubset: [...currentIndices],
          currentSum: s,
          targetBudget,
          message: `🎯 Target Budget ₹${targetBudget}k Achieved! Combination: ${currentIndices.map((i) => `Station ${stations[i].id}`).join(' + ')}`
        });
        return;
      }

      if (k === n || s > targetBudget) {
        if (s > targetBudget) {
          trace.push({
            stationIndex: k - 1,
            decision: 'backtrack',
            currentSubset: [...currentIndices],
            currentSum: s,
            targetBudget,
            message: `⚠️ Cost ₹${s}k exceeds budget ₹${targetBudget}k. PRUNING this branch!`,
            isPruned: true
          });
        }
        return;
      }

      // Option 1: Include stations[k]
      x[k] = 1;
      const newSum = s + costs[k];
      trace.push({
        stationIndex: k,
        decision: 'include',
        currentSubset: [...currentIndices, k],
        currentSum: newSum,
        targetBudget,
        message: `Include Station ${stations[k].id} (Cost ₹${costs[k]}k). Current accumulated sum = ₹${newSum}k.`
      });
      backtrack(newSum, k + 1);

      // Option 2: Exclude stations[k]
      x[k] = 0;
      trace.push({
        stationIndex: k,
        decision: 'exclude',
        currentSubset: [...currentIndices],
        currentSum: s,
        targetBudget,
        message: `Exclude Station ${stations[k].id}. Backtrack to explore alternatives. Accumulated sum remains ₹${s}k.`
      });
      backtrack(s, k + 1);
    };

    trace.push({
      stationIndex: -1,
      decision: 'include',
      currentSubset: [],
      currentSum: 0,
      targetBudget,
      message: `Initial state: Empty selection. Budget Target = ₹${targetBudget}k.`
    });

    backtrack(0, 0);

    setSteps(trace);
    setCurrentStepIndex(0);
    setSolutions(foundSolutions);
    setIsPlaying(false);
  };

  useEffect(() => {
    generateSteps();
  }, [stations, targetBudget]);

  // Autoplay handler
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        setCurrentStepIndex((prev) => {
          if (prev < steps.length - 1) {
            return prev + 1;
          } else {
            setIsPlaying(false);
            return prev;
          }
        });
      }, speed);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, speed, steps.length]);

  const currentStep = steps[currentStepIndex] || steps[0] || {
    stationIndex: -1,
    decision: 'include',
    currentSubset: [],
    currentSum: 0,
    targetBudget,
    message: ''
  };

  return (
    <div className="bg-zinc-950 text-white rounded-2xl border border-zinc-800 p-5 sm:p-7 shadow-xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-5 border-b border-zinc-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-800 uppercase tracking-wider">
              DAA Experiment #8
            </span>
            <span className="text-xs text-zinc-400">Backtracking State-Space Explorer</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            Weather Stations Budget Selector (Sum of Subsets)
          </h2>
          <p className="text-xs text-zinc-400 mt-1 max-w-2xl">
            Simulate pruning redundant state-space branches in agricultural equipment planning. Select weather stations whose combined installation cost matches the allocated government budget constraint.
          </p>
        </div>

        {/* Budget Input */}
        <div className="flex items-center gap-3 bg-zinc-900 border border-zinc-700 px-3.5 py-2 rounded-xl">
          <DollarSign className="w-4 h-4 text-emerald-400" />
          <div className="flex flex-col">
            <span className="text-[10px] font-bold uppercase text-zinc-400">Target Budget</span>
            <div className="flex items-center gap-1">
              <span className="text-sm font-black text-emerald-400">₹</span>
              <input
                type="number"
                min="10"
                max="100"
                step="5"
                value={targetBudget}
                onChange={(e) => setTargetBudget(Number(e.target.value) || 0)}
                className="w-16 bg-black border border-zinc-700 rounded px-1.5 py-0.5 text-xs text-emerald-300 font-mono font-bold focus:outline-none focus:border-emerald-500"
              />
              <span className="text-xs text-zinc-400">k</span>
            </div>
          </div>
        </div>
      </div>

      {/* Available Stations Pool */}
      <div className="my-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-2">
            <Radio className="w-3.5 h-3.5 text-red-500" />
            Candidate Weather Stations ({stations.length})
          </h3>
          <span className="text-[11px] text-zinc-400">
            Total Possible Subsets: 2^{stations.length} = {Math.pow(2, stations.length)} configurations
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {stations.map((st, idx) => {
            const isIncluded = currentStep.currentSubset.includes(idx);
            const isInspecting = currentStep.stationIndex === idx;
            return (
              <div
                key={st.id}
                className={`p-3 rounded-xl border transition-all relative ${
                  isIncluded
                    ? 'bg-emerald-950/60 border-emerald-500/80 shadow-[0_0_15px_rgba(16,185,129,0.2)]'
                    : isInspecting
                    ? 'bg-amber-950/60 border-amber-500/80'
                    : 'bg-zinc-900/60 border-zinc-800'
                }`}
              >
                <div className="flex items-start justify-between">
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-300 font-bold">
                    #{st.id}
                  </span>
                  <span className="text-xs font-mono font-extrabold text-emerald-400">
                    ₹{st.cost}k
                  </span>
                </div>
                <h4 className="text-xs font-bold text-white mt-1.5 line-clamp-1">{st.name}</h4>
                <p className="text-[10px] text-zinc-400">{st.location}</p>

                <div className="mt-2.5 pt-2 border-t border-zinc-800/80 flex items-center justify-between text-[10px]">
                  <span className="text-zinc-400">Status:</span>
                  {isIncluded ? (
                    <span className="inline-flex items-center gap-1 font-bold text-emerald-400">
                      <CheckCircle2 className="w-3 h-3" /> Included
                    </span>
                  ) : isInspecting && currentStep.decision === 'exclude' ? (
                    <span className="inline-flex items-center gap-1 font-bold text-zinc-400">
                      <XCircle className="w-3 h-3 text-red-400" /> Excluded
                    </span>
                  ) : (
                    <span className="text-zinc-500">Candidate</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Simulator Execution Status */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 sm:p-5 my-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-xl bg-black border border-zinc-800 flex flex-col items-center justify-center min-w-[100px]">
              <span className="text-[10px] text-zinc-400 uppercase font-bold">Current Sum</span>
              <span
                className={`text-xl font-mono font-black ${
                  currentStep.currentSum === targetBudget
                    ? 'text-emerald-400'
                    : currentStep.currentSum > targetBudget
                    ? 'text-red-400'
                    : 'text-amber-400'
                }`}
              >
                ₹{currentStep.currentSum}k
              </span>
            </div>

            <div className="p-3 rounded-xl bg-black border border-zinc-800 flex flex-col items-center justify-center min-w-[100px]">
              <span className="text-[10px] text-zinc-400 uppercase font-bold">Target</span>
              <span className="text-xl font-mono font-black text-zinc-200">
                ₹{targetBudget}k
              </span>
            </div>

            <div className="p-3 rounded-xl bg-black border border-zinc-800 flex flex-col items-center justify-center min-w-[100px]">
              <span className="text-[10px] text-zinc-400 uppercase font-bold">Solutions Found</span>
              <span className="text-xl font-mono font-black text-emerald-400">
                {solutions.length}
              </span>
            </div>
          </div>

          <div className="flex-1 max-w-xl">
            <div className="flex items-center justify-between text-xs text-zinc-400 mb-1.5">
              <span>Backtracking Trace Step</span>
              <span className="font-mono">
                {currentStepIndex + 1} / {steps.length}
              </span>
            </div>
            <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-red-600 to-amber-500 transition-all duration-300"
                style={{ width: `${((currentStepIndex + 1) / steps.length) * 100}%` }}
              />
            </div>
            <p className="text-xs font-mono text-zinc-300 mt-2 bg-black/60 p-2.5 rounded-lg border border-zinc-800">
              {currentStep.message}
            </p>
          </div>
        </div>
      </div>

      {/* Control Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-zinc-800">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-md active:scale-95 cursor-pointer"
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isPlaying ? 'Pause' : 'Auto Backtrack'}</span>
          </button>

          <button
            onClick={() => {
              setIsPlaying(false);
              setCurrentStepIndex((prev) => Math.min(prev + 1, steps.length - 1));
            }}
            disabled={currentStepIndex >= steps.length - 1}
            className="px-3 py-2 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 text-white rounded-xl text-xs font-bold flex items-center gap-1 transition-all cursor-pointer"
          >
            <SkipForward className="w-3.5 h-3.5" />
            <span>Step Forward</span>
          </button>

          <button
            onClick={() => {
              setIsPlaying(false);
              setCurrentStepIndex(0);
            }}
            className="px-3 py-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 rounded-xl text-xs font-bold flex items-center gap-1 transition-all cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        </div>

        {/* Speed Slider */}
        <div className="flex items-center gap-2 text-xs text-zinc-400">
          <span>Speed:</span>
          <input
            type="range"
            min="200"
            max="1500"
            step="100"
            value={speed}
            onChange={(e) => setSpeed(Number(e.target.value))}
            className="w-24 accent-red-600 cursor-pointer"
          />
          <span className="font-mono text-zinc-300 text-[11px]">{speed}ms</span>
        </div>
      </div>

      {/* Solutions Gallery */}
      {solutions.length > 0 && (
        <div className="mt-6 pt-5 border-t border-zinc-800">
          <h3 className="text-xs font-bold text-emerald-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            Valid Budget-Matching Station Portfolios ({solutions.length})
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {solutions.map((sol, idx) => (
              <div
                key={idx}
                className="bg-emerald-950/40 border border-emerald-500/40 p-3.5 rounded-xl flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-xs font-bold text-emerald-300 mb-1.5">
                    <span>Portfolio Option #{idx + 1}</span>
                    <span className="font-mono text-emerald-400">Exact ₹{targetBudget}k</span>
                  </div>
                  <ul className="space-y-1 text-xs text-zinc-300">
                    {sol.map((stationIdx) => (
                      <li key={stationIdx} className="flex items-center justify-between font-mono text-[11px]">
                        <span>• Station {stations[stationIdx].id} ({stations[stationIdx].location})</span>
                        <span className="text-zinc-400">₹{stations[stationIdx].cost}k</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="mt-3 pt-2 border-t border-emerald-900/60 text-[10px] text-emerald-300/80">
                  Ready for district procurement authorization.
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
