import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, SkipForward, Sparkles } from 'lucide-react';
import { VisuAlgoCodePanel } from './common/VisuAlgoCodePanel';
import { ALGORITHM_CODES } from './common/algorithmCodes';

interface QuickStep {
  array: number[];
  low: number;
  high: number;
  pivotIndex: number;
  pivotVal: number;
  i: number;
  j: number;
  action: 'select_pivot' | 'compare' | 'swap' | 'pivot_placed' | 'sorted';
  description: string;
  comparingIndices?: [number, number];
  swappedIndices?: [number, number];
  activeCodeLine: number;
}

interface QuickSortProps {
  onSimulationComplete?: () => void;
}

export const QuickSortSimulator: React.FC<QuickSortProps> = ({ onSimulationComplete }) => {
  const [initialArray, setInitialArray] = useState<number[]>([10, 80, 30, 90, 40, 50, 70]);
  const [inputStr, setInputStr] = useState<string>('10, 80, 30, 90, 40, 50, 70');
  const [steps, setSteps] = useState<QuickStep[]>([]);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [speed, setSpeed] = useState<number>(1000);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const generateSteps = (arr: number[]) => {
    const generated: QuickStep[] = [];
    const workingArr = [...arr];

    generated.push({
      array: [...workingArr],
      low: 0,
      high: workingArr.length - 1,
      pivotIndex: -1,
      pivotVal: workingArr[workingArr.length - 1],
      i: -1,
      j: -1,
      action: 'select_pivot',
      description: `Initial unsorted array of ${workingArr.length} elements. Starting Lomuto partition.`,
      activeCodeLine: 0
    });

    const partition = (low: number, high: number): number => {
      const pivot = workingArr[high];
      let i = low - 1;

      generated.push({
        array: [...workingArr],
        low,
        high,
        pivotIndex: high,
        pivotVal: pivot,
        i,
        j: low,
        action: 'select_pivot',
        description: `Selected pivot element ${pivot} at index #${high}. Partitioning subarray [${low}..${high}].`,
        activeCodeLine: 2
      });

      for (let j = low; j < high; j++) {
        generated.push({
          array: [...workingArr],
          low,
          high,
          pivotIndex: high,
          pivotVal: pivot,
          i,
          j,
          action: 'compare',
          comparingIndices: [j, high],
          description: `Comparing arr[${j}] (${workingArr[j]}) with pivot (${pivot}).`,
          activeCodeLine: 4
        });

        if (workingArr[j] <= pivot) {
          i++;
          const temp = workingArr[i];
          workingArr[i] = workingArr[j];
          workingArr[j] = temp;

          generated.push({
            array: [...workingArr],
            low,
            high,
            pivotIndex: high,
            pivotVal: pivot,
            i,
            j,
            action: 'swap',
            swappedIndices: [i, j],
            description: `arr[${j}] <= ${pivot}. Incremented i = ${i} and swapped arr[${i}] (${workingArr[i]}) with arr[${j}] (${workingArr[j]}).`,
            activeCodeLine: 5
          });
        }
      }

      // Place pivot in sorted place
      const temp = workingArr[i + 1];
      workingArr[i + 1] = workingArr[high];
      workingArr[high] = temp;

      generated.push({
        array: [...workingArr],
        low,
        high,
        pivotIndex: i + 1,
        pivotVal: pivot,
        i: i + 1,
        j: high,
        action: 'pivot_placed',
        swappedIndices: [i + 1, high],
        description: `Placed pivot ${pivot} into its final sorted position at index #${i + 1}.`,
        activeCodeLine: 6
      });

      return i + 1;
    };

    const sort = (low: number, high: number) => {
      if (low < high) {
        const pi = partition(low, high);
        sort(low, pi - 1);
        sort(pi + 1, high);
      }
    };

    sort(0, workingArr.length - 1);

    generated.push({
      array: [...workingArr],
      low: 0,
      high: workingArr.length - 1,
      pivotIndex: -1,
      pivotVal: -1,
      i: -1,
      j: -1,
      action: 'sorted',
      description: 'Quick Sort Complete! All elements partitioned and sorted.',
      activeCodeLine: 0
    });

    setSteps(generated);
    setCurrentStepIndex(0);
  };

  useEffect(() => {
    generateSteps(initialArray);
  }, [initialArray]);

  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        setCurrentStepIndex(prev => {
          if (prev < steps.length - 1) {
            return prev + 1;
          } else {
            setIsPlaying(false);
            return prev;
          }
        });
      }, speed);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, steps.length, speed]);

  // Notify parent when simulation reaches the final step (sorting completed)
  useEffect(() => {
    if (steps.length > 0 && currentStepIndex === steps.length - 1) {
      onSimulationComplete?.();
    }
  }, [currentStepIndex, steps.length, onSimulationComplete]);

  const handleApplyInput = () => {
    const parsed = inputStr
      .split(',')
      .map(x => parseInt(x.trim(), 10))
      .filter(x => !isNaN(x));
    if (parsed.length >= 2 && parsed.length <= 12) {
      setInitialArray(parsed);
      setIsPlaying(false);
    }
  };

  const handleRandomize = () => {
    const count = 7;
    const rand = Array.from({ length: count }, () => Math.floor(Math.random() * 90) + 10);
    setInitialArray(rand);
    setInputStr(rand.join(', '));
    setIsPlaying(false);
  };

  const currentStep = (steps[currentStepIndex] || {
    array: initialArray,
    low: 0,
    high: initialArray.length - 1,
    pivotIndex: -1,
    pivotVal: -1,
    i: -1,
    j: -1,
    action: 'select_pivot',
    description: 'Ready',
    activeCodeLine: 0
  }) as QuickStep;

  const maxVal = Math.max(...initialArray, 100);

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100 mb-6">
        <div>
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
            Quick Sort Lomuto Partition Visualizer & VisuAlgo Code Tracer
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Step through pivot selection, pointer increments, and array partitioning with active code line tracking
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold px-2.5 py-1 bg-blue-50 text-blue-700 rounded-md border border-blue-200">
            Step {currentStepIndex + 1} of {steps.length}
          </span>
        </div>
      </div>

      {/* Input controls */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3 mb-6 bg-slate-50 p-3 rounded-lg border border-slate-200">
        <div className="md:col-span-6 flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-700 whitespace-nowrap">Input Array:</label>
          <input
            type="text"
            value={inputStr}
            onChange={(e) => setInputStr(e.target.value)}
            placeholder="e.g. 10, 80, 30, 90, 40, 50, 70"
            className="w-full text-xs font-mono px-3 py-1.5 bg-white border border-slate-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
        </div>
        <div className="md:col-span-6 flex items-center gap-2 justify-end">
          <button
            onClick={handleApplyInput}
            className="px-3 py-1.5 bg-slate-800 text-white text-xs font-medium rounded hover:bg-slate-900 transition-colors cursor-pointer"
          >
            Apply Array
          </button>
          <button
            onClick={handleRandomize}
            className="px-3 py-1.5 bg-white border border-slate-300 text-slate-700 text-xs font-medium rounded hover:bg-slate-100 transition-colors flex items-center gap-1 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" /> Random
          </button>
        </div>
      </div>

      {/* Main Grid: Visualizer Canvas (Left) + VisuAlgo Code Panel (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-6 items-start">
        {/* Visualizer Canvas */}
        <div className="lg:col-span-7 bg-slate-950 rounded-xl p-6 text-white min-h-[340px] flex flex-col justify-between shadow-inner">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <span className="text-xs font-mono font-bold text-slate-400 uppercase">Array Elements</span>
            <span className="text-[11px] font-mono text-slate-400">
              Pivot: <span className="text-amber-400 font-bold">{currentStep.pivotVal >= 0 ? currentStep.pivotVal : 'None'}</span> |
              i: <span className="text-indigo-400 font-bold">{currentStep.i}</span> |
              j: <span className="text-teal-400 font-bold">{currentStep.j}</span>
            </span>
          </div>

          {/* Array Bars */}
          <div className="flex items-end justify-center gap-3 sm:gap-4 h-52 pt-4 pb-2">
            {currentStep.array.map((val, idx) => {
              const heightPercent = Math.max((val / maxVal) * 100, 15);
              const isPivot = idx === currentStep.pivotIndex;
              const isComparing = currentStep.comparingIndices?.includes(idx);
              const isSwapped = currentStep.swappedIndices?.includes(idx);
              const isSorted = currentStep.action === 'sorted';

              let barColor = 'bg-slate-700 text-slate-300';
              if (isSorted) {
                barColor = 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30';
              } else if (isPivot) {
                barColor = 'bg-amber-400 text-slate-950 font-bold shadow-lg shadow-amber-400/50 scale-105';
              } else if (isComparing) {
                barColor = 'bg-teal-400 text-slate-950 font-bold animate-pulse shadow-md';
              } else if (isSwapped) {
                barColor = 'bg-indigo-500 text-white shadow-md';
              }

              return (
                <div key={idx} className="flex flex-col items-center gap-2 flex-1 max-w-[50px]">
                  <span className="text-xs font-mono font-bold">{val}</span>
                  <div
                    style={{ height: `${heightPercent}%` }}
                    className={`w-full rounded-t-md transition-all duration-300 flex items-end justify-center pb-1 ${barColor}`}
                  >
                    <span className="text-[10px] font-mono opacity-75">#{idx}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Legend */}
          <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-slate-400 pt-3 border-t border-slate-800">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-amber-400"></span> Pivot Element
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-teal-400"></span> Comparing with Pivot
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-indigo-500"></span> Swapped
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-emerald-500"></span> Sorted Final
            </div>
          </div>
        </div>

        {/* VisuAlgo Code Panel */}
        <div className="lg:col-span-5">
          <VisuAlgoCodePanel
            title="Quick Sort (Lomuto)"
            explanation={currentStep.description}
            codeLines={ALGORITHM_CODES.quickSort.lines}
            activeLineIndex={currentStep.activeCodeLine}
            stepInfo={{ current: currentStepIndex + 1, total: steps.length }}
          />
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-slate-100">
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setIsPlaying(false);
              setCurrentStepIndex(0);
            }}
            className="p-2 border border-slate-300 rounded-lg hover:bg-slate-100 text-slate-700 text-sm font-medium flex items-center gap-1.5 cursor-pointer"
            title="Reset Simulation"
          >
            <RotateCcw className="w-4 h-4" /> Reset
          </button>

          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className={`px-4 py-2 rounded-lg font-medium text-sm flex items-center gap-2 transition-colors cursor-pointer ${
              isPlaying
                ? 'bg-amber-600 hover:bg-amber-700 text-white'
                : 'bg-blue-700 hover:bg-blue-800 text-white'
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4" /> Pause
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" /> Auto Play
              </>
            )}
          </button>

          <button
            onClick={() => {
              setIsPlaying(false);
              setCurrentStepIndex(prev => Math.min(prev + 1, steps.length - 1));
            }}
            disabled={currentStepIndex >= steps.length - 1}
            className="px-3.5 py-2 border border-slate-300 bg-white rounded-lg hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed text-slate-700 text-sm font-medium flex items-center gap-1.5 cursor-pointer"
          >
            <SkipForward className="w-4 h-4" /> Next Step
          </button>
        </div>

        <div className="flex items-center gap-3">
          <label className="text-xs font-semibold text-slate-600">Speed:</label>
          <select
            value={speed}
            onChange={(e) => setSpeed(Number(e.target.value))}
            className="text-xs bg-white border border-slate-300 rounded px-2.5 py-1.5 font-medium text-slate-700 focus:outline-none"
          >
            <option value={1500}>0.75x (Slow)</option>
            <option value={1000}>1.0x (Normal)</option>
            <option value={500}>2.0x (Fast)</option>
          </select>
        </div>
      </div>
    </div>
  );
};
