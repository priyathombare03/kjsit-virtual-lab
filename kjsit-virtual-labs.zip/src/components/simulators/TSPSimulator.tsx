import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, SkipForward, SkipBack, Sparkles, Navigation } from 'lucide-react';
import { VisuAlgoCodePanel } from './common/VisuAlgoCodePanel';
import { ALGORITHM_CODES } from './common/algorithmCodes';

interface City {
  id: number;
  name: string;
  x: number;
  y: number;
}

interface TSPStep {
  currentPath: number[];
  visitedCities: number[];
  currentCost: number;
  bestCost: number;
  bestPath: number[];
  action: 'explore' | 'bound_exceeded' | 'new_best' | 'completed';
  description: string;
}

export const TSPSimulator: React.FC<{ onSimulationComplete?: () => void }> = ({ onSimulationComplete }) => {
  const cities: City[] = [
    { id: 0, name: 'Mumbai (0)', x: 90, y: 130 },
    { id: 1, name: 'Pune (1)', x: 210, y: 220 },
    { id: 2, name: 'Nashik (2)', x: 190, y: 50 },
    { id: 3, name: 'Surat (3)', x: 380, y: 60 },
    { id: 4, name: 'Goa (4)', x: 370, y: 220 }
  ];

  // Adjacency distance matrix for 5 cities
  const distMatrix: number[][] = [
    [0, 10, 15, 20, 25],
    [10, 0, 35, 25, 12],
    [15, 35, 0, 30, 28],
    [20, 25, 30, 0, 18],
    [25, 12, 28, 18, 0]
  ];

  const [steps, setSteps] = useState<TSPStep[]>([]);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [speed, setSpeed] = useState<number>(1000);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Generate branch & bound / dynamic programming tour trace
  const generateSteps = () => {
    const trace: TSPStep[] = [];
    let minCost = Infinity;
    let optimalTour: number[] = [];

    trace.push({
      currentPath: [0],
      visitedCities: [0],
      currentCost: 0,
      bestCost: Infinity,
      bestPath: [],
      action: 'explore',
      description: 'Starting TSP tour from Origin City: Mumbai (0). Exploring all permutations using cost pruning.'
    });

    const otherCities = [1, 2, 3, 4];

    // Permutation generator for step-by-step visualization
    const permute = (arr: number[], m: number[] = []) => {
      if (arr.length === 0) {
        const fullTour = [0, ...m, 0];
        let tourCost = 0;
        for (let i = 0; i < fullTour.length - 1; i++) {
          tourCost += distMatrix[fullTour[i]][fullTour[i + 1]];
        }

        if (tourCost < minCost) {
          minCost = tourCost;
          optimalTour = [...fullTour];
          trace.push({
            currentPath: [...fullTour],
            visitedCities: [0, ...m],
            currentCost: tourCost,
            bestCost: minCost,
            bestPath: [...optimalTour],
            action: 'new_best',
            description: `Found new optimal tour: ${fullTour.map(c => cities[c].name.split(' ')[0]).join(' \u2192 ')} with Cost = ${tourCost} km!`
          });
        } else {
          trace.push({
            currentPath: [...fullTour],
            visitedCities: [0, ...m],
            currentCost: tourCost,
            bestCost: minCost,
            bestPath: [...optimalTour],
            action: 'explore',
            description: `Evaluated tour ${fullTour.map(c => cities[c].name.split(' ')[0]).join(' \u2192 ')}: Cost = ${tourCost} km (Optimal remaining: ${minCost} km).`
          });
        }
      } else {
        for (let i = 0; i < arr.length; i++) {
          const curr = arr.slice();
          const next = curr.splice(i, 1);
          permute(curr.slice(), m.concat(next));
        }
      }
    };

    permute(otherCities);

    trace.push({
      currentPath: optimalTour,
      visitedCities: [0, 1, 2, 3, 4],
      currentCost: minCost,
      bestCost: minCost,
      bestPath: optimalTour,
      action: 'completed',
      description: `TSP Solved! Minimum cost Hamiltonian cycle: ${optimalTour.map(c => cities[c].name.split(' ')[0]).join(' \u2192 ')} with minimal cost = ${minCost} km.`
    });

    setSteps(trace);
    setCurrentStepIndex(0);
  };

  useEffect(() => {
    generateSteps();
  }, []);

  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        setCurrentStepIndex(prev => {
          if (prev < steps.length - 1) {
            return prev + 1;
          } else {
            setIsPlaying(false);
            return prev;
          }
        });
      }, speed);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, steps.length, speed]);

  const currentStep = steps[currentStepIndex] || {
    currentPath: [0],
    visitedCities: [0],
    currentCost: 0,
    bestCost: Infinity,
    bestPath: [],
    action: 'explore',
    description: 'Ready'
  };

  useEffect(() => {
    if (currentStep.action === 'completed') {
      onSimulationComplete?.();
    }
  }, [currentStep.action, onSimulationComplete]);

  const activeLineIndex = 
    currentStep.action === 'completed' ? 2 :
    currentStep.action === 'new_best' ? 7 :
    currentStep.action === 'bound_exceeded' ? 4 : 6;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Navigation className="w-4 h-4 text-rose-500" />
            Travelling Salesperson Problem (TSP) Visualizer
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Finding the shortest possible Hamiltonian cycle visiting every city exactly once and returning to origin
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono font-bold px-2.5 py-1 bg-slate-800 text-rose-400 rounded-md border border-slate-700">
            Step {currentStepIndex + 1} of {steps.length}
          </span>
        </div>
      </div>

      {/* Main 12-column Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left 7 cols: Interactive Visual Simulation */}
        <div className="lg:col-span-7 space-y-4">
          {/* Map Canvas Card */}
          <div className="bg-[#0F172A] border border-slate-800 rounded-xl p-4 text-white flex flex-col justify-between relative overflow-hidden shadow-md">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 text-xs font-mono">
              <span className="text-slate-400">Current Cost: <strong className="text-amber-400">{currentStep.currentCost} km</strong></span>
              <span className="text-emerald-400 font-bold">Best Minimum Cost: {currentStep.bestCost === Infinity ? '--' : `${currentStep.bestCost} km`}</span>
            </div>

            <div className="py-2 flex items-center justify-center">
              <svg viewBox="0 0 480 270" className="w-full max-w-[460px] h-auto">
                {/* Background all city-pair lines */}
                {cities.map((c1, i) =>
                  cities.slice(i + 1).map(c2 => (
                    <line
                      key={`${c1.id}-${c2.id}`}
                      x1={c1.x}
                      y1={c1.y}
                      x2={c2.x}
                      y2={c2.y}
                      stroke="#1e293b"
                      strokeWidth="1"
                      strokeDasharray="3,3"
                    />
                  ))
                )}

                {/* Render Current Tour Path */}
                {currentStep.currentPath.length > 1 && (
                  <g>
                    {currentStep.currentPath.slice(0, -1).map((fromId, idx) => {
                      const toId = currentStep.currentPath[idx + 1];
                      const fromCity = cities[fromId];
                      const toCity = cities[toId];
                      const isOptimalFinished = currentStep.action === 'completed' || currentStep.action === 'new_best';
                      return (
                        <line
                          key={`tour-${idx}`}
                          x1={fromCity.x}
                          y1={fromCity.y}
                          x2={toCity.x}
                          y2={toCity.y}
                          stroke={isOptimalFinished ? '#10b981' : '#f59e0b'}
                          strokeWidth="3.5"
                          strokeLinecap="round"
                          className="transition-all duration-300"
                        />
                      );
                    })}
                  </g>
                )}

                {/* Render Cities */}
                {cities.map(c => {
                  const isOrigin = c.id === 0;
                  const isVisited = currentStep.visitedCities.includes(c.id);
                  return (
                    <g key={c.id}>
                      <circle
                        cx={c.x}
                        cy={c.y}
                        r={isOrigin ? "19" : "16"}
                        fill={isOrigin ? "#dc2626" : isVisited ? "#0284c7" : "#334155"}
                        stroke="#ffffff"
                        strokeWidth="2"
                      />
                      <text
                        x={c.x}
                        y={c.y + 4}
                        textAnchor="middle"
                        fill="#ffffff"
                        fontSize="12"
                        fontWeight="bold"
                      >
                        {c.id}
                      </text>
                      <text
                        x={c.x}
                        y={c.y + 24}
                        textAnchor="middle"
                        fill="#cbd5e1"
                        fontSize="10"
                        fontWeight="600"
                      >
                        {c.name.split(' ')[0]}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>

            {/* Active Tour Breadcrumb */}
            <div className="bg-[#1E293B] rounded-lg p-2.5 border border-slate-700 text-xs">
              <span className="text-[11px] font-semibold text-slate-400 block mb-1">Active Tour:</span>
              <div className="font-mono text-xs text-amber-300 font-bold break-words">
                {currentStep.currentPath.map(c => cities[c]?.name?.split(' ')[0] || c).join(' \u2192 ')}
              </div>
            </div>
          </div>

          {/* Playback Controls Bar */}
          <div className="bg-[#1E293B] border border-slate-700 rounded-xl p-3 shadow-md flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentStepIndex(0)}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
                title="Reset"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
              <button
                onClick={() => setCurrentStepIndex(prev => Math.max(0, prev - 1))}
                disabled={currentStepIndex === 0}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg transition-colors disabled:opacity-40 cursor-pointer"
                title="Previous"
              >
                <SkipBack className="w-4 h-4" />
              </button>
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="px-3.5 py-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-lg shadow-sm flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                {isPlaying ? (
                  <>
                    <Pause className="w-3.5 h-3.5" /> Pause
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5" /> Play
                  </>
                )}
              </button>
              <button
                onClick={() => setCurrentStepIndex(prev => Math.min(steps.length - 1, prev + 1))}
                disabled={currentStepIndex === steps.length - 1}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-700 rounded-lg transition-colors disabled:opacity-40 cursor-pointer"
                title="Next"
              >
                <SkipForward className="w-4 h-4" />
              </button>
            </div>

            {/* Speed Selector */}
            <div className="flex items-center gap-1.5 text-xs text-slate-300">
              <span className="text-slate-400">Speed:</span>
              <select
                value={speed}
                onChange={e => setSpeed(Number(e.target.value))}
                className="bg-[#0F172A] text-white border border-slate-700 rounded px-2 py-1 text-xs font-mono cursor-pointer"
              >
                <option value={1500}>0.75x</option>
                <option value={1000}>1.0x</option>
                <option value={400}>2.5x</option>
              </select>
            </div>
          </div>

          {/* Compact Distance Cost Matrix */}
          <div className="bg-[#0F172A] border border-slate-800 rounded-xl p-3 shadow-md">
            <h4 className="text-[11px] font-bold text-slate-300 uppercase tracking-wider mb-1.5 font-mono">
              Distance Cost Matrix ($C_{'{ij}'}$)
            </h4>
            <div className="overflow-x-auto">
              <table className="w-full text-[11px] font-mono border-collapse text-center">
                <thead>
                  <tr className="bg-[#1E293B] text-slate-300">
                    <th className="p-1 border border-slate-700">City</th>
                    {cities.map(c => (
                      <th key={c.id} className="p-1 border border-slate-700 font-bold">{c.id}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {distMatrix.map((row, i) => (
                    <tr key={i} className="hover:bg-slate-800/40">
                      <td className="p-1 border border-slate-700 font-bold bg-[#1E293B]/70 text-slate-300">{i}</td>
                      {row.map((val, j) => {
                        const isSelf = i === j;
                        return (
                          <td
                            key={j}
                            className={`p-1 border border-slate-700 ${
                              isSelf ? 'bg-slate-900 text-slate-500' : 'text-slate-200'
                            }`}
                          >
                            {isSelf ? '-' : val}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right 5 cols: Live VisuAlgo Code Panel */}
        <div className="lg:col-span-5 flex flex-col space-y-3">
          <VisuAlgoCodePanel
            title={ALGORITHM_CODES.tsp.title}
            explanation={currentStep.description}
            codeLines={ALGORITHM_CODES.tsp.lines}
            activeLineIndex={activeLineIndex}
            stepInfo={{
              current: currentStepIndex + 1,
              total: steps.length
            }}
          />
        </div>
      </div>
    </div>
  );
};
