import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, SkipForward, Sparkles } from 'lucide-react';
import { VisuAlgoCodePanel } from './common/VisuAlgoCodePanel';
import { ALGORITHM_CODES } from './common/algorithmCodes';

interface MergeStep {
  array: number[];
  left: number;
  mid: number;
  right: number;
  action: 'split' | 'merge_compare' | 'merge_copy' | 'sorted';
  comparingIndices?: [number, number];
  mergedRange?: [number, number];
  description: string;
  depth: number;
  activeCodeLine: number;
}

interface MergeSortProps {
  onSimulationComplete?: () => void;
}

export const MergeSortSimulator: React.FC<MergeSortProps> = ({ onSimulationComplete }) => {
  const [initialArray, setInitialArray] = useState<number[]>([38, 27, 43, 3, 9, 82, 10]);
  const [inputStr, setInputStr] = useState<string>('38, 27, 43, 3, 9, 82, 10');
  const [steps, setSteps] = useState<MergeStep[]>([]);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [speed, setSpeed] = useState<number>(1000);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Generate Merge Sort Trace Steps
  const generateSteps = (arr: number[]) => {
    const generated: MergeStep[] = [];
    const workingArr = [...arr];

    generated.push({
      array: [...workingArr],
      left: 0,
      mid: Math.floor(workingArr.length / 2),
      right: workingArr.length - 1,
      action: 'split',
      description: `Initial unsorted array of ${workingArr.length} elements.`,
      depth: 0,
      activeCodeLine: 0
    });

    const merge = (l: number, m: number, r: number, depth: number) => {
      const n1 = m - l + 1;
      const n2 = r - m;
      const L = workingArr.slice(l, m + 1);
      const R = workingArr.slice(m + 1, r + 1);

      generated.push({
        array: [...workingArr],
        left: l,
        mid: m,
        right: r,
        action: 'split',
        description: `Merging sub-arrays [${L.join(', ')}] (left) and [${R.join(', ')}] (right).`,
        depth,
        activeCodeLine: 5
      });

      let i = 0, j = 0, k = l;
      while (i < n1 && j < n2) {
        generated.push({
          array: [...workingArr],
          left: l,
          mid: m,
          right: r,
          action: 'merge_compare',
          comparingIndices: [l + i, m + 1 + j],
          description: `Comparing L[${i}] = ${L[i]} with R[${j}] = ${R[j]}.`,
          depth,
          activeCodeLine: 6
        });

        if (L[i] <= R[j]) {
          workingArr[k] = L[i];
          generated.push({
            array: [...workingArr],
            left: l,
            mid: m,
            right: r,
            action: 'merge_copy',
            mergedRange: [l, k],
            description: `Copied smaller element ${L[i]} to index ${k}.`,
            depth,
            activeCodeLine: 7
          });
          i++;
        } else {
          workingArr[k] = R[j];
          generated.push({
            array: [...workingArr],
            left: l,
            mid: m,
            right: r,
            action: 'merge_copy',
            mergedRange: [l, k],
            description: `Copied smaller element ${R[j]} to index ${k}.`,
            depth,
            activeCodeLine: 7
          });
          j++;
        }
        k++;
      }

      while (i < n1) {
        workingArr[k] = L[i];
        generated.push({
          array: [...workingArr],
          left: l,
          mid: m,
          right: r,
          action: 'merge_copy',
          mergedRange: [l, k],
          description: `Copied remaining left element ${L[i]} to index ${k}.`,
          depth,
          activeCodeLine: 8
        });
        i++;
        k++;
      }

      while (j < n2) {
        workingArr[k] = R[j];
        generated.push({
          array: [...workingArr],
          left: l,
          mid: m,
          right: r,
          action: 'merge_copy',
          mergedRange: [l, k],
          description: `Copied remaining right element ${R[j]} to index ${k}.`,
          depth,
          activeCodeLine: 8
        });
        j++;
        k++;
      }
    };

    const sort = (l: number, r: number, depth: number) => {
      if (l < r) {
        const m = Math.floor((l + r) / 2);

        generated.push({
          array: [...workingArr],
          left: l,
          mid: m,
          right: r,
          action: 'split',
          description: `Splitting range [${l}..${r}] into [${l}..${m}] and [${m + 1}..${r}].`,
          depth,
          activeCodeLine: 2
        });

        sort(l, m, depth + 1);
        sort(m + 1, r, depth + 1);
        merge(l, m, r, depth);
      }
    };

    sort(0, workingArr.length - 1, 0);

    generated.push({
      array: [...workingArr],
      left: 0,
      mid: Math.floor(workingArr.length / 2),
      right: workingArr.length - 1,
      action: 'sorted',
      description: 'Merge Sort Complete! Entire array is sorted.',
      depth: 0,
      activeCodeLine: 0
    });

    setSteps(generated);
    setCurrentStepIndex(0);
  };

  useEffect(() => {
    generateSteps(initialArray);
  }, [initialArray]);

  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        setCurrentStepIndex(prev => {
          if (prev < steps.length - 1) {
            return prev + 1;
          } else {
            setIsPlaying(false);
            return prev;
          }
        });
      }, speed);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, steps.length, speed]);

  // Notify parent when simulation reaches the final step (sorting completed)
  useEffect(() => {
    if (steps.length > 0 && currentStepIndex === steps.length - 1) {
      onSimulationComplete?.();
    }
  }, [currentStepIndex, steps.length, onSimulationComplete]);

  const handleApplyInput = () => {
    const parsed = inputStr
      .split(',')
      .map(x => parseInt(x.trim(), 10))
      .filter(x => !isNaN(x));
    if (parsed.length >= 2 && parsed.length <= 12) {
      setInitialArray(parsed);
      setIsPlaying(false);
    }
  };

  const handleRandomize = () => {
    const count = 7;
    const rand = Array.from({ length: count }, () => Math.floor(Math.random() * 90) + 10);
    setInitialArray(rand);
    setInputStr(rand.join(', '));
    setIsPlaying(false);
  };

  const currentStep = (steps[currentStepIndex] || {
    array: initialArray,
    action: 'split',
    description: 'Ready',
    left: 0,
    right: initialArray.length - 1,
    activeCodeLine: 0
  }) as MergeStep;

  const maxVal = Math.max(...initialArray, 100);

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100 mb-6">
        <div>
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
            Merge Sort Visualizer & VisuAlgo Code Tracer
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Step through recursive divisions and orderly sorted merges with line tracking
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold px-2.5 py-1 bg-blue-50 text-blue-700 rounded-md border border-blue-200">
            Step {currentStepIndex + 1} of {steps.length}
          </span>
        </div>
      </div>

      {/* Input controls */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3 mb-6 bg-slate-50 p-3 rounded-lg border border-slate-200">
        <div className="md:col-span-6 flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-700 whitespace-nowrap">Input Array:</label>
          <input
            type="text"
            value={inputStr}
            onChange={(e) => setInputStr(e.target.value)}
            placeholder="e.g. 38, 27, 43, 3, 9, 82, 10"
            className="w-full text-xs font-mono px-3 py-1.5 bg-white border border-slate-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
        </div>
        <div className="md:col-span-6 flex items-center gap-2 justify-end">
          <button
            onClick={handleApplyInput}
            className="px-3 py-1.5 bg-slate-800 text-white text-xs font-medium rounded hover:bg-slate-900 transition-colors cursor-pointer"
          >
            Apply Array
          </button>
          <button
            onClick={handleRandomize}
            className="px-3 py-1.5 bg-white border border-slate-300 text-slate-700 text-xs font-medium rounded hover:bg-slate-100 transition-colors flex items-center gap-1 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" /> Random
          </button>
        </div>
      </div>

      {/* Main Grid: Visualizer Canvas (Left) + VisuAlgo Code Panel (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-6 items-start">
        {/* Visualizer Canvas */}
        <div className="lg:col-span-7 bg-slate-950 rounded-xl p-6 text-white min-h-[340px] flex flex-col justify-between shadow-inner">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <span className="text-xs font-mono font-bold text-slate-400 uppercase">Array Elements</span>
            <span className="text-[11px] font-mono text-slate-400">
              Active Sub-Range: [{currentStep.left}..{currentStep.right}]
            </span>
          </div>

          {/* Array Bars */}
          <div className="flex items-end justify-center gap-3 sm:gap-4 h-52 pt-4 pb-2">
            {currentStep.array.map((val, idx) => {
              const heightPercent = Math.max((val / maxVal) * 100, 15);
              const isComparing = currentStep.comparingIndices?.includes(idx);
              const isWithinSubarray = idx >= (currentStep.left ?? 0) && idx <= (currentStep.right ?? currentStep.array.length - 1);
              const isMerged = currentStep.mergedRange && idx >= currentStep.mergedRange[0] && idx <= currentStep.mergedRange[1];
              const isFinalSorted = currentStep.action === 'sorted';

              let barColor = 'bg-slate-700 text-slate-300';
              if (isFinalSorted) {
                barColor = 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30';
              } else if (isComparing) {
                barColor = 'bg-amber-400 text-slate-950 animate-pulse font-bold shadow-lg shadow-amber-400/40';
              } else if (isMerged) {
                barColor = 'bg-indigo-500 text-white shadow-md';
              } else if (isWithinSubarray) {
                barColor = 'bg-blue-600 text-white';
              }

              return (
                <div key={idx} className="flex flex-col items-center gap-2 flex-1 max-w-[50px]">
                  <span className="text-xs font-mono font-bold">{val}</span>
                  <div
                    style={{ height: `${heightPercent}%` }}
                    className={`w-full rounded-t-md transition-all duration-300 flex items-end justify-center pb-1 ${barColor}`}
                  >
                    <span className="text-[10px] font-mono opacity-75">#{idx}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Legend */}
          <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-slate-400 pt-3 border-t border-slate-800">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-blue-600"></span> Active Sub-array
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-amber-400"></span> Comparing Elements
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-indigo-500"></span> Merged in Step
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-emerald-500"></span> Sorted Complete
            </div>
          </div>
        </div>

        {/* VisuAlgo Code Panel */}
        <div className="lg:col-span-5">
          <VisuAlgoCodePanel
            title="Merge Sort"
            explanation={currentStep.description}
            codeLines={ALGORITHM_CODES.mergeSort.lines}
            activeLineIndex={currentStep.activeCodeLine}
            stepInfo={{ current: currentStepIndex + 1, total: steps.length }}
          />
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-slate-100">
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setIsPlaying(false);
              setCurrentStepIndex(0);
            }}
            className="p-2 border border-slate-300 rounded-lg hover:bg-slate-100 text-slate-700 text-sm font-medium flex items-center gap-1.5 cursor-pointer"
            title="Reset Simulation"
          >
            <RotateCcw className="w-4 h-4" /> Reset
          </button>

          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className={`px-4 py-2 rounded-lg font-medium text-sm flex items-center gap-2 transition-colors cursor-pointer ${
              isPlaying
                ? 'bg-amber-600 hover:bg-amber-700 text-white'
                : 'bg-blue-700 hover:bg-blue-800 text-white'
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4" /> Pause
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" /> Auto Play
              </>
            )}
          </button>

          <button
            onClick={() => {
              setIsPlaying(false);
              setCurrentStepIndex(prev => Math.min(prev + 1, steps.length - 1));
            }}
            disabled={currentStepIndex >= steps.length - 1}
            className="px-3.5 py-2 border border-slate-300 bg-white rounded-lg hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed text-slate-700 text-sm font-medium flex items-center gap-1.5 cursor-pointer"
          >
            <SkipForward className="w-4 h-4" /> Next Step
          </button>
        </div>

        <div className="flex items-center gap-3">
          <label className="text-xs font-semibold text-slate-600">Speed:</label>
          <select
            value={speed}
            onChange={(e) => setSpeed(Number(e.target.value))}
            className="text-xs bg-white border border-slate-300 rounded px-2.5 py-1.5 font-medium text-slate-700 focus:outline-none"
          >
            <option value={1500}>0.75x (Slow)</option>
            <option value={1000}>1.0x (Normal)</option>
            <option value={500}>2.0x (Fast)</option>
          </select>
        </div>
      </div>
    </div>
  );
};
