import React, { useState } from 'react';
import { Search, RotateCcw, MapPin, CheckCircle2, Layers } from 'lucide-react';

interface KNNPoint {
  id: number;
  x: number;
  y: number;
  label: 'Red' | 'Blue' | 'Green';
}

export const KNNSimulator: React.FC = () => {
  const [points, setPoints] = useState<KNNPoint[]>([
    // Red Class
    { id: 1, x: 2.0, y: 3.0, label: 'Red' },
    { id: 2, x: 2.5, y: 4.0, label: 'Red' },
    { id: 3, x: 1.8, y: 2.2, label: 'Red' },
    { id: 4, x: 3.0, y: 3.5, label: 'Red' },
    // Blue Class
    { id: 5, x: 7.0, y: 8.0, label: 'Blue' },
    { id: 6, x: 8.0, y: 7.0, label: 'Blue' },
    { id: 7, x: 7.5, y: 8.5, label: 'Blue' },
    { id: 8, x: 6.5, y: 7.5, label: 'Blue' },
    // Green Class
    { id: 9, x: 7.5, y: 2.5, label: 'Green' },
    { id: 10, x: 8.5, y: 3.0, label: 'Green' },
    { id: 11, x: 8.0, y: 1.8, label: 'Green' },
    { id: 12, x: 7.0, y: 3.2, label: 'Green' }
  ]);

  const [queryPoint, setQueryPoint] = useState<{ x: number; y: number }>({ x: 5.0, y: 5.0 });
  const [kValue, setKValue] = useState<number>(3);
  const [metric, setMetric] = useState<'euclidean' | 'manhattan'>('euclidean');
  const [logs, setLogs] = useState<string[]>([
    'KJSIT Virtual Lab initialized: K-Nearest Neighbors (K-NN) Classifier.',
    'Click on the canvas to place a query test point X_q.'
  ]);

  const addLog = (msg: string) => {
    setLogs((prev) => [msg, ...prev.slice(0, 6)]);
  };

  const calcDistance = (p1: { x: number; y: number }, p2: { x: number; y: number }) => {
    if (metric === 'manhattan') {
      return Math.abs(p1.x - p2.x) + Math.abs(p1.y - p2.y);
    }
    return Math.sqrt(Math.pow(p1.x - p2.x, 2) + Math.pow(p1.y - p2.y, 2));
  };

  // Compute distances to all points and sort
  const scoredPoints = points.map((p) => ({
    ...p,
    dist: calcDistance(queryPoint, p)
  }));
  scoredPoints.sort((a, b) => a.dist - b.dist);

  const nearestNeighbors = scoredPoints.slice(0, kValue);
  const maxNeighborDist = nearestNeighbors.length > 0 ? nearestNeighbors[nearestNeighbors.length - 1].dist : 0;

  // Vote Count
  const voteCount: Record<string, number> = { Red: 0, Blue: 0, Green: 0 };
  nearestNeighbors.forEach((n) => {
    voteCount[n.label] = (voteCount[n.label] || 0) + 1;
  });

  let winningClass: 'Red' | 'Blue' | 'Green' = 'Red';
  let maxVotes = -1;
  (['Red', 'Blue', 'Green'] as const).forEach((c) => {
    if (voteCount[c] > maxVotes) {
      maxVotes = voteCount[c];
      winningClass = c;
    }
  });

  // Map 2D Coordinate Space [0, 10] x [0, 10] -> SVG [40, 460] x [260, 20]
  const mapX = (x: number) => 40 + (x / 10) * 420;
  const mapY = (y: number) => 260 - (y / 10) * 230;

  const handleCanvasClick = (e: React.MouseEvent<SVGSVGElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    const rawX = ((clickX - 40) / 420) * 10;
    const rawY = ((260 - clickY) / 230) * 10;

    if (rawX >= 0 && rawX <= 10 && rawY >= 0 && rawY <= 10) {
      const q = { x: parseFloat(rawX.toFixed(2)), y: parseFloat(rawY.toFixed(2)) };
      setQueryPoint(q);
      addLog(`Query test point placed at (${q.x}, ${q.y}). Classifying with K=${kValue}...`);
    }
  };

  const getColorHex = (label: string) => {
    if (label === 'Red') return '#ef4444';
    if (label === 'Blue') return '#3b82f6';
    return '#10b981';
  };

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-wrap gap-4 items-center justify-between">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-400 font-mono">Neighbors (K):</span>
            <input
              type="range"
              min="1"
              max="9"
              step="2"
              value={kValue}
              onChange={(e) => setKValue(parseInt(e.target.value, 10))}
              className="w-20 accent-blue-500 cursor-pointer"
            />
            <span className="text-xs text-white font-mono font-bold">K = {kValue}</span>
          </div>

          <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-400 font-mono">Distance Metric:</span>
            <select
              value={metric}
              onChange={(e) => setMetric(e.target.value as any)}
              className="bg-slate-950 text-white text-xs px-2 py-0.5 rounded border border-slate-700 font-mono"
            >
              <option value="euclidean">Euclidean (L2)</option>
              <option value="manhattan">Manhattan (L1)</option>
            </select>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs font-mono">
            <span className="text-slate-400">Classified As:</span>
            <span className="font-bold uppercase px-2 py-0.5 rounded text-white" style={{ backgroundColor: getColorHex(winningClass) }}>
              {winningClass} ({voteCount[winningClass]}/{kValue} votes)
            </span>
          </div>
        </div>
      </div>

      {/* 2D Feature Canvas */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-inner">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-400">
              Interactive 2D Feature Space (Click anywhere to relocate Test Query Point)
            </span>
          </div>
          <div className="flex items-center gap-3 text-xs font-mono">
            <div className="flex items-center gap-1 text-red-400">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block"></span>
              <span>Red</span>
            </div>
            <div className="flex items-center gap-1 text-blue-400">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block"></span>
              <span>Blue</span>
            </div>
            <div className="flex items-center gap-1 text-emerald-400">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block"></span>
              <span>Green</span>
            </div>
            <div className="flex items-center gap-1 text-amber-300">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block"></span>
              <span>Query (X_q)</span>
            </div>
          </div>
        </div>

        <div className="flex justify-center">
          <svg
            viewBox="0 0 500 290"
            className="w-full max-w-[580px] bg-slate-950 rounded-xl border border-slate-800 cursor-crosshair shadow-md"
            onClick={handleCanvasClick}
          >
            {/* Grid */}
            {[0, 2, 4, 6, 8, 10].map((x) => (
              <line key={`gx-${x}`} x1={mapX(x)} y1={mapY(0)} x2={mapX(x)} y2={mapY(10)} stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />
            ))}
            {[0, 2, 4, 6, 8, 10].map((y) => (
              <line key={`gy-${y}`} x1={mapX(0)} y1={mapY(y)} x2={mapX(10)} y2={mapY(y)} stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />
            ))}

            {/* Axes */}
            <line x1={mapX(0)} y1={mapY(0)} x2={mapX(10)} y2={mapY(0)} stroke="#64748b" strokeWidth="2" />
            <line x1={mapX(0)} y1={mapY(0)} x2={mapX(0)} y2={mapY(10)} stroke="#64748b" strokeWidth="2" />

            {/* Axis Labels */}
            {[0, 2, 4, 6, 8, 10].map((x) => (
              <text key={`tx-${x}`} x={mapX(x)} y={mapY(0) + 16} fill="#94a3b8" fontSize="10" textAnchor="middle">{x}</text>
            ))}
            {[0, 2, 4, 6, 8, 10].map((y) => (
              <text key={`ty-${y}`} x={mapX(0) - 8} y={mapY(y) + 3} fill="#94a3b8" fontSize="10" textAnchor="end">{y}</text>
            ))}

            {/* Nearest Neighbor Highlight Lines */}
            {nearestNeighbors.map((n, i) => (
              <line
                key={`line-${i}`}
                x1={mapX(queryPoint.x)}
                y1={mapY(queryPoint.y)}
                x2={mapX(n.x)}
                y2={mapY(n.y)}
                stroke={getColorHex(n.label)}
                strokeWidth="2"
                strokeDasharray="3 2"
              />
            ))}

            {/* Neighborhood Enclosing Radius (Euclidean) */}
            {metric === 'euclidean' && (
              <circle
                cx={mapX(queryPoint.x)}
                cy={mapY(queryPoint.y)}
                r={(maxNeighborDist / 10) * 420}
                fill="#f59e0b"
                fillOpacity="0.08"
                stroke="#f59e0b"
                strokeWidth="1.5"
                strokeDasharray="4 3"
              />
            )}

            {/* Training Points */}
            {points.map((pt) => {
              const isNearest = nearestNeighbors.some((n) => n.id === pt.id);
              return (
                <circle
                  key={`pt-${pt.id}`}
                  cx={mapX(pt.x)}
                  cy={mapY(pt.y)}
                  r={isNearest ? '7' : '5'}
                  fill={getColorHex(pt.label)}
                  stroke={isNearest ? '#ffffff' : '#0f172a'}
                  strokeWidth={isNearest ? '2.5' : '1'}
                />
              );
            })}

            {/* Query Point */}
            <circle
              cx={mapX(queryPoint.x)}
              cy={mapY(queryPoint.y)}
              r="8"
              fill="#fbbf24"
              stroke="#ffffff"
              strokeWidth="2.5"
              className="animate-pulse"
            />
          </svg>
        </div>
      </div>

      {/* Neighbor breakdown & Logs */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 font-mono text-xs text-slate-300">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-400 block mb-2">
            Top {kValue} Nearest Neighbors Distance Tally
          </span>
          <div className="space-y-1.5">
            {nearestNeighbors.map((n, i) => (
              <div key={i} className="flex items-center justify-between bg-slate-950 p-2 rounded border border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: getColorHex(n.label) }}></span>
                  <span>Point ({n.x}, {n.y}) - Class {n.label}</span>
                </div>
                <span className="text-slate-400">Dist: {n.dist.toFixed(3)}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs text-slate-300">
          <span className="text-xs font-bold uppercase tracking-wider text-purple-400 block mb-2">
            KJSIT Virtual Lab Execution Trace
          </span>
          <div className="space-y-1 max-h-32 overflow-y-auto">
            {logs.map((log, i) => (
              <div key={i} className="flex items-start gap-2">
                <span className="text-blue-500">&gt;</span>
                <span className={i === 0 ? 'text-emerald-300 font-semibold' : 'text-slate-400'}>{log}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
