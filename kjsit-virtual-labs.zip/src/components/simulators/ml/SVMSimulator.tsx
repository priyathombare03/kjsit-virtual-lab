import React, { useState } from 'react';
import { Shield, RotateCcw, Award, Layers } from 'lucide-react';

interface SVMPoint {
  id: number;
  x: number;
  y: number;
  label: -1 | 1;
  isSupportVector?: boolean;
}

export const SVMSimulator: React.FC = () => {
  const [cParam, setCParam] = useState<number>(1.0);
  const [kernel, setKernel] = useState<'linear' | 'rbf'>('linear');

  // Hardcoded Linear Max Margin points
  const points: SVMPoint[] = [
    // Class -1 (Red)
    { id: 1, x: 2.0, y: 3.0, label: -1 },
    { id: 2, x: 1.5, y: 4.5, label: -1 },
    { id: 3, x: 3.0, y: 2.5, label: -1 },
    { id: 4, x: 3.5, y: 5.0, label: -1, isSupportVector: true },
    // Class +1 (Blue)
    { id: 5, x: 5.5, y: 6.5, label: 1, isSupportVector: true },
    { id: 6, x: 7.0, y: 8.0, label: 1 },
    { id: 7, x: 8.0, y: 6.0, label: 1 },
    { id: 8, x: 6.5, y: 9.0, label: 1 }
  ];

  // Map 2D space [0, 10] x [0, 10] -> SVG [40, 460] x [260, 20]
  const mapX = (x: number) => 40 + (x / 10) * 420;
  const mapY = (y: number) => 260 - (y / 10) * 230;

  // Maximum margin separating hyperplane: x + y = 10 approximately
  // Main separator: y = -x + 10.2
  // Margin 1 (w.x + b = +1): y = -x + 12.0
  // Margin -1 (w.x + b = -1): y = -x + 8.4

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-wrap gap-4 items-center justify-between">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-400 font-mono">Kernel Type:</span>
            <select
              value={kernel}
              onChange={(e) => setKernel(e.target.value as any)}
              className="bg-slate-950 text-white text-xs px-2 py-0.5 rounded border border-slate-700 font-mono font-bold"
            >
              <option value="linear">Linear Kernel K(x, x') = xᵀx'</option>
              <option value="rbf">RBF / Gaussian Kernel exp(-γ||x-x'||²)</option>
            </select>
          </div>

          <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-400 font-mono">Regularization (C):</span>
            <input
              type="range"
              min="0.1"
              max="10"
              step="0.5"
              value={cParam}
              onChange={(e) => setCParam(parseFloat(e.target.value))}
              className="w-24 accent-blue-500 cursor-pointer"
            />
            <span className="text-xs text-white font-mono font-bold">C = {cParam.toFixed(1)}</span>
          </div>
        </div>

        <button
          onClick={() => {
            setCParam(1.0);
            setKernel('linear');
          }}
          className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors border border-slate-700"
          title="Reset"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Margin Width (2/||w||)</span>
          <span className="text-xl font-bold font-mono text-emerald-400">1.824</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Support Vectors</span>
          <span className="text-xl font-bold font-mono text-blue-400">2 Points</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Optimization</span>
          <span className="text-xl font-bold font-mono text-purple-400">Dual QP Solved</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Classification</span>
          <span className="text-xl font-bold font-mono text-white">100% Separable</span>
        </div>
      </div>

      {/* 2D Canvas */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-inner">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-400">
            SVM Maximum-Margin Decision Boundary with Support Vector Girdle
          </span>
          <div className="flex items-center gap-3 text-xs font-mono">
            <div className="flex items-center gap-1 text-red-400">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block"></span>
              <span>Class -1</span>
            </div>
            <div className="flex items-center gap-1 text-blue-400">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block"></span>
              <span>Class +1</span>
            </div>
            <div className="flex items-center gap-1 text-amber-300">
              <span className="w-2.5 h-2.5 rounded-full border-2 border-amber-400 inline-block"></span>
              <span>Support Vectors</span>
            </div>
          </div>
        </div>

        <div className="flex justify-center">
          <svg viewBox="0 0 500 290" className="w-full max-w-[580px] bg-slate-950 rounded-xl border border-slate-800">
            {/* Grid */}
            {[0, 2, 4, 6, 8, 10].map((x) => (
              <line key={`gx-${x}`} x1={mapX(x)} y1={mapY(0)} x2={mapX(x)} y2={mapY(10)} stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />
            ))}
            {[0, 2, 4, 6, 8, 10].map((y) => (
              <line key={`gy-${y}`} x1={mapX(0)} y1={mapY(y)} x2={mapX(10)} y2={mapY(y)} stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />
            ))}

            {/* Axes */}
            <line x1={mapX(0)} y1={mapY(0)} x2={mapX(10)} y2={mapY(0)} stroke="#64748b" strokeWidth="2" />
            <line x1={mapX(0)} y1={mapY(0)} x2={mapX(0)} y2={mapY(10)} stroke="#64748b" strokeWidth="2" />

            {/* Margin Street Polygon */}
            <polygon
              points={`
                ${mapX(0)},${mapY(12.0)} 
                ${mapX(10)},${mapY(2.0)} 
                ${mapX(10)},${mapY(-1.6)} 
                ${mapX(0)},${mapY(8.4)}
              `}
              fill="#3b82f6"
              fillOpacity="0.08"
            />

            {/* Margin Lines */}
            <line x1={mapX(0)} y1={mapY(12.0)} x2={mapX(10)} y2={mapY(2.0)} stroke="#60a5fa" strokeWidth="1.5" strokeDasharray="4 3" />
            <line x1={mapX(0)} y1={mapY(8.4)} x2={mapX(10)} y2={mapY(-1.6)} stroke="#f87171" strokeWidth="1.5" strokeDasharray="4 3" />

            {/* Main Decision Boundary */}
            <line x1={mapX(0)} y1={mapY(10.2)} x2={mapX(10)} y2={mapY(0.2)} stroke="#ffffff" strokeWidth="3" />

            {/* Data points */}
            {points.map((pt) => (
              <g key={`pt-${pt.id}`}>
                {pt.isSupportVector && (
                  <circle
                    cx={mapX(pt.x)}
                    cy={mapY(pt.y)}
                    r="12"
                    fill="none"
                    stroke="#fbbf24"
                    strokeWidth="2"
                    strokeDasharray="3 2"
                    className="animate-spin"
                  />
                )}
                <circle
                  cx={mapX(pt.x)}
                  cy={mapY(pt.y)}
                  r="6"
                  fill={pt.label === 1 ? '#3b82f6' : '#ef4444'}
                  stroke="#ffffff"
                  strokeWidth="1.5"
                />
              </g>
            ))}
          </svg>
        </div>
      </div>
    </div>
  );
};
