import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, ShieldCheck, Activity, Target } from 'lucide-react';

interface DataPoint {
  x1: number;
  x2: number;
  label: 0 | 1;
}

export const LogisticRegressionSimulator: React.FC = () => {
  const [points, setPoints] = useState<DataPoint[]>([
    // Class 0 (Red / Negative)
    { x1: 2.0, x2: 3.0, label: 0 },
    { x1: 1.5, x2: 2.0, label: 0 },
    { x1: 3.0, x2: 1.5, label: 0 },
    { x1: 2.5, x2: 4.0, label: 0 },
    { x1: 1.0, x2: 3.5, label: 0 },
    { x1: 3.5, x2: 3.0, label: 0 },
    // Class 1 (Green / Positive)
    { x1: 6.0, x2: 7.0, label: 1 },
    { x1: 7.5, x2: 8.0, label: 1 },
    { x1: 8.0, x2: 6.5, label: 1 },
    { x1: 6.5, x2: 8.5, label: 1 },
    { x1: 5.5, x2: 6.0, label: 1 },
    { x1: 7.0, x2: 7.5, label: 1 }
  ]);

  const [w1, setW1] = useState<number>(0.1);
  const [w2, setW2] = useState<number>(0.1);
  const [bias, setBias] = useState<number>(-0.5);
  const [threshold, setThreshold] = useState<number>(0.5);
  const [learningRate, setLearningRate] = useState<number>(0.05);
  const [epoch, setEpoch] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [logs, setLogs] = useState<string[]>([
    'KJSIT Virtual Lab initialized: Logistic Regression Binary Classifier.',
    'Hypothesis: σ(w₁x₁ + w₂x₂ + b), Cross-Entropy Log-Loss minimization.'
  ]);

  const sigmoid = (z: number) => 1.0 / (1.0 + Math.exp(-Math.max(-100, Math.min(100, z))));

  const addLog = (msg: string) => {
    setLogs((prev) => [msg, ...prev.slice(0, 6)]);
  };

  const computeLogLoss = () => {
    if (points.length === 0) return 0;
    const loss = points.reduce((sum, pt) => {
      const z = w1 * pt.x1 + w2 * pt.x2 + bias;
      const p = Math.max(1e-7, Math.min(1 - 1e-7, sigmoid(z)));
      return sum - (pt.label * Math.log(p) + (1 - pt.label) * Math.log(1 - p));
    }, 0);
    return loss / points.length;
  };

  const stepGradientDescent = () => {
    const m = points.length;
    let dw1 = 0;
    let dw2 = 0;
    let db = 0;

    points.forEach((pt) => {
      const z = w1 * pt.x1 + w2 * pt.x2 + bias;
      const yHat = sigmoid(z);
      const err = yHat - pt.label;
      dw1 += err * pt.x1;
      dw2 += err * pt.x2;
      db += err;
    });

    const newW1 = w1 - learningRate * (dw1 / m);
    const newW2 = w2 - learningRate * (dw2 / m);
    const newBias = bias - learningRate * (db / m);

    setW1(newW1);
    setW2(newW2);
    setBias(newBias);
    setEpoch((prev) => prev + 1);

    addLog(
      `Epoch ${epoch + 1}: w₁=${newW1.toFixed(3)}, w₂=${newW2.toFixed(3)}, b=${newBias.toFixed(3)}, Log-Loss=${computeLogLoss().toFixed(4)}`
    );
  };

  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        stepGradientDescent();
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isPlaying, w1, w2, bias, points, learningRate, epoch]);

  // Confusion Matrix Calculation
  let TP = 0, FP = 0, TN = 0, FN = 0;
  points.forEach((pt) => {
    const z = w1 * pt.x1 + w2 * pt.x2 + bias;
    const predProb = sigmoid(z);
    const pred = predProb >= threshold ? 1 : 0;
    if (pred === 1 && pt.label === 1) TP++;
    else if (pred === 1 && pt.label === 0) FP++;
    else if (pred === 0 && pt.label === 0) TN++;
    else FN++;
  });

  const accuracy = ((TP + TN) / (points.length || 1)) * 100;
  const precision = TP + FP > 0 ? (TP / (TP + FP)) * 100 : 100;
  const recall = TP + FN > 0 ? (TP / (TP + FN)) * 100 : 100;

  // Map 2D Coordinate Space [0, 10] x [0, 10] -> SVG [40, 460] x [260, 20]
  const mapX = (x: number) => 40 + (x / 10) * 420;
  const mapY = (y: number) => 260 - (y / 10) * 230;

  // Decision boundary line: w1 x1 + w2 x2 + b = log(threshold / (1 - threshold))
  // x2 = (threshold_z - b - w1*x1) / w2
  const zCutoff = Math.log(threshold / (1.0 - threshold + 1e-9));
  const calcBoundaryY = (x1: number) => {
    if (Math.abs(w2) < 1e-5) return 5;
    return (zCutoff - bias - w1 * x1) / w2;
  };

  const handleReset = () => {
    setIsPlaying(false);
    setW1(0.1);
    setW2(0.1);
    setBias(-0.5);
    setEpoch(0);
    setLogs(['Model reset: weights and bias initialized to default values.']);
  };

  return (
    <div className="space-y-6">
      {/* Controls Bar */}
      <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-wrap gap-4 items-center justify-between">
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm ${
              isPlaying ? 'bg-amber-600 hover:bg-amber-700 text-white' : 'bg-emerald-600 hover:bg-emerald-700 text-white'
            }`}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isPlaying ? 'Pause' : 'Train Optimizer'}</span>
          </button>

          <button
            onClick={stepGradientDescent}
            disabled={isPlaying}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors disabled:opacity-50"
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Step Epoch</span>
          </button>

          <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-400 font-mono">Threshold (θ):</span>
            <input
              type="range"
              min="0.1"
              max="0.9"
              step="0.05"
              value={threshold}
              onChange={(e) => setThreshold(parseFloat(e.target.value))}
              className="w-20 accent-blue-500 cursor-pointer"
            />
            <span className="text-xs text-white font-mono font-bold">{threshold.toFixed(2)}</span>
          </div>

          <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-400 font-mono">LR (α):</span>
            <select
              value={learningRate}
              onChange={(e) => setLearningRate(parseFloat(e.target.value))}
              className="bg-slate-950 text-white text-xs px-2 py-0.5 rounded border border-slate-700 font-mono"
            >
              <option value="0.01">0.01</option>
              <option value="0.05">0.05</option>
              <option value="0.1">0.10</option>
            </select>
          </div>
        </div>

        <button
          onClick={handleReset}
          className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors border border-slate-700"
          title="Reset"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Metrics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Accuracy</span>
          <span className="text-xl font-bold font-mono text-emerald-400">{accuracy.toFixed(1)}%</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Log-Loss (Cost)</span>
          <span className="text-xl font-bold font-mono text-amber-400">{computeLogLoss().toFixed(4)}</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Precision</span>
          <span className="text-xl font-bold font-mono text-blue-400">{precision.toFixed(1)}%</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Recall</span>
          <span className="text-xl font-bold font-mono text-purple-400">{recall.toFixed(1)}%</span>
        </div>
      </div>

      {/* 2D Decision Boundary Canvas & Confusion Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-inner">
          <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-400">
              2D Classification Boundary: w₁x₁ + w₂x₂ + b = 0
            </span>
            <div className="flex items-center gap-3 text-xs font-mono">
              <div className="flex items-center gap-1 text-red-400">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block"></span>
                <span>Class 0</span>
              </div>
              <div className="flex items-center gap-1 text-emerald-400">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block"></span>
                <span>Class 1</span>
              </div>
            </div>
          </div>

          <div className="flex justify-center">
            <svg viewBox="0 0 500 290" className="w-full max-w-[550px] bg-slate-950 rounded-xl border border-slate-800">
              {/* Grid */}
              {[0, 2, 4, 6, 8, 10].map((x) => (
                <line key={`gx-${x}`} x1={mapX(x)} y1={mapY(0)} x2={mapX(x)} y2={mapY(10)} stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />
              ))}
              {[0, 2, 4, 6, 8, 10].map((y) => (
                <line key={`gy-${y}`} x1={mapX(0)} y1={mapY(y)} x2={mapX(10)} y2={mapY(y)} stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />
              ))}

              {/* Axes */}
              <line x1={mapX(0)} y1={mapY(0)} x2={mapX(10)} y2={mapY(0)} stroke="#64748b" strokeWidth="2" />
              <line x1={mapX(0)} y1={mapY(0)} x2={mapX(0)} y2={mapY(10)} stroke="#64748b" strokeWidth="2" />

              {/* Labels */}
              {[0, 2, 4, 6, 8, 10].map((x) => (
                <text key={`tx-${x}`} x={mapX(x)} y={mapY(0) + 16} fill="#94a3b8" fontSize="10" textAnchor="middle">{x}</text>
              ))}
              {[0, 2, 4, 6, 8, 10].map((y) => (
                <text key={`ty-${y}`} x={mapX(0) - 8} y={mapY(y) + 3} fill="#94a3b8" fontSize="10" textAnchor="end">{y}</text>
              ))}

              {/* Decision Hyperplane */}
              <line
                x1={mapX(0)}
                y1={mapY(calcBoundaryY(0))}
                x2={mapX(10)}
                y2={mapY(calcBoundaryY(10))}
                stroke="#3b82f6"
                strokeWidth="3"
                strokeDasharray="4 2"
              />

              {/* Data points */}
              {points.map((pt, idx) => (
                <circle
                  key={`pt-${idx}`}
                  cx={mapX(pt.x1)}
                  cy={mapY(pt.x2)}
                  r="6"
                  fill={pt.label === 1 ? '#10b981' : '#ef4444'}
                  stroke={pt.label === 1 ? '#064e3b' : '#7f1d1d'}
                  strokeWidth="1.5"
                />
              ))}
            </svg>
          </div>
        </div>

        {/* Confusion Matrix Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-purple-400 block mb-3">
              Confusion Matrix
            </span>
            <div className="grid grid-cols-2 gap-2 text-center font-mono">
              <div className="bg-emerald-950/80 border border-emerald-800 p-3 rounded-lg">
                <span className="text-[10px] text-emerald-400 block">True Positive (TP)</span>
                <span className="text-lg font-bold text-white">{TP}</span>
              </div>
              <div className="bg-red-950/80 border border-red-800 p-3 rounded-lg">
                <span className="text-[10px] text-red-400 block">False Positive (FP)</span>
                <span className="text-lg font-bold text-white">{FP}</span>
              </div>
              <div className="bg-red-950/80 border border-red-800 p-3 rounded-lg">
                <span className="text-[10px] text-red-400 block">False Negative (FN)</span>
                <span className="text-lg font-bold text-white">{FN}</span>
              </div>
              <div className="bg-emerald-950/80 border border-emerald-800 p-3 rounded-lg">
                <span className="text-[10px] text-emerald-400 block">True Negative (TN)</span>
                <span className="text-lg font-bold text-white">{TN}</span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] font-mono text-slate-400">
            <div>Weights: w₁={w1.toFixed(3)}, w₂={w2.toFixed(3)}</div>
            <div>Bias: b={bias.toFixed(3)}</div>
          </div>
        </div>
      </div>

      {/* Logs */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs text-slate-300">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-800 text-slate-400 font-semibold mb-2">
          <Target className="w-3.5 h-3.5 text-blue-400" />
          <span>KJSIT Virtual Lab Execution Trace</span>
        </div>
        <div className="space-y-1 max-h-32 overflow-y-auto">
          {logs.map((log, i) => (
            <div key={i} className="flex items-start gap-2">
              <span className="text-blue-500">&gt;</span>
              <span className={i === 0 ? 'text-emerald-300 font-semibold' : 'text-slate-400'}>{log}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
