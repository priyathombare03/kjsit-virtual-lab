import React, { useState } from 'react';
import { RotateCcw, Award, CheckCircle2, BarChart2 } from 'lucide-react';

export const NaiveBayesSimulator: React.FC = () => {
  // Class 0: μ = 3.0, σ = 1.2; Class 1: μ = 7.0, σ = 1.4
  const [testFeatureX, setTestFeatureX] = useState<number>(4.8);
  const [priorC0, setPriorC0] = useState<number>(0.5);

  const priorC1 = 1.0 - priorC0;
  const mu0 = 3.0, sigma0 = 1.2;
  const mu1 = 7.0, sigma1 = 1.4;

  const gaussianPdf = (x: number, mu: number, sigma: number) => {
    const num = Math.exp(-Math.pow(x - mu, 2) / (2 * Math.pow(sigma, 2)));
    const den = Math.sqrt(2 * Math.PI) * sigma;
    return num / den;
  };

  const likelihoodC0 = gaussianPdf(testFeatureX, mu0, sigma0);
  const likelihoodC1 = gaussianPdf(testFeatureX, mu1, sigma1);

  const unnormPostC0 = priorC0 * likelihoodC0;
  const unnormPostC1 = priorC1 * likelihoodC1;
  const totalEvidence = unnormPostC0 + unnormPostC1;

  const posteriorC0 = (unnormPostC0 / (totalEvidence || 1)) * 100;
  const posteriorC1 = (unnormPostC1 / (totalEvidence || 1)) * 100;

  const classifiedClass = posteriorC0 >= posteriorC1 ? 'Class 0 (Normal)' : 'Class 1 (Anomalous)';

  // SVG coordinate mapper: X [0, 10] -> SVG [40, 460], Y [0, 0.4] -> SVG [240, 20]
  const mapX = (x: number) => 40 + (x / 10) * 420;
  const mapY = (y: number) => 240 - (y / 0.4) * 210;

  // Generate curve path
  const generateCurve = (mu: number, sigma: number) => {
    let d = '';
    for (let x = 0; x <= 10; x += 0.2) {
      const y = gaussianPdf(x, mu, sigma);
      const px = mapX(x);
      const py = mapY(y);
      d += (x === 0 ? `M ${px} ${py}` : ` L ${px} ${py}`);
    }
    return d;
  };

  return (
    <div className="space-y-6">
      {/* Top Controls */}
      <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-wrap gap-4 items-center justify-between">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-400 font-mono">Test Sample (x):</span>
            <input
              type="range"
              min="0.5"
              max="9.5"
              step="0.1"
              value={testFeatureX}
              onChange={(e) => setTestFeatureX(parseFloat(e.target.value))}
              className="w-28 accent-blue-500 cursor-pointer"
            />
            <span className="text-xs text-white font-mono font-bold">{testFeatureX.toFixed(1)}</span>
          </div>

          <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-400 font-mono">Prior P(Class 0):</span>
            <input
              type="range"
              min="0.1"
              max="0.9"
              step="0.1"
              value={priorC0}
              onChange={(e) => setPriorC0(parseFloat(e.target.value))}
              className="w-20 accent-emerald-500 cursor-pointer"
            />
            <span className="text-xs text-white font-mono font-bold">{priorC0.toFixed(1)}</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setTestFeatureX(4.8);
              setPriorC0(0.5);
            }}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors border border-slate-700"
            title="Reset"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Probability Results Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 text-center">
          <span className="text-[10px] text-blue-400 uppercase font-mono block">Class 0 Posterior P(C0|x)</span>
          <span className="text-2xl font-bold font-mono text-blue-400">{posteriorC0.toFixed(1)}%</span>
          <span className="text-[10px] text-slate-400 block mt-1 font-mono">Likelihood: {likelihoodC0.toFixed(4)}</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 text-center">
          <span className="text-[10px] text-purple-400 uppercase font-mono block">Class 1 Posterior P(C1|x)</span>
          <span className="text-2xl font-bold font-mono text-purple-400">{posteriorC1.toFixed(1)}%</span>
          <span className="text-[10px] text-slate-400 block mt-1 font-mono">Likelihood: {likelihoodC1.toFixed(4)}</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 text-center">
          <span className="text-[10px] text-emerald-400 uppercase font-mono block">MAP Decision</span>
          <span className="text-sm font-bold font-mono text-white mt-1 block">{classifiedClass}</span>
          <span className="text-[10px] text-slate-400 block mt-1 font-mono">Bayes Criterion Maximized</span>
        </div>
      </div>

      {/* Gaussian Distribution Curves */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-inner">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-400">
            Gaussian Class-Conditional Likelihood Distributions 𝒩(μ, σ²)
          </span>
          <div className="flex items-center gap-3 text-xs font-mono">
            <div className="flex items-center gap-1 text-blue-400">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block"></span>
              <span>Class 0 (μ=3.0, σ=1.2)</span>
            </div>
            <div className="flex items-center gap-1 text-purple-400">
              <span className="w-2.5 h-2.5 rounded-full bg-purple-500 inline-block"></span>
              <span>Class 1 (μ=7.0, σ=1.4)</span>
            </div>
          </div>
        </div>

        <div className="flex justify-center">
          <svg viewBox="0 0 500 270" className="w-full max-w-[580px] bg-slate-950 rounded-xl border border-slate-800">
            {/* Grid */}
            {[0, 2, 4, 6, 8, 10].map((x) => (
              <line key={`gx-${x}`} x1={mapX(x)} y1={mapY(0)} x2={mapX(x)} y2={mapY(0.4)} stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />
            ))}

            {/* Axes */}
            <line x1={mapX(0)} y1={mapY(0)} x2={mapX(10)} y2={mapY(0)} stroke="#64748b" strokeWidth="2" />
            <line x1={mapX(0)} y1={mapY(0)} x2={mapX(0)} y2={mapY(0.4)} stroke="#64748b" strokeWidth="2" />

            {/* Labels */}
            {[0, 2, 4, 6, 8, 10].map((x) => (
              <text key={`tx-${x}`} x={mapX(x)} y={mapY(0) + 16} fill="#94a3b8" fontSize="10" textAnchor="middle">{x}</text>
            ))}

            {/* Curve 0 (Blue) */}
            <path d={generateCurve(mu0, sigma0)} fill="none" stroke="#3b82f6" strokeWidth="3" />

            {/* Curve 1 (Purple) */}
            <path d={generateCurve(mu1, sigma1)} fill="none" stroke="#a855f7" strokeWidth="3" />

            {/* Vertical Sample Line */}
            <line
              x1={mapX(testFeatureX)}
              y1={mapY(0)}
              x2={mapX(testFeatureX)}
              y2={mapY(0.38)}
              stroke="#fbbf24"
              strokeWidth="2"
              strokeDasharray="4 2"
            />
            <circle cx={mapX(testFeatureX)} cy={mapY(likelihoodC0)} r="5" fill="#3b82f6" stroke="#ffffff" strokeWidth="1.5" />
            <circle cx={mapX(testFeatureX)} cy={mapY(likelihoodC1)} r="5" fill="#a855f7" stroke="#ffffff" strokeWidth="1.5" />
          </svg>
        </div>
      </div>
    </div>
  );
};
