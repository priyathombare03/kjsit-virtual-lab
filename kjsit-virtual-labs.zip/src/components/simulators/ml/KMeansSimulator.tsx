import React, { useState } from 'react';
import { Play, RotateCcw, Activity, RefreshCw, Layers } from 'lucide-react';

interface ClusterPoint {
  id: number;
  x: number;
  y: number;
  cluster: number; // -1: unassigned, 0..K-1
}

interface Centroid {
  x: number;
  y: number;
  color: string;
}

const CLUSTER_COLORS = ['#ef4444', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6'];

export const KMeansSimulator: React.FC = () => {
  const [k, setK] = useState<number>(3);
  const [points, setPoints] = useState<ClusterPoint[]>([
    // Cluster 1 cluster
    { id: 1, x: 2.0, y: 3.0, cluster: -1 },
    { id: 2, x: 2.5, y: 3.8, cluster: -1 },
    { id: 3, x: 1.8, y: 2.2, cluster: -1 },
    { id: 4, x: 3.2, y: 2.8, cluster: -1 },
    { id: 5, x: 2.2, y: 4.2, cluster: -1 },
    // Cluster 2 cluster
    { id: 6, x: 7.5, y: 8.0, cluster: -1 },
    { id: 7, x: 8.2, y: 7.5, cluster: -1 },
    { id: 8, x: 6.8, y: 8.8, cluster: -1 },
    { id: 9, x: 8.5, y: 8.5, cluster: -1 },
    { id: 10, x: 7.0, y: 7.2, cluster: -1 },
    // Cluster 3 cluster
    { id: 11, x: 8.0, y: 2.5, cluster: -1 },
    { id: 12, x: 7.2, y: 3.2, cluster: -1 },
    { id: 13, x: 8.5, y: 1.8, cluster: -1 },
    { id: 14, x: 9.0, y: 3.0, cluster: -1 },
    { id: 15, x: 7.8, y: 2.0, cluster: -1 }
  ]);

  const [centroids, setCentroids] = useState<Centroid[]>([
    { x: 3.0, y: 7.0, color: CLUSTER_COLORS[0] },
    { x: 6.0, y: 3.0, color: CLUSTER_COLORS[1] },
    { x: 5.0, y: 5.0, color: CLUSTER_COLORS[2] }
  ]);

  const [iteration, setIteration] = useState<number>(0);
  const [wcss, setWcss] = useState<number>(0);
  const [logs, setLogs] = useState<string[]>([
    'KJSIT Virtual Lab initialized: K-Means Clustering Algorithm.',
    'Click "Step Iteration" to execute Lloyd\'s Alternating Expectation-Maximization step.'
  ]);

  const addLog = (msg: string) => {
    setLogs((prev) => [msg, ...prev.slice(0, 6)]);
  };

  const distSq = (x1: number, y1: number, x2: number, y2: number) => {
    return Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2);
  };

  // Step 1: Assign points to nearest centroid
  // Step 2: Recompute centroid coordinates
  const handleStepIteration = () => {
    // Step 1: Assignment
    let totalWcss = 0;
    const updatedPoints = points.map((p) => {
      let minDist = Infinity;
      let closestCluster = 0;

      centroids.forEach((c, idx) => {
        const d = distSq(p.x, p.y, c.x, c.y);
        if (d < minDist) {
          minDist = d;
          closestCluster = idx;
        }
      });

      totalWcss += minDist;
      return { ...p, cluster: closestCluster };
    });

    // Step 2: Update centroids
    const newCentroids = centroids.map((c, idx) => {
      const assigned = updatedPoints.filter((p) => p.cluster === idx);
      if (assigned.length === 0) return c;
      const sumX = assigned.reduce((acc, p) => acc + p.x, 0);
      const sumY = assigned.reduce((acc, p) => acc + p.y, 0);
      return {
        ...c,
        x: parseFloat((sumX / assigned.length).toFixed(2)),
        y: parseFloat((sumY / assigned.length).toFixed(2))
      };
    });

    setPoints(updatedPoints);
    setCentroids(newCentroids);
    setIteration((prev) => prev + 1);
    setWcss(totalWcss);

    addLog(`Iteration ${iteration + 1}: Points assigned to ${k} Voronoi cells. WCSS = ${totalWcss.toFixed(3)}`);
  };

  const handleKChange = (newK: number) => {
    setK(newK);
    setIteration(0);
    setWcss(0);

    // Pick random centroids from current points
    const sampled = [...points].sort(() => 0.5 - Math.random()).slice(0, newK);
    const newC: Centroid[] = sampled.map((s, i) => ({
      x: s.x + (Math.random() - 0.5),
      y: s.y + (Math.random() - 0.5),
      color: CLUSTER_COLORS[i % CLUSTER_COLORS.length]
    }));

    setCentroids(newC);
    setPoints(points.map((p) => ({ ...p, cluster: -1 })));
    addLog(`Re-initialized with K = ${newK} clusters.`);
  };

  const handleReset = () => {
    setIteration(0);
    setWcss(0);
    setPoints(points.map((p) => ({ ...p, cluster: -1 })));
    setCentroids([
      { x: 3.0, y: 7.0, color: CLUSTER_COLORS[0] },
      { x: 6.0, y: 3.0, color: CLUSTER_COLORS[1] },
      { x: 5.0, y: 5.0, color: CLUSTER_COLORS[2] }
    ]);
    addLog('Reset centroids and unassigned cluster labels.');
  };

  // Coordinate mapping
  const mapX = (x: number) => 40 + (x / 10) * 420;
  const mapY = (y: number) => 260 - (y / 10) * 230;

  return (
    <div className="space-y-6">
      {/* Control Bar */}
      <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-wrap gap-4 items-center justify-between">
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={handleStepIteration}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Step Iteration</span>
          </button>

          <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-400 font-mono">Clusters (K):</span>
            <select
              value={k}
              onChange={(e) => handleKChange(parseInt(e.target.value, 10))}
              className="bg-slate-950 text-white text-xs px-2 py-0.5 rounded border border-slate-700 font-mono font-bold focus:outline-none"
            >
              <option value="2">K = 2</option>
              <option value="3">K = 3 (Default)</option>
              <option value="4">K = 4</option>
              <option value="5">K = 5</option>
            </select>
          </div>
        </div>

        <button
          onClick={handleReset}
          className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors border border-slate-700"
          title="Reset"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Iterations</span>
          <span className="text-xl font-bold font-mono text-white">{iteration}</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">WCSS (Inertia)</span>
          <span className="text-xl font-bold font-mono text-amber-400">{wcss.toFixed(3)}</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Number of Clusters</span>
          <span className="text-xl font-bold font-mono text-blue-400">{k}</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Total Samples</span>
          <span className="text-xl font-bold font-mono text-emerald-400">{points.length}</span>
        </div>
      </div>

      {/* 2D Canvas */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-inner">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-400">
            2D Voronoi Clustering Canvas
          </span>
          <div className="flex items-center gap-3 text-xs font-mono">
            {centroids.slice(0, k).map((c, idx) => (
              <div key={idx} className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: c.color }}></span>
                <span style={{ color: c.color }}>Centroid {idx + 1} ({c.x}, {c.y})</span>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-center">
          <svg viewBox="0 0 500 290" className="w-full max-w-[580px] bg-slate-950 rounded-xl border border-slate-800">
            {/* Grid */}
            {[0, 2, 4, 6, 8, 10].map((x) => (
              <line key={`gx-${x}`} x1={mapX(x)} y1={mapY(0)} x2={mapX(x)} y2={mapY(10)} stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />
            ))}
            {[0, 2, 4, 6, 8, 10].map((y) => (
              <line key={`gy-${y}`} x1={mapX(0)} y1={mapY(y)} x2={mapX(10)} y2={mapY(y)} stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />
            ))}

            {/* Axes */}
            <line x1={mapX(0)} y1={mapY(0)} x2={mapX(10)} y2={mapY(0)} stroke="#64748b" strokeWidth="2" />
            <line x1={mapX(0)} y1={mapY(0)} x2={mapX(0)} y2={mapY(10)} stroke="#64748b" strokeWidth="2" />

            {/* Connection lines from points to assigned centroids */}
            {points.map((p) => {
              if (p.cluster < 0 || p.cluster >= centroids.length) return null;
              const c = centroids[p.cluster];
              return (
                <line
                  key={`line-${p.id}`}
                  x1={mapX(p.x)}
                  y1={mapY(p.y)}
                  x2={mapX(c.x)}
                  y2={mapY(c.y)}
                  stroke={c.color}
                  strokeWidth="1"
                  strokeDasharray="2 2"
                  opacity="0.4"
                />
              );
            })}

            {/* Data points */}
            {points.map((p) => {
              const color = p.cluster >= 0 ? centroids[p.cluster]?.color || '#94a3b8' : '#94a3b8';
              return (
                <circle
                  key={`pt-${p.id}`}
                  cx={mapX(p.x)}
                  cy={mapY(p.y)}
                  r="5.5"
                  fill={color}
                  stroke="#0f172a"
                  strokeWidth="1.5"
                />
              );
            })}

            {/* Centroids */}
            {centroids.slice(0, k).map((c, idx) => (
              <g key={`c-${idx}`}>
                <polygon
                  points={`
                    ${mapX(c.x)},${mapY(c.y) - 10} 
                    ${mapX(c.x) + 9},${mapY(c.y) + 7} 
                    ${mapX(c.x) - 9},${mapY(c.y) + 7}
                  `}
                  fill={c.color}
                  stroke="#ffffff"
                  strokeWidth="2"
                  className="animate-pulse"
                />
                <circle cx={mapX(c.x)} cy={mapY(c.y)} r="18" fill="none" stroke={c.color} strokeWidth="1" strokeDasharray="3 3" opacity="0.6" />
              </g>
            ))}
          </svg>
        </div>
      </div>

      {/* Logs */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs text-slate-300">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-800 text-slate-400 font-semibold mb-2">
          <Layers className="w-3.5 h-3.5 text-blue-400" />
          <span>KJSIT Virtual Lab Execution Trace & Centroid Convergence</span>
        </div>
        <div className="space-y-1 max-h-32 overflow-y-auto">
          {logs.map((log, i) => (
            <div key={i} className="flex items-start gap-2">
              <span className="text-blue-500">&gt;</span>
              <span className={i === 0 ? 'text-emerald-300 font-semibold' : 'text-slate-400'}>{log}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
