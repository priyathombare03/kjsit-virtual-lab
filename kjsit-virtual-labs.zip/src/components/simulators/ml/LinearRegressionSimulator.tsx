import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Plus, RefreshCw, BarChart2, TrendingUp, Award } from 'lucide-react';

interface Point {
  x: number;
  y: number;
}

export const LinearRegressionSimulator: React.FC = () => {
  const [points, setPoints] = useState<Point[]>([
    { x: 1.0, y: 2.2 },
    { x: 2.0, y: 3.8 },
    { x: 3.0, y: 5.5 },
    { x: 4.0, y: 7.2 },
    { x: 5.0, y: 9.8 },
    { x: 6.0, y: 11.4 },
    { x: 7.0, y: 13.1 },
    { x: 8.0, y: 15.6 }
  ]);

  const [weight, setWeight] = useState<number>(0.0);
  const [bias, setBias] = useState<number>(0.0);
  const [learningRate, setLearningRate] = useState<number>(0.02);
  const [epoch, setEpoch] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [lossHistory, setLossHistory] = useState<number[]>([]);
  const [logs, setLogs] = useState<string[]>([
    'KJSIT Virtual Lab initialized: Univariate Linear Regression with Gradient Descent.',
    'Model: ŷ = w·x + b, Cost Function: MSE = (1/2m) ∑(ŷ - y)²'
  ]);

  const addLog = (msg: string) => {
    setLogs((prev) => [msg, ...prev.slice(0, 6)]);
  };

  // Compute Current MSE Loss
  const computeLoss = (w: number, b: number, pts: Point[]) => {
    if (pts.length === 0) return 0;
    const totalSqErr = pts.reduce((sum, pt) => {
      const pred = w * pt.x + b;
      return sum + Math.pow(pred - pt.y, 2);
    }, 0);
    return totalSqErr / (2 * pts.length);
  };

  const currentLoss = computeLoss(weight, bias, points);

  // One Gradient Descent Step
  const stepGradientDescent = () => {
    if (points.length === 0) return;
    const m = points.length;
    let dw = 0;
    let db = 0;

    points.forEach((pt) => {
      const pred = weight * pt.x + bias;
      const error = pred - pt.y;
      dw += error * pt.x;
      db += error;
    });

    const newWeight = weight - learningRate * (dw / m);
    const newBias = bias - learningRate * (db / m);
    const newLoss = computeLoss(newWeight, newBias, points);

    setWeight(newWeight);
    setBias(newBias);
    setEpoch((prev) => prev + 1);
    setLossHistory((prev) => [...prev.slice(-25), newLoss]);

    addLog(
      `Epoch ${epoch + 1}: w = ${newWeight.toFixed(3)}, b = ${newBias.toFixed(3)}, Loss (MSE) = ${newLoss.toFixed(4)}`
    );
  };

  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        stepGradientDescent();
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isPlaying, weight, bias, points, learningRate, epoch]);

  // Canvas Coordinates mapping: X (0 to 10) -> (40 to 460), Y (0 to 20) -> (260 to 20)
  const mapX = (x: number) => 40 + (x / 10) * 420;
  const mapY = (y: number) => 260 - (y / 20) * 230;

  const handleCanvasClick = (e: React.MouseEvent<SVGSVGElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    // Invert mapping
    const rawX = ((clickX - 40) / 420) * 10;
    const rawY = ((260 - clickY) / 230) * 20;

    if (rawX >= 0 && rawX <= 10 && rawY >= 0 && rawY <= 20) {
      const newPt: Point = { x: parseFloat(rawX.toFixed(2)), y: parseFloat(rawY.toFixed(2)) };
      setPoints([...points, newPt]);
      addLog(`Added new sample point: (${newPt.x}, ${newPt.y})`);
    }
  };

  const handleReset = () => {
    setIsPlaying(false);
    setWeight(0.0);
    setBias(0.0);
    setEpoch(0);
    setLossHistory([]);
    setLogs(['Parameters reset to w = 0.0, b = 0.0, Epoch = 0.']);
  };

  const handleLoadDataset = (type: 'linear' | 'noisy' | 'steep') => {
    setIsPlaying(false);
    setWeight(0.0);
    setBias(0.0);
    setEpoch(0);
    setLossHistory([]);

    if (type === 'linear') {
      setPoints([
        { x: 1, y: 2 },
        { x: 2, y: 4 },
        { x: 3, y: 6 },
        { x: 4, y: 8 },
        { x: 5, y: 10 },
        { x: 6, y: 12 },
        { x: 7, y: 14 }
      ]);
      addLog('Loaded Clean Linear Dataset: y ≈ 2x');
    } else if (type === 'noisy') {
      setPoints([
        { x: 1, y: 3.2 },
        { x: 2, y: 3.8 },
        { x: 3, y: 7.1 },
        { x: 4, y: 6.9 },
        { x: 5, y: 11.2 },
        { x: 6, y: 10.5 },
        { x: 7, y: 14.8 },
        { x: 8, y: 15.1 }
      ]);
      addLog('Loaded Realistic Noisy Observation Dataset.');
    } else {
      setPoints([
        { x: 1, y: 1.5 },
        { x: 2, y: 4.5 },
        { x: 3, y: 7.5 },
        { x: 4, y: 10.5 },
        { x: 5, y: 13.5 },
        { x: 6, y: 16.5 }
      ]);
      addLog('Loaded Steep Gradient Slope Dataset: y ≈ 3x');
    }
  };

  // Regression Line Points
  const lineY0 = weight * 0 + bias;
  const lineY10 = weight * 10 + bias;

  return (
    <div className="space-y-6">
      {/* Top Controls Toolbar */}
      <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-wrap gap-4 items-center justify-between">
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm ${
              isPlaying ? 'bg-amber-600 hover:bg-amber-700 text-white' : 'bg-emerald-600 hover:bg-emerald-700 text-white'
            }`}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isPlaying ? 'Pause' : 'Auto Train'}</span>
          </button>

          <button
            onClick={stepGradientDescent}
            disabled={isPlaying}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors disabled:opacity-50"
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Step Epoch</span>
          </button>

          <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-400 font-mono">Learning Rate (α):</span>
            <select
              value={learningRate}
              onChange={(e) => setLearningRate(parseFloat(e.target.value))}
              className="bg-slate-950 text-white text-xs px-2 py-0.5 rounded border border-slate-700 font-mono font-bold focus:outline-none"
            >
              <option value="0.005">0.005 (Slow)</option>
              <option value="0.02">0.02 (Optimal)</option>
              <option value="0.05">0.05 (Fast)</option>
              <option value="0.1">0.10 (Aggressive)</option>
            </select>
          </div>

          <div className="flex items-center gap-1 bg-slate-800 px-2 py-1 rounded-lg border border-slate-700 text-xs">
            <span className="text-slate-400">Presets:</span>
            <button
              onClick={() => handleLoadDataset('linear')}
              className="px-2 py-0.5 bg-slate-700 hover:bg-slate-600 rounded text-[11px]"
            >
              Linear
            </button>
            <button
              onClick={() => handleLoadDataset('noisy')}
              className="px-2 py-0.5 bg-slate-700 hover:bg-slate-600 rounded text-[11px]"
            >
              Noisy
            </button>
            <button
              onClick={() => handleLoadDataset('steep')}
              className="px-2 py-0.5 bg-slate-700 hover:bg-slate-600 rounded text-[11px]"
            >
              Steep
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleReset}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors border border-slate-700"
            title="Reset Model Parameters"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Epoch Count</span>
          <span className="text-xl font-bold font-mono text-white">{epoch}</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Weight (Slope w)</span>
          <span className="text-xl font-bold font-mono text-blue-400">{weight.toFixed(4)}</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Bias (Intercept b)</span>
          <span className="text-xl font-bold font-mono text-purple-400">{bias.toFixed(4)}</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Loss (MSE J)</span>
          <span className="text-xl font-bold font-mono text-emerald-400">{currentLoss.toFixed(4)}</span>
        </div>
      </div>

      {/* 2D Interactive Scatter & Regression Plane */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-inner">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-400">
              Interactive 2D Feature Space
            </span>
            <span className="text-[11px] text-slate-400 font-mono">
              (Click canvas to add custom observation points)
            </span>
          </div>
          <div className="flex items-center gap-3 text-xs font-mono">
            <div className="flex items-center gap-1 text-emerald-400">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block"></span>
              <span>Dataset ({points.length} samples)</span>
            </div>
            <div className="flex items-center gap-1 text-blue-400">
              <span className="w-4 h-0.5 bg-blue-500 inline-block"></span>
              <span>ŷ = {weight.toFixed(2)}x + {bias.toFixed(2)}</span>
            </div>
          </div>
        </div>

        <div className="relative flex justify-center">
          <svg
            viewBox="0 0 500 290"
            className="w-full max-w-[600px] bg-slate-950 rounded-xl border border-slate-800 cursor-crosshair shadow-md"
            onClick={handleCanvasClick}
          >
            {/* Grid Lines */}
            {[0, 2, 4, 6, 8, 10].map((x) => (
              <line
                key={`gx-${x}`}
                x1={mapX(x)}
                y1={mapY(0)}
                x2={mapX(x)}
                y2={mapY(20)}
                stroke="#1e293b"
                strokeWidth="1"
                strokeDasharray="3 3"
              />
            ))}
            {[0, 5, 10, 15, 20].map((y) => (
              <line
                key={`gy-${y}`}
                x1={mapX(0)}
                y1={mapY(y)}
                x2={mapX(10)}
                y2={mapY(y)}
                stroke="#1e293b"
                strokeWidth="1"
                strokeDasharray="3 3"
              />
            ))}

            {/* Axes */}
            <line x1={mapX(0)} y1={mapY(0)} x2={mapX(10)} y2={mapY(0)} stroke="#64748b" strokeWidth="2" />
            <line x1={mapX(0)} y1={mapY(0)} x2={mapX(0)} y2={mapY(20)} stroke="#64748b" strokeWidth="2" />

            {/* Axis Labels */}
            {[0, 2, 4, 6, 8, 10].map((x) => (
              <text key={`tx-${x}`} x={mapX(x)} y={mapY(0) + 16} fill="#94a3b8" fontSize="10" textAnchor="middle">
                {x}
              </text>
            ))}
            {[0, 5, 10, 15, 20].map((y) => (
              <text key={`ty-${y}`} x={mapX(0) - 8} y={mapY(y) + 3} fill="#94a3b8" fontSize="10" textAnchor="end">
                {y}
              </text>
            ))}

            {/* Residual Error Lines */}
            {points.map((pt, i) => {
              const predY = weight * pt.x + bias;
              return (
                <line
                  key={`res-${i}`}
                  x1={mapX(pt.x)}
                  y1={mapY(pt.y)}
                  x2={mapX(pt.x)}
                  y2={mapY(predY)}
                  stroke="#ef4444"
                  strokeWidth="1.5"
                  strokeDasharray="2 2"
                  opacity="0.7"
                />
              );
            })}

            {/* Fitted Regression Line */}
            <line
              x1={mapX(0)}
              y1={mapY(lineY0)}
              x2={mapX(10)}
              y2={mapY(lineY10)}
              stroke="#3b82f6"
              strokeWidth="3"
              strokeLinecap="round"
            />

            {/* Data Points */}
            {points.map((pt, i) => (
              <circle
                key={`pt-${i}`}
                cx={mapX(pt.x)}
                cy={mapY(pt.y)}
                r="5"
                fill="#10b981"
                stroke="#064e3b"
                strokeWidth="1.5"
                className="transition-all hover:scale-125"
              />
            ))}
          </svg>
        </div>
      </div>

      {/* Execution Logs */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs text-slate-300">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-800 text-slate-400 font-semibold mb-2">
          <Play className="w-3.5 h-3.5 text-blue-400" />
          <span>KJSIT Virtual Lab Execution Trace & Cost Convergence</span>
        </div>
        <div className="space-y-1 max-h-32 overflow-y-auto">
          {logs.map((log, i) => (
            <div key={i} className="flex items-start gap-2">
              <span className="text-blue-500">&gt;</span>
              <span className={i === 0 ? 'text-emerald-300 font-semibold' : 'text-slate-400'}>{log}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
