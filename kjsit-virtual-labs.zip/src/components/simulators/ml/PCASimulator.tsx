import React, { useState } from 'react';
import { RotateCcw, TrendingUp, Layers, CheckCircle2 } from 'lucide-react';

export const PCASimulator: React.FC = () => {
  const [projectTo1D, setProjectTo1D] = useState<boolean>(false);

  // 2D Correlated Cloud centered at origin (0, 0)
  const rawPoints = [
    { x: -3.2, y: -2.1 },
    { x: -2.5, y: -1.8 },
    { x: -1.8, y: -0.9 },
    { x: -0.9, y: -1.1 },
    { x: 0.1, y: 0.2 },
    { x: 0.8, y: 0.6 },
    { x: 1.5, y: 1.2 },
    { x: 2.3, y: 1.9 },
    { x: 3.1, y: 2.6 }
  ];

  // Principal component unit vectors: PC1 ~ (0.83, 0.55), PC2 ~ (-0.55, 0.83)
  const pc1 = { x: 0.832, y: 0.555 };
  const pc2 = { x: -0.555, y: 0.832 };

  // Map 2D coordinate space [-5, 5] x [-5, 5] -> SVG [40, 460] x [260, 20]
  const mapX = (x: number) => 40 + ((x + 5) / 10) * 420;
  const mapY = (y: number) => 260 - ((y + 5) / 10) * 230;

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-wrap gap-4 items-center justify-between">
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setProjectTo1D(!projectTo1D)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm ${
              projectTo1D ? 'bg-purple-600 hover:bg-purple-700 text-white' : 'bg-blue-600 hover:bg-blue-700 text-white'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>{projectTo1D ? 'Show 2D Space' : 'Project to 1D Principal Subspace'}</span>
          </button>
        </div>

        <button
          onClick={() => setProjectTo1D(false)}
          className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors border border-slate-700"
          title="Reset"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">PC1 Explained Variance</span>
          <span className="text-xl font-bold font-mono text-emerald-400">92.4%</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">PC2 Explained Variance</span>
          <span className="text-xl font-bold font-mono text-blue-400">7.6%</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Dimension Reduction</span>
          <span className="text-xl font-bold font-mono text-purple-400">2D → 1D</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Information Retained</span>
          <span className="text-xl font-bold font-mono text-white">92.4%</span>
        </div>
      </div>

      {/* 2D Canvas */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-inner">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-400">
            PCA Eigenvector Orthogonal Subspace Projection
          </span>
          <div className="flex items-center gap-3 text-xs font-mono">
            <div className="flex items-center gap-1 text-emerald-400">
              <span className="w-4 h-0.5 bg-emerald-500 inline-block"></span>
              <span>PC1 Vector (λ₁ = 5.82)</span>
            </div>
            <div className="flex items-center gap-1 text-blue-400">
              <span className="w-4 h-0.5 bg-blue-500 inline-block"></span>
              <span>PC2 Vector (λ₂ = 0.48)</span>
            </div>
          </div>
        </div>

        <div className="flex justify-center">
          <svg viewBox="0 0 500 290" className="w-full max-w-[580px] bg-slate-950 rounded-xl border border-slate-800">
            {/* Grid */}
            {[-4, -2, 0, 2, 4].map((x) => (
              <line key={`gx-${x}`} x1={mapX(x)} y1={mapY(-5)} x2={mapX(x)} y2={mapY(5)} stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />
            ))}
            {[-4, -2, 0, 2, 4].map((y) => (
              <line key={`gy-${y}`} x1={mapX(-5)} y1={mapY(y)} x2={mapX(5)} y2={mapY(y)} stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />
            ))}

            {/* Axes */}
            <line x1={mapX(-5)} y1={mapY(0)} x2={mapX(5)} y2={mapY(0)} stroke="#64748b" strokeWidth="2" />
            <line x1={mapX(0)} y1={mapY(-5)} x2={mapX(0)} y2={mapY(5)} stroke="#64748b" strokeWidth="2" />

            {/* PC1 Axis Line */}
            <line
              x1={mapX(-5 * pc1.x)}
              y1={mapY(-5 * pc1.y)}
              x2={mapX(5 * pc1.x)}
              y2={mapY(5 * pc1.y)}
              stroke="#10b981"
              strokeWidth="2.5"
            />

            {/* PC2 Axis Line */}
            <line
              x1={mapX(-3 * pc2.x)}
              y1={mapY(-3 * pc2.y)}
              x2={mapX(3 * pc2.x)}
              y2={mapY(3 * pc2.y)}
              stroke="#3b82f6"
              strokeWidth="1.5"
              strokeDasharray="4 2"
            />

            {/* Projection Lines & Points */}
            {rawPoints.map((pt, i) => {
              // Dot product with PC1
              const scalarProj = pt.x * pc1.x + pt.y * pc1.y;
              const projPoint = { x: scalarProj * pc1.x, y: scalarProj * pc1.y };

              return (
                <g key={`proj-${i}`}>
                  {/* Drop line from original to projection */}
                  <line
                    x1={mapX(pt.x)}
                    y1={mapY(pt.y)}
                    x2={mapX(projPoint.x)}
                    y2={mapY(projPoint.y)}
                    stroke="#a855f7"
                    strokeWidth="1.5"
                    strokeDasharray="2 2"
                    opacity={projectTo1D ? '0.8' : '0.4'}
                  />

                  {/* Projected Point on 1D Subspace */}
                  <circle
                    cx={mapX(projPoint.x)}
                    cy={mapY(projPoint.y)}
                    r="5"
                    fill="#10b981"
                    stroke="#064e3b"
                    strokeWidth="1.5"
                  />

                  {/* Original 2D point (if not hidden in 1D view) */}
                  {!projectTo1D && (
                    <circle
                      cx={mapX(pt.x)}
                      cy={mapY(pt.y)}
                      r="5.5"
                      fill="#94a3b8"
                      stroke="#0f172a"
                      strokeWidth="1.5"
                    />
                  )}
                </g>
              );
            })}
          </svg>
        </div>
      </div>
    </div>
  );
};
