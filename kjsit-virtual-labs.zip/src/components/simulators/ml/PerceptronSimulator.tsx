import React, { useState } from 'react';
import { Play, RotateCcw, Activity, Zap } from 'lucide-react';

interface GateSample {
  x1: number;
  x2: number;
  label: 0 | 1;
}

export const PerceptronSimulator: React.FC = () => {
  const [gate, setGate] = useState<'AND' | 'OR' | 'NAND' | 'XOR'>('AND');
  const [w1, setW1] = useState<number>(0.0);
  const [w2, setW2] = useState<number>(0.0);
  const [bias, setBias] = useState<number>(0.0);
  const [learningRate, setLearningRate] = useState<number>(0.1);
  const [epoch, setEpoch] = useState<number>(0);
  const [logs, setLogs] = useState<string[]>([
    'KJSIT Virtual Lab initialized: Single Layer Perceptron (Rosenblatt 1958).',
    'Activation Function: Unit Step Threshold function f(z) = 1 if z ≥ 0 else 0.'
  ]);

  const getDataset = (): GateSample[] => {
    if (gate === 'AND') {
      return [
        { x1: 0, x2: 0, label: 0 },
        { x1: 0, x2: 1, label: 0 },
        { x1: 1, x2: 0, label: 0 },
        { x1: 1, x2: 1, label: 1 }
      ];
    } else if (gate === 'OR') {
      return [
        { x1: 0, x2: 0, label: 0 },
        { x1: 0, x2: 1, label: 1 },
        { x1: 1, x2: 0, label: 1 },
        { x1: 1, x2: 1, label: 1 }
      ];
    } else if (gate === 'NAND') {
      return [
        { x1: 0, x2: 0, label: 1 },
        { x1: 0, x2: 1, label: 1 },
        { x1: 1, x2: 0, label: 1 },
        { x1: 1, x2: 1, label: 0 }
      ];
    } else {
      // XOR (Non-linearly separable)
      return [
        { x1: 0, x2: 0, label: 0 },
        { x1: 0, x2: 1, label: 1 },
        { x1: 1, x2: 0, label: 1 },
        { x1: 1, x2: 1, label: 0 }
      ];
    }
  };

  const dataset = getDataset();

  const addLog = (msg: string) => {
    setLogs((prev) => [msg, ...prev.slice(0, 6)]);
  };

  const stepEpoch = () => {
    let currentW1 = w1;
    let currentW2 = w2;
    let currentBias = bias;
    let errors = 0;

    dataset.forEach((sample) => {
      const z = currentW1 * sample.x1 + currentW2 * sample.x2 + currentBias;
      const yHat = z >= 0 ? 1 : 0;
      const error = sample.label - yHat;

      if (error !== 0) {
        errors++;
        currentW1 += learningRate * error * sample.x1;
        currentW2 += learningRate * error * sample.x2;
        currentBias += learningRate * error;
      }
    });

    setW1(parseFloat(currentW1.toFixed(3)));
    setW2(parseFloat(currentW2.toFixed(3)));
    setBias(parseFloat(currentBias.toFixed(3)));
    setEpoch((prev) => prev + 1);

    if (errors === 0) {
      addLog(`Epoch ${epoch + 1}: Linearly separated! Zero classification errors.`);
    } else {
      addLog(`Epoch ${epoch + 1}: ${errors} misclassifications updated. w₁=${currentW1.toFixed(2)}, w₂=${currentW2.toFixed(2)}, b=${currentBias.toFixed(2)}`);
    }
  };

  const handleReset = () => {
    setW1(0.0);
    setW2(0.0);
    setBias(0.0);
    setEpoch(0);
    setLogs(['Perceptron weights reset to zeros.']);
  };

  // Map 2D space [-0.5, 1.5] x [-0.5, 1.5] -> SVG [40, 460] x [260, 20]
  const mapX = (x: number) => 40 + ((x + 0.5) / 2.0) * 420;
  const mapY = (y: number) => 260 - ((y + 0.5) / 2.0) * 230;

  // Boundary line: w1 x1 + w2 x2 + b = 0 => x2 = (-b - w1 x1) / w2
  const calcBoundaryY = (x1: number) => {
    if (Math.abs(w2) < 1e-4) return 0.5;
    return (-bias - w1 * x1) / w2;
  };

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-wrap gap-4 items-center justify-between">
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={stepEpoch}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Step Single Epoch</span>
          </button>

          <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-400 font-mono">Logic Gate:</span>
            <select
              value={gate}
              onChange={(e) => {
                setGate(e.target.value as any);
                handleReset();
              }}
              className="bg-slate-950 text-white text-xs px-2 py-0.5 rounded border border-slate-700 font-mono font-bold focus:outline-none"
            >
              <option value="AND">AND (Linearly Separable)</option>
              <option value="OR">OR (Linearly Separable)</option>
              <option value="NAND">NAND (Linearly Separable)</option>
              <option value="XOR">XOR (Minsky-Papert 1969 Proof)</option>
            </select>
          </div>
        </div>

        <button
          onClick={handleReset}
          className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors border border-slate-700"
          title="Reset"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Epochs</span>
          <span className="text-xl font-bold font-mono text-white">{epoch}</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Weight w₁</span>
          <span className="text-xl font-bold font-mono text-blue-400">{w1.toFixed(3)}</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Weight w₂</span>
          <span className="text-xl font-bold font-mono text-purple-400">{w2.toFixed(3)}</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Threshold Bias b</span>
          <span className="text-xl font-bold font-mono text-emerald-400">{bias.toFixed(3)}</span>
        </div>
      </div>

      {/* 2D Canvas & Truth Table */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-inner">
          <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-400">
              Logic Gate Hyperplane Decision Boundary
            </span>
            {gate === 'XOR' && (
              <span className="text-xs text-amber-400 font-mono font-bold animate-pulse">
                ⚠️ XOR is non-linearly separable!
              </span>
            )}
          </div>

          <div className="flex justify-center">
            <svg viewBox="0 0 500 290" className="w-full max-w-[550px] bg-slate-950 rounded-xl border border-slate-800">
              {/* Axes */}
              <line x1={mapX(-0.5)} y1={mapY(0)} x2={mapX(1.5)} y2={mapY(0)} stroke="#64748b" strokeWidth="2" />
              <line x1={mapX(0)} y1={mapY(-0.5)} x2={mapX(0)} y2={mapY(1.5)} stroke="#64748b" strokeWidth="2" />

              {/* Ticks */}
              {[0, 1].map((val) => (
                <g key={`val-${val}`}>
                  <text x={mapX(val)} y={mapY(0) + 16} fill="#94a3b8" fontSize="11" textAnchor="middle">{val}</text>
                  <text x={mapX(0) - 10} y={mapY(val) + 4} fill="#94a3b8" fontSize="11" textAnchor="end">{val}</text>
                </g>
              ))}

              {/* Separating Hyperplane */}
              {(w1 !== 0 || w2 !== 0) && (
                <line
                  x1={mapX(-0.5)}
                  y1={mapY(calcBoundaryY(-0.5))}
                  x2={mapX(1.5)}
                  y2={mapY(calcBoundaryY(1.5))}
                  stroke="#3b82f6"
                  strokeWidth="3"
                />
              )}

              {/* Data points */}
              {dataset.map((pt, i) => (
                <g key={`pt-${i}`}>
                  <circle
                    cx={mapX(pt.x1)}
                    cy={mapY(pt.x2)}
                    r="9"
                    fill={pt.label === 1 ? '#10b981' : '#ef4444'}
                    stroke="#ffffff"
                    strokeWidth="2"
                  />
                  <text
                    x={mapX(pt.x1)}
                    y={mapY(pt.x2) + 4}
                    fill="#ffffff"
                    fontSize="10"
                    fontWeight="bold"
                    textAnchor="middle"
                  >
                    {pt.label}
                  </text>
                </g>
              ))}
            </svg>
          </div>
        </div>

        {/* Truth Table Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-400 block mb-3 font-mono">
            {gate} Truth Table & Activation
          </span>
          <table className="w-full text-xs font-mono text-slate-300">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="p-1.5 text-left">x₁</th>
                <th className="p-1.5 text-left">x₂</th>
                <th className="p-1.5 text-left">Target</th>
                <th className="p-1.5 text-left">ŷ</th>
              </tr>
            </thead>
            <tbody>
              {dataset.map((row, idx) => {
                const z = w1 * row.x1 + w2 * row.x2 + bias;
                const pred = z >= 0 ? 1 : 0;
                const isCorrect = pred === row.label;
                return (
                  <tr key={idx} className="border-b border-slate-800/50">
                    <td className="p-1.5">{row.x1}</td>
                    <td className="p-1.5">{row.x2}</td>
                    <td className="p-1.5 font-bold text-white">{row.label}</td>
                    <td className={`p-1.5 font-bold ${isCorrect ? 'text-emerald-400' : 'text-red-400'}`}>
                      {pred} {isCorrect ? '✓' : '✗'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Execution Logs */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs text-slate-300">
        <div className="space-y-1 max-h-32 overflow-y-auto">
          {logs.map((log, i) => (
            <div key={i} className="flex items-start gap-2">
              <span className="text-blue-500">&gt;</span>
              <span className={i === 0 ? 'text-emerald-300 font-semibold' : 'text-slate-400'}>{log}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
