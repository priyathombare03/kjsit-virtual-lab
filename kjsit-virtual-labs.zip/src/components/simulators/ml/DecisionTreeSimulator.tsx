import React, { useState } from 'react';
import { GitBranch, RotateCcw, Award, CheckCircle2, Split } from 'lucide-react';

interface WeatherSample {
  id: number;
  outlook: 'Sunny' | 'Overcast' | 'Rain';
  humidity: 'High' | 'Normal';
  wind: 'Weak' | 'Strong';
  play: 'Yes' | 'No';
}

export const DecisionTreeSimulator: React.FC = () => {
  const dataset: WeatherSample[] = [
    { id: 1, outlook: 'Sunny', humidity: 'High', wind: 'Weak', play: 'No' },
    { id: 2, outlook: 'Sunny', humidity: 'High', wind: 'Strong', play: 'No' },
    { id: 3, outlook: 'Overcast', humidity: 'High', wind: 'Weak', play: 'Yes' },
    { id: 4, outlook: 'Rain', humidity: 'High', wind: 'Weak', play: 'Yes' },
    { id: 5, outlook: 'Rain', humidity: 'Normal', wind: 'Weak', play: 'Yes' },
    { id: 6, outlook: 'Rain', humidity: 'Normal', wind: 'Strong', play: 'No' },
    { id: 7, outlook: 'Overcast', humidity: 'Normal', wind: 'Strong', play: 'Yes' },
    { id: 8, outlook: 'Sunny', humidity: 'Normal', wind: 'Weak', play: 'Yes' }
  ];

  const [selectedFeature, setSelectedFeature] = useState<'outlook' | 'humidity' | 'wind'>('outlook');
  const [maxDepth, setMaxDepth] = useState<number>(2);
  const [logs, setLogs] = useState<string[]>([
    'KJSIT Virtual Lab initialized: Decision Tree Classifier (ID3 / CART).',
    'Root Entropy: H(S) = - (5/8 log₂ 5/8 + 3/8 log₂ 3/8) = 0.954 bits.'
  ]);

  const addLog = (msg: string) => {
    setLogs((prev) => [msg, ...prev.slice(0, 6)]);
  };

  const handleFeatureSelect = (feat: 'outlook' | 'humidity' | 'wind') => {
    setSelectedFeature(feat);
    if (feat === 'outlook') {
      addLog('Evaluated Outlook: Subsets {Sunny: 1Y/2N, Overcast: 2Y/0N, Rain: 2Y/1N} -> Info Gain = 0.347 bits.');
    } else if (feat === 'humidity') {
      addLog('Evaluated Humidity: Subsets {High: 2Y/2N, Normal: 3Y/1N} -> Info Gain = 0.138 bits.');
    } else {
      addLog('Evaluated Wind: Subsets {Weak: 4Y/1N, Strong: 1Y/2N} -> Info Gain = 0.049 bits.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Controls */}
      <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-wrap gap-4 items-center justify-between">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-400 font-mono">Split Feature:</span>
            <select
              value={selectedFeature}
              onChange={(e) => handleFeatureSelect(e.target.value as any)}
              className="bg-slate-950 text-white text-xs px-2 py-0.5 rounded border border-slate-700 font-mono font-bold focus:outline-none"
            >
              <option value="outlook">Outlook (Max Gain = 0.347)</option>
              <option value="humidity">Humidity (Gain = 0.138)</option>
              <option value="wind">Wind (Gain = 0.049)</option>
            </select>
          </div>

          <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-xs text-slate-400 font-mono">Max Depth:</span>
            <select
              value={maxDepth}
              onChange={(e) => setMaxDepth(parseInt(e.target.value, 10))}
              className="bg-slate-950 text-white text-xs px-2 py-0.5 rounded border border-slate-700 font-mono"
            >
              <option value="1">Depth 1 (Decision Stump)</option>
              <option value="2">Depth 2 (Standard)</option>
              <option value="3">Depth 3 (Full Tree)</option>
            </select>
          </div>
        </div>

        <button
          onClick={() => {
            setSelectedFeature('outlook');
            setMaxDepth(2);
            setLogs(['Reset to optimal Root Split (Outlook).']);
          }}
          className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors border border-slate-700"
          title="Reset"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Interactive Tree Structure Visualization */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-inner text-white">
        <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-400">
            Hierarchical Decision Tree Hierarchy
          </span>
          <span className="text-xs text-emerald-400 font-mono">
            Best Root Attribute: Outlook (Shannon IG: 0.347 bits)
          </span>
        </div>

        {/* Tree Flow Visualizer */}
        <div className="py-4 flex flex-col items-center">
          {/* Root Node */}
          <div className="px-5 py-3 bg-blue-950 border-2 border-blue-500 rounded-xl text-center shadow-lg">
            <span className="text-[10px] text-blue-400 uppercase font-mono block">Root Node (Depth 0)</span>
            <span className="text-sm font-bold font-mono text-white">Split: {selectedFeature.toUpperCase()}?</span>
            <span className="text-[11px] text-slate-400 block font-mono mt-0.5">Total: [5 Yes / 3 No] (Entropy: 0.954)</span>
          </div>

          {/* Connectors */}
          <div className="w-full max-w-[500px] grid grid-cols-3 gap-2 mt-4 text-center">
            {/* Branch 1 */}
            <div className="flex flex-col items-center">
              <div className="w-0.5 h-6 bg-blue-500"></div>
              <span className="px-2 py-0.5 bg-slate-800 text-[10px] font-mono rounded text-slate-300 mb-2">
                {selectedFeature === 'outlook' ? 'Sunny' : selectedFeature === 'humidity' ? 'High' : 'Weak'}
              </span>
              <div className="p-3 bg-slate-800 border border-slate-700 rounded-lg text-center w-full">
                <span className="text-[10px] text-slate-400 block">
                  {selectedFeature === 'outlook' ? '[1 Yes / 2 No]' : '[2 Yes / 2 No]'}
                </span>
                {maxDepth >= 2 && selectedFeature === 'outlook' ? (
                  <div className="mt-2 pt-2 border-t border-slate-700">
                    <span className="text-[10px] text-purple-400 font-bold block">Split: Humidity?</span>
                    <div className="text-[9px] text-emerald-400 mt-1">Normal → Yes (1)</div>
                    <div className="text-[9px] text-red-400">High → No (2)</div>
                  </div>
                ) : (
                  <span className="text-xs font-bold text-red-400 mt-1 block">Leaf: NO</span>
                )}
              </div>
            </div>

            {/* Branch 2 */}
            <div className="flex flex-col items-center">
              <div className="w-0.5 h-6 bg-blue-500"></div>
              <span className="px-2 py-0.5 bg-slate-800 text-[10px] font-mono rounded text-slate-300 mb-2">
                {selectedFeature === 'outlook' ? 'Overcast' : selectedFeature === 'humidity' ? 'Normal' : 'Strong'}
              </span>
              <div className="p-3 bg-emerald-950/80 border border-emerald-700 rounded-lg text-center w-full">
                <span className="text-[10px] text-emerald-400 block">
                  {selectedFeature === 'outlook' ? '[2 Yes / 0 No]' : '[3 Yes / 1 No]'}
                </span>
                <span className="text-xs font-bold text-emerald-300 mt-1 block">Leaf: YES (Pure)</span>
                <span className="text-[9px] text-slate-400 font-mono">Entropy = 0.0</span>
              </div>
            </div>

            {/* Branch 3 */}
            <div className="flex flex-col items-center">
              <div className="w-0.5 h-6 bg-blue-500"></div>
              <span className="px-2 py-0.5 bg-slate-800 text-[10px] font-mono rounded text-slate-300 mb-2">
                {selectedFeature === 'outlook' ? 'Rain' : 'Other'}
              </span>
              <div className="p-3 bg-slate-800 border border-slate-700 rounded-lg text-center w-full">
                <span className="text-[10px] text-slate-400 block">
                  {selectedFeature === 'outlook' ? '[2 Yes / 1 No]' : '[0 Yes / 0 No]'}
                </span>
                {maxDepth >= 2 && selectedFeature === 'outlook' ? (
                  <div className="mt-2 pt-2 border-t border-slate-700">
                    <span className="text-[10px] text-purple-400 font-bold block">Split: Wind?</span>
                    <div className="text-[9px] text-emerald-400 mt-1">Weak → Yes (2)</div>
                    <div className="text-[9px] text-red-400">Strong → No (1)</div>
                  </div>
                ) : (
                  <span className="text-xs font-bold text-emerald-400 mt-1 block">Leaf: YES</span>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Dataset Table & Logs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 overflow-x-auto">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-400 block mb-2 font-mono">
            Training Dataset (Weather / Play Tennis Subset)
          </span>
          <table className="w-full text-[11px] font-mono text-slate-300 border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-left">
                <th className="p-1.5">ID</th>
                <th className="p-1.5">Outlook</th>
                <th className="p-1.5">Humidity</th>
                <th className="p-1.5">Wind</th>
                <th className="p-1.5">Play Tennis</th>
              </tr>
            </thead>
            <tbody>
              {dataset.map((row) => (
                <tr key={row.id} className="border-b border-slate-800/50 hover:bg-slate-800/30">
                  <td className="p-1.5 text-slate-500">#{row.id}</td>
                  <td className="p-1.5">{row.outlook}</td>
                  <td className="p-1.5">{row.humidity}</td>
                  <td className="p-1.5">{row.wind}</td>
                  <td className={`p-1.5 font-bold ${row.play === 'Yes' ? 'text-emerald-400' : 'text-red-400'}`}>
                    {row.play}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs text-slate-300">
          <span className="text-xs font-bold uppercase tracking-wider text-purple-400 block mb-2">
            KJSIT Virtual Lab Information Theory Log
          </span>
          <div className="space-y-1 max-h-36 overflow-y-auto">
            {logs.map((log, i) => (
              <div key={i} className="flex items-start gap-2">
                <span className="text-blue-500">&gt;</span>
                <span className={i === 0 ? 'text-emerald-300 font-semibold' : 'text-slate-400'}>{log}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
