import React, { useState } from 'react';
import { Network, Play, RotateCcw, SkipForward, CheckCircle2 } from 'lucide-react';
import { VisuAlgoCodePanel } from './common/VisuAlgoCodePanel';
import { ALGORITHM_CODES } from './common/algorithmCodes';

interface Edge {
  from: number;
  to: number;
  weight: number;
}

interface DijkstraProps {
  onSimulationComplete?: () => void;
}

export const DijkstraSimulator: React.FC<DijkstraProps> = ({ onSimulationComplete }) => {
  const [source, setSource] = useState<number>(0);
  const [step, setStep] = useState<number>(0);

  const nodes = [
    { id: 0, label: 'A (0)', x: 60, y: 150 },
    { id: 1, label: 'B (1)', x: 180, y: 60 },
    { id: 2, label: 'C (2)', x: 180, y: 240 },
    { id: 3, label: 'D (3)', x: 300, y: 60 },
    { id: 4, label: 'E (4)', x: 300, y: 240 },
  ];

  const edges: Edge[] = [
    { from: 0, to: 1, weight: 10 },
    { from: 0, to: 2, weight: 3 },
    { from: 1, to: 2, weight: 1 },
    { from: 1, to: 3, weight: 2 },
    { from: 2, to: 1, weight: 4 },
    { from: 2, to: 3, weight: 8 },
    { from: 2, to: 4, weight: 2 },
    { from: 3, to: 4, weight: 7 },
    { from: 4, to: 3, weight: 9 },
  ];

  // Precomputed execution steps for source 0 with VisuAlgo line pointers
  const executionSteps = [
    {
      visited: [],
      dist: [0, Infinity, Infinity, Infinity, Infinity],
      current: -1,
      activeCodeLine: 0,
      desc: 'Initialize: dist[source=0] = 0, dist[v] = ∞ for all other vertices.'
    },
    {
      visited: [0],
      dist: [0, 10, 3, Infinity, Infinity],
      current: 0,
      activeCodeLine: 6,
      desc: 'Extracted min vertex 0 (dist=0). Relaxed edges: dist[1] = 10, dist[2] = 3.'
    },
    {
      visited: [0, 2],
      dist: [0, 7, 3, 11, 5],
      current: 2,
      activeCodeLine: 6,
      desc: 'Extracted min vertex 2 (dist=3). Relaxed edges: dist[1] = 3+4 = 7 (improved!), dist[3] = 3+8 = 11, dist[4] = 3+2 = 5.'
    },
    {
      visited: [0, 2, 4],
      dist: [0, 7, 3, 11, 5],
      current: 4,
      activeCodeLine: 5,
      desc: 'Extracted min vertex 4 (dist=5). Edge (4->3: wt=9) gives 5+9=14 > 11 (no update).'
    },
    {
      visited: [0, 2, 4, 1],
      dist: [0, 7, 3, 9, 5],
      current: 1,
      activeCodeLine: 6,
      desc: 'Extracted min vertex 1 (dist=7). Relaxed edge (1->3: wt=2) -> dist[3] = 7+2 = 9 (improved!).'
    },
    {
      visited: [0, 2, 4, 1, 3],
      dist: [0, 7, 3, 9, 5],
      current: 3,
      activeCodeLine: 2,
      desc: 'Extracted min vertex 3 (dist=9). All vertices visited! Final Single-Source Shortest Paths discovered.'
    }
  ];

  const currentStepData = executionSteps[Math.min(step, executionSteps.length - 1)];

  // Trigger simulation completion when reached final step
  React.useEffect(() => {
    if (step >= executionSteps.length - 1) {
      onSimulationComplete?.();
    }
  }, [step, executionSteps.length, onSimulationComplete]);

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100 mb-6">
        <div>
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Network className="w-5 h-5 text-cyan-600" />
            Dijkstra Single-Source Shortest Path Simulator
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Greedy Edge Relaxation & Shortest Path Computation
          </p>
        </div>
        <span className="text-xs font-semibold px-2.5 py-1 bg-cyan-50 text-cyan-700 rounded-md border border-cyan-200">
          Step {step + 1} of {executionSteps.length}
        </span>
      </div>

      {/* Main Grid: Graph + Table on Left, VisuAlgo Code on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-6">
        <div className="lg:col-span-7 space-y-4">
          {/* Graph Visualizer Canvas */}
          <div className="bg-slate-950 rounded-xl p-4 flex flex-col items-center justify-center min-h-[300px] relative">
            <svg width="360" height="300" className="overflow-visible">
              <defs>
                <marker
                  id="arrowhead"
                  markerWidth="8"
                  markerHeight="6"
                  refX="22"
                  refY="3"
                  orient="auto"
                >
                  <polygon points="0 0, 8 3, 0 6" fill="#94a3b8" />
                </marker>
              </defs>

              {/* Edges */}
              {edges.map((e, idx) => {
                const u = nodes[e.from];
                const v = nodes[e.to];
                const isRelaxing = currentStepData.current === e.from;

                return (
                  <g key={idx}>
                    <line
                      x1={u.x}
                      y1={u.y}
                      x2={v.x}
                      y2={v.y}
                      stroke={isRelaxing ? '#38bdf8' : '#475569'}
                      strokeWidth={isRelaxing ? 3 : 1.5}
                      markerEnd="url(#arrowhead)"
                    />
                    {/* Weight label */}
                    <rect
                      x={(u.x + v.x) / 2 - 8}
                      y={(u.y + v.y) / 2 - 8}
                      width="16"
                      height="16"
                      rx="4"
                      fill="#0f172a"
                    />
                    <text
                      x={(u.x + v.x) / 2}
                      y={(u.y + v.y) / 2 + 4}
                      fill="#38bdf8"
                      fontSize="10"
                      fontWeight="bold"
                      textAnchor="middle"
                    >
                      {e.weight}
                    </text>
                  </g>
                );
              })}

              {/* Nodes */}
              {nodes.map((n) => {
                const isVisited = currentStepData.visited.includes(n.id);
                const isCurrent = currentStepData.current === n.id;
                let fill = '#1e293b';
                if (isCurrent) fill = '#f59e0b';
                else if (isVisited) fill = '#10b981';

                return (
                  <g key={n.id}>
                    <circle
                      cx={n.x}
                      cy={n.y}
                      r="20"
                      fill={fill}
                      stroke="#e2e8f0"
                      strokeWidth="2"
                    />
                    <text
                      x={n.x}
                      y={n.y + 4}
                      fill="#ffffff"
                      fontSize="11"
                      fontWeight="bold"
                      textAnchor="middle"
                    >
                      {n.label}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Distance Table */}
          <div className="border border-slate-200 rounded-xl overflow-hidden shadow-sm">
            <div className="bg-slate-100 px-4 py-2 border-b border-slate-200 font-semibold text-xs text-slate-800">
              Shortest Distance Array dist[]
            </div>
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-semibold border-b border-slate-100">
                <tr>
                  <th className="py-2 px-3">Vertex</th>
                  <th className="py-2 px-3">Shortest Distance</th>
                  <th className="py-2 px-3">Visited Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {nodes.map((node) => {
                  const d = currentStepData.dist[node.id];
                  const isVis = currentStepData.visited.includes(node.id);
                  return (
                    <tr key={node.id} className={isVis ? 'bg-emerald-50/40' : ''}>
                      <td className="py-2 px-3 font-bold text-slate-800">{node.label}</td>
                      <td className="py-2 px-3 font-mono font-bold text-blue-700">
                        {d === Infinity ? '∞' : d}
                      </td>
                      <td className="py-2 px-3">
                        {isVis ? (
                          <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded font-semibold text-[10px]">
                            Visited
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded text-[10px]">
                            Unvisited
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* VisuAlgo Code Panel */}
        <div className="lg:col-span-5">
          <VisuAlgoCodePanel
            title="Dijkstra's Algorithm"
            explanation={currentStepData.desc}
            codeLines={ALGORITHM_CODES.dijkstra.lines}
            activeLineIndex={currentStepData.activeCodeLine}
            stepInfo={{ current: step + 1, total: executionSteps.length }}
          />
        </div>
      </div>

      {/* Description */}
      <div className="bg-cyan-50 border border-cyan-200 rounded-lg p-3.5 mb-6 text-sm text-slate-800 flex items-start gap-3">
        <div className="w-2 h-2 rounded-full bg-cyan-600 mt-2 shrink-0"></div>
        <div>
          <span className="font-semibold text-cyan-900 block text-xs uppercase tracking-wide mb-0.5">
            Step Execution Log:
          </span>
          <p className="text-slate-700 text-sm leading-relaxed">{currentStepData.desc}</p>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setStep(0)}
          className="p-2 border border-slate-300 rounded-lg hover:bg-slate-100 text-slate-700 text-xs font-medium flex items-center gap-1.5 cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" /> Reset
        </button>
        <button
          onClick={() => setStep(prev => Math.min(prev + 1, executionSteps.length - 1))}
          disabled={step >= executionSteps.length - 1}
          className="px-4 py-2 bg-cyan-700 hover:bg-cyan-800 disabled:opacity-40 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
        >
          <SkipForward className="w-4 h-4" /> Next Step
        </button>
      </div>
    </div>
  );
};
