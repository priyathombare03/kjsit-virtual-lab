import React, { useState } from 'react';
import { Grid, SkipForward, RotateCcw } from 'lucide-react';

const INF = 999;

export const FloydWarshallSimulator: React.FC = () => {
  const [kStep, setKStep] = useState<number>(0);

  const matrices = [
    // Initial Matrix D^(0)
    {
      k: -1,
      name: 'Initial Adjacency Matrix D^(0)',
      desc: 'Direct edge weights without intermediate vertices.',
      matrix: [
        [0, 5, INF, 10],
        [INF, 0, 3, INF],
        [INF, INF, 0, 1],
        [INF, INF, INF, 0]
      ]
    },
    // After k = 0 (Node 0 as intermediate)
    {
      k: 0,
      name: 'Matrix D^(1) [Intermediate k = 0 / Node 0]',
      desc: 'Check if paths via Node 0 improve distances: D[i][0] + D[0][j] vs D[i][j]. No improvements found.',
      matrix: [
        [0, 5, INF, 10],
        [INF, 0, 3, INF],
        [INF, INF, 0, 1],
        [INF, INF, INF, 0]
      ]
    },
    // After k = 1 (Node 1 as intermediate)
    {
      k: 1,
      name: 'Matrix D^(2) [Intermediate k = 1 / Node 1]',
      desc: 'Paths via Node 1: D[0][2] improves from ∞ to D[0][1] + D[1][2] = 5 + 3 = 8!',
      matrix: [
        [0, 5, 8, 10],
        [INF, 0, 3, INF],
        [INF, INF, 0, 1],
        [INF, INF, INF, 0]
      ]
    },
    // After k = 2 (Node 2 as intermediate)
    {
      k: 2,
      name: 'Matrix D^(3) [Intermediate k = 2 / Node 2]',
      desc: 'Paths via Node 2: D[0][3] improves to D[0][2] + D[2][3] = 8 + 1 = 9! D[1][3] improves to D[1][2] + D[2][3] = 3 + 1 = 4!',
      matrix: [
        [0, 5, 8, 9],
        [INF, 0, 3, 4],
        [INF, INF, 0, 1],
        [INF, INF, INF, 0]
      ]
    },
    // After k = 3 (Node 3 as intermediate)
    {
      k: 3,
      name: 'Matrix D^(4) [Final All-Pairs Shortest Distances]',
      desc: 'Paths via Node 3 checked. All intermediate vertices evaluated! Resulting matrix gives all-pairs shortest paths.',
      matrix: [
        [0, 5, 8, 9],
        [INF, 0, 3, 4],
        [INF, INF, 0, 1],
        [INF, INF, INF, 0]
      ]
    }
  ];

  const current = matrices[kStep];

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100 mb-6">
        <div>
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Grid className="w-5 h-5 text-indigo-600" />
            Floyd-Warshall All-Pairs DP Matrix Visualizer
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Step through intermediate vertex iterations k = 0, 1, 2, 3 in Θ(V³) time
          </p>
        </div>
        <span className="text-xs font-semibold px-2.5 py-1 bg-indigo-50 text-indigo-700 rounded-md border border-indigo-200">
          Iteration {kStep + 1} of {matrices.length}
        </span>
      </div>

      {/* Matrix Display */}
      <div className="bg-slate-950 rounded-xl p-6 mb-6 text-white flex flex-col items-center justify-center">
        <div className="text-xs font-mono text-cyan-400 mb-4 font-bold">
          {current.name}
        </div>

        <div className="overflow-x-auto w-full max-w-md">
          <table className="w-full text-center font-mono text-sm border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="p-2 text-left">u \ v</th>
                <th className="p-2">0</th>
                <th className="p-2">1</th>
                <th className="p-2">2</th>
                <th className="p-2">3</th>
              </tr>
            </thead>
            <tbody>
              {current.matrix.map((row, i) => (
                <tr key={i} className="border-b border-slate-800/60">
                  <td className="p-2 text-left text-slate-400 font-bold">{i}</td>
                  {row.map((val, j) => {
                    const isDiag = i === j;
                    const isInf = val === INF;
                    return (
                      <td
                        key={j}
                        className={`p-2.5 rounded transition-colors ${
                          isDiag ? 'text-slate-500' : isInf ? 'text-rose-400' : 'text-emerald-400 font-bold bg-slate-900/60'
                        }`}
                      >
                        {isInf ? '∞' : val}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Description */}
      <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-3.5 mb-6 text-sm text-slate-800 flex items-start gap-3">
        <div className="w-2 h-2 rounded-full bg-indigo-600 mt-2 shrink-0"></div>
        <div>
          <span className="font-semibold text-indigo-900 block text-xs uppercase tracking-wide mb-0.5">
            Recurrence Evaluation:
          </span>
          <p className="text-slate-700 text-sm leading-relaxed">{current.desc}</p>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setKStep(0)}
          className="p-2 border border-slate-300 rounded-lg hover:bg-slate-100 text-slate-700 text-xs font-medium flex items-center gap-1.5"
        >
          <RotateCcw className="w-4 h-4" /> Reset
        </button>
        <button
          onClick={() => setKStep(prev => Math.min(prev + 1, matrices.length - 1))}
          disabled={kStep >= matrices.length - 1}
          className="px-4 py-2 bg-indigo-700 hover:bg-indigo-800 disabled:opacity-40 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5"
        >
          <SkipForward className="w-4 h-4" /> Next Iteration (k = {kStep < matrices.length - 1 ? matrices[kStep + 1].k : 'Done'})
        </button>
      </div>
    </div>
  );
};
