import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, SkipForward, Crown, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface BoardStep {
  board: number[][];
  row: number;
  col: number;
  action: 'try' | 'conflict' | 'place' | 'backtrack' | 'solution_found';
  conflicts?: [number, number][];
  description: string;
}

export const NQueensSimulator: React.FC = () => {
  const [n, setN] = useState<number>(4);
  const [steps, setSteps] = useState<BoardStep[]>([]);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [speed, setSpeed] = useState<number>(1000);
  const [solutionsCount, setSolutionsCount] = useState<number>(0);
  const [mode, setMode] = useState<'simulation' | 'manual'>('simulation');
  const [manualBoard, setManualBoard] = useState<number[][]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize manual board
  useEffect(() => {
    setManualBoard(Array.from({ length: n }, () => Array(n).fill(0)));
  }, [n]);

  // Generate Backtracking Trace
  const generateSteps = (boardSize: number) => {
    const generated: BoardStep[] = [];
    const b = Array.from({ length: boardSize }, () => Array(boardSize).fill(0));
    let totalSolutions = 0;

    const isSafeWithConflicts = (row: number, col: number): { safe: boolean; conflictCells: [number, number][] } => {
      const conflicts: [number, number][] = [];

      // Check column
      for (let i = 0; i < row; i++) {
        if (b[i][col] === 1) conflicts.push([i, col]);
      }
      // Upper left diagonal
      for (let i = row - 1, j = col - 1; i >= 0 && j >= 0; i--, j--) {
        if (b[i][j] === 1) conflicts.push([i, j]);
      }
      // Upper right diagonal
      for (let i = row - 1, j = col + 1; i >= 0 && j < boardSize; i--, j++) {
        if (b[i][j] === 1) conflicts.push([i, j]);
      }

      return { safe: conflicts.length === 0, conflictCells: conflicts };
    };

    const solve = (row: number) => {
      if (row === boardSize) {
        totalSolutions++;
        generated.push({
          board: b.map(r => [...r]),
          row,
          col: -1,
          action: 'solution_found',
          description: `Solution #${totalSolutions} Found! All ${boardSize} queens placed without conflicts.`
        });
        return;
      }

      for (let col = 0; col < boardSize; col++) {
        generated.push({
          board: b.map(r => [...r]),
          row,
          col,
          action: 'try',
          description: `Checking Row ${row}, Column ${col} for conflicts...`
        });

        const { safe, conflictCells } = isSafeWithConflicts(row, col);

        if (safe) {
          b[row][col] = 1;
          generated.push({
            board: b.map(r => [...r]),
            row,
            col,
            action: 'place',
            description: `Safe! Placed Queen at (${row}, ${col}). Proceeding to Row ${row + 1}.`
          });

          solve(row + 1);

          // Backtrack
          b[row][col] = 0;
          generated.push({
            board: b.map(r => [...r]),
            row,
            col,
            action: 'backtrack',
            description: `Backtracking from (${row}, ${col}). Removing queen to test next column.`
          });
        } else {
          generated.push({
            board: b.map(r => [...r]),
            row,
            col,
            action: 'conflict',
            conflicts: conflictCells,
            description: `Conflict detected at (${row}, ${col}) with Queen at (${conflictCells[0][0]}, ${conflictCells[0][1]}).`
          });
        }
      }
    };

    solve(0);
    setSolutionsCount(totalSolutions);
    setSteps(generated);
    setCurrentStepIndex(0);
  };

  useEffect(() => {
    if (mode === 'simulation') {
      generateSteps(n);
    }
  }, [n, mode]);

  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        setCurrentStepIndex(prev => {
          if (prev < steps.length - 1) return prev + 1;
          setIsPlaying(false);
          return prev;
        });
      }, speed);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, steps.length, speed]);

  const currentStep = (steps[currentStepIndex] || {
    board: Array.from({ length: n }, () => Array(n).fill(0)),
    row: 0,
    col: 0,
    action: 'try',
    description: 'Ready'
  }) as BoardStep;
/*
    board: Array.from({ length: n }, () => Array(n).fill(0)),
    row: 0,
    col: 0,
    action: 'try',
    description: 'Ready'
  };*/

  const handleManualCellClick = (r: number, c: number) => {
    if (mode !== 'manual') return;
    const newB = manualBoard.map(rowArr => [...rowArr]);
    newB[r][c] = newB[r][c] === 1 ? 0 : 1;
    setManualBoard(newB);
  };

  // Check manual conflicts
  const getManualPlacedCount = () => {
    let count = 0;
    manualBoard.forEach(row => row.forEach(c => { if (c === 1) count++; }));
    return count;
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100 mb-6">
        <div>
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Crown className="w-5 h-5 text-amber-500" />
            N-Queens Backtracking Chessboard Visualizer
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Depth-first recursive exploration on an N × N chessboard with real-time conflict pruning
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex rounded-lg border border-slate-300 p-0.5 bg-slate-100 text-xs">
            <button
              onClick={() => { setMode('simulation'); setIsPlaying(false); }}
              className={`px-3 py-1 rounded-md font-medium transition-colors ${
                mode === 'simulation' ? 'bg-white shadow text-slate-900' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Auto Simulation
            </button>
            <button
              onClick={() => { setMode('manual'); setIsPlaying(false); }}
              className={`px-3 py-1 rounded-md font-medium transition-colors ${
                mode === 'manual' ? 'bg-white shadow text-slate-900' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Interactive Placement
            </button>
          </div>
        </div>
      </div>

      {/* Board Dimension Selector */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 bg-slate-50 p-3 rounded-lg border border-slate-200">
        <div className="flex items-center gap-3">
          <label className="text-xs font-semibold text-slate-700">Board Size (N):</label>
          <div className="flex gap-1.5">
            {[4, 5, 6, 8].map(size => (
              <button
                key={size}
                onClick={() => { setN(size); setIsPlaying(false); }}
                className={`px-3 py-1 text-xs font-mono font-bold rounded ${
                  n === size
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                }`}
              >
                {size} × {size}
              </button>
            ))}
          </div>
        </div>
        {mode === 'simulation' ? (
          <span className="text-xs text-slate-600 font-medium">
            Step <strong className="text-slate-900">{currentStepIndex + 1}</strong> / {steps.length} | Found {solutionsCount} solutions
          </span>
        ) : (
          <span className="text-xs text-slate-600 font-medium">
            Placed Queens: <strong className="text-amber-600">{getManualPlacedCount()}</strong> / {n}
          </span>
        )}
      </div>

      {/* Chessboard Area */}
      <div className="flex flex-col items-center justify-center p-6 bg-slate-950 rounded-xl mb-6 text-white min-h-[340px]">
        <div
          className="grid gap-1 p-2 bg-slate-900 rounded-lg shadow-2xl border-4 border-slate-800"
          style={{ gridTemplateColumns: `repeat(${n}, minmax(0, 1fr))` }}
        >
          {Array.from({ length: n }, (_, r) =>
            Array.from({ length: n }, (_, c) => {
              const isDark = (r + c) % 2 === 1;
              const hasQueen = mode === 'simulation'
                ? currentStep.board[r]?.[c] === 1
                : manualBoard[r]?.[c] === 1;

              const isTrying = mode === 'simulation' && currentStep.row === r && currentStep.col === c;
              const isConflict = mode === 'simulation' && currentStep.action === 'conflict' && isTrying;
              const isSourceConflict = mode === 'simulation' && currentStep.conflicts?.some(([cr, cc]) => cr === r && cc === c);

              let cellStyle = isDark ? 'bg-slate-800' : 'bg-slate-700';
              if (isConflict) {
                cellStyle = 'bg-rose-700/80 ring-2 ring-rose-500 animate-pulse';
              } else if (isSourceConflict) {
                cellStyle = 'bg-amber-600/80 ring-2 ring-amber-400';
              } else if (isTrying) {
                cellStyle = 'bg-blue-600/70 ring-2 ring-cyan-400';
              }

              return (
                <button
                  key={`${r}-${c}`}
                  onClick={() => handleManualCellClick(r, c)}
                  disabled={mode === 'simulation'}
                  className={`w-12 h-12 sm:w-14 sm:h-14 rounded flex flex-col items-center justify-center relative transition-all duration-200 ${cellStyle} ${
                    mode === 'manual' ? 'hover:ring-2 hover:ring-amber-300 cursor-pointer' : ''
                  }`}
                >
                  {hasQueen && (
                    <Crown className="w-7 h-7 sm:w-8 sm:h-8 text-amber-400 fill-amber-400 drop-shadow-md animate-in zoom-in-50 duration-200" />
                  )}
                  {isConflict && !hasQueen && (
                    <AlertTriangle className="w-5 h-5 text-rose-300 animate-bounce" />
                  )}
                  <span className="absolute bottom-0.5 right-1 text-[8px] text-slate-400/60 font-mono">
                    {r},{c}
                  </span>
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* Description / Instructions */}
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-3.5 mb-6 text-sm text-slate-800 flex items-start gap-3">
        <div className="w-2 h-2 rounded-full bg-amber-500 mt-2 shrink-0"></div>
        <div>
          {mode === 'simulation' ? (
            <>
              <span className="font-semibold text-amber-900 block text-xs uppercase tracking-wide mb-0.5">
                Status: {currentStep.action.toUpperCase()}
              </span>
              <p className="text-slate-700 text-sm leading-relaxed">{currentStep.description}</p>
            </>
          ) : (
            <>
              <span className="font-semibold text-amber-900 block text-xs uppercase tracking-wide mb-0.5">
                Interactive Student Mode
              </span>
              <p className="text-slate-700 text-sm leading-relaxed">
                Click on the chessboard squares to place or remove queens. Try placing {n} queens such that no two attack each other!
              </p>
            </>
          )}
        </div>
      </div>

      {/* Controls */}
      {mode === 'simulation' && (
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setIsPlaying(false);
                setCurrentStepIndex(0);
              }}
              className="p-2 border border-slate-300 rounded-lg hover:bg-slate-100 text-slate-700 text-sm font-medium flex items-center gap-1.5"
            >
              <RotateCcw className="w-4 h-4" /> Reset
            </button>
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className={`px-4 py-2 rounded-lg font-medium text-sm flex items-center gap-2 transition-colors ${
                isPlaying ? 'bg-rose-600 text-white' : 'bg-amber-600 hover:bg-amber-700 text-white'
              }`}
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
              {isPlaying ? 'Pause' : 'Auto Backtrack'}
            </button>
            <button
              onClick={() => {
                setIsPlaying(false);
                setCurrentStepIndex(prev => Math.min(prev + 1, steps.length - 1));
              }}
              disabled={currentStepIndex >= steps.length - 1}
              className="px-3.5 py-2 border border-slate-300 bg-white rounded-lg hover:bg-slate-50 disabled:opacity-40 text-slate-700 text-sm font-medium flex items-center gap-1.5"
            >
              <SkipForward className="w-4 h-4" /> Next
            </button>
          </div>

          <div className="flex items-center gap-3">
            <label className="text-xs font-semibold text-slate-600">Speed:</label>
            <select
              value={speed}
              onChange={(e) => setSpeed(Number(e.target.value))}
              className="text-xs bg-white border border-slate-300 rounded px-2.5 py-1.5 font-medium text-slate-700"
            >
              <option value={1500}>0.75x</option>
              <option value={1000}>1.0x</option>
              <option value={400}>2.5x</option>
            </select>
          </div>
        </div>
      )}
    </div>
  );
};
