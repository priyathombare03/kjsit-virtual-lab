import React, { useState } from 'react';
import { Palette, CheckCircle2, AlertCircle, RotateCcw } from 'lucide-react';

const COLOR_PALETTE = [
  { id: 1, name: 'Crimson Red', hex: '#ef4444', text: 'text-white' },
  { id: 2, name: 'Emerald Green', hex: '#10b981', text: 'text-white' },
  { id: 3, name: 'Royal Blue', hex: '#3b82f6', text: 'text-white' },
  { id: 4, name: 'Amber Gold', hex: '#f59e0b', text: 'text-black' },
];

export const GraphColoringSimulator: React.FC = () => {
  const [maxColors, setMaxColors] = useState<number>(3);
  const [selectedColor, setSelectedColor] = useState<number>(1);
  const [nodeColors, setNodeColors] = useState<Record<number, number>>({
    0: 0, 1: 0, 2: 0, 3: 0, 4: 0
  });

  // Graph Vertices & Coordinates
  const nodes = [
    { id: 0, label: 'A (0)', x: 180, y: 50 },
    { id: 1, label: 'B (1)', x: 80, y: 150 },
    { id: 2, label: 'C (2)', x: 280, y: 150 },
    { id: 3, label: 'D (3)', x: 120, y: 260 },
    { id: 4, label: 'E (4)', x: 240, y: 260 },
  ];

  // Adjacency Edges
  const edges: [number, number][] = [
    [0, 1], [0, 2], [1, 2], [1, 3], [2, 4], [3, 4], [0, 3]
  ];

  // Check conflicts
  const conflicts: [number, number][] = [];
  edges.forEach(([u, v]) => {
    if (nodeColors[u] !== 0 && nodeColors[v] !== 0 && nodeColors[u] === nodeColors[v]) {
      conflicts.push([u, v]);
    }
  });

  const handleNodeClick = (nodeId: number) => {
    setNodeColors(prev => ({
      ...prev,
      [nodeId]: prev[nodeId] === selectedColor ? 0 : selectedColor
    }));
  };

  const handleAutoSolve = () => {
    // Backtracking solver
    const V = 5;
    const adjMatrix: number[][] = Array.from({ length: V }, () => Array(V).fill(0));
    edges.forEach(([u, v]) => {
      adjMatrix[u][v] = 1;
      adjMatrix[v][u] = 1;
    });

    const result: number[] = Array(V).fill(0);

    const isSafe = (v: number, c: number) => {
      for (let i = 0; i < V; i++) {
        if (adjMatrix[v][i] && result[i] === c) return false;
      }
      return true;
    };

    const solve = (v: number): boolean => {
      if (v === V) return true;
      for (let c = 1; c <= maxColors; c++) {
        if (isSafe(v, c)) {
          result[v] = c;
          if (solve(v + 1)) return true;
          result[v] = 0;
        }
      }
      return false;
    };

    if (solve(0)) {
      const newColors: Record<number, number> = {};
      result.forEach((c, idx) => { newColors[idx] = c; });
      setNodeColors(newColors);
    }
  };

  const allColored = Object.values(nodeColors).every((c: number) => Number(c) > 0);
  const isValidValidSolution = allColored && conflicts.length === 0;

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100 mb-6">
        <div>
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Palette className="w-5 h-5 text-rose-600" />
            m-Coloring Problem Interactive Graph Visualizer
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Assign colors to vertices such that no two adjacent vertices share the same color using at most m colors
          </p>
        </div>
        <button
          onClick={handleAutoSolve}
          className="px-3.5 py-1.5 bg-rose-600 text-white text-xs font-semibold rounded-lg hover:bg-rose-700 transition-colors shadow-sm"
        >
          Auto Solve with m = {maxColors}
        </button>
      </div>

      {/* Palette & Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6 bg-slate-50 p-4 rounded-xl border border-slate-200">
        <div>
          <label className="text-xs font-semibold text-slate-700 block mb-1.5">
            Select Active Color to Paint Nodes:
          </label>
          <div className="flex items-center gap-2">
            {COLOR_PALETTE.slice(0, maxColors).map(col => (
              <button
                key={col.id}
                onClick={() => setSelectedColor(col.id)}
                style={{ backgroundColor: col.hex }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-transform ${col.text} ${
                  selectedColor === col.id ? 'ring-2 ring-slate-900 ring-offset-2 scale-105' : 'opacity-80 hover:opacity-100'
                }`}
              >
                Color {col.id}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between md:justify-end gap-3">
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1">
              Max Colors (m): <span className="font-bold text-rose-600">{maxColors}</span>
            </label>
            <div className="flex gap-1">
              {[2, 3, 4].map(num => (
                <button
                  key={num}
                  onClick={() => setMaxColors(num)}
                  className={`px-2.5 py-1 text-xs font-bold rounded ${
                    maxColors === num ? 'bg-slate-900 text-white' : 'bg-white border border-slate-300 text-slate-700'
                  }`}
                >
                  m = {num}
                </button>
              ))}
            </div>
          </div>
          <button
            onClick={() => setNodeColors({ 0: 0, 1: 0, 2: 0, 3: 0, 4: 0 })}
            className="px-3 py-2 border border-slate-300 bg-white rounded-lg text-xs font-medium text-slate-700 hover:bg-slate-100 flex items-center gap-1 mt-3"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Clear
          </button>
        </div>
      </div>

      {/* SVG Interactive Graph Canvas */}
      <div className="bg-slate-950 rounded-xl p-4 mb-6 flex flex-col items-center justify-center relative min-h-[320px]">
        <svg width="360" height="300" className="overflow-visible">
          {/* Edges */}
          {edges.map(([u, v], idx) => {
            const nodeU = nodes[u];
            const nodeV = nodes[v];
            const isConflicted = conflicts.some(([cu, cv]) => (cu === u && cv === v) || (cu === v && cv === u));

            return (
              <line
                key={idx}
                x1={nodeU.x}
                y1={nodeU.y}
                x2={nodeV.x}
                y2={nodeV.y}
                stroke={isConflicted ? '#ef4444' : '#475569'}
                strokeWidth={isConflicted ? 4 : 2}
                strokeDasharray={isConflicted ? '6,3' : undefined}
                className="transition-all duration-300"
              />
            );
          })}

          {/* Nodes */}
          {nodes.map((node) => {
            const colorId = nodeColors[node.id];
            const colorDef = COLOR_PALETTE.find(c => c.id === colorId);
            const fillColor = colorDef ? colorDef.hex : '#1e293b';

            return (
              <g
                key={node.id}
                onClick={() => handleNodeClick(node.id)}
                className="cursor-pointer group"
              >
                <circle
                  cx={node.x}
                  cy={node.y}
                  r="24"
                  fill={fillColor}
                  stroke="#94a3b8"
                  strokeWidth="2"
                  className="transition-transform group-hover:scale-110"
                />
                <text
                  x={node.x}
                  y={node.y + 4}
                  textAnchor="middle"
                  fill="#ffffff"
                  fontSize="12"
                  fontWeight="bold"
                  pointerEvents="none"
                >
                  {node.label}
                </text>
              </g>
            );
          })}
        </svg>
      </div>

      {/* Conflict / Success Banner */}
      {conflicts.length > 0 ? (
        <div className="bg-rose-50 border border-rose-200 rounded-lg p-3.5 text-xs text-rose-900 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>
            <strong>Adjacent Conflict:</strong> Vertices {conflicts.map(([u, v]) => `${nodes[u].label} and ${nodes[v].label}`).join(', ')} share the exact same color!
          </span>
        </div>
      ) : isValidValidSolution ? (
        <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3.5 text-xs text-emerald-900 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>
            <strong>Valid Graph Coloring:</strong> All vertices colored properly without any adjacent edge conflicts!
          </span>
        </div>
      ) : (
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3.5 text-xs text-slate-600">
          Click on any vertex circle above to paint it with the currently selected color palette.
        </div>
      )}
    </div>
  );
};
