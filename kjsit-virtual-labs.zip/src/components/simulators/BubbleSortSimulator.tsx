import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, SkipForward, Sparkles, Code } from 'lucide-react';
import { VisuAlgoCodePanel } from './common/VisuAlgoCodePanel';
import { ALGORITHM_CODES } from './common/algorithmCodes';

interface BubbleStep {
  array: number[];
  leftIdx: number;
  rightIdx: number;
  action: 'init' | 'pass_start' | 'compare' | 'swap' | 'pass_end' | 'completed';
  description: string;
  swappedInPass: boolean;
  sortedFromIdx: number;
  activeCodeLine: number; // index in ALGORITHM_CODES.bubbleSort.lines
}

interface BubbleSortProps {
  onSimulationComplete?: () => void;
}

export const BubbleSortSimulator: React.FC<BubbleSortProps> = ({ onSimulationComplete }) => {
  // Default array matches the VisuAlgo screenshot: 10, 14, 29, 14, 37
  const [initialArray, setInitialArray] = useState<number[]>([10, 14, 29, 14, 37]);
  const [inputStr, setInputStr] = useState<string>('10, 14, 29, 14, 37');
  const [steps, setSteps] = useState<BubbleStep[]>([]);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [speed, setSpeed] = useState<number>(900);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const generateSteps = (arr: number[]) => {
    const generated: BubbleStep[] = [];
    const a = [...arr];
    const n = a.length;

    generated.push({
      array: [...a],
      leftIdx: -1,
      rightIdx: -1,
      action: 'init',
      description: `Initial array with ${n} elements. Preparing Bubble Sort simulation.`,
      swappedInPass: false,
      sortedFromIdx: n,
      activeCodeLine: 0
    });

    let swapped = false;
    let unsortedLimit = n;

    do {
      swapped = false;
      generated.push({
        array: [...a],
        leftIdx: -1,
        rightIdx: -1,
        action: 'pass_start',
        description: `Starting pass: swapped = false. Scanning from index 0 to ${unsortedLimit - 2}.`,
        swappedInPass: false,
        sortedFromIdx: unsortedLimit,
        activeCodeLine: 1
      });

      for (let i = 0; i < unsortedLimit - 1; i++) {
        const leftVal = a[i];
        const rightVal = a[i + 1];

        // Highlight line 3: if leftElement > rightElement
        generated.push({
          array: [...a],
          leftIdx: i,
          rightIdx: i + 1,
          action: 'compare',
          description: `Checking if ${leftVal} (index ${i}) > ${rightVal} (index ${i + 1}) and swap them if that is true; swapped = ${swapped}.`,
          swappedInPass: swapped,
          sortedFromIdx: unsortedLimit,
          activeCodeLine: 3
        });

        if (a[i] > a[i + 1]) {
          const temp = a[i];
          a[i] = a[i + 1];
          a[i + 1] = temp;
          swapped = true;

          // Highlight line 4: swap(leftElement, rightElement)
          generated.push({
            array: [...a],
            leftIdx: i,
            rightIdx: i + 1,
            action: 'swap',
            description: `Swapped ${temp} and ${a[i]} because ${temp} > ${a[i]}; swapped = true.`,
            swappedInPass: true,
            sortedFromIdx: unsortedLimit,
            activeCodeLine: 4
          });
        }
      }

      unsortedLimit--;
      generated.push({
        array: [...a],
        leftIdx: -1,
        rightIdx: -1,
        action: 'pass_end',
        description: `End of pass. Element at index ${unsortedLimit} is now locked in its final sorted position.`,
        swappedInPass: swapped,
        sortedFromIdx: unsortedLimit,
        activeCodeLine: 6
      });
    } while (swapped && unsortedLimit > 1);

    generated.push({
      array: [...a],
      leftIdx: -1,
      rightIdx: -1,
      action: 'completed',
      description: `Bubble Sort Complete! Array is completely sorted. Total elements: ${n}.`,
      swappedInPass: false,
      sortedFromIdx: 0,
      activeCodeLine: 6
    });

    setSteps(generated);
    setCurrentStepIndex(0);
  };

  useEffect(() => {
    generateSteps(initialArray);
  }, [initialArray]);

  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        setCurrentStepIndex(prev => {
          if (prev < steps.length - 1) {
            return prev + 1;
          } else {
            setIsPlaying(false);
            return prev;
          }
        });
      }, speed);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, steps.length, speed]);

  // Notify parent when simulation reaches the final step (sorting completed)
  useEffect(() => {
    if (steps.length > 0 && currentStepIndex === steps.length - 1) {
      onSimulationComplete?.();
    }
  }, [currentStepIndex, steps.length, onSimulationComplete]);

  const handleApplyInput = () => {
    const parsed = inputStr
      .split(',')
      .map(x => parseInt(x.trim(), 10))
      .filter(x => !isNaN(x));
    if (parsed.length >= 2 && parsed.length <= 10) {
      setInitialArray(parsed);
      setIsPlaying(false);
    }
  };

  const handleRandomize = () => {
    const rand = Array.from({ length: 6 }, () => Math.floor(Math.random() * 85) + 10);
    setInitialArray(rand);
    setInputStr(rand.join(', '));
    setIsPlaying(false);
  };

  const currentStep = (steps[currentStepIndex] || {
    array: initialArray,
    leftIdx: -1,
    rightIdx: -1,
    action: 'init',
    description: 'Ready to simulate Bubble Sort.',
    swappedInPass: false,
    sortedFromIdx: initialArray.length,
    activeCodeLine: 0
  }) as BubbleStep;

  const maxVal = Math.max(...initialArray, 50);

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100 mb-6">
        <div>
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
            Bubble Sort Interactive Visualizer & Code Tracer
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Step-by-step comparison and swapping with synchronized VisuAlgo pseudocode tracking
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold px-2.5 py-1 bg-amber-50 text-amber-700 rounded-md border border-amber-200">
            Step {currentStepIndex + 1} of {steps.length}
          </span>
        </div>
      </div>

      {/* Input controls */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3 mb-6 bg-slate-50 p-3 rounded-lg border border-slate-200">
        <div className="md:col-span-7 flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-700 whitespace-nowrap">Input Array:</label>
          <input
            type="text"
            value={inputStr}
            onChange={e => setInputStr(e.target.value)}
            placeholder="e.g. 10, 14, 29, 14, 37"
            className="w-full text-xs font-mono px-3 py-1.5 bg-white border border-slate-300 rounded focus:outline-none focus:ring-1 focus:ring-amber-500"
          />
        </div>
        <div className="md:col-span-5 flex items-center gap-2 justify-end">
          <button
            onClick={handleApplyInput}
            className="px-3 py-1.5 bg-slate-800 text-white text-xs font-medium rounded hover:bg-slate-900 transition-colors"
          >
            Apply
          </button>
          <button
            onClick={handleRandomize}
            className="px-3 py-1.5 bg-white border border-slate-300 text-slate-700 text-xs font-medium rounded hover:bg-slate-100 transition-colors flex items-center gap-1"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" /> Random
          </button>
        </div>
      </div>

      {/* Main Grid: Visualizer Canvas (Left) + VisuAlgo Code Panel (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-6 items-start">
        {/* Visualizer Canvas (VisuAlgo styling: light background with colored bars) */}
        <div className="lg:col-span-7 bg-[#ededed] border border-slate-300 rounded-xl p-6 min-h-[340px] flex flex-col justify-between shadow-inner">
          <div className="flex items-center justify-between pb-2 border-b border-slate-300/80">
            <span className="text-xs font-mono font-bold text-slate-600 uppercase">Array Elements</span>
            <span className="text-[11px] font-mono text-slate-500">
              Comparing: {currentStep.leftIdx >= 0 ? `arr[${currentStep.leftIdx}] & arr[${currentStep.rightIdx}]` : 'None'}
            </span>
          </div>

          {/* Bars representation exactly as shown in screenshot */}
          <div className="flex items-end justify-center gap-4 sm:gap-6 h-56 pt-4 pb-2">
            {currentStep.array.map((val, idx) => {
              const heightPercent = Math.max((val / maxVal) * 85, 20);
              const isComparing = idx === currentStep.leftIdx || idx === currentStep.rightIdx;
              const isSorted = idx >= currentStep.sortedFromIdx;

              // Color styles matching screenshot:
              // Sorted element is orange (#f39c12 / #ff9800)
              // Comparing or unsorted is soft cyan-blue (#a2d2df / #90caf9)
              let barBg = 'bg-[#a0c4d8] text-slate-800';
              if (isSorted) {
                barBg = 'bg-[#ff9800] text-slate-900 font-extrabold shadow-md';
              } else if (isComparing) {
                barBg = 'bg-[#ffeb3b] text-slate-950 font-black ring-2 ring-amber-500 scale-105 transition-transform';
              }

              return (
                <div key={idx} className="flex flex-col items-center gap-1 flex-1 max-w-[65px]">
                  <div
                    style={{ height: `${heightPercent}%` }}
                    className={`w-full rounded-t-sm transition-all duration-300 flex items-center justify-center ${barBg}`}
                  >
                    <span className="text-xs sm:text-sm font-mono font-bold">{val}</span>
                  </div>
                  <span className="text-xs font-mono font-bold text-slate-700 mt-1">{idx}</span>
                </div>
              );
            })}
          </div>

          {/* Legend */}
          <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-slate-600 pt-3 border-t border-slate-300">
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-3.5 rounded bg-[#a0c4d8] border border-slate-400"></span> Unsorted
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-3.5 rounded bg-[#ffeb3b] border border-amber-500"></span> Comparing
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-3.5 rounded bg-[#ff9800]"></span> Sorted Element
            </div>
          </div>
        </div>

        {/* VisuAlgo Code Panel (Right) */}
        <div className="lg:col-span-5">
          <VisuAlgoCodePanel
            title="Bubble Sort"
            explanation={currentStep.description}
            codeLines={ALGORITHM_CODES.bubbleSort.lines}
            activeLineIndex={currentStep.activeCodeLine}
            stepInfo={{ current: currentStepIndex + 1, total: steps.length }}
          />
        </div>
      </div>

      {/* Playback Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-slate-100">
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setIsPlaying(false);
              setCurrentStepIndex(0);
            }}
            className="p-2 border border-slate-300 rounded-lg hover:bg-slate-100 text-slate-700 text-sm font-medium flex items-center gap-1.5 cursor-pointer"
            title="Reset Simulation"
          >
            <RotateCcw className="w-4 h-4" /> Reset
          </button>

          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className={`px-4 py-2 rounded-lg font-medium text-sm flex items-center gap-2 transition-colors cursor-pointer ${
              isPlaying
                ? 'bg-amber-600 hover:bg-amber-700 text-white'
                : 'bg-blue-700 hover:bg-blue-800 text-white'
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4" /> Pause
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" /> Auto Play
              </>
            )}
          </button>

          <button
            onClick={() => {
              setIsPlaying(false);
              setCurrentStepIndex(prev => Math.min(prev + 1, steps.length - 1));
            }}
            disabled={currentStepIndex >= steps.length - 1}
            className="px-3.5 py-2 border border-slate-300 bg-white rounded-lg hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed text-slate-700 text-sm font-medium flex items-center gap-1.5 cursor-pointer"
          >
            <SkipForward className="w-4 h-4" /> Next Step
          </button>
        </div>

        <div className="flex items-center gap-3">
          <label className="text-xs font-semibold text-slate-600">Speed:</label>
          <select
            value={speed}
            onChange={e => setSpeed(Number(e.target.value))}
            className="text-xs bg-white border border-slate-300 rounded px-2.5 py-1.5 font-medium text-slate-700 focus:outline-none"
          >
            <option value={1400}>0.75x (Slow)</option>
            <option value={900}>1.0x (Normal)</option>
            <option value={450}>2.0x (Fast)</option>
          </select>
        </div>
      </div>
    </div>
  );
};
