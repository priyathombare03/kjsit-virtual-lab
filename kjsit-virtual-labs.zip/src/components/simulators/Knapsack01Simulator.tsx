import React, { useState } from 'react';
import { Table, ArrowRight, RotateCcw, Sparkles } from 'lucide-react';

export const Knapsack01Simulator: React.FC = () => {
  const [W, setW] = useState<number>(7);
  const [items, setItems] = useState([
    { name: 'Item 1', val: 1, wt: 1 },
    { name: 'Item 2', val: 4, wt: 3 },
    { name: 'Item 3', val: 5, wt: 4 },
    { name: 'Item 4', val: 7, wt: 5 },
  ]);

  const [hoveredCell, setHoveredCell] = useState<{ i: number; w: number } | null>(null);

  // Compute DP Table
  const n = items.length;
  const dp: number[][] = Array.from({ length: n + 1 }, () => Array(W + 1).fill(0));

  for (let i = 1; i <= n; i++) {
    const item = items[i - 1];
    for (let w = 1; w <= W; w++) {
      if (item.wt <= w) {
        dp[i][w] = Math.max(dp[i - 1][w], item.val + dp[i - 1][w - item.wt]);
      } else {
        dp[i][w] = dp[i - 1][w];
      }
    }
  }

  // Traceback items
  const includedItems: number[] = [];
  let currW = W;
  for (let i = n; i > 0; i--) {
    if (dp[i][currW] !== dp[i - 1][currW]) {
      includedItems.push(i - 1);
      currW -= items[i - 1].wt;
    }
  }

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100 mb-6">
        <div>
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Table className="w-5 h-5 text-purple-600" />
            0/1 Knapsack Dynamic Programming Matrix Table
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            2D Tabulation Grid DP[i][w] representing max profit with first i items and capacity w
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold px-2.5 py-1 bg-purple-50 text-purple-700 rounded-md border border-purple-200">
            DP Time Complexity: O(n·W)
          </span>
        </div>
      </div>

      {/* Inputs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-6 bg-slate-50 p-4 rounded-xl border border-slate-200">
        <div>
          <label className="text-xs font-semibold text-slate-700 block mb-1">
            Knapsack Capacity (W): <span className="font-bold text-purple-700">{W}</span>
          </label>
          <input
            type="range"
            min="4"
            max="10"
            value={W}
            onChange={(e) => setW(Number(e.target.value))}
            className="w-full accent-purple-600 cursor-pointer"
          />
        </div>
        <div className="sm:col-span-3 flex flex-wrap items-center justify-end gap-2">
          <span className="text-xs text-slate-500">
            Hover over any table cell to inspect the subproblem formula comparison.
          </span>
        </div>
      </div>

      {/* DP Table */}
      <div className="overflow-x-auto border border-slate-200 rounded-xl mb-6 shadow-inner bg-slate-900 text-white p-4">
        <div className="text-xs font-mono text-slate-400 mb-2 flex justify-between">
          <span>DP[i][w] Matrix (Rows: Items i=0..{n}, Columns: Weights w=0..{W})</span>
          <span className="text-emerald-400 font-bold">Max Profit = {dp[n][W]}</span>
        </div>
        <table className="w-full text-center text-xs font-mono border-collapse">
          <thead>
            <tr className="border-b border-slate-700 text-slate-400">
              <th className="p-2 text-left">Item i \ w</th>
              {Array.from({ length: W + 1 }, (_, w) => (
                <th key={w} className="p-2 border-l border-slate-800 font-bold text-cyan-400">
                  {w}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: n + 1 }, (_, i) => {
              const itemLabel = i === 0 ? 'Base (0)' : `${items[i - 1].name} (v=${items[i - 1].val}, w=${items[i - 1].wt})`;
              return (
                <tr key={i} className="border-b border-slate-800/60 hover:bg-slate-800/40">
                  <td className="p-2 text-left font-semibold text-slate-300 whitespace-nowrap">
                    {itemLabel}
                  </td>
                  {Array.from({ length: W + 1 }, (_, w) => {
                    const isTarget = i === n && w === W;
                    const isHovered = hoveredCell?.i === i && hoveredCell?.w === w;
                    let cellBg = 'bg-transparent';
                    if (isTarget) cellBg = 'bg-emerald-600 text-white font-black ring-2 ring-emerald-400';
                    else if (isHovered) cellBg = 'bg-purple-600 text-white font-bold';
                    else if (i > 0 && w > 0 && dp[i][w] !== dp[i - 1][w]) cellBg = 'bg-slate-800 text-emerald-300 font-semibold';

                    return (
                      <td
                        key={w}
                        onMouseEnter={() => setHoveredCell({ i, w })}
                        onMouseLeave={() => setHoveredCell(null)}
                        className={`p-2 border-l border-slate-800 transition-colors cursor-pointer ${cellBg}`}
                      >
                        {dp[i][w]}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Dynamic Explanation of Hovered Cell */}
      {hoveredCell && hoveredCell.i > 0 && hoveredCell.w > 0 && (
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-3.5 mb-6 text-xs text-purple-950">
          <div className="font-bold text-purple-900 mb-1">
            Inspecting Cell DP[{hoveredCell.i}][{hoveredCell.w}]:
          </div>
          {items[hoveredCell.i - 1].wt <= hoveredCell.w ? (
            <p>
              Weight {items[hoveredCell.i - 1].wt} &le; Capacity {hoveredCell.w}:<br />
              <code>
                max(Exclude: DP[{hoveredCell.i - 1}][{hoveredCell.w}] = {dp[hoveredCell.i - 1][hoveredCell.w]}, Include: {items[hoveredCell.i - 1].val} + DP[{hoveredCell.i - 1}][{hoveredCell.w - items[hoveredCell.i - 1].wt}] = {items[hoveredCell.i - 1].val + dp[hoveredCell.i - 1][hoveredCell.w - items[hoveredCell.i - 1].wt]}) = {dp[hoveredCell.i][hoveredCell.w]}
              </code>
            </p>
          ) : (
            <p>
              Weight {items[hoveredCell.i - 1].wt} &gt; Capacity {hoveredCell.w} (Cannot fit):<br />
              <code>
                DP[{hoveredCell.i}][{hoveredCell.w}] = DP[{hoveredCell.i - 1}][{hoveredCell.w}] = {dp[hoveredCell.i][hoveredCell.w]}
              </code>
            </p>
          )}
        </div>
      )}

      {/* Traceback Result Card */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
            Optimal Backtracked Solution
          </span>
          <span className="text-sm font-semibold text-slate-900">
            Selected Items:{' '}
            {includedItems.map(idx => `${items[idx].name} (Val: ${items[idx].val}, Wt: ${items[idx].wt})`).join(', ')}
          </span>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <span className="text-xs text-slate-500 block">Total Profit Earned</span>
            <span className="text-xl font-black text-emerald-600">₹{dp[n][W]}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
