import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, SkipForward, SkipBack, Sparkles, CheckCircle2, XCircle } from 'lucide-react';
import { VisuAlgoCodePanel } from './common/VisuAlgoCodePanel';
import { ALGORITHM_CODES } from './common/algorithmCodes';

interface Edge {
  id: string;
  u: string;
  v: string;
  weight: number;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
}

interface NodeCoord {
  id: string;
  label: string;
  x: number;
  y: number;
}

interface KruskalStep {
  edgeIndex: number;
  currentEdge: Edge | null;
  mstEdges: string[];
  rejectedEdges: string[];
  dsuParents: { [key: string]: string };
  action: 'examine' | 'include' | 'reject' | 'completed';
  description: string;
  totalWeight: number;
  activeCodeLine: number;
}

interface KruskalsProps {
  onSimulationComplete?: () => void;
}

export const KruskalsSimulator: React.FC<KruskalsProps> = ({ onSimulationComplete }) => {
  const nodes: NodeCoord[] = [
    { id: 'A', label: 'A', x: 80, y: 70 },
    { id: 'B', label: 'B', x: 260, y: 50 },
    { id: 'C', label: 'C', x: 440, y: 70 },
    { id: 'D', label: 'D', x: 80, y: 210 },
    { id: 'E', label: 'E', x: 260, y: 230 },
    { id: 'F', label: 'F', x: 440, y: 210 }
  ];

  const defaultEdges: Edge[] = [
    { id: 'e1', u: 'A', v: 'B', weight: 4, x1: 80, y1: 70, x2: 260, y2: 50 },
    { id: 'e2', u: 'B', v: 'C', weight: 3, x1: 260, y1: 50, x2: 440, y2: 70 },
    { id: 'e3', u: 'A', v: 'D', weight: 2, x1: 80, y1: 70, x2: 80, y2: 210 },
    { id: 'e4', u: 'B', v: 'E', weight: 2, x1: 260, y1: 50, x2: 260, y2: 230 },
    { id: 'e5', u: 'C', v: 'F', weight: 5, x1: 440, y1: 70, x2: 440, y2: 210 },
    { id: 'e6', u: 'D', v: 'E', weight: 3, x1: 80, y1: 210, x2: 260, y2: 230 },
    { id: 'e7', u: 'E', v: 'F', weight: 4, x1: 260, y1: 230, x2: 440, y2: 210 },
    { id: 'e8', u: 'B', v: 'D', weight: 1, x1: 260, y1: 50, x2: 80, y2: 210 },
    { id: 'e9', u: 'B', v: 'F', weight: 7, x1: 260, y1: 50, x2: 440, y2: 210 }
  ];

  const [steps, setSteps] = useState<KruskalStep[]>([]);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [speed, setSpeed] = useState<number>(1000);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Generate complete Kruskal algorithm step trace
  const generateSteps = () => {
    const sortedEdges = [...defaultEdges].sort((a, b) => a.weight - b.weight);
    const parent: { [key: string]: string } = {};
    nodes.forEach(n => {
      parent[n.id] = n.id;
    });

    const find = (i: string): string => {
      if (parent[i] === i) return i;
      parent[i] = find(parent[i]);
      return parent[i];
    };

    const union = (i: string, j: string) => {
      const rootI = find(i);
      const rootJ = find(j);
      if (rootI !== rootJ) {
        parent[rootI] = rootJ;
      }
    };

    const trace: KruskalStep[] = [];
    const mst: string[] = [];
    const rejected: string[] = [];
    let currentTotalWeight = 0;

    trace.push({
      edgeIndex: -1,
      currentEdge: null,
      mstEdges: [],
      rejectedEdges: [],
      dsuParents: { ...parent },
      action: 'examine',
      description: `Edges sorted in ascending weight order. Initialized ${nodes.length} disjoint sets for vertices.`,
      totalWeight: 0,
      activeCodeLine: 0 // sort all edges E by weight ascending
    });

    for (let idx = 0; idx < sortedEdges.length; idx++) {
      const edge = sortedEdges[idx];
      const rootU = find(edge.u);
      const rootV = find(edge.v);

      trace.push({
        edgeIndex: idx,
        currentEdge: edge,
        mstEdges: [...mst],
        rejectedEdges: [...rejected],
        dsuParents: { ...parent },
        action: 'examine',
        description: `Inspecting edge (${edge.u} - ${edge.v}) with weight ${edge.weight}. Find(${edge.u})=${rootU}, Find(${edge.v})=${rootV}.`,
        totalWeight: currentTotalWeight,
        activeCodeLine: 2 // for each edge (u, v, weight) in E
      });

      if (rootU !== rootV) {
        union(edge.u, edge.v);
        mst.push(edge.id);
        currentTotalWeight += edge.weight;

        trace.push({
          edgeIndex: idx,
          currentEdge: edge,
          mstEdges: [...mst],
          rejectedEdges: [...rejected],
          dsuParents: { ...parent },
          action: 'include',
          description: `Different component roots (${rootU} ≠ ${rootV}). Edge (${edge.u} - ${edge.v}) added to MST! Union sets.`,
          totalWeight: currentTotalWeight,
          activeCodeLine: 6 // add (u, v) to MST_Edges; union(rootU, rootV)
        });

        if (mst.length === nodes.length - 1) {
          break;
        }
      } else {
        rejected.push(edge.id);
        trace.push({
          edgeIndex: idx,
          currentEdge: edge,
          mstEdges: [...mst],
          rejectedEdges: [...rejected],
          dsuParents: { ...parent },
          action: 'reject',
          description: `Cycle detected! Both vertices belong to root component ${rootU}. Edge (${edge.u} - ${edge.v}) rejected.`,
          totalWeight: currentTotalWeight,
          activeCodeLine: 8 // else: discard (u, v) // forms cycle
        });
      }
    }

    trace.push({
      edgeIndex: sortedEdges.length,
      currentEdge: null,
      mstEdges: [...mst],
      rejectedEdges: [...rejected],
      dsuParents: { ...parent },
      action: 'completed',
      description: `Kruskal's MST Complete! Connected all ${nodes.length} vertices with ${mst.length} edges. Total MST Weight = ${currentTotalWeight}.`,
      totalWeight: currentTotalWeight,
      activeCodeLine: 6
    });

    setSteps(trace);
    setCurrentStepIndex(0);
  };

  useEffect(() => {
    generateSteps();
  }, []);

  // Timer playback
  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setTimeout(() => {
        if (currentStepIndex < steps.length - 1) {
          setCurrentStepIndex(prev => prev + 1);
        } else {
          setIsPlaying(false);
        }
      }, speed);
    } else {
      if (timerRef.current) clearTimeout(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [isPlaying, currentStepIndex, steps.length, speed]);

  // Trigger completion when final step reached
  useEffect(() => {
    if (steps.length > 0 && currentStepIndex === steps.length - 1) {
      onSimulationComplete?.();
    }
  }, [currentStepIndex, steps.length, onSimulationComplete]);

  const currentStep = steps[currentStepIndex] || {
    edgeIndex: -1,
    currentEdge: null,
    mstEdges: [],
    rejectedEdges: [],
    dsuParents: {},
    action: 'examine',
    description: 'Preparing simulation...',
    totalWeight: 0,
    activeCodeLine: 0
  };

  const sortedEdges = [...defaultEdges].sort((a, b) => a.weight - b.weight);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900 text-white p-4 rounded-xl border border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-red-600/30 text-red-400 border border-red-500/30">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm">
              Kruskal's Minimum Spanning Tree Algorithm
            </h3>
            <p className="text-xs text-slate-400">
              Disjoint Set Union (DSU) & Minimum Spanning Tree
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-slate-400">MST Edges: </span>
            <span className="text-emerald-400 font-bold">
              {currentStep.mstEdges.length} / {nodes.length - 1}
            </span>
          </div>
          <div className="bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
            <span className="text-slate-400">Total MST Weight: </span>
            <span className="text-amber-400 font-bold">{currentStep.totalWeight}</span>
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Graph Canvas */}
        <div className="lg:col-span-4 bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col justify-between min-h-[360px]">
          <div className="flex justify-center items-center h-[260px]">
            <svg width="340" height="250" className="overflow-visible">
              {/* Render Edges */}
              {defaultEdges.map(e => {
                const isMST = currentStep.mstEdges.includes(e.id);
                const isRejected = currentStep.rejectedEdges.includes(e.id);
                const isCurrent = currentStep.currentEdge?.id === e.id;

                let strokeColor = '#334155';
                let strokeWidth = 2;
                let strokeDash = '0';

                if (isMST) {
                  strokeColor = '#10b981';
                  strokeWidth = 3.5;
                } else if (isCurrent) {
                  strokeColor = '#f59e0b';
                  strokeWidth = 3;
                } else if (isRejected) {
                  strokeColor = '#ef4444';
                  strokeWidth = 1.5;
                  strokeDash = '4,4';
                }

                const midX = (e.x1 + e.x2) / 2;
                const midY = (e.y1 + e.y2) / 2 - 8;

                return (
                  <g key={e.id}>
                    <line
                      x1={e.x1}
                      y1={e.y1}
                      x2={e.x2}
                      y2={e.y2}
                      stroke={strokeColor}
                      strokeWidth={strokeWidth}
                      strokeDasharray={strokeDash}
                      className="transition-all duration-300"
                    />
                    <circle cx={midX} cy={midY + 8} r="10" fill="#0f172a" stroke={strokeColor} strokeWidth="1" />
                    <text
                      x={midX}
                      y={midY + 12}
                      textAnchor="middle"
                      fill="#ffffff"
                      fontSize="11"
                      fontWeight="bold"
                      fontFamily="monospace"
                    >
                      {e.weight}
                    </text>
                  </g>
                );
              })}

              {/* Render Nodes */}
              {nodes.map(n => {
                const parentOfN = currentStep.dsuParents[n.id] || n.id;
                return (
                  <g key={n.id}>
                    <circle
                      cx={n.x}
                      cy={n.y}
                      r="16"
                      fill="#1e293b"
                      stroke="#dc2626"
                      strokeWidth="2.5"
                      className="transition-all"
                    />
                    <text
                      x={n.x}
                      y={n.y + 5}
                      textAnchor="middle"
                      fill="#ffffff"
                      fontSize="12"
                      fontWeight="bold"
                    >
                      {n.label}
                    </text>
                    <text
                      x={n.x}
                      y={n.y + 26}
                      textAnchor="middle"
                      fill="#94a3b8"
                      fontSize="9"
                      fontFamily="monospace"
                    >
                      root:{parentOfN}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Description */}
          <div className="bg-slate-900/90 rounded-lg p-3 border border-slate-800 text-xs">
            <p className="text-slate-200 font-medium leading-relaxed">
              {currentStep.description}
            </p>
          </div>
        </div>

        {/* Sorted Edge Priority Queue List */}
        <div className="lg:col-span-3 bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col justify-between min-h-[360px]">
          <div>
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center justify-between">
              <span>Sorted Edges</span>
              <span className="text-[10px] text-slate-500 font-normal">Ascending</span>
            </h4>
            <div className="space-y-1.5 max-h-[260px] overflow-y-auto pr-1">
              {sortedEdges.map((e, idx) => {
                const isMST = currentStep.mstEdges.includes(e.id);
                const isRejected = currentStep.rejectedEdges.includes(e.id);
                const isCurrent = currentStep.currentEdge?.id === e.id;

                let rowClass = 'bg-white border-slate-200 text-slate-700';
                let icon = null;

                if (isMST) {
                  rowClass = 'bg-emerald-50 border-emerald-300 text-emerald-900 font-bold';
                  icon = <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />;
                } else if (isCurrent) {
                  rowClass = 'bg-amber-50 border-amber-400 text-amber-900 font-bold ring-1 ring-amber-400';
                  icon = <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping"></span>;
                } else if (isRejected) {
                  rowClass = 'bg-red-50 border-red-200 text-red-700 opacity-60';
                  icon = <XCircle className="w-3.5 h-3.5 text-red-500 shrink-0" />;
                }

                return (
                  <div
                    key={e.id}
                    className={`flex items-center justify-between px-3 py-1.5 rounded-lg border text-xs font-mono transition-all ${rowClass}`}
                  >
                    <div className="flex items-center gap-2">
                      {icon || <span className="w-3.5 text-[10px] text-slate-400">{idx + 1}</span>}
                      <span>({e.u} - {e.v})</span>
                    </div>
                    <span className="px-2 py-0.5 bg-slate-100 border border-slate-200 rounded text-[11px] font-bold">
                      wt: {e.weight}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-200 text-[11px] text-slate-600">
            <span className="font-semibold text-slate-800">Greedy Invariant:</span> Pick least weight edge without cycle (E = V - 1).
          </div>
        </div>

        {/* VisuAlgo Code Panel */}
        <div className="lg:col-span-5">
          <VisuAlgoCodePanel
            title="Kruskal's MST Algorithm"
            explanation={currentStep.description}
            codeLines={ALGORITHM_CODES.kruskalMST.lines}
            activeLineIndex={currentStep.activeCodeLine}
            stepInfo={{ current: currentStepIndex + 1, total: steps.length || 1 }}
          />
        </div>
      </div>

      {/* Playback Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentStepIndex(0)}
            className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            title="Reset"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <button
            onClick={() => setCurrentStepIndex(prev => Math.max(0, prev - 1))}
            disabled={currentStepIndex === 0}
            className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-40 cursor-pointer"
            title="Previous Step"
          >
            <SkipBack className="w-4 h-4" />
          </button>
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-semibold rounded-lg shadow-sm flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4" /> Pause
              </>
            ) : (
              <>
                <Play className="w-4 h-4" /> Play Simulation
              </>
            )}
          </button>
          <button
            onClick={() => setCurrentStepIndex(prev => Math.min(steps.length - 1, prev + 1))}
            disabled={currentStepIndex === steps.length - 1}
            className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-40 cursor-pointer"
            title="Next Step"
          >
            <SkipForward className="w-4 h-4" />
          </button>
        </div>

        {/* Speed */}
        <div className="flex items-center gap-1.5 text-xs text-slate-600">
          <span>Speed:</span>
          <select
            value={speed}
            onChange={e => setSpeed(Number(e.target.value))}
            className="bg-white border border-slate-300 rounded px-2 py-1 text-xs"
          >
            <option value={1500}>0.75x</option>
            <option value={1000}>1.0x</option>
            <option value={500}>2.0x</option>
          </select>
        </div>
      </div>
    </div>
  );
};
