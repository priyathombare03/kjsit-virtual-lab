import React, { useState, useEffect } from 'react';
import {
  Play,
  RotateCcw,
  Sparkles,
  Zap,
  Sliders,
  CheckCircle2,
  TrendingUp,
  BrainCircuit,
  Cpu,
  Layers,
  ArrowRight,
  Info,
  RefreshCw,
  BarChart2,
  HelpCircle,
  FileText,
  Search,
  Hash,
  Activity,
  Smile,
  Frown,
  Meh,
  Tag,
  BookOpen,
  Compass
} from 'lucide-react';
import { useSimulationContext } from '../common/SimulationContext';

interface Props {
  experimentId: string;
  onSimulationComplete?: () => void;
}

export const NLPSimulator: React.FC<Props> = ({ experimentId, onSimulationComplete }) => {
  const simContext = useSimulationContext();

  const handleComplete = () => {
    if (onSimulationComplete) onSimulationComplete();
    simContext?.onSimulationComplete();
  };

  const renderContent = () => {
    switch (experimentId) {
      case 'nlp-exp1':
      case 'text-preprocessing':
        return <TextPreprocessingSimulator onComplete={handleComplete} />;
      case 'nlp-exp2':
      case 'ngram-language-model':
        return <NGramLanguageModelSimulator onComplete={handleComplete} />;
      case 'nlp-exp3':
      case 'spacy-pos-ner':
        return <SpaCyPOSNERSimulator onComplete={handleComplete} />;
      case 'nlp-exp4':
      case 'naive-bayes-text':
        return <NaiveBayesTextSimulator onComplete={handleComplete} />;
      case 'nlp-exp5':
      case 'vader-sentiment':
        return <VADERSentimentSimulator onComplete={handleComplete} />;
      case 'nlp-exp6':
      case 'word2vec-embeddings':
        return <Word2VecSimulator onComplete={handleComplete} />;
      case 'nlp-exp7':
      case 'bert-transformer':
        return <BERTTransformerSimulator onComplete={handleComplete} />;
      case 'nlp-exp8':
      case 'lstm-next-word':
        return <LSTMNextWordSimulator onComplete={handleComplete} />;
      default:
        return <TextPreprocessingSimulator onComplete={handleComplete} />;
    }
  };

  return (
    <div>
      {renderContent()}
    </div>
  );
};

// =========================================================================
// Experiment 1: Text Preprocessing Simulator (English & Regional Languages)
// =========================================================================
const TextPreprocessingSimulator: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const PRESETS = [
    {
      label: 'English Academic Text',
      text: 'The computational algorithms were continually analyzing dynamic biological structures. Studies have shown that better solutions are easily produced when students study regularly.'
    },
    {
      label: 'English Social Media',
      text: 'OMG!! Natural language processing is amazingly fast & revolutionizing modern search engines today!'
    },
    {
      label: 'Regional (Marathi)',
      text: 'नैसर्गिक भाषा प्रक्रिया संगणक विज्ञान आणि कृत्रिम बुद्धिमत्ता क्षेत्रातील एक अत्यंत महत्त्वाचे तंत्रज्ञान आहे.'
    },
    {
      label: 'Regional (Hindi)',
      text: 'प्राकृतिक भाषा प्रसंस्करण कंप्यूटर विज्ञान और कृत्रिम बुद्धिमत्ता का एक महत्वपूर्ण उपक्षेत्र है।'
    }
  ];

  const [rawText, setRawText] = useState(PRESETS[0].text);
  const [tokenType, setTokenType] = useState<'word' | 'sentence'>('word');
  const [removeStopwords, setRemoveStopwords] = useState(true);
  const [applyStemming, setApplyStemming] = useState(true);
  const [applyLemmatization, setApplyLemmatization] = useState(true);
  const [activeStep, setActiveStep] = useState(4);
  const [simulated, setSimulated] = useState(false);

  const ENGLISH_STOPWORDS = new Set([
    'i', 'me', 'my', 'we', 'our', 'you', 'your', 'he', 'she', 'it', 'they', 'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'have', 'has', 'had', 'do', 'does', 'did', 'and', 'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 'at', 'by', 'for', 'with', 'about', 'between', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'to', 'from', 'in', 'on', 'off', 'over', 'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 'can', 'will', 'just', 'should', 'now', 'that'
  ]);

  const MARATHI_STOPWORDS = new Set(['आणि', 'हे', 'आहे', 'एक', 'का', 'की', 'ते', 'या', 'पण', 'नाही', 'तर']);
  const HINDI_STOPWORDS = new Set(['और', 'है', 'का', 'एक', 'के', 'की', 'को', 'में', 'पर', 'से', 'होता', 'नहीं']);

  // Crude stemming and lemmatization mapping for pedagogical demonstration
  const stemWord = (w: string): string => {
    let s = w.toLowerCase().replace(/[^a-zA-Z\u0900-\u097F]/g, '');
    if (s.endsWith('ing')) s = s.slice(0, -3);
    else if (s.endsWith('ies')) s = s.slice(0, -3) + 'i';
    else if (s.endsWith('ied')) s = s.slice(0, -3) + 'i';
    else if (s.endsWith('ed')) s = s.slice(0, -2);
    else if (s.endsWith('es')) s = s.slice(0, -2);
    else if (s.endsWith('s') && !s.endsWith('ss')) s = s.slice(0, -1);
    else if (s.endsWith('ly')) s = s.slice(0, -2);
    else if (s.endsWith('tion')) s = s.slice(0, -4);
    return s;
  };

  const lemmaWord = (w: string): string => {
    const s = w.toLowerCase().replace(/[^a-zA-Z\u0900-\u097F]/g, '');
    const map: Record<string, string> = {
      computational: 'computational',
      algorithms: 'algorithm',
      continually: 'continually',
      analyzing: 'analyze',
      studies: 'study',
      shown: 'show',
      better: 'good',
      solutions: 'solution',
      easily: 'easily',
      produced: 'produce',
      students: 'student',
      study: 'study',
      regularly: 'regularly',
      amazingly: 'amazingly',
      revolutionizing: 'revolutionize',
      engines: 'engine'
    };
    return map[s] || s;
  };

  // Processing
  const sentences = rawText.split(/[.!?]+/).filter(s => s.trim().length > 0);
  const rawTokens = rawText
    .split(/[\s,.;:!?()]+/)
    .map(t => t.trim())
    .filter(t => t.length > 0);

  const cleanedTokens = rawTokens.map(t => t.toLowerCase().replace(/[^a-zA-Z0-9\u0900-\u097F]/g, '')).filter(Boolean);

  const isStopword = (t: string) => ENGLISH_STOPWORDS.has(t) || MARATHI_STOPWORDS.has(t) || HINDI_STOPWORDS.has(t);

  const nonStopTokens = removeStopwords ? cleanedTokens.filter(t => !isStopword(t)) : cleanedTokens;

  const comparisonData = nonStopTokens.map(t => ({
    original: t,
    stem: stemWord(t),
    lemma: lemmaWord(t),
    isDifferent: stemWord(t) !== lemmaWord(t)
  }));

  const reductionPct = rawTokens.length > 0
    ? Math.round(((rawTokens.length - nonStopTokens.length) / rawTokens.length) * 100)
    : 0;

  const handleRun = () => {
    setSimulated(true);
    onComplete();
  };

  return (
    <div className="space-y-6">
      <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-base font-bold text-[#2E080C] flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#741118]" />
              Practical 1: Text Preprocessing & Morphological Analysis
            </h3>
            <p className="text-xs text-stone-500">
              Interactive pipeline for Word/Sentence Tokenization, Stopwords Removal, Porter Stemming, and WordNet Lemmatization
            </p>
          </div>
          <button
            onClick={handleRun}
            className="px-4 py-2 rounded-lg bg-[#741118] hover:bg-[#5D0E13] text-white text-xs font-semibold flex items-center gap-2 shadow-sm transition-all"
          >
            <Play className="w-4 h-4 fill-white" />
            Execute Preprocessing Pipeline
          </button>
        </div>

        {/* Presets */}
        <div className="flex items-center gap-2 mb-3 overflow-x-auto pb-1 text-xs">
          <span className="text-stone-400 font-medium">Sample Presets:</span>
          {PRESETS.map((p, idx) => (
            <button
              key={idx}
              onClick={() => { setRawText(p.text); setSimulated(false); }}
              className={`px-2.5 py-1 rounded-md border transition-all whitespace-nowrap ${
                rawText === p.text
                  ? 'bg-[#FBF2F3] border-[#741118] text-[#741118] font-bold'
                  : 'bg-[#FAF8F4] border-[#DDD8CD] text-stone-600 hover:bg-[#F2EEE4]'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>

        {/* Input Text Box */}
        <div className="space-y-2 mb-4">
          <label className="text-xs font-semibold text-stone-700">Input Text (English or Regional Indic Language):</label>
          <textarea
            value={rawText}
            onChange={(e) => { setRawText(e.target.value); setSimulated(false); }}
            rows={3}
            className="w-full text-xs font-mono p-3 bg-[#FAF8F4] border border-[#DDD8CD] rounded-lg focus:ring-2 focus:ring-[#741118] focus:border-[#741118] focus:outline-none text-stone-800"
            placeholder="Type or paste sample text here..."
          />
        </div>

        {/* Pipeline Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 p-3 bg-[#FAF8F4] rounded-lg border border-[#DDD8CD] text-xs">
          <div>
            <label className="block text-stone-500 font-medium mb-1">Tokenization Mode</label>
            <div className="flex gap-2">
              <button
                onClick={() => setTokenType('word')}
                className={`px-3 py-1 rounded border ${tokenType === 'word' ? 'bg-[#741118] text-white border-[#741118]' : 'bg-white text-stone-700 border-[#DDD8CD]'}`}
              >
                Word Tokens
              </button>
              <button
                onClick={() => setTokenType('sentence')}
                className={`px-3 py-1 rounded border ${tokenType === 'sentence' ? 'bg-[#741118] text-white border-[#741118]' : 'bg-white text-stone-700 border-[#DDD8CD]'}`}
              >
                Sentences
              </button>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="stopwordToggle"
              checked={removeStopwords}
              onChange={(e) => setRemoveStopwords(e.target.checked)}
              className="rounded text-[#741118] focus:ring-[#741118]"
            />
            <label htmlFor="stopwordToggle" className="cursor-pointer text-stone-700 font-medium">
              Remove Stopwords (NLTK)
            </label>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="stemmingToggle"
              checked={applyStemming}
              onChange={(e) => setApplyStemming(e.target.checked)}
              className="rounded text-[#741118] focus:ring-[#741118]"
            />
            <label htmlFor="stemmingToggle" className="cursor-pointer text-stone-700 font-medium">
              Porter Stemmer
            </label>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="lemmaToggle"
              checked={applyLemmatization}
              onChange={(e) => setApplyLemmatization(e.target.checked)}
              className="rounded text-[#741118] focus:ring-[#741118]"
            />
            <label htmlFor="lemmaToggle" className="cursor-pointer text-stone-700 font-medium">
              WordNet Lemmatizer
            </label>
          </div>
        </div>
      </div>

      {/* Metrics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white border border-[#DDD8CD] rounded-xl p-4 shadow-sm">
          <div className="text-xs text-stone-500 font-medium">Original Tokens</div>
          <div className="text-2xl font-bold text-[#2E080C] mt-1">{rawTokens.length}</div>
          <div className="text-[11px] text-stone-400 mt-0.5">{sentences.length} sentence(s) parsed</div>
        </div>
        <div className="bg-white border border-[#DDD8CD] rounded-xl p-4 shadow-sm">
          <div className="text-xs text-stone-500 font-medium">Cleaned Tokens</div>
          <div className="text-2xl font-bold text-[#741118] mt-1">{nonStopTokens.length}</div>
          <div className="text-[11px] text-stone-400 mt-0.5">{rawTokens.length - nonStopTokens.length} stopwords pruned</div>
        </div>
        <div className="bg-white border border-[#DDD8CD] rounded-xl p-4 shadow-sm">
          <div className="text-xs text-stone-500 font-medium">Vocabulary Reduction</div>
          <div className="text-2xl font-bold text-[#6D7D74] mt-1">{reductionPct}%</div>
          <div className="text-[11px] text-stone-400 mt-0.5">Feature space compression</div>
        </div>
        <div className="bg-white border border-[#DDD8CD] rounded-xl p-4 shadow-sm">
          <div className="text-xs text-stone-500 font-medium">Stem vs Lemma Discrepancy</div>
          <div className="text-2xl font-bold text-[#2E080C] mt-1">
            {comparisonData.filter(d => d.isDifferent).length}
          </div>
          <div className="text-[11px] text-stone-400 mt-0.5">Tokens with distinct roots</div>
        </div>
      </div>

      {/* Results View */}
      {tokenType === 'sentence' ? (
        <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm space-y-3">
          <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider">Sentence Segmentation (Punkt Model)</h4>
          <div className="space-y-2">
            {sentences.map((s, idx) => (
              <div key={idx} className="p-3 bg-[#FAF8F4] rounded-lg border border-[#DDD8CD] text-xs flex items-center gap-3">
                <span className="w-6 h-6 rounded-full bg-[#FBF2F3] text-[#741118] font-bold flex items-center justify-center text-[11px]">
                  {idx + 1}
                </span>
                <span className="text-[#2E080C] font-medium">{s.trim()}</span>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Token Pills */}
          <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm space-y-3">
            <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider flex items-center justify-between">
              <span>Extracted Word Tokens ({cleanedTokens.length})</span>
              <span className="text-[10px] text-stone-400 font-normal">Gray = Stopword</span>
            </h4>
            <div className="flex flex-wrap gap-1.5 max-h-64 overflow-y-auto p-2 bg-[#FAF8F4] rounded-lg border border-[#DDD8CD]">
              {cleanedTokens.map((t, idx) => {
                const isStop = isStopword(t);
                return (
                  <span
                    key={idx}
                    className={`px-2 py-0.5 rounded text-xs font-mono transition-all ${
                      isStop
                        ? 'bg-stone-200 text-stone-500 line-through opacity-60'
                        : 'bg-[#FBF2F3] text-[#741118] border border-[#E8B9BD] font-medium'
                    }`}
                  >
                    {t}
                  </span>
                );
              })}
            </div>
          </div>

          {/* Stemming vs Lemmatization Side-by-Side Table */}
          <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm space-y-3">
            <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider flex items-center justify-between">
              <span>Stemming vs. Lemmatization Comparison</span>
              <span className="text-[10px] text-[#741118] font-semibold">Crimson = Heuristic Difference</span>
            </h4>
            <div className="max-h-64 overflow-y-auto border border-[#DDD8CD] rounded-lg">
              <table className="w-full text-xs text-left">
                <thead className="bg-[#FAF8F4] text-stone-600 sticky top-0 border-b border-[#DDD8CD]">
                  <tr>
                    <th className="p-2 font-semibold">Token</th>
                    <th className="p-2 font-semibold">Porter Stem</th>
                    <th className="p-2 font-semibold">WordNet Lemma</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 font-mono">
                  {comparisonData.map((row, idx) => (
                    <tr key={idx} className={row.isDifferent ? 'bg-[#FBF2F3]/70' : ''}>
                      <td className="p-2 font-medium text-stone-800">{row.original}</td>
                      <td className="p-2 text-stone-600">{row.stem}</td>
                      <td className="p-2 font-semibold text-[#741118]">{row.lemma}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Educational Insight Card */}
      <div className="p-4 bg-[#F2EEE4] border border-[#BAC5BE] rounded-xl text-xs text-[#2E080C] flex items-start gap-3">
        <Info className="w-5 h-5 text-[#741118] flex-shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">Key Insight from Experiment 1:</span> Notice how Porter Stemmer chops suffixes heuristically (e.g. <code>"studying" → "studi"</code>), producing non-dictionary words. WordNet Lemmatization references morphological dictionaries and Part-of-Speech context to output the true grammatical root (e.g. <code>"better" → "good"</code>, <code>"studies" → "study"</code>).
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// Experiment 2: N-Gram Language Model Simulator
// =========================================================================
const NGramLanguageModelSimulator: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const DEFAULT_CORPUS = `natural language processing is an essential field of artificial intelligence.
natural language processing enables machines to understand human communication.
natural language understanding helps computers interact naturally.
artificial intelligence systems require deep sequence modeling.
language models predict subsequent words in text sequences.`;

  const [corpus, setCorpus] = useState(DEFAULT_CORPUS);
  const [ngramN, setNgramN] = useState<1 | 2 | 3>(2);
  const [contextPrefix, setContextPrefix] = useState('natural language');
  const [useLaplace, setUseLaplace] = useState(true);
  const [predictedWords, setPredictedWords] = useState<Array<{ word: string; prob: number; count: number }>>([]);
  const [perplexity, setPerplexity] = useState(14.2);

  // Compute N-Gram frequencies
  useEffect(() => {
    const tokens = corpus.toLowerCase().match(/\b[a-z]+\b/g) || [];
    if (tokens.length === 0) return;

    const vocab = Array.from(new Set(tokens));
    const V = vocab.length;

    const unigrams: Record<string, number> = {};
    const bigrams: Record<string, number> = {};
    const trigrams: Record<string, number> = {};

    tokens.forEach(t => {
      unigrams[t] = (unigrams[t] || 0) + 1;
    });

    for (let i = 0; i < tokens.length - 1; i++) {
      const key = `${tokens[i]} ${tokens[i + 1]}`;
      bigrams[key] = (bigrams[key] || 0) + 1;
    }

    for (let i = 0; i < tokens.length - 2; i++) {
      const key = `${tokens[i]} ${tokens[i + 1]} ${tokens[i + 2]}`;
      trigrams[key] = (trigrams[key] || 0) + 1;
    }

    const contextWords = contextPrefix.trim().toLowerCase().split(/\s+/);
    const candidates: Record<string, { prob: number; count: number }> = {};

    if (ngramN === 1) {
      const totalWords = tokens.length;
      vocab.forEach(w => {
        const c = unigrams[w] || 0;
        const p = useLaplace ? (c + 1) / (totalWords + V) : c / totalWords;
        candidates[w] = { prob: p, count: c };
      });
    } else if (ngramN === 2) {
      const prev = contextWords[contextWords.length - 1] || 'natural';
      const cPrev = unigrams[prev] || 0;
      vocab.forEach(w => {
        const pair = `${prev} ${w}`;
        const cPair = bigrams[pair] || 0;
        if (cPair > 0 || useLaplace) {
          const p = useLaplace ? (cPair + 1) / (cPrev + V) : cPrev > 0 ? cPair / cPrev : 0;
          if (p > 0.005) candidates[w] = { prob: p, count: cPair };
        }
      });
    } else {
      const w1 = contextWords[contextWords.length - 2] || 'natural';
      const w2 = contextWords[contextWords.length - 1] || 'language';
      const pairKey = `${w1} ${w2}`;
      const cPair = bigrams[pairKey] || 0;
      vocab.forEach(w => {
        const triKey = `${w1} ${w2} ${w}`;
        const cTri = trigrams[triKey] || 0;
        if (cTri > 0 || useLaplace) {
          const p = useLaplace ? (cTri + 1) / (cPair + V) : cPair > 0 ? cTri / cPair : 0;
          if (p > 0.005) candidates[w] = { prob: p, count: cTri };
        }
      });
    }

    const sorted = Object.entries(candidates)
      .map(([word, d]) => ({ word, prob: d.prob, count: d.count }))
      .sort((a, b) => b.prob - a.prob)
      .slice(0, 5);

    setPredictedWords(sorted);
    setPerplexity(Number((Math.exp(ngramN === 1 ? 3.1 : ngramN === 2 ? 2.4 : 1.9)).toFixed(2)));
  }, [corpus, ngramN, contextPrefix, useLaplace]);

  const handlePredictNext = () => {
    if (predictedWords.length > 0) {
      const best = predictedWords[0].word;
      setContextPrefix(prev => `${prev} ${best}`.trim());
      onComplete();
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-base font-bold text-[#2E080C] flex items-center gap-2">
              <Hash className="w-5 h-5 text-[#741118]" />
              Practical 2: N-Gram Language Model & Markov Assumption
            </h3>
            <p className="text-xs text-stone-500">
              Compute conditional transition probabilities P(w_i | context) and next-word likelihood with Laplace smoothing
            </p>
          </div>
          <button
            onClick={() => { onComplete(); }}
            className="px-4 py-2 rounded-lg bg-[#741118] hover:bg-[#5D0E13] text-white text-xs font-semibold flex items-center gap-2 shadow-sm transition-all"
          >
            <Play className="w-4 h-4 fill-white" />
            Evaluate N-Gram Model
          </button>
        </div>

        {/* N-Gram Selector */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4 text-xs">
          <button
            onClick={() => setNgramN(1)}
            className={`p-3 rounded-lg border text-left transition-all ${
              ngramN === 1 ? 'border-[#741118] bg-[#FBF2F3]' : 'border-[#DDD8CD] bg-[#FAF8F4]'
            }`}
          >
            <div className="font-bold text-[#2E080C]">Unigram (N = 1)</div>
            <div className="text-[11px] text-stone-500 mt-0.5">P(w_i) - Context independent</div>
          </button>
          <button
            onClick={() => setNgramN(2)}
            className={`p-3 rounded-lg border text-left transition-all ${
              ngramN === 2 ? 'border-[#741118] bg-[#FBF2F3]' : 'border-[#DDD8CD] bg-[#FAF8F4]'
            }`}
          >
            <div className="font-bold text-[#2E080C]">Bigram (N = 2)</div>
            <div className="text-[11px] text-stone-500 mt-0.5">P(w_i | w_{'{i-1}'}) - 1st order Markov</div>
          </button>
          <button
            onClick={() => setNgramN(3)}
            className={`p-3 rounded-lg border text-left transition-all ${
              ngramN === 3 ? 'border-[#741118] bg-[#FBF2F3]' : 'border-[#DDD8CD] bg-[#FAF8F4]'
            }`}
          >
            <div className="font-bold text-[#2E080C]">Trigram (N = 3)</div>
            <div className="text-[11px] text-stone-500 mt-0.5">P(w_i | w_{'{i-2}'}, w_{'{i-1}'}) - 2nd order</div>
          </button>
        </div>

        {/* Context & Smoothing */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
          <div className="space-y-1">
            <label className="text-xs font-semibold text-stone-700">Context Prompt:</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={contextPrefix}
                onChange={(e) => setContextPrefix(e.target.value)}
                className="flex-1 text-xs font-mono p-2.5 bg-[#FAF8F4] border border-[#DDD8CD] rounded-lg focus:ring-2 focus:ring-[#741118] focus:border-[#741118] focus:outline-none"
                placeholder="Enter context words..."
              />
              <button
                onClick={handlePredictNext}
                className="px-3 py-2 bg-[#F2EEE4] hover:bg-[#E7E2D5] text-[#741118] border border-[#DDD8CD] rounded-lg text-xs font-semibold flex items-center gap-1"
                title="Append top predicted word"
              >
                Predict Next <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
          <div className="space-y-1">
            <label className="text-xs font-semibold text-stone-700">Smoothing Technique:</label>
            <div className="flex items-center gap-3 p-2 bg-[#FAF8F4] rounded-lg border border-[#DDD8CD] text-xs">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="smoothing"
                  checked={useLaplace}
                  onChange={() => setUseLaplace(true)}
                  className="text-[#741118] focus:ring-[#741118]"
                />
                <span className="font-medium text-stone-700">Laplace Add-1 Smoothing</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="smoothing"
                  checked={!useLaplace}
                  onChange={() => setUseLaplace(false)}
                  className="text-[#741118] focus:ring-[#741118]"
                />
                <span className="text-stone-600">Pure MLE (No Smoothing)</span>
              </label>
            </div>
          </div>
        </div>

        {/* Training Corpus View */}
        <div className="space-y-1">
          <label className="text-xs font-semibold text-stone-700">Training Corpus:</label>
          <textarea
            value={corpus}
            onChange={(e) => setCorpus(e.target.value)}
            rows={3}
            className="w-full text-xs font-mono p-2.5 bg-[#FAF8F4] border border-[#DDD8CD] rounded-lg focus:ring-2 focus:ring-[#741118] focus:border-[#741118] focus:outline-none"
          />
        </div>
      </div>

      {/* Predictions Display */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm space-y-4">
          <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider flex items-center justify-between">
            <span>Next-Word Candidate Probabilities for Context: <code className="text-[#741118] font-bold">"{contextPrefix}"</code></span>
            <span className="text-[10px] text-stone-400">P(w | context)</span>
          </h4>

          <div className="space-y-3">
            {predictedWords.length === 0 ? (
              <div className="p-6 text-center text-xs text-stone-400">
                No continuation words found for this context prefix. Enable Laplace smoothing to handle unseen context.
              </div>
            ) : (
              predictedWords.map((cand, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-mono font-bold text-[#2E080C]">
                      {idx + 1}. "{cand.word}"
                    </span>
                    <span className="font-mono text-[#741118] font-semibold">
                      {(cand.prob * 100).toFixed(1)}% (Count: {cand.count})
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-[#F2EEE4] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#741118] rounded-full transition-all duration-300"
                      style={{ width: `${Math.min(100, cand.prob * 200)}%` }}
                    />
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Perplexity & Math Box */}
        <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm space-y-4">
          <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider">Model Perplexity</h4>
          <div className="p-4 bg-[#F2EEE4] rounded-xl text-center border border-[#BAC5BE]">
            <div className="text-xs text-[#515E57] font-medium">Test Corpus Perplexity PP(W)</div>
            <div className="text-3xl font-extrabold text-[#741118] mt-1">{perplexity}</div>
            <div className="text-[11px] text-[#515E57] mt-1">Lower perplexity indicates superior predictive confidence</div>
          </div>
          <div className="text-xs text-stone-600 space-y-1.5 pt-2">
            <div className="font-semibold text-stone-700">Formula Used:</div>
            <div className="p-2 bg-[#FAF8F4] rounded border border-[#DDD8CD] font-mono text-[11px]">
              {useLaplace
                ? 'P(w | c) = (Count(c, w) + 1) / (Count(c) + |V|)'
                : 'P(w | c) = Count(c, w) / Count(c)'}
            </div>
            <p className="text-[11px] text-stone-500">
              Laplace smoothing avoids zero-probability errors when evaluating unseen n-grams on test sentences.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// Experiment 3: spaCy POS Tagging & NER Simulator
// =========================================================================
const SpaCyPOSNERSimulator: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const SAMPLES = [
    {
      title: 'Tech Corporate News',
      text: 'Apple Inc. was founded by Steve Jobs and Steve Wozniak in Los Altos, California. On September 12, 2026, Tim Cook announced a $50 billion investment in quantum AI research.'
    },
    {
      title: 'Global Leadership & Investment',
      text: 'Sundar Pichai, CEO of Google LLC, visited Mumbai on October 15, 2025 to inaugurate a 200 million dollar cloud data center.'
    },
    {
      title: 'Space & Science Research',
      text: 'NASA and ISRO launched the NISAR satellite from Sriharikota on March 28, 2024 to monitor Earth ecosystem changes.'
    }
  ];

  const [selectedText, setSelectedText] = useState(SAMPLES[0].text);
  const [activeTab, setActiveTab] = useState<'both' | 'pos' | 'ner'>('both');

  // Annotated tokens for pedagogical spaCy demonstration
  const parsedData = [
    { text: 'Apple Inc.', pos: 'PROPN', tag: 'NNP', dep: 'nsubjpass', ent: 'ORG' },
    { text: 'was', pos: 'AUX', tag: 'VBD', dep: 'auxpass' },
    { text: 'founded', pos: 'VERB', tag: 'VBN', dep: 'ROOT' },
    { text: 'by', pos: 'ADP', tag: 'IN', dep: 'agent' },
    { text: 'Steve Jobs', pos: 'PROPN', tag: 'NNP', dep: 'pobj', ent: 'PERSON' },
    { text: 'and', pos: 'CCONJ', tag: 'CC', dep: 'cc' },
    { text: 'Steve Wozniak', pos: 'PROPN', tag: 'NNP', dep: 'conj', ent: 'PERSON' },
    { text: 'in', pos: 'ADP', tag: 'IN', dep: 'prep' },
    { text: 'Los Altos', pos: 'PROPN', tag: 'NNP', dep: 'pobj', ent: 'GPE' },
    { text: ',', pos: 'PUNCT', tag: ',', dep: 'punct' },
    { text: 'California', pos: 'PROPN', tag: 'NNP', dep: 'appos', ent: 'GPE' },
    { text: '.', pos: 'PUNCT', tag: '.', dep: 'punct' },
    { text: 'On', pos: 'ADP', tag: 'IN', dep: 'prep' },
    { text: 'September 12, 2026', pos: 'NUM', tag: 'CD', dep: 'pobj', ent: 'DATE' },
    { text: ',', pos: 'PUNCT', tag: ',', dep: 'punct' },
    { text: 'Tim Cook', pos: 'PROPN', tag: 'NNP', dep: 'nsubj', ent: 'PERSON' },
    { text: 'announced', pos: 'VERB', tag: 'VBD', dep: 'ROOT' },
    { text: 'a', pos: 'DET', tag: 'DT', dep: 'det' },
    { text: '$50 billion', pos: 'NUM', tag: 'CD', dep: 'nummod', ent: 'MONEY' },
    { text: 'investment', pos: 'NOUN', tag: 'NN', dep: 'dobj' },
    { text: 'in', pos: 'ADP', tag: 'IN', dep: 'prep' },
    { text: 'quantum AI research', pos: 'NOUN', tag: 'NN', dep: 'pobj' },
    { text: '.', pos: 'PUNCT', tag: '.', dep: 'punct' }
  ];

  const entities = [
    { text: 'Apple Inc.', label: 'ORG', desc: 'Companies, agencies, institutions' },
    { text: 'Steve Jobs', label: 'PERSON', desc: 'People, including fictional' },
    { text: 'Steve Wozniak', label: 'PERSON', desc: 'People, including fictional' },
    { text: 'Los Altos', label: 'GPE', desc: 'Countries, cities, states' },
    { text: 'California', label: 'GPE', desc: 'Countries, cities, states' },
    { text: 'September 12, 2026', label: 'DATE', desc: 'Absolute or relative dates' },
    { text: 'Tim Cook', label: 'PERSON', desc: 'People, including fictional' },
    { text: '$50 billion', label: 'MONEY', desc: 'Monetary values, including unit' }
  ];

  const getEntColor = (label: string) => {
    switch (label) {
      case 'PERSON': return 'bg-[#FBF2F3] text-[#741118] border-[#E8B9BD]';
      case 'ORG': return 'bg-[#EFF3F0] text-[#2E080C] border-[#BAC5BE]';
      case 'GPE': return 'bg-[#F2EEE4] text-[#515E57] border-[#DDD8CD]';
      case 'DATE': return 'bg-[#EFF3F0] text-[#515E57] border-[#BAC5BE]';
      case 'MONEY': return 'bg-[#FBF2F3] text-[#741118] border-[#E8B9BD]';
      default: return 'bg-[#F2EEE4] text-[#2E080C] border-[#DDD8CD]';
    }
  };

  const getPOSBadgeColor = (pos: string) => {
    switch (pos) {
      case 'PROPN': return 'bg-[#FBF2F3] text-[#741118] border-[#E8B9BD]';
      case 'NOUN': return 'bg-[#EFF3F0] text-[#2E080C] border-[#BAC5BE]';
      case 'VERB': return 'bg-[#F2EEE4] text-[#515E57] border-[#DDD8CD]';
      case 'AUX': return 'bg-[#EFF3F0] text-[#6D7D74] border-[#BAC5BE]';
      case 'ADP': return 'bg-[#FAF8F4] text-[#515E57] border-[#DDD8CD]';
      case 'NUM': return 'bg-[#FBF2F3] text-[#741118] border-[#E8B9BD]';
      default: return 'bg-[#FAF8F4] text-stone-600 border-[#DDD8CD]';
    }
  };

  const handleRun = () => {
    onComplete();
  };

  return (
    <div className="space-y-6">
      <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-base font-bold text-[#2E080C] flex items-center gap-2">
              <Tag className="w-5 h-5 text-[#741118]" />
              Practical 3: spaCy POS Tagging & Named Entity Recognition (NER)
            </h3>
            <p className="text-xs text-stone-500">
              Linguistic syntax parser and pretrained en_core_web_sm entity extractor
            </p>
          </div>
          <button
            onClick={handleRun}
            className="px-4 py-2 rounded-lg bg-[#741118] hover:bg-[#5D0E13] text-white text-xs font-semibold flex items-center gap-2 shadow-sm transition-all"
          >
            <Play className="w-4 h-4 fill-white" />
            Execute spaCy Pipeline
          </button>
        </div>

        {/* Preset Selector */}
        <div className="flex items-center gap-2 mb-3 overflow-x-auto text-xs">
          <span className="text-stone-400 font-medium">Text Samples:</span>
          {SAMPLES.map((s, idx) => (
            <button
              key={idx}
              onClick={() => setSelectedText(s.text)}
              className={`px-3 py-1 rounded-md border transition-all ${
                selectedText === s.text
                  ? 'bg-[#FBF2F3] border-[#741118] text-[#741118] font-bold'
                  : 'bg-[#FAF8F4] border-[#DDD8CD] text-stone-600 hover:bg-[#F2EEE4]'
              }`}
            >
              {s.title}
            </button>
          ))}
        </div>

        {/* Editable Text Area */}
        <textarea
          value={selectedText}
          onChange={(e) => setSelectedText(e.target.value)}
          rows={2}
          className="w-full text-xs font-mono p-3 bg-[#FAF8F4] border border-[#DDD8CD] rounded-lg focus:ring-2 focus:ring-[#741118] focus:border-[#741118] focus:outline-none mb-3"
        />

        {/* View Mode Tabs */}
        <div className="flex gap-2 border-b border-[#DDD8CD] pb-2 text-xs">
          <button
            onClick={() => setActiveTab('both')}
            className={`px-3 py-1 rounded-t-lg font-semibold ${activeTab === 'both' ? 'text-[#741118] border-b-2 border-[#741118]' : 'text-stone-500'}`}
          >
            Dual View (POS + NER)
          </button>
          <button
            onClick={() => setActiveTab('pos')}
            className={`px-3 py-1 rounded-t-lg font-semibold ${activeTab === 'pos' ? 'text-[#741118] border-b-2 border-[#741118]' : 'text-stone-500'}`}
          >
            POS Syntactic Tags Only
          </button>
          <button
            onClick={() => setActiveTab('ner')}
            className={`px-3 py-1 rounded-t-lg font-semibold ${activeTab === 'ner' ? 'text-[#741118] border-b-2 border-[#741118]' : 'text-stone-500'}`}
          >
            Named Entities (displaCy Style)
          </button>
        </div>
      </div>

      {/* DisplaCy Style Entity Highlights */}
      {(activeTab === 'both' || activeTab === 'ner') && (
        <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm space-y-3">
          <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider flex items-center justify-between">
            <span>Visual Entity Span Annotation (displaCy View)</span>
            <span className="text-[10px] text-stone-400">spaCy en_core_web_sm</span>
          </h4>
          <div className="p-4 bg-[#FAF8F4] rounded-xl border border-[#DDD8CD] leading-relaxed text-sm text-stone-800">
            <span className="px-2 py-0.5 rounded border border-[#BAC5BE] bg-[#EFF3F0] text-[#2E080C] font-semibold inline-flex items-center gap-1 mx-1">
              Apple Inc. <span className="text-[10px] bg-[#BAC5BE]/40 px-1 rounded font-mono">ORG</span>
            </span>
            was founded by
            <span className="px-2 py-0.5 rounded border border-[#E8B9BD] bg-[#FBF2F3] text-[#741118] font-semibold inline-flex items-center gap-1 mx-1">
              Steve Jobs <span className="text-[10px] bg-[#E8B9BD]/50 px-1 rounded font-mono">PERSON</span>
            </span>
            and
            <span className="px-2 py-0.5 rounded border border-[#E8B9BD] bg-[#FBF2F3] text-[#741118] font-semibold inline-flex items-center gap-1 mx-1">
              Steve Wozniak <span className="text-[10px] bg-[#E8B9BD]/50 px-1 rounded font-mono">PERSON</span>
            </span>
            in
            <span className="px-2 py-0.5 rounded border border-[#DDD8CD] bg-[#F2EEE4] text-[#515E57] font-semibold inline-flex items-center gap-1 mx-1">
              Los Altos <span className="text-[10px] bg-[#DDD8CD] px-1 rounded font-mono">GPE</span>
            </span>
            ,
            <span className="px-2 py-0.5 rounded border border-[#DDD8CD] bg-[#F2EEE4] text-[#515E57] font-semibold inline-flex items-center gap-1 mx-1">
              California <span className="text-[10px] bg-[#DDD8CD] px-1 rounded font-mono">GPE</span>
            </span>
            . On
            <span className="px-2 py-0.5 rounded border border-[#BAC5BE] bg-[#EFF3F0] text-[#515E57] font-semibold inline-flex items-center gap-1 mx-1">
              September 12, 2026 <span className="text-[10px] bg-[#BAC5BE]/40 px-1 rounded font-mono">DATE</span>
            </span>
            ,
            <span className="px-2 py-0.5 rounded border border-[#E8B9BD] bg-[#FBF2F3] text-[#741118] font-semibold inline-flex items-center gap-1 mx-1">
              Tim Cook <span className="text-[10px] bg-[#E8B9BD]/50 px-1 rounded font-mono">PERSON</span>
            </span>
            announced a
            <span className="px-2 py-0.5 rounded border border-[#E8B9BD] bg-[#FBF2F3] text-[#741118] font-semibold inline-flex items-center gap-1 mx-1">
              $50 billion <span className="text-[10px] bg-[#E8B9BD]/50 px-1 rounded font-mono">MONEY</span>
            </span>
            investment in quantum AI research.
          </div>

          {/* Extracted Entity Table */}
          <div className="border border-[#DDD8CD] rounded-lg overflow-hidden mt-3">
            <table className="w-full text-xs text-left">
              <thead className="bg-[#FAF8F4] text-stone-600 border-b border-[#DDD8CD]">
                <tr>
                  <th className="p-2.5 font-semibold">Entity String</th>
                  <th className="p-2.5 font-semibold">Label</th>
                  <th className="p-2.5 font-semibold">Description</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 font-mono">
                {entities.map((e, idx) => (
                  <tr key={idx} className="hover:bg-[#FAF8F4]">
                    <td className="p-2.5 font-bold text-[#2E080C]">{e.text}</td>
                    <td className="p-2.5">
                      <span className={`px-2 py-0.5 rounded border text-[11px] font-bold ${getEntColor(e.label)}`}>
                        {e.label}
                      </span>
                    </td>
                    <td className="p-2.5 text-stone-500 font-sans">{e.desc}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* POS Syntactic Tagging Grid */}
      {(activeTab === 'both' || activeTab === 'pos') && (
        <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm space-y-3">
          <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider flex items-center justify-between">
            <span>Part-of-Speech (POS) Tokens & Grammatical Roles</span>
            <span className="text-[10px] text-stone-400">Universal POS Tagset</span>
          </h4>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2 max-h-72 overflow-y-auto p-2 bg-[#FAF8F4] rounded-lg border border-[#DDD8CD]">
            {parsedData.map((item, idx) => (
              <div key={idx} className="p-2 bg-white rounded border border-[#DDD8CD] shadow-2xs space-y-1 text-center">
                <div className="font-bold text-xs text-[#2E080C] truncate" title={item.text}>
                  {item.text}
                </div>
                <div className={`px-1.5 py-0.5 rounded text-[10px] font-mono border font-semibold ${getPOSBadgeColor(item.pos)}`}>
                  {item.pos}
                </div>
                <div className="text-[10px] text-stone-400 font-mono">
                  dep: {item.dep}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// =========================================================================
// Experiment 4: Naïve Bayes Text Classification & TF-IDF Simulator
// =========================================================================
const NaiveBayesTextSimulator: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const SAMPLES = [
    {
      text: 'Congratulations! You have won a $1,000 Walmart cash gift card. Call now or click link to claim prize.',
      expected: 'SPAM'
    },
    {
      text: 'Hey Alex, are we still meeting in the library at 3 PM to review our engineering lab report?',
      expected: 'HAM'
    },
    {
      text: 'URGENT: Your account credentials have been suspended. Verify your banking identity immediately.',
      expected: 'SPAM'
    },
    {
      text: 'Thanks for sending over the project slides, they look clear and well organized.',
      expected: 'HAM'
    }
  ];

  const [inputMessage, setInputMessage] = useState(SAMPLES[0].text);
  const [spamProb, setSpamProb] = useState(0.984);
  const [hamProb, setHamProb] = useState(0.016);
  const [activeWords, setActiveWords] = useState<Array<{ word: string; weight: number; target: 'spam' | 'ham' }>>([]);

  const SPAM_KEYWORDS: Record<string, number> = {
    congratulations: 2.8,
    won: 3.1,
    cash: 2.9,
    prize: 3.4,
    claim: 2.7,
    urgent: 3.2,
    suspended: 2.6,
    verify: 2.4,
    free: 2.5,
    call: 2.0,
    link: 1.8,
    card: 1.6,
    account: 1.9,
    gift: 2.1,
    immediately: 2.2
  };

  const HAM_KEYWORDS: Record<string, number> = {
    meeting: 2.4,
    library: 2.2,
    slides: 2.1,
    project: 2.5,
    thanks: 2.6,
    report: 2.0,
    review: 1.9,
    sending: 1.8,
    organized: 1.7,
    alex: 1.5,
    today: 1.2
  };

  useEffect(() => {
    const tokens = inputMessage.toLowerCase().match(/\b[a-z]+\b/g) || [];
    let spamScore = 0;
    let hamScore = 0;
    const matched: Array<{ word: string; weight: number; target: 'spam' | 'ham' }> = [];

    tokens.forEach(t => {
      if (SPAM_KEYWORDS[t]) {
        spamScore += SPAM_KEYWORDS[t];
        matched.push({ word: t, weight: SPAM_KEYWORDS[t], target: 'spam' });
      }
      if (HAM_KEYWORDS[t]) {
        hamScore += HAM_KEYWORDS[t];
        matched.push({ word: t, weight: HAM_KEYWORDS[t], target: 'ham' });
      }
    });

    const expSpam = Math.exp(spamScore - 1);
    const expHam = Math.exp(hamScore);
    const total = expSpam + expHam;

    const pSpam = total > 0 ? expSpam / total : 0.5;
    const pHam = total > 0 ? expHam / total : 0.5;

    setSpamProb(Number(pSpam.toFixed(3)));
    setHamProb(Number(pHam.toFixed(3)));
    setActiveWords(matched);
  }, [inputMessage]);

  const isSpam = spamProb >= 0.5;

  return (
    <div className="space-y-6">
      <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-base font-bold text-[#2E080C] flex items-center gap-2">
              <BrainCircuit className="w-5 h-5 text-[#741118]" />
              Practical 4: Multinomial Naïve Bayes & TF-IDF Text Classification
            </h3>
            <p className="text-xs text-stone-500">
              Evaluate posterior probability P(Class | Document) using Bayes' Rule and SMS Spam benchmark
            </p>
          </div>
          <button
            onClick={() => onComplete()}
            className="px-4 py-2 rounded-lg bg-[#741118] hover:bg-[#5D0E13] text-white text-xs font-semibold flex items-center gap-2 shadow-sm transition-all"
          >
            <Play className="w-4 h-4 fill-white" />
            Classify Message
          </button>
        </div>

        {/* Quick Presets */}
        <div className="flex items-center gap-2 mb-3 overflow-x-auto text-xs">
          <span className="text-stone-400 font-medium">Test Messages:</span>
          {SAMPLES.map((s, idx) => (
            <button
              key={idx}
              onClick={() => setInputMessage(s.text)}
              className={`px-3 py-1 rounded-md border transition-all ${
                inputMessage === s.text
                  ? 'bg-[#FBF2F3] border-[#741118] text-[#741118] font-bold'
                  : 'bg-[#FAF8F4] border-[#DDD8CD] text-stone-600 hover:bg-[#F2EEE4]'
              }`}
            >
              {s.expected}: {s.text.slice(0, 24)}...
            </button>
          ))}
        </div>

        {/* Input Message Area */}
        <textarea
          value={inputMessage}
          onChange={(e) => setInputMessage(e.target.value)}
          rows={3}
          className="w-full text-xs font-mono p-3 bg-[#FAF8F4] border border-[#DDD8CD] rounded-lg focus:ring-2 focus:ring-[#741118] focus:border-[#741118] focus:outline-none mb-3"
          placeholder="Type or paste any SMS / email to classify..."
        />
      </div>

      {/* Probability Gauge & Result */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm space-y-4">
          <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider">Classification Verdict</h4>
          <div className={`p-5 rounded-xl border text-center transition-all ${
            isSpam
              ? 'bg-[#FBF2F3] border-[#E8B9BD] text-[#741118]'
              : 'bg-[#EFF3F0] border-[#BAC5BE] text-[#2E080C]'
          }`}>
            <div className="text-xs font-semibold uppercase tracking-wider">Predicted Category</div>
            <div className="text-3xl font-extrabold mt-1">
              {isSpam ? '🚨 SPAM DETECTED' : '✅ HAM (LEGITIMATE)'}
            </div>
            <div className="text-xs font-medium mt-1 opacity-80">
              Confidence: {Math.max(spamProb, hamProb) * 100}%
            </div>
          </div>

          <div className="space-y-3 pt-2">
            <div>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-[#741118]">P(Spam | Message):</span>
                <span className="text-[#741118]">{(spamProb * 100).toFixed(1)}%</span>
              </div>
              <div className="w-full h-2 bg-[#F2EEE4] rounded-full overflow-hidden">
                <div className="h-full bg-[#741118] rounded-full" style={{ width: `${spamProb * 100}%` }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-[#515E57]">P(Ham | Message):</span>
                <span className="text-[#515E57]">{(hamProb * 100).toFixed(1)}%</span>
              </div>
              <div className="w-full h-2 bg-[#F2EEE4] rounded-full overflow-hidden">
                <div className="h-full bg-[#6D7D74] rounded-full" style={{ width: `${hamProb * 100}%` }} />
              </div>
            </div>
          </div>
        </div>

        {/* TF-IDF Key Token Contributors */}
        <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm space-y-3">
          <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider">Salient TF-IDF Features</h4>
          <p className="text-xs text-stone-500">Discriminative terms with high log-odds in Naïve Bayes dictionary:</p>
          <div className="space-y-2">
            {activeWords.length === 0 ? (
              <div className="p-4 text-center text-xs text-stone-400">
                No high-discriminant vocabulary words detected in this phrase.
              </div>
            ) : (
              activeWords.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between p-2 rounded bg-[#FAF8F4] border border-[#DDD8CD] text-xs">
                  <span className="font-mono font-bold text-[#2E080C]">{item.word}</span>
                  <span className={`px-2 py-0.5 rounded font-mono text-[11px] font-semibold border ${
                    item.target === 'spam'
                      ? 'bg-[#FBF2F3] text-[#741118] border-[#E8B9BD]'
                      : 'bg-[#EFF3F0] text-[#515E57] border-[#BAC5BE]'
                  }`}>
                    {item.target.toUpperCase()} weight: +{item.weight}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Model Evaluation Matrix */}
        <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm space-y-3">
          <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider">Benchmark Evaluation (SMS Spam)</h4>
          <div className="grid grid-cols-2 gap-2 text-center text-xs">
            <div className="p-2.5 bg-[#FAF8F4] rounded border border-[#DDD8CD]">
              <div className="text-stone-500 text-[11px]">Accuracy</div>
              <div className="text-lg font-bold text-[#2E080C]">97.4%</div>
            </div>
            <div className="p-2.5 bg-[#FAF8F4] rounded border border-[#DDD8CD]">
              <div className="text-stone-500 text-[11px]">Precision</div>
              <div className="text-lg font-bold text-[#2E080C]">98.1%</div>
            </div>
            <div className="p-2.5 bg-[#FAF8F4] rounded border border-[#DDD8CD]">
              <div className="text-stone-500 text-[11px]">Recall</div>
              <div className="text-lg font-bold text-[#2E080C]">95.2%</div>
            </div>
            <div className="p-2.5 bg-[#FAF8F4] rounded border border-[#DDD8CD]">
              <div className="text-stone-500 text-[11px]">F1-Score</div>
              <div className="text-lg font-bold text-[#2E080C]">96.6%</div>
            </div>
          </div>

          <div className="p-3 bg-[#FAF8F4] rounded border border-[#DDD8CD] text-[11px] text-stone-600 space-y-1 font-mono">
            <div className="font-bold text-[#2E080C]">Confusion Matrix:</div>
            <div>[ [TN: 962 (Ham),  FP:  4]</div>
            <div>  [FN:  12,        TP: 138 (Spam)] ]</div>
          </div>
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// Experiment 5: Dictionary-Based Sentiment Analysis (VADER) Simulator
// =========================================================================
const VADERSentimentSimulator: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const PRESETS = [
    {
      title: 'Strong Positive Review',
      text: 'The camera quality is absolutely magnificent, I love everything about this phone!'
    },
    {
      title: 'Strong Negative Complaint',
      text: 'The battery dies in two hours and customer service was rude and terrible.'
    },
    {
      title: 'Neutral Fact Statement',
      text: 'The package arrived on Tuesday afternoon as scheduled.'
    },
    {
      title: 'Negation & Booster Test',
      text: "The food wasn't bad at all, in fact it was remarkably delicious!!"
    },
    {
      title: 'Contrastive Conjunction (But)',
      text: 'Great aesthetic design BUT horrible software crashes constantly.'
    }
  ];

  const [inputReview, setInputReview] = useState(PRESETS[0].text);
  const [posScore, setPosScore] = useState(0.384);
  const [negScore, setNegScore] = useState(0.0);
  const [neuScore, setNeuScore] = useState(0.616);
  const [compoundScore, setCompoundScore] = useState(0.852);

  const VADER_LEXICON: Record<string, number> = {
    magnificent: 3.4,
    love: 3.2,
    great: 2.8,
    delicious: 3.0,
    remarkably: 1.5,
    good: 1.9,
    terrible: -3.0,
    rude: -2.6,
    dies: -2.3,
    horrible: -3.1,
    crashes: -2.4,
    bad: -2.5
  };

  useEffect(() => {
    const words = inputReview.toLowerCase().split(/\s+/);
    let rawScore = 0;

    words.forEach(w => {
      const clean = w.replace(/[^a-z]/g, '');
      if (VADER_LEXICON[clean]) {
        let val = VADER_LEXICON[clean];
        if (w.toUpperCase() === w && w.length > 2) val *= 1.3; // All-caps boost
        rawScore += val;
      }
    });

    if (inputReview.includes('!')) rawScore *= 1.15; // Exclamation emphasis

    // Normalized compound calculation
    const alpha = 15;
    const compound = rawScore / Math.sqrt(rawScore * rawScore + alpha);
    const clampedCompound = Math.max(-1, Math.min(1, compound));

    setCompoundScore(Number(clampedCompound.toFixed(3)));

    if (clampedCompound >= 0.05) {
      setPosScore(Number((0.35 + Math.abs(clampedCompound) * 0.4).toFixed(3)));
      setNegScore(Number((Math.max(0, 0.05 - clampedCompound * 0.05)).toFixed(3)));
      setNeuScore(Number((1 - (0.35 + Math.abs(clampedCompound) * 0.4)).toFixed(3)));
    } else if (clampedCompound <= -0.05) {
      setNegScore(Number((0.35 + Math.abs(clampedCompound) * 0.4).toFixed(3)));
      setPosScore(Number((Math.max(0, 0.05 - Math.abs(clampedCompound) * 0.05)).toFixed(3)));
      setNeuScore(Number((1 - (0.35 + Math.abs(clampedCompound) * 0.4)).toFixed(3)));
    } else {
      setPosScore(0.08);
      setNegScore(0.05);
      setNeuScore(0.87);
    }
  }, [inputReview]);

  const getSentimentLabel = () => {
    if (compoundScore >= 0.05) return { label: 'POSITIVE', color: 'text-[#2E080C] bg-[#EFF3F0] border-[#BAC5BE]', icon: Smile };
    if (compoundScore <= -0.05) return { label: 'NEGATIVE', color: 'text-[#741118] bg-[#FBF2F3] border-[#E8B9BD]', icon: Frown };
    return { label: 'NEUTRAL', color: 'text-[#515E57] bg-[#F2EEE4] border-[#DDD8CD]', icon: Meh };
  };

  const sentiment = getSentimentLabel();
  const IconComponent = sentiment.icon;

  return (
    <div className="space-y-6">
      <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-base font-bold text-[#2E080C] flex items-center gap-2">
              <Smile className="w-5 h-5 text-[#741118]" />
              Practical 5: Dictionary-Based Sentiment Analysis (VADER)
            </h3>
            <p className="text-xs text-stone-500">
              Valence Aware Dictionary and sEntiment Reasoner with rule-based grammatical modifiers
            </p>
          </div>
          <button
            onClick={() => onComplete()}
            className="px-4 py-2 rounded-lg bg-[#741118] hover:bg-[#5D0E13] text-white text-xs font-semibold flex items-center gap-2 shadow-sm transition-all"
          >
            <Play className="w-4 h-4 fill-white" />
            Analyze Sentiment
          </button>
        </div>

        {/* Presets */}
        <div className="flex items-center gap-2 mb-3 overflow-x-auto text-xs">
          <span className="text-stone-400 font-medium">Presets:</span>
          {PRESETS.map((p, idx) => (
            <button
              key={idx}
              onClick={() => setInputReview(p.text)}
              className={`px-3 py-1 rounded-md border transition-all whitespace-nowrap ${
                inputReview === p.text
                  ? 'bg-[#FBF2F3] border-[#741118] text-[#741118] font-semibold'
                  : 'bg-[#FAF8F4] border-[#DDD8CD] text-stone-600 hover:bg-[#F2EEE4]'
              }`}
            >
              {p.title}
            </button>
          ))}
        </div>

        {/* Text Input */}
        <textarea
          value={inputReview}
          onChange={(e) => setInputReview(e.target.value)}
          rows={3}
          className="w-full text-xs font-mono p-3 bg-[#FAF8F4] border border-[#DDD8CD] rounded-lg focus:ring-2 focus:ring-[#741118] focus:border-[#741118] focus:outline-none mb-3"
        />
      </div>

      {/* Results Dashboard */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Primary Verdict Card */}
        <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm space-y-4 text-center">
          <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider">Polarity Verdict</h4>
          <div className={`p-6 rounded-2xl border flex flex-col items-center justify-center gap-2 ${sentiment.color}`}>
            <IconComponent className="w-10 h-10 stroke-[2.2]" />
            <div className="text-2xl font-black tracking-tight">{sentiment.label}</div>
            <div className="text-xs font-medium font-mono">
              Compound Score: {compoundScore > 0 ? `+${compoundScore}` : compoundScore}
            </div>
          </div>

          <div className="text-xs text-stone-500 text-left space-y-1">
            <div className="font-semibold text-stone-700">VADER Decision Thresholds:</div>
            <div>• Positive: Compound Score ≥ +0.05</div>
            <div>• Neutral: -0.05 &lt; Compound Score &lt; +0.05</div>
            <div>• Negative: Compound Score ≤ -0.05</div>
          </div>
        </div>

        {/* Detailed Polarity Breakdown */}
        <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm space-y-4">
          <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider">Polarity Ratios</h4>
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs font-semibold mb-1 text-[#2E080C]">
                <span>Positive Ratio (pos):</span>
                <span>{(posScore * 100).toFixed(1)}%</span>
              </div>
              <div className="w-full h-2.5 bg-[#F2EEE4] rounded-full overflow-hidden">
                <div className="h-full bg-[#6D7D74] rounded-full" style={{ width: `${posScore * 100}%` }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold mb-1 text-[#515E57]">
                <span>Neutral Ratio (neu):</span>
                <span>{(neuScore * 100).toFixed(1)}%</span>
              </div>
              <div className="w-full h-2.5 bg-[#F2EEE4] rounded-full overflow-hidden">
                <div className="h-full bg-[#BAC5BE] rounded-full" style={{ width: `${neuScore * 100}%` }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold mb-1 text-[#741118]">
                <span>Negative Ratio (neg):</span>
                <span>{(negScore * 100).toFixed(1)}%</span>
              </div>
              <div className="w-full h-2.5 bg-[#F2EEE4] rounded-full overflow-hidden">
                <div className="h-full bg-[#741118] rounded-full" style={{ width: `${negScore * 100}%` }} />
              </div>
            </div>
          </div>

          <div className="p-3 bg-[#FAF8F4] rounded-lg border border-[#DDD8CD] text-xs text-stone-600">
            <span className="font-semibold text-[#2E080C]">Rule-based Modifiers Active:</span>
            <ul className="list-disc list-inside mt-1 space-y-0.5 text-[11px] text-stone-500">
              <li>Punctuation booster (e.g. <code>!</code> increases magnitude)</li>
              <li>ALL-CAPS valence multiplier (+73.3% intensity)</li>
              <li>Degree adverb scaling (e.g. <code>remarkably</code>)</li>
            </ul>
          </div>
        </div>

        {/* Word-level Attribution */}
        <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm space-y-3">
          <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider">Word-level Valence Tokens</h4>
          <p className="text-xs text-stone-500">Tokens matched against the VADER dictionary:</p>
          <div className="flex flex-wrap gap-1.5 p-3 bg-[#FAF8F4] rounded-lg border border-[#DDD8CD]">
            {inputReview.split(/\s+/).map((w, idx) => {
              const clean = w.toLowerCase().replace(/[^a-z]/g, '');
              const val = VADER_LEXICON[clean];
              if (val !== undefined) {
                return (
                  <span
                    key={idx}
                    className={`px-2 py-0.5 rounded text-xs font-mono font-bold border ${
                      val > 0
                        ? 'bg-[#EFF3F0] text-[#2E080C] border-[#BAC5BE]'
                        : 'bg-[#FBF2F3] text-[#741118] border-[#E8B9BD]'
                    }`}
                  >
                    {w} ({val > 0 ? `+${val}` : val})
                  </span>
                );
              }
              return (
                <span key={idx} className="px-1.5 py-0.5 text-xs text-stone-400 font-mono">
                  {w}
                </span>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// Experiment 6: Word2Vec Distributed Word Embeddings Simulator
// =========================================================================
const Word2VecSimulator: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [modelType, setModelType] = useState<'skipgram' | 'cbow'>('skipgram');
  const [searchWord, setSearchWord] = useState('learning');
  const [analogyA, setAnalogyA] = useState('king');
  const [analogyB, setAnalogyB] = useState('man');
  const [analogyC, setAnalogyC] = useState('woman');
  const [analogyResult, setAnalogyResult] = useState('queen');

  // Simulated continuous embedding coordinates and similarities
  const NEAREST_NEIGHBORS: Record<string, Array<{ word: string; sim: number }>> = {
    learning: [
      { word: 'machine', sim: 0.894 },
      { word: 'neural', sim: 0.841 },
      { word: 'intelligence', sim: 0.792 },
      { word: 'algorithms', sim: 0.763 },
      { word: 'training', sim: 0.728 }
    ],
    king: [
      { word: 'queen', sim: 0.871 },
      { word: 'monarch', sim: 0.835 },
      { word: 'ruler', sim: 0.798 },
      { word: 'prince', sim: 0.764 },
      { word: 'palace', sim: 0.712 }
    ],
    computer: [
      { word: 'software', sim: 0.862 },
      { word: 'hardware', sim: 0.824 },
      { word: 'processor', sim: 0.789 },
      { word: 'network', sim: 0.751 },
      { word: 'computation', sim: 0.723 }
    ],
    natural: [
      { word: 'language', sim: 0.884 },
      { word: 'linguistic', sim: 0.821 },
      { word: 'speech', sim: 0.776 },
      { word: 'semantic', sim: 0.742 },
      { word: 'text', sim: 0.715 }
    ]
  };

  const handleCalculateAnalogy = () => {
    if (analogyA === 'king' && analogyB === 'man' && analogyC === 'woman') {
      setAnalogyResult('queen');
    } else if (analogyA === 'paris' && analogyB === 'france' && analogyC === 'tokyo') {
      setAnalogyResult('japan');
    } else {
      setAnalogyResult('target_concept');
    }
    onComplete();
  };

  const currentNeighbors = NEAREST_NEIGHBORS[searchWord.toLowerCase()] || NEAREST_NEIGHBORS['learning'];

  return (
    <div className="space-y-6">
      <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-base font-bold text-[#2E080C] flex items-center gap-2">
              <Compass className="w-5 h-5 text-[#741118]" />
              Practical 6: Word2Vec Continuous Distributed Word Representations
            </h3>
            <p className="text-xs text-stone-500">
              Continuous Bag of Words (CBOW), Skip-Gram with Negative Sampling, and Vector Analogies
            </p>
          </div>
          <button
            onClick={() => onComplete()}
            className="px-4 py-2 rounded-lg bg-[#741118] hover:bg-[#5D0E13] text-white text-xs font-semibold flex items-center gap-2 shadow-sm transition-all"
          >
            <Play className="w-4 h-4 fill-white" />
            Query Embeddings
          </button>
        </div>

        {/* Model Architecture Toggle */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4 text-xs">
          <button
            onClick={() => setModelType('skipgram')}
            className={`p-3 rounded-lg border text-left transition-all ${
              modelType === 'skipgram' ? 'border-[#741118] bg-[#FBF2F3]' : 'border-[#DDD8CD] bg-[#FAF8F4]'
            }`}
          >
            <div className="font-bold text-[#2E080C]">Skip-Gram Architecture (sg = 1)</div>
            <div className="text-[11px] text-stone-500 mt-0.5">Predicts context words given target center word. Best for rare words.</div>
          </button>
          <button
            onClick={() => setModelType('cbow')}
            className={`p-3 rounded-lg border text-left transition-all ${
              modelType === 'cbow' ? 'border-[#741118] bg-[#FBF2F3]' : 'border-[#DDD8CD] bg-[#FAF8F4]'
            }`}
          >
            <div className="font-bold text-[#2E080C]">Continuous Bag of Words (sg = 0)</div>
            <div className="text-[11px] text-stone-500 mt-0.5">Predicts target word given context window. Fast & smooth on large corpora.</div>
          </button>
        </div>

        {/* Cosine Similarity Search */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-stone-700">Semantic Cosine Similarity Query:</label>
          <div className="flex gap-2">
            <input
              type="text"
              value={searchWord}
              onChange={(e) => setSearchWord(e.target.value)}
              className="flex-1 text-xs font-mono p-2.5 bg-[#FAF8F4] border border-[#DDD8CD] rounded-lg focus:ring-2 focus:ring-[#741118] focus:border-[#741118] focus:outline-none"
              placeholder="Enter word (e.g. learning, king, computer, natural)..."
            />
            <button
              onClick={() => onComplete()}
              className="px-4 py-2 bg-[#741118] hover:bg-[#5D0E13] text-white rounded-lg text-xs font-semibold"
            >
              Find Nearest
            </button>
          </div>
        </div>
      </div>

      {/* Neighbor Ranking & Vector Analogy */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Nearest Neighbors */}
        <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm space-y-4">
          <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider flex items-center justify-between">
            <span>Top Nearest Semantic Neighbors for <code className="text-[#741118] font-bold">"{searchWord}"</code></span>
            <span className="text-[10px] text-stone-400">Cosine Similarity: cos(θ)</span>
          </h4>

          <div className="space-y-3">
            {currentNeighbors.map((item, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-mono font-bold text-[#2E080C]">
                    {idx + 1}. {item.word}
                  </span>
                  <span className="font-mono text-[#741118] font-semibold">
                    {item.sim.toFixed(4)}
                  </span>
                </div>
                <div className="w-full h-2 bg-[#F2EEE4] rounded-full overflow-hidden">
                  <div className="h-full bg-[#741118] rounded-full" style={{ width: `${item.sim * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Vector Analogy Calculator */}
        <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm space-y-4">
          <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider">
            Vector Arithmetic Analogy (A : B :: C : ?)
          </h4>
          <div className="p-4 bg-[#FAF8F4] rounded-xl border border-[#DDD8CD] space-y-3">
            <div className="text-xs text-stone-600 font-medium">
              Solve: <code className="font-bold text-[#2E080C]">vec(A) - vec(B) + vec(C) ≈ vec(?)</code>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="text-[10px] text-stone-400 block mb-0.5">Word A</label>
                <input
                  type="text"
                  value={analogyA}
                  onChange={(e) => setAnalogyA(e.target.value)}
                  className="w-full text-xs font-mono p-2 bg-white border border-[#DDD8CD] rounded focus:ring-1 focus:ring-[#741118] focus:outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-stone-400 block mb-0.5">Minus Word B</label>
                <input
                  type="text"
                  value={analogyB}
                  onChange={(e) => setAnalogyB(e.target.value)}
                  className="w-full text-xs font-mono p-2 bg-white border border-[#DDD8CD] rounded focus:ring-1 focus:ring-[#741118] focus:outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-stone-400 block mb-0.5">Plus Word C</label>
                <input
                  type="text"
                  value={analogyC}
                  onChange={(e) => setAnalogyC(e.target.value)}
                  className="w-full text-xs font-mono p-2 bg-white border border-[#DDD8CD] rounded focus:ring-1 focus:ring-[#741118] focus:outline-none"
                />
              </div>
            </div>

            <button
              onClick={handleCalculateAnalogy}
              className="w-full py-2 bg-[#F2EEE4] hover:bg-[#E7E2D5] text-[#741118] font-semibold text-xs rounded border border-[#DDD8CD] transition-all"
            >
              Compute Vector Analogy
            </button>

            <div className="p-3 bg-white rounded-lg border border-[#BAC5BE] text-center">
              <div className="text-[11px] text-stone-400 font-medium">Predicted Target Vector:</div>
              <div className="text-2xl font-black text-[#741118] mt-0.5">
                "{analogyResult}"
              </div>
              <div className="text-[10px] text-[#515E57] mt-0.5">Cosine Proximity: 0.824</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// =========================================================================
// Experiment 7: Transformer-Based BERT Hugging Face Simulator
// =========================================================================
const BERTTransformerSimulator: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [inputText, setInputText] = useState('The Transformer self-attention mechanism is profoundly revolutionary!');
  const [activeTab, setActiveTab] = useState<'tokens' | 'attention' | 'logits'>('tokens');

  // WordPiece Tokenizer representation
  const wordPieceTokens = [
    { token: '[CLS]', id: 101, type: 'special' },
    { token: 'the', id: 1996, type: 'word' },
    { token: 'transform', id: 10938, type: 'subword' },
    { token: '##er', id: 2121, type: 'subword' },
    { token: 'self', id: 2969, type: 'word' },
    { token: '-', id: 1011, type: 'punct' },
    { token: 'attention', id: 3086, type: 'word' },
    { token: 'mechanism', id: 5358, type: 'word' },
    { token: 'is', id: 2003, type: 'word' },
    { token: 'profound', id: 10842, type: 'subword' },
    { token: '##ly', id: 2135, type: 'subword' },
    { token: 'revolutionary', id: 6220, type: 'word' },
    { token: '!', id: 999, type: 'punct' },
    { token: '[SEP]', id: 102, type: 'special' }
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-base font-bold text-[#2E080C] flex items-center gap-2">
              <Layers className="w-5 h-5 text-[#741118]" />
              Practical 7: Transformer-Based Pre-trained BERT (Hugging Face)
            </h3>
            <p className="text-xs text-stone-500">
              Bidirectional Encoder Representations from Transformers, WordPiece Tokenization & Self-Attention
            </p>
          </div>
          <button
            onClick={() => onComplete()}
            className="px-4 py-2 rounded-lg bg-[#741118] hover:bg-[#5D0E13] text-white text-xs font-semibold flex items-center gap-2 shadow-sm transition-all"
          >
            <Play className="w-4 h-4 fill-white" />
            Run Transformer Inference
          </button>
        </div>

        {/* Text Input */}
        <textarea
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          rows={2}
          className="w-full text-xs font-mono p-3 bg-[#FAF8F4] border border-[#DDD8CD] rounded-lg focus:ring-2 focus:ring-[#741118] focus:border-[#741118] focus:outline-none mb-3"
        />

        {/* Tabs */}
        <div className="flex gap-2 border-b border-[#DDD8CD] pb-2 text-xs">
          <button
            onClick={() => setActiveTab('tokens')}
            className={`px-3 py-1 font-semibold ${activeTab === 'tokens' ? 'text-[#741118] border-b-2 border-[#741118]' : 'text-stone-500'}`}
          >
            WordPiece Tokenizer IDs
          </button>
          <button
            onClick={() => setActiveTab('attention')}
            className={`px-3 py-1 font-semibold ${activeTab === 'attention' ? 'text-[#741118] border-b-2 border-[#741118]' : 'text-stone-500'}`}
          >
            Self-Attention Weight Matrix
          </button>
          <button
            onClick={() => setActiveTab('logits')}
            className={`px-3 py-1 font-semibold ${activeTab === 'logits' ? 'text-[#741118] border-b-2 border-[#741118]' : 'text-stone-500'}`}
          >
            Downstream Logits & Softmax
          </button>
        </div>
      </div>

      {/* Tab Contents */}
      {activeTab === 'tokens' && (
        <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm space-y-4">
          <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider flex items-center justify-between">
            <span>WordPiece Subword Tokenization</span>
            <span className="text-[10px] text-stone-400">Total Tokens: {wordPieceTokens.length}</span>
          </h4>
          <div className="flex flex-wrap gap-2 p-3 bg-[#FAF8F4] rounded-lg border border-[#DDD8CD]">
            {wordPieceTokens.map((t, idx) => (
              <div
                key={idx}
                className={`p-2 rounded border text-xs font-mono flex flex-col items-center ${
                  t.type === 'special'
                    ? 'bg-[#FBF2F3] text-[#741118] border-[#E8B9BD] font-bold'
                    : t.type === 'subword'
                    ? 'bg-[#EFF3F0] text-[#2E080C] border-[#BAC5BE]'
                    : 'bg-white text-[#2E080C] border-[#DDD8CD]'
                }`}
              >
                <span>{t.token}</span>
                <span className="text-[9px] opacity-60">ID: {t.id}</span>
              </div>
            ))}
          </div>
          <div className="text-xs text-stone-500">
            Notice how WordPiece splits unknown or inflected words into subwords with the <code>##</code> prefix (e.g. <code>profound</code> + <code>##ly</code>). This solves the Out-of-Vocabulary (OOV) problem without inflating the vocabulary size.
          </div>
        </div>
      )}

      {activeTab === 'attention' && (
        <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm space-y-4">
          <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider">
            Multi-Head Self-Attention Heatmap (Layer 12, Head 1)
          </h4>
          <div className="p-4 bg-[#2E080C] rounded-xl text-white font-mono text-[11px] overflow-x-auto">
            <div className="text-[#BAC5BE] mb-2">// Query-Key dot-product attention weights: softmax(Q K^T / √d_k)</div>
            <div className="grid grid-cols-7 gap-1 text-center">
              <span className="text-[#6D7D74] font-bold">Token</span>
              <span className="text-[#F2EEE4]">[CLS]</span>
              <span className="text-[#F2EEE4]">transform</span>
              <span className="text-[#F2EEE4]">attention</span>
              <span className="text-[#F2EEE4]">mechanism</span>
              <span className="text-[#F2EEE4]">profoundly</span>
              <span className="text-[#F2EEE4]">[SEP]</span>

              <span className="text-[#BAC5BE]">[CLS]</span>
              <span className="bg-[#741118]/60 text-white p-1 rounded">0.42</span>
              <span className="bg-[#741118]/30 text-white/90 p-1 rounded">0.18</span>
              <span className="bg-[#741118]/20 text-white/80 p-1 rounded">0.11</span>
              <span className="bg-[#741118]/30 text-white/90 p-1 rounded">0.15</span>
              <span className="bg-[#741118]/20 text-white/80 p-1 rounded">0.08</span>
              <span className="bg-[#741118]/10 text-white/70 p-1 rounded">0.06</span>

              <span className="text-[#BAC5BE]">attention</span>
              <span className="bg-[#741118]/20 text-white/80 p-1 rounded">0.12</span>
              <span className="bg-[#741118]/40 text-white/90 p-1 rounded">0.25</span>
              <span className="bg-[#741118] text-white p-1 rounded font-bold">0.68</span>
              <span className="bg-[#741118]/40 text-white/90 p-1 rounded">0.22</span>
              <span className="bg-[#741118]/30 text-white/90 p-1 rounded">0.14</span>
              <span className="bg-[#741118]/10 text-white/70 p-1 rounded">0.05</span>

              <span className="text-[#BAC5BE]">mechanism</span>
              <span className="bg-[#741118]/20 text-white/80 p-1 rounded">0.14</span>
              <span className="bg-[#741118]/40 text-white/90 p-1 rounded">0.21</span>
              <span className="bg-[#741118]/80 text-white p-1 rounded font-bold">0.54</span>
              <span className="bg-[#741118] text-white p-1 rounded font-bold">0.61</span>
              <span className="bg-[#741118]/30 text-white/90 p-1 rounded">0.19</span>
              <span className="bg-[#741118]/10 text-white/70 p-1 rounded">0.07</span>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'logits' && (
        <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm space-y-4">
          <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider">
            Downstream Sequence Classification (SST-2 Fine-Tuned Head)
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 bg-[#EFF3F0] rounded-xl border border-[#BAC5BE]">
              <div className="text-xs text-[#2E080C] font-semibold">Positive Class Logit & Softmax</div>
              <div className="text-3xl font-bold text-[#2E080C] mt-1">99.6%</div>
              <div className="text-xs text-[#515E57] mt-1 font-mono">Raw Logit: +4.82</div>
            </div>
            <div className="p-4 bg-[#FAF8F4] rounded-xl border border-[#DDD8CD]">
              <div className="text-xs text-[#515E57] font-semibold">Negative Class Logit & Softmax</div>
              <div className="text-3xl font-bold text-[#2E080C] mt-1">0.4%</div>
              <div className="text-xs text-stone-500 mt-1 font-mono">Raw Logit: -1.94</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// =========================================================================
// Experiment 8: LSTM Sequence Modeling & Next-Word Prediction Simulator
// =========================================================================
const LSTMNextWordSimulator: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [seedText, setSeedText] = useState('natural language processing enables');
  const [temperature, setTemperature] = useState(0.7);
  const [stepCount, setStepCount] = useState(0);

  const CANDIDATES = [
    { word: 'computers', prob: 0.584 },
    { word: 'machines', prob: 0.241 },
    { word: 'intelligent', prob: 0.112 },
    { word: 'deep', prob: 0.042 },
    { word: 'automated', prob: 0.021 }
  ];

  const handleStepGenerate = () => {
    const best = CANDIDATES[0].word;
    setSeedText(prev => `${prev} ${best}`);
    setStepCount(prev => prev + 1);
    onComplete();
  };

  return (
    <div className="space-y-6">
      <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-base font-bold text-[#2E080C] flex items-center gap-2">
              <Cpu className="w-5 h-5 text-[#741118]" />
              Practical 8: Long Short-Term Memory (LSTM) Sequence Modeling
            </h3>
            <p className="text-xs text-stone-500">
              Predict next-word sequences and monitor internal Cell State & Sigmoid Gating activations
            </p>
          </div>
          <button
            onClick={handleStepGenerate}
            className="px-4 py-2 rounded-lg bg-[#741118] hover:bg-[#5D0E13] text-white text-xs font-semibold flex items-center gap-2 shadow-sm transition-all"
          >
            <Play className="w-4 h-4 fill-white" />
            Generate Next Token
          </button>
        </div>

        {/* Input Seed */}
        <div className="space-y-2 mb-4">
          <label className="text-xs font-semibold text-stone-700">Seed Prompt Sequence:</label>
          <input
            type="text"
            value={seedText}
            onChange={(e) => setSeedText(e.target.value)}
            className="w-full text-xs font-mono p-3 bg-[#FAF8F4] border border-[#DDD8CD] rounded-lg focus:ring-2 focus:ring-[#741118] focus:border-[#741118] focus:outline-none"
          />
        </div>

        {/* Controls */}
        <div className="flex items-center gap-4 text-xs">
          <span className="text-stone-600 font-medium">Sampling Temperature (T): {temperature}</span>
          <input
            type="range"
            min="0.2"
            max="1.5"
            step="0.1"
            value={temperature}
            onChange={(e) => setTemperature(parseFloat(e.target.value))}
            className="w-48 accent-[#741118]"
          />
          <span className="text-[11px] text-stone-400">(Low = Greedy, High = Creative)</span>
        </div>
      </div>

      {/* LSTM Internal Architecture & Gates */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Gates Monitor */}
        <div className="bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm space-y-3">
          <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider">
            LSTM Cell Gate Activations (t = {stepCount})
          </h4>
          <div className="space-y-3 text-xs">
            <div>
              <div className="flex justify-between font-mono mb-1">
                <span>Forget Gate (f_t):</span>
                <span className="font-bold text-[#741118]">0.82 (Keep 82% old cell state)</span>
              </div>
              <div className="w-full h-2 bg-[#F2EEE4] rounded-full overflow-hidden">
                <div className="h-full bg-[#741118] rounded-full" style={{ width: '82%' }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between font-mono mb-1">
                <span>Input Gate (i_t):</span>
                <span className="font-bold text-[#515E57]">0.74 (Add 74% new input info)</span>
              </div>
              <div className="w-full h-2 bg-[#F2EEE4] rounded-full overflow-hidden">
                <div className="h-full bg-[#6D7D74] rounded-full" style={{ width: '74%' }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between font-mono mb-1">
                <span>Output Gate (o_t):</span>
                <span className="font-bold text-[#2E080C]">0.91 (High signal emission)</span>
              </div>
              <div className="w-full h-2 bg-[#F2EEE4] rounded-full overflow-hidden">
                <div className="h-full bg-[#2E080C] rounded-full" style={{ width: '91%' }} />
              </div>
            </div>
          </div>
          <div className="p-3 bg-[#FAF8F4] rounded-lg border border-[#DDD8CD] text-[11px] text-stone-500 mt-2">
            The additive Cell State gradient highway (<code>C_t = f_t * C_{'{t-1}'} + i_t * C~_t</code>) prevents vanishing gradients over long historical contexts.
          </div>
        </div>

        {/* Next Token Candidates */}
        <div className="lg:col-span-2 bg-white border border-[#DDD8CD] rounded-xl p-5 shadow-sm space-y-4">
          <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider flex items-center justify-between">
            <span>Softmax Probability Distribution for Next Token</span>
            <span className="text-[10px] text-stone-400">Vocabulary Size: |V| = 2500</span>
          </h4>

          <div className="space-y-3">
            {CANDIDATES.map((c, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-mono font-bold text-[#2E080C]">
                    {idx + 1}. "{c.word}"
                  </span>
                  <span className="font-mono text-[#741118] font-semibold">
                    {(c.prob * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="w-full h-2.5 bg-[#F2EEE4] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#741118] rounded-full transition-all duration-300"
                    style={{ width: `${c.prob * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
