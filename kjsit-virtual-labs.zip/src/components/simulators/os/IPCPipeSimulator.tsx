import React, { useState } from 'react';
import {
  Send,
  RotateCcw,
  Layers,
  ArrowRight,
  ShieldCheck,
  Zap,
  Terminal,
  Cpu,
  Info
} from 'lucide-react';

export const IPCPipeSimulator: React.FC = () => {
  const [mode, setMode] = useState<'PIPE' | 'SHARED_MEM'>('PIPE');
  const [inputMessage, setInputMessage] = useState('Operating Systems IPC Virtual Lab');
  const [pipeBuffer, setPipeBuffer] = useState<string[]>(['Init Stream Payload']);
  const [consumerReceived, setConsumerReceived] = useState<string[]>([]);
  const [sharedMemoryData, setSharedMemoryData] = useState<string>('0x7F4A0000: Initial Shared Buffer');
  const [mutexLocked, setMutexLocked] = useState<boolean>(false);
  const [logs, setLogs] = useState<string[]>([
    '[INIT] pipe(int fd[2]) executed: fd[0] = 3 (read), fd[1] = 4 (write).',
    '[KERNEL] Allocated 64KB circular ring buffer in kernel memory space.'
  ]);

  const addLog = (msg: string) => {
    setLogs((prev) => [...prev.slice(-12), msg]);
  };

  const handleSendPipe = () => {
    if (!inputMessage.trim()) return;
    if (pipeBuffer.length >= 5) {
      addLog('[BLOCK] Pipe kernel buffer full (capacity 5 messages). Writer process blocked!');
      return;
    }

    setPipeBuffer((prev) => [...prev, inputMessage]);
    addLog(`[WRITE fd[1]] Parent (PID 1024) wrote "${inputMessage}" (${inputMessage.length} bytes) to kernel pipe.`);
  };

  const handleReadPipe = () => {
    if (pipeBuffer.length === 0) {
      addLog('[BLOCK] Pipe empty. Consumer (PID 1025) read(fd[0]) is blocking waiting for data.');
      return;
    }

    const msg = pipeBuffer[0];
    setPipeBuffer((prev) => prev.slice(1));
    setConsumerReceived((prev) => [...prev, msg]);
    addLog(`[READ fd[0]] Child (PID 1025) consumed "${msg}" from kernel buffer.`);
  };

  const handleWriteSharedMem = () => {
    if (mutexLocked) {
      addLog('[MUTEX LOCK] Shared memory segment locked by another thread. Write operation blocked!');
      return;
    }

    setSharedMemoryData(`0x7F4A0000: ${inputMessage}`);
    addLog(`[SHM WRITE] Process wrote "${inputMessage}" directly to physical memory frame with ZERO kernel copies.`);
  };

  const handleReset = () => {
    setPipeBuffer([]);
    setConsumerReceived([]);
    setSharedMemoryData('0x7F4A0000: Initial Shared Buffer');
    setLogs([
      '[RESET] IPC channels flushed and reset.',
      '[KERNEL] Ready for message passing or shared memory synchronization.'
    ]);
  };

  return (
    <div className="space-y-6">
      {/* Mode Switcher */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold uppercase tracking-wider mb-1">
            <Cpu className="w-3 h-3" />
            <span>IPC Protocol Simulator</span>
          </div>
          <h4 className="text-sm font-bold text-slate-900">Inter-Process Communication Channels</h4>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setMode('PIPE')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              mode === 'PIPE' ? 'bg-amber-800 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            UNIX Anonymous Pipe (pipe())
          </button>
          <button
            onClick={() => setMode('SHARED_MEM')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              mode === 'SHARED_MEM' ? 'bg-amber-800 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            POSIX Shared Memory (mmap())
          </button>
        </div>
      </div>

      {mode === 'PIPE' ? (
        /* Pipe Simulator View */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: Producer / Parent Process */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Parent Process (Producer)
              </span>
              <span className="text-[10px] font-mono bg-blue-100 text-blue-800 px-2 py-0.5 rounded">PID: 1024</span>
            </div>

            <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-200 text-xs space-y-2">
              <div className="text-blue-900 font-bold">Write End: <code className="font-mono">fd[1] = 4</code></div>
              <p className="text-[11px] text-blue-800/80">
                Data written to <code className="font-mono">fd[1]</code> is queued in the kernel ring buffer.
              </p>
            </div>

            <div className="space-y-2">
              <label className="text-[11px] font-bold text-slate-700 block">Message String Payload:</label>
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                placeholder="Enter string message..."
              />
              <button
                onClick={handleSendPipe}
                className="w-full py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold text-xs shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>write(fd[1], buffer, len)</span>
              </button>
            </div>
          </div>

          {/* Center: Kernel Buffer State */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">Kernel Ring Buffer</span>
                <span className="text-[10px] font-mono text-slate-500">{pipeBuffer.length} / 5 slots</span>
              </div>

              <div className="mt-4 p-3 bg-slate-900 rounded-xl border border-slate-800 text-slate-200 space-y-2 min-h-[160px]">
                <div className="text-[10px] text-slate-400 font-mono pb-1 border-b border-slate-800 flex justify-between">
                  <span>FIFO Byte Queue</span>
                  <span>Max 64KB</span>
                </div>

                {pipeBuffer.length === 0 ? (
                  <div className="text-center text-xs text-slate-500 py-8">
                    [Buffer Empty - Read will block]
                  </div>
                ) : (
                  pipeBuffer.map((msg, i) => (
                    <div
                      key={i}
                      className="p-2 bg-amber-950/80 border border-amber-500/30 rounded text-[11px] font-mono text-amber-200 truncate flex items-center gap-2"
                    >
                      <span className="text-[9px] bg-amber-900 text-amber-300 px-1 py-0.5 rounded">Packet {i+1}</span>
                      <span className="truncate">{msg}</span>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="text-center">
              <span className="text-[10px] text-slate-400">Byte Flow Direction: Parent [fd1] → Kernel → Child [fd0]</span>
            </div>
          </div>

          {/* Right: Consumer / Child Process */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Child Process (Consumer)
              </span>
              <span className="text-[10px] font-mono bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">PID: 1025</span>
            </div>

            <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-200 text-xs space-y-2">
              <div className="text-emerald-900 font-bold">Read End: <code className="font-mono">fd[0] = 3</code></div>
              <p className="text-[11px] text-emerald-800/80">
                Calling <code className="font-mono">read(fd[0])</code> pops bytes from kernel buffer into memory.
              </p>
            </div>

            <button
              onClick={handleReadPipe}
              className="w-full py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>read(fd[0], buffer, len)</span>
            </button>

            <div className="space-y-1">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Received Payloads:</span>
              <div className="p-2 bg-slate-50 rounded-xl border border-slate-200 max-h-24 overflow-y-auto space-y-1 text-xs font-mono">
                {consumerReceived.length === 0 ? (
                  <span className="text-slate-400 text-[11px]">No messages read yet.</span>
                ) : (
                  consumerReceived.map((m, idx) => (
                    <div key={idx} className="text-emerald-800 bg-emerald-50 p-1 rounded border border-emerald-200">
                      &gt; {m}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Shared Memory View */
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">POSIX Shared Memory Segment</h4>

            <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 text-slate-200 space-y-3">
              <div className="flex justify-between items-center text-xs font-mono pb-2 border-b border-slate-800">
                <span className="text-amber-400">Physical Memory Block</span>
                <span className="text-slate-400">Size: 4096 bytes (1 page)</span>
              </div>
              <div className="p-3 bg-slate-950 rounded border border-slate-800 font-mono text-xs text-emerald-400 break-all">
                {sharedMemoryData}
              </div>
              <div className="flex items-center justify-between text-xs pt-1">
                <span className="text-slate-400">Mutex Lock State:</span>
                <span className={`px-2 py-0.5 rounded font-bold ${mutexLocked ? 'bg-rose-900 text-rose-200' : 'bg-emerald-900 text-emerald-200'}`}>
                  {mutexLocked ? 'LOCKED (In Critical Section)' : 'UNLOCKED (Available)'}
                </span>
              </div>
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                className="flex-1 px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
              />
              <button
                onClick={handleWriteSharedMem}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                Write to SHM
              </button>
              <button
                onClick={() => setMutexLocked(!mutexLocked)}
                className="px-3 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                Toggle Mutex
              </button>
            </div>
          </div>

          <div className="bg-amber-50/60 p-5 rounded-2xl border border-amber-200 space-y-3 text-xs text-amber-900">
            <h4 className="font-bold text-amber-900 text-sm flex items-center gap-1.5">
              <Info className="w-4 h-4 text-amber-700" />
              Shared Memory vs Kernel Pipes
            </h4>
            <p className="leading-relaxed text-[11px] text-amber-800">
              Unlike anonymous pipes that copy memory twice (Process space → Kernel space → Target Process space), POSIX Shared Memory directly maps the same physical RAM frame into both processes' virtual address spaces, achieving near-zero latency.
            </p>
          </div>
        </div>
      )}

      {/* Terminal Log */}
      <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 font-mono text-xs text-slate-300">
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-slate-400">
          <div className="flex items-center gap-1.5">
            <Terminal className="w-4 h-4 text-emerald-400" />
            <span>IPC Kernel Activity Trace</span>
          </div>
          <button onClick={handleReset} className="text-[10px] text-slate-400 hover:text-white cursor-pointer">
            Clear Logs
          </button>
        </div>
        <div className="space-y-1 max-h-32 overflow-y-auto text-[11px]">
          {logs.map((l, i) => (
            <div key={i} className={l.includes('[BLOCK]') ? 'text-rose-400' : 'text-slate-300'}>
              {l}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
