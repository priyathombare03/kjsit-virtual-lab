import React, { useState, useEffect } from 'react';
import {
  Play,
  RotateCcw,
  ShieldCheck,
  AlertTriangle,
  Cpu,
  Layers,
  Sparkles,
  Zap,
  Info
} from 'lucide-react';

interface ThreadInfo {
  id: number;
  tid: string;
  state: 'READY' | 'RUNNING' | 'WAITING_MUTEX' | 'TERMINATED';
  iterationsDone: number;
  color: string;
}

export const PthreadsSimulator: React.FC = () => {
  const [useMutex, setUseMutex] = useState<boolean>(true);
  const [numThreads, setNumThreads] = useState<number>(4);
  const [iterationsPerThread, setIterationsPerThread] = useState<number>(25000);
  const [counter, setCounter] = useState<number>(0);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [threads, setThreads] = useState<ThreadInfo[]>([
    { id: 0, tid: '0x7F01', state: 'READY', iterationsDone: 0, color: 'bg-blue-600' },
    { id: 1, tid: '0x7F02', state: 'READY', iterationsDone: 0, color: 'bg-emerald-600' },
    { id: 2, tid: '0x7F03', state: 'READY', iterationsDone: 0, color: 'bg-purple-600' },
    { id: 3, tid: '0x7F04', state: 'READY', iterationsDone: 0, color: 'bg-amber-600' }
  ]);

  const expectedTotal = numThreads * iterationsPerThread;

  const handleStartSimulation = () => {
    setIsRunning(true);
    setCounter(0);

    // Initial threads state
    const tList: ThreadInfo[] = Array.from({ length: numThreads }).map((_, i) => ({
      id: i,
      tid: `0x7F0${i + 1}`,
      state: 'RUNNING',
      iterationsDone: 0,
      color: ['bg-blue-600', 'bg-emerald-600', 'bg-purple-600', 'bg-amber-600', 'bg-rose-600'][i % 5]
    }));
    setThreads(tList);

    if (useMutex) {
      // Synchronized with pthread_mutex_lock() -> Exact sum
      let curr = 0;
      const timer = setInterval(() => {
        curr += Math.floor(expectedTotal / 10);
        if (curr >= expectedTotal) {
          curr = expectedTotal;
          clearInterval(timer);
          setIsRunning(false);
          setThreads((prev) => prev.map((t) => ({ ...t, state: 'TERMINATED', iterationsDone: iterationsPerThread })));
        } else {
          setThreads((prev) =>
            prev.map((t) => ({
              ...t,
              iterationsDone: Math.min(iterationsPerThread, Math.floor(curr / numThreads))
            }))
          );
        }
        setCounter(curr);
      }, 80);
    } else {
      // Race Condition: non-atomic load-modify-store clobbering increments
      const lossFactor = 0.65 + Math.random() * 0.15; // 65-80% of expected due to race condition
      const actualFinal = Math.floor(expectedTotal * lossFactor);
      let curr = 0;

      const timer = setInterval(() => {
        curr += Math.floor(actualFinal / 10);
        if (curr >= actualFinal) {
          curr = actualFinal;
          clearInterval(timer);
          setIsRunning(false);
          setThreads((prev) => prev.map((t) => ({ ...t, state: 'TERMINATED', iterationsDone: iterationsPerThread })));
        } else {
          setThreads((prev) =>
            prev.map((t) => ({
              ...t,
              iterationsDone: Math.min(iterationsPerThread, Math.floor(curr / numThreads))
            }))
          );
        }
        setCounter(curr);
      }, 80);
    }
  };

  const handleReset = () => {
    setIsRunning(false);
    setCounter(0);
    setThreads(
      Array.from({ length: numThreads }).map((_, i) => ({
        id: i,
        tid: `0x7F0${i + 1}`,
        state: 'READY',
        iterationsDone: 0,
        color: ['bg-blue-600', 'bg-emerald-600', 'bg-purple-600', 'bg-amber-600', 'bg-rose-600'][i % 5]
      }))
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold uppercase tracking-wider mb-1">
            <Cpu className="w-3 h-3" />
            <span>Thread Concurrency</span>
          </div>
          <h4 className="text-sm font-bold text-slate-900">POSIX Threads (pthreads) & Race Condition Simulator</h4>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setUseMutex(!useMutex)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              useMutex
                ? 'bg-emerald-800 text-white shadow-xs'
                : 'bg-rose-100 text-rose-800 border border-rose-200'
            }`}
          >
            {useMutex ? 'Mutex Synchronization ON (pthread_mutex_lock)' : 'No Mutex (Race Condition Vulnerability)'}
          </button>

          <button
            onClick={handleStartSimulation}
            disabled={isRunning}
            className="px-4 py-1.5 bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold cursor-pointer flex items-center gap-1.5"
          >
            <Play className="w-3.5 h-3.5" />
            <span>Spawn & Run Threads</span>
          </button>

          <button
            onClick={handleReset}
            className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
            title="Reset"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Counter & Race Condition Alert */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-2">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Expected Shared Counter Sum
          </span>
          <span className="text-2xl font-black text-slate-900 font-mono block">
            {expectedTotal.toLocaleString()}
          </span>
          <span className="text-xs text-slate-500 font-mono">
            {numThreads} threads × {iterationsPerThread.toLocaleString()} increments
          </span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-2">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Actual Value in Shared Memory
          </span>
          <span
            className={`text-2xl font-black font-mono block ${
              counter === expectedTotal
                ? 'text-emerald-700'
                : counter === 0
                ? 'text-slate-800'
                : 'text-rose-600'
            }`}
          >
            {counter.toLocaleString()}
          </span>
          <span className="text-xs text-slate-500">
            {counter === expectedTotal && counter > 0
              ? '✓ Perfect atomic synchronization'
              : !useMutex && counter > 0 && !isRunning
              ? '⚠ Data race caused lost increments'
              : isRunning
              ? 'Computing in parallel...'
              : 'Idle'}
          </span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-2">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Synchronization Primitive
          </span>
          <div className="text-sm font-bold text-slate-900">
            {useMutex ? 'pthread_mutex_t lock' : 'None (Atomic Clobber)'}
          </div>
          <span className="text-xs text-slate-500">
            {useMutex ? 'Guarantees Mutual Exclusion' : 'Unprotected Critical Section'}
          </span>
        </div>
      </div>

      {/* Thread Workers Visualizer */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
        <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
          POSIX Thread Worker Pool (pthread_t)
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {threads.map((t) => {
            const progress = Math.min(100, Math.round((t.iterationsDone / iterationsPerThread) * 100));

            return (
              <div key={t.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className={`w-3 h-3 rounded-full ${t.color}`}></span>
                    <span className="font-bold text-xs text-slate-900">Thread #{t.id}</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">{t.tid}</span>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-500">Status:</span>
                    <span className={`font-bold ${t.state === 'RUNNING' ? 'text-blue-600 animate-pulse' : t.state === 'TERMINATED' ? 'text-emerald-700' : 'text-slate-600'}`}>
                      {t.state}
                    </span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-500">Progress:</span>
                    <span className="font-mono text-slate-700">{progress}%</span>
                  </div>
                  <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                    <div
                      style={{ width: `${progress}%` }}
                      className={`h-full ${t.color} transition-all duration-100`}
                    ></div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Assembly Instruction Dissection */}
      <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 text-xs font-mono text-slate-300 space-y-3">
        <h5 className="text-amber-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-1.5">
          <Info className="w-4 h-4 text-amber-500" />
          Why Race Conditions Occur (Assembly Level Analysis)
        </h5>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-[11px] text-slate-400 leading-relaxed">
          <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
            <span className="text-rose-400 font-bold block">Without Mutex (3 Non-Atomic Instructions):</span>
            <div>1. <code className="text-slate-200">mov eax, [counter]</code> (Read RAM into register)</div>
            <div>2. <code className="text-slate-200">add eax, 1</code> (Increment in CPU ALU)</div>
            <div>3. <code className="text-slate-200">mov [counter], eax</code> (Write register back to RAM)</div>
            <p className="text-[10px] text-slate-500 pt-1">
              If CPU context-switches between steps 1 and 3, both threads read the same stale value and overwrite each other.
            </p>
          </div>
          <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
            <span className="text-emerald-400 font-bold block">With Mutex (Atomic Critical Section):</span>
            <div>1. <code className="text-slate-200">pthread_mutex_lock(&amp;lock)</code> (Test &amp; Set Lock)</div>
            <div>2. <code className="text-slate-200">counter++</code> (Only 1 thread in critical region)</div>
            <div>3. <code className="text-slate-200">pthread_mutex_unlock(&amp;lock)</code> (Release lock)</div>
            <p className="text-[10px] text-slate-500 pt-1">
              Guarantees strict atomicity, preventing race conditions and lost updates.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
