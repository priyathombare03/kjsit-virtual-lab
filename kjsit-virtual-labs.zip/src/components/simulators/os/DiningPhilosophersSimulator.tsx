import React, { useState, useEffect } from 'react';
import {
  Utensils,
  AlertTriangle,
  CheckCircle2,
  RotateCcw,
  ShieldCheck,
  Play,
  Pause,
  Layers,
  Info,
  Cpu
} from 'lucide-react';

type PhilState = 'THINKING' | 'HUNGRY' | 'EATING';

interface Philosopher {
  id: number;
  name: string;
  state: PhilState;
  mealsEaten: number;
}

export const DiningPhilosophersSimulator: React.FC = () => {
  const [philosophers, setPhilosophers] = useState<Philosopher[]>([
    { id: 0, name: 'P0 (Aristotle)', state: 'THINKING', mealsEaten: 0 },
    { id: 1, name: 'P1 (Plato)', state: 'THINKING', mealsEaten: 0 },
    { id: 2, name: 'P2 (Socrates)', state: 'THINKING', mealsEaten: 0 },
    { id: 3, name: 'P3 (Descartes)', state: 'THINKING', mealsEaten: 0 },
    { id: 4, name: 'P4 (Kant)', state: 'THINKING', mealsEaten: 0 }
  ]);

  // Chopstick mutex states: true = in use, false = available
  const [chopsticks, setChopsticks] = useState<boolean[]>([false, false, false, false, false]);
  const [isDeadlocked, setIsDeadlocked] = useState<boolean>(false);
  const [protocol, setProtocol] = useState<'NAIVE' | 'ASYMMETRIC'>('ASYMMETRIC');
  const [autoSimulate, setAutoSimulate] = useState<boolean>(false);

  // Check deadlock: all 5 hungry and all holding 1 chopstick
  useEffect(() => {
    const allHungry = philosophers.every((p) => p.state === 'HUNGRY');
    const allChopsticksHeld = chopsticks.every((c) => c === true);
    if (allHungry && allChopsticksHeld && protocol === 'NAIVE') {
      setIsDeadlocked(true);
    } else {
      setIsDeadlocked(false);
    }
  }, [philosophers, chopsticks, protocol]);

  // Auto-simulation loop
  useEffect(() => {
    if (!autoSimulate || isDeadlocked) return;

    const interval = setInterval(() => {
      setPhilosophers((prev) => {
        const next = [...prev];
        const randomPhil = Math.floor(Math.random() * 5);
        const p = next[randomPhil];

        if (p.state === 'THINKING') {
          p.state = 'HUNGRY';
        } else if (p.state === 'EATING') {
          // Finish eating, release chopsticks
          p.state = 'THINKING';
          p.mealsEaten++;
          setChopsticks((prevChop) => {
            const nextChop = [...prevChop];
            nextChop[p.id] = false;
            nextChop[(p.id + 1) % 5] = false;
            return nextChop;
          });
        }
        return next;
      });

      // Try feeding hungry philosophers based on protocol
      setPhilosophers((prev) => {
        const next = [...prev];
        next.forEach((p) => {
          if (p.state === 'HUNGRY') {
            const left = p.id;
            const right = (p.id + 1) % 5;

            if (!chopsticks[left] && !chopsticks[right]) {
              p.state = 'EATING';
              setChopsticks((prevChop) => {
                const nextChop = [...prevChop];
                nextChop[left] = true;
                nextChop[right] = true;
                return nextChop;
              });
            }
          }
        });
        return next;
      });
    }, 1200);

    return () => clearInterval(interval);
  }, [autoSimulate, isDeadlocked, protocol, chopsticks]);

  const handlePhilosopherClick = (id: number) => {
    if (isDeadlocked) return;

    setPhilosophers((prev) => {
      const next = [...prev];
      const p = next[id];
      const left = id;
      const right = (id + 1) % 5;

      if (p.state === 'THINKING') {
        p.state = 'HUNGRY';
        // Try acquiring chopsticks
        if (!chopsticks[left] && !chopsticks[right]) {
          p.state = 'EATING';
          setChopsticks((prevChop) => {
            const nc = [...prevChop];
            nc[left] = true;
            nc[right] = true;
            return nc;
          });
        }
      } else if (p.state === 'HUNGRY') {
        // Try acquiring chopsticks if freed
        if (!chopsticks[left] && !chopsticks[right]) {
          p.state = 'EATING';
          setChopsticks((prevChop) => {
            const nc = [...prevChop];
            nc[left] = true;
            nc[right] = true;
            return nc;
          });
        }
      } else if (p.state === 'EATING') {
        // Release chopsticks
        p.state = 'THINKING';
        p.mealsEaten++;
        setChopsticks((prevChop) => {
          const nc = [...prevChop];
          nc[left] = false;
          nc[right] = false;
          return nc;
        });
      }
      return next;
    });
  };

  const handleTriggerDeadlock = () => {
    setProtocol('NAIVE');
    setAutoSimulate(false);
    setPhilosophers((prev) =>
      prev.map((p) => ({ ...p, state: 'HUNGRY' }))
    );
    // Every philosopher holds their left chopstick
    setChopsticks([true, true, true, true, true]);
    setIsDeadlocked(true);
  };

  const handleReset = () => {
    setPhilosophers([
      { id: 0, name: 'P0 (Aristotle)', state: 'THINKING', mealsEaten: 0 },
      { id: 1, name: 'P1 (Plato)', state: 'THINKING', mealsEaten: 0 },
      { id: 2, name: 'P2 (Socrates)', state: 'THINKING', mealsEaten: 0 },
      { id: 3, name: 'P3 (Descartes)', state: 'THINKING', mealsEaten: 0 },
      { id: 4, name: 'P4 (Kant)', state: 'THINKING', mealsEaten: 0 }
    ]);
    setChopsticks([false, false, false, false, false]);
    setIsDeadlocked(false);
    setAutoSimulate(false);
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold uppercase tracking-wider mb-1">
            <Cpu className="w-3 h-3" />
            <span>Process Synchronization</span>
          </div>
          <h4 className="text-sm font-bold text-slate-900">Dining Philosophers Synchronization Simulator</h4>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setProtocol(protocol === 'ASYMMETRIC' ? 'NAIVE' : 'ASYMMETRIC')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              protocol === 'ASYMMETRIC'
                ? 'bg-emerald-800 text-white shadow-xs'
                : 'bg-rose-100 text-rose-800 border border-rose-200'
            }`}
          >
            {protocol === 'ASYMMETRIC' ? 'Asymmetric Semaphore (Deadlock-Free)' : 'Naive Hold-and-Wait (Vulnerable)'}
          </button>

          <button
            onClick={() => setAutoSimulate(!autoSimulate)}
            className="inline-flex items-center gap-1 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold cursor-pointer"
          >
            {autoSimulate ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{autoSimulate ? 'Pause Simulation' : 'Auto Live Run'}</span>
          </button>

          <button
            onClick={handleReset}
            className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
            title="Reset"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Deadlock Alert if active */}
      {isDeadlocked && (
        <div className="p-4 bg-rose-50 border-2 border-rose-500 rounded-2xl flex items-center justify-between gap-4 text-rose-900 animate-pulse">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-6 h-6 text-rose-600 shrink-0" />
            <div>
              <h5 className="text-sm font-black">DEADLOCK DETECTED (Circular Wait)</h5>
              <p className="text-xs text-rose-700">
                All 5 philosophers are holding one chopstick and waiting indefinitely for their neighbor to release the second chopstick.
              </p>
            </div>
          </div>
          <button
            onClick={handleReset}
            className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold cursor-pointer"
          >
            Resolve Deadlock
          </button>
        </div>
      )}

      {/* Main Table Simulation Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Visual Circular Dining Table */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs flex flex-col items-center justify-center min-h-[380px] relative">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-6">
            Click on any Philosopher node to toggle state (Thinking → Hungry → Eating)
          </div>

          {/* Circular Arrangement */}
          <div className="relative w-72 h-72 rounded-full border-4 border-dashed border-slate-200 bg-slate-50 flex items-center justify-center">
            {/* Center Spaghetti Plate */}
            <div className="w-24 h-24 rounded-full bg-amber-100 border-2 border-amber-300 flex flex-col items-center justify-center shadow-inner text-center">
              <Utensils className="w-6 h-6 text-amber-700 mb-0.5" />
              <span className="text-[9px] font-black text-amber-900 uppercase">Shared Resource</span>
            </div>

            {/* 5 Philosophers positioned around table */}
            {philosophers.map((p, idx) => {
              const angle = (idx * 72 - 90) * (Math.PI / 180);
              const radius = 110; // distance from center
              const x = Math.cos(angle) * radius;
              const y = Math.sin(angle) * radius;

              const isEating = p.state === 'EATING';
              const isHungry = p.state === 'HUNGRY';

              return (
                <button
                  key={p.id}
                  onClick={() => handlePhilosopherClick(p.id)}
                  style={{
                    transform: `translate(${x}px, ${y}px)`
                  }}
                  className={`absolute w-20 h-20 rounded-2xl flex flex-col items-center justify-center p-1 border-2 transition-all cursor-pointer shadow-md ${
                    isEating
                      ? 'bg-emerald-700 text-white border-emerald-800 ring-4 ring-emerald-500/30 scale-110 z-10'
                      : isHungry
                      ? 'bg-amber-500 text-white border-amber-600 animate-bounce'
                      : 'bg-white text-slate-800 border-slate-300 hover:border-slate-400'
                  }`}
                >
                  <span className="text-[11px] font-black">{p.name.split(' ')[0]}</span>
                  <span className="text-[9px] uppercase font-bold opacity-90">{p.state}</span>
                  <span className="text-[8px] opacity-75 mt-0.5">Meals: {p.mealsEaten}</span>
                </button>
              );
            })}
          </div>

          {/* Quick Trigger Button */}
          <div className="mt-8 flex gap-3">
            <button
              onClick={handleTriggerDeadlock}
              className="px-3.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 rounded-xl text-xs font-bold cursor-pointer"
            >
              Trigger Circular Wait Deadlock
            </button>
          </div>
        </div>

        {/* State Summary & Chopstick Mutex Inspector */}
        <div className="space-y-6">
          {/* Chopstick Status */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Chopstick Mutex Semaphores
            </h4>

            <div className="space-y-2">
              {chopsticks.map((isHeld, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs"
                >
                  <span className="font-mono font-bold text-slate-800">Chopstick #{i}</span>
                  <span
                    className={`px-2 py-0.5 rounded font-bold text-[10px] uppercase ${
                      isHeld ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {isHeld ? 'ACQUIRED (In Use)' : 'FREE (sem = 1)'}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Theory card */}
          <div className="bg-amber-50/70 p-4 rounded-2xl border border-amber-200 text-xs text-amber-900 space-y-2">
            <div className="flex items-center gap-1.5 font-bold text-amber-900">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Deadlock Prevention Protocol</span>
            </div>
            <p className="text-[11px] leading-relaxed text-amber-800">
              The asymmetric protocol prevents deadlocks by requiring odd philosophers to pick up their right chopstick first and even philosophers to pick up their left chopstick first, completely eliminating circular wait chains.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
