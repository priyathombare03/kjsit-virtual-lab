import React, { useState, useMemo } from 'react';
import {
  Clock,
  RotateCw,
  Plus,
  Trash2,
  Cpu,
  Sliders,
  ArrowRight,
  Sparkles,
  Layers
} from 'lucide-react';

interface Process {
  id: string;
  name: string;
  at: number;
  bt: number;
  priority: number; // Lower number = higher priority
  color: string;
}

interface GanttBlock {
  processName: string;
  start: number;
  end: number;
  color: string;
}

interface ProcessResult {
  name: string;
  at: number;
  bt: number;
  priority: number;
  ct: number;
  tat: number;
  wt: number;
  color: string;
}

const COLORS = [
  'bg-blue-500 text-white border-blue-600',
  'bg-emerald-500 text-white border-emerald-600',
  'bg-purple-500 text-white border-purple-600',
  'bg-amber-500 text-white border-amber-600',
  'bg-rose-500 text-white border-rose-600',
  'bg-teal-500 text-white border-teal-600'
];

export const CPUSchedulingRRPrioritySimulator: React.FC = () => {
  const [mode, setMode] = useState<'RR' | 'PRIORITY_NP' | 'PRIORITY_P'>('RR');
  const [quantum, setQuantum] = useState<number>(2);
  const [processes, setProcesses] = useState<Process[]>([
    { id: '1', name: 'P1', at: 0, bt: 5, priority: 3, color: COLORS[0] },
    { id: '2', name: 'P2', at: 1, bt: 3, priority: 1, color: COLORS[1] },
    { id: '3', name: 'P3', at: 2, bt: 8, priority: 4, color: COLORS[2] },
    { id: '4', name: 'P4', at: 3, bt: 6, priority: 2, color: COLORS[3] }
  ]);

  const { ganttChart, results, avgTAT, avgWT, contextSwitches } = useMemo(() => {
    if (processes.length === 0) {
      return { ganttChart: [], results: [], avgTAT: 0, avgWT: 0, contextSwitches: 0 };
    }

    const n = processes.length;
    const gantt: GanttBlock[] = [];
    const resMap: Record<string, { ct: number; tat: number; wt: number }> = {};
    let switches = 0;

    if (mode === 'RR') {
      // Round Robin Algorithm with Ready Queue simulation
      const remBt: Record<string, number> = {};
      processes.forEach((p) => (remBt[p.name] = p.bt));

      let currentTime = 0;
      let completed = 0;
      const readyQueue: string[] = [];
      const inQueue: Record<string, boolean> = {};

      // Check arrivals at t=0
      processes.forEach((p) => {
        if (p.at <= currentTime && !inQueue[p.name]) {
          readyQueue.push(p.name);
          inQueue[p.name] = true;
        }
      });

      while (completed < n) {
        if (readyQueue.length === 0) {
          // Find next arriving process
          const uncompleted = processes.filter((p) => remBt[p.name] > 0);
          const nextArrival = Math.min(...uncompleted.map((p) => p.at));
          gantt.push({
            processName: 'IDLE',
            start: currentTime,
            end: nextArrival,
            color: 'bg-slate-200 text-slate-600 border-slate-300'
          });
          currentTime = nextArrival;

          processes.forEach((p) => {
            if (p.at <= currentTime && !inQueue[p.name] && remBt[p.name] > 0) {
              readyQueue.push(p.name);
              inQueue[p.name] = true;
            }
          });
          continue;
        }

        const currentName = readyQueue.shift()!;
        inQueue[currentName] = false;
        const currentProc = processes.find((p) => p.name === currentName)!;

        const execTime = Math.min(quantum, remBt[currentName]);
        const start = currentTime;
        const end = currentTime + execTime;
        gantt.push({
          processName: currentName,
          start,
          end,
          color: currentProc.color
        });
        currentTime = end;
        remBt[currentName] -= execTime;

        // Check new arrivals during this quantum window
        processes.forEach((p) => {
          if (p.at <= currentTime && !inQueue[p.name] && remBt[p.name] > 0 && p.name !== currentName) {
            readyQueue.push(p.name);
            inQueue[p.name] = true;
          }
        });

        if (remBt[currentName] > 0) {
          readyQueue.push(currentName);
          inQueue[currentName] = true;
          switches++;
        } else {
          completed++;
          const ct = currentTime;
          const tat = ct - currentProc.at;
          const wt = tat - currentProc.bt;
          resMap[currentName] = { ct, tat, wt };
        }
      }
    } else if (mode === 'PRIORITY_NP') {
      // Non-Preemptive Priority (Lower priority number = higher priority)
      let completed = 0;
      let currentTime = 0;
      const done: Record<string, boolean> = {};

      while (completed < n) {
        const available = processes.filter((p) => p.at <= currentTime && !done[p.name]);

        if (available.length === 0) {
          const nextProcs = processes.filter((p) => !done[p.name]);
          const nextArrival = Math.min(...nextProcs.map((p) => p.at));
          gantt.push({
            processName: 'IDLE',
            start: currentTime,
            end: nextArrival,
            color: 'bg-slate-200 text-slate-600 border-slate-300'
          });
          currentTime = nextArrival;
          continue;
        }

        available.sort((a, b) => a.priority - b.priority || a.at - b.at);
        const chosen = available[0];

        const start = currentTime;
        const end = currentTime + chosen.bt;
        gantt.push({
          processName: chosen.name,
          start,
          end,
          color: chosen.color
        });
        currentTime = end;
        done[chosen.name] = true;
        completed++;
        switches++;

        const ct = end;
        const tat = ct - chosen.at;
        const wt = tat - chosen.bt;
        resMap[chosen.name] = { ct, tat, wt };
      }
    } else {
      // Preemptive Priority
      const remBt: Record<string, number> = {};
      processes.forEach((p) => (remBt[p.name] = p.bt));
      let completed = 0;
      let currentTime = 0;
      let currentProcess: Process | null = null;
      let blockStart = 0;

      while (completed < n) {
        const available = processes.filter((p) => p.at <= currentTime && remBt[p.name] > 0);

        if (available.length === 0) {
          if (currentProcess) {
            gantt.push({
              processName: currentProcess.name,
              start: blockStart,
              end: currentTime,
              color: currentProcess.color
            });
            currentProcess = null;
          }
          const nextArrival = Math.min(...processes.filter((p) => remBt[p.name] > 0).map((p) => p.at));
          gantt.push({
            processName: 'IDLE',
            start: currentTime,
            end: nextArrival,
            color: 'bg-slate-200 text-slate-600 border-slate-300'
          });
          currentTime = nextArrival;
          blockStart = currentTime;
          continue;
        }

        available.sort((a, b) => a.priority - b.priority || a.at - b.at);
        const highest = available[0];

        if (!currentProcess || currentProcess.name !== highest.name) {
          if (currentProcess) {
            gantt.push({
              processName: currentProcess.name,
              start: blockStart,
              end: currentTime,
              color: currentProcess.color
            });
            switches++;
          }
          currentProcess = highest;
          blockStart = currentTime;
        }

        remBt[highest.name]--;
        currentTime++;

        if (remBt[highest.name] === 0) {
          completed++;
          gantt.push({
            processName: highest.name,
            start: blockStart,
            end: currentTime,
            color: highest.color
          });
          currentProcess = null;
          blockStart = currentTime;

          const ct = currentTime;
          const tat = ct - highest.at;
          const wt = tat - highest.bt;
          resMap[highest.name] = { ct, tat, wt };
        }
      }
    }

    const calculatedResults: ProcessResult[] = processes.map((p) => ({
      name: p.name,
      at: p.at,
      bt: p.bt,
      priority: p.priority,
      ct: resMap[p.name]?.ct || 0,
      tat: resMap[p.name]?.tat || 0,
      wt: resMap[p.name]?.wt || 0,
      color: p.color
    }));

    const totalTAT = calculatedResults.reduce((acc, curr) => acc + curr.tat, 0);
    const totalWT = calculatedResults.reduce((acc, curr) => acc + curr.wt, 0);

    return {
      ganttChart: gantt,
      results: calculatedResults,
      avgTAT: Number((totalTAT / n).toFixed(2)),
      avgWT: Number((totalWT / n).toFixed(2)),
      contextSwitches: switches
    };
  }, [processes, mode, quantum]);

  const handleUpdate = (id: string, field: 'at' | 'bt' | 'priority', value: number) => {
    const safeVal = Math.max(field === 'priority' ? 1 : 0, isNaN(value) ? 0 : value);
    setProcesses((prev) =>
      prev.map((p) => (p.id === id ? { ...p, [field]: safeVal } : p))
    );
  };

  const totalDuration = ganttChart.length > 0 ? ganttChart[ganttChart.length - 1].end : 0;

  return (
    <div className="space-y-6">
      {/* Top Config Bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Cpu className="w-5 h-5 text-amber-600" />
          <div>
            <h4 className="text-sm font-bold text-slate-900">Scheduler Configuration</h4>
            <p className="text-xs text-slate-500">Toggle between Round Robin and Priority dispatching</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setMode('RR')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                mode === 'RR' ? 'bg-amber-800 text-white shadow-xs' : 'text-slate-700 hover:text-slate-900'
              }`}
            >
              Round Robin (RR)
            </button>
            <button
              onClick={() => setMode('PRIORITY_NP')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                mode === 'PRIORITY_NP' ? 'bg-amber-800 text-white shadow-xs' : 'text-slate-700 hover:text-slate-900'
              }`}
            >
              Priority (Non-Preempt)
            </button>
            <button
              onClick={() => setMode('PRIORITY_P')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                mode === 'PRIORITY_P' ? 'bg-amber-800 text-white shadow-xs' : 'text-slate-700 hover:text-slate-900'
              }`}
            >
              Priority (Preemptive)
            </button>
          </div>

          {mode === 'RR' && (
            <div className="flex items-center gap-2 bg-amber-50 px-3 py-1.5 rounded-xl border border-amber-200">
              <span className="text-xs font-bold text-amber-900">Time Quantum (q):</span>
              <input
                type="range"
                min={1}
                max={6}
                value={quantum}
                onChange={(e) => setQuantum(parseInt(e.target.value))}
                className="w-20 accent-amber-700 cursor-pointer"
              />
              <span className="text-xs font-mono font-black text-amber-800 w-5 text-center">{quantum}t</span>
            </div>
          )}
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Workload Editor */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Process Workload Table</h4>
            <span className="text-[10px] text-slate-400">Lower priority # = Higher rank</span>
          </div>

          <div className="space-y-2 max-h-[320px] overflow-y-auto pr-1">
            {processes.map((proc) => (
              <div
                key={proc.id}
                className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`w-6 h-6 rounded flex items-center justify-center font-bold font-mono text-[11px] ${proc.color}`}>
                      {proc.name}
                    </div>
                    <span className="font-bold text-slate-800">{proc.name}</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500">ID: {proc.id}</span>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="text-[9px] text-slate-400 font-bold block">Arrival (AT)</label>
                    <input
                      type="number"
                      min={0}
                      value={proc.at}
                      onChange={(e) => handleUpdate(proc.id, 'at', parseInt(e.target.value))}
                      className="w-full px-2 py-1 bg-white border border-slate-300 rounded font-mono text-xs"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] text-slate-400 font-bold block">Burst (BT)</label>
                    <input
                      type="number"
                      min={1}
                      value={proc.bt}
                      onChange={(e) => handleUpdate(proc.id, 'bt', parseInt(e.target.value))}
                      className="w-full px-2 py-1 bg-white border border-slate-300 rounded font-mono text-xs"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] text-slate-400 font-bold block">Priority</label>
                    <input
                      type="number"
                      min={1}
                      value={proc.priority}
                      onChange={(e) => handleUpdate(proc.id, 'priority', parseInt(e.target.value))}
                      className="w-full px-2 py-1 bg-white border border-slate-300 rounded font-mono text-xs font-bold text-amber-700"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Gantt & Performance Metrics */}
        <div className="lg:col-span-2 space-y-6">
          {/* Execution Timeline */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-600" />
                <h4 className="text-sm font-bold text-slate-900">Execution Timeline & Time Slices</h4>
              </div>
              <span className="text-xs font-mono text-slate-500">
                Context Switches: <strong className="text-amber-800">{contextSwitches}</strong>
              </span>
            </div>

            <div className="space-y-2">
              <div className="h-14 bg-slate-100 rounded-xl p-1 flex items-center gap-1 overflow-x-auto border border-slate-200">
                {ganttChart.map((block, idx) => {
                  const duration = block.end - block.start;
                  return (
                    <div
                      key={idx}
                      style={{ flex: `${duration} 0 auto`, minWidth: '36px' }}
                      className={`h-full rounded-lg flex flex-col items-center justify-center font-mono text-xs font-black shadow-2xs border ${block.color}`}
                    >
                      <span>{block.processName}</span>
                      <span className="text-[9px] opacity-80">{duration}t</span>
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 px-1">
                <span>0</span>
                {ganttChart.map((b, i) => (
                  <span key={i}>{b.end}</span>
                ))}
              </div>
            </div>
          </div>

          {/* Performance Table */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Metrics Table</h4>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                  <tr>
                    <th className="p-2">Process</th>
                    <th className="p-2">Priority</th>
                    <th className="p-2">AT</th>
                    <th className="p-2">BT</th>
                    <th className="p-2">CT</th>
                    <th className="p-2">TAT</th>
                    <th className="p-2">WT</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {results.map((r) => (
                    <tr key={r.name} className="hover:bg-slate-50">
                      <td className="p-2 font-bold font-sans flex items-center gap-1.5">
                        <span className={`w-2.5 h-2.5 rounded-full ${r.color}`}></span>
                        <span>{r.name}</span>
                      </td>
                      <td className="p-2 text-amber-700 font-bold">{r.priority}</td>
                      <td className="p-2">{r.at}</td>
                      <td className="p-2">{r.bt}</td>
                      <td className="p-2 font-bold text-slate-800">{r.ct}</td>
                      <td className="p-2 text-blue-700 font-bold">{r.tat}</td>
                      <td className="p-2 text-emerald-700 font-bold">{r.wt}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="grid grid-cols-3 gap-3 pt-3 border-t border-slate-100">
              <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-200/80">
                <span className="text-[10px] font-bold text-blue-700 uppercase tracking-wider block">Average TAT</span>
                <span className="text-base font-black text-blue-900 font-mono mt-0.5 block">{avgTAT} ticks</span>
              </div>
              <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-200/80">
                <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block">Average WT</span>
                <span className="text-base font-black text-emerald-900 font-mono mt-0.5 block">{avgWT} ticks</span>
              </div>
              <div className="p-3 bg-amber-50/60 rounded-xl border border-amber-200/80">
                <span className="text-[10px] font-bold text-amber-700 uppercase tracking-wider block">Context Switches</span>
                <span className="text-base font-black text-amber-900 font-mono mt-0.5 block">{contextSwitches} switches</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
