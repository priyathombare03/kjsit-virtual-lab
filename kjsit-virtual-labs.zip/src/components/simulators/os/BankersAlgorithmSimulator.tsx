import React, { useState, useMemo } from 'react';
import {
  ShieldCheck,
  AlertTriangle,
  Play,
  RotateCcw,
  CheckCircle2,
  Layers,
  ArrowRight,
  Send,
  Cpu,
  Info
} from 'lucide-react';

export const BankersAlgorithmSimulator: React.FC = () => {
  // 5 Processes, 3 Resource types (A, B, C)
  const [allocation, setAllocation] = useState<number[][]>([
    [0, 1, 0], // P0
    [2, 0, 0], // P1
    [3, 0, 2], // P2
    [2, 1, 1], // P3
    [0, 0, 2]  // P4
  ]);

  const [maxDemand, setMaxDemand] = useState<number[][]>([
    [7, 5, 3], // P0
    [3, 2, 2], // P1
    [9, 0, 2], // P2
    [2, 2, 2], // P3
    [4, 3, 3]  // P4
  ]);

  const [available, setAvailable] = useState<number[]>([3, 3, 2]);

  // Request simulation state
  const [reqProcess, setReqProcess] = useState<number>(1);
  const [requestVector, setRequestVector] = useState<number[]>([1, 0, 2]);
  const [requestResult, setRequestResult] = useState<string | null>(null);

  // Auto-calculated Need matrix
  const needMatrix = useMemo(() => {
    return maxDemand.map((row, i) =>
      row.map((maxVal, j) => Math.max(0, maxVal - allocation[i][j]))
    );
  }, [maxDemand, allocation]);

  // Safety Algorithm Calculation
  const safetyResult = useMemo(() => {
    const n = allocation.length;
    const m = available.length;
    const work = [...available];
    const finish = new Array(n).fill(false);
    const safeSeq: number[] = [];
    const stepLogs: string[] = [];

    stepLogs.push(`[INIT] Available vector Work = [${work.join(', ')}]`);

    let count = 0;
    while (count < n) {
      let found = false;
      for (let p = 0; p < n; p++) {
        if (!finish[p]) {
          let canExecute = true;
          for (let j = 0; j < m; j++) {
            if (needMatrix[p][j] > work[j]) {
              canExecute = false;
              break;
            }
          }

          if (canExecute) {
            for (let k = 0; k < m; k++) {
              work[k] += allocation[p][k];
            }
            safeSeq.push(p);
            finish[p] = true;
            found = true;
            count++;
            stepLogs.push(`[PASS ${count}] P${p} executes: Need [${needMatrix[p].join(', ')}] <= Work. Resources freed -> New Work = [${work.join(', ')}]`);
            break;
          }
        }
      }

      if (!found) {
        return {
          isSafe: false,
          safeSeq: [],
          stepLogs: [...stepLogs, `[ERROR] No process satisfies Need <= Work. Deadlock risk! System is in an UNSAFE STATE.`]
        };
      }
    }

    return {
      isSafe: true,
      safeSeq,
      stepLogs: [...stepLogs, `[SUCCESS] Safe Sequence found: <${safeSeq.map((p) => 'P' + p).join(', ')}>`]
    };
  }, [allocation, maxDemand, available, needMatrix]);

  const handleCellChange = (
    matrix: 'alloc' | 'max',
    row: number,
    col: number,
    val: number
  ) => {
    const safeVal = Math.max(0, isNaN(val) ? 0 : val);
    if (matrix === 'alloc') {
      setAllocation((prev) =>
        prev.map((r, i) =>
          i === row ? r.map((c, j) => (j === col ? safeVal : c)) : r
        )
      );
    } else {
      setMaxDemand((prev) =>
        prev.map((r, i) =>
          i === row ? r.map((c, j) => (j === col ? safeVal : c)) : r
        )
      );
    }
  };

  const handleAvailChange = (idx: number, val: number) => {
    const safeVal = Math.max(0, isNaN(val) ? 0 : val);
    setAvailable((prev) =>
      prev.map((c, i) => (i === idx ? safeVal : c))
    );
  };

  const handleTestRequest = () => {
    const p = reqProcess;
    const req = requestVector;

    // Check Request <= Need
    for (let j = 0; j < 3; j++) {
      if (req[j] > needMatrix[p][j]) {
        setRequestResult(`DENIED: Process P${p} requested ${req[j]} of R${j}, which exceeds declared Need ${needMatrix[p][j]}.`);
        return;
      }
    }

    // Check Request <= Available
    for (let j = 0; j < 3; j++) {
      if (req[j] > available[j]) {
        setRequestResult(`WAIT: Process P${p} must wait. Requested ${req[j]} of R${j}, but only ${available[j]} is available.`);
        return;
      }
    }

    // Temporarily allocate
    const tempAlloc = allocation.map((r, i) =>
      i === p ? r.map((val, j) => val + req[j]) : [...r]
    );
    const tempAvail = available.map((val, j) => val - req[j]);
    const tempNeed = maxDemand.map((r, i) =>
      r.map((val, j) => val - tempAlloc[i][j])
    );

    // Run safety check on temporary state
    const n = 5;
    const m = 3;
    const work = [...tempAvail];
    const finish = new Array(n).fill(false);
    let count = 0;

    while (count < n) {
      let found = false;
      for (let i = 0; i < n; i++) {
        if (!finish[i]) {
          let can = true;
          for (let j = 0; j < m; j++) {
            if (tempNeed[i][j] > work[j]) {
              can = false;
              break;
            }
          }
          if (can) {
            for (let k = 0; k < m; k++) work[k] += tempAlloc[i][k];
            finish[i] = true;
            found = true;
            count++;
            break;
          }
        }
      }
      if (!found) break;
    }

    if (count === n) {
      setRequestResult(`GRANTED: Request [${req.join(', ')}] by P${p} leaves system in a SAFE STATE.`);
    } else {
      setRequestResult(`DENIED: Granting request [${req.join(', ')}] would lead to an UNSAFE STATE (potential deadlock). P${p} must wait.`);
    }
  };

  const handleReset = (type: 'safe' | 'unsafe') => {
    if (type === 'safe') {
      setAllocation([
        [0, 1, 0],
        [2, 0, 0],
        [3, 0, 2],
        [2, 1, 1],
        [0, 0, 2]
      ]);
      setMaxDemand([
        [7, 5, 3],
        [3, 2, 2],
        [9, 0, 2],
        [2, 2, 2],
        [4, 3, 3]
      ]);
      setAvailable([3, 3, 2]);
    } else {
      // Unsafe preset
      setAllocation([
        [0, 1, 0],
        [3, 0, 2],
        [3, 0, 2],
        [2, 1, 1],
        [0, 0, 2]
      ]);
      setMaxDemand([
        [7, 5, 3],
        [3, 2, 2],
        [9, 0, 2],
        [2, 2, 2],
        [4, 3, 3]
      ]);
      setAvailable([0, 0, 0]);
    }
    setRequestResult(null);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold uppercase tracking-wider mb-1">
            <Cpu className="w-3 h-3" />
            <span>Deadlock Avoidance</span>
          </div>
          <h4 className="text-sm font-bold text-slate-900">Dijkstra's Banker's Algorithm Simulator</h4>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => handleReset('safe')}
            className="px-3 py-1.5 bg-emerald-800 text-white rounded-xl text-xs font-bold cursor-pointer hover:bg-emerald-900"
          >
            Load Safe Preset
          </button>
          <button
            onClick={() => handleReset('unsafe')}
            className="px-3 py-1.5 bg-rose-800 text-white rounded-xl text-xs font-bold cursor-pointer hover:bg-rose-900"
          >
            Load Unsafe Preset
          </button>
        </div>
      </div>

      {/* Safety Status Banner */}
      <div
        className={`p-4 rounded-2xl border-2 flex items-center justify-between gap-4 ${
          safetyResult.isSafe
            ? 'bg-emerald-50/70 border-emerald-500 text-emerald-900'
            : 'bg-rose-50/70 border-rose-500 text-rose-900 animate-pulse'
        }`}
      >
        <div className="flex items-center gap-3">
          {safetyResult.isSafe ? (
            <ShieldCheck className="w-7 h-7 text-emerald-600 shrink-0" />
          ) : (
            <AlertTriangle className="w-7 h-7 text-rose-600 shrink-0" />
          )}
          <div>
            <h5 className="text-sm font-black">
              {safetyResult.isSafe ? 'SYSTEM IS IN A SAFE STATE' : 'UNSAFE STATE DETECTED!'}
            </h5>
            <p className="text-xs opacity-90">
              {safetyResult.isSafe
                ? `Valid Safe Execution Sequence: <${safetyResult.safeSeq.map((p) => 'P' + p).join(' → ')}>`
                : 'No sequence of process execution guarantees avoidance of circular-wait deadlock.'}
            </p>
          </div>
        </div>
      </div>

      {/* Resource Matrices */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Allocation Matrix */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
          <h5 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Allocation Matrix (Current)
          </h5>
          <table className="w-full text-xs font-mono text-center">
            <thead className="bg-slate-50 text-slate-500 font-sans">
              <tr>
                <th className="p-1">Proc</th>
                <th className="p-1">A</th>
                <th className="p-1">B</th>
                <th className="p-1">C</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {allocation.map((row, i) => (
                <tr key={i}>
                  <td className="p-1 font-bold font-sans">P{i}</td>
                  {row.map((val, j) => (
                    <td key={j} className="p-1">
                      <input
                        type="number"
                        min={0}
                        value={val}
                        onChange={(e) => handleCellChange('alloc', i, j, parseInt(e.target.value))}
                        className="w-10 text-center py-0.5 bg-slate-50 border border-slate-200 rounded font-bold"
                      />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Max Demand Matrix */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
          <h5 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Max Demand Matrix
          </h5>
          <table className="w-full text-xs font-mono text-center">
            <thead className="bg-slate-50 text-slate-500 font-sans">
              <tr>
                <th className="p-1">Proc</th>
                <th className="p-1">A</th>
                <th className="p-1">B</th>
                <th className="p-1">C</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {maxDemand.map((row, i) => (
                <tr key={i}>
                  <td className="p-1 font-bold font-sans">P{i}</td>
                  {row.map((val, j) => (
                    <td key={j} className="p-1">
                      <input
                        type="number"
                        min={0}
                        value={val}
                        onChange={(e) => handleCellChange('max', i, j, parseInt(e.target.value))}
                        className="w-10 text-center py-0.5 bg-slate-50 border border-slate-200 rounded font-bold"
                      />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Calculated Need Matrix + Available Vector */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex justify-between items-center">
            <h5 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Need Matrix (Max - Alloc)
            </h5>
            <span className="text-[10px] text-emerald-700 font-bold">Auto-derived</span>
          </div>

          <table className="w-full text-xs font-mono text-center">
            <thead className="bg-emerald-50 text-emerald-800 font-sans">
              <tr>
                <th className="p-1">Proc</th>
                <th className="p-1">A</th>
                <th className="p-1">B</th>
                <th className="p-1">C</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {needMatrix.map((row, i) => (
                <tr key={i} className="hover:bg-slate-50">
                  <td className="p-1 font-bold font-sans">P{i}</td>
                  {row.map((val, j) => (
                    <td key={j} className="p-1 font-bold text-slate-800">
                      {val}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>

          {/* Available Vector */}
          <div className="pt-2 border-t border-slate-100">
            <span className="text-[10px] font-bold text-slate-400 block mb-1">Available Resource Vector:</span>
            <div className="flex items-center gap-2 font-mono text-xs">
              {['A', 'B', 'C'].map((r, i) => (
                <div key={r} className="flex-1 bg-amber-50 p-1.5 rounded-lg border border-amber-200 text-center">
                  <span className="text-[9px] text-amber-800 font-sans block">Res {r}</span>
                  <input
                    type="number"
                    min={0}
                    value={available[i]}
                    onChange={(e) => handleAvailChange(i, parseInt(e.target.value))}
                    className="w-8 text-center bg-white border border-amber-300 rounded font-black text-amber-900"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Resource Request Validation Engine */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
        <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
          Dynamic Resource Request Validator
        </h4>

        <div className="flex flex-wrap items-center gap-4 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-600 font-bold">Process:</span>
            <select
              value={reqProcess}
              onChange={(e) => setReqProcess(parseInt(e.target.value))}
              className="px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg font-bold"
            >
              {[0, 1, 2, 3, 4].map((p) => (
                <option key={p} value={p}>Process P{p}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2 font-mono">
            <span className="text-slate-600 font-sans font-bold">Request:</span>
            {['A', 'B', 'C'].map((r, idx) => (
              <div key={r} className="flex items-center gap-1">
                <span className="text-[10px] text-slate-400">{r}:</span>
                <input
                  type="number"
                  min={0}
                  value={requestVector[idx]}
                  onChange={(e) => {
                    const val = Math.max(0, parseInt(e.target.value) || 0);
                    setRequestVector((prev) => prev.map((v, i) => (i === idx ? val : v)));
                  }}
                  className="w-10 px-1 py-0.5 text-center bg-slate-50 border border-slate-200 rounded font-bold"
                />
              </div>
            ))}
          </div>

          <button
            onClick={handleTestRequest}
            className="px-4 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold cursor-pointer shadow-xs"
          >
            Validate Request
          </button>
        </div>

        {requestResult && (
          <div
            className={`p-3 rounded-xl text-xs font-bold ${
              requestResult.includes('GRANTED')
                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                : 'bg-rose-50 text-rose-800 border border-rose-200'
            }`}
          >
            {requestResult}
          </div>
        )}
      </div>

      {/* Safety Steps Trace Log */}
      <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 font-mono text-xs text-slate-300">
        <span className="text-slate-500 block mb-2 font-bold uppercase text-[10px]">
          Safety Algorithm Execution Vector Trace:
        </span>
        <div className="space-y-1 max-h-36 overflow-y-auto text-[11px]">
          {safetyResult.stepLogs.map((log, i) => (
            <div key={i} className={log.includes('[SUCCESS]') ? 'text-emerald-400 font-bold' : log.includes('[ERROR]') ? 'text-rose-400' : 'text-slate-300'}>
              {log}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
