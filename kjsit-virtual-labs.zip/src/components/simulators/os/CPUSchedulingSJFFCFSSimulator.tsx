import React, { useState, useMemo } from 'react';
import {
  Clock,
  Play,
  RotateCcw,
  Plus,
  Trash2,
  CheckCircle2,
  Layers,
  ArrowRight,
  TrendingUp,
  Cpu
} from 'lucide-react';

interface Process {
  id: string;
  name: string;
  at: number; // Arrival Time
  bt: number; // Burst Time
  color: string;
}

interface GanttBlock {
  processName: string;
  start: number;
  end: number;
  color: string;
}

interface ProcessResult {
  name: string;
  at: number;
  bt: number;
  ct: number; // Completion Time
  tat: number; // Turnaround Time = CT - AT
  wt: number; // Waiting Time = TAT - BT
  color: string;
}

const COLORS = [
  'bg-blue-500 text-white border-blue-600',
  'bg-emerald-500 text-white border-emerald-600',
  'bg-purple-500 text-white border-purple-600',
  'bg-amber-500 text-white border-amber-600',
  'bg-rose-500 text-white border-rose-600',
  'bg-cyan-500 text-white border-cyan-600'
];

export const CPUSchedulingSJFFCFSSimulator: React.FC = () => {
  const [algorithm, setAlgorithm] = useState<'FCFS' | 'SJF_NP' | 'SRTF'>('FCFS');
  const [processes, setProcesses] = useState<Process[]>([
    { id: '1', name: 'P1', at: 0, bt: 8, color: COLORS[0] },
    { id: '2', name: 'P2', at: 1, bt: 4, color: COLORS[1] },
    { id: '3', name: 'P3', at: 2, bt: 9, color: COLORS[2] },
    { id: '4', name: 'P4', at: 3, bt: 5, color: COLORS[3] }
  ]);

  // Compute Schedule Simulation
  const { ganttChart, results, avgTAT, avgWT } = useMemo(() => {
    if (processes.length === 0) {
      return { ganttChart: [], results: [], avgTAT: 0, avgWT: 0 };
    }

    const n = processes.length;
    const gantt: GanttBlock[] = [];
    const resMap: Record<string, { ct: number; tat: number; wt: number }> = {};

    if (algorithm === 'FCFS') {
      // Sort by Arrival Time
      const sorted = [...processes].sort((a, b) => a.at - b.at);
      let currentTime = 0;

      sorted.forEach((p) => {
        if (currentTime < p.at) {
          // Idle period
          gantt.push({
            processName: 'IDLE',
            start: currentTime,
            end: p.at,
            color: 'bg-slate-200 text-slate-600 border-slate-300'
          });
          currentTime = p.at;
        }

        const start = currentTime;
        const end = currentTime + p.bt;
        gantt.push({
          processName: p.name,
          start,
          end,
          color: p.color
        });
        currentTime = end;

        const ct = end;
        const tat = ct - p.at;
        const wt = tat - p.bt;
        resMap[p.name] = { ct, tat, wt };
      });
    } else if (algorithm === 'SJF_NP') {
      // Non-Preemptive SJF
      let completed = 0;
      let currentTime = 0;
      const done: Record<string, boolean> = {};

      while (completed < n) {
        // Find arrived uncompleted with smallest BT
        const available = processes.filter((p) => p.at <= currentTime && !done[p.name]);

        if (available.length === 0) {
          // Advance to next arrival
          const nextProcs = processes.filter((p) => !done[p.name]);
          const nextArrival = Math.min(...nextProcs.map((p) => p.at));
          gantt.push({
            processName: 'IDLE',
            start: currentTime,
            end: nextArrival,
            color: 'bg-slate-200 text-slate-600 border-slate-300'
          });
          currentTime = nextArrival;
          continue;
        }

        available.sort((a, b) => a.bt - b.bt || a.at - b.at);
        const chosen = available[0];

        const start = currentTime;
        const end = currentTime + chosen.bt;
        gantt.push({
          processName: chosen.name,
          start,
          end,
          color: chosen.color
        });
        currentTime = end;
        done[chosen.name] = true;
        completed++;

        const ct = end;
        const tat = ct - chosen.at;
        const wt = tat - chosen.bt;
        resMap[chosen.name] = { ct, tat, wt };
      }
    } else {
      // SRTF (Preemptive SJF) - Step by step time ticks
      const remBt: Record<string, number> = {};
      processes.forEach((p) => (remBt[p.name] = p.bt));
      let completed = 0;
      let currentTime = 0;
      let currentProcess: Process | null = null;
      let blockStart = 0;

      while (completed < n) {
        // Available procs at currentTime with remBt > 0
        const available = processes.filter((p) => p.at <= currentTime && remBt[p.name] > 0);

        if (available.length === 0) {
          if (currentProcess) {
            gantt.push({
              processName: currentProcess.name,
              start: blockStart,
              end: currentTime,
              color: currentProcess.color
            });
            currentProcess = null;
          }
          const nextArrival = Math.min(...processes.filter((p) => remBt[p.name] > 0).map((p) => p.at));
          gantt.push({
            processName: 'IDLE',
            start: currentTime,
            end: nextArrival,
            color: 'bg-slate-200 text-slate-600 border-slate-300'
          });
          currentTime = nextArrival;
          blockStart = currentTime;
          continue;
        }

        available.sort((a, b) => remBt[a.name] - remBt[b.name] || a.at - b.at);
        const shortest = available[0];

        if (!currentProcess || currentProcess.name !== shortest.name) {
          if (currentProcess) {
            gantt.push({
              processName: currentProcess.name,
              start: blockStart,
              end: currentTime,
              color: currentProcess.color
            });
          }
          currentProcess = shortest;
          blockStart = currentTime;
        }

        remBt[shortest.name]--;
        currentTime++;

        if (remBt[shortest.name] === 0) {
          completed++;
          gantt.push({
            processName: shortest.name,
            start: blockStart,
            end: currentTime,
            color: shortest.color
          });
          currentProcess = null;
          blockStart = currentTime;

          const ct = currentTime;
          const tat = ct - shortest.at;
          const wt = tat - shortest.bt;
          resMap[shortest.name] = { ct, tat, wt };
        }
      }
    }

    const calculatedResults: ProcessResult[] = processes.map((p) => ({
      name: p.name,
      at: p.at,
      bt: p.bt,
      ct: resMap[p.name]?.ct || 0,
      tat: resMap[p.name]?.tat || 0,
      wt: resMap[p.name]?.wt || 0,
      color: p.color
    }));

    const totalTAT = calculatedResults.reduce((acc, curr) => acc + curr.tat, 0);
    const totalWT = calculatedResults.reduce((acc, curr) => acc + curr.wt, 0);

    return {
      ganttChart: gantt,
      results: calculatedResults,
      avgTAT: Number((totalTAT / n).toFixed(2)),
      avgWT: Number((totalWT / n).toFixed(2))
    };
  }, [processes, algorithm]);

  const handleAddProcess = () => {
    if (processes.length >= 6) return;
    const nextNum = processes.length + 1;
    const newProc: Process = {
      id: String(Date.now()),
      name: `P${nextNum}`,
      at: Math.floor(Math.random() * 4),
      bt: Math.floor(Math.random() * 8) + 2,
      color: COLORS[processes.length % COLORS.length]
    };
    setProcesses((prev) => [...prev, newProc]);
  };

  const handleUpdateProcess = (id: string, field: 'at' | 'bt', value: number) => {
    const safeVal = Math.max(0, isNaN(value) ? 0 : value);
    setProcesses((prev) =>
      prev.map((p) => (p.id === id ? { ...p, [field]: safeVal } : p))
    );
  };

  const handleDeleteProcess = (id: string) => {
    if (processes.length <= 2) return;
    setProcesses((prev) => prev.filter((p) => p.id !== id));
  };

  const handleLoadPreset = (type: 'convoy' | 'optimal') => {
    if (type === 'convoy') {
      setProcesses([
        { id: '1', name: 'P1', at: 0, bt: 24, color: COLORS[0] },
        { id: '2', name: 'P2', at: 0, bt: 3, color: COLORS[1] },
        { id: '3', name: 'P3', at: 0, bt: 3, color: COLORS[2] }
      ]);
      setAlgorithm('FCFS');
    } else {
      setProcesses([
        { id: '1', name: 'P1', at: 0, bt: 7, color: COLORS[0] },
        { id: '2', name: 'P2', at: 2, bt: 4, color: COLORS[1] },
        { id: '3', name: 'P3', at: 4, bt: 1, color: COLORS[2] },
        { id: '4', name: 'P4', at: 5, bt: 4, color: COLORS[3] }
      ]);
      setAlgorithm('SRTF');
    }
  };

  const totalDuration = ganttChart.length > 0 ? ganttChart[ganttChart.length - 1].end : 0;

  return (
    <div className="space-y-6">
      {/* Algorithm Selector & Presets */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Cpu className="w-5 h-5 text-amber-600" />
          <div>
            <h4 className="text-sm font-bold text-slate-900">Algorithm Strategy</h4>
            <p className="text-xs text-slate-500">Select CPU scheduling policy to simulate</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setAlgorithm('FCFS')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              algorithm === 'FCFS'
                ? 'bg-amber-800 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            FCFS (First Come First Serve)
          </button>
          <button
            onClick={() => setAlgorithm('SJF_NP')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              algorithm === 'SJF_NP'
                ? 'bg-amber-800 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            SJF (Non-Preemptive)
          </button>
          <button
            onClick={() => setAlgorithm('SRTF')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              algorithm === 'SRTF'
                ? 'bg-amber-800 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            SRTF (Preemptive SJF)
          </button>
        </div>
      </div>

      {/* Main Simulation View: Process Editor + Results */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Process Configuration Table */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Process Workload Table</h4>
            <button
              onClick={handleAddProcess}
              disabled={processes.length >= 6}
              className="inline-flex items-center gap-1 px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded-lg text-xs font-bold transition-colors disabled:opacity-50 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Process</span>
            </button>
          </div>

          <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
            {processes.map((proc) => (
              <div
                key={proc.id}
                className="flex items-center gap-3 p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs"
              >
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-black font-mono shadow-2xs ${proc.color}`}>
                  {proc.name}
                </div>

                <div className="flex-1 grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-slate-400 font-bold block">Arrival (AT)</label>
                    <input
                      type="number"
                      min={0}
                      value={proc.at}
                      onChange={(e) => handleUpdateProcess(proc.id, 'at', parseInt(e.target.value) || 0)}
                      className="w-full px-2 py-1 bg-white border border-slate-300 rounded font-mono text-xs font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 font-bold block">Burst (BT)</label>
                    <input
                      type="number"
                      min={1}
                      value={proc.bt}
                      onChange={(e) => handleUpdateProcess(proc.id, 'bt', parseInt(e.target.value) || 1)}
                      className="w-full px-2 py-1 bg-white border border-slate-300 rounded font-mono text-xs font-bold"
                    />
                  </div>
                </div>

                {processes.length > 2 && (
                  <button
                    onClick={() => handleDeleteProcess(proc.id)}
                    className="text-slate-400 hover:text-rose-600 p-1 cursor-pointer"
                    title="Remove Process"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))}
          </div>

          {/* Quick KJSIT Presets */}
          <div className="pt-3 border-t border-slate-100 space-y-1.5 text-xs">
            <span className="text-[11px] font-bold text-slate-500">Benchmark Test Cases:</span>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => handleLoadPreset('convoy')}
                className="py-1.5 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-bold cursor-pointer"
              >
                Convoy Effect (P1=24)
              </button>
              <button
                onClick={() => handleLoadPreset('optimal')}
                className="py-1.5 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-bold cursor-pointer"
              >
                SJF Preemption Test
              </button>
            </div>
          </div>
        </div>

        {/* Right 2 Cols: Gantt Chart & Metrics */}
        <div className="lg:col-span-2 space-y-6">
          {/* Gantt Chart Visualizer */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-600" />
                <h4 className="text-sm font-bold text-slate-900">CPU Execution Gantt Chart</h4>
              </div>
              <span className="text-xs font-mono text-slate-500">
                Total CPU Time: <strong className="text-slate-900">{totalDuration} ticks</strong>
              </span>
            </div>

            {/* Visual Gantt Bar */}
            <div className="space-y-2">
              <div className="h-14 bg-slate-100 rounded-xl p-1 flex items-center gap-1 overflow-x-auto border border-slate-200">
                {ganttChart.map((block, idx) => {
                  const duration = block.end - block.start;
                  const flexBasis = `${Math.max(8, (duration / totalDuration) * 100)}%`;

                  return (
                    <div
                      key={idx}
                      style={{ flex: `${duration} 0 auto`, minWidth: '40px' }}
                      className={`h-full rounded-lg flex flex-col items-center justify-center font-mono text-xs font-black shadow-2xs border ${block.color}`}
                    >
                      <span>{block.processName}</span>
                      <span className="text-[9px] opacity-80">{duration}t</span>
                    </div>
                  );
                })}
              </div>

              {/* Time axis marks */}
              <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 px-1">
                <span>0</span>
                {ganttChart.map((b, i) => (
                  <span key={i}>{b.end}</span>
                ))}
              </div>
            </div>
          </div>

          {/* Results Table & Average Stats */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Scheduling Performance Metrics
            </h4>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                  <tr>
                    <th className="p-2">Process</th>
                    <th className="p-2">Arrival (AT)</th>
                    <th className="p-2">Burst (BT)</th>
                    <th className="p-2">Completion (CT)</th>
                    <th className="p-2">Turnaround (TAT)</th>
                    <th className="p-2">Waiting (WT)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {results.map((r) => (
                    <tr key={r.name} className="hover:bg-slate-50">
                      <td className="p-2 font-black font-sans flex items-center gap-1.5">
                        <span className={`w-2.5 h-2.5 rounded-full ${r.color}`}></span>
                        <span>{r.name}</span>
                      </td>
                      <td className="p-2">{r.at}</td>
                      <td className="p-2">{r.bt}</td>
                      <td className="p-2 font-bold text-slate-800">{r.ct}</td>
                      <td className="p-2 text-blue-700 font-bold">{r.tat}</td>
                      <td className="p-2 text-emerald-700 font-bold">{r.wt}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Performance Summary Cards */}
            <div className="grid grid-cols-2 gap-4 pt-3 border-t border-slate-100">
              <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-200/80">
                <span className="text-[10px] font-bold text-blue-700 uppercase tracking-wider block">Average Turnaround Time (TAT)</span>
                <span className="text-lg font-black text-blue-900 font-mono mt-0.5 block">{avgTAT} ticks</span>
                <span className="text-[9px] text-blue-600/80">Formula: Σ(CT - AT) / N</span>
              </div>
              <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-200/80">
                <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block">Average Waiting Time (WT)</span>
                <span className="text-lg font-black text-emerald-900 font-mono mt-0.5 block">{avgWT} ticks</span>
                <span className="text-[9px] text-emerald-600/80">Formula: Σ(TAT - BT) / N</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
