import React, { useState, useMemo } from 'react';
import {
  Layers,
  RotateCcw,
  Play,
  CheckCircle2,
  AlertTriangle,
  Cpu,
  Info,
  TrendingUp
} from 'lucide-react';

interface FrameState {
  pageRef: number;
  frames: (number | null)[];
  isHit: boolean;
  victimPage: number | null;
}

export const PageReplacementSimulator: React.FC = () => {
  const [algorithm, setAlgorithm] = useState<'FIFO' | 'LRU' | 'OPT' | 'CLOCK'>('LRU');
  const [numFrames, setNumFrames] = useState<number>(3);
  const [refStringInput, setRefStringInput] = useState<string>('7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1');

  // Parse reference string
  const refString = useMemo(() => {
    return refStringInput
      .split(/[\s,]+/)
      .map((s) => parseInt(s.trim()))
      .filter((n) => !isNaN(n));
  }, [refStringInput]);

  // Execute Page Replacement
  const { history, pageFaults, pageHits, hitRatio, faultRatio } = useMemo(() => {
    if (refString.length === 0) {
      return { history: [], pageFaults: 0, pageHits: 0, hitRatio: '0.0%', faultRatio: '0.0%' };
    }

    const frames: (number | null)[] = new Array(numFrames).fill(null);
    const historySteps: FrameState[] = [];
    let faults = 0;
    let hits = 0;

    if (algorithm === 'FIFO') {
      const queue: number[] = [];
      refString.forEach((page) => {
        const hit = frames.includes(page);
        let victim: number | null = null;

        if (hit) {
          hits++;
        } else {
          faults++;
          const emptyIdx = frames.indexOf(null);
          if (emptyIdx !== -1) {
            frames[emptyIdx] = page;
            queue.push(page);
          } else {
            victim = queue.shift()!;
            const replaceIdx = frames.indexOf(victim);
            frames[replaceIdx] = page;
            queue.push(page);
          }
        }

        historySteps.push({
          pageRef: page,
          frames: [...frames],
          isHit: hit,
          victimPage: victim
        });
      });
    } else if (algorithm === 'LRU') {
      const lastUsed: Record<number, number> = {};
      refString.forEach((page, time) => {
        const hit = frames.includes(page);
        let victim: number | null = null;

        if (hit) {
          hits++;
          lastUsed[page] = time;
        } else {
          faults++;
          const emptyIdx = frames.indexOf(null);
          if (emptyIdx !== -1) {
            frames[emptyIdx] = page;
          } else {
            // Find least recently used
            let minTime = Infinity;
            let lruPage = frames[0]!;
            frames.forEach((f) => {
              if (f !== null && (lastUsed[f] ?? -1) < minTime) {
                minTime = lastUsed[f] ?? -1;
                lruPage = f;
              }
            });
            victim = lruPage;
            const replaceIdx = frames.indexOf(victim);
            frames[replaceIdx] = page;
          }
          lastUsed[page] = time;
        }

        historySteps.push({
          pageRef: page,
          frames: [...frames],
          isHit: hit,
          victimPage: victim
        });
      });
    } else if (algorithm === 'OPT') {
      // Optimal Page Replacement (inspect future references)
      refString.forEach((page, idx) => {
        const hit = frames.includes(page);
        let victim: number | null = null;

        if (hit) {
          hits++;
        } else {
          faults++;
          const emptyIdx = frames.indexOf(null);
          if (emptyIdx !== -1) {
            frames[emptyIdx] = page;
          } else {
            // Find page that will not be used for longest future duration
            let farthest = -1;
            let optPage = frames[0]!;
            frames.forEach((f) => {
              if (f !== null) {
                const nextUse = refString.slice(idx + 1).indexOf(f);
                if (nextUse === -1) {
                  farthest = Infinity;
                  optPage = f;
                } else if (nextUse > farthest) {
                  farthest = nextUse;
                  optPage = f;
                }
              }
            });
            victim = optPage;
            const replaceIdx = frames.indexOf(victim);
            frames[replaceIdx] = page;
          }
        }

        historySteps.push({
          pageRef: page,
          frames: [...frames],
          isHit: hit,
          victimPage: victim
        });
      });
    } else {
      // Clock / Second Chance
      const refBits = new Array(numFrames).fill(0);
      let pointer = 0;

      refString.forEach((page) => {
        const hitIdx = frames.indexOf(page);
        let hit = false;
        let victim: number | null = null;

        if (hitIdx !== -1) {
          hits++;
          hit = true;
          refBits[hitIdx] = 1;
        } else {
          faults++;
          const emptyIdx = frames.indexOf(null);
          if (emptyIdx !== -1) {
            frames[emptyIdx] = page;
            refBits[emptyIdx] = 1;
          } else {
            while (refBits[pointer] === 1) {
              refBits[pointer] = 0;
              pointer = (pointer + 1) % numFrames;
            }
            victim = frames[pointer];
            frames[pointer] = page;
            refBits[pointer] = 1;
            pointer = (pointer + 1) % numFrames;
          }
        }

        historySteps.push({
          pageRef: page,
          frames: [...frames],
          isHit: hit,
          victimPage: victim
        });
      });
    }

    const total = refString.length;
    return {
      history: historySteps,
      pageFaults: faults,
      pageHits: hits,
      hitRatio: `${((hits / total) * 100).toFixed(1)}%`,
      faultRatio: `${((faults / total) * 100).toFixed(1)}%`
    };
  }, [refString, numFrames, algorithm]);

  const handleBeladyPreset = () => {
    setRefStringInput('1, 2, 3, 4, 1, 2, 5, 1, 2, 3, 4, 5');
    setAlgorithm('FIFO');
  };

  const handleIITPreset = () => {
    setRefStringInput('7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1');
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Strategy */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold uppercase tracking-wider mb-1">
            <Cpu className="w-3 h-3" />
            <span>Virtual Memory Subsystem</span>
          </div>
          <h4 className="text-sm font-bold text-slate-900">Page Replacement Algorithm Simulator</h4>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {(['FIFO', 'LRU', 'OPT', 'CLOCK'] as const).map((alg) => (
            <button
              key={alg}
              onClick={() => setAlgorithm(alg)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                algorithm === alg
                  ? 'bg-amber-800 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {alg === 'FIFO' ? 'FIFO' : alg === 'LRU' ? 'LRU' : alg === 'OPT' ? 'Optimal (OPT)' : 'Clock (2nd Chance)'}
            </button>
          ))}
        </div>
      </div>

      {/* Frame & String Config */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="md:col-span-2 space-y-1">
            <label className="font-bold text-slate-700 block">Page Reference String:</label>
            <input
              type="text"
              value={refStringInput}
              onChange={(e) => setRefStringInput(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs focus:bg-white"
            />
          </div>

          <div className="space-y-1">
            <label className="font-bold text-slate-700 block">Frame Capacity (F):</label>
            <div className="flex items-center gap-3">
              <input
                type="range"
                min={3}
                max={5}
                value={numFrames}
                onChange={(e) => setNumFrames(parseInt(e.target.value))}
                className="flex-1 accent-amber-700 cursor-pointer"
              />
              <span className="font-mono font-black text-sm text-slate-900 w-8">{numFrames} frames</span>
            </div>
          </div>
        </div>

        {/* Quick Presets */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 text-xs">
          <span className="text-slate-500 font-bold">Standard Presets:</span>
          <button
            onClick={handleIITPreset}
            className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium cursor-pointer"
          >
            KJSIT 20-Page String
          </button>
          <button
            onClick={handleBeladyPreset}
            className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded-lg font-bold cursor-pointer"
          >
            Belady’s Anomaly Test Case (FIFO 3 vs 4 frames)
          </button>
        </div>
      </div>

      {/* Metrics Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total References</span>
          <span className="text-xl font-black text-slate-900 font-mono mt-1 block">{refString.length}</span>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold text-rose-600 uppercase tracking-wider block">Page Faults (Misses)</span>
          <span className="text-xl font-black text-rose-700 font-mono mt-1 block">{pageFaults}</span>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider block">Page Hits</span>
          <span className="text-xl font-black text-emerald-700 font-mono mt-1 block">{pageHits}</span>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider block">Hit Ratio</span>
          <span className="text-xl font-black text-blue-700 font-mono mt-1 block">{hitRatio}</span>
        </div>
      </div>

      {/* Step-by-Step Frame Matrix Visualizer */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
        <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
          Reference Stream & Memory Frame Matrix
        </h4>

        <div className="overflow-x-auto pb-2">
          <div className="inline-flex gap-2 min-w-full">
            {history.map((step, idx) => (
              <div
                key={idx}
                className={`flex flex-col items-center p-2 rounded-xl border text-xs min-w-[52px] ${
                  step.isHit
                    ? 'bg-emerald-50/80 border-emerald-300'
                    : 'bg-rose-50/80 border-rose-300'
                }`}
              >
                {/* Page Ref Token */}
                <span className="font-mono font-black text-sm text-slate-900 pb-1 border-b border-slate-200 w-full text-center">
                  {step.pageRef}
                </span>

                {/* Frame Slots */}
                <div className="space-y-1 my-2 w-full">
                  {step.frames.map((frameVal, fIdx) => (
                    <div
                      key={fIdx}
                      className={`h-7 rounded flex items-center justify-center font-mono font-bold text-xs ${
                        frameVal === step.pageRef
                          ? step.isHit
                            ? 'bg-emerald-600 text-white'
                            : 'bg-rose-600 text-white'
                          : 'bg-white text-slate-700 border border-slate-200'
                      }`}
                    >
                      {frameVal !== null ? frameVal : '-'}
                    </div>
                  ))}
                </div>

                {/* Hit / Fault Indicator */}
                <span
                  className={`text-[9px] font-bold px-1 py-0.5 rounded uppercase ${
                    step.isHit ? 'bg-emerald-200 text-emerald-800' : 'bg-rose-200 text-rose-800'
                  }`}
                >
                  {step.isHit ? 'HIT' : 'FAULT'}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
