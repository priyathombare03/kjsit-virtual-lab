import React, { useState, useMemo } from 'react';
import {
  Layers,
  RotateCcw,
  HardDrive,
  CheckCircle2,
  TrendingUp,
  Cpu,
  Info,
  ArrowRight
} from 'lucide-react';

export const DiskSchedulingSimulator: React.FC = () => {
  const [algorithm, setAlgorithm] = useState<'FCFS' | 'SSTF' | 'SCAN' | 'CSCAN' | 'LOOK' | 'CLOOK'>('FCFS');
  const [initialHead, setInitialHead] = useState<number>(53);
  const [direction, setDirection] = useState<'RIGHT' | 'LEFT'>('RIGHT');
  const [maxCylinder, setMaxCylinder] = useState<number>(199);
  const [queueInput, setQueueInput] = useState<string>('98, 183, 37, 122, 14, 124, 65, 67');

  const requests = useMemo(() => {
    return queueInput
      .split(/[\s,]+/)
      .map((s) => parseInt(s.trim()))
      .filter((n) => !isNaN(n) && n >= 0 && n <= maxCylinder);
  }, [queueInput, maxCylinder]);

  // Compute Head Trajectory
  const { trajectory, totalHeadMovement, avgSeekMovement } = useMemo(() => {
    if (requests.length === 0) {
      return { trajectory: [initialHead], totalHeadMovement: 0, avgSeekMovement: 0 };
    }

    const path: number[] = [initialHead];
    let movement = 0;

    if (algorithm === 'FCFS') {
      requests.forEach((req) => {
        path.push(req);
      });
    } else if (algorithm === 'SSTF') {
      let current = initialHead;
      const unserviced = [...requests];

      while (unserviced.length > 0) {
        let minDist = Infinity;
        let chosenIdx = 0;

        unserviced.forEach((r, idx) => {
          const dist = Math.abs(r - current);
          if (dist < minDist) {
            minDist = dist;
            chosenIdx = idx;
          }
        });

        const nextTrack = unserviced.splice(chosenIdx, 1)[0];
        path.push(nextTrack);
        current = nextTrack;
      }
    } else if (algorithm === 'SCAN') {
      // Moves towards one end, reverses at boundary
      const left = requests.filter((r) => r < initialHead).sort((a, b) => b - a);
      const right = requests.filter((r) => r >= initialHead).sort((a, b) => a - b);

      if (direction === 'RIGHT') {
        right.forEach((r) => path.push(r));
        if (left.length > 0) {
          path.push(maxCylinder); // reaches end
          left.forEach((r) => path.push(r));
        }
      } else {
        left.forEach((r) => path.push(r));
        if (right.length > 0) {
          path.push(0); // reaches start
          right.forEach((r) => path.push(r));
        }
      }
    } else if (algorithm === 'CSCAN') {
      // Moves towards end, jumps directly to other end
      const left = requests.filter((r) => r < initialHead).sort((a, b) => a - b);
      const right = requests.filter((r) => r >= initialHead).sort((a, b) => a - b);

      if (direction === 'RIGHT') {
        right.forEach((r) => path.push(r));
        if (left.length > 0) {
          path.push(maxCylinder);
          path.push(0);
          left.forEach((r) => path.push(r));
        }
      } else {
        const leftDesc = requests.filter((r) => r <= initialHead).sort((a, b) => b - a);
        const rightDesc = requests.filter((r) => r > initialHead).sort((a, b) => b - a);
        leftDesc.forEach((r) => path.push(r));
        if (rightDesc.length > 0) {
          path.push(0);
          path.push(maxCylinder);
          rightDesc.forEach((r) => path.push(r));
        }
      }
    } else if (algorithm === 'LOOK') {
      // Reverses at last request instead of end of disk
      const left = requests.filter((r) => r < initialHead).sort((a, b) => b - a);
      const right = requests.filter((r) => r >= initialHead).sort((a, b) => a - b);

      if (direction === 'RIGHT') {
        right.forEach((r) => path.push(r));
        left.forEach((r) => path.push(r));
      } else {
        left.forEach((r) => path.push(r));
        right.forEach((r) => path.push(r));
      }
    } else {
      // C-LOOK
      const left = requests.filter((r) => r < initialHead).sort((a, b) => a - b);
      const right = requests.filter((r) => r >= initialHead).sort((a, b) => a - b);

      if (direction === 'RIGHT') {
        right.forEach((r) => path.push(r));
        left.forEach((r) => path.push(r));
      } else {
        const leftDesc = requests.filter((r) => r <= initialHead).sort((a, b) => b - a);
        const rightDesc = requests.filter((r) => r > initialHead).sort((a, b) => b - a);
        leftDesc.forEach((r) => path.push(r));
        rightDesc.forEach((r) => path.push(r));
      }
    }

    for (let i = 1; i < path.length; i++) {
      movement += Math.abs(path[i] - path[i - 1]);
    }

    return {
      trajectory: path,
      totalHeadMovement: movement,
      avgSeekMovement: Number((movement / requests.length).toFixed(2))
    };
  }, [requests, initialHead, algorithm, direction, maxCylinder]);

  const handleIITPreset = () => {
    setQueueInput('98, 183, 37, 122, 14, 124, 65, 67');
    setInitialHead(53);
    setMaxCylinder(199);
  };

  return (
    <div className="space-y-6">
      {/* Algorithm Selector Bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold uppercase tracking-wider mb-1">
            <HardDrive className="w-3 h-3" />
            <span>Secondary Storage Management</span>
          </div>
          <h4 className="text-sm font-bold text-slate-900">Disk Head Arm Scheduling Simulator</h4>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {(['FCFS', 'SSTF', 'SCAN', 'CSCAN', 'LOOK', 'CLOOK'] as const).map((alg) => (
            <button
              key={alg}
              onClick={() => setAlgorithm(alg)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                algorithm === alg
                  ? 'bg-amber-800 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {alg}
            </button>
          ))}
        </div>
      </div>

      {/* Track Config */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="space-y-1">
            <label className="font-bold text-slate-700 block">I/O Track Queue Sequence:</label>
            <input
              type="text"
              value={queueInput}
              onChange={(e) => setQueueInput(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs focus:bg-white"
            />
          </div>

          <div className="space-y-1">
            <label className="font-bold text-slate-700 block">Initial Head Position (0 - {maxCylinder}):</label>
            <div className="flex items-center gap-3">
              <input
                type="range"
                min={0}
                max={maxCylinder}
                value={initialHead}
                onChange={(e) => setInitialHead(parseInt(e.target.value))}
                className="flex-1 accent-amber-700 cursor-pointer"
              />
              <span className="font-mono font-black text-sm text-slate-900 w-8">{initialHead}</span>
            </div>
          </div>

          <div className="space-y-1">
            <label className="font-bold text-slate-700 block">Arm Scan Initial Direction:</label>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setDirection('RIGHT')}
                className={`flex-1 py-2 rounded-xl font-bold text-xs cursor-pointer ${
                  direction === 'RIGHT' ? 'bg-amber-800 text-white shadow-xs' : 'bg-slate-100 text-slate-700'
                }`}
              >
                High Cylinders (→)
              </button>
              <button
                onClick={() => setDirection('LEFT')}
                className={`flex-1 py-2 rounded-xl font-bold text-xs cursor-pointer ${
                  direction === 'LEFT' ? 'bg-amber-800 text-white shadow-xs' : 'bg-slate-100 text-slate-700'
                }`}
              >
                Low Cylinders (←)
              </button>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 pt-2 border-t border-slate-100 text-xs">
          <span className="text-slate-500 font-bold">Standard Presets:</span>
          <button
            onClick={handleIITPreset}
            className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium cursor-pointer"
          >
            KJSIT Benchmark (Head 53, Tracks: 98, 183, 37, 122, 14, 124, 65, 67)
          </button>
        </div>
      </div>

      {/* Metrics Bar */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Requests</span>
          <span className="text-xl font-black text-slate-900 font-mono mt-1 block">{requests.length}</span>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold text-amber-700 uppercase tracking-wider block">Total Head Movement</span>
          <span className="text-xl font-black text-amber-900 font-mono mt-1 block">{totalHeadMovement} cylinders</span>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider block">Average Seek Distance</span>
          <span className="text-xl font-black text-blue-700 font-mono mt-1 block">{avgSeekMovement} cyl/req</span>
        </div>
      </div>

      {/* Interactive SVG Trajectory Visualizer */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Head Arm Motion Plot (Cylinder Position vs Time Sequence)
          </h4>
          <span className="text-xs font-mono text-slate-500">
            Path: {trajectory.join(' → ')}
          </span>
        </div>

        <div className="w-full bg-slate-950 p-4 rounded-2xl border border-slate-800 overflow-x-auto">
          <svg className="w-full h-64 min-w-[500px]" viewBox="0 0 600 240">
            {/* Grid lines */}
            {[0, 50, 100, 150, 199].map((cyl) => {
              const x = (cyl / maxCylinder) * 540 + 30;
              return (
                <g key={cyl}>
                  <line x1={x} y1={20} x2={x} y2={210} stroke="#334155" strokeDasharray="3,3" />
                  <text x={x} y={15} fill="#94a3b8" fontSize="10" textAnchor="middle" fontFamily="monospace">
                    {cyl}
                  </text>
                </g>
              );
            })}

            {/* Path lines */}
            {trajectory.map((pos, idx) => {
              if (idx === 0) return null;
              const prev = trajectory[idx - 1];
              const x1 = (prev / maxCylinder) * 540 + 30;
              const y1 = ((idx - 1) / (trajectory.length - 1)) * 180 + 30;
              const x2 = (pos / maxCylinder) * 540 + 30;
              const y2 = (idx / (trajectory.length - 1)) * 180 + 30;

              return (
                <line
                  key={idx}
                  x1={x1}
                  y1={y1}
                  x2={x2}
                  y2={y2}
                  stroke="#f59e0b"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                />
              );
            })}

            {/* Nodes */}
            {trajectory.map((pos, idx) => {
              const x = (pos / maxCylinder) * 540 + 30;
              const y = (idx / (trajectory.length - 1 || 1)) * 180 + 30;

              return (
                <g key={idx}>
                  <circle
                    cx={x}
                    cy={y}
                    r={idx === 0 ? "6" : "4.5"}
                    fill={idx === 0 ? "#10b981" : "#fbbf24"}
                    stroke="#ffffff"
                    strokeWidth="1.5"
                  />
                  <text x={x} y={y - 8} fill="#f1f5f9" fontSize="9" textAnchor="middle" fontFamily="monospace">
                    {pos}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>
      </div>
    </div>
  );
};
