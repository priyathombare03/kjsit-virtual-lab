import React, { useState, useMemo } from 'react';
import {
  Layers,
  RotateCcw,
  Zap,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Cpu,
  Info
} from 'lucide-react';

interface MemoryBlock {
  id: number;
  totalSize: number;
  allocatedSize: number;
  processName: string | null;
  color: string;
}

interface ProcessReq {
  id: string;
  name: string;
  size: number;
}

export const MemoryAllocationSimulator: React.FC = () => {
  const [strategy, setStrategy] = useState<'FIRST' | 'BEST' | 'WORST' | 'NEXT'>('FIRST');

  const [initialBlocks, setInitialBlocks] = useState<number[]>([100, 500, 200, 300, 600]);
  const [processes, setProcesses] = useState<ProcessReq[]>([
    { id: '1', name: 'P1', size: 212 },
    { id: '2', name: 'P2', size: 417 },
    { id: '3', name: 'P3', size: 112 },
    { id: '4', name: 'P4', size: 426 }
  ]);

  const [isCompacted, setIsCompacted] = useState<boolean>(false);

  // Compute allocation state
  const { blocksState, allocationResult, totalFreeMemory, externalFrag } = useMemo(() => {
    const blocks: MemoryBlock[] = initialBlocks.map((size, idx) => ({
      id: idx + 1,
      totalSize: size,
      allocatedSize: 0,
      processName: null,
      color: 'bg-slate-100 text-slate-700'
    }));

    const result: { proc: ProcessReq; blockId: number | null; status: string }[] = [];
    const colors = [
      'bg-blue-600 text-white border-blue-700',
      'bg-emerald-600 text-white border-emerald-700',
      'bg-purple-600 text-white border-purple-700',
      'bg-amber-600 text-white border-amber-700',
      'bg-rose-600 text-white border-rose-700'
    ];

    let lastAllocatedIdx = 0;

    processes.forEach((p, pIdx) => {
      let chosenIdx = -1;

      if (strategy === 'FIRST') {
        for (let i = 0; i < blocks.length; i++) {
          const rem = blocks[i].totalSize - blocks[i].allocatedSize;
          if (rem >= p.size) {
            chosenIdx = i;
            break;
          }
        }
      } else if (strategy === 'BEST') {
        let minRem = Infinity;
        for (let i = 0; i < blocks.length; i++) {
          const rem = blocks[i].totalSize - blocks[i].allocatedSize;
          if (rem >= p.size && rem < minRem) {
            minRem = rem;
            chosenIdx = i;
          }
        }
      } else if (strategy === 'WORST') {
        let maxRem = -1;
        for (let i = 0; i < blocks.length; i++) {
          const rem = blocks[i].totalSize - blocks[i].allocatedSize;
          if (rem >= p.size && rem > maxRem) {
            maxRem = rem;
            chosenIdx = i;
          }
        }
      } else {
        // NEXT FIT
        const n = blocks.length;
        for (let step = 0; step < n; step++) {
          const i = (lastAllocatedIdx + step) % n;
          const rem = blocks[i].totalSize - blocks[i].allocatedSize;
          if (rem >= p.size) {
            chosenIdx = i;
            lastAllocatedIdx = i;
            break;
          }
        }
      }

      if (chosenIdx !== -1) {
        blocks[chosenIdx].allocatedSize += p.size;
        blocks[chosenIdx].processName = blocks[chosenIdx].processName
          ? `${blocks[chosenIdx].processName}, ${p.name}`
          : p.name;
        blocks[chosenIdx].color = colors[pIdx % colors.length];

        result.push({
          proc: p,
          blockId: blocks[chosenIdx].id,
          status: `Allocated to Block ${blocks[chosenIdx].id}`
        });
      } else {
        result.push({
          proc: p,
          blockId: null,
          status: 'Not Allocated (Fragmented)'
        });
      }
    });

    const totalFree = blocks.reduce(
      (acc, b) => acc + (b.totalSize - b.allocatedSize),
      0
    );

    const unallocated = result.filter((r) => r.blockId === null);
    const unallocatedSizeNeeded = unallocated.reduce((acc, r) => acc + r.proc.size, 0);

    const extFrag =
      unallocated.length > 0 && totalFree >= unallocated[0].proc.size;

    return {
      blocksState: blocks,
      allocationResult: result,
      totalFreeMemory: totalFree,
      externalFrag: extFrag
    };
  }, [initialBlocks, processes, strategy, isCompacted]);

  const handleCompaction = () => {
    // Compact all allocated memory into one side and free holes into a single partition
    const totalAlloc = blocksState.reduce((acc, b) => acc + b.allocatedSize, 0);
    const totalCap = initialBlocks.reduce((acc, b) => acc + b, 0);
    const freeChunk = totalCap - totalAlloc;

    setInitialBlocks([totalAlloc, freeChunk]);
    setIsCompacted(true);
  };

  const handleReset = () => {
    setInitialBlocks([100, 500, 200, 300, 600]);
    setIsCompacted(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Strategy Selector */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold uppercase tracking-wider mb-1">
            <Cpu className="w-3 h-3" />
            <span>Memory Management Strategy</span>
          </div>
          <h4 className="text-sm font-bold text-slate-900">Dynamic Contiguous Memory Allocation</h4>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {(['FIRST', 'BEST', 'WORST', 'NEXT'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setStrategy(s)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                strategy === s
                  ? 'bg-amber-800 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {s === 'FIRST' ? 'First Fit' : s === 'BEST' ? 'Best Fit' : s === 'WORST' ? 'Worst Fit' : 'Next Fit'}
            </button>
          ))}

          <button
            onClick={handleCompaction}
            className="px-3 py-1.5 bg-blue-700 hover:bg-blue-800 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Compact Memory</span>
          </button>

          <button
            onClick={handleReset}
            className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
            title="Reset"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* External Fragmentation Alert */}
      {externalFrag && (
        <div className="p-4 bg-amber-50 border border-amber-300 rounded-2xl flex items-center justify-between gap-3 text-amber-900">
          <div className="flex items-center gap-2.5">
            <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
            <div className="text-xs">
              <strong className="font-bold">External Fragmentation Detected:</strong> Total free memory ({totalFreeMemory}KB) is sufficient, but no single contiguous block fits the waiting process. Use <strong>Compact Memory</strong> to merge free holes.
            </div>
          </div>
        </div>
      )}

      {/* Main Simulation View */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Process Requests */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Process Request Queue
          </h4>

          <div className="space-y-2">
            {allocationResult.map((res) => {
              const isAllocated = res.blockId !== null;
              return (
                <div
                  key={res.proc.id}
                  className={`p-3 rounded-xl border flex items-center justify-between text-xs ${
                    isAllocated
                      ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                      : 'bg-rose-50/70 border-rose-200 text-rose-900'
                  }`}
                >
                  <div>
                    <span className="font-black text-sm block">{res.proc.name}</span>
                    <span className="text-[11px] opacity-80">Request: {res.proc.size} KB</span>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded font-bold text-[10px] uppercase ${
                      isAllocated ? 'bg-emerald-200 text-emerald-800' : 'bg-rose-200 text-rose-800'
                    }`}
                  >
                    {res.status}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Center & Right: Visual Memory Blocks Map */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Physical RAM Partition Layout
              </h4>
              <span className="text-xs font-mono text-slate-500">
                Total Free Space: <strong className="text-emerald-700">{totalFreeMemory} KB</strong>
              </span>
            </div>

            {/* Visual RAM Blocks */}
            <div className="space-y-3">
              {blocksState.map((block) => {
                const fillPercent = Math.min(100, Math.round((block.allocatedSize / block.totalSize) * 100));
                const freeSpace = block.totalSize - block.allocatedSize;

                return (
                  <div key={block.id} className="space-y-1">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="font-bold text-slate-800">
                        Block {block.id} ({block.totalSize} KB)
                      </span>
                      <span className="text-slate-500 text-[11px]">
                        Used: {block.allocatedSize} KB | Free: {freeSpace} KB
                      </span>
                    </div>

                    {/* Progress representation */}
                    <div className="h-9 bg-slate-100 rounded-xl overflow-hidden flex border border-slate-200">
                      {block.allocatedSize > 0 && (
                        <div
                          style={{ width: `${fillPercent}%` }}
                          className={`h-full ${block.color} flex items-center justify-center font-mono text-[11px] font-bold px-2 truncate transition-all`}
                        >
                          {block.processName} ({block.allocatedSize}KB)
                        </div>
                      )}
                      {freeSpace > 0 && (
                        <div className="flex-1 h-full bg-slate-50 flex items-center justify-center text-[10px] text-slate-400 font-mono italic">
                          Hole: {freeSpace}KB
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Theory card */}
          <div className="bg-amber-50/70 p-4 rounded-2xl border border-amber-200 text-xs text-amber-900 space-y-1.5">
            <h5 className="font-bold flex items-center gap-1.5 text-amber-900">
              <Info className="w-4 h-4 text-amber-700" />
              Dynamic Storage Placement Trade-offs
            </h5>
            <p className="leading-relaxed text-[11px] text-amber-800/90">
              First Fit is generally the fastest because it terminates on the first match. Best Fit produces minimal leftovers per block, often creating micro-slivers. Worst Fit creates large residual holes that can accommodate future processes.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
