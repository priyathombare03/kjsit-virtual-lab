import React, { useState } from 'react';
import {
  GitBranch,
  Play,
  RotateCcw,
  Terminal,
  ShieldCheck,
  AlertTriangle,
  Layers,
  Cpu,
  ArrowRight,
  Info,
  CheckCircle2,
  Trash2
} from 'lucide-react';

interface ProcessNode {
  id: number;
  pid: number;
  ppid: number;
  name: string;
  state: 'RUNNING' | 'READY' | 'WAITING' | 'ZOMBIE' | 'ORPHAN' | 'TERMINATED';
  children: number[];
  exitCode?: number;
}

export const ProcessForkSimulator: React.FC = () => {
  const [processes, setProcesses] = useState<ProcessNode[]>([
    {
      id: 1,
      pid: 1000,
      ppid: 1, // init
      name: 'main_parent (bash)',
      state: 'RUNNING',
      children: []
    }
  ]);
  const [nextPid, setNextPid] = useState(1001);
  const [selectedPid, setSelectedPid] = useState<number>(1000);
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    '[INIT] System booted. Root process systemd (PID 1) initialized.',
    '[EXEC] Process main_parent started with PID 1000, PPID 1.'
  ]);

  const addLog = (msg: string) => {
    setTerminalLogs((prev) => [...prev.slice(-15), msg]);
  };

  const handleFork = (parentPid: number) => {
    const parent = processes.find((p) => p.pid === parentPid);
    if (!parent || parent.state === 'TERMINATED' || parent.state === 'ZOMBIE') {
      addLog(`[ERROR] Cannot fork from dead/zombie process PID ${parentPid}`);
      return;
    }

    const childPid = nextPid;
    setNextPid((prev) => prev + 1);

    const newChild: ProcessNode = {
      id: childPid,
      pid: childPid,
      ppid: parentPid,
      name: `child_p${childPid}`,
      state: 'READY',
      children: []
    };

    setProcesses((prev) =>
      prev
        .map((p) =>
          p.pid === parentPid ? { ...p, children: [...p.children, childPid] } : p
        )
        .concat(newChild)
    );

    addLog(`[SYSCALL] fork() invoked by PID ${parentPid} -> Spawned child PID ${childPid}`);
    addLog(`[PCB] Child PID ${childPid} created. PPID: ${parentPid}. Memory shared via Copy-On-Write (COW).`);
  };

  const handleWait = (parentPid: number) => {
    const parent = processes.find((p) => p.pid === parentPid);
    if (!parent || parent.children.length === 0) {
      addLog(`[WAIT] PID ${parentPid} has no child processes to wait for.`);
      return;
    }

    // Find any zombie children or active children
    const zombieChild = processes.find(
      (p) => p.ppid === parentPid && p.state === 'ZOMBIE'
    );

    if (zombieChild) {
      // Reap the zombie
      setProcesses((prev) => prev.filter((p) => p.pid !== zombieChild.pid));
      addLog(`[WAIT REAP] Parent PID ${parentPid} invoked wait(). Reaped Zombie PID ${zombieChild.pid} (Exit code: ${zombieChild.exitCode ?? 0}). Removed from Process Table.`);
    } else {
      const activeChild = processes.find(
        (p) => p.ppid === parentPid && (p.state === 'RUNNING' || p.state === 'READY')
      );
      if (activeChild) {
        addLog(`[WAIT BLOCK] Parent PID ${parentPid} blocking until child PID ${activeChild.pid} invokes exit().`);
      }
    }
  };

  const handleExit = (targetPid: number, isZombieTrigger: boolean = false) => {
    if (targetPid === 1000 && processes.length > 1) {
      // Parent exits before children -> Children become orphans adopted by PID 1
      setProcesses((prev) =>
        prev
          .filter((p) => p.pid !== 1000)
          .map((p) => (p.ppid === 1000 ? { ...p, ppid: 1, state: 'ORPHAN' } : p))
      );
      addLog(`[ORPHAN TRIGGER] Parent PID 1000 exited! All child processes reparented to init/systemd (PID 1).`);
      return;
    }

    const target = processes.find((p) => p.pid === targetPid);
    if (!target) return;

    if (isZombieTrigger) {
      // Child terminates, but parent does not wait() -> Zombie
      setProcesses((prev) =>
        prev.map((p) =>
          p.pid === targetPid
            ? { ...p, state: 'ZOMBIE', exitCode: 0 }
            : p
        )
      );
      addLog(`[ZOMBIE CREATED] Child PID ${targetPid} invoked exit(0), but parent PID ${target.ppid} has not called wait(). Process remains as <defunct> in Process Table.`);
    } else {
      // Reaped or normal termination
      setProcesses((prev) => prev.filter((p) => p.pid !== targetPid));
      addLog(`[TERMINATE] Process PID ${targetPid} terminated and cleaned up.`);
    }
  };

  const handleReset = () => {
    setProcesses([
      {
        id: 1,
        pid: 1000,
        ppid: 1,
        name: 'main_parent (bash)',
        state: 'RUNNING',
        children: []
      }
    ]);
    setNextPid(1001);
    setSelectedPid(1000);
    setTerminalLogs([
      '[RESET] Process table reset to initial state.',
      '[EXEC] Process main_parent started with PID 1000, PPID 1.'
    ]);
  };

  const selectedProcess = processes.find((p) => p.pid === selectedPid) || processes[0];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 text-white p-5 rounded-2xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-2.5 py-0.5 rounded-full bg-amber-950/80 border border-amber-500/30 text-amber-300 text-[10px] font-bold uppercase tracking-wider mb-1.5">
            <Cpu className="w-3 h-3" />
            <span>UNIX Kernel Process Subsystem</span>
          </div>
          <h3 className="text-lg font-black text-white">Process Creation, Forking & Lifecycle Simulator</h3>
          <p className="text-xs text-slate-300">
            Interactive visualization of fork(), exec(), wait(), and exit() system calls, PCB structures, and Zombie/Orphan process states.
          </p>
        </div>

        <button
          onClick={handleReset}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer self-start md:self-auto"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Process Tree</span>
        </button>
      </div>

      {/* Main Grid: Visual Tree + Control Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Process Tree & Process Table */}
        <div className="lg:col-span-2 space-y-6">
          {/* Visual Process Hierarchy */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <GitBranch className="w-4 h-4 text-amber-600" />
                <h4 className="text-sm font-bold text-slate-900">Active Process Hierarchy Tree</h4>
              </div>
              <span className="text-xs text-slate-500 font-mono">
                Active Processes: <strong className="text-slate-800">{processes.length}</strong>
              </span>
            </div>

            {/* Tree nodes rendering */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 min-h-[220px] flex flex-wrap gap-4 items-center justify-center">
              {processes.length === 0 ? (
                <div className="text-center text-xs text-slate-400 py-8">
                  No active processes. Click Reset to restore init.
                </div>
              ) : (
                processes.map((proc) => {
                  const isSelected = selectedProcess?.pid === proc.pid;
                  const isZombie = proc.state === 'ZOMBIE';
                  const isOrphan = proc.state === 'ORPHAN';

                  return (
                    <div
                      key={proc.pid}
                      onClick={() => setSelectedPid(proc.pid)}
                      className={`p-4 rounded-xl border-2 transition-all cursor-pointer w-48 shadow-2xs relative ${
                        isSelected
                          ? 'border-amber-600 bg-amber-50/70 ring-2 ring-amber-500/20'
                          : isZombie
                          ? 'border-rose-300 bg-rose-50/60'
                          : isOrphan
                          ? 'border-purple-300 bg-purple-50/60'
                          : 'border-slate-200 bg-white hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-xs font-mono font-black text-slate-900">PID: {proc.pid}</span>
                        <span
                          className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase ${
                            isZombie
                              ? 'bg-rose-200 text-rose-800'
                              : isOrphan
                              ? 'bg-purple-200 text-purple-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {proc.state}
                        </span>
                      </div>
                      <div className="text-[11px] font-semibold text-slate-700 truncate">{proc.name}</div>
                      <div className="text-[10px] text-slate-500 font-mono mt-1">PPID: {proc.ppid}</div>

                      {/* Quick action buttons on card */}
                      <div className="mt-3 pt-2 border-t border-slate-200/60 flex items-center justify-between gap-1">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleFork(proc.pid);
                          }}
                          className="px-2 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded text-[10px] font-bold cursor-pointer transition-colors"
                          title="Spawn child process via fork()"
                        >
                          + fork()
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleExit(proc.pid, true);
                          }}
                          className="px-2 py-1 bg-rose-100 hover:bg-rose-200 text-rose-700 rounded text-[10px] font-bold cursor-pointer transition-colors"
                          title="Exit without wait() -> Become Zombie"
                        >
                          Zombie
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleExit(proc.pid, false);
                          }}
                          className="p-1 text-slate-400 hover:text-rose-600 cursor-pointer"
                          title="Terminate"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Quick Helper Scenarios */}
            <div className="mt-4 flex flex-wrap gap-2 text-xs">
              <span className="font-bold text-slate-700 flex items-center gap-1">Preset Scenarios:</span>
              <button
                onClick={() => {
                  handleFork(1000);
                  setTimeout(() => handleFork(1000), 100);
                }}
                className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium cursor-pointer"
              >
                1 Parent + 2 Children
              </button>
              <button
                onClick={() => {
                  handleReset();
                  setTimeout(() => {
                    handleFork(1000);
                    setTimeout(() => handleExit(1001, true), 100);
                  }, 100);
                }}
                className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-800 rounded-lg font-medium border border-rose-200 cursor-pointer"
              >
                Demonstrate Zombie Process
              </button>
              <button
                onClick={() => {
                  handleReset();
                  setTimeout(() => {
                    handleFork(1000);
                    setTimeout(() => handleExit(1000, false), 100);
                  }, 100);
                }}
                className="px-2.5 py-1 bg-purple-50 hover:bg-purple-100 text-purple-800 rounded-lg font-medium border border-purple-200 cursor-pointer"
              >
                Demonstrate Orphan (Adopted by PID 1)
              </button>
            </div>
          </div>

          {/* Linux Kernel Terminal Trace */}
          <div className="bg-slate-950 text-slate-100 p-4 rounded-2xl border border-slate-800 font-mono text-xs shadow-2xs">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-slate-400">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-emerald-400" />
                <span>Kernel System Call Trace (strace log)</span>
              </div>
              <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded">Live Stream</span>
            </div>
            <div className="space-y-1 max-h-40 overflow-y-auto pr-2 text-[11px] leading-relaxed">
              {terminalLogs.map((log, idx) => (
                <div
                  key={idx}
                  className={
                    log.includes('[ERROR]')
                      ? 'text-rose-400'
                      : log.includes('[ZOMBIE')
                      ? 'text-amber-400'
                      : log.includes('[ORPHAN')
                      ? 'text-purple-400'
                      : log.includes('[SYSCALL]')
                      ? 'text-emerald-400'
                      : 'text-slate-300'
                  }
                >
                  {log}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Col: Process Control Block (PCB) Inspector & System Call Controller */}
        <div className="space-y-6">
          {/* PCB Inspector */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-100">
              <Layers className="w-4 h-4 text-amber-600" />
              <h4 className="text-sm font-bold text-slate-900">
                Process Control Block (PCB)
              </h4>
            </div>

            {selectedProcess ? (
              <div className="space-y-3 text-xs">
                <div className="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-200 font-mono">
                  <div>
                    <span className="text-slate-400 block text-[10px]">PROCESS ID</span>
                    <strong className="text-slate-800 text-sm">{selectedProcess.pid}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">PARENT PID</span>
                    <strong className="text-slate-800 text-sm">{selectedProcess.ppid}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">EXEC STATE</span>
                    <span className="text-emerald-700 font-bold">{selectedProcess.state}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">PROGRAM COUNTER</span>
                    <span className="text-slate-700">0x7FFF8A40</span>
                  </div>
                </div>

                <div className="space-y-1.5 pt-1">
                  <div className="flex justify-between text-slate-600">
                    <span className="text-slate-400">File Descriptors:</span>
                    <span className="font-mono text-[11px]">0 (stdin), 1 (stdout), 2 (stderr)</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span className="text-slate-400">Memory Segments:</span>
                    <span className="font-mono text-[11px]">Text (4KB), Data (2KB), Heap (16KB)</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span className="text-slate-400">Scheduling Priority:</span>
                    <span className="font-mono text-[11px]">Nice: 0 (Normal Priority)</span>
                  </div>
                </div>

                {/* Actions for Selected Process */}
                <div className="pt-3 border-t border-slate-100 space-y-2">
                  <span className="text-[11px] font-bold text-slate-700 block">Execute System Calls on PID {selectedProcess.pid}:</span>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => handleFork(selectedProcess.pid)}
                      className="w-full py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold text-xs cursor-pointer shadow-xs transition-colors"
                    >
                      fork()
                    </button>
                    <button
                      onClick={() => handleWait(selectedProcess.pid)}
                      className="w-full py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg font-bold text-xs cursor-pointer transition-colors"
                    >
                      wait()
                    </button>
                  </div>
                  <button
                    onClick={() => handleExit(selectedProcess.pid, false)}
                    className="w-full py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg font-bold text-xs cursor-pointer transition-colors"
                  >
                    exit(0) [Normal Termination]
                  </button>
                </div>
              </div>
            ) : (
              <p className="text-xs text-slate-400">Select a process node to inspect PCB.</p>
            )}
          </div>

          {/* Key Insights Callout */}
          <div className="bg-amber-50/70 p-4 rounded-2xl border border-amber-200 text-xs text-amber-900 space-y-1.5">
            <div className="flex items-center gap-1.5 font-bold text-amber-800">
              <Info className="w-4 h-4 text-amber-600" />
              <span>Copy-On-Write (COW) Optimization</span>
            </div>
            <p className="leading-relaxed text-[11px] text-amber-800/90">
              Modern UNIX kernels optimize fork() by sharing the same physical pages read-only until either the parent or child process executes a memory write instruction.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
