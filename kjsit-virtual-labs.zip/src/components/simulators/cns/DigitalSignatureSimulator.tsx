import React, { useState } from 'react';
import { Award, Shield, CheckCircle2, XCircle, Key, FileText, AlertTriangle, RefreshCw, Lock, Unlock } from 'lucide-react';

export const DigitalSignatureSimulator: React.FC = () => {
  const [docText, setDocText] = useState('Somaiya KJSIT Autonomous Certificate: Grade A+ (10.0 CGPA)');
  const [tamperedText, setTamperedText] = useState('Somaiya KJSIT Autonomous Certificate: Grade A+ (10.0 CGPA)');
  const [isTampered, setIsTampered] = useState(false);

  // RSA Parameters for demo signing
  const p = 61, q = 53, n = 3233, e = 17, d = 2753;

  // Simple string hash mod n
  const computeHash = (text: string, mod: number) => {
    let h = 0;
    for (let i = 0; i < text.length; i++) {
      h = (h * 31 + text.charCodeAt(i)) % mod;
    }
    return h || 1;
  };

  const powerMod = (base: number, exp: number, mod: number) => {
    let res = 1;
    base = base % mod;
    while (exp > 0) {
      if (exp % 2 === 1) res = (res * base) % mod;
      base = (base * base) % mod;
      exp = Math.floor(exp / 2);
    }
    return res;
  };

  // Sign original document with Private Key d
  const originalHash = computeHash(docText, n);
  const signature = powerMod(originalHash, d, n);

  // Receiver verifies using Public Key (e, n)
  const currentText = isTampered ? tamperedText : docText;
  const receiverCalculatedHash = computeHash(currentText, n);
  const recoveredHashFromSignature = powerMod(signature, e, n);
  const isSignatureValid = receiverCalculatedHash === recoveredHashFromSignature;

  return (
    <div className="space-y-6">
      {/* Sender Signing Workspace */}
      <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-4">
        <h4 className="font-bold text-zinc-900 flex items-center gap-2">
          <Award className="w-5 h-5 text-red-700" />
          Sender Document Signing (Private Key Signing)
        </h4>

        <div>
          <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
            Original Document / Certificate Payload
          </label>
          <textarea
            value={docText}
            onChange={(e) => {
              setDocText(e.target.value);
              setTamperedText(e.target.value);
            }}
            className="w-full p-2.5 text-sm border border-zinc-300 rounded-lg font-mono focus:ring-2 focus:ring-red-700"
            rows={2}
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs">
          <div className="p-3 bg-zinc-50 border border-zinc-200 rounded-lg">
            <span className="text-zinc-500 text-[10px] uppercase block">1. Document Hash H(M)</span>
            <span className="text-sm font-bold text-zinc-900">{originalHash}</span>
          </div>

          <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
            <span className="text-red-700 text-[10px] uppercase font-bold block">2. Private Key d</span>
            <span className="text-sm font-bold text-red-800">d = {d} (Modulus n = {n})</span>
          </div>

          <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
            <span className="text-amber-800 text-[10px] uppercase font-bold block">3. Digital Signature S</span>
            <span className="text-sm font-bold text-amber-900">S = ({originalHash}^{d}) mod {n} = {signature}</span>
          </div>
        </div>
      </div>

      {/* Receiver Verification & Tamper Testing Sandbox */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-zinc-900 flex items-center gap-2">
              <FileText className="w-5 h-5 text-red-700" />
              Document in Transit
            </h4>
            <button
              onClick={() => setIsTampered(!isTampered)}
              className={`px-3 py-1 text-xs font-bold rounded-lg border transition-all flex items-center gap-1 cursor-pointer ${
                isTampered
                  ? 'bg-red-800 text-white border-red-900 shadow-xs'
                  : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200 border-zinc-300'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              {isTampered ? 'Tampering Active' : 'Simulate Attacker Tampering'}
            </button>
          </div>

          {isTampered ? (
            <div>
              <label className="block text-xs font-semibold text-red-700 uppercase mb-1">
                Tampered Content (Adversary modified data in transit)
              </label>
              <textarea
                value={tamperedText}
                onChange={(e) => setTamperedText(e.target.value)}
                className="w-full p-2.5 text-sm border-2 border-red-500 bg-red-50 rounded-lg font-mono text-red-900"
                rows={2}
              />
              <span className="text-[11px] text-red-600 font-semibold block mt-1">
                ⚠️ Notice how signature remained unchanged while document was modified!
              </span>
            </div>
          ) : (
            <div className="p-3 bg-zinc-50 border border-zinc-200 rounded-lg font-mono text-xs text-zinc-700">
              {docText}
            </div>
          )}

          <div className="p-3 bg-zinc-50 border border-zinc-200 rounded-lg font-mono text-xs">
            <span className="text-zinc-500 text-[10px] uppercase block mb-1">Attached Digital Signature:</span>
            <span className="font-bold text-zinc-900">{signature}</span>
          </div>
        </div>

        {/* Verification Engine */}
        <div className={`p-5 rounded-xl border shadow-xs flex flex-col justify-between ${isSignatureValid ? 'bg-zinc-900 border-zinc-800 text-white' : 'bg-red-950 border-red-700 text-white'}`}>
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <span className="text-xs font-semibold uppercase text-zinc-400">
                Public Verification Result
              </span>
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold flex items-center gap-1 ${isSignatureValid ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-red-500/30 text-red-200 border border-red-500'}`}>
                {isSignatureValid ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
                {isSignatureValid ? 'AUTHENTIC (VALID)' : 'TAMPERED (INVALID)'}
              </span>
            </div>

            <div className="mt-4 space-y-3 font-mono text-xs">
              <div className="p-3 bg-zinc-950/60 rounded-lg border border-zinc-800">
                <span className="text-zinc-400 block text-[10px]">Hash computed from received message:</span>
                <span className="text-amber-400 font-bold text-sm">{receiverCalculatedHash}</span>
              </div>

              <div className="p-3 bg-zinc-950/60 rounded-lg border border-zinc-800">
                <span className="text-zinc-400 block text-[10px]">Hash decrypted from Signature using Public Key (e={e}, n={n}):</span>
                <span className="text-emerald-400 font-bold text-sm">
                  ({signature}^{e}) mod {n} = {recoveredHashFromSignature}
                </span>
              </div>
            </div>
          </div>

          <div className="text-[11px] text-zinc-400 bg-black/40 p-2.5 rounded mt-3">
            📜 <strong>Non-Repudiation Guaranteed:</strong> Because the signature can only be constructed using the signer's private key, valid verification confirms both message integrity and sender identity.
          </div>
        </div>
      </div>
    </div>
  );
};
