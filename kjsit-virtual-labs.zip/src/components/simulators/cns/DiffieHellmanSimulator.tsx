import React, { useState } from 'react';
import { Network, Shield, Key, AlertTriangle, ArrowRight, User, UserX, RefreshCw, CheckCircle2 } from 'lucide-react';

export const DiffieHellmanSimulator: React.FC = () => {
  const [p, setP] = useState(23);
  const [g, setG] = useState(5);
  const [alicePrivate, setAlicePrivate] = useState(6);
  const [bobPrivate, setBobPrivate] = useState(15);
  const [mitmActive, setMitmActive] = useState(false);
  const [evePrivate1, setEvePrivate1] = useState(8);
  const [evePrivate2, setEvePrivate2] = useState(12);

  // Fast powerMod
  const powerMod = (base: number, exp: number, mod: number) => {
    let res = 1;
    base = base % mod;
    while (exp > 0) {
      if (exp % 2 === 1) res = (res * base) % mod;
      base = (base * base) % mod;
      exp = Math.floor(exp / 2);
    }
    return res;
  };

  // Normal Exchange
  const alicePublic = powerMod(g, alicePrivate, p);
  const bobPublic = powerMod(g, bobPrivate, p);

  // Alice & Bob Shared Keys
  const aliceShared = !mitmActive
    ? powerMod(bobPublic, alicePrivate, p)
    : powerMod(powerMod(g, evePrivate2, p), alicePrivate, p);

  const bobShared = !mitmActive
    ? powerMod(alicePublic, bobPrivate, p)
    : powerMod(powerMod(g, evePrivate1, p), bobPrivate, p);

  // Eve Interception Values
  const evePublicToBob = powerMod(g, evePrivate1, p);
  const evePublicToAlice = powerMod(g, evePrivate2, p);
  const eveSharedWithAlice = powerMod(alicePublic, evePrivate2, p);
  const eveSharedWithBob = powerMod(bobPublic, evePrivate1, p);

  return (
    <div className="space-y-6">
      {/* Parameter Setup */}
      <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h4 className="font-bold text-zinc-900 flex items-center gap-2">
              <Network className="w-5 h-5 text-red-700" />
              Diffie-Hellman Key Exchange Setup
            </h4>
            <p className="text-xs text-zinc-500 mt-0.5">
              Public Domain Parameters: Prime p and Primitive Root Generator g (mod p).
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setMitmActive(!mitmActive)}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition-all flex items-center gap-1.5 cursor-pointer ${
                mitmActive
                  ? 'bg-amber-600 text-white border-amber-700 shadow-xs'
                  : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200 border-zinc-300'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              {mitmActive ? 'MITM Attack ACTIVE' : 'Enable Man-in-the-Middle Attack'}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
              Public Prime p
            </label>
            <input
              type="number"
              value={p}
              onChange={(e) => setP(parseInt(e.target.value) || 2)}
              className="w-full p-2 text-sm border border-zinc-300 rounded-lg font-mono font-bold"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
              Generator g (mod p)
            </label>
            <input
              type="number"
              value={g}
              onChange={(e) => setG(parseInt(e.target.value) || 2)}
              className="w-full p-2 text-sm border border-zinc-300 rounded-lg font-mono font-bold"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
              Alice Secret (a)
            </label>
            <input
              type="number"
              value={alicePrivate}
              onChange={(e) => setAlicePrivate(parseInt(e.target.value) || 1)}
              className="w-full p-2 text-sm border border-zinc-300 rounded-lg font-mono font-bold text-red-700"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
              Bob Secret (b)
            </label>
            <input
              type="number"
              value={bobPrivate}
              onChange={(e) => setBobPrivate(parseInt(e.target.value) || 1)}
              className="w-full p-2 text-sm border border-zinc-300 rounded-lg font-mono font-bold text-blue-700"
            />
          </div>
        </div>
      </div>

      {/* Protocol Visual Exchange Stream */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Alice Node */}
        <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-3 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 pb-2 border-b border-zinc-200">
              <User className="w-5 h-5 text-red-700" />
              <h5 className="font-bold text-zinc-900">Alice (Client)</h5>
            </div>

            <div className="mt-3 space-y-2 text-xs font-mono">
              <div className="p-2 bg-zinc-50 rounded border border-zinc-200">
                <span className="text-zinc-500 block text-[10px]">Private Secret:</span>
                <span className="text-red-700 font-bold">a = {alicePrivate}</span>
              </div>

              <div className="p-2 bg-red-50 rounded border border-red-200">
                <span className="text-red-800 block text-[10px] font-bold">Calculated Public Key:</span>
                <span className="text-red-900 font-bold">A = ({g}^{alicePrivate}) mod {p} = {alicePublic}</span>
              </div>
            </div>
          </div>

          <div className="p-3 bg-zinc-950 text-white rounded-xl border border-zinc-800 text-center font-mono">
            <span className="text-[10px] text-zinc-400 uppercase block">Alice Shared Secret (K_A)</span>
            <span className="text-emerald-400 font-bold text-lg">{aliceShared}</span>
          </div>
        </div>

        {/* Transmission Channel / Eve */}
        <div className={`p-5 rounded-xl border shadow-xs flex flex-col justify-between ${mitmActive ? 'bg-amber-950/20 border-amber-500' : 'bg-zinc-900 border-zinc-800 text-white'}`}>
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800 text-xs">
              <span className="font-bold flex items-center gap-1.5 text-zinc-300">
                {mitmActive ? <UserX className="w-4 h-4 text-amber-500" /> : <Network className="w-4 h-4 text-emerald-400" />}
                {mitmActive ? 'Eve Interception Channel (MITM)' : 'Insecure Public Channel'}
              </span>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${mitmActive ? 'bg-amber-500 text-black' : 'bg-zinc-800 text-zinc-400'}`}>
                {mitmActive ? 'Adversary Active' : 'Passive Wire'}
              </span>
            </div>

            {!mitmActive ? (
              <div className="mt-4 space-y-3 text-xs font-mono text-center">
                <div className="p-2.5 bg-zinc-950 rounded-lg border border-zinc-800">
                  <span className="text-zinc-500 block text-[10px]">Alice transmits to Bob:</span>
                  <span className="text-amber-400 font-bold">Public Key A = {alicePublic}</span>
                </div>
                <div className="p-2.5 bg-zinc-950 rounded-lg border border-zinc-800">
                  <span className="text-zinc-500 block text-[10px]">Bob transmits to Alice:</span>
                  <span className="text-blue-400 font-bold">Public Key B = {bobPublic}</span>
                </div>
                <div className="text-[11px] text-zinc-400 italic">
                  Eavesdropper observes (p={p}, g={g}, A={alicePublic}, B={bobPublic}) but cannot compute secret without solving discrete log.
                </div>
              </div>
            ) : (
              <div className="mt-3 space-y-2 text-xs font-mono">
                <div className="p-2 bg-amber-900/40 rounded border border-amber-700 text-amber-200">
                  Eve splits channel into 2 separate keys:
                  <div className="text-[11px] mt-1 text-white">
                    Shared with Alice: <span className="font-bold text-amber-400">{eveSharedWithAlice}</span>
                  </div>
                  <div className="text-[11px] text-white">
                    Shared with Bob: <span className="font-bold text-amber-400">{eveSharedWithBob}</span>
                  </div>
                </div>
                <div className="text-[10px] text-amber-300">
                  ⚠️ Alice and Bob believe they are communicating securely, but Eve decrypts and re-encrypts all messages in transit!
                </div>
              </div>
            )}
          </div>

          <div className="text-[10px] text-zinc-400 p-2 bg-zinc-950/60 rounded text-center mt-3 font-sans">
            Formula: K = g^(ab) mod p
          </div>
        </div>

        {/* Bob Node */}
        <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-3 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 pb-2 border-b border-zinc-200">
              <User className="w-5 h-5 text-blue-700" />
              <h5 className="font-bold text-zinc-900">Bob (Server)</h5>
            </div>

            <div className="mt-3 space-y-2 text-xs font-mono">
              <div className="p-2 bg-zinc-50 rounded border border-zinc-200">
                <span className="text-zinc-500 block text-[10px]">Private Secret:</span>
                <span className="text-blue-700 font-bold">b = {bobPrivate}</span>
              </div>

              <div className="p-2 bg-blue-50 rounded border border-blue-200">
                <span className="text-blue-800 block text-[10px] font-bold">Calculated Public Key:</span>
                <span className="text-blue-900 font-bold">B = ({g}^{bobPrivate}) mod {p} = {bobPublic}</span>
              </div>
            </div>
          </div>

          <div className="p-3 bg-zinc-950 text-white rounded-xl border border-zinc-800 text-center font-mono">
            <span className="text-[10px] text-zinc-400 uppercase block">Bob Shared Secret (K_B)</span>
            <span className="text-emerald-400 font-bold text-lg">{bobShared}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
