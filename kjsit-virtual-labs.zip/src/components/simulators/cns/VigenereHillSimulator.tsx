import React, { useState } from 'react';
import { Network, Grid, Key, RefreshCw, ArrowRight, Check, AlertTriangle, Layers } from 'lucide-react';

export const VigenereHillSimulator: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'vigenere' | 'hill' | 'railfence'>('vigenere');

  // Vigenère State
  const [vigenereInput, setVigenereInput] = useState('ATTACKATDAWN');
  const [vigenereKey, setVigenereKey] = useState('LEMON');

  // Hill Cipher 2x2 State
  const [hillInput, setHillInput] = useState('HELLOMUMBAI');
  const [k00, setK00] = useState(3);
  const [k01, setK01] = useState(3);
  const [k10, setK10] = useState(2);
  const [k11, setK11] = useState(5);

  // Rail Fence State
  const [railInput, setRailInput] = useState('DEFENDTHEEASTWALL');
  const [rails, setRails] = useState(3);

  // Vigenère Logic
  const processVigenere = (text: string, key: string) => {
    const cleanText = text.toUpperCase().replace(/[^A-Z]/g, '');
    const cleanKey = key.toUpperCase().replace(/[^A-Z]/g, '') || 'A';
    const steps = [];

    for (let i = 0; i < cleanText.length; i++) {
      const pChar = cleanText[i];
      const kChar = cleanKey[i % cleanKey.length];
      const pVal = pChar.charCodeAt(0) - 65;
      const kVal = kChar.charCodeAt(0) - 65;
      const cVal = (pVal + kVal) % 26;
      const cChar = String.fromCharCode(cVal + 65);
      steps.push({ pChar, kChar, pVal, kVal, cVal, cChar });
    }

    const ciphertext = steps.map((s) => s.cChar).join('');
    return { steps, ciphertext };
  };

  const vigenereData = processVigenere(vigenereInput, vigenereKey);

  // Hill Cipher Logic
  const mod26 = (n: number) => ((n % 26) + 26) % 26;
  const gcd = (a: number, b: number): number => (!b ? a : gcd(b, a % b));
  const modInverse = (a: number, m: number = 26) => {
    a = mod26(a);
    for (let x = 1; x < m; x++) {
      if ((a * x) % m === 1) return x;
    }
    return -1;
  };

  const detK = mod26(k00 * k11 - k01 * k10);
  const isHillInvertible = gcd(detK, 26) === 1;
  const detInv = isHillInvertible ? modInverse(detK, 26) : null;

  const inv00 = detInv !== null ? mod26(detInv * k11) : 0;
  const inv01 = detInv !== null ? mod26(detInv * -k01) : 0;
  const inv10 = detInv !== null ? mod26(detInv * -k10) : 0;
  const inv11 = detInv !== null ? mod26(detInv * k00) : 0;

  const processHill = (text: string) => {
    let clean = text.toUpperCase().replace(/[^A-Z]/g, '');
    if (clean.length % 2 !== 0) clean += 'X';
    const pairs = [];

    for (let i = 0; i < clean.length; i += 2) {
      const p1 = clean.charCodeAt(i) - 65;
      const p2 = clean.charCodeAt(i + 1) - 65;
      const c1 = mod26(k00 * p1 + k01 * p2);
      const c2 = mod26(k10 * p1 + k11 * p2);
      pairs.push({
        plain: `${clean[i]}${clean[i + 1]}`,
        pVec: [p1, p2],
        cVec: [c1, c2],
        cipher: `${String.fromCharCode(c1 + 65)}${String.fromCharCode(c2 + 65)}`
      });
    }

    return { pairs, ciphertext: pairs.map((p) => p.cipher).join('') };
  };

  const hillData = processHill(hillInput);

  // Rail Fence Logic
  const processRailFence = (text: string, numRails: number) => {
    const clean = text.toUpperCase().replace(/[^A-Z]/g, '');
    if (numRails <= 1 || clean.length === 0) return { matrix: [], result: clean };

    const grid: (string | null)[][] = Array.from({ length: numRails }, () =>
      Array(clean.length).fill(null)
    );

    let row = 0;
    let down = false;

    for (let col = 0; col < clean.length; col++) {
      grid[row][col] = clean[col];
      if (row === 0 || row === numRails - 1) down = !down;
      row += down ? 1 : -1;
    }

    const rowsText: string[] = [];
    grid.forEach((r) => {
      rowsText.push(r.filter((c) => c !== null).join(''));
    });

    return { matrix: grid, result: rowsText.join(''), rowsText };
  };

  const railData = processRailFence(railInput, rails);

  return (
    <div className="space-y-6">
      {/* Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-zinc-200 pb-3">
        <button
          onClick={() => setActiveTab('vigenere')}
          className={`px-4 py-2 text-sm font-semibold rounded-lg transition-all cursor-pointer ${
            activeTab === 'vigenere' ? 'bg-red-800 text-white shadow-xs' : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
          }`}
        >
          Vigenère Polyalphabetic Cipher
        </button>
        <button
          onClick={() => setActiveTab('hill')}
          className={`px-4 py-2 text-sm font-semibold rounded-lg transition-all cursor-pointer ${
            activeTab === 'hill' ? 'bg-red-800 text-white shadow-xs' : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
          }`}
        >
          Hill 2×2 Matrix Cipher (Linear Algebra)
        </button>
        <button
          onClick={() => setActiveTab('railfence')}
          className={`px-4 py-2 text-sm font-semibold rounded-lg transition-all cursor-pointer ${
            activeTab === 'railfence' ? 'bg-red-800 text-white shadow-xs' : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
          }`}
        >
          Rail Fence Transposition
        </button>
      </div>

      {/* Vigenère View */}
      {activeTab === 'vigenere' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-4">
            <h4 className="font-bold text-zinc-900 flex items-center gap-2">
              <Key className="w-5 h-5 text-red-700" />
              Vigenère Key Stream Configuration
            </h4>

            <div>
              <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
                Plaintext Message
              </label>
              <input
                type="text"
                value={vigenereInput}
                onChange={(e) => setVigenereInput(e.target.value.toUpperCase())}
                className="w-full p-2.5 text-sm border border-zinc-300 rounded-lg font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
                Keyword (Repeating Polyalphabetic Key)
              </label>
              <input
                type="text"
                value={vigenereKey}
                onChange={(e) => setVigenereKey(e.target.value.toUpperCase())}
                className="w-full p-2.5 text-sm border border-zinc-300 rounded-lg font-mono font-bold"
              />
            </div>

            {/* Repeated Keystream Alignment Box */}
            <div className="bg-zinc-50 p-4 rounded-xl border border-zinc-200">
              <span className="text-xs font-semibold uppercase text-zinc-500 block mb-2">
                Periodic Keystream Alignment:
              </span>
              <div className="space-y-1 font-mono text-sm">
                <div className="flex gap-1 items-center">
                  <span className="text-xs text-zinc-500 w-16">Plain:</span>
                  {vigenereData.steps.slice(0, 14).map((s, i) => (
                    <span key={i} className="w-6 h-6 flex items-center justify-center bg-white border border-zinc-200 rounded font-bold text-zinc-800 text-xs">
                      {s.pChar}
                    </span>
                  ))}
                </div>
                <div className="flex gap-1 items-center">
                  <span className="text-xs text-zinc-500 w-16">Key:</span>
                  {vigenereData.steps.slice(0, 14).map((s, i) => (
                    <span key={i} className="w-6 h-6 flex items-center justify-center bg-amber-50 border border-amber-300 rounded font-bold text-amber-900 text-xs">
                      {s.kChar}
                    </span>
                  ))}
                </div>
                <div className="flex gap-1 items-center">
                  <span className="text-xs text-red-700 font-bold w-16">Cipher:</span>
                  {vigenereData.steps.slice(0, 14).map((s, i) => (
                    <span key={i} className="w-6 h-6 flex items-center justify-center bg-red-800 text-white rounded font-bold text-xs">
                      {s.cChar}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="bg-zinc-900 text-zinc-100 p-5 rounded-xl border border-zinc-800 shadow-xs flex flex-col justify-between">
            <div>
              <span className="text-xs font-semibold uppercase text-zinc-400 block mb-1">
                Tabula Recta Character Addition Trace (C = (P + K) mod 26):
              </span>
              <div className="max-h-[260px] overflow-y-auto space-y-1.5 font-mono text-xs pr-1">
                {vigenereData.steps.map((s, idx) => (
                  <div key={idx} className="flex justify-between items-center p-2 bg-zinc-950 rounded border border-zinc-800">
                    <span className="text-zinc-400 font-sans text-[10px]">#{idx + 1}</span>
                    <span>
                      '{s.pChar}' ({s.pVal}) + '{s.kChar}' ({s.kVal})
                    </span>
                    <span className="text-zinc-500">= ({s.pVal + s.kVal}) % 26 =</span>
                    <span className="text-emerald-400 font-bold">
                      {s.cVal} ('{s.cChar}')
                    </span>
                  </div>
                ))}
              </div>

              <div className="mt-4 pt-3 border-t border-zinc-800">
                <span className="text-xs uppercase text-zinc-400 block mb-1">Final Ciphertext:</span>
                <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-800 text-emerald-400 font-mono font-bold tracking-widest text-base">
                  {vigenereData.ciphertext || '(Empty)'}
                </div>
              </div>
            </div>

            <div className="text-[11px] text-zinc-400 bg-zinc-800/50 p-2 rounded mt-3">
              🛡️ <strong>Kasiski Attack:</strong> The length of repeating substrings in the ciphertext reveals the period length of keyword '{vigenereKey}' (|K| = {vigenereKey.length}).
            </div>
          </div>
        </div>
      )}

      {/* Hill Cipher View */}
      {activeTab === 'hill' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-4">
            <h4 className="font-bold text-zinc-900 flex items-center gap-2">
              <Layers className="w-5 h-5 text-red-700" />
              2×2 Key Matrix Setup (mod 26)
            </h4>

            <div>
              <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
                Plaintext (Padded to even length with 'X')
              </label>
              <input
                type="text"
                value={hillInput}
                onChange={(e) => setHillInput(e.target.value.toUpperCase())}
                className="w-full p-2.5 text-sm border border-zinc-300 rounded-lg font-mono font-bold"
              />
            </div>

            {/* Matrix Inputs */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-semibold text-zinc-600 uppercase">
                  Encryption Key Matrix K
                </label>
                <button
                  onClick={() => {
                    setK00(3); setK01(3); setK10(2); setK11(5);
                  }}
                  className="text-xs text-red-700 font-semibold hover:underline cursor-pointer"
                >
                  Standard Preset [[3, 3], [2, 5]]
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3 max-w-[200px] mx-auto bg-zinc-900 p-3 rounded-xl">
                <input
                  type="number"
                  value={k00}
                  onChange={(e) => setK00(parseInt(e.target.value) || 0)}
                  className="w-full p-2 text-center font-mono font-bold text-white bg-zinc-800 border border-zinc-700 rounded"
                />
                <input
                  type="number"
                  value={k01}
                  onChange={(e) => setK01(parseInt(e.target.value) || 0)}
                  className="w-full p-2 text-center font-mono font-bold text-white bg-zinc-800 border border-zinc-700 rounded"
                />
                <input
                  type="number"
                  value={k10}
                  onChange={(e) => setK10(parseInt(e.target.value) || 0)}
                  className="w-full p-2 text-center font-mono font-bold text-white bg-zinc-800 border border-zinc-700 rounded"
                />
                <input
                  type="number"
                  value={k11}
                  onChange={(e) => setK11(parseInt(e.target.value) || 0)}
                  className="w-full p-2 text-center font-mono font-bold text-white bg-zinc-800 border border-zinc-700 rounded"
                />
              </div>
            </div>

            {/* Invertibility & Matrix Math Status */}
            <div className={`p-3.5 rounded-xl border text-xs ${isHillInvertible ? 'bg-emerald-50 border-emerald-200 text-emerald-900' : 'bg-red-50 border-red-200 text-red-900'}`}>
              <div className="flex items-center gap-2 font-bold mb-1">
                {isHillInvertible ? <Check className="w-4 h-4 text-emerald-600" /> : <AlertTriangle className="w-4 h-4 text-red-600" />}
                <span>Determinant det(K) = {detK} (mod 26)</span>
              </div>
              <div>
                gcd({detK}, 26) = {gcd(detK, 26)} → {isHillInvertible ? `Invertible! Modular inverse d^-1 = ${detInv}` : 'Not Invertible! Choose values coprime to 26.'}
              </div>
              {isHillInvertible && (
                <div className="mt-2 pt-2 border-t border-emerald-200 font-mono text-[11px]">
                  Decryption Inverse K⁻¹ = [[{inv00}, {inv01}], [{inv10}, {inv11}]]
                </div>
              )}
            </div>
          </div>

          <div className="bg-zinc-900 text-zinc-100 p-5 rounded-xl border border-zinc-800 shadow-xs flex flex-col justify-between">
            <div>
              <span className="text-xs font-semibold uppercase text-zinc-400 block mb-2">
                Vector Block Multiplication (C = K × P mod 26):
              </span>

              <div className="space-y-2 max-h-[260px] overflow-y-auto pr-1">
                {hillData.pairs.map((item, idx) => (
                  <div key={idx} className="p-2.5 bg-zinc-950 rounded-lg border border-zinc-800 text-xs font-mono">
                    <div className="flex justify-between items-center text-zinc-400 mb-1">
                      <span>Vector #{idx + 1}: [{item.plain}] = [{item.pVec[0]}, {item.pVec[1]}]ᵀ</span>
                      <span className="text-emerald-400 font-bold">→ [{item.cipher}]</span>
                    </div>
                    <div className="text-[11px] text-zinc-500">
                      c₁ = ({k00}×{item.pVec[0]} + {k01}×{item.pVec[1]}) % 26 = {item.cVec[0]} ('{item.cipher[0]}')
                    </div>
                    <div className="text-[11px] text-zinc-500">
                      c₂ = ({k10}×{item.pVec[0]} + {k11}×{item.pVec[1]}) % 26 = {item.cVec[1]} ('{item.cipher[1]}')
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-4 pt-3 border-t border-zinc-800">
                <span className="text-xs uppercase text-zinc-400 block mb-1">Final Hill Ciphertext:</span>
                <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-800 text-emerald-400 font-mono font-bold tracking-widest text-base">
                  {hillData.ciphertext || '(Empty)'}
                </div>
              </div>
            </div>

            <div className="text-[11px] text-zinc-400 bg-zinc-800/50 p-2 rounded mt-3">
              📐 <strong>Linear Vulnerability:</strong> An attacker knowing 2 pairs of plaintext vectors can solve the 2×2 linear system to recover matrix K instantly.
            </div>
          </div>
        </div>
      )}

      {/* Rail Fence View */}
      {activeTab === 'railfence' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-4">
            <h4 className="font-bold text-zinc-900 flex items-center gap-2">
              <Layers className="w-5 h-5 text-red-700" />
              Rail Fence Transposition Parameters
            </h4>

            <div>
              <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
                Plaintext Message
              </label>
              <input
                type="text"
                value={railInput}
                onChange={(e) => setRailInput(e.target.value.toUpperCase())}
                className="w-full p-2.5 text-sm border border-zinc-300 rounded-lg font-mono font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
                Number of Rails (Depth): <span className="text-red-700 font-bold">{rails}</span>
              </label>
              <input
                type="range"
                min="2"
                max="5"
                value={rails}
                onChange={(e) => setRails(parseInt(e.target.value))}
                className="w-full accent-red-700 cursor-pointer"
              />
              <div className="flex justify-between text-xs text-zinc-400 font-mono">
                <span>2 Rails</span>
                <span>3 Rails</span>
                <span>4 Rails</span>
                <span>5 Rails</span>
              </div>
            </div>
          </div>

          <div className="bg-zinc-900 text-zinc-100 p-5 rounded-xl border border-zinc-800 shadow-xs flex flex-col justify-between">
            <div>
              <span className="text-xs font-semibold uppercase text-zinc-400 block mb-2">
                Zigzag Rail Matrix Trace:
              </span>

              <div className="overflow-x-auto bg-zinc-950 p-3 rounded-lg border border-zinc-800 space-y-2 font-mono text-xs">
                {railData.matrix.map((row, rIdx) => (
                  <div key={rIdx} className="flex gap-1.5 items-center">
                    <span className="text-zinc-500 text-[10px] w-12">Rail {rIdx + 1}:</span>
                    {row.map((cell, cIdx) => (
                      <span
                        key={cIdx}
                        className={`w-6 h-6 flex items-center justify-center rounded text-xs font-bold ${
                          cell ? 'bg-red-800 text-white border border-red-600' : 'bg-zinc-900 text-zinc-700'
                        }`}
                      >
                        {cell || '·'}
                      </span>
                    ))}
                  </div>
                ))}
              </div>

              <div className="mt-4 pt-3 border-t border-zinc-800">
                <span className="text-xs uppercase text-zinc-400 block mb-1">Read by Rows (Ciphertext):</span>
                <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-800 text-emerald-400 font-mono font-bold tracking-widest text-base">
                  {railData.result || '(Empty)'}
                </div>
              </div>
            </div>

            <div className="text-[11px] text-zinc-400 bg-zinc-800/50 p-2 rounded mt-3">
              🔄 <strong>Transposition Principle:</strong> Character frequencies remain 100% identical; only the positional indexes are permuted.
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
