import React, { useState } from 'react';
import { Cpu, Shield, Key, RefreshCw, ArrowRight, Play, CheckCircle2, Layers } from 'lucide-react';

export const DESSimulator: React.FC = () => {
  const [currentRound, setCurrentRound] = useState(1);
  const [leftState, setLeftState] = useState('01234567');
  const [rightState, setRightState] = useState('89ABCDEF');
  const [selectedSBox, setSelectedSBox] = useState<number>(1);
  const [sboxInputBit, setSboxInputBit] = useState('100101'); // 6-bit input

  // DES S-Box 1 Table (4x16)
  const S1 = [
    [14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7],
    [0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3, 8],
    [4, 1, 14, 8, 13, 6, 2, 11, 15, 12, 9, 7, 3, 10, 5, 0],
    [15, 12, 8, 2, 4, 9, 1, 7, 5, 11, 3, 14, 10, 0, 6, 13]
  ];

  // Decode 6-bit input for S-Box
  const clean6 = sboxInputBit.padEnd(6, '0').slice(0, 6);
  const row = parseInt(clean6[0] + clean6[5], 2);
  const col = parseInt(clean6.slice(1, 5), 2);
  const sboxOutputVal = S1[row % 4][col % 16];
  const sboxOutputBin = sboxOutputVal.toString(2).padStart(4, '0');

  // Simple Round Transition Simulation
  const handleNextRound = () => {
    if (currentRound < 16) {
      const nextRoundNum = currentRound + 1;
      setCurrentRound(nextRoundNum);
      const nextL = rightState;
      // Simulated XOR with subkey
      const nextR = (parseInt(leftState, 16) ^ (parseInt(rightState, 16) + nextRoundNum * 1337))
        .toString(16)
        .toUpperCase()
        .slice(-8)
        .padStart(8, '0');
      setLeftState(nextL);
      setRightState(nextR);
    }
  };

  const handleReset = () => {
    setCurrentRound(1);
    setLeftState('01234567');
    setRightState('89ABCDEF');
  };

  return (
    <div className="space-y-6">
      {/* Feistel Architecture Visualizer */}
      <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h4 className="font-bold text-zinc-900 flex items-center gap-2">
              <Cpu className="w-5 h-5 text-red-700" />
              DES 16-Round Feistel Network State (Round {currentRound} of 16)
            </h4>
            <p className="text-xs text-zinc-500 mt-0.5">
              Input 64-bit Block split into Left (L_{currentRound - 1}) and Right (R_{currentRound - 1}) 32-bit registers.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleNextRound}
              disabled={currentRound >= 16}
              className="px-4 py-2 bg-red-800 hover:bg-red-900 disabled:opacity-50 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 shadow-xs cursor-pointer"
            >
              <Play className="w-3.5 h-3.5" /> Execute Round {currentRound}
            </button>
            <button
              onClick={handleReset}
              className="px-3 py-2 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-bold rounded-lg flex items-center gap-1 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Reset
            </button>
          </div>
        </div>

        {/* Feistel Split Flow */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-zinc-950 p-4 rounded-xl border border-zinc-800 text-zinc-100 font-mono">
          <div className="p-3 bg-zinc-900 rounded-lg border border-zinc-700 text-center">
            <span className="text-[10px] uppercase text-zinc-400 block mb-1">Left Half L_{currentRound - 1} (32 bits)</span>
            <span className="text-amber-400 font-bold text-lg tracking-wider">0x{leftState}</span>
            <div className="mt-2 text-[11px] text-zinc-500">Next L_{currentRound} = R_{currentRound - 1}</div>
          </div>

          <div className="p-3 bg-zinc-900 rounded-lg border border-zinc-700 text-center">
            <span className="text-[10px] uppercase text-zinc-400 block mb-1">Right Half R_{currentRound - 1} (32 bits)</span>
            <span className="text-emerald-400 font-bold text-lg tracking-wider">0x{rightState}</span>
            <div className="mt-2 text-[11px] text-zinc-500">
              Next R_{currentRound} = L_{currentRound - 1} ⊕ F(R_{currentRound - 1}, K_{currentRound})
            </div>
          </div>
        </div>

        {/* Round Progress Tracker */}
        <div className="flex gap-1 overflow-x-auto py-1">
          {[...Array(16)].map((_, i) => (
            <div
              key={i}
              className={`flex-1 min-w-[28px] text-center py-1 rounded text-[10px] font-mono font-bold transition-all ${
                i + 1 === currentRound
                  ? 'bg-red-800 text-white shadow-xs'
                  : i + 1 < currentRound
                  ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-700'
                  : 'bg-zinc-100 text-zinc-400'
              }`}
            >
              R{i + 1}
            </div>
          ))}
        </div>
      </div>

      {/* S-Box Non-linear Substitution Sandbox */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-4">
          <h4 className="font-bold text-zinc-900 flex items-center gap-2">
            <Layers className="w-5 h-5 text-red-700" />
            DES S-Box 1 (6-to-4 Bit Non-Linear Compression)
          </h4>

          <div>
            <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
              6-Bit Binary Input to S-Box
            </label>
            <input
              type="text"
              maxLength={6}
              value={sboxInputBit}
              onChange={(e) => setSboxInputBit(e.target.value.replace(/[^01]/g, ''))}
              className="w-full p-2.5 text-center text-base border border-zinc-300 rounded-lg font-mono font-bold tracking-widest"
              placeholder="100101"
            />
          </div>

          <div className="p-3 bg-zinc-50 rounded-lg border border-zinc-200 space-y-2 text-xs font-mono">
            <div className="flex justify-between">
              <span className="text-zinc-600">Outer Bits (1st & 6th):</span>
              <span className="font-bold text-red-700">
                '{clean6[0]}' and '{clean6[5]}' → Row {row} (binary {(row).toString(2).padStart(2, '0')})
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-600">Inner Bits (2nd to 5th):</span>
              <span className="font-bold text-amber-700">
                '{clean6.slice(1, 5)}' → Column {col} (decimal {col})
              </span>
            </div>
            <div className="flex justify-between pt-2 border-t border-zinc-200">
              <span className="text-zinc-800 font-bold">S-Box 1 Output:</span>
              <span className="font-bold text-emerald-700 text-sm">
                {sboxOutputVal} (Binary: {sboxOutputBin})
              </span>
            </div>
          </div>
        </div>

        {/* S-Box Matrix Display */}
        <div className="bg-zinc-900 text-zinc-100 p-5 rounded-xl border border-zinc-800 shadow-xs">
          <span className="text-xs font-semibold uppercase text-zinc-400 block mb-2">
            S-Box 1 Matrix Table (4 Rows × 16 Columns):
          </span>

          <div className="overflow-x-auto">
            <table className="w-full text-center font-mono text-[10px] border-collapse">
              <thead>
                <tr className="text-zinc-500 border-b border-zinc-800">
                  <th className="p-1">R\C</th>
                  {[...Array(16)].map((_, c) => (
                    <th key={c} className={`p-1 ${c === col ? 'text-amber-400 font-bold' : ''}`}>
                      {c}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {S1.map((rVals, rIdx) => (
                  <tr
                    key={rIdx}
                    className={`border-b border-zinc-800/50 ${
                      rIdx === row ? 'bg-red-950/40 text-white' : 'text-zinc-400'
                    }`}
                  >
                    <td className={`p-1 font-bold ${rIdx === row ? 'text-red-400' : 'text-zinc-500'}`}>
                      {rIdx}
                    </td>
                    {rVals.map((val, cIdx) => (
                      <td
                        key={cIdx}
                        className={`p-1 rounded ${
                          rIdx === row && cIdx === col
                            ? 'bg-red-700 text-white font-bold text-xs shadow-xs'
                            : ''
                        }`}
                      >
                        {val}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="text-[11px] text-zinc-400 bg-zinc-800/50 p-2 rounded mt-3">
            🔐 <strong>Cryptographic Purpose:</strong> S-boxes provide the crucial non-linear "confusion" property preventing linear algebraic attacks on DES.
          </div>
        </div>
      </div>
    </div>
  );
};
