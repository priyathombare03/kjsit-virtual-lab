import React, { useState } from 'react';
import { Shield, Sparkles, RefreshCw, BarChart2, Check, ArrowRight, Layers } from 'lucide-react';

export const SHA256HashSimulator: React.FC = () => {
  const [inputText1, setInputText1] = useState('Somaiya KJSIT Virtual Labs');
  const [inputText2, setInputText2] = useState('somaiya KJSIT Virtual Labs'); // 1 character difference

  // Pure JavaScript SHA-256 implementation
  const sha256 = (ascii: string) => {
    function rightRotate(value: number, amount: number) {
      return (value >>> amount) | (value << (32 - amount));
    }

    const mathPow = Math.pow;
    const maxWord = mathPow(2, 32);
    let lengthProperty = 'length';
    let i = 0, j = 0;
    let result = '';

    const words: number[] = [];
    const asciiBitLength = ascii[lengthProperty] * 8;

    const hash: number[] = [];
    const k: number[] = [];
    let primeCounter = 0;

    const isComposite: Record<number, boolean> = {};
    for (let candidate = 2; primeCounter < 64; candidate++) {
      if (!isComposite[candidate]) {
        for (i = 0; i < 313; i += candidate) {
          isComposite[i] = true;
        }
        hash[primeCounter] = (mathPow(candidate, 0.5) * maxWord) | 0;
        k[primeCounter++] = (mathPow(candidate, 1 / 3) * maxWord) | 0;
      }
    }

    ascii += '\x80';
    while ((ascii[lengthProperty] % 64) - 56) ascii += '\x00';
    for (i = 0; i < ascii[lengthProperty]; i++) {
      j = ascii.charCodeAt(i);
      if (j >> 8) return '';
      words[i >> 2] |= j << ((3 - (i % 4)) * 8);
    }
    words[words[lengthProperty]] = (asciiBitLength / maxWord) | 0;
    words[words[lengthProperty]] = asciiBitLength;

    for (j = 0; j < words[lengthProperty]; ) {
      const w = words.slice(j, (j += 16));
      const oldHash = hash.slice(0);
      for (i = 0; i < 64; i++) {
        const i2 = i + j;
        const w15 = w[i - 15], w2 = w[i - 2];
        const a = hash[0], e = hash[4];
        const s0 = rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22);
        const maj = (a & hash[1]) ^ (a & hash[2]) ^ (hash[1] & hash[2]);
        const t2 = s0 + maj;
        const s1 = rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25);
        const ch = (e & hash[5]) ^ (~e & hash[6]);
        const t1 =
          hash[7] +
          s1 +
          ch +
          k[i] +
          (w[i] =
            i < 16
              ? w[i]
              : (w[i - 16] +
                  (rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15 >>> 3)) +
                  w[i - 7] +
                  (rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2 >>> 10))) |
                0);

        hash[7] = hash[6];
        hash[6] = hash[5];
        hash[5] = hash[4];
        hash[4] = (hash[3] + t1) | 0;
        hash[3] = hash[2];
        hash[2] = hash[1];
        hash[1] = hash[0];
        hash[0] = (t1 + t2) | 0;
      }

      for (i = 0; i < 8; i++) {
        hash[i] = (hash[i] + oldHash[i]) | 0;
      }
    }

    for (i = 0; i < 8; i++) {
      for (j = 3; j + 1; j--) {
        const b = (hash[i] >> (j * 8)) & 255;
        result += (b < 16 ? '0' : '') + b.toString(16);
      }
    }
    return result;
  };

  const hash1 = sha256(inputText1);
  const hash2 = sha256(inputText2);

  // Calculate bit difference (Avalanche Effect)
  const hexToBin = (hex: string) => {
    let bin = '';
    for (let i = 0; i < hex.length; i++) {
      bin += parseInt(hex[i], 16).toString(2).padStart(4, '0');
    }
    return bin;
  };

  const bin1 = hexToBin(hash1);
  const bin2 = hexToBin(hash2);

  let flippedBits = 0;
  for (let i = 0; i < Math.min(bin1.length, bin2.length); i++) {
    if (bin1[i] !== bin2[i]) flippedBits++;
  }

  const avalanchePercent = ((flippedBits / 256) * 100).toFixed(2);

  return (
    <div className="space-y-6">
      {/* Hash Generator */}
      <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-4">
        <h4 className="font-bold text-zinc-900 flex items-center gap-2">
          <Shield className="w-5 h-5 text-red-700" />
          SHA-256 Cryptographic Hash Digest Calculation
        </h4>

        <div>
          <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
            Input Plaintext Message
          </label>
          <input
            type="text"
            value={inputText1}
            onChange={(e) => setInputText1(e.target.value)}
            className="w-full p-2.5 text-sm border border-zinc-300 rounded-lg font-mono font-bold"
          />
        </div>

        <div className="p-4 bg-zinc-950 rounded-xl border border-zinc-800 text-zinc-100 font-mono text-xs space-y-2">
          <span className="text-zinc-400 uppercase text-[10px] block">256-Bit Hexadecimal Digest (64 Characters):</span>
          <div className="text-emerald-400 font-bold text-sm break-all tracking-wider">
            {hash1}
          </div>
        </div>
      </div>

      {/* Avalanche Effect Interactive Analyzer */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-4">
          <h4 className="font-bold text-zinc-900 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-red-700" />
            Avalanche Effect Sensitivity Test
          </h4>
          <p className="text-xs text-zinc-500">
            Compare two slightly different inputs (e.g. 1 character change) to verify that ~50% of the 256 output bits flip completely.
          </p>

          <div>
            <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
              Modified Input String (Input 2)
            </label>
            <input
              type="text"
              value={inputText2}
              onChange={(e) => setInputText2(e.target.value)}
              className="w-full p-2.5 text-sm border border-zinc-300 rounded-lg font-mono font-bold text-red-700"
            />
          </div>

          <div className="p-3 bg-zinc-50 rounded-lg border border-zinc-200 text-xs font-mono space-y-1">
            <div className="text-zinc-600 truncate">Hash 1: {hash1.slice(0, 24)}...</div>
            <div className="text-red-700 font-bold truncate">Hash 2: {hash2.slice(0, 24)}...</div>
          </div>
        </div>

        {/* Avalanche Metrics Card */}
        <div className="bg-zinc-900 text-zinc-100 p-5 rounded-xl border border-zinc-800 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <span className="text-xs font-semibold uppercase text-zinc-400 flex items-center gap-1.5">
                <BarChart2 className="w-4 h-4 text-emerald-400" />
                Bit-Flip Measurement
              </span>
              <span className="text-xs px-2 py-0.5 bg-emerald-950 text-emerald-300 font-mono rounded border border-emerald-700 font-bold">
                {avalanchePercent}% Flipped
              </span>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-3 text-center font-mono">
              <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-800">
                <span className="text-[10px] text-zinc-500 block">Total Hash Bits</span>
                <span className="text-lg font-bold text-white">256</span>
              </div>
              <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-800">
                <span className="text-[10px] text-zinc-500 block">Flipped Bits</span>
                <span className="text-lg font-bold text-emerald-400">{flippedBits}</span>
              </div>
            </div>

            <div className="mt-3 text-xs text-zinc-400">
              🎯 <strong>Ideal Benchmark:</strong> 128 / 256 bits (50.00%). The current difference is{' '}
              <strong className="text-white">{flippedBits} bits ({avalanchePercent}%)</strong>, confirming optimal diffusion.
            </div>
          </div>

          <div className="text-[11px] text-zinc-400 bg-zinc-800/50 p-2 rounded mt-3">
            🧱 <strong>Pre-image Resistance:</strong> Because all 64 compression rounds thoroughly mix bits, calculating the input from the 64-hex digest is computationally intractable (2^256 steps).
          </div>
        </div>
      </div>
    </div>
  );
};
