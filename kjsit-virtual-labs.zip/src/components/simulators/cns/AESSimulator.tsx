import React, { useState } from 'react';
import { Shield, Cpu, RefreshCw, Play, Layers, ArrowRight, CheckCircle2, Zap } from 'lucide-react';

export const AESSimulator: React.FC = () => {
  const [currentStep, setCurrentStep] = useState<'input' | 'subbytes' | 'shiftrows' | 'mixcolumns' | 'addroundkey'>('input');
  const [roundNum, setRoundNum] = useState(1);

  // 4x4 Byte State Matrix
  const [stateMatrix, setStateMatrix] = useState<string[][]>([
    ['00', '11', '22', '33'],
    ['44', '55', '66', '77'],
    ['88', '99', 'AA', 'BB'],
    ['CC', 'DD', 'EE', 'FF']
  ]);

  // AES S-Box sample substitutions
  const sboxMap: Record<string, string> = {
    '00': '63', '11': '82', '22': '93', '33': 'C3',
    '44': '1B', '55': 'FC', '66': '33', '77': 'F5',
    '88': 'C4', '99': 'EE', 'AA': 'AC', 'BB': 'EA',
    'CC': '4B', 'DD': 'F1', 'EE': '28', 'FF': '16'
  };

  // SubBytes Execution
  const applySubBytes = () => {
    const next = stateMatrix.map((row) =>
      row.map((cell) => sboxMap[cell.toUpperCase()] || '5B')
    );
    setStateMatrix(next);
    setCurrentStep('subbytes');
  };

  // ShiftRows Execution
  const applyShiftRows = () => {
    const next = [
      [...stateMatrix[0]], // Row 0: shift 0
      [stateMatrix[1][1], stateMatrix[1][2], stateMatrix[1][3], stateMatrix[1][0]], // Row 1: shift 1
      [stateMatrix[2][2], stateMatrix[2][3], stateMatrix[2][0], stateMatrix[2][1]], // Row 2: shift 2
      [stateMatrix[3][3], stateMatrix[3][0], stateMatrix[3][1], stateMatrix[3][2]]  // Row 3: shift 3
    ];
    setStateMatrix(next);
    setCurrentStep('shiftrows');
  };

  // MixColumns Execution (Simulated GF(2^8))
  const applyMixColumns = () => {
    const next = [
      ['04', '66', '81', 'E5'],
      ['E0', 'CB', '19', '9A'],
      ['48', 'F8', 'D3', '7A'],
      ['28', '06', '26', '4C']
    ];
    setStateMatrix(next);
    setCurrentStep('mixcolumns');
  };

  // AddRoundKey Execution
  const applyAddRoundKey = () => {
    const next = [
      ['D6', 'AA', '74', 'FD'],
      ['D2', 'AF', '72', 'FA'],
      ['DA', 'A6', '78', 'F1'],
      ['D6', 'AB', '76', 'FE']
    ];
    setStateMatrix(next);
    setCurrentStep('addroundkey');
  };

  const handleReset = () => {
    setStateMatrix([
      ['00', '11', '22', '33'],
      ['44', '55', '66', '77'],
      ['88', '99', 'AA', 'BB'],
      ['CC', 'DD', 'EE', 'FF']
    ]);
    setCurrentStep('input');
    setRoundNum(1);
  };

  return (
    <div className="space-y-6">
      {/* 4x4 State Grid Header */}
      <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h4 className="font-bold text-zinc-900 flex items-center gap-2">
              <Shield className="w-5 h-5 text-red-700" />
              AES-128 4×4 State Matrix Transformations (Round {roundNum} of 10)
            </h4>
            <p className="text-xs text-zinc-500 mt-0.5">
              128-bit block stored as 16 bytes across a 4-row by 4-column matrix in Galois Field GF(2^8).
            </p>
          </div>

          <button
            onClick={handleReset}
            className="px-3 py-1.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-bold rounded-lg flex items-center gap-1 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Reset State
          </button>
        </div>

        {/* Action Pipeline Steps */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <button
            onClick={applySubBytes}
            className={`p-2.5 rounded-lg text-xs font-bold transition-all flex flex-col items-center gap-1 cursor-pointer ${
              currentStep === 'subbytes'
                ? 'bg-red-800 text-white shadow-xs'
                : 'bg-zinc-100 hover:bg-zinc-200 text-zinc-800'
            }`}
          >
            <span>1. SubBytes</span>
            <span className="text-[10px] font-normal opacity-80">Nonlinear S-Box GF(2⁸)</span>
          </button>

          <button
            onClick={applyShiftRows}
            className={`p-2.5 rounded-lg text-xs font-bold transition-all flex flex-col items-center gap-1 cursor-pointer ${
              currentStep === 'shiftrows'
                ? 'bg-red-800 text-white shadow-xs'
                : 'bg-zinc-100 hover:bg-zinc-200 text-zinc-800'
            }`}
          >
            <span>2. ShiftRows</span>
            <span className="text-[10px] font-normal opacity-80">Cyclic Row Shifts (0,1,2,3)</span>
          </button>

          <button
            onClick={applyMixColumns}
            className={`p-2.5 rounded-lg text-xs font-bold transition-all flex flex-col items-center gap-1 cursor-pointer ${
              currentStep === 'mixcolumns'
                ? 'bg-red-800 text-white shadow-xs'
                : 'bg-zinc-100 hover:bg-zinc-200 text-zinc-800'
            }`}
          >
            <span>3. MixColumns</span>
            <span className="text-[10px] font-normal opacity-80">Matrix Mult over GF(2⁸)</span>
          </button>

          <button
            onClick={applyAddRoundKey}
            className={`p-2.5 rounded-lg text-xs font-bold transition-all flex flex-col items-center gap-1 cursor-pointer ${
              currentStep === 'addroundkey'
                ? 'bg-red-800 text-white shadow-xs'
                : 'bg-zinc-100 hover:bg-zinc-200 text-zinc-800'
            }`}
          >
            <span>4. AddRoundKey</span>
            <span className="text-[10px] font-normal opacity-80">Bitwise XOR with Subkey</span>
          </button>
        </div>
      </div>

      {/* State Matrix Visualizer & Details */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-zinc-900 text-zinc-100 p-5 rounded-xl border border-zinc-800 shadow-xs flex flex-col items-center justify-center space-y-4">
          <span className="text-xs font-semibold uppercase text-zinc-400">
            Active 4×4 State Matrix Grid (Hex Bytes):
          </span>

          <div className="grid grid-cols-4 gap-2.5 bg-zinc-950 p-4 rounded-xl border border-zinc-800 shadow-inner">
            {stateMatrix.flatMap((row, rIdx) =>
              row.map((byteVal, cIdx) => (
                <div
                  key={`${rIdx}-${cIdx}`}
                  className={`w-12 h-12 flex flex-col items-center justify-center rounded-lg border font-mono font-bold text-sm transition-all ${
                    currentStep === 'subbytes'
                      ? 'bg-amber-950/60 border-amber-500 text-amber-300'
                      : currentStep === 'shiftrows'
                      ? 'bg-purple-950/60 border-purple-500 text-purple-300'
                      : currentStep === 'mixcolumns'
                      ? 'bg-blue-950/60 border-blue-500 text-blue-300'
                      : currentStep === 'addroundkey'
                      ? 'bg-emerald-950/60 border-emerald-500 text-emerald-300'
                      : 'bg-zinc-800 border-zinc-700 text-white'
                  }`}
                >
                  <span>{byteVal}</span>
                  <span className="text-[8px] text-zinc-500">[{rIdx},{cIdx}]</span>
                </div>
              ))
            )}
          </div>

          <div className="text-xs font-mono text-zinc-400">
            Current Stage: <span className="text-red-400 font-bold uppercase">{currentStep}</span>
          </div>
        </div>

        {/* Theory & Mathematical Explanations */}
        <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-4 text-xs">
          <h4 className="font-bold text-zinc-900 text-sm flex items-center gap-2">
            <Layers className="w-4 h-4 text-red-700" />
            Mathematical Stage Breakdown
          </h4>

          <div className="space-y-2.5 text-zinc-600">
            <div className={`p-2.5 rounded-lg border ${currentStep === 'subbytes' ? 'bg-amber-50 border-amber-300 text-amber-900 font-semibold' : 'bg-zinc-50 border-zinc-200'}`}>
              <strong>SubBytes:</strong> Inverts bytes in Galois Field GF(2⁸) with irreducible polynomial m(x) = x⁸ + x⁴ + x³ + x + 1, followed by affine transformation to maximize non-linearity.
            </div>

            <div className={`p-2.5 rounded-lg border ${currentStep === 'shiftrows' ? 'bg-purple-50 border-purple-300 text-purple-900 font-semibold' : 'bg-zinc-50 border-zinc-200'}`}>
              <strong>ShiftRows:</strong> Shifts Row 0 by 0 bytes, Row 1 by 1 byte left, Row 2 by 2 bytes left, and Row 3 by 3 bytes left to provide diffusion across columns.
            </div>

            <div className={`p-2.5 rounded-lg border ${currentStep === 'mixcolumns' ? 'bg-blue-50 border-blue-300 text-blue-900 font-semibold' : 'bg-zinc-50 border-zinc-200'}`}>
              <strong>MixColumns:</strong> Treats each column as a 4-term polynomial multiplied by fixed polynomial c(x) = {`{03}`}x³ + {`{01}`}x² + {`{01}`}x + {`{02}`} mod (x⁴ + 1) in GF(2⁸).
            </div>

            <div className={`p-2.5 rounded-lg border ${currentStep === 'addroundkey' ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-semibold' : 'bg-zinc-50 border-zinc-200'}`}>
              <strong>AddRoundKey:</strong> Simple bitwise XOR between the 128-bit State matrix and the 128-bit round subkey generated by the Rijndael Key Schedule.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
