import React, { useState } from 'react';
import { Network, Shield, Key, RefreshCw, Layers, ArrowRight, Play, CheckCircle2 } from 'lucide-react';

export const ECCSimulator: React.FC = () => {
  // Elliptic curve over F_p: y^2 = x^3 + ax + b (mod p)
  const [a, setA] = useState(2);
  const [b, setB] = useState(3);
  const [p, setP] = useState(17);

  // Selected base points
  const [pX, setPX] = useState(3);
  const [pY, setPY] = useState(10);
  const [scalarK, setScalarK] = useState(2);

  // Modulo arithmetic helpers
  const modP = (val: number, prime: number) => ((val % prime) + prime) % prime;
  const modInverse = (val: number, prime: number) => {
    val = modP(val, prime);
    for (let x = 1; x < prime; x++) {
      if ((val * x) % prime === 1) return x;
    }
    return 1;
  };

  // Check if (x, y) is on curve y^2 = x^3 + ax + b mod p
  const isOnCurve = (x: number, y: number) => {
    const left = modP(y * y, p);
    const right = modP(x * x * x + a * x + b, p);
    return left === right;
  };

  // Find all valid points on curve
  const validPoints: [number, number][] = [];
  for (let x = 0; x < p; x++) {
    for (let y = 0; y < p; y++) {
      if (isOnCurve(x, y)) {
        validPoints.push([x, y]);
      }
    }
  }

  // Point Doubling 2P = P + P
  const doublePoint = (x: number, y: number): [number, number] | null => {
    if (y === 0) return null; // Point at infinity
    const num = modP(3 * x * x + a, p);
    const den = modP(2 * y, p);
    const slope = modP(num * modInverse(den, p), p);
    const x3 = modP(slope * slope - 2 * x, p);
    const y3 = modP(slope * (x - x3) - y, p);
    return [x3, y3];
  };

  const doubledResult = doublePoint(pX, pY);

  return (
    <div className="space-y-6">
      {/* Curve Setup */}
      <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h4 className="font-bold text-zinc-900 flex items-center gap-2">
              <Network className="w-5 h-5 text-red-700" />
              Elliptic Curve over Finite Prime Field F_p
            </h4>
            <p className="text-xs text-zinc-500 mt-0.5">
              Weierstrass Curve Equation: y² ≡ x³ + {a}x + {b} (mod {p})
            </p>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => { setA(2); setB(3); setP(17); setPX(3); setPY(10); }}
              className="px-3 py-1 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-semibold rounded-lg cursor-pointer"
            >
              Preset (a=2, b=3, p=17)
            </button>
            <button
              onClick={() => { setA(1); setB(6); setP(11); setPX(2); setPY(7); }}
              className="px-3 py-1 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-semibold rounded-lg cursor-pointer"
            >
              Small (a=1, b=6, p=11)
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
              Parameter 'a'
            </label>
            <input
              type="number"
              value={a}
              onChange={(e) => setA(parseInt(e.target.value) || 0)}
              className="w-full p-2.5 text-sm border border-zinc-300 rounded-lg font-mono font-bold"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
              Parameter 'b'
            </label>
            <input
              type="number"
              value={b}
              onChange={(e) => setB(parseInt(e.target.value) || 0)}
              className="w-full p-2.5 text-sm border border-zinc-300 rounded-lg font-mono font-bold"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
              Prime Modulus 'p'
            </label>
            <input
              type="number"
              value={p}
              onChange={(e) => setP(parseInt(e.target.value) || 17)}
              className="w-full p-2.5 text-sm border border-zinc-300 rounded-lg font-mono font-bold"
            />
          </div>
        </div>
      </div>

      {/* Discrete Finite Field Point Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-4">
          <h4 className="font-bold text-zinc-900 text-sm flex items-center gap-2">
            <Layers className="w-4 h-4 text-red-700" />
            Valid Curve Points on F_{p} ({validPoints.length} Points Found)
          </h4>

          <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto p-3 bg-zinc-50 rounded-xl border border-zinc-200">
            {validPoints.map(([x, y], idx) => (
              <button
                key={idx}
                onClick={() => { setPX(x); setPY(y); }}
                className={`px-2.5 py-1 text-xs font-mono rounded-md border transition-all cursor-pointer ${
                  x === pX && y === pY
                    ? 'bg-red-800 text-white border-red-900 font-bold shadow-xs'
                    : 'bg-white hover:bg-zinc-100 text-zinc-800 border-zinc-300'
                }`}
              >
                ({x}, {y})
              </button>
            ))}
          </div>

          <div className="text-xs text-zinc-500">
            Click any valid point above to select base point P for Point Doubling & Scalar Multiplication.
          </div>
        </div>

        {/* Point Doubling Mathematics */}
        <div className="bg-zinc-900 text-zinc-100 p-5 rounded-xl border border-zinc-800 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <span className="text-xs font-semibold uppercase text-zinc-400">
                Point Doubling 2P = P + P
              </span>
              <span className="text-xs px-2 py-0.5 bg-red-950 text-red-300 rounded border border-red-700 font-mono">
                P = ({pX}, {pY})
              </span>
            </div>

            <div className="mt-4 space-y-3 font-mono text-xs">
              <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-800">
                <span className="text-zinc-500 block text-[10px]">Tangent Slope Formula:</span>
                <span className="text-amber-400 font-bold">
                  λ = (3·x₁² + a) / (2·y₁) mod p = (3·{pX}² + {a}) / (2·{pY}) mod {p}
                </span>
              </div>

              <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-800">
                <span className="text-zinc-500 block text-[10px]">Resulting Point 2P Coordinates:</span>
                <span className="text-emerald-400 font-bold text-base">
                  {doubledResult ? `2P = (${doubledResult[0]}, ${doubledResult[1]})` : 'Point at Infinity (O)'}
                </span>
              </div>
            </div>
          </div>

          <div className="text-[11px] text-zinc-400 bg-zinc-800/50 p-2.5 rounded mt-3">
            ⚡ <strong>ECC Efficiency:</strong> 256-bit ECC provides security equivalent to 3072-bit RSA, consuming 10× less battery and bandwidth on mobile devices.
          </div>
        </div>
      </div>
    </div>
  );
};
