import React, { useState } from 'react';
import { Shield, Lock, Play, RefreshCw, CheckCircle2, XCircle, ArrowRight, AlertTriangle, Filter } from 'lucide-react';

interface ACLRule {
  id: number;
  action: 'PERMIT' | 'DENY';
  protocol: 'TCP' | 'UDP' | 'ICMP' | 'ANY';
  srcIp: string;
  dstPort: string;
  description: string;
}

export const FirewallACLSimulator: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'firewall' | 'tls'>('firewall');

  // Firewall Rule Table
  const [rules, setRules] = useState<ACLRule[]>([
    { id: 10, action: 'PERMIT', protocol: 'TCP', srcIp: '192.168.1.0/24', dstPort: '443', description: 'Allow Outbound HTTPS' },
    { id: 20, action: 'PERMIT', protocol: 'TCP', srcIp: '192.168.1.0/24', dstPort: '80', description: 'Allow Outbound HTTP' },
    { id: 30, action: 'DENY', protocol: 'TCP', srcIp: '10.0.0.0/8', dstPort: '22', description: 'Block Rogue SSH Ingress' },
    { id: 40, action: 'DENY', protocol: 'ICMP', srcIp: 'ANY', dstPort: 'ANY', description: 'Drop Ping/ICMP Floods' },
    { id: 99, action: 'DENY', protocol: 'ANY', srcIp: 'ANY', dstPort: 'ANY', description: 'Implicit Deny All' }
  ]);

  // Test Packet
  const [pktSrcIp, setPktSrcIp] = useState('192.168.1.50');
  const [pktDstPort, setPktDstPort] = useState('443');
  const [pktProtocol, setPktProtocol] = useState<'TCP' | 'UDP' | 'ICMP'>('TCP');

  // TLS 1.3 Handshake Step
  const [tlsStep, setTlsStep] = useState(0);

  // Evaluate Packet against ACL
  const evaluatePacket = () => {
    for (const rule of rules) {
      const matchProto = rule.protocol === 'ANY' || rule.protocol === pktProtocol;
      const matchPort = rule.dstPort === 'ANY' || rule.dstPort === pktDstPort;
      const matchIp =
        rule.srcIp === 'ANY' ||
        (rule.srcIp === '192.168.1.0/24' && pktSrcIp.startsWith('192.168.1.')) ||
        (rule.srcIp === '10.0.0.0/8' && pktSrcIp.startsWith('10.')) ||
        rule.srcIp === pktSrcIp;

      if (matchProto && matchPort && matchIp) {
        return { matchedRule: rule, decision: rule.action };
      }
    }
    return { matchedRule: rules[rules.length - 1], decision: 'DENY' as const };
  };

  const evalResult = evaluatePacket();

  return (
    <div className="space-y-6">
      {/* Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-zinc-200 pb-3">
        <button
          onClick={() => setActiveTab('firewall')}
          className={`px-4 py-2 text-sm font-semibold rounded-lg transition-all cursor-pointer ${
            activeTab === 'firewall' ? 'bg-red-800 text-white shadow-xs' : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
          }`}
        >
          Stateful Packet Inspection & ACL Engine
        </button>
        <button
          onClick={() => setActiveTab('tls')}
          className={`px-4 py-2 text-sm font-semibold rounded-lg transition-all cursor-pointer ${
            activeTab === 'tls' ? 'bg-red-800 text-white shadow-xs' : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
          }`}
        >
          TLS 1.3 (1-RTT) Cryptographic Handshake
        </button>
      </div>

      {activeTab === 'firewall' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Packet Injector */}
          <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-4">
            <h4 className="font-bold text-zinc-900 flex items-center gap-2">
              <Filter className="w-5 h-5 text-red-700" />
              IP Packet Test Injector
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
                  Source IP
                </label>
                <input
                  type="text"
                  value={pktSrcIp}
                  onChange={(e) => setPktSrcIp(e.target.value)}
                  className="w-full p-2 text-sm border border-zinc-300 rounded-lg font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
                  Protocol
                </label>
                <select
                  value={pktProtocol}
                  onChange={(e) => setPktProtocol(e.target.value as any)}
                  className="w-full p-2 text-sm border border-zinc-300 rounded-lg font-mono font-bold"
                >
                  <option value="TCP">TCP</option>
                  <option value="UDP">UDP</option>
                  <option value="ICMP">ICMP</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
                  Destination Port
                </label>
                <input
                  type="text"
                  value={pktDstPort}
                  onChange={(e) => setPktDstPort(e.target.value)}
                  className="w-full p-2 text-sm border border-zinc-300 rounded-lg font-mono font-bold"
                />
              </div>
            </div>

            {/* Decision Display */}
            <div className={`p-4 rounded-xl border flex items-center justify-between ${evalResult.decision === 'PERMIT' ? 'bg-emerald-50 border-emerald-300 text-emerald-900' : 'bg-red-50 border-red-300 text-red-900'}`}>
              <div className="flex items-center gap-3">
                {evalResult.decision === 'PERMIT' ? (
                  <CheckCircle2 className="w-8 h-8 text-emerald-600" />
                ) : (
                  <XCircle className="w-8 h-8 text-red-600" />
                )}
                <div>
                  <span className="font-bold text-base block uppercase">
                    Firewall Decision: {evalResult.decision}
                  </span>
                  <span className="text-xs">
                    Matched Rule #{evalResult.matchedRule.id}: {evalResult.matchedRule.description}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* ACL Ruleset Table */}
          <div className="bg-zinc-900 text-zinc-100 p-5 rounded-xl border border-zinc-800 shadow-xs space-y-3">
            <span className="text-xs font-semibold uppercase text-zinc-400 block">
              Active Security Access Control List (Evaluated Top-to-Bottom):
            </span>

            <div className="space-y-1.5 max-h-[300px] overflow-y-auto pr-1">
              {rules.map((r) => (
                <div
                  key={r.id}
                  className={`p-2.5 rounded-lg border text-xs font-mono flex items-center justify-between transition-all ${
                    r.id === evalResult.matchedRule.id
                      ? 'bg-zinc-800 border-amber-500 shadow-xs'
                      : 'bg-zinc-950 border-zinc-800 text-zinc-400'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-zinc-500 w-6">#{r.id}</span>
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${r.action === 'PERMIT' ? 'bg-emerald-950 text-emerald-300 border border-emerald-700' : 'bg-red-950 text-red-300 border border-red-700'}`}>
                      {r.action}
                    </span>
                    <span>{r.protocol}</span>
                    <span className="text-zinc-500">src:</span>
                    <span>{r.srcIp}</span>
                    <span className="text-zinc-500">dstPort:</span>
                    <span>{r.dstPort}</span>
                  </div>
                  <span className="text-[10px] text-zinc-500 italic hidden sm:inline">{r.description}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'tls' && (
        <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h4 className="font-bold text-zinc-900 flex items-center gap-2">
                <Lock className="w-5 h-5 text-red-700" />
                TLS 1.3 1-RTT Handshake Sequence
              </h4>
              <p className="text-xs text-zinc-500 mt-0.5">
                Client and Server negotiate ciphersuite and establish ephemeral ECDHE session key in a single round-trip.
              </p>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setTlsStep((prev) => (prev < 3 ? prev + 1 : 0))}
                className="px-4 py-2 bg-red-800 hover:bg-red-900 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                <Play className="w-3.5 h-3.5" /> Next Handshake Step ({tlsStep + 1}/4)
              </button>
              <button
                onClick={() => setTlsStep(0)}
                className="px-3 py-2 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-bold rounded-lg cursor-pointer"
              >
                Reset
              </button>
            </div>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className={`p-4 rounded-xl border transition-all ${tlsStep >= 0 ? 'bg-zinc-900 text-zinc-100 border-zinc-800' : 'bg-zinc-100 text-zinc-400'}`}>
              <div className="flex items-center gap-2 font-bold text-sm text-red-400">
                <span>1. ClientHello (1-RTT Key Share)</span>
              </div>
              <div className="text-[11px] text-zinc-300 mt-1">
                Client sends: Supported Ciphersuites (TLS_AES_256_GCM_SHA384) + Client ECDH Public Key (g^a mod p) + SNI (Server Name Indication).
              </div>
            </div>

            <div className={`p-4 rounded-xl border transition-all ${tlsStep >= 1 ? 'bg-zinc-900 text-zinc-100 border-zinc-800' : 'bg-zinc-100 text-zinc-400'}`}>
              <div className="flex items-center gap-2 font-bold text-sm text-blue-400">
                <span>2. ServerHello + Encrypted Extensions + Certificate</span>
              </div>
              <div className="text-[11px] text-zinc-300 mt-1">
                Server selects cipher + sends Server ECDH Public Key (g^b mod p) + X.509 Certificate + Digital Signature (CertificateVerify).
              </div>
            </div>

            <div className={`p-4 rounded-xl border transition-all ${tlsStep >= 2 ? 'bg-zinc-900 text-zinc-100 border-zinc-800' : 'bg-zinc-100 text-zinc-400'}`}>
              <div className="flex items-center gap-2 font-bold text-sm text-amber-400">
                <span>3. Shared Secret Key Derivation (HKDF)</span>
              </div>
              <div className="text-[11px] text-zinc-300 mt-1">
                Both parties independently compute premaster secret g^(ab) mod p, then derive AES-256 Symmetric Session Keys & HMAC keys.
              </div>
            </div>

            <div className={`p-4 rounded-xl border transition-all ${tlsStep >= 3 ? 'bg-emerald-950 text-emerald-100 border-emerald-700 shadow-xs' : 'bg-zinc-100 text-zinc-400'}`}>
              <div className="flex items-center gap-2 font-bold text-sm text-emerald-300">
                <CheckCircle2 className="w-4 h-4" />
                <span>4. Encrypted Application Data Flow (HTTPS Ready)</span>
              </div>
              <div className="text-[11px] text-emerald-200 mt-1">
                Full bi-directional authenticated encryption (AEAD) established with Perfect Forward Secrecy (PFS).
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
