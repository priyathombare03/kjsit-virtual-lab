import React, { useState } from 'react';
import { Key, Shield, RefreshCw, Play, CheckCircle2, Lock, Unlock, Zap, Sparkles } from 'lucide-react';

export const RSASimulator: React.FC = () => {
  const [p, setP] = useState(61);
  const [q, setQ] = useState(53);
  const [eVal, setEVal] = useState(17);
  const [msgVal, setMsgVal] = useState(65); // ASCII for 'A'

  // Helper calculations
  const gcd = (a: number, b: number): number => (!b ? a : gcd(b, a % b));
  
  const extGCD = (a: number, b: number): [number, number, number] => {
    if (b === 0) return [a, 1, 0];
    const [g, x1, y1] = extGCD(b, a % b);
    const x = y1;
    const y = x1 - Math.floor(a / b) * y1;
    return [g, x, y];
  };

  const modInverse = (a: number, m: number) => {
    const [g, x] = extGCD(a, m);
    if (g !== 1) return null;
    return ((x % m) + m) % m;
  };

  // Modular Exponentiation (base^exp mod mod)
  const powerMod = (base: number, exp: number, mod: number) => {
    let res = 1;
    base = base % mod;
    while (exp > 0) {
      if (exp % 2 === 1) res = (res * base) % mod;
      base = (base * base) % mod;
      exp = Math.floor(exp / 2);
    }
    return res;
  };

  const n = p * q;
  const phi = (p - 1) * (q - 1);
  const isECoprime = gcd(eVal, phi) === 1;
  const dVal = isECoprime ? modInverse(eVal, phi) : null;

  const ciphertext = isECoprime && dVal !== null ? powerMod(msgVal, eVal, n) : 0;
  const decrypted = isECoprime && dVal !== null ? powerMod(ciphertext, dVal, n) : 0;

  // Preset prime sets
  const handleSelectPreset = (pNum: number, qNum: number, eNum: number) => {
    setP(pNum);
    setQ(qNum);
    setEVal(eNum);
  };

  return (
    <div className="space-y-6">
      {/* Parameter Selection & Key Generation */}
      <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h4 className="font-bold text-zinc-900 flex items-center gap-2">
              <Key className="w-5 h-5 text-red-700" />
              RSA Key Generation & Mathematical Setup
            </h4>
            <p className="text-xs text-zinc-500 mt-0.5">
              Select two distinct primes p & q, compute modulus n = p × q, totient φ(n) = (p-1)(q-1), and modular inverse d ≡ e⁻¹ (mod φ(n)).
            </p>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => handleSelectPreset(61, 53, 17)}
              className="px-3 py-1 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-semibold rounded-lg cursor-pointer"
            >
              Demo (61, 53)
            </button>
            <button
              onClick={() => handleSelectPreset(13, 11, 7)}
              className="px-3 py-1 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-semibold rounded-lg cursor-pointer"
            >
              Small (13, 11)
            </button>
            <button
              onClick={() => handleSelectPreset(89, 97, 19)}
              className="px-3 py-1 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-semibold rounded-lg cursor-pointer"
            >
              Large (89, 97)
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
              Prime Number p
            </label>
            <input
              type="number"
              value={p}
              onChange={(e) => setP(parseInt(e.target.value) || 2)}
              className="w-full p-2.5 text-sm border border-zinc-300 rounded-lg font-mono font-bold"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
              Prime Number q
            </label>
            <input
              type="number"
              value={q}
              onChange={(e) => setQ(parseInt(e.target.value) || 2)}
              className="w-full p-2.5 text-sm border border-zinc-300 rounded-lg font-mono font-bold"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
              Public Exponent e
            </label>
            <input
              type="number"
              value={eVal}
              onChange={(e) => setEVal(parseInt(e.target.value) || 3)}
              className="w-full p-2.5 text-sm border border-zinc-300 rounded-lg font-mono font-bold"
            />
          </div>
        </div>

        {/* Derived Keys Overview Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
          <div className="p-3 bg-zinc-50 border border-zinc-200 rounded-lg text-center">
            <span className="text-zinc-500 text-[10px] uppercase block">Modulus n (p × q)</span>
            <span className="text-sm font-bold text-zinc-900">{n}</span>
          </div>

          <div className="p-3 bg-zinc-50 border border-zinc-200 rounded-lg text-center">
            <span className="text-zinc-500 text-[10px] uppercase block">Totient φ(n)</span>
            <span className="text-sm font-bold text-zinc-900">{phi}</span>
          </div>

          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-center">
            <span className="text-emerald-700 text-[10px] uppercase font-bold block">Public Key (e, n)</span>
            <span className="text-sm font-bold text-emerald-800">({eVal}, {n})</span>
          </div>

          <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-center">
            <span className="text-red-700 text-[10px] uppercase font-bold block">Private Key (d, n)</span>
            <span className="text-sm font-bold text-red-800">{dVal !== null ? `(${dVal}, ${n})` : 'Invalid e'}</span>
          </div>
        </div>
      </div>

      {/* Encryption & Decryption Sandbox */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-4">
          <h4 className="font-bold text-zinc-900 flex items-center gap-2">
            <Lock className="w-5 h-5 text-red-700" />
            Encryption: C = (M^e) mod n
          </h4>

          <div>
            <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
              Numeric Plaintext Message M (where 0 ≤ M &lt; {n})
            </label>
            <input
              type="number"
              value={msgVal}
              max={n - 1}
              onChange={(e) => setMsgVal(parseInt(e.target.value) || 0)}
              className="w-full p-2.5 text-sm border border-zinc-300 rounded-lg font-mono font-bold"
            />
            <span className="text-[11px] text-zinc-500">
              Corresponds to ASCII character: '{String.fromCharCode(msgVal >= 32 && msgVal <= 126 ? msgVal : 63)}'
            </span>
          </div>

          <div className="p-4 bg-zinc-950 rounded-xl border border-zinc-800 text-zinc-100 font-mono text-xs space-y-2">
            <div className="text-zinc-400">
              Formula: C = ({msgVal}^{eVal}) mod {n}
            </div>
            <div className="text-amber-400 font-bold text-base flex justify-between items-center pt-2 border-t border-zinc-800">
              <span>Ciphertext C:</span>
              <span>{ciphertext}</span>
            </div>
          </div>
        </div>

        <div className="bg-zinc-900 text-zinc-100 p-5 rounded-xl border border-zinc-800 shadow-xs space-y-4">
          <h4 className="font-bold text-white flex items-center gap-2">
            <Unlock className="w-5 h-5 text-emerald-400" />
            Decryption: M = (C^d) mod n
          </h4>

          <div className="space-y-2 text-xs font-mono text-zinc-400">
            <div>
              Private Key Exponent d = <span className="text-red-400 font-bold">{dVal}</span>
            </div>
            <div>
              Formula: M = ({ciphertext}^{dVal}) mod {n}
            </div>
          </div>

          <div className="p-4 bg-zinc-950 rounded-xl border border-zinc-800 text-zinc-100 font-mono text-xs space-y-2">
            <div className="text-emerald-400 font-bold text-base flex justify-between items-center">
              <span>Recovered Plaintext M:</span>
              <span>{decrypted}</span>
            </div>
            <div className="text-[11px] text-zinc-400">
              Matches original input: <span className="text-emerald-300 font-bold">{decrypted === msgVal ? 'EXACT MATCH (VERIFIED)' : 'MISMATCH'}</span>
            </div>
          </div>

          <div className="text-[11px] text-zinc-400 bg-zinc-800/50 p-2.5 rounded">
            ✨ <strong>Square-and-Multiply:</strong> Computes modular exponentiation in O(log e) multiplications by evaluating the binary representation of the exponent.
          </div>
        </div>
      </div>
    </div>
  );
};
