import React, { useState } from 'react';
import { Shield, Key, RefreshCw, BarChart2, Zap, ArrowRight, Lock, Unlock, Eye, Sparkles } from 'lucide-react';

export const ClassicalCipherSimulator: React.FC = () => {
  const [activeCipher, setActiveCipher] = useState<'caesar' | 'playfair' | 'mono'>('caesar');
  
  // Caesar State
  const [caesarInput, setCaesarInput] = useState('SOMAIYA KJSIT VIRTUAL LAB');
  const [caesarShift, setCaesarShift] = useState(3);
  const [caesarMode, setCaesarMode] = useState<'encrypt' | 'decrypt'>('encrypt');

  // Playfair State
  const [playfairKey, setPlayfairKey] = useState('MONARCHY');
  const [playfairInput, setPlayfairInput] = useState('INSTRUMENTS');

  // Monoalphabetic State
  const standardAlphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const [monoKey, setMonoKey] = useState('QWERTYUIOPASDFGHJKLZXCVBNM');
  const [monoInput, setMonoInput] = useState('KNOWLEDGE ALONE LIBERATES');

  // Caesar Execution
  const processCaesar = (text: string, shift: number, mode: 'encrypt' | 'decrypt') => {
    const s = mode === 'encrypt' ? (shift % 26) : ((26 - (shift % 26)) % 26);
    return text
      .toUpperCase()
      .split('')
      .map((char) => {
        const code = char.charCodeAt(0);
        if (code >= 65 && code <= 90) {
          return String.fromCharCode(((code - 65 + s) % 26) + 65);
        }
        return char;
      })
      .join('');
  };

  const caesarResult = processCaesar(caesarInput, caesarShift, caesarMode);

  // Playfair Grid Builder
  const buildPlayfairGrid = (key: string) => {
    const cleanKey = key.toUpperCase().replace(/[^A-Z]/g, '').replace(/J/g, 'I');
    const seen = new Set<string>();
    const matrix: string[] = [];

    for (const char of cleanKey) {
      if (!seen.has(char)) {
        seen.add(char);
        matrix.push(char);
      }
    }

    for (const char of 'ABCDEFGHIKLMNOPQRSTUVWXYZ') {
      if (!seen.has(char)) {
        seen.add(char);
        matrix.push(char);
      }
    }

    const grid: string[][] = [];
    for (let r = 0; r < 5; r++) {
      grid.push(matrix.slice(r * 5, r * 5 + 5));
    }
    return grid;
  };

  const playfairGrid = buildPlayfairGrid(playfairKey);

  // Playfair Digraph Processor
  const processPlayfair = (text: string, grid: string[][]) => {
    const clean = text.toUpperCase().replace(/[^A-Z]/g, '').replace(/J/g, 'I');
    const digraphs: [string, string][] = [];
    let i = 0;
    while (i < clean.length) {
      const c1 = clean[i];
      let c2 = i + 1 < clean.length ? clean[i + 1] : 'X';
      if (c1 === c2) {
        c2 = 'X';
        i++;
      } else {
        i += 2;
      }
      digraphs.push([c1, c2]);
    }

    const findPos = (ch: string): [number, number] => {
      for (let r = 0; r < 5; r++) {
        for (let c = 0; c < 5; c++) {
          if (grid[r][c] === ch) return [r, c];
        }
      }
      return [0, 0];
    };

    const encryptedPairs = digraphs.map(([c1, c2]) => {
      const [r1, col1] = findPos(c1);
      const [r2, col2] = findPos(c2);
      let out1 = '', out2 = '';

      if (r1 === r2) {
        // Same Row -> shift right
        out1 = grid[r1][(col1 + 1) % 5];
        out2 = grid[r2][(col2 + 1) % 5];
      } else if (col1 === col2) {
        // Same Column -> shift down
        out1 = grid[(r1 + 1) % 5][col1];
        out2 = grid[(r2 + 1) % 5][col2];
      } else {
        // Rectangle swap
        out1 = grid[r1][col2];
        out2 = grid[r2][col1];
      }
      return { pair: `${c1}${c2}`, enc: `${out1}${out2}`, rule: r1 === r2 ? 'Same Row (Shift Right)' : col1 === col2 ? 'Same Col (Shift Down)' : 'Rectangle (Corner Swap)' };
    });

    return encryptedPairs;
  };

  const playfairPairs = processPlayfair(playfairInput, playfairGrid);
  const playfairCiphertext = playfairPairs.map((p) => p.enc).join(' ');

  // Monoalphabetic
  const processMono = (text: string, key: string) => {
    const map: Record<string, string> = {};
    for (let i = 0; i < 26; i++) {
      map[standardAlphabet[i]] = key[i] || standardAlphabet[i];
    }
    return text
      .toUpperCase()
      .split('')
      .map((c) => map[c] || c)
      .join('');
  };

  const monoResult = processMono(monoInput, monoKey);

  // Letter Frequency Counter
  const getFrequencies = (text: string) => {
    const counts: Record<string, number> = {};
    let total = 0;
    for (const ch of text.toUpperCase()) {
      if (ch >= 'A' && ch <= 'Z') {
        counts[ch] = (counts[ch] || 0) + 1;
        total++;
      }
    }
    return { counts, total };
  };

  const activeText = activeCipher === 'caesar' ? caesarResult : activeCipher === 'playfair' ? playfairCiphertext : monoResult;
  const { counts: cipherCounts, total: totalCipherChars } = getFrequencies(activeText);

  // English top frequencies benchmark
  const englishBenchmark: Record<string, number> = { E: 12.7, T: 9.1, A: 8.2, O: 7.5, I: 7.0, N: 6.7, S: 6.3, H: 6.1, R: 6.0, D: 4.3 };

  return (
    <div className="space-y-6">
      {/* Tab Selector */}
      <div className="flex flex-wrap gap-2 border-b border-zinc-200 pb-3">
        <button
          onClick={() => setActiveCipher('caesar')}
          className={`px-4 py-2 text-sm font-semibold rounded-lg transition-all ${
            activeCipher === 'caesar'
              ? 'bg-red-800 text-white shadow-sm'
              : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
          }`}
        >
          Caesar Shift Cipher
        </button>
        <button
          onClick={() => setActiveCipher('playfair')}
          className={`px-4 py-2 text-sm font-semibold rounded-lg transition-all ${
            activeCipher === 'playfair'
              ? 'bg-red-800 text-white shadow-sm'
              : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
          }`}
        >
          Playfair 5×5 Matrix Cipher
        </button>
        <button
          onClick={() => setActiveCipher('mono')}
          className={`px-4 py-2 text-sm font-semibold rounded-lg transition-all ${
            activeCipher === 'mono'
              ? 'bg-red-800 text-white shadow-sm'
              : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
          }`}
        >
          Monoalphabetic Substitution
        </button>
      </div>

      {/* Caesar Simulator */}
      {activeCipher === 'caesar' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-zinc-900 flex items-center gap-2">
                <Shield className="w-5 h-5 text-red-700" />
                Caesar Parameter Controls
              </h4>
              <div className="flex items-center gap-1 bg-zinc-100 p-1 rounded-lg">
                <button
                  onClick={() => setCaesarMode('encrypt')}
                  className={`px-3 py-1 text-xs font-bold rounded-md transition-all ${
                    caesarMode === 'encrypt' ? 'bg-red-800 text-white' : 'text-zinc-600'
                  }`}
                >
                  Encrypt (+k)
                </button>
                <button
                  onClick={() => setCaesarMode('decrypt')}
                  className={`px-3 py-1 text-xs font-bold rounded-md transition-all ${
                    caesarMode === 'decrypt' ? 'bg-red-800 text-white' : 'text-zinc-600'
                  }`}
                >
                  Decrypt (-k)
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
                Plaintext / Ciphertext Input
              </label>
              <textarea
                value={caesarInput}
                onChange={(e) => setCaesarInput(e.target.value)}
                className="w-full p-3 text-sm border border-zinc-300 rounded-lg focus:ring-2 focus:ring-red-700 font-mono"
                rows={3}
              />
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-semibold text-zinc-600 uppercase">
                  Shift Key (k): <span className="text-red-700 font-bold text-sm">{caesarShift}</span> (mod 26)
                </label>
                <button
                  onClick={() => setCaesarShift((prev) => (prev + 1) % 26)}
                  className="text-xs text-red-700 font-medium hover:underline flex items-center gap-1"
                >
                  <RefreshCw className="w-3 h-3" /> Next Shift
                </button>
              </div>
              <input
                type="range"
                min="0"
                max="25"
                value={caesarShift}
                onChange={(e) => setCaesarShift(parseInt(e.target.value))}
                className="w-full accent-red-700 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-zinc-400 font-mono mt-1">
                <span>k=0</span>
                <span>k=13 (ROT13)</span>
                <span>k=25</span>
              </div>
            </div>

            {/* Alphabet Shift Ribbon */}
            <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200 overflow-x-auto">
              <span className="text-xs font-semibold text-zinc-500 block mb-1">
                Modular Shift Wheel Mapping:
              </span>
              <div className="flex gap-1 font-mono text-xs">
                {standardAlphabet.slice(0, 13).split('').map((ch, idx) => {
                  const shifted = String.fromCharCode(((idx + caesarShift) % 26) + 65);
                  return (
                    <div key={ch} className="text-center p-1 bg-white border border-zinc-200 rounded min-w-[24px]">
                      <div className="text-zinc-600 text-[10px]">{ch}</div>
                      <div className="text-red-700 font-bold text-xs">{shifted}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="bg-zinc-900 text-zinc-100 p-5 rounded-xl border border-zinc-800 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
                <span className="text-xs font-semibold uppercase text-zinc-400 flex items-center gap-1">
                  <Key className="w-4 h-4 text-amber-400" />
                  {caesarMode === 'encrypt' ? 'Generated Ciphertext' : 'Recovered Plaintext'}
                </span>
                <span className="text-xs px-2 py-0.5 bg-red-900/50 text-red-300 rounded border border-red-700/50 font-mono">
                  Shift: {caesarShift}
                </span>
              </div>

              <div className="mt-4 p-4 bg-zinc-950 rounded-lg border border-zinc-800 font-mono text-base text-emerald-400 break-all">
                {caesarResult || '(No Input Provided)'}
              </div>

              {/* Brute Force Cryptanalysis Preview */}
              <div className="mt-4">
                <span className="text-xs font-semibold uppercase text-zinc-400 block mb-2">
                  Brute Force Exhaustive Cryptanalysis (Testing 25 Shifts):
                </span>
                <div className="max-h-40 overflow-y-auto space-y-1 text-xs font-mono bg-zinc-950 p-3 rounded-lg border border-zinc-800 text-zinc-400">
                  {[...Array(6)].map((_, i) => {
                    const testShift = (i + 1) % 26;
                    const testDecrypted = processCaesar(caesarResult, testShift, 'decrypt');
                    return (
                      <div
                        key={i}
                        className={`flex justify-between py-0.5 px-1 rounded ${
                          testShift === caesarShift ? 'bg-red-950/80 text-emerald-300 font-bold border border-red-700' : ''
                        }`}
                      >
                        <span>k = {testShift.toString().padStart(2, '0')}:</span>
                        <span className="truncate max-w-[240px]">{testDecrypted}</span>
                        {testShift === caesarShift && <span className="text-amber-400 text-[10px] uppercase font-bold">MATCH</span>}
                      </div>
                    );
                  })}
                  <div className="text-center text-[10px] text-zinc-500">... [19 more shift trials computed] ...</div>
                </div>
              </div>
            </div>

            <div className="text-[11px] text-zinc-400 bg-zinc-800/50 p-2 rounded mt-3">
              💡 <strong>Cryptanalysis Note:</strong> Caesar ciphers are easily cracked in O(1) time because there are only 25 unique key permutations.
            </div>
          </div>
        </div>
      )}

      {/* Playfair Simulator */}
      {activeCipher === 'playfair' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-4">
            <h4 className="font-bold text-zinc-900 flex items-center gap-2">
              <Shield className="w-5 h-5 text-red-700" />
              Playfair 5×5 Matrix Setup
            </h4>

            <div>
              <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
                Keyword (e.g. MONARCHY, KJSIT)
              </label>
              <input
                type="text"
                value={playfairKey}
                onChange={(e) => setPlayfairKey(e.target.value.toUpperCase())}
                className="w-full p-2.5 text-sm border border-zinc-300 rounded-lg focus:ring-2 focus:ring-red-700 font-mono font-bold"
              />
              <span className="text-[11px] text-zinc-500">
                Letters I and J are combined into a single matrix cell.
              </span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
                Plaintext Message
              </label>
              <input
                type="text"
                value={playfairInput}
                onChange={(e) => setPlayfairInput(e.target.value.toUpperCase())}
                className="w-full p-2.5 text-sm border border-zinc-300 rounded-lg focus:ring-2 focus:ring-red-700 font-mono"
              />
            </div>

            {/* Visual 5x5 Matrix */}
            <div>
              <span className="text-xs font-semibold text-zinc-700 uppercase block mb-2">
                5×5 Key Matrix (Key: {playfairKey})
              </span>
              <div className="grid grid-cols-5 gap-1.5 max-w-[260px] mx-auto bg-zinc-900 p-2.5 rounded-xl shadow-inner">
                {playfairGrid.flatMap((row, rIdx) =>
                  row.map((cell, cIdx) => (
                    <div
                      key={`${rIdx}-${cIdx}`}
                      className="w-10 h-10 flex items-center justify-center bg-zinc-800 text-white font-mono font-bold text-sm rounded-lg border border-zinc-700 hover:border-red-500 transition-all"
                    >
                      {cell === 'I' ? 'I/J' : cell}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          <div className="bg-zinc-900 text-zinc-100 p-5 rounded-xl border border-zinc-800 shadow-xs space-y-4">
            <h4 className="font-bold text-white flex items-center gap-2 text-sm uppercase">
              <Sparkles className="w-4 h-4 text-red-400" />
              Digraph Step-by-Step Encryption
            </h4>

            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
              {playfairPairs.map((pair, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-2.5 bg-zinc-950 rounded-lg border border-zinc-800 font-mono text-xs"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-zinc-500 font-sans text-[10px]">#{idx + 1}</span>
                    <span className="px-2 py-0.5 bg-zinc-800 text-amber-300 font-bold rounded">
                      {pair.pair}
                    </span>
                    <ArrowRight className="w-3 h-3 text-zinc-500" />
                    <span className="px-2 py-0.5 bg-red-950 text-emerald-400 font-bold rounded border border-red-700">
                      {pair.enc}
                    </span>
                  </div>
                  <span className="text-[11px] text-zinc-400 italic">{pair.rule}</span>
                </div>
              ))}
            </div>

            <div className="pt-3 border-t border-zinc-800">
              <span className="text-xs uppercase text-zinc-400 block mb-1">Final Playfair Ciphertext:</span>
              <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-800 text-emerald-400 font-mono font-bold tracking-wider">
                {playfairCiphertext || '(No input)'}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Monoalphabetic Simulator */}
      {activeCipher === 'mono' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-xs space-y-4">
            <h4 className="font-bold text-zinc-900 flex items-center gap-2">
              <Key className="w-5 h-5 text-red-700" />
              Monoalphabetic Substitution Key
            </h4>

            <div>
              <label className="block text-xs font-semibold text-zinc-600 uppercase mb-1">
                Plaintext Message
              </label>
              <textarea
                value={monoInput}
                onChange={(e) => setMonoInput(e.target.value)}
                className="w-full p-2.5 text-sm border border-zinc-300 rounded-lg font-mono focus:ring-2 focus:ring-red-700"
                rows={2}
              />
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-semibold text-zinc-600 uppercase">
                  Substitution Key (26 Distinct Letters)
                </label>
                <button
                  onClick={() => {
                    const shuffled = standardAlphabet.split('').sort(() => 0.5 - Math.random()).join('');
                    setMonoKey(shuffled);
                  }}
                  className="text-xs text-red-700 font-semibold hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" /> Randomize Permutation
                </button>
              </div>
              <input
                type="text"
                value={monoKey}
                onChange={(e) => setMonoKey(e.target.value.toUpperCase())}
                className="w-full p-2 text-sm border border-zinc-300 rounded-lg font-mono font-bold"
              />
            </div>

            {/* Substitution Table Ribbon */}
            <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200 overflow-x-auto">
              <div className="flex gap-1 font-mono text-[11px]">
                {standardAlphabet.slice(0, 13).split('').map((orig, i) => (
                  <div key={orig} className="text-center p-1 bg-white border border-zinc-200 rounded min-w-[24px]">
                    <div className="text-zinc-500">{orig}</div>
                    <div className="text-red-700 font-bold">{monoKey[i] || '?'}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-zinc-900 text-zinc-100 p-5 rounded-xl border border-zinc-800 shadow-xs flex flex-col justify-between">
            <div>
              <span className="text-xs font-semibold uppercase text-zinc-400 block mb-1">
                Encrypted Ciphertext:
              </span>
              <div className="p-4 bg-zinc-950 rounded-lg border border-zinc-800 font-mono text-emerald-400 font-bold break-all">
                {monoResult}
              </div>

              <div className="mt-4">
                <span className="text-xs font-semibold uppercase text-zinc-400 block mb-2 flex items-center gap-1">
                  <BarChart2 className="w-4 h-4 text-red-400" />
                  Letter Frequency Distribution (English vs. Ciphertext):
                </span>
                <div className="grid grid-cols-5 gap-2 text-xs font-mono">
                  {['E', 'T', 'A', 'O', 'I'].map((char) => {
                    const count = cipherCounts[char] || 0;
                    const pct = totalCipherChars > 0 ? ((count / totalCipherChars) * 100).toFixed(1) : '0';
                    return (
                      <div key={char} className="bg-zinc-950 p-2 rounded border border-zinc-800 text-center">
                        <span className="text-amber-400 font-bold text-sm">{char}</span>
                        <div className="text-[10px] text-zinc-400 mt-1">Observed: {pct}%</div>
                        <div className="text-[9px] text-zinc-500">Benchmark: {englishBenchmark[char]}%</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="text-[11px] text-zinc-400 bg-zinc-800/50 p-2 rounded mt-3">
              📊 <strong>Frequency Cryptanalysis:</strong> In natural English, 'E' and 'T' are the most frequent letters. By mapping peaks in the ciphertext distribution, the substitution key can be recovered without brute force.
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
