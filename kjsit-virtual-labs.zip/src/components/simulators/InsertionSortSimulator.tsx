import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, SkipForward, Sparkles } from 'lucide-react';
import { VisuAlgoCodePanel } from './common/VisuAlgoCodePanel';
import { ALGORITHM_CODES } from './common/algorithmCodes';

interface InsertionStep {
  array: number[];
  i: number;
  j: number;
  key: number;
  action: 'pick_key' | 'compare' | 'shift' | 'insert' | 'sorted';
  description: string;
  comparingIndices?: [number, number];
  keyIndex?: number;
  sortedUpTo: number;
  activeCodeLine: number;
}

interface InsertionSortProps {
  onSimulationComplete?: () => void;
}

export const InsertionSortSimulator: React.FC<InsertionSortProps> = ({ onSimulationComplete }) => {
  const [initialArray, setInitialArray] = useState<number[]>([12, 11, 13, 5, 6, 7, 28]);
  const [inputStr, setInputStr] = useState<string>('12, 11, 13, 5, 6, 7, 28');
  const [steps, setSteps] = useState<InsertionStep[]>([]);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [speed, setSpeed] = useState<number>(1000);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Generate complete Insertion Sort step trace with line highlighting
  const generateSteps = (arr: number[]) => {
    const generated: InsertionStep[] = [];
    const a = [...arr];
    const n = a.length;

    generated.push({
      array: [...a],
      i: 0,
      j: -1,
      key: a[0],
      action: 'pick_key',
      description: `Initial unsorted array of ${n} elements. Index #0 (${a[0]}) is initially considered sorted.`,
      sortedUpTo: 0,
      activeCodeLine: 0
    });

    for (let i = 1; i < n; i++) {
      const key = a[i];
      let j = i - 1;

      generated.push({
        array: [...a],
        i,
        j,
        key,
        keyIndex: i,
        action: 'pick_key',
        description: `Pass ${i}: Picked key element ${key} at index #${i} to insert into sorted prefix [0..${i - 1}].`,
        sortedUpTo: i - 1,
        activeCodeLine: 1
      });

      while (j >= 0 && a[j] > key) {
        generated.push({
          array: [...a],
          i,
          j,
          key,
          action: 'compare',
          comparingIndices: [j, j + 1],
          description: `Comparing arr[${j}] (${a[j]}) with key (${key}). Since ${a[j]} > ${key}, shift ${a[j]} rightwards.`,
          sortedUpTo: i - 1,
          activeCodeLine: 3
        });

        a[j + 1] = a[j];

        generated.push({
          array: [...a],
          i,
          j,
          key,
          action: 'shift',
          comparingIndices: [j, j + 1],
          description: `Shifted element ${a[j]} to position #${j + 1}.`,
          sortedUpTo: i - 1,
          activeCodeLine: 4
        });

        j--;
      }

      if (j >= 0) {
        generated.push({
          array: [...a],
          i,
          j,
          key,
          action: 'compare',
          comparingIndices: [j, j + 1],
          description: `arr[${j}] (${a[j]}) <= key (${key}). Found correct insertion point at index #${j + 1}.`,
          sortedUpTo: i - 1,
          activeCodeLine: 3
        });
      }

      a[j + 1] = key;

      generated.push({
        array: [...a],
        i,
        j: j + 1,
        key,
        action: 'insert',
        description: `Inserted key (${key}) into its correct sorted position at index #${j + 1}.`,
        sortedUpTo: i,
        activeCodeLine: 6
      });
    }

    generated.push({
      array: [...a],
      i: n,
      j: n,
      key: a[n - 1],
      action: 'sorted',
      description: `Insertion Sort Complete! Array is completely sorted in ascending order.`,
      sortedUpTo: n - 1,
      activeCodeLine: 7
    });

    setSteps(generated);
    setCurrentStepIndex(0);
  };

  useEffect(() => {
    generateSteps(initialArray);
  }, [initialArray]);

  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        setCurrentStepIndex(prev => {
          if (prev < steps.length - 1) {
            return prev + 1;
          } else {
            setIsPlaying(false);
            return prev;
          }
        });
      }, speed);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, steps.length, speed]);

  // Notify parent when simulation reaches the final step (sorting completed)
  useEffect(() => {
    if (steps.length > 0 && currentStepIndex === steps.length - 1) {
      onSimulationComplete?.();
    }
  }, [currentStepIndex, steps.length, onSimulationComplete]);

  const handleApplyInput = () => {
    const parsed = inputStr
      .split(',')
      .map(x => parseInt(x.trim(), 10))
      .filter(x => !isNaN(x));
    if (parsed.length >= 2 && parsed.length <= 12) {
      setInitialArray(parsed);
      setIsPlaying(false);
    }
  };

  const handleRandomize = () => {
    const count = 7;
    const rand = Array.from({ length: count }, () => Math.floor(Math.random() * 85) + 5);
    setInitialArray(rand);
    setInputStr(rand.join(', '));
    setIsPlaying(false);
  };

  const currentStep = (steps[currentStepIndex] || {
    array: initialArray,
    i: 0,
    j: -1,
    key: initialArray[0],
    action: 'pick_key',
    description: 'Ready',
    sortedUpTo: 0,
    activeCodeLine: 0
  }) as InsertionStep;

  const maxVal = Math.max(...initialArray, 50);

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100 mb-6">
        <div>
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
            Insertion Sort Visualizer & VisuAlgo Code Tracer
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Progressively inserting key elements into the sorted subarray with active line tracking
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold px-2.5 py-1 bg-emerald-50 text-emerald-700 rounded-md border border-emerald-200">
            Step {currentStepIndex + 1} of {steps.length}
          </span>
        </div>
      </div>

      {/* Input controls */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3 mb-6 bg-slate-50 p-3 rounded-lg border border-slate-200">
        <div className="md:col-span-6 flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-700 whitespace-nowrap">Input Array:</label>
          <input
            type="text"
            value={inputStr}
            onChange={e => setInputStr(e.target.value)}
            placeholder="e.g. 12, 11, 13, 5, 6, 7, 28"
            className="w-full text-xs font-mono px-3 py-1.5 bg-white border border-slate-300 rounded focus:outline-none focus:ring-1 focus:ring-emerald-500"
          />
        </div>
        <div className="md:col-span-6 flex items-center gap-2 justify-end">
          <button
            onClick={handleApplyInput}
            className="px-3 py-1.5 bg-slate-800 text-white text-xs font-medium rounded hover:bg-slate-900 transition-colors cursor-pointer"
          >
            Apply Array
          </button>
          <button
            onClick={handleRandomize}
            className="px-3 py-1.5 bg-white border border-slate-300 text-slate-700 text-xs font-medium rounded hover:bg-slate-100 transition-colors flex items-center gap-1 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" /> Random
          </button>
        </div>
      </div>

      {/* Main Grid: Visualizer Canvas (Left) + VisuAlgo Code Panel (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-6 items-start">
        {/* Visualizer Canvas */}
        <div className="lg:col-span-7 bg-slate-950 rounded-xl p-6 text-white min-h-[340px] flex flex-col justify-between shadow-inner">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <span className="text-xs font-mono font-bold text-slate-400 uppercase">Array Elements</span>
            <span className="text-[11px] font-mono text-slate-400">
              Active Key: <span className="text-amber-400 font-bold">{currentStep.key}</span>
            </span>
          </div>

          {/* Bars */}
          <div className="flex items-end justify-center gap-3 sm:gap-4 h-52 pt-4 pb-2">
            {currentStep.array.map((val, idx) => {
              const heightPercent = Math.max((val / maxVal) * 100, 15);
              const isKey = currentStep.keyIndex === idx && currentStep.action === 'pick_key';
              const isComparing = currentStep.comparingIndices?.includes(idx);
              const isSorted = idx <= currentStep.sortedUpTo || currentStep.action === 'sorted';

              let barColor = 'bg-slate-700 text-slate-300';
              if (isKey) {
                barColor = 'bg-amber-400 text-slate-950 font-bold shadow-lg shadow-amber-400/50 scale-105';
              } else if (isComparing) {
                barColor = 'bg-indigo-400 text-white font-bold animate-pulse shadow-md';
              } else if (isSorted) {
                barColor = 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20';
              }

              return (
                <div key={idx} className="flex flex-col items-center gap-2 flex-1 max-w-[50px]">
                  <span className="text-xs font-mono font-bold">{val}</span>
                  <div
                    style={{ height: `${heightPercent}%` }}
                    className={`w-full rounded-t-md transition-all duration-300 flex items-end justify-center pb-1 ${barColor}`}
                  >
                    <span className="text-[10px] font-mono opacity-75">#{idx}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Legend */}
          <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-slate-400 pt-3 border-t border-slate-800">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-amber-400"></span> Active Key
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-indigo-400"></span> Shifting / Comparing
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-emerald-500"></span> Sorted Prefix
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-slate-700"></span> Unsorted
            </div>
          </div>
        </div>

        {/* VisuAlgo Code Panel */}
        <div className="lg:col-span-5">
          <VisuAlgoCodePanel
            title="Insertion Sort"
            explanation={currentStep.description}
            codeLines={ALGORITHM_CODES.insertionSort.lines}
            activeLineIndex={currentStep.activeCodeLine}
            stepInfo={{ current: currentStepIndex + 1, total: steps.length }}
          />
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-slate-100">
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setIsPlaying(false);
              setCurrentStepIndex(0);
            }}
            className="p-2 border border-slate-300 rounded-lg hover:bg-slate-100 text-slate-700 text-sm font-medium flex items-center gap-1.5 cursor-pointer"
            title="Reset Simulation"
          >
            <RotateCcw className="w-4 h-4" /> Reset
          </button>

          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className={`px-4 py-2 rounded-lg font-medium text-sm flex items-center gap-2 transition-colors cursor-pointer ${
              isPlaying
                ? 'bg-amber-600 hover:bg-amber-700 text-white'
                : 'bg-emerald-700 hover:bg-emerald-800 text-white'
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4" /> Pause
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" /> Auto Play
              </>
            )}
          </button>

          <button
            onClick={() => {
              setIsPlaying(false);
              setCurrentStepIndex(prev => Math.min(prev + 1, steps.length - 1));
            }}
            disabled={currentStepIndex >= steps.length - 1}
            className="px-3.5 py-2 border border-slate-300 bg-white rounded-lg hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed text-slate-700 text-sm font-medium flex items-center gap-1.5 cursor-pointer"
          >
            <SkipForward className="w-4 h-4" /> Next Step
          </button>
        </div>

        <div className="flex items-center gap-3">
          <label className="text-xs font-semibold text-slate-600">Speed:</label>
          <select
            value={speed}
            onChange={e => setSpeed(Number(e.target.value))}
            className="text-xs bg-white border border-slate-300 rounded px-2.5 py-1.5 font-medium text-slate-700 focus:outline-none"
          >
            <option value={1500}>0.75x (Slow)</option>
            <option value={1000}>1.0x (Normal)</option>
            <option value={500}>2.0x (Fast)</option>
          </select>
        </div>
      </div>
    </div>
  );
};
