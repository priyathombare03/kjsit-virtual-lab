import { LabExperiment } from '../../../types';
import { ALGORITHM_CODES } from './algorithmCodes';

export interface TraceStep {
  stepNumber: number;
  activeLineIndex: number;
  explanation: string;
  variables?: Record<string, string | number | boolean>;
  stateSnapshot?: {
    label: string;
    items: (string | number)[];
    highlightIndex?: number;
    secondaryHighlight?: number;
  };
  outputLine?: string;
}

export interface TracePlan {
  title: string;
  language: string;
  availableLanguages: { id: string; name: string }[];
  codeLines: string[];
  steps: TraceStep[];
  defaultInput?: string;
  expectedOutput?: string;
}

// Curated specialized trace plans for major lab experiments across subjects
const CURATED_TRACES: Record<string, {
  title: string;
  codeLines: string[];
  steps: TraceStep[];
}> = {
  // DSA - Stack
  'stack': {
    title: 'Stack ADT Operations',
    codeLines: [
      'push(element):',
      '  if top >= MAX_CAPACITY - 1: return OVERFLOW',
      '  top = top + 1',
      '  stack[top] = element',
      'pop():',
      '  if top < 0: return UNDERFLOW',
      '  val = stack[top]; top = top - 1',
      '  return val',
      'peek():',
      '  if top < 0: return NULL',
      '  return stack[top]'
    ],
    steps: [
      {
        stepNumber: 1,
        activeLineIndex: 0,
        explanation: 'Initialized Stack with 3 elements: [10, 25, 40], TOP = 2.',
        variables: { top: 2, capacity: 6, status: 'READY' },
        stateSnapshot: { label: 'Stack Buffer', items: [10, 25, 40], highlightIndex: 2 },
        outputLine: '[INIT] Stack created with capacity 6. Current size = 3.'
      },
      {
        stepNumber: 2,
        activeLineIndex: 1,
        explanation: 'Evaluating PUSH(55): Checking condition (top >= MAX_CAPACITY - 1) -> 2 >= 5 is FALSE.',
        variables: { top: 2, element: 55, condition: 'FALSE' },
        stateSnapshot: { label: 'Stack Buffer', items: [10, 25, 40], highlightIndex: 2 },
        outputLine: '[CHECK] Capacity check passed: top (2) < MAX (5).'
      },
      {
        stepNumber: 3,
        activeLineIndex: 2,
        explanation: 'Incrementing stack pointer: top = top + 1 -> new TOP is 3.',
        variables: { top: 3, element: 55 },
        stateSnapshot: { label: 'Stack Buffer', items: [10, 25, 40, '...'], highlightIndex: 3 },
        outputLine: '[POINTER] Stack top incremented to index 3.'
      },
      {
        stepNumber: 4,
        activeLineIndex: 3,
        explanation: 'Assigning element: stack[top] = 55. Element 55 is stored at index 3.',
        variables: { top: 3, 'stack[3]': 55, element: 55 },
        stateSnapshot: { label: 'Stack Buffer', items: [10, 25, 40, 55], highlightIndex: 3 },
        outputLine: '[PUSH] Value 55 pushed onto stack successfully.'
      },
      {
        stepNumber: 5,
        activeLineIndex: 8,
        explanation: 'Executing PEEK(): Checking top element at index 3 -> stack[3] == 55.',
        variables: { top: 3, peekVal: 55 },
        stateSnapshot: { label: 'Stack Buffer', items: [10, 25, 40, 55], highlightIndex: 3 },
        outputLine: '[PEEK] Current top of stack is 55.'
      },
      {
        stepNumber: 6,
        activeLineIndex: 4,
        explanation: 'Initiating POP() operation to remove the most recently added item.',
        variables: { top: 3 },
        stateSnapshot: { label: 'Stack Buffer', items: [10, 25, 40, 55], highlightIndex: 3 },
        outputLine: '[POP] Starting pop routine.'
      },
      {
        stepNumber: 7,
        activeLineIndex: 5,
        explanation: 'Checking underflow condition: (top < 0) -> (3 < 0) is FALSE. Stack is not empty.',
        variables: { top: 3, condition: 'FALSE' },
        stateSnapshot: { label: 'Stack Buffer', items: [10, 25, 40, 55], highlightIndex: 3 },
        outputLine: '[CHECK] Underflow check passed.'
      },
      {
        stepNumber: 8,
        activeLineIndex: 6,
        explanation: 'Extracting top value val = 55 and decrementing stack pointer: top = top - 1 -> TOP is 2.',
        variables: { top: 2, val: 55 },
        stateSnapshot: { label: 'Stack Buffer', items: [10, 25, 40], highlightIndex: 2 },
        outputLine: '[POP] Extracted value: 55. Decremented TOP to 2.'
      },
      {
        stepNumber: 9,
        activeLineIndex: 7,
        explanation: 'Returning popped value 55 to caller. LIFO integrity maintained.',
        variables: { returnVal: 55, top: 2, count: 3 },
        stateSnapshot: { label: 'Stack Buffer', items: [10, 25, 40], highlightIndex: 2 },
        outputLine: '[COMPLETE] POP returned 55. Active stack: [10, 25, 40].'
      }
    ]
  },

  // DSA - Queue
  'queue': {
    title: 'Linear & Circular Queue ADT',
    codeLines: [
      'enqueue(item):',
      '  if (rear + 1) % MAX == front: return QUEUE_OVERFLOW',
      '  if front == -1: front = 0',
      '  rear = (rear + 1) % MAX',
      '  queue[rear] = item',
      'dequeue():',
      '  if front == -1: return QUEUE_UNDERFLOW',
      '  val = queue[front]',
      '  if front == rear: front = -1; rear = -1',
      '  else: front = (front + 1) % MAX',
      '  return val'
    ],
    steps: [
      {
        stepNumber: 1,
        activeLineIndex: 0,
        explanation: 'Queue initialized: front = -1, rear = -1, MAX_SIZE = 5.',
        variables: { front: -1, rear: -1, MAX: 5 },
        stateSnapshot: { label: 'Queue Buffer', items: [] },
        outputLine: '[INIT] Circular Queue buffer allocated.'
      },
      {
        stepNumber: 2,
        activeLineIndex: 1,
        explanation: 'ENQUEUE(15): Checking full condition ((rear + 1) % MAX == front) -> FALSE.',
        variables: { item: 15, isFull: false },
        stateSnapshot: { label: 'Queue Buffer', items: [] },
        outputLine: '[CHECK] Queue is not full.'
      },
      {
        stepNumber: 3,
        activeLineIndex: 2,
        explanation: 'Queue was empty (front == -1): Setting front = 0.',
        variables: { front: 0, rear: -1, item: 15 },
        stateSnapshot: { label: 'Queue Buffer', items: [] },
        outputLine: '[POINTER] First item inserted: set front = 0.'
      },
      {
        stepNumber: 4,
        activeLineIndex: 3,
        explanation: 'Advancing rear index: rear = (rear + 1) % 5 -> rear = 0.',
        variables: { front: 0, rear: 0, item: 15 },
        stateSnapshot: { label: 'Queue Buffer', items: [15], highlightIndex: 0 },
        outputLine: '[POINTER] rear pointer moved to index 0.'
      },
      {
        stepNumber: 5,
        activeLineIndex: 4,
        explanation: 'Writing element into buffer: queue[0] = 15.',
        variables: { front: 0, rear: 0, 'queue[0]': 15 },
        stateSnapshot: { label: 'Queue Buffer', items: [15], highlightIndex: 0 },
        outputLine: '[ENQUEUE] Value 15 inserted at rear (0).'
      },
      {
        stepNumber: 6,
        activeLineIndex: 4,
        explanation: 'ENQUEUE(30): Incrementing rear to 1, writing queue[1] = 30.',
        variables: { front: 0, rear: 1, 'queue[1]': 30 },
        stateSnapshot: { label: 'Queue Buffer', items: [15, 30], highlightIndex: 1 },
        outputLine: '[ENQUEUE] Value 30 inserted at rear (1).'
      },
      {
        stepNumber: 7,
        activeLineIndex: 5,
        explanation: 'Initiating DEQUEUE() to remove item from front of queue.',
        variables: { front: 0, rear: 1 },
        stateSnapshot: { label: 'Queue Buffer', items: [15, 30], highlightIndex: 0 },
        outputLine: '[DEQUEUE] Processing dequeue from front.'
      },
      {
        stepNumber: 8,
        activeLineIndex: 7,
        explanation: 'Extracting front element: val = queue[0] -> val = 15.',
        variables: { val: 15, front: 0, rear: 1 },
        stateSnapshot: { label: 'Queue Buffer', items: [15, 30], highlightIndex: 0 },
        outputLine: '[DEQUEUE] Read value 15 from index 0.'
      },
      {
        stepNumber: 9,
        activeLineIndex: 9,
        explanation: 'Advancing front pointer: front = (0 + 1) % 5 -> front is 1.',
        variables: { front: 1, rear: 1, remaining: 1 },
        stateSnapshot: { label: 'Queue Buffer', items: [30], highlightIndex: 0 },
        outputLine: '[POINTER] front moved to 1. FIFO ordering confirmed.'
      }
    ]
  },

  // DSA - Singly Linked List
  'linked-list': {
    title: 'Singly Linked List Operations',
    codeLines: [
      'insert_node(data):',
      '  newNode = createNode(data)',
      '  if head == NULL: head = newNode; return',
      '  temp = head',
      '  while temp.next != NULL: temp = temp.next',
      '  temp.next = newNode',
      'delete_node(key):',
      '  if head.data == key: head = head.next; return',
      '  prev = head; curr = head.next',
      '  while curr != NULL and curr.data != key:',
      '    prev = curr; curr = curr.next',
      '  if curr != NULL: prev.next = curr.next'
    ],
    steps: [
      {
        stepNumber: 1,
        activeLineIndex: 0,
        explanation: 'Calling insert_node(42): Allocating new node in heap memory.',
        variables: { data: 42, head: '0x1000' },
        stateSnapshot: { label: 'List Nodes', items: ['[10]->', '[25]->', '[NULL]'] },
        outputLine: '[ALLOC] Allocated new Node with data = 42.'
      },
      {
        stepNumber: 2,
        activeLineIndex: 2,
        explanation: 'Checking if list is empty (head == NULL) -> FALSE (list has nodes).',
        variables: { head: '0x1000', empty: false },
        stateSnapshot: { label: 'List Nodes', items: ['[10]->', '[25]->', '[NULL]'], highlightIndex: 0 },
        outputLine: '[CHECK] Head is valid, traversing to tail.'
      },
      {
        stepNumber: 3,
        activeLineIndex: 3,
        explanation: 'Initializing traversal pointer: temp = head (pointing to Node 10).',
        variables: { temp: 'Node(10)', data: 10 },
        stateSnapshot: { label: 'List Nodes', items: ['[10]*', '[25]->', '[NULL]'], highlightIndex: 0 },
        outputLine: '[TRAVERSE] temp positioned at Head.'
      },
      {
        stepNumber: 4,
        activeLineIndex: 4,
        explanation: 'Advancing temp: temp.next != NULL -> temp moves to Node 25.',
        variables: { temp: 'Node(25)', data: 25 },
        stateSnapshot: { label: 'List Nodes', items: ['[10]->', '[25]*', '[NULL]'], highlightIndex: 1 },
        outputLine: '[TRAVERSE] temp reached tail node (25.next == NULL).'
      },
      {
        stepNumber: 5,
        activeLineIndex: 5,
        explanation: 'Linking new node: temp.next = newNode (Node 25 now links to Node 42).',
        variables: { 'temp.next': 'Node(42)', tail: 42 },
        stateSnapshot: { label: 'List Nodes', items: ['[10]->', '[25]->', '[42]->', '[NULL]'], highlightIndex: 2 },
        outputLine: '[INSERT] Node(42) appended to tail. List size = 3.'
      }
    ]
  },

  // DSA - Binary Search Tree
  'bst': {
    title: 'Binary Search Tree Operations',
    codeLines: [
      'insert(root, key):',
      '  if root == NULL: return createNode(key)',
      '  if key < root.key:',
      '    root.left = insert(root.left, key)',
      '  else if key > root.key:',
      '    root.right = insert(root.right, key)',
      '  return root',
      'inorder_traversal(root):',
      '  if root != NULL:',
      '    inorder(root.left)',
      '    print(root.key)',
      '    inorder(root.right)'
    ],
    steps: [
      {
        stepNumber: 1,
        activeLineIndex: 0,
        explanation: 'BST insertion request: key = 35. Root currently holds 50.',
        variables: { key: 35, root: 50 },
        stateSnapshot: { label: 'BST Subtree', items: ['(50)', 'Left: (30)', 'Right: (70)'], highlightIndex: 0 },
        outputLine: '[BST] Comparing key 35 with root 50.'
      },
      {
        stepNumber: 2,
        activeLineIndex: 2,
        explanation: 'Evaluating (key < root.key): 35 < 50 is TRUE -> Branching LEFT.',
        variables: { key: 35, branch: 'LEFT' },
        stateSnapshot: { label: 'BST Subtree', items: ['(50)', 'Left: (30)', 'Right: (70)'], highlightIndex: 1 },
        outputLine: '[BRANCH] 35 < 50: Moving to left child (30).'
      },
      {
        stepNumber: 3,
        activeLineIndex: 4,
        explanation: 'Comparing with child 30: 35 > 30 is TRUE -> Branching RIGHT of 30.',
        variables: { current: 30, key: 35, branch: 'RIGHT' },
        stateSnapshot: { label: 'BST Subtree', items: ['(30)', 'Left: NULL', 'Right: NULL'], highlightIndex: 0 },
        outputLine: '[BRANCH] 35 > 30: Moving to right child of 30.'
      },
      {
        stepNumber: 4,
        activeLineIndex: 1,
        explanation: 'Right child of 30 is NULL: Creating new Node(35).',
        variables: { parent: 30, inserted: 35 },
        stateSnapshot: { label: 'BST Subtree', items: ['(30)', 'Left: NULL', 'Right: (35)*'], highlightIndex: 2 },
        outputLine: '[INSERT] Node(35) successfully attached as right child of Node(30).'
      },
      {
        stepNumber: 5,
        activeLineIndex: 7,
        explanation: 'Executing In-Order Traversal: In-order visits nodes in strictly sorted ascending order.',
        variables: { order: 'ASCENDING' },
        stateSnapshot: { label: 'Sorted Keys', items: [20, 30, 35, 50, 70, 85] },
        outputLine: '[TRAVERSE] Inorder Output: 20 -> 30 -> 35 -> 50 -> 70 -> 85.'
      }
    ]
  },

  // DBMS - DDL & Table Constraints
  'dbms-ddl': {
    title: 'SQL DDL & Integrity Constraints Execution',
    codeLines: [
      'CREATE TABLE Department (',
      '  dept_id INT PRIMARY KEY,',
      '  dept_name VARCHAR(100) NOT NULL UNIQUE',
      ');',
      'CREATE TABLE Student (',
      '  student_id INT PRIMARY KEY,',
      '  name VARCHAR(100) NOT NULL,',
      '  dept_id INT REFERENCES Department(dept_id),',
      '  cgpa NUMERIC(3,2) CHECK (cgpa BETWEEN 0.0 AND 10.0)',
      ');',
      'ALTER TABLE Student ADD CONSTRAINT chk_active CHECK (is_active IN (0,1));'
    ],
    steps: [
      {
        stepNumber: 1,
        activeLineIndex: 0,
        explanation: 'Parsing DDL statement: CREATE TABLE Department with PRIMARY KEY and UNIQUE constraints.',
        variables: { table: 'Department', engine: 'PostgreSQL/MySQL' },
        stateSnapshot: { label: 'Catalog Tables', items: ['Information_Schema'] },
        outputLine: '[DDL] Parsing relational schema for Department...'
      },
      {
        stepNumber: 2,
        activeLineIndex: 1,
        explanation: 'Allocating B-Tree index for PRIMARY KEY (dept_id). Enforcing NOT NULL + UNIQUE.',
        variables: { pk_col: 'dept_id', index_type: 'BTREE' },
        stateSnapshot: { label: 'Catalog Tables', items: ['Department (dept_id PK, dept_name UNIQUE)'] },
        outputLine: '[INDEX] Created primary key btree index on dept_id.'
      },
      {
        stepNumber: 3,
        activeLineIndex: 4,
        explanation: 'Creating Student table with Foreign Key constraint referencing Department(dept_id).',
        variables: { table: 'Student', fk: 'Department(dept_id)' },
        stateSnapshot: { label: 'Catalog Tables', items: ['Department', 'Student (Pending FK)'] },
        outputLine: '[DDL] Creating table Student...'
      },
      {
        stepNumber: 4,
        activeLineIndex: 7,
        explanation: 'Validating Referential Integrity: Verifying parent table Department exists in catalog.',
        variables: { parent_table: 'Department', fk_verified: true },
        stateSnapshot: { label: 'Catalog Tables', items: ['Department (Parent)', 'Student (Child FK)'] },
        outputLine: '[FK] Foreign key constraint verified and linked.'
      },
      {
        stepNumber: 5,
        activeLineIndex: 8,
        explanation: 'Attaching Domain Check Constraint: cgpa must strictly lie within 0.00 and 10.00.',
        variables: { constraint: 'chk_cgpa', min: 0.0, max: 10.0 },
        stateSnapshot: { label: 'Active Constraints', items: ['PK_student', 'FK_dept', 'CHK_cgpa'] },
        outputLine: '[CONSTRAINT] Domain check attached. DDL execution finished with 0 errors.'
      }
    ]
  },

  // DBMS - SQL Joins
  'dbms-joins': {
    title: 'Relational SQL Joins Execution Engine',
    codeLines: [
      'SELECT s.name, s.cgpa, d.dept_name',
      'FROM Student s',
      'INNER JOIN Department d ON s.dept_id = d.dept_id',
      'WHERE s.cgpa >= 8.5',
      'ORDER BY s.cgpa DESC;'
    ],
    steps: [
      {
        stepNumber: 1,
        activeLineIndex: 1,
        explanation: 'FROM Clause: Loading relations Student (s) and Department (d) into memory buffer.',
        variables: { student_rows: 4, dept_rows: 3 },
        stateSnapshot: { label: 'Joined Rows', items: ['Loading tables into scan buffer...'] },
        outputLine: '[SCAN] Sequential scan initiated on Student (4 rows) and Department (3 rows).'
      },
      {
        stepNumber: 2,
        activeLineIndex: 2,
        explanation: 'INNER JOIN: Hash Join evaluated on condition s.dept_id == d.dept_id.',
        variables: { join_method: 'HASH_JOIN', matches_found: 3 },
        stateSnapshot: { label: 'Matched Records', items: ['(101, Priya, AI&DS)', '(102, Rahul, Comps)', '(103, Sneha, IT)'] },
        outputLine: '[JOIN] Matched 3 tuples on equality condition (s.dept_id = d.dept_id).'
      },
      {
        stepNumber: 3,
        activeLineIndex: 3,
        explanation: 'WHERE Filter: Filtering tuples matching predicate (cgpa >= 8.5).',
        variables: { predicate: 'cgpa >= 8.5', passed: 2, filtered_out: 1 },
        stateSnapshot: { label: 'Filtered Tuples', items: ['Priya (9.42, AI&DS)', 'Sneha (8.90, IT)'] },
        outputLine: '[FILTER] Rahul (7.80) eliminated by WHERE filter. 2 tuples retained.'
      },
      {
        stepNumber: 4,
        activeLineIndex: 4,
        explanation: 'ORDER BY: Sorting result set by s.cgpa in descending order.',
        variables: { sort_key: 'cgpa', direction: 'DESC' },
        stateSnapshot: { label: 'Sorted Output', items: ['1: Priya (9.42)', '2: Sneha (8.90)'] },
        outputLine: '[SORT] QuickSort on cgpa DESC completed.'
      },
      {
        stepNumber: 5,
        activeLineIndex: 0,
        explanation: 'SELECT Projection: Projecting columns (name, cgpa, dept_name). Result set delivered.',
        variables: { returned_rows: 2, columns: 3 },
        stateSnapshot: { label: 'Final Result Set', items: ['Priya | 9.42 | AI&DS', 'Sneha | 8.90 | IT'] },
        outputLine: '[QUERY COMPLETE] 2 rows in set (0.002 sec).'
      }
    ]
  },

  // OS - CPU Scheduling (FCFS / Round Robin)
  'os-cpu-scheduling': {
    title: 'CPU Scheduling Execution Tracer',
    codeLines: [
      'schedule_processes(queue):',
      '  sort queue by arrival_time ascending',
      '  currentTime = 0',
      '  for each p in queue:',
      '    if currentTime < p.arrival: currentTime = p.arrival',
      '    p.startTime = currentTime',
      '    p.waitingTime = currentTime - p.arrival',
      '    currentTime += p.burstTime',
      '    p.turnaroundTime = currentTime - p.arrival',
      '  calculate_averages(waitingTimes, turnaroundTimes)'
    ],
    steps: [
      {
        stepNumber: 1,
        activeLineIndex: 1,
        explanation: 'Scheduling dispatcher ready: 3 processes [P1: AT=0 BT=5], [P2: AT=1 BT=3], [P3: AT=2 BT=8].',
        variables: { ready_queue: 'P1, P2, P3', count: 3 },
        stateSnapshot: { label: 'Gantt Chart', items: ['Ready Queue: P1, P2, P3'] },
        outputLine: '[INIT] Loaded process control blocks (PCBs) into Ready Queue.'
      },
      {
        stepNumber: 2,
        activeLineIndex: 3,
        explanation: 'Dispatching P1: Arrival = 0, Burst = 5. CPU allocated to P1 at t = 0.',
        variables: { running_pid: 'P1', current_time: 0, burst: 5 },
        stateSnapshot: { label: 'Gantt Chart', items: ['[0-- P1 --5]'] },
        outputLine: '[DISPATCH] P1 entered CPU at time 0.'
      },
      {
        stepNumber: 3,
        activeLineIndex: 6,
        explanation: 'P1 waiting time = 0 - 0 = 0 ms. CPU executing P1 burst of 5 ms.',
        variables: { 'P1.wait': 0, 'P1.turnaround': 5, current_time: 5 },
        stateSnapshot: { label: 'Gantt Chart', items: ['[0-- P1 --5] (Done)'] },
        outputLine: '[BURST] P1 finished execution at t = 5. Turnaround = 5ms.'
      },
      {
        stepNumber: 4,
        activeLineIndex: 3,
        explanation: 'Context Switching: Dispatching P2 at t = 5. Arrival was 1, Wait = 5 - 1 = 4 ms.',
        variables: { running_pid: 'P2', 'P2.wait': 4, current_time: 5, burst: 3 },
        stateSnapshot: { label: 'Gantt Chart', items: ['[0-- P1 --5]', '[5-- P2 --8]'] },
        outputLine: '[DISPATCH] P2 entered CPU at time 5. Waiting time = 4ms.'
      },
      {
        stepNumber: 5,
        activeLineIndex: 7,
        explanation: 'P2 completed at t = 8. Turnaround = 8 - 1 = 7 ms. Dispatching P3.',
        variables: { 'P2.turnaround': 7, current_time: 8, running_pid: 'P3' },
        stateSnapshot: { label: 'Gantt Chart', items: ['[0-- P1 --5]', '[5-- P2 --8]', '[8-- P3 --16]'] },
        outputLine: '[DISPATCH] P3 entered CPU at time 8. Burst = 8ms.'
      },
      {
        stepNumber: 6,
        activeLineIndex: 9,
        explanation: 'All processes finished. Avg Waiting Time = (0 + 4 + 6)/3 = 3.33 ms. Avg Turnaround = 9.33 ms.',
        variables: { avg_wait: '3.33 ms', avg_tat: '9.33 ms', cpu_util: '100%' },
        stateSnapshot: { label: 'Final Metrics', items: ['P1: WT=0, TAT=5', 'P2: WT=4, TAT=7', 'P3: WT=6, TAT=14'] },
        outputLine: '[METRICS] Schedule Complete. Average Waiting Time: 3.33ms.'
      }
    ]
  },

  // ML / AIML - Linear Regression Gradient Descent
  'ml-gradient-descent': {
    title: 'Linear Regression Gradient Descent Execution',
    codeLines: [
      'gradient_descent(X, y, lr, epochs):',
      '  w = 0.0; b = 0.0; m = len(y)',
      '  for epoch in range(epochs):',
      '    y_pred = w * X + b',
      '    error = y_pred - y',
      '    dw = (2/m) * sum(error * X)',
      '    db = (2/m) * sum(error)',
      '    w = w - lr * dw',
      '    b = b - lr * db',
      '    loss = (1/m) * sum(error ** 2)',
      '  return w, b'
    ],
    steps: [
      {
        stepNumber: 1,
        activeLineIndex: 1,
        explanation: 'Model Initialization: Initializing weight w = 0.0, bias b = 0.0, learning_rate = 0.01.',
        variables: { w: 0.0, b: 0.0, lr: 0.01, samples: 100 },
        stateSnapshot: { label: 'Model Weights', items: ['w: 0.000', 'b: 0.000', 'Epoch: 0'] },
        outputLine: '[INIT] Hyperparameters: lr = 0.01, epochs = 100, samples = 100.'
      },
      {
        stepNumber: 2,
        activeLineIndex: 3,
        explanation: 'Forward Pass (Epoch 1): Calculating predictions y_pred = w*X + b.',
        variables: { epoch: 1, w: 0.0, b: 0.0 },
        stateSnapshot: { label: 'Forward Pass', items: ['Predictions: [0.0, 0.0, 0.0...]', 'MSE Loss: 42.50'] },
        outputLine: '[FORWARD] Forward computation generated baseline predictions.'
      },
      {
        stepNumber: 3,
        activeLineIndex: 5,
        explanation: 'Computing Gradients: dw = (2/m)*sum((y_pred - y)*X) -> dw = -14.20.',
        variables: { dw: -14.20, db: -4.80 },
        stateSnapshot: { label: 'Gradients', items: ['dw: -14.200', 'db: -4.800'] },
        outputLine: '[GRADIENT] Loss derivative with respect to w: -14.20.'
      },
      {
        stepNumber: 4,
        activeLineIndex: 7,
        explanation: 'Backpropagation Update: w = w - lr*dw -> w = 0 - (0.01)*(-14.20) = 0.142.',
        variables: { 'w_new': 0.142, 'b_new': 0.048, epoch: 1 },
        stateSnapshot: { label: 'Model Weights', items: ['w: 0.142', 'b: 0.048', 'Loss: 38.10'] },
        outputLine: '[UPDATE] Weights adjusted via gradient descent.'
      },
      {
        stepNumber: 5,
        activeLineIndex: 9,
        explanation: 'Epoch 100 converged: Optimal slope w = 2.45, intercept b = 1.10. Loss minimized to 0.021.',
        variables: { w_final: 2.45, b_final: 1.10, min_loss: 0.021, r2_score: 0.985 },
        stateSnapshot: { label: 'Final Model', items: ['w: 2.450', 'b: 1.100', 'R²: 0.985'] },
        outputLine: '[CONVERGED] Optimal line: y = 2.45 * x + 1.10. R² Score: 0.985.'
      }
    ]
  },

  // DAA - Fractional Knapsack (Greedy)
  'fractional-knapsack': {
    title: 'Fractional Knapsack (Greedy Approach)',
    codeLines: [
      'calculate_ratios(items):',
      '  for each item: ratio = item.profit / item.weight',
      '  sort items descending by ratio',
      'greedy_knapsack(items, capacity):',
      '  totalProfit = 0; remainingCap = capacity',
      '  for each item in sortedItems:',
      '    if remainingCap >= item.weight:',
      '      take 100% item; remainingCap -= item.weight',
      '      totalProfit += item.profit',
      '    else:',
      '      fraction = remainingCap / item.weight',
      '      totalProfit += fraction * item.profit',
      '      remainingCap = 0; break // knapsack full',
      '  return totalProfit'
    ],
    steps: [
      {
        stepNumber: 1,
        activeLineIndex: 1,
        explanation: 'Computing profit-to-weight ratios: Item 1: 60/10=6.0, Item 2: 100/20=5.0, Item 3: 120/30=4.0. Knapsack capacity W = 50 kg.',
        variables: { capacity: 50, item1_ratio: 6.0, item2_ratio: 5.0, item3_ratio: 4.0 },
        stateSnapshot: { label: 'Item Ratios', items: ['Item 1 (r=6.0)', 'Item 2 (r=5.0)', 'Item 3 (r=4.0)'] },
        outputLine: '[INIT] Items sorted by efficiency ratio: Item 1 (6.0), Item 2 (5.0), Item 3 (4.0).'
      },
      {
        stepNumber: 2,
        activeLineIndex: 6,
        explanation: 'Greedy Choice 1: Examining Item 1 (wt: 10kg, profit: ₹60). Remaining capacity (50) >= weight (10) -> Take whole item.',
        variables: { taken: '100% Item 1', remainingCap: 40, totalProfit: 60 },
        stateSnapshot: { label: 'Knapsack Load', items: ['[Item 1: 10kg, ₹60]'] },
        outputLine: '[TAKE] Loaded 100% of Item 1. Remaining capacity = 40 kg. Total profit = ₹60.'
      },
      {
        stepNumber: 3,
        activeLineIndex: 6,
        explanation: 'Greedy Choice 2: Examining Item 2 (wt: 20kg, profit: ₹100). Remaining capacity (40) >= weight (20) -> Take whole item.',
        variables: { taken: '100% Item 2', remainingCap: 20, totalProfit: 160 },
        stateSnapshot: { label: 'Knapsack Load', items: ['[Item 1: 10kg, ₹60]', '[Item 2: 20kg, ₹100]'] },
        outputLine: '[TAKE] Loaded 100% of Item 2. Remaining capacity = 20 kg. Total profit = ₹160.'
      },
      {
        stepNumber: 4,
        activeLineIndex: 9,
        explanation: 'Greedy Choice 3: Examining Item 3 (wt: 30kg, profit: ₹120). Remaining capacity (20) < weight (30) -> Take fraction 20/30 = 0.67.',
        variables: { fraction: '2/3 (66.7%)', addedProfit: 80, totalProfit: 240, remainingCap: 0 },
        stateSnapshot: { label: 'Knapsack Load', items: ['[Item 1: 10kg]', '[Item 2: 20kg]', '[Item 3: 20/30 (66.7%)]'] },
        outputLine: '[FRACTION] Loaded 20/30 fraction of Item 3 (+₹80). Knapsack capacity full (50 kg).'
      },
      {
        stepNumber: 5,
        activeLineIndex: 13,
        explanation: 'Optimization Complete: Maximum optimal profit = ₹240. Total weight loaded = 50 kg.',
        variables: { maxProfit: 240, totalWeight: 50, efficiency: '100% (Optimal)' },
        stateSnapshot: { label: 'Final Knapsack', items: ['Total Weight: 50/50 kg', 'Total Value: ₹240.00'] },
        outputLine: '[RESULT] Greedy Fractional Knapsack optimal profit = ₹240.'
      }
    ]
  },

  // DAA - 0/1 Knapsack (Dynamic Programming)
  '01-knapsack': {
    title: '0/1 Knapsack (Dynamic Programming)',
    codeLines: [
      'knapsack_01(weights, values, W, n):',
      '  initialize DP[n + 1][W + 1] with 0',
      '  for i = 1 to n:',
      '    for w = 0 to W:',
      '      if weights[i - 1] <= w:',
      '        DP[i][w] = max(values[i-1] + DP[i-1][w - weights[i-1]], DP[i-1][w])',
      '      else:',
      '        DP[i][w] = DP[i-1][w]',
      '  return DP[n][W]'
    ],
    steps: [
      {
        stepNumber: 1,
        activeLineIndex: 1,
        explanation: 'Initializing DP table of size (4 x 8) with all 0s. Items: (wt:2, val:3), (wt:3, val:4), (wt:4, val:5), Capacity W = 7.',
        variables: { n: 3, capacity: 7, table_size: '4x8' },
        stateSnapshot: { label: 'DP Table Row 0', items: ['DP[0][0..7] = 0'] },
        outputLine: '[INIT] DP Table initialized for 3 items and capacity 7.'
      },
      {
        stepNumber: 2,
        activeLineIndex: 4,
        explanation: 'Item 1 (wt: 2, val: 3): For w >= 2, DP[1][w] = max(3 + DP[0][w-2], DP[0][w]) = 3.',
        variables: { item: 1, wt: 2, val: 3, 'DP[1][7]': 3 },
        stateSnapshot: { label: 'DP Table Row 1', items: ['w<2: 0', 'w>=2: 3'] },
        outputLine: '[DP STEP] Row 1 computed: Max value with Item 1 = 3.'
      },
      {
        stepNumber: 3,
        activeLineIndex: 5,
        explanation: 'Item 2 (wt: 3, val: 4): For w = 5, DP[2][5] = max(4 + DP[1][2], DP[1][5]) = max(4 + 3, 3) = 7.',
        variables: { item: 2, wt: 3, val: 4, 'DP[2][5]': 7 },
        stateSnapshot: { label: 'DP Table Row 2', items: ['DP[2][3]=4', 'DP[2][5]=7', 'DP[2][7]=7'] },
        outputLine: '[DP STEP] Row 2 computed: Combining Item 1 and Item 2 yields value 7 at w=5.'
      },
      {
        stepNumber: 4,
        activeLineIndex: 5,
        explanation: 'Item 3 (wt: 4, val: 5): For w = 7, DP[3][7] = max(5 + DP[2][3], DP[2][7]) = max(5 + 4, 7) = 9.',
        variables: { item: 3, wt: 4, val: 5, 'DP[3][7]': 9 },
        stateSnapshot: { label: 'DP Table Row 3', items: ['DP[3][6]=8', 'DP[3][7]=9'] },
        outputLine: '[DP STEP] Optimal cell computed: DP[3][7] = 9.'
      },
      {
        stepNumber: 5,
        activeLineIndex: 8,
        explanation: 'Backtracking optimal subset: Items 2 (wt:3, val:4) and 3 (wt:4, val:5) chosen. Total Weight = 7, Optimal Value = 9.',
        variables: { optimalValue: 9, chosenItems: 'Item 2, Item 3', totalWeight: 7 },
        stateSnapshot: { label: 'Optimal Subset', items: ['Item 2 (wt:3, val:4)', 'Item 3 (wt:4, val:5)'] },
        outputLine: '[RESULT] 0/1 Knapsack optimal value = 9. Total weight = 7 kg.'
      }
    ]
  },

  // DAA - Travelling Salesperson Problem (Branch & Bound)
  'tsp': {
    title: 'Travelling Salesperson Problem (Branch & Bound)',
    codeLines: [
      'tsp_branch_and_bound(adjMatrix):',
      '  bound = calculate_initial_lower_bound(adjMatrix)',
      '  visited = [startCity]; minCost = INFINITY',
      '  priorityQueue.push(RootNode(visited, bound))',
      '  while not priorityQueue.isEmpty():',
      '    curr = priorityQueue.pop()',
      '    if curr.bound < minCost:',
      '      for each unvisited city v:',
      '        newBound = update_bound(curr, v)',
      '        if isCompleteTour(curr + v):',
      '          minCost = min(minCost, tourCost)',
      '  return minCost, optimalTour'
    ],
    steps: [
      {
        stepNumber: 1,
        activeLineIndex: 1,
        explanation: 'Calculating initial reduced cost matrix bound. Starting city: 0 (Mumbai). Initial lower bound = 64.',
        variables: { start: 'Mumbai (0)', initial_bound: 64, unvisited: 'Pune, Nashik, Surat, Goa' },
        stateSnapshot: { label: 'Active Tour', items: ['[0: Mumbai]'] },
        outputLine: '[INIT] Root node created. Initial matrix lower bound = 64.'
      },
      {
        stepNumber: 2,
        activeLineIndex: 6,
        explanation: 'Branching from Mumbai (0) -> Pune (1): Path cost = 10, updated lower bound = 68.',
        variables: { current: 'Pune (1)', stepCost: 10, bound: 68 },
        stateSnapshot: { label: 'Active Tour', items: ['Mumbai (0) -> Pune (1)'] },
        outputLine: '[BRANCH] Explored edge (0 -> 1). Lower bound = 68.'
      },
      {
        stepNumber: 3,
        activeLineIndex: 7,
        explanation: 'Branching from Pune (1) -> Goa (4): Edge cost = 12. Path: 0 -> 1 -> 4. Updated bound = 70.',
        variables: { current: 'Goa (4)', stepCost: 12, bound: 70 },
        stateSnapshot: { label: 'Active Tour', items: ['Mumbai -> Pune -> Goa'] },
        outputLine: '[BRANCH] Visited Goa (4). Cumulative path cost = 22.'
      },
      {
        stepNumber: 4,
        activeLineIndex: 8,
        explanation: 'Visiting remaining cities: Goa (4) -> Surat (3) -> Nashik (2) -> return to Mumbai (0).',
        variables: { completedTour: '0->1->4->3->2->0', tourCost: 72 },
        stateSnapshot: { label: 'Full Tour', items: ['0->1->4->3->2->0 (Cost: 72)'] },
        outputLine: '[TOUR] Complete Hamiltonian cycle found with total cost 72.'
      },
      {
        stepNumber: 5,
        activeLineIndex: 11,
        explanation: 'Optimal Hamiltonian cycle verified: Mumbai -> Pune -> Goa -> Surat -> Nashik -> Mumbai. Minimum Cost = 72.',
        variables: { optimalCost: 72, citiesVisited: 5, status: 'OPTIMAL' },
        stateSnapshot: { label: 'Optimal Tour', items: ['Cost: 72 km/₹', 'Path: 0-1-4-3-2-0'] },
        outputLine: '[RESULT] TSP optimal tour cost = 72.'
      }
    ]
  },

  // DAA - N-Queens (Backtracking)
  'n-queens': {
    title: 'N-Queens Backtracking Problem',
    codeLines: [
      'solveNQueens(board, col, N):',
      '  if col >= N: return TRUE // All queens placed',
      '  for row = 0 to N - 1:',
      '    if isSafe(board, row, col):',
      '      board[row][col] = QUEEN',
      '      if solveNQueens(board, col + 1, N): return TRUE',
      '      board[row][col] = EMPTY // Backtrack',
      '  return FALSE // Trigger backtrack to previous col'
    ],
    steps: [
      {
        stepNumber: 1,
        activeLineIndex: 0,
        explanation: 'Initializing 4x4 chessboard. Target: Place 4 non-attacking queens.',
        variables: { N: 4, col: 0, placed: 0 },
        stateSnapshot: { label: 'Board 4x4', items: ['. . . .', '. . . .', '. . . .', '. . . .'] },
        outputLine: '[INIT] Starting 4-Queens solver at column 0.'
      },
      {
        stepNumber: 2,
        activeLineIndex: 4,
        explanation: 'Column 0: isSafe(row 1, col 0) is TRUE -> Place Queen at (1, 0). Recurse to col 1.',
        variables: { 'Q[0]': '(1, 0)', col: 1 },
        stateSnapshot: { label: 'Board 4x4', items: ['. . . .', 'Q . . .', '. . . .', '. . . .'] },
        outputLine: '[PLACE] Placed Queen 0 at row 1, col 0.'
      },
      {
        stepNumber: 3,
        activeLineIndex: 4,
        explanation: 'Column 1: Checking safe rows. Row 0, 1, 2 conflict. Safe at row 3 -> Place Queen at (3, 1).',
        variables: { 'Q[1]': '(3, 1)', col: 2 },
        stateSnapshot: { label: 'Board 4x4', items: ['. . . .', 'Q . . .', '. . . .', '. Q . .'] },
        outputLine: '[PLACE] Placed Queen 1 at row 3, col 1.'
      },
      {
        stepNumber: 4,
        activeLineIndex: 4,
        explanation: 'Column 2: Safe check at row 0 -> Place Queen at (0, 2). Recurse to col 3.',
        variables: { 'Q[2]': '(0, 2)', col: 3 },
        stateSnapshot: { label: 'Board 4x4', items: ['. . Q .', 'Q . . .', '. . . .', '. Q . .'] },
        outputLine: '[PLACE] Placed Queen 2 at row 0, col 2.'
      },
      {
        stepNumber: 5,
        activeLineIndex: 1,
        explanation: 'Column 3: Safe check at row 2 -> Place Queen at (2, 3). col == 4 >= N -> Valid solution reached!',
        variables: { 'Q[3]': '(2, 3)', solution: '[1, 3, 0, 2]' },
        stateSnapshot: { label: 'Solved Board', items: ['. . Q .', 'Q . . .', '. . . Q', '. Q . .'] },
        outputLine: '[SOLVED] All 4 queens placed with zero horizontal, vertical, or diagonal conflicts!'
      }
    ]
  },

  // DAA - KMP String Matching
  'kmp': {
    title: 'Knuth-Morris-Pratt (KMP) String Matching',
    codeLines: [
      'computeLPS(pattern, M, lps):',
      '  len = 0; lps[0] = 0; i = 1',
      '  while i < M: if pat[i] == pat[len]: len++; lps[i] = len; i++',
      'KMP_Search(text, pattern):',
      '  i = 0; j = 0; N = len(text); M = len(pattern)',
      '  while i < N:',
      '    if pattern[j] == text[i]: i++; j++',
      '    if j == M: print("Found at", i - j); j = lps[j - 1]',
      '    else if i < N and pattern[j] != text[i]:',
      '      if j != 0: j = lps[j - 1]',
      '      else: i++'
    ],
    steps: [
      {
        stepNumber: 1,
        activeLineIndex: 1,
        explanation: 'Precomputing Longest Prefix Suffix (LPS) array for pattern "ABABCABAB".',
        variables: { pattern: 'ABABCABAB', lps: '[0, 0, 1, 2, 0, 1, 2, 3, 4]' },
        stateSnapshot: { label: 'LPS Table', items: ['A:0', 'B:0', 'A:1', 'B:2', 'C:0', 'A:1', 'B:2', 'A:3', 'B:4'] },
        outputLine: '[LPS] Computed π lookup table in O(M) time.'
      },
      {
        stepNumber: 2,
        activeLineIndex: 6,
        explanation: 'Comparing text[0..3] ("ABAB") with pattern[0..3] ("ABAB") -> 4 consecutive character matches.',
        variables: { text_idx: 4, pat_idx: 4, matched_chars: 4 },
        stateSnapshot: { label: 'Text Scan', items: ['text: [A B A B] B A B C...', 'pat:  [A B A B] C...'] },
        outputLine: '[MATCH] text[0..3] matches pattern[0..3].'
      },
      {
        stepNumber: 3,
        activeLineIndex: 9,
        explanation: 'Mismatch at index 4: text[4] == "B", pattern[4] == "C". Shifting pattern via lps[3] = 2 without resetting text index i!',
        variables: { 'pattern[4]': 'C', 'text[4]': 'B', 'lps[3]': 2, 'new_j': 2 },
        stateSnapshot: { label: 'LPS Shift', items: ['Jumped pattern pointer j from 4 to 2 (lps[3]=2)'] },
        outputLine: '[OPTIMIZATION] Mismatch: jumped pattern pointer j=2. Text index i=4 preserved.'
      },
      {
        stepNumber: 4,
        activeLineIndex: 7,
        explanation: 'Continuing scan: Match found at text index 10! All M characters aligned.',
        variables: { match_index: 10, pattern_len: 9 },
        stateSnapshot: { label: 'Pattern Match', items: ['Found pattern at index 10'] },
        outputLine: '[FOUND] Substring match found at text offset 10.'
      },
      {
        stepNumber: 5,
        activeLineIndex: 7,
        explanation: 'KMP Search complete. Total comparisons performed: O(N) linear time.',
        variables: { total_occurrences: 1, time_complexity: 'O(N + M)' },
        stateSnapshot: { label: 'Search Results', items: ['Offsets: [10]', 'Comparisons: 16 (linear)'] },
        outputLine: '[COMPLETE] KMP linear string matching finished.'
      }
    ]
  },

  // DAA - Sum of Subsets (Backtracking)
  'sum-of-subsets': {
    title: 'Sum of Subsets (Backtracking)',
    codeLines: [
      'findSubsets(arr, idx, currSum, target, subset):',
      '  if currSum == target: recordSolution(subset); return',
      '  if idx >= len(arr) or currSum > target: return // Prune',
      '  // Include arr[idx]',
      '  subset.push(arr[idx])',
      '  findSubsets(arr, idx + 1, currSum + arr[idx], target, subset)',
      '  // Exclude arr[idx] (Backtrack)',
      '  subset.pop()',
      '  findSubsets(arr, idx + 1, currSum, target, subset)'
    ],
    steps: [
      {
        stepNumber: 1,
        activeLineIndex: 0,
        explanation: 'Sum of Subsets instance: Set = {10, 7, 5, 18, 12, 20, 15}, Target Sum = 35.',
        variables: { target: 35, currSum: 0, set: '10, 7, 5, 18, 12, 20, 15' },
        stateSnapshot: { label: 'Candidate Subset', items: [] },
        outputLine: '[INIT] Searching power set for subsets summing to 35.'
      },
      {
        stepNumber: 2,
        activeLineIndex: 4,
        explanation: 'Include 10: currSum = 10. Next include 7: currSum = 17. Next include 5: currSum = 22.',
        variables: { subset: '[10, 7, 5]', currSum: 22, remainingTarget: 13 },
        stateSnapshot: { label: 'Candidate Subset', items: [10, 7, 5] },
        outputLine: '[EXPLORE] Subset {10, 7, 5} sum = 22 < 35.'
      },
      {
        stepNumber: 3,
        activeLineIndex: 2,
        explanation: 'Testing 18: currSum = 22 + 18 = 40 > 35 -> Bound exceeded! Pruning right branch and backtracking.',
        variables: { testSum: 40, target: 35, action: 'PRUNE' },
        stateSnapshot: { label: 'Candidate Subset', items: [10, 7, 5, '18 (x)'] },
        outputLine: '[PRUNE] Sum 40 exceeds target 35. Backtracking from 18.'
      },
      {
        stepNumber: 4,
        activeLineIndex: 5,
        explanation: 'Testing 12: currSum = 22 + 12 = 34. Close to target. Exploring next branches: {10, 7, 18} sum = 35!',
        variables: { subset: '[10, 7, 18]', currSum: 35 },
        stateSnapshot: { label: 'Solution Subset', items: [10, 7, 18] },
        outputLine: '[SOLUTION] Found valid subset {10, 7, 18} summing exactly to 35!'
      },
      {
        stepNumber: 5,
        activeLineIndex: 1,
        explanation: 'Search terminated. Valid subsets identified: {10, 7, 18} and {20, 15}.',
        variables: { solutions_count: 2, target: 35 },
        stateSnapshot: { label: 'Identified Subsets', items: ['{10, 7, 18} = 35', '{20, 15} = 35'] },
        outputLine: '[COMPLETE] Backtracking search finished.'
      }
    ]
  },

  // DAA - Floyd-Warshall (All-Pairs Shortest Path)
  'floyd-warshall': {
    title: 'Floyd-Warshall All-Pairs Shortest Path',
    codeLines: [
      'floydWarshall(V, graph):',
      '  dist = copy(graph) // Initialize distance matrix',
      '  for k = 0 to V - 1: // Intermediate vertex',
      '    for i = 0 to V - 1: // Source vertex',
      '      for j = 0 to V - 1: // Destination vertex',
      '        if dist[i][k] + dist[k][j] < dist[i][j]:',
      '          dist[i][j] = dist[i][k] + dist[k][j]',
      '  return dist'
    ],
    steps: [
      {
        stepNumber: 1,
        activeLineIndex: 1,
        explanation: 'Initializing 4-vertex adjacency distance matrix D(0). Direct edges assigned weights, non-edges set to INFINITY.',
        variables: { V: 4, k: 'None', 'D[0][1]': 5, 'D[0][3]': 10, 'D[1][2]': 3, 'D[2][3]': 1 },
        stateSnapshot: { label: 'Distance Matrix D(0)', items: ['(0->1): 5', '(1->2): 3', '(2->3): 1', '(0->3): 10'] },
        outputLine: '[INIT] Direct distance matrix initialized.'
      },
      {
        stepNumber: 2,
        activeLineIndex: 5,
        explanation: 'Iteration k = 0 (Vertex 0 as intermediate): Checking if path through vertex 0 improves any pairs. Matrix updated to D(1).',
        variables: { intermediate: 'Vertex 0', relaxations: 0 },
        stateSnapshot: { label: 'Matrix D(1)', items: ['No improvements through vertex 0'] },
        outputLine: '[STEP] Finished pass k=0.'
      },
      {
        stepNumber: 3,
        activeLineIndex: 6,
        explanation: 'Iteration k = 1 (Vertex 1 as intermediate): Path 0 -> 1 -> 2 has cost dist[0][1] + dist[1][2] = 5 + 3 = 8 < dist[0][2] (INF)! Relaxing (0, 2) to 8.',
        variables: { intermediate: 'Vertex 1', 'dist[0][2]': 8 },
        stateSnapshot: { label: 'Matrix D(2)', items: ['(0->2) reduced from INF to 8'] },
        outputLine: '[RELAX] Path (0 -> 2) improved from INF to 8 via vertex 1.'
      },
      {
        stepNumber: 4,
        activeLineIndex: 6,
        explanation: 'Iteration k = 2 (Vertex 2 as intermediate): Path 0 -> 2 -> 3 has cost dist[0][2] + dist[2][3] = 8 + 1 = 9 < dist[0][3] (10)! Relaxing (0, 3) to 9.',
        variables: { intermediate: 'Vertex 2', 'dist[0][3]': 9 },
        stateSnapshot: { label: 'Matrix D(3)', items: ['(0->3) reduced from 10 to 9'] },
        outputLine: '[RELAX] Path (0 -> 3) improved from 10 to 9 via vertex 2.'
      },
      {
        stepNumber: 5,
        activeLineIndex: 7,
        explanation: 'All-Pairs Shortest Path complete! Final matrix D(4) contains optimal geodesic distances between all vertex pairs.',
        variables: { '0->1': 5, '0->2': 8, '0->3': 9, '1->2': 3, '1->3': 4, '2->3': 1 },
        stateSnapshot: { label: 'Final All-Pairs Matrix', items: ['(0->1): 5', '(0->2): 8', '(0->3): 9', '(1->3): 4'] },
        outputLine: '[COMPLETE] Floyd-Warshall O(V³) dynamic programming all-pairs shortest paths computed.'
      }
    ]
  },

  // DAA - Graph Coloring (Backtracking)
  'graph-coloring': {
    title: 'm-Coloring Problem (Backtracking)',
    codeLines: [
      'graphColoring(graph, m, color, vertex):',
      '  if vertex == V: return TRUE // All vertices assigned',
      '  for c = 1 to m: // Try available colors',
      '    if isSafe(vertex, graph, color, c):',
      '      color[vertex] = c',
      '      if graphColoring(graph, m, color, vertex + 1): return TRUE',
      '      color[vertex] = 0 // Backtrack',
      '  return FALSE'
    ],
    steps: [
      {
        stepNumber: 1,
        activeLineIndex: 0,
        explanation: 'Graph Coloring instance: 4 vertices (A, B, C, D) in cycle with cross diagonal. Target: Color using at most m = 3 colors.',
        variables: { V: 4, max_colors: 3, colors: '[1: Red, 2: Green, 3: Blue]' },
        stateSnapshot: { label: 'Vertex Colors', items: ['A: Uncolored', 'B: Uncolored', 'C: Uncolored', 'D: Uncolored'] },
        outputLine: '[INIT] Checking 3-colorability for 4-vertex graph.'
      },
      {
        stepNumber: 2,
        activeLineIndex: 4,
        explanation: 'Vertex A: isSafe(A, color 1 [Red]) is TRUE -> color[A] = 1 (Red). Proceed to Vertex B.',
        variables: { 'color[A]': '1 (Red)', vertex: 'B' },
        stateSnapshot: { label: 'Vertex Colors', items: ['A: Red', 'B: Uncolored', 'C: Uncolored', 'D: Uncolored'] },
        outputLine: '[COLOR] Vertex A colored Red.'
      },
      {
        stepNumber: 3,
        activeLineIndex: 4,
        explanation: 'Vertex B (adjacent to A): Color 1 conflicts with A. Trying Color 2 [Green] -> isSafe is TRUE -> color[B] = 2 (Green).',
        variables: { 'color[B]': '2 (Green)', vertex: 'C' },
        stateSnapshot: { label: 'Vertex Colors', items: ['A: Red', 'B: Green', 'C: Uncolored', 'D: Uncolored'] },
        outputLine: '[COLOR] Vertex B colored Green.'
      },
      {
        stepNumber: 4,
        activeLineIndex: 4,
        explanation: 'Vertex C (adjacent to A & B): Colors 1 and 2 conflict with neighbors. Trying Color 3 [Blue] -> isSafe is TRUE -> color[C] = 3 (Blue).',
        variables: { 'color[C]': '3 (Blue)', vertex: 'D' },
        stateSnapshot: { label: 'Vertex Colors', items: ['A: Red', 'B: Green', 'C: Blue', 'D: Uncolored'] },
        outputLine: '[COLOR] Vertex C colored Blue.'
      },
      {
        stepNumber: 5,
        activeLineIndex: 1,
        explanation: 'Vertex D (adjacent to B & C): Neighbor colors are Green (2) and Blue (3). Color 1 (Red) is SAFE -> color[D] = 1 (Red). All 4 vertices colored!',
        variables: { 'color[D]': '1 (Red)', chromatic_number: 3, status: 'VALID' },
        stateSnapshot: { label: 'Final Coloring', items: ['A: Red', 'B: Green', 'C: Blue', 'D: Red'] },
        outputLine: '[SUCCESS] Valid 3-coloring found with no two adjacent vertices sharing the same color!'
      }
    ]
  }
};

/**
 * Universal trace generator that extracts or constructs a rich, interactive
 * line-by-line execution trace for ANY experiment across ANY lab.
 */
export function getExperimentTracePlan(
  experiment: LabExperiment,
  preferredLanguage?: string
): TracePlan {
  const expId = experiment.id.toLowerCase();
  const subjId = (experiment.subjectId || '').toLowerCase();
  const title = experiment.title;

  // 1. Direct curated match check
  if (expId.includes('fractional-knapsack') || expId.includes('fractional')) {
    return {
      ...CURATED_TRACES['fractional-knapsack'],
      language: 'pseudocode',
      availableLanguages: getAvailableLanguages(experiment),
      defaultInput: experiment.sampleInput,
      expectedOutput: experiment.expectedOutput
    };
  }
  if (expId.includes('01-knapsack') || expId.includes('knapsack-01') || expId.includes('knapsack01')) {
    return {
      ...CURATED_TRACES['01-knapsack'],
      language: 'pseudocode',
      availableLanguages: getAvailableLanguages(experiment),
      defaultInput: experiment.sampleInput,
      expectedOutput: experiment.expectedOutput
    };
  }
  if (expId.includes('tsp') || expId.includes('travelling') || expId.includes('traveling')) {
    return {
      ...CURATED_TRACES['tsp'],
      language: 'pseudocode',
      availableLanguages: getAvailableLanguages(experiment),
      defaultInput: experiment.sampleInput,
      expectedOutput: experiment.expectedOutput
    };
  }
  if (expId.includes('n-queen') || expId.includes('nqueens') || expId.includes('queens')) {
    return {
      ...CURATED_TRACES['n-queens'],
      language: 'pseudocode',
      availableLanguages: getAvailableLanguages(experiment),
      defaultInput: experiment.sampleInput,
      expectedOutput: experiment.expectedOutput
    };
  }
  if (expId.includes('kmp') || expId.includes('knuth-morris')) {
    return {
      ...CURATED_TRACES['kmp'],
      language: 'pseudocode',
      availableLanguages: getAvailableLanguages(experiment),
      defaultInput: experiment.sampleInput,
      expectedOutput: experiment.expectedOutput
    };
  }
  if (expId.includes('sum-of-subsets') || expId.includes('subset-sum') || expId.includes('weather-stations-budget')) {
    return {
      ...CURATED_TRACES['sum-of-subsets'],
      language: 'pseudocode',
      availableLanguages: getAvailableLanguages(experiment),
      defaultInput: experiment.sampleInput,
      expectedOutput: experiment.expectedOutput
    };
  }
  if (expId.includes('floyd')) {
    return {
      ...CURATED_TRACES['floyd-warshall'],
      language: 'pseudocode',
      availableLanguages: getAvailableLanguages(experiment),
      defaultInput: experiment.sampleInput,
      expectedOutput: experiment.expectedOutput
    };
  }
  if (expId.includes('graph-color') || expId.includes('coloring')) {
    return {
      ...CURATED_TRACES['graph-coloring'],
      language: 'pseudocode',
      availableLanguages: getAvailableLanguages(experiment),
      defaultInput: experiment.sampleInput,
      expectedOutput: experiment.expectedOutput
    };
  }
  if (expId.includes('stack')) {
    return {
      ...CURATED_TRACES['stack'],
      language: 'pseudocode',
      availableLanguages: getAvailableLanguages(experiment),
      defaultInput: experiment.sampleInput,
      expectedOutput: experiment.expectedOutput
    };
  }
  if (expId.includes('queue')) {
    return {
      ...CURATED_TRACES['queue'],
      language: 'pseudocode',
      availableLanguages: getAvailableLanguages(experiment),
      defaultInput: experiment.sampleInput,
      expectedOutput: experiment.expectedOutput
    };
  }
  if (expId.includes('linked-list') || expId.includes('singly') || expId.includes('doubly')) {
    return {
      ...CURATED_TRACES['linked-list'],
      language: 'pseudocode',
      availableLanguages: getAvailableLanguages(experiment),
      defaultInput: experiment.sampleInput,
      expectedOutput: experiment.expectedOutput
    };
  }
  if (expId.includes('bst') || expId.includes('binary-search-tree')) {
    return {
      ...CURATED_TRACES['bst'],
      language: 'pseudocode',
      availableLanguages: getAvailableLanguages(experiment),
      defaultInput: experiment.sampleInput,
      expectedOutput: experiment.expectedOutput
    };
  }
  if (subjId === 'dbms' && (expId.includes('ddl') || expId.includes('table') || expId.includes('constraint'))) {
    return {
      ...CURATED_TRACES['dbms-ddl'],
      language: 'sql',
      availableLanguages: getAvailableLanguages(experiment),
      defaultInput: experiment.sampleInput,
      expectedOutput: experiment.expectedOutput
    };
  }
  if (subjId === 'dbms' && (expId.includes('join') || expId.includes('query') || expId.includes('select'))) {
    return {
      ...CURATED_TRACES['dbms-joins'],
      language: 'sql',
      availableLanguages: getAvailableLanguages(experiment),
      defaultInput: experiment.sampleInput,
      expectedOutput: experiment.expectedOutput
    };
  }
  if (subjId === 'os' && (expId.includes('schedul') || expId.includes('fcfs') || expId.includes('sjf') || expId.includes('round-robin'))) {
    return {
      ...CURATED_TRACES['os-cpu-scheduling'],
      language: 'pseudocode',
      availableLanguages: getAvailableLanguages(experiment),
      defaultInput: experiment.sampleInput,
      expectedOutput: experiment.expectedOutput
    };
  }
  if ((subjId === 'aiml' || subjId === 'ml') && (expId.includes('regress') || expId.includes('gradient') || expId.includes('linear'))) {
    return {
      ...CURATED_TRACES['ml-gradient-descent'],
      language: 'python',
      availableLanguages: getAvailableLanguages(experiment),
      defaultInput: experiment.sampleInput,
      expectedOutput: experiment.expectedOutput
    };
  }

  // 2. Algorithm codes dictionary check
  const algoCodeKey = findMatchingAlgoKey(expId);
  if (algoCodeKey && ALGORITHM_CODES[algoCodeKey]) {
    const def = ALGORITHM_CODES[algoCodeKey];
    const steps = generateStepsFromCodeLines(def.lines, title, experiment);
    return {
      title: def.title || title,
      codeLines: def.lines,
      language: 'pseudocode',
      availableLanguages: getAvailableLanguages(experiment),
      steps,
      defaultInput: experiment.sampleInput,
      expectedOutput: experiment.expectedOutput
    };
  }

  // 3. Language source code trace (if user requested specific language)
  if (preferredLanguage && experiment.code && experiment.code[preferredLanguage]) {
    const rawCode = experiment.code[preferredLanguage] || '';
    const cleanLines = rawCode.split('\n').slice(0, 35).map(l => l.trimEnd());
    const steps = generateStepsFromCodeLines(cleanLines, title, experiment);
    return {
      title: `${title} (${preferredLanguage.toUpperCase()})`,
      codeLines: cleanLines,
      language: preferredLanguage,
      availableLanguages: getAvailableLanguages(experiment),
      steps,
      defaultInput: experiment.sampleInput,
      expectedOutput: experiment.expectedOutput
    };
  }

  // 4. Synthesize robust trace from experiment.algorithm
  if (experiment.algorithm && experiment.algorithm.length > 0) {
    const formattedLines = formatAlgorithmIntoCodeLines(experiment.algorithm);
    const steps = generateStepsFromAlgorithm(experiment.algorithm, title, experiment);
    return {
      title: `${title} Algorithm`,
      codeLines: formattedLines,
      language: 'algorithm',
      availableLanguages: getAvailableLanguages(experiment),
      steps,
      defaultInput: experiment.sampleInput,
      expectedOutput: experiment.expectedOutput
    };
  }

  // 5. Fallback from experiment primary code (C, Python, SQL)
  const primaryCode = experiment.code?.c || experiment.code?.python || experiment.code?.sql || experiment.code?.cpp || '';
  const lines = primaryCode
    ? primaryCode.split('\n').slice(0, 25).map(l => l.trimEnd())
    : [
        `initialize_${expId.replace(/-/g, '_')}():`,
        '  input = read_dataset_or_parameters()',
        '  validate_preconditions(input)',
        '  execute_core_transformation()',
        '  record_metrics_and_state()',
        '  display_results()',
        '  return status_ok'
      ];

  const steps = generateStepsFromCodeLines(lines, title, experiment);
  return {
    title: `${title} Execution Tracer`,
    codeLines: lines,
    language: 'pseudocode',
    availableLanguages: getAvailableLanguages(experiment),
    steps,
    defaultInput: experiment.sampleInput,
    expectedOutput: experiment.expectedOutput
  };
}

function getAvailableLanguages(exp: LabExperiment): { id: string; name: string }[] {
  const list: { id: string; name: string }[] = [{ id: 'algorithm', name: 'Algorithm / Pseudocode' }];
  if (exp.code) {
    if (exp.code.c) list.push({ id: 'c', name: 'C Language' });
    if (exp.code.python) list.push({ id: 'python', name: 'Python' });
    if (exp.code.sql) list.push({ id: 'sql', name: 'SQL' });
    if (exp.code.java) list.push({ id: 'java', name: 'Java' });
    if (exp.code.cpp) list.push({ id: 'cpp', name: 'C++' });
    if (exp.code.bash) list.push({ id: 'bash', name: 'Bash Shell' });
  }
  return list;
}

function findMatchingAlgoKey(id: string): string | null {
  if (id.includes('bubble')) return 'bubbleSort';
  if (id.includes('selection')) return 'selectionSort';
  if (id.includes('insertion')) return 'insertionSort';
  if (id.includes('merge')) return 'mergeSort';
  if (id.includes('quick')) return 'quickSort';
  if (id.includes('infix')) return 'infixToPostfix';
  if (id.includes('dijkstra')) return 'dijkstra';
  if (id.includes('kruskal')) return 'kruskalMST';
  if (id.includes('fractional') || id.includes('knapsack')) return 'fractionalKnapsack';
  return null;
}

function formatAlgorithmIntoCodeLines(algoSteps: string[]): string[] {
  return algoSteps.map((step, idx) => {
    // Clean step prefixes like "Step 1: ", "1. ", etc.
    const cleaned = step.replace(/^Step\s*\d+\s*:\s*/i, '').replace(/^\d+\.\s*/, '').trim();
    return `${idx + 1}.  ${cleaned}`;
  });
}

function generateStepsFromAlgorithm(
  algoSteps: string[],
  title: string,
  exp: LabExperiment
): TraceStep[] {
  return algoSteps.map((step, idx) => {
    const cleanStep = step.replace(/^Step\s*\d+\s*:\s*/i, '').replace(/^\d+\.\s*/, '').trim();
    const isFirst = idx === 0;
    const isLast = idx === algoSteps.length - 1;

    let explanation = `Executing Step ${idx + 1}: ${cleanStep}`;
    if (isFirst) {
      explanation = `Initialization: ${cleanStep}`;
    } else if (isLast) {
      explanation = `Completion: ${cleanStep}. All parameters verified.`;
    }

    return {
      stepNumber: idx + 1,
      activeLineIndex: idx,
      explanation,
      variables: {
        currentStep: idx + 1,
        totalSteps: algoSteps.length,
        status: isLast ? 'COMPLETED' : 'IN_PROGRESS'
      },
      stateSnapshot: {
        label: 'Execution State',
        items: [`Step ${idx + 1}/${algoSteps.length}: ${cleanStep.slice(0, 36)}...`],
        highlightIndex: 0
      },
      outputLine: `[STEP ${idx + 1}] ${cleanStep.slice(0, 65)}`
    };
  });
}

function generateStepsFromCodeLines(
  lines: string[],
  title: string,
  exp: LabExperiment
): TraceStep[] {
  const steps: TraceStep[] = [];
  const meaningfulIndices: number[] = [];

  // Identify lines that are not comments or empty brackets
  lines.forEach((l, idx) => {
    const trimmed = l.trim();
    if (trimmed && !trimmed.startsWith('//') && !trimmed.startsWith('/*') && trimmed !== '{' && trimmed !== '}') {
      meaningfulIndices.push(idx);
    }
  });

  const targetIndices = meaningfulIndices.length > 0 ? meaningfulIndices : lines.map((_, i) => i);
  // Cap at max 12 steps for fluid interactive playback
  const selected = targetIndices.slice(0, 12);

  selected.forEach((lineIdx, sIdx) => {
    const lineText = lines[lineIdx].trim();
    const isFirst = sIdx === 0;
    const isLast = sIdx === selected.length - 1;

    let explanation = `Executing line #${lineIdx + 1}: ${lineText}`;
    if (isFirst) {
      explanation = `Initiating ${title}: ${lineText}`;
    } else if (isLast) {
      explanation = `Finalizing ${title}: ${lineText}. Output ready.`;
    }

    steps.push({
      stepNumber: sIdx + 1,
      activeLineIndex: lineIdx,
      explanation,
      variables: {
        line: lineIdx + 1,
        step: sIdx + 1,
        total: selected.length
      },
      stateSnapshot: {
        label: 'Active Instruction',
        items: [`L${lineIdx + 1}: ${lineText}`],
        highlightIndex: 0
      },
      outputLine: `[EXEC] Line ${lineIdx + 1}: ${lineText.slice(0, 60)}`
    });
  });

  return steps;
}
