import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  SkipForward,
  SkipBack,
  Terminal,
  Activity,
  CheckCircle2,
  Sliders,
  Code2,
  Layers,
  Copy,
  Check
} from 'lucide-react';
import { LabExperiment } from '../../../types';
import { VisuAlgoCodePanel } from './VisuAlgoCodePanel';
import { getExperimentTracePlan, TracePlan, TraceStep } from './universalTraceEngine';

interface Props {
  experiment: LabExperiment;
  onSimulationComplete?: () => void;
  className?: string;
  defaultAutoPlay?: boolean;
}

export const UniversalExecutionTracer: React.FC<Props> = ({
  experiment,
  onSimulationComplete,
  className = '',
  defaultAutoPlay = false
}) => {
  const [selectedLang, setSelectedLang] = useState<string>('algorithm');
  const [tracePlan, setTracePlan] = useState<TracePlan>(() =>
    getExperimentTracePlan(experiment, 'algorithm')
  );
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(defaultAutoPlay);
  const [speedMs, setSpeedMs] = useState<number>(1200); // 1.2s per step
  const [consoleLogs, setConsoleLogs] = useState<string[]>([]);
  const [copied, setCopied] = useState<boolean>(false);
  const playTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Update trace plan when experiment or selected language changes
  useEffect(() => {
    const plan = getExperimentTracePlan(experiment, selectedLang === 'algorithm' ? undefined : selectedLang);
    setTracePlan(plan);
    setCurrentStepIndex(0);
    setIsPlaying(false);

    // Initial console log
    if (plan.steps.length > 0 && plan.steps[0].outputLine) {
      setConsoleLogs([plan.steps[0].outputLine]);
    } else {
      setConsoleLogs([`[INIT] Ready to execute ${experiment.title}`]);
    }
  }, [experiment.id, selectedLang]);

  const currentStep: TraceStep =
    tracePlan.steps[currentStepIndex] || {
      stepNumber: 1,
      activeLineIndex: 0,
      explanation: 'Ready for execution. Click Next Step or Auto Play to trace code.',
      variables: {},
      outputLine: ''
    };

  // Playback timer effect
  useEffect(() => {
    if (isPlaying) {
      playTimerRef.current = setTimeout(() => {
        if (currentStepIndex < tracePlan.steps.length - 1) {
          const nextIdx = currentStepIndex + 1;
          setCurrentStepIndex(nextIdx);
          const nextStep = tracePlan.steps[nextIdx];
          if (nextStep?.outputLine) {
            setConsoleLogs((prev) => [...prev, nextStep.outputLine!]);
          }
        } else {
          // Finished execution
          setIsPlaying(false);
          onSimulationComplete?.();
        }
      }, speedMs);
    }

    return () => {
      if (playTimerRef.current) {
        clearTimeout(playTimerRef.current);
      }
    };
  }, [isPlaying, currentStepIndex, tracePlan.steps, speedMs, onSimulationComplete]);

  const handleNextStep = () => {
    setIsPlaying(false);
    if (currentStepIndex < tracePlan.steps.length - 1) {
      const nextIdx = currentStepIndex + 1;
      setCurrentStepIndex(nextIdx);
      const nextStep = tracePlan.steps[nextIdx];
      if (nextStep?.outputLine) {
        setConsoleLogs((prev) => [...prev, nextStep.outputLine!]);
      }
      if (nextIdx === tracePlan.steps.length - 1) {
        onSimulationComplete?.();
      }
    }
  };

  const handlePrevStep = () => {
    setIsPlaying(false);
    if (currentStepIndex > 0) {
      setCurrentStepIndex((prev) => prev - 1);
    }
  };

  const handleReset = () => {
    setIsPlaying(false);
    setCurrentStepIndex(0);
    if (tracePlan.steps.length > 0 && tracePlan.steps[0].outputLine) {
      setConsoleLogs([`[RESET] Execution reset to step 1.`, tracePlan.steps[0].outputLine]);
    } else {
      setConsoleLogs([`[RESET] Execution reset to initial step.`]);
    }
  };

  const handleCopyLogs = () => {
    navigator.clipboard.writeText(consoleLogs.join('\n'));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const progressPercent = Math.round(
    ((currentStepIndex + 1) / Math.max(tracePlan.steps.length, 1)) * 100
  );

  return (
    <div className={`space-y-5 ${className}`}>
      {/* Top Controls & Language Selector Header */}
      <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-4 shadow-lg flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#00D8FF]/10 border border-[#00D8FF]/30 flex items-center justify-center text-[#00D8FF] shadow-[0_0_12px_rgba(0,216,255,0.2)]">
            <Activity className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-white tracking-wide">
                {tracePlan.title}
              </h3>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-[#00D8FF]/15 text-[#00D8FF] border border-[#00D8FF]/40 font-bold">
                Step-by-Step
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5 font-sans">
              Interactive execution highlighting each active step and memory snapshot
            </p>
          </div>
        </div>

        {/* Language / View Switcher */}
        {tracePlan.availableLanguages.length > 1 && (
          <div className="flex items-center gap-1.5 bg-[#1E293B] p-1 rounded-xl border border-slate-700/80">
            <span className="text-[11px] font-mono text-slate-400 px-2 flex items-center gap-1">
              <Code2 className="w-3.5 h-3.5 text-[#00D8FF]" /> View:
            </span>
            {tracePlan.availableLanguages.map((lang) => (
              <button
                key={lang.id}
                onClick={() => setSelectedLang(lang.id)}
                className={`px-2.5 py-1 text-xs font-mono font-bold rounded-lg transition-all cursor-pointer ${
                  selectedLang === lang.id
                    ? 'bg-[#00D8FF] text-slate-950 shadow-sm'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                {lang.name}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Main Grid: Interactive Simulation & State (Left 7 cols) + Code Panel (Right 5 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left 7 columns: Interactive Simulation Controls, Memory State & Console Output */}
        <div className="lg:col-span-7 flex flex-col space-y-4">
          {/* Playback & Step Controls Bar */}
          <div className="bg-[#0F172A] border border-slate-800 rounded-xl p-3.5 shadow-md flex flex-wrap items-center justify-between gap-3">
            {/* Step buttons */}
            <div className="flex items-center gap-2">
              <button
                onClick={handleReset}
                className="px-3 py-1.5 bg-[#1E293B] hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold rounded-lg border border-slate-700 transition-all flex items-center gap-1.5 cursor-pointer active:scale-95"
                title="Reset Execution"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>

              <button
                onClick={handlePrevStep}
                disabled={currentStepIndex === 0}
                className="px-3 py-1.5 bg-[#1E293B] hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-slate-300 hover:text-white text-xs font-bold rounded-lg border border-slate-700 transition-all flex items-center gap-1 cursor-pointer active:scale-95"
                title="Previous Step"
              >
                <SkipBack className="w-3.5 h-3.5" />
                <span>Prev</span>
              </button>

              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 shadow-md cursor-pointer active:scale-95 ${
                  isPlaying
                    ? 'bg-amber-500 hover:bg-amber-600 text-slate-950 font-black'
                    : 'bg-[#00D8FF] hover:bg-[#38BDF8] text-slate-950 font-black'
                }`}
                title={isPlaying ? 'Pause Execution' : 'Auto Play Steps'}
              >
                {isPlaying ? (
                  <>
                    <Pause className="w-3.5 h-3.5 fill-current" />
                    <span>Pause</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Auto Play</span>
                  </>
                )}
              </button>

              <button
                onClick={handleNextStep}
                disabled={currentStepIndex >= tracePlan.steps.length - 1}
                className="px-3 py-1.5 bg-[#1E293B] hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-slate-300 hover:text-white text-xs font-bold rounded-lg border border-slate-700 transition-all flex items-center gap-1 cursor-pointer active:scale-95"
                title="Next Step"
              >
                <span>Next</span>
                <SkipForward className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Speed & Progress indicator */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1 bg-[#1E293B] px-2 py-1 rounded-lg border border-slate-800 text-[11px] font-mono text-slate-300">
                <Sliders className="w-3 h-3 text-[#00D8FF]" />
                <button
                  onClick={() => setSpeedMs(1800)}
                  className={`px-1.5 py-0.5 rounded ${speedMs === 1800 ? 'bg-[#00D8FF] text-slate-950 font-bold' : 'hover:text-white'}`}
                >
                  0.5x
                </button>
                <button
                  onClick={() => setSpeedMs(1200)}
                  className={`px-1.5 py-0.5 rounded ${speedMs === 1200 ? 'bg-[#00D8FF] text-slate-950 font-bold' : 'hover:text-white'}`}
                >
                  1x
                </button>
                <button
                  onClick={() => setSpeedMs(600)}
                  className={`px-1.5 py-0.5 rounded ${speedMs === 600 ? 'bg-[#00D8FF] text-slate-950 font-bold' : 'hover:text-white'}`}
                >
                  2x
                </button>
              </div>

              <div className="text-right">
                <span className="text-[11px] font-mono font-bold text-[#00D8FF]">
                  {progressPercent}% Complete
                </span>
                <div className="w-24 h-1.5 bg-slate-800 rounded-full overflow-hidden mt-0.5">
                  <div
                    className="h-full bg-[#00D8FF] transition-all duration-200"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Watch Variables & Memory State Card */}
          <div className="bg-[#0F172A] border border-slate-800 rounded-xl overflow-hidden shadow-lg">
            <div className="bg-[#1E293B] px-4 py-2.5 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#00D8FF]" />
                <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                  Interactive State & Variables
                </h4>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-black/40 text-emerald-400 border border-emerald-500/30">
                LIVE WATCH
              </span>
            </div>

            <div className="p-4 space-y-3">
              {/* Variables Grid */}
              {currentStep.variables && Object.keys(currentStep.variables).length > 0 ? (
                <div className="grid grid-cols-2 gap-2">
                  {Object.entries(currentStep.variables).map(([k, v]) => (
                    <div
                      key={k}
                      className="bg-[#1E293B]/70 border border-slate-700/80 rounded-lg p-2 flex items-center justify-between"
                    >
                      <span className="text-xs font-mono text-slate-400 font-bold truncate pr-1">
                        {k}
                      </span>
                      <span className="text-xs font-mono font-black text-[#00D8FF] bg-black/40 px-2 py-0.5 rounded border border-[#00D8FF]/20 truncate">
                        {String(v)}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-400 italic">No local variables at current step.</p>
              )}

              {/* Data Structure / Memory Buffer Snapshot */}
              {currentStep.stateSnapshot && (
                <div className="pt-2 border-t border-slate-800/80">
                  <span className="text-[11px] font-mono text-slate-400 block mb-1.5 font-semibold">
                    {currentStep.stateSnapshot.label}:
                  </span>
                  <div className="flex items-center gap-1.5 flex-wrap bg-[#0B1120] p-2.5 rounded-lg border border-slate-800 min-h-[44px]">
                    {currentStep.stateSnapshot.items.length > 0 ? (
                      currentStep.stateSnapshot.items.map((item, idx) => {
                        const isHighlighted = idx === currentStep.stateSnapshot?.highlightIndex;
                        return (
                          <span
                            key={idx}
                            className={`text-xs font-mono font-bold px-2.5 py-1 rounded transition-all ${
                              isHighlighted
                                ? 'bg-[#1E3E62] text-white border-2 border-[#00D8FF] shadow-[0_0_8px_rgba(0,216,255,0.4)] scale-105'
                                : 'bg-[#1E293B] text-slate-200 border border-slate-700'
                            }`}
                          >
                            {String(item)}
                          </span>
                        );
                      })
                    ) : (
                      <span className="text-xs text-slate-500 font-mono italic">Empty Buffer</span>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Live Terminal / Execution Console Output */}
          <div className="bg-[#0B1120] border border-slate-800 rounded-xl overflow-hidden shadow-lg flex-1 flex flex-col min-h-[220px]">
            <div className="bg-[#0F172A] px-4 py-2 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Terminal className="w-3.5 h-3.5 text-[#00D8FF]" />
                <span className="text-xs font-bold text-white font-mono uppercase tracking-wider">
                  Live Execution Console (stdout)
                </span>
              </div>
              <button
                onClick={handleCopyLogs}
                className="text-[10px] font-mono text-slate-400 hover:text-white flex items-center gap-1 px-2 py-0.5 rounded hover:bg-slate-800 transition-colors cursor-pointer"
                title="Copy Terminal Logs"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            <div className="p-3 font-mono text-xs text-slate-300 space-y-1.5 flex-1 overflow-y-auto max-h-[260px] select-text">
              {consoleLogs.map((log, i) => (
                <div key={i} className="flex items-start gap-2 leading-relaxed">
                  <span className="text-[#00D8FF] select-none shrink-0">&gt;</span>
                  <span className={i === consoleLogs.length - 1 ? 'text-white font-bold' : 'text-slate-300'}>
                    {log}
                  </span>
                </div>
              ))}
              {currentStepIndex === tracePlan.steps.length - 1 && (
                <div className="pt-2 text-emerald-400 font-bold flex items-center gap-1.5 border-t border-slate-800/80 mt-2">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>[EXECUTION SUCCESSFUL] All steps completed & verified.</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right 5 columns: VisuAlgo Code Panel from User's Screenshot */}
        <div className="lg:col-span-5 flex flex-col space-y-3">
          <VisuAlgoCodePanel
            title={tracePlan.title}
            explanation={currentStep.explanation}
            codeLines={tracePlan.codeLines}
            activeLineIndex={currentStep.activeLineIndex}
            stepInfo={{
              current: currentStepIndex + 1,
              total: tracePlan.steps.length
            }}
          />
        </div>
      </div>
    </div>
  );
};
