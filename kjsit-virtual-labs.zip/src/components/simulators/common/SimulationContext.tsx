import React, { createContext, useContext } from 'react';

interface SimulationContextValue {
  onSimulationComplete: () => void;
}

const SimulationContext = createContext<SimulationContextValue | null>(null);

export const SimulationProvider: React.FC<{
  onSimulationComplete?: () => void;
  children: React.ReactNode;
}> = ({ onSimulationComplete, children }) => {
  return (
    <SimulationContext.Provider
      value={{
        onSimulationComplete: () => {
          onSimulationComplete?.();
        }
      }}
    >
      {children}
    </SimulationContext.Provider>
  );
};

export const useSimulationContext = () => {
  return useContext(SimulationContext);
};
