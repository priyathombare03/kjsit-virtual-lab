import React, { useState, useEffect, useRef } from 'react';
import { ChevronRight, ChevronLeft, Code, Play, Terminal } from 'lucide-react';

export interface VisuAlgoCodePanelProps {
  title: string;
  explanation: string;
  codeLines: string[];
  activeLineIndex: number;
  className?: string;
  defaultCollapsed?: boolean;
  stepInfo?: { current: number; total: number };
  maxHeight?: string;
}

export const VisuAlgoCodePanel: React.FC<VisuAlgoCodePanelProps> = ({
  title,
  explanation,
  codeLines,
  activeLineIndex,
  className = '',
  defaultCollapsed = false,
  stepInfo,
  maxHeight = 'max-h-[380px]'
}) => {
  const [isCollapsed, setIsCollapsed] = useState(defaultCollapsed);
  const activeLineRef = useRef<HTMLDivElement | null>(null);

  // Smooth scroll active line into view
  useEffect(() => {
    if (activeLineRef.current) {
      activeLineRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest'
      });
    }
  }, [activeLineIndex]);

  if (isCollapsed) {
    return (
      <div className={`relative ${className}`}>
        <button
          onClick={() => setIsCollapsed(false)}
          className="flex items-center gap-2 px-3.5 py-2 bg-[#1E293B] hover:bg-[#0F172A] text-[#E2E8F0] hover:text-white text-xs font-bold rounded-lg shadow-md border border-[#0EA5E9]/50 transition-all cursor-pointer"
          title="Expand Algorithm Code Panel"
        >
          <Code className="w-4 h-4 text-[#00D8FF]" />
          <span>Show Code ({title})</span>
          <ChevronLeft className="w-4 h-4 text-[#00D8FF]" />
        </button>
      </div>
    );
  }

  return (
    <div className={`flex flex-col rounded-xl overflow-hidden shadow-xl border border-slate-800/80 text-left bg-[#0F172A] transition-all ${className}`}>
      {/* Top Title Bar */}
      <div className="bg-[#0F172A] text-white px-4 py-2.5 flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <span className="w-2.5 h-2.5 rounded-full bg-[#00D8FF] shadow-[0_0_8px_rgba(0,216,255,0.7)]"></span>
          <h4 className="text-sm font-bold tracking-wide text-white font-sans">
            {title}
          </h4>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider hidden sm:inline flex items-center gap-1">
            <Terminal className="w-3 h-3 text-[#00D8FF]" />
            Live Tracer
          </span>
          <button
            onClick={() => setIsCollapsed(true)}
            className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors cursor-pointer"
            title="Collapse Code Panel"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Header Status Bar (replaces bright green with #1E293B & 2px solid #0EA5E9) */}
      <div
        style={{ backgroundColor: '#1E293B', borderBottom: '2px solid #0EA5E9' }}
        className="px-4 py-3 text-white flex items-start gap-2.5 shadow-sm"
      >
        <div className="mt-0.5 shrink-0">
          <Play className="w-3.5 h-3.5 fill-[#00D8FF] text-[#00D8FF]" />
        </div>
        <div className="flex-1">
          <p className="text-white font-bold text-xs leading-relaxed tracking-wide font-sans">
            {explanation || 'Ready for simulation. Click Next Step or Auto Play to execute.'}
          </p>
        </div>
      </div>

      {/* Code Editor Body (replaces hot pink with #0F172A background, #E2E8F0 text, and #1E3E62 + #00D8FF active highlight) */}
      <div
        style={{
          backgroundColor: '#0F172A',
          fontFamily: "'JetBrains Mono', 'Fira Code', Consolas, Menlo, Monaco, monospace"
        }}
        className={`p-3 text-xs overflow-x-auto overflow-y-auto ${maxHeight} select-text leading-relaxed scrollbar-thin scrollbar-thumb-slate-700`}
      >
        <div className="space-y-0.5 min-w-[300px]">
          {codeLines.map((line, idx) => {
            const isActive = idx === activeLineIndex;

            return (
              <div
                key={idx}
                ref={isActive ? activeLineRef : null}
                style={
                  isActive
                    ? {
                        backgroundColor: '#1E3E62',
                        borderLeft: '4px solid #00D8FF',
                        color: '#FFFFFF'
                      }
                    : {
                        color: '#E2E8F0'
                      }
                }
                className={`px-3 py-1.5 rounded-r transition-all duration-150 flex items-center gap-2.5 ${
                  isActive
                    ? 'font-bold shadow-md'
                    : 'hover:bg-[#1E293B]/70 border-l-4 border-transparent'
                }`}
              >
                {/* Line number and active pointer */}
                <span
                  style={{
                    color: isActive ? '#00D8FF' : '#94A3B8'
                  }}
                  className="w-6 text-[11px] select-none font-bold shrink-0 text-right pr-1"
                >
                  {isActive ? '▶' : `${idx + 1}`}
                </span>

                {/* Code line content */}
                <span className="whitespace-pre flex-1 tracking-wide font-medium">
                  {line}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
