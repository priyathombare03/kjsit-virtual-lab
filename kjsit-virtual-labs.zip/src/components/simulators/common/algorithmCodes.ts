export interface AlgorithmCodeDef {
  title: string;
  lines: string[];
}

export const ALGORITHM_CODES: Record<string, AlgorithmCodeDef> = {
  // Bubble Sort (from VisuAlgo screenshot)
  bubbleSort: {
    title: 'Bubble Sort',
    lines: [
      'do',
      '  swapped = false',
      '  for i = 1 to indexOfLastUnsortedElement-1',
      '    if leftElement > rightElement',
      '      swap(leftElement, rightElement)',
      '      swapped = true; ++swapCounter',
      'while swapped'
    ]
  },

  // Selection Sort
  selectionSort: {
    title: 'Selection Sort',
    lines: [
      'for i = 0 to n - 2',
      '  minIdx = i',
      '  for j = i + 1 to n - 1',
      '    if arr[j] < arr[minIdx]',
      '      minIdx = j',
      '  if minIdx != i',
      '    swap(arr[i], arr[minIdx])',
      '  mark arr[i] as sorted'
    ]
  },

  // Insertion Sort
  insertionSort: {
    title: 'Insertion Sort',
    lines: [
      'for i = 1 to n - 1',
      '  key = arr[i]',
      '  j = i - 1',
      '  while j >= 0 and arr[j] > key',
      '    arr[j + 1] = arr[j]',
      '    j = j - 1',
      '  arr[j + 1] = key',
      '  mark arr[0..i] as sorted'
    ]
  },

  // Merge Sort
  mergeSort: {
    title: 'Merge Sort',
    lines: [
      'mergeSort(arr, left, right):',
      '  if left < right:',
      '    mid = floor((left + right) / 2)',
      '    mergeSort(arr, left, mid)',
      '    mergeSort(arr, mid + 1, right)',
      '    merge(arr, left, mid, right):',
      '      compare L[i] with R[j]',
      '      copy smaller element to arr[k]',
      '      copy remaining elements'
    ]
  },

  // Quick Sort
  quickSort: {
    title: 'Quick Sort (Lomuto Partition)',
    lines: [
      'quickSort(arr, low, high):',
      '  if low < high:',
      '    pivot = arr[high]; i = low - 1',
      '    for j = low to high - 1:',
      '      if arr[j] <= pivot:',
      '        i++; swap(arr[i], arr[j])',
      '    swap(arr[i + 1], arr[high])',
      '    pi = i + 1',
      '    quickSort(arr, low, pi - 1)',
      '    quickSort(arr, pi + 1, high)'
    ]
  },

  // Infix to Postfix Conversion
  infixToPostfix: {
    title: 'Infix to Postfix Conversion',
    lines: [
      'for each token in expression:',
      '  if isOperand(token):',
      '    output.append(token)',
      '  else if token == \'(\':',
      '    stack.push(token)',
      '  else if token == \')\':',
      '    while stack.top() != \'(\': output.append(stack.pop())',
      '    stack.pop() // discard \'(\'',
      '  else if isOperator(token):',
      '    while precedence(stack.top()) >= precedence(token):',
      '      output.append(stack.pop())',
      '    stack.push(token)',
      'while not stack.isEmpty():',
      '  output.append(stack.pop())'
    ]
  },

  // Stack ADT
  stackADT: {
    title: 'Stack ADT Operations',
    lines: [
      'push(element):',
      '  if top >= MAX_CAPACITY - 1: return OVERFLOW',
      '  top = top + 1',
      '  stack[top] = element',
      'pop():',
      '  if top < 0: return UNDERFLOW',
      '  val = stack[top]; top = top - 1',
      '  return val',
      'peek():',
      '  if top < 0: return NULL',
      '  return stack[top]'
    ]
  },

  // Linear / Circular Queue ADT
  queueADT: {
    title: 'Queue ADT (FIFO)',
    lines: [
      'enqueue(item):',
      '  if (rear + 1) % MAX == front: return QUEUE_FULL',
      '  if front == -1: front = 0',
      '  rear = (rear + 1) % MAX',
      '  queue[rear] = item',
      'dequeue():',
      '  if front == -1: return QUEUE_EMPTY',
      '  val = queue[front]',
      '  if front == rear: front = -1; rear = -1',
      '  else: front = (front + 1) % MAX',
      '  return val'
    ]
  },

  // Binary Search Tree (BST)
  bstOperations: {
    title: 'Binary Search Tree (BST)',
    lines: [
      'insert(root, key):',
      '  if root == null: return new Node(key)',
      '  if key < root.key:',
      '    root.left = insert(root.left, key)',
      '  else if key > root.key:',
      '    root.right = insert(root.right, key)',
      '  return root',
      'search(root, key):',
      '  if root == null or root.key == key: return root',
      '  if key < root.key: return search(root.left, key)',
      '  return search(root.right, key)'
    ]
  },

  // Kruskal's MST
  kruskalMST: {
    title: "Kruskal's Minimum Spanning Tree",
    lines: [
      'sort all edges E by weight ascending',
      'initialize DisjointSet for all vertices V',
      'for each edge (u, v, weight) in E:',
      '  rootU = find(u)',
      '  rootV = find(v)',
      '  if rootU != rootV:',
      '    add (u, v) to MST_Edges',
      '    union(rootU, rootV)',
      '  else: discard (u, v) // forms cycle'
    ]
  },

  // Dijkstra's Shortest Path
  dijkstra: {
    title: "Dijkstra's Algorithm",
    lines: [
      'dist[start] = 0; pq.push((0, start))',
      'while not pq.isEmpty():',
      '  (currDist, u) = pq.pop()',
      '  if currDist > dist[u]: continue',
      '  for each neighbor v of u with weight w:',
      '    if dist[u] + w < dist[v]:',
      '      dist[v] = dist[u] + w',
      '      parent[v] = u; pq.push((dist[v], v))'
    ]
  },

  // Fractional Knapsack
  fractionalKnapsack: {
    title: 'Fractional Knapsack (Greedy)',
    lines: [
      'compute ratio = value / weight for all items',
      'sort items in descending order of ratio',
      'for each item in sortedItems:',
      '  if capacity >= item.weight:',
      '    take 100% of item; capacity -= item.weight',
      '  else:',
      '    take fraction (capacity / item.weight)',
      '    break // knapsack full'
    ]
  },

  // Traveling Salesperson Problem (TSP)
  tsp: {
    title: 'TSP (Branch and Bound / DP)',
    lines: [
      'function tsp(currCity, visitedMask, cost):',
      '  if visitedMask == ALL_VISITED:',
      '    return cost + dist[currCity][START]',
      '  lowerBound = cost + estimateMinRemainingEdges()',
      '  if lowerBound >= bestCost: pruneBranch()',
      '  for each unvisited neighbor v:',
      '    tsp(v, visitedMask | (1 << v), cost + dist[currCity][v])',
      '  update bestTour and bestCost'
    ]
  },

  // Breadth-First Search (BFS)
  bfsTraversal: {
    title: 'Breadth-First Search (BFS)',
    lines: [
      'bfs(startVertex):',
      '  create empty Queue Q; mark startVertex as visited',
      '  Q.enqueue(startVertex)',
      '  while Q is not empty:',
      '    curr = Q.dequeue(); visit(curr)',
      '    for each neighbor v of curr:',
      '      if v is not visited:',
      '        mark v as visited; Q.enqueue(v)'
    ]
  },

  // Depth-First Search (DFS)
  dfsTraversal: {
    title: 'Depth-First Search (DFS)',
    lines: [
      'dfs(startVertex):',
      '  create empty Stack S (or recursion)',
      '  S.push(startVertex)',
      '  while S is not empty:',
      '    curr = S.pop()',
      '    if curr is not visited:',
      '      mark curr as visited; visit(curr)',
      '      for each neighbor v of curr (reversed):',
      '        if v is not visited: S.push(v)'
    ]
  }
};
