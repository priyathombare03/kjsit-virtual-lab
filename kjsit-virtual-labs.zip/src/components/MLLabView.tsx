import React, { useState } from 'react';
import {
  BrainCircuit,
  ArrowLeft,
  ArrowRight,
  Search,
  BookOpen,
  CheckCircle2,
  Filter,
  Sparkles,
  ExternalLink,
  GraduationCap,
  Award,
  Cpu,
  Layers,
  Network,
  Activity,
  Binary
} from 'lucide-react';
import { ML_EXPERIMENTS } from '../data/mlExperiments';
import { LabExperiment, UserSession } from '../types';
import { LaunchLabArrow } from './LaunchLabArrow';

interface MLLabViewProps {
  onSelectExperiment: (experimentId: string) => void;
  onBackToLabs: () => void;
  userSession: UserSession | null;
}

export const MLLabView: React.FC<MLLabViewProps> = ({
  onSelectExperiment,
  onBackToLabs,
  userSession
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [search, setSearch] = useState<string>('');

  const categories = [
    'All',
    'Supervised Learning',
    'Unsupervised Learning',
    'Classification',
    'Neural Networks & Dim Reduction'
  ];

  const filteredExperiments = ML_EXPERIMENTS.filter((exp) => {
    if (selectedCategory !== 'All') {
      if (selectedCategory === 'Supervised Learning' && !exp.category.includes('Supervised')) return false;
      if (selectedCategory === 'Unsupervised Learning' && !exp.category.includes('Unsupervised')) return false;
      if (selectedCategory === 'Classification' && !exp.category.includes('Classification')) return false;
      if (selectedCategory === 'Neural Networks & Dim Reduction' && !exp.category.includes('Neural') && !exp.category.includes('Dimensionality')) return false;
    }

    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        exp.title.toLowerCase().includes(q) ||
        exp.subtitle.toLowerCase().includes(q) ||
        exp.category.toLowerCase().includes(q) ||
        exp.aim.toLowerCase().includes(q) ||
        (exp.iitReference && exp.iitReference.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const getCategoryBadgeColor = (category: string) => {
    if (category.includes('Regression')) return 'bg-blue-100 text-blue-800 border-blue-200';
    if (category.includes('Classification')) return 'bg-purple-100 text-purple-800 border-purple-200';
    if (category.includes('Clustering')) return 'bg-emerald-100 text-emerald-800 border-emerald-200';
    if (category.includes('Neural')) return 'bg-amber-100 text-amber-800 border-amber-200';
    if (category.includes('Dimensionality')) return 'bg-rose-100 text-rose-800 border-rose-200';
    return 'bg-slate-100 text-slate-800 border-slate-200';
  };

  return (
    <div className="py-10 bg-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb & Navigation */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <button
            onClick={onBackToLabs}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-white border border-zinc-300 rounded-xl text-xs font-bold text-zinc-800 hover:bg-zinc-100 transition-colors shadow-2xs cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to All Laboratories</span>
          </button>

          <div className="flex items-center gap-2 text-xs text-zinc-500">
            <span>Home</span>
            <span>/</span>
            <span>Virtual Labs</span>
            <span>/</span>
            <span className="font-bold text-red-700">Machine Learning Lab (CSC601)</span>
          </div>
        </div>

        {/* Subject Header Banner */}
        <div className="bg-black text-white rounded-2xl p-6 sm:p-8 shadow-sm mb-8 relative overflow-hidden border border-zinc-900">
          <div className="max-w-3xl relative z-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-950/90 border border-red-800 text-red-300 text-[10px] font-bold uppercase tracking-widest mb-3">
              <Award className="w-3.5 h-3.5 text-red-400" />
              <span>KJSIT Virtual Lab Curriculum Benchmark • Pattern Recognition & ML</span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white mb-2">
              Machine Learning & Pattern Recognition Laboratory
            </h1>

            <p className="text-xs sm:text-sm font-mono text-red-400 mb-3">
              Course Code: CSC601
            </p>

            <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed mb-6">
              Hands-on interactive simulators for Supervised Learning, Unsupervised Clustering, Decision Trees, Support Vector Machines, Neural Perceptrons, and PCA. Designed strictly in alignment with KJSIT Virtual Labs (vlabs.ac.in) pedagogy.
            </p>

            <div className="flex flex-wrap items-center gap-4 text-xs text-zinc-300 pt-2 border-t border-zinc-900">
              <div className="flex items-center gap-1.5">
                <BrainCircuit className="w-4 h-4 text-red-400" />
                <span><strong className="text-white">9</strong> Interactive Simulators</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-red-400" />
                <span>Hyperparameter Tuning & Live Visual Canvas</span>
              </div>
              <div className="flex items-center gap-1.5">
                <GraduationCap className="w-4 h-4 text-red-400" />
                <span>Pre/Post Lab Quizzes & Python / C++ Code</span>
              </div>
            </div>
          </div>

          {/* Decorative Corner Background Emblem */}
          <div className="absolute right-0 bottom-0 translate-x-8 translate-y-8 opacity-10 pointer-events-none">
            <BrainCircuit className="w-72 h-72 text-red-500" />
          </div>
        </div>

        {/* KJSIT Virtual Lab Reference Banner */}
        <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-4 sm:p-5 mb-8 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-red-700 text-white flex items-center justify-center shrink-0 shadow-sm mt-0.5">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xs sm:text-sm font-bold text-black">
                  National Mission on Education through ICT (MHRD / KJSIT Virtual Labs Alignment)
                </h3>
                <span className="px-2 py-0.5 bg-red-100 text-red-800 font-extrabold text-[9px] rounded-full uppercase">
                  KJSIT Autonomous
                </span>
              </div>
              <p className="text-[11px] text-zinc-600 mt-1 leading-relaxed">
                All 9 experiments adhere to the standard KJSIT Virtual Labs workflow: <strong>Aim → Theory → Algorithm → Interactive Canvas Simulation → Production Python/C++ Code → Assessment Quiz</strong>.
              </p>
            </div>
          </div>
          <a
            href="https://vlab.co.in"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white hover:bg-zinc-100 border border-zinc-300 rounded-xl text-xs font-bold text-red-700 transition-colors shadow-2xs shrink-0 self-start sm:self-center"
          >
            <span>vlabs.ac.in Portal</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* Search & Category Filter Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-4 border-b border-zinc-200">
          {/* Category Tabs */}
          <div className="flex flex-wrap items-center gap-1.5">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-red-700 text-white shadow-xs'
                    : 'bg-white text-zinc-700 hover:bg-zinc-100 border border-zinc-300'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Search Input */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search ML experiments, formulas, algorithms..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3.5 py-1.5 text-xs bg-white border border-zinc-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-600 transition-all placeholder:text-zinc-400"
            />
          </div>
        </div>

        {/* Experiment Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {filteredExperiments.map((exp) => (
            <div
              key={exp.id}
              onClick={() => onSelectExperiment(exp.id)}
              className="bg-red-900/90 backdrop-blur-md border border-red-500/30 rounded-xl flex flex-col justify-between hover:border-red-400 hover:shadow-[0_8px_32px_rgba(185,28,28,0.4)] transition-all group cursor-pointer relative overflow-hidden"
            >
              {/* Optional glassy reflection layer */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
              
              <div className="p-3.5 relative z-10">
                {/* Exp Number + Title beside it */}
                <div className="flex items-start gap-2.5">
                  <span className="w-6 h-6 rounded-md bg-white/20 text-white font-mono text-[11px] font-bold flex items-center justify-center shrink-0 mt-0.5 border border-white/20 shadow-inner">
                    #{exp.num}
                  </span>
                  <div className="min-w-0 flex-1">
                    <h3 className="text-sm font-extrabold text-white group-hover:text-red-100 transition-colors leading-tight drop-shadow-sm">
                      {exp.title}
                    </h3>
                  </div>
                </div>
              </div>

              {/* Card Footer */}
              <div className="px-3.5 py-2.5 bg-red-950/60 border-t border-red-800/50 flex items-center justify-end mt-auto relative z-10">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectExperiment(exp.id);
                  }}
                  className="launch-lab-btn w-full sm:w-auto px-3.5 py-2 sm:py-1.5 bg-white/15 hover:bg-white/25 active:bg-white/35 text-white text-xs font-bold rounded-lg border border-white/20 hover:border-white/35 shadow-xs hover:shadow-md transition-all duration-200 flex items-center justify-center gap-2 active:scale-95 cursor-pointer backdrop-blur-sm select-none"
                  title={`Launch Lab: ${exp.title}`}
                >
                  <span>Launch Lab</span>
                  <LaunchLabArrow />
                </button>
              </div>
            </div>
          ))}
        </div>

        {filteredExperiments.length === 0 && (
          <div className="text-center py-16 bg-white rounded-2xl border border-zinc-200">
            <Search className="w-8 h-8 text-zinc-300 mx-auto mb-2" />
            <h4 className="text-base font-bold text-zinc-800">No experiments match your filter</h4>
            <p className="text-xs text-zinc-500 mt-1">Try resetting the category filter or searching for a different keyword.</p>
            <button
              onClick={() => { setSelectedCategory('All'); setSearch(''); }}
              className="mt-4 px-4 py-2 bg-red-700 text-white text-xs font-bold rounded-lg cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
