import React, { useState, useEffect, useRef } from 'react';
import {
  Gamepad2,
  Play,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Code2,
  Trophy,
  Sparkles,
  ExternalLink,
  Terminal,
  Shield,
  Zap,
  ChevronRight,
  Flame,
  Clock,
  Eye,
  EyeOff,
  Copy,
  Check,
  Plane,
  ArrowRight,
  Layers,
  HelpCircle,
  Cpu,
  Tv,
  Box,
  Volume2,
  VolumeX,
  Compass,
  Film,
  PlusCircle,
  Lightbulb,
  Maximize2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { CodinGamePuzzle } from '../types';
import { ThreeGameViewport } from './game/ThreeGameViewport';
import { TwoDGameViewport } from './game/TwoDGameViewport';
import { CartoonVideoPlayer } from './game/CartoonVideoPlayer';
import { AiCartoonCoach } from './game/AiCartoonCoach';
import { gameAudio } from '../utils/gameAudio';
import { generateAiGameLevel, CartoonScene } from '../utils/aiGameService';

export type SupportedLanguage = 'javascript' | 'python' | 'cpp' | 'c' | 'java';
export type ViewportMode = '3d' | '2d' | 'video';

interface DsaInBuiltGameArenaProps {
  experimentId: string;
  experimentTitle: string;
  puzzles?: CodinGamePuzzle[];
  onProceedToSelfEvaluation?: () => void;
}

// Game definitions for all 8 DSA Experiments
interface GameConfig {
  id: string;
  title: string;
  tagline: string;
  themeColor: string;
  icon: string;
  storyboard: CartoonScene[];
  levels: {
    level: number;
    name: string;
    description: string;
    initialData: any;
    expectedAnswer: string;
    hint: string;
  }[];
}

export const EXPERIMENT_GAMES: Record<string, GameConfig> = {
  'stack-adt-linked-list': {
    id: 'bracket-dungeon',
    title: 'LIFO Vault Escape: The Bracket Dungeon',
    tagline: 'Balance ancient enchanted runes to unlock sealed dungeon gates before the timer runs out!',
    themeColor: 'from-amber-600 to-red-700',
    icon: '🏰',
    storyboard: [
      { speaker: 'Byte the Bot', text: 'Alert! Ancient rune guardians have sealed the dungeon portcullis!', emotion: 'alarmed' },
      { speaker: 'Archmage LIFO', text: 'Cast runes into the pedestal. Every bracket opened must be resolved in reverse order.', emotion: 'determined' },
      { speaker: 'Byte the Bot', text: 'Balance the bracket strings to raise the heavy iron portcullis!', emotion: 'cheering' }
    ],
    levels: [
      {
        level: 1,
        name: 'Gate of Novice Runes',
        description: 'Expression: { [ ( ) ] } - Standard nested brackets.',
        initialData: { expression: '{[()]}' },
        expectedAnswer: 'true',
        hint: 'Every opening bracket must be closed in reverse (LIFO) order.'
      },
      {
        level: 2,
        name: 'The Deceiver Trap',
        description: 'Expression: { [ ( ] ) } - Mismatched cross-nested brackets!',
        initialData: { expression: '{[(])}' },
        expectedAnswer: 'false',
        hint: 'Closing bracket ] encounters ( on top of stack, triggering vault alarm!'
      },
      {
        level: 3,
        name: 'The Citadel of Complex Expressions',
        description: 'Expression: ( ( [ { ( ) } ] ) ) - Deep recursive nesting.',
        initialData: { expression: '(([{(())}]))' },
        expectedAnswer: 'true',
        hint: 'Stack depth reaches 6. All pairs match perfectly.'
      }
    ]
  },
  'linear-queue-adt': {
    id: 'runway-atc',
    title: 'Airport Runway ATC: Circular Buffer Dispatcher',
    tagline: 'Manage incoming flights and runway takeoffs using strict FIFO queue ordering with circular buffer wrap-around!',
    themeColor: 'from-sky-600 to-blue-800',
    icon: '✈️',
    storyboard: [
      { speaker: 'Captain Algo', text: 'Heavy morning fog on the taxiway! Air traffic control radar is coming online.', emotion: 'determined' },
      { speaker: 'Byte the Bot', text: 'First-in flights get takeoff clearance first. Do not allow the circular buffer to overflow!', emotion: 'alarmed' },
      { speaker: 'Captain Algo', text: 'Clear flights AI-101 and BA-202 down runway 27-Left immediately!', emotion: 'cheering' }
    ],
    levels: [
      {
        level: 1,
        name: 'Morning Flight Wave',
        description: 'Enqueue: AI-101, BA-202, EK-303. Dequeue 2 flights. Who departs?',
        initialData: {
          operations: ['ENQUEUE AI-101', 'ENQUEUE BA-202', 'ENQUEUE EK-303', 'DEQUEUE', 'DEQUEUE'],
          capacity: 5
        },
        expectedAnswer: 'AI-101, BA-202',
        hint: 'First In, First Out: The flights that arrived first are given clearance first.'
      },
      {
        level: 2,
        name: 'Circular Buffer Wrap-Around',
        description: 'Buffer size 4. Enqueue 4 flights, dequeue 2, enqueue 2 more flights to wrap around indices!',
        initialData: {
          operations: ['ENQ F1', 'ENQ F2', 'ENQ F3', 'ENQ F4', 'DEQ', 'DEQ', 'ENQ F5', 'ENQ F6'],
          capacity: 4
        },
        expectedAnswer: 'F3, F4, F5, F6',
        hint: 'Rear wraps to index 0: rear = (rear + 1) % capacity. Memory is reused without shifting.'
      },
      {
        level: 3,
        name: 'Emergency Buffer Saturation',
        description: 'Buffer capacity 3. Test queue full condition when 4th flight arrives.',
        initialData: {
          operations: ['ENQ FL-1', 'ENQ FL-2', 'ENQ FL-3', 'ENQ FL-4'],
          capacity: 3
        },
        expectedAnswer: 'QUEUE_FULL',
        hint: 'When (rear + 1) % capacity === front, queue overflow occurs!'
      }
    ]
  },
  'infix-to-postfix': {
    id: 'rpn-asteroid-blaster',
    title: 'Asteroid Defense: Reverse Polish Math Cannon',
    tagline: 'Convert infix radar telemetry to Postfix RPN and calculate exact laser blast frequency to vaporize meteors!',
    themeColor: 'from-purple-600 to-indigo-800',
    icon: '🚀',
    storyboard: [
      { speaker: 'Byte the Bot', text: 'Incoming asteroid storm! Radar telemetry is formatted in complicated infix notation!', emotion: 'alarmed' },
      { speaker: 'Captain Algo', text: 'Switch targeting computer to Reverse Polish Notation (RPN). Operators evaluate immediately.', emotion: 'determined' },
      { speaker: 'Byte the Bot', text: 'Charge the plasma laser and fire at maximum frequency!', emotion: 'cheering' }
    ],
    levels: [
      {
        level: 1,
        name: 'Meteor Alpha: Basic Precedence',
        description: 'Infix: 3 + 5 * 2 -> Convert to Postfix and evaluate yield.',
        initialData: { infix: '3 + 5 * 2' },
        expectedAnswer: '3 5 2 * + = 13',
        hint: 'Multiplication (*) has higher precedence than addition (+), so 5 * 2 = 10; 3 + 10 = 13.'
      },
      {
        level: 2,
        name: 'Meteor Beta: Bracket Override',
        description: 'Infix: ( 3 + 5 ) * 2 -> Parentheses override normal precedence.',
        initialData: { infix: '( 3 + 5 ) * 2' },
        expectedAnswer: '3 5 + 2 * = 16',
        hint: 'Parentheses force addition first: 3 + 5 = 8; then 8 * 2 = 16.'
      },
      {
        level: 3,
        name: 'Mega Asteroid: Multi-operator Blast',
        description: 'Infix: 10 + 20 / 5 * 2 - 3 -> Mixed arithmetic stack evaluation.',
        initialData: { infix: '10 + 20 / 5 * 2 - 3' },
        expectedAnswer: '10 20 5 / 2 * + 3 - = 15',
        hint: 'Left-to-right evaluation of same precedence operators: 20/5 = 4; 4*2 = 8; 10+8 = 18; 18-3 = 15.'
      }
    ]
  },
  'polynomial-arithmetic': {
    id: 'polynomial-alchemy',
    title: 'Spell Alchemy: Battle of Polynomial Powers',
    tagline: 'Traverse sorted linked list spell terms, merge matching degree powers, and forge the ultimate boss counter-spell!',
    themeColor: 'from-emerald-600 to-teal-800',
    icon: '✨',
    storyboard: [
      { speaker: 'Archmage LIFO', text: 'The elemental chaos beast threatens the laboratory sanctum!', emotion: 'alarmed' },
      { speaker: 'Byte the Bot', text: 'Combine polynomial spell ingredients in our linked list alchemy cauldron!', emotion: 'determined' },
      { speaker: 'Archmage LIFO', text: 'Match like terms by exponent and fuse them together into a super-spell!', emotion: 'cheering' }
    ],
    levels: [
      {
        level: 1,
        name: 'Dual Fireball Fusion',
        description: 'P1: 4x^3 + 2x^2 + 5 | P2: 2x^3 + 3x^2 + 1. Add polynomials via linked list.',
        initialData: { p1: '4x^3 + 2x^2 + 5', p2: '2x^3 + 3x^2 + 1' },
        expectedAnswer: '6x^3 + 5x^2 + 6',
        hint: 'Match terms with equal exponents and add their coefficients: (4+2)x^3 + (2+3)x^2 + (5+1).'
      },
      {
        level: 2,
        name: 'Disjoint Degree Term Merge',
        description: 'P1: 5x^4 + 3x^2 + 2 | P2: 2x^3 + 4x + 1. Exponents do not all overlap.',
        initialData: { p1: '5x^4 + 3x^2 + 2', p2: '2x^3 + 4x + 1' },
        expectedAnswer: '5x^4 + 2x^3 + 3x^2 + 4x + 3',
        hint: 'When exponents differ, append the node with the higher exponent first to maintain sorted order.'
      },
      {
        level: 3,
        name: 'Cancelling Shield Term',
        description: 'P1: 3x^2 + 4x + 5 | P2: -3x^2 + 2x + 1. Exponent 2 terms cancel out to zero!',
        initialData: { p1: '3x^2 + 4x + 5', p2: '-3x^2 + 2x + 1' },
        expectedAnswer: '6x + 6',
        hint: '3 + (-3) = 0. Zero coefficient terms are eliminated from the resulting polynomial linked list.'
      }
    ]
  },
  'binary-tree-traversals': {
    id: 'world-tree-harvester',
    title: 'Sacred World Tree: Crystal Rune Harvester',
    tagline: 'Glide along sacred branches of the World Tree, visiting nodes in strict Inorder, Preorder, and Postorder sequences!',
    themeColor: 'from-green-600 to-emerald-900',
    icon: '🌳',
    storyboard: [
      { speaker: 'Byte the Bot', text: 'Welcome to the World Tree canopy! Crystal orbs are glowing on every branch.', emotion: 'cheering' },
      { speaker: 'Captain Algo', text: 'Our drone collector must harvest nodes in exact algorithmic order.', emotion: 'determined' },
      { speaker: 'Byte the Bot', text: 'Inorder gives sorted keys! Preorder duplicates tree structure! Let us harvest!', emotion: 'happy' }
    ],
    levels: [
      {
        level: 1,
        name: 'Shrine of Inorder Harmony',
        description: 'Tree: Root [4], Left [2], Right [6], Children: 1, 3, 5, 7. Perform Inorder (L-Root-R).',
        initialData: { tree: '4(2(1,3), 6(5,7))', traversal: 'INORDER' },
        expectedAnswer: '1 2 3 4 5 6 7',
        hint: 'Inorder visits Left subtree, then Current Node, then Right subtree. In a BST, this yields sorted ascending order!'
      },
      {
        level: 2,
        name: 'Portal of Preorder Awakening',
        description: 'Tree: Root [A], Left [B], Right [C], B children [D, E]. Perform Preorder (Root-L-R).',
        initialData: { tree: 'A(B(D,E), C)', traversal: 'PREORDER' },
        expectedAnswer: 'A B D E C',
        hint: 'Preorder visits Root immediately before recursing down left and right children.'
      },
      {
        level: 3,
        name: 'Cavern of Postorder Harvesting',
        description: 'Tree: Root [10], Left [5(2, 7)], Right [15(12, 20)]. Perform Postorder (L-R-Root).',
        initialData: { tree: '10(5(2,7), 15(12,20))', traversal: 'POSTORDER' },
        expectedAnswer: '2 7 5 12 20 15 10',
        hint: 'Postorder processes all leaves and children before visiting the parent (essential for deleting trees / evaluating RPN).'
      }
    ]
  },
  'binary-search-tree-operations': {
    id: 'bst-crystal-vault',
    title: 'Gemstone Vault: BST Storage Cabinet',
    tagline: 'Store and retrieve glowing crystals following the invariant: Left Subtree < Current Node < Right Subtree!',
    themeColor: 'from-teal-600 to-cyan-900',
    icon: '💎',
    storyboard: [
      { speaker: 'Byte the Bot', text: 'The vault shelves are filling up with priceless algorithmic gemstones!', emotion: 'happy' },
      { speaker: 'Captain Algo', text: 'Remember the core invariant: small crystals branch Left, large crystals branch Right.', emotion: 'determined' },
      { speaker: 'Byte the Bot', text: 'Guarantees O(log N) lookup time for every precious stone in the vault!', emotion: 'cheering' }
    ],
    levels: [
      {
        level: 1,
        name: 'Gem Insertion & Order',
        description: 'Insert Carats: [50, 30, 70, 20, 40]. Where does 40 settle?',
        initialData: { sequence: [50, 30, 70, 20, 40], query: 'locate 40' },
        expectedAnswer: '50 -> Left(30) -> Right(40)',
        hint: '40 < 50 (go Left to 30), 40 > 30 (go Right to 40).'
      },
      {
        level: 2,
        name: 'Vault Search Probe',
        description: 'Search for Gem [65] in tree containing: 50, 30, 70, 60, 80, 65.',
        initialData: { sequence: [50, 30, 70, 60, 80, 65], target: 65 },
        expectedAnswer: 'FOUND (50 -> 70 -> 60 -> 65)',
        hint: 'Compare target with root. If greater, branch right; if smaller, branch left. Takes O(h) steps.'
      },
      {
        level: 3,
        name: 'Successor Replacement on Deletion',
        description: 'Delete Root [50] having two children (Left: 30, Right: 70). Who replaces 50?',
        initialData: { deleteNode: 50, rootChildren: 'L:30, R:70' },
        expectedAnswer: 'INORDER_SUCCESSOR (Smallest value in right subtree)',
        hint: 'To maintain BST invariant when deleting a node with 2 children, replace it with the minimum node in its right subtree.'
      }
    ]
  },
  'graph-traversals-dfs-bfs': {
    id: 'cyber-matrix-hack',
    title: 'Cyber Matrix: Network Infiltration & Routing',
    tagline: 'Deploy cyber probes through network firewalls using BFS wavefront expansion and DFS recursive deep-drilling!',
    themeColor: 'from-cyan-600 to-slate-900',
    icon: '🌐',
    storyboard: [
      { speaker: 'Byte the Bot', text: 'Firewall detected! Cyber routers are blinking across the grid.', emotion: 'alarmed' },
      { speaker: 'Captain Algo', text: 'Deploy Breadth-First Search to find the shortest hop path to the core terminal.', emotion: 'determined' },
      { speaker: 'Byte the Bot', text: 'Queue up the wavefront expansion! Infiltrate routers 0 through 4!', emotion: 'cheering' }
    ],
    levels: [
      {
        level: 1,
        name: 'BFS Radial Scan (Shortest Hops)',
        description: 'Start at Router 0. Neighbors: 1, 2. Router 1 connects to 3. Router 2 connects to 4. Find BFS traversal order.',
        initialData: { start: 0, edges: '0->1, 0->2, 1->3, 2->4' },
        expectedAnswer: '0 1 2 3 4',
        hint: 'BFS uses a Queue to visit all distance-1 neighbors before exploring distance-2 nodes.'
      },
      {
        level: 2,
        name: 'DFS Deep Tunneling Probe',
        description: 'Start at Node 0. Adjacency: 0->1->3, 0->2->4. Follow deep DFS branch first.',
        initialData: { start: 0, mode: 'DFS' },
        expectedAnswer: '0 1 3 2 4',
        hint: 'DFS uses a Stack (or recursion) to plunge as deep as possible along each branch before backtracking.'
      },
      {
        level: 3,
        name: 'Firewall Shortest Path Discovery',
        description: 'Find shortest hop count from Gateway (0) to Mainframe (5) in weighted/unweighted network.',
        initialData: { start: 0, target: 5, hops: 'BFS' },
        expectedAnswer: 'Hops: 3 (Path: 0 -> 2 -> 4 -> 5)',
        hint: 'BFS is guaranteed to discover the shortest path in unweighted graphs because it explores equidistant rings.'
      }
    ]
  },
  'sorting-algorithms-application': {
    id: 'harbor-cargo-crane',
    title: 'Harbor Cargo Crane: Container Terminal Sorter',
    tagline: 'Operate the robotic harbor crane to compare, hoist, and swap heavy freight containers into sorted ascending weight order!',
    themeColor: 'from-orange-600 to-amber-900',
    icon: '🏗️',
    storyboard: [
      { speaker: 'Captain Algo', text: 'Freight ships have docked at the pier! Heavy shipping containers are completely disorganized.', emotion: 'determined' },
      { speaker: 'Byte the Bot', text: 'The crane hydraulic engine is engaged! Hoist, compare, and swap adjacent freight.', emotion: 'cheering' },
      { speaker: 'Captain Algo', text: 'Bubble the heaviest container to the end of the pier in Pass 1!', emotion: 'happy' }
    ],
    levels: [
      {
        level: 1,
        name: 'Light Freight Sort (Pass 1)',
        description: 'Containers: [64, 34, 25, 12, 22, 11, 90]. Run 1st Bubble Sort Pass.',
        initialData: { array: [64, 34, 25, 12, 22, 11, 90] },
        expectedAnswer: '34, 25, 12, 22, 11, 64, 90 (Largest element 90 bubbled to end)',
        hint: 'Adjacent pairs compare and swap if left > right. The maximum element bubbles up to the highest index.'
      },
      {
        level: 2,
        name: 'Quick Sort Pivot Partitioning',
        description: 'Array: [10, 80, 30, 90, 40, 50, 70]. Partition around pivot 70.',
        initialData: { array: [10, 80, 30, 90, 40, 50, 70], pivot: 70 },
        expectedAnswer: 'Left: [10, 30, 40, 50], Pivot: 70, Right: [80, 90]',
        hint: 'Elements smaller than pivot move left, elements greater move right. Pivot locks into its final sorted index!'
      },
      {
        level: 3,
        name: 'Full Port Harmonization',
        description: 'Sort [45, 12, 85, 32, 89, 39, 69, 44, 42, 1, 45] completely.',
        initialData: { array: [45, 12, 85, 32, 89, 39, 69, 44, 42, 1, 45] },
        expectedAnswer: '1, 12, 32, 39, 42, 44, 45, 45, 69, 85, 89',
        hint: 'O(N log N) divide-and-conquer (Merge Sort / Quick Sort) efficiently sorts large arrays in minimal comparisons.'
      }
    ]
  },

  // =========================================================================
  // DAA LABORATORY EXPERIMENTS (1 TO 9)
  // =========================================================================
  'selection-sort': {
    id: 'selection-weather-calibrator',
    title: 'Thermal Station Calibrator: Selection Sort Arena',
    tagline: 'Scan remote meteorological sensor nodes to identify the absolute minimum temperature and lock it into place per pass!',
    themeColor: 'from-amber-600 to-red-800',
    icon: '🌡️',
    storyboard: [
      { speaker: 'Dr. Kelvin', text: 'Attention Meteorologists! Remote sensors have recorded extreme temperature anomalies across districts.', emotion: 'alarmed' },
      { speaker: 'Byte the Bot', text: 'In each pass, find the coldest station and swap it to the front of the telemetry array!', emotion: 'determined' },
      { speaker: 'Dr. Kelvin', text: 'Keep total swaps minimal (at most N-1 swaps) to conserve telemetry satellite bandwidth.', emotion: 'cheering' }
    ],
    levels: [
      {
        level: 1,
        name: 'Pass 1: Coldest District Detection',
        description: 'Readings: [38, 22, 45, 19, 31, 27]°C. Find minimum and swap with index 0.',
        initialData: { temperatures: [38, 22, 45, 19, 31, 27] },
        expectedAnswer: '[19, 22, 45, 38, 31, 27] (19 swapped with 38)',
        hint: 'Minimum value is 19 at index 3. Swap arr[0] and arr[3].'
      },
      {
        level: 2,
        name: 'Pass 2: Sub-Array Calibration',
        description: 'Current Array: [19, 22, 45, 38, 31, 27]. Find minimum from index 1 to 5.',
        initialData: { temperatures: [19, 22, 45, 38, 31, 27], startIndex: 1 },
        expectedAnswer: '[19, 22, 45, 38, 31, 27] (22 is already minimum at index 1, 0 swaps)',
        hint: '22 is already the lowest in the remaining array, so no swap is needed.'
      },
      {
        level: 3,
        name: 'Full Weather Telemetry Harmonization',
        description: 'Sort [42, 18, 35, 12, 29, 24] completely using Selection Sort.',
        initialData: { temperatures: [42, 18, 35, 12, 29, 24] },
        expectedAnswer: '12, 18, 24, 29, 35, 42',
        hint: 'Selection sort makes exactly N-1 passes, always placing the i-th smallest item into position i.'
      }
    ]
  },

  'insertion-sort': {
    id: 'soil-moisture-sorter',
    title: 'Smart Agro Moisture Stream: Insertion Sorter',
    tagline: 'Continuously insert live streaming IoT soil moisture sensor values into an active sorted irrigation array in real-time!',
    themeColor: 'from-emerald-600 to-teal-800',
    icon: '🌱',
    storyboard: [
      { speaker: 'Agronomist Green', text: 'IoT soil moisture probes are transmitting real-time telemetry from wheat crop plots.', emotion: 'determined' },
      { speaker: 'Byte the Bot', text: 'As each sensor streams in, shift higher values to the right and insert the probe into its exact sorted position!', emotion: 'cheering' },
      { speaker: 'Agronomist Green', text: 'Insertion Sort runs in O(N) linear time for nearly sorted telemetry streams!', emotion: 'happy' }
    ],
    levels: [
      {
        level: 1,
        name: 'Insert Incoming Probe',
        description: 'Sorted Probes: [15, 28, 45, 60]. New live probe reading: 33%. Insert into correct position.',
        initialData: { sortedArray: [15, 28, 45, 60], newKey: 33 },
        expectedAnswer: '[15, 28, 33, 45, 60]',
        hint: '33 is smaller than 60 and 45, so shift them right and place 33 after 28.'
      },
      {
        level: 2,
        name: 'Multiple Stream Influx',
        description: 'Active array: [12, 34, 56]. Stream [20, 15] sequentially into the array.',
        initialData: { initial: [12, 34, 56], stream: [20, 15] },
        expectedAnswer: '[12, 15, 20, 34, 56]',
        hint: 'Insert 20 -> [12, 20, 34, 56]. Then insert 15 -> [12, 15, 20, 34, 56].'
      },
      {
        level: 3,
        name: 'High-Speed Irrigation Harmonization',
        description: 'Sort IoT array [65, 22, 58, 14, 43, 81] in ascending order using card shifts.',
        initialData: { readings: [65, 22, 58, 14, 43, 81] },
        expectedAnswer: '14, 22, 43, 58, 65, 81',
        hint: 'Maintain a growing sorted prefix on the left, inserting elements one by one.'
      }
    ]
  },

  'merge-sort': {
    id: 'village-grain-merger',
    title: 'Smart Granary Silo: Divide-and-Conquer Merger',
    tagline: 'Divide large agricultural village datasets into atomic sub-problems and merge sorted grain batches with guaranteed O(N log N) speed!',
    themeColor: 'from-amber-600 to-yellow-800',
    icon: '🌾',
    storyboard: [
      { speaker: 'Silo Controller', text: 'Incoming grain crates from northern and southern farm clusters have arrived at the centralized silo.', emotion: 'determined' },
      { speaker: 'Byte the Bot', text: 'Divide the datasets into halves, conquer recursively, and merge two sorted streams using two pointers!', emotion: 'cheering' },
      { speaker: 'Silo Controller', text: 'Guaranteed O(N log N) worst-case time complexity ensures no truck waits at the terminal.', emotion: 'happy' }
    ],
    levels: [
      {
        level: 1,
        name: 'Two-Pointer Stream Merge',
        description: 'North Silo: [14, 32, 67]. South Silo: [19, 45, 80]. Merge both into one ascending list.',
        initialData: { listA: [14, 32, 67], listB: [19, 45, 80] },
        expectedAnswer: '[14, 19, 32, 45, 67, 80]',
        hint: 'Compare heads of both lists: 14 < 19, 19 < 32, 32 < 45, 45 < 67, 67 < 80, 80.'
      },
      {
        level: 2,
        name: 'Recursive Divide Step',
        description: 'Array size 8: [38, 27, 43, 3, 9, 82, 10, 15]. What is the tree depth of recursive division?',
        initialData: { size: 8 },
        expectedAnswer: 'Depth = 3 (log2 8 = 3 levels of division)',
        hint: '8 -> 4,4 -> 2,2,2,2 -> 1,1,1,1,1,1,1,1. Tree depth is log2(N).'
      },
      {
        level: 3,
        name: 'Grand Regional Granary Harmonization',
        description: 'Sort [75, 23, 98, 44, 57, 12, 36, 68] using Merge Sort.',
        initialData: { crates: [75, 23, 98, 44, 57, 12, 36, 68] },
        expectedAnswer: '12, 23, 36, 44, 57, 68, 75, 98',
        hint: 'Divide until singletons, then merge adjacent pairs upwards.'
      }
    ]
  },

  'quick-sort': {
    id: 'heatwave-pivot-zone',
    title: 'Climate Hazard Classifier: Quick Sort Pivot Arena',
    tagline: 'Partition atmospheric temperature sensor telemetry around a dynamic pivot to segregate cool vs hazard heat zones!',
    themeColor: 'from-orange-600 to-red-900',
    icon: '⚡',
    storyboard: [
      { speaker: 'Climate Scientist', text: 'Extreme heatwave warning! Temperatures must be partitioned immediately around the critical heat threshold.', emotion: 'alarmed' },
      { speaker: 'Byte the Bot', text: 'Select the pivot element, partition smaller temperatures to the left and extreme heat to the right in O(N) time!', emotion: 'determined' },
      { speaker: 'Climate Scientist', text: 'The pivot locks into its permanent sorted index after each partition pass!', emotion: 'cheering' }
    ],
    levels: [
      {
        level: 1,
        name: 'Lomuto Partition Step',
        description: 'Telemetry: [35, 12, 48, 22, 60, 30]. Pivot = 30 (last element). Partition array.',
        initialData: { array: [35, 12, 48, 22, 60, 30], pivot: 30 },
        expectedAnswer: '[12, 22, 30, 35, 60, 48] (Pivot 30 at index 2)',
        hint: 'Elements < 30 are [12, 22]. Pivot 30 lands between smaller and larger elements.'
      },
      {
        level: 2,
        name: 'Hoare Partition Efficiency',
        description: 'Why is Quick Sort average case O(N log N) faster than Merge Sort in practice?',
        initialData: { question: 'Cache locality and in-place partitioning' },
        expectedAnswer: 'In-place partitioning with zero extra memory allocation and excellent CPU cache locality.',
        hint: 'Quick sort requires no O(N) auxiliary merge array and has low constant factors.'
      },
      {
        level: 3,
        name: 'Full Heatwave Hazard Partition',
        description: 'Sort [52, 28, 77, 19, 64, 43] using Quick Sort recursion.',
        initialData: { array: [52, 28, 77, 19, 64, 43] },
        expectedAnswer: '19, 28, 43, 52, 64, 77',
        hint: 'Partition around pivot, then recursively sort left and right partitions.'
      }
    ]
  },

  'kruskals': {
    id: 'wireless-island-mst',
    title: 'Island Archipelago: Kruskal Minimum Spanning Mesh',
    tagline: 'Connect isolated remote island IoT sensor nodes with minimum total fiber optic / wireless laser link cost without forming cycles!',
    themeColor: 'from-cyan-600 to-blue-900',
    icon: '🌐',
    storyboard: [
      { speaker: 'Network Architect', text: 'Archipelago communications are down! We need to connect all 6 islands with minimum total cabling cost.', emotion: 'determined' },
      { speaker: 'Byte the Bot', text: 'Sort all candidate edges in ascending order of cost. Pick edges greedily using Union-Find Disjoint Sets!', emotion: 'cheering' },
      { speaker: 'Network Architect', text: 'Never pick an edge that connects two nodes in the same set — cycles waste valuable power!', emotion: 'alarmed' }
    ],
    levels: [
      {
        level: 1,
        name: 'Greedy Edge Selection',
        description: 'Sorted Candidate Edges: (A-B: 2), (B-C: 3), (A-C: 4), (C-D: 5). Which edge is rejected to prevent a cycle?',
        initialData: { edges: [{ u: 'A', v: 'B', w: 2 }, { u: 'B', v: 'C', w: 3 }, { u: 'A', v: 'C', w: 4 }, { u: 'C', v: 'D', w: 5 }] },
        expectedAnswer: 'Reject (A-C: 4) because A and C are already connected via A-B-C.',
        hint: 'Connecting A and C would create closed cycle A-B-C-A.'
      },
      {
        level: 2,
        name: 'Disjoint Set Union-Find',
        description: 'How many edges are present in a Minimum Spanning Tree for a connected graph with V vertices?',
        initialData: { vertices: 'V' },
        expectedAnswer: 'V - 1 edges exactly.',
        hint: 'A tree spanning V vertices always contains exactly V - 1 edges without any cycles.'
      },
      {
        level: 3,
        name: 'Full Island Mesh Optimization',
        description: 'Find MST weight for 5 nodes with edges (1-2: 1), (1-3: 3), (2-3: 2), (2-4: 4), (3-4: 5), (4-5: 7).',
        initialData: { nodes: 5 },
        expectedAnswer: 'Total MST Weight = 1 + 2 + 4 + 7 = 14',
        hint: 'Select edges (1-2: 1), (2-3: 2), (2-4: 4), (4-5: 7). Edge (1-3: 3) creates a cycle and is skipped.'
      }
    ]
  },

  'tsp': {
    id: 'drone-logistics-tsp',
    title: 'Drone Fleet Navigator: Traveling Salesperson Tour',
    tagline: 'Compute optimal shortest Hamiltonian flight cycle for delivery drones visiting every customer hub exactly once and returning to depot!',
    themeColor: 'from-purple-600 to-indigo-900',
    icon: '🚁',
    storyboard: [
      { speaker: 'Fleet Dispatcher', text: 'High-priority vaccine supplies must be dispatched to 5 smart medical centers across the city.', emotion: 'determined' },
      { speaker: 'Byte the Bot', text: 'The drone must visit every clinic exactly once and return to Central Hospital depot with minimal battery usage!', emotion: 'alarmed' },
      { speaker: 'Fleet Dispatcher', text: 'Use dynamic programming with bitmask memoization to solve the NP-hard TSP in O(N^2 * 2^N) time!', emotion: 'cheering' }
    ],
    levels: [
      {
        level: 1,
        name: '3-Hub Triangular Flight',
        description: 'Distances: A-B = 10, B-C = 15, C-A = 20. Calculate total round trip tour distance A -> B -> C -> A.',
        initialData: { tour: ['A', 'B', 'C', 'A'], distances: { 'A-B': 10, 'B-C': 15, 'C-A': 20 } },
        expectedAnswer: '45 km (10 + 15 + 20)',
        hint: 'Sum all legs of the closed circuit loop.'
      },
      {
        level: 2,
        name: 'Bitmask State Representation',
        description: 'If 4 cities are visited, what does bitmask 1011 (binary) represent if city 0 is depot?',
        initialData: { mask: '1011', cities: [0, 1, 2, 3] },
        expectedAnswer: 'Cities 0, 1, and 3 have been visited; City 2 is unvisited.',
        hint: 'Bits 0, 1, 3 are 1 (visited), bit 2 is 0 (unvisited).'
      },
      {
        level: 3,
        name: 'Optimal 4-City Hamiltonian Cycle',
        description: 'Determine minimum cost tour starting at city 0 with distance matrix [[0,10,15,20],[10,0,35,25],[15,35,0,30],[20,25,30,0]].',
        initialData: { n: 4 },
        expectedAnswer: '80 (Tour: 0 -> 1 -> 3 -> 2 -> 0 = 10 + 25 + 30 + 15 = 80)',
        hint: 'Evaluate tours: 0-1-3-2-0 yields 10+25+30+15 = 80.'
      }
    ]
  },

  'n-queen': {
    id: 'chessboard-matrix-defense',
    title: 'Holographic Chess Matrix: N-Queens Backtracking',
    tagline: 'Position holographic defense queens on an N x N cyber chessboard so that no two queens threaten each other along rows, columns, or diagonals!',
    themeColor: 'from-pink-600 to-rose-900',
    icon: '👑',
    storyboard: [
      { speaker: 'Grandmaster AI', text: 'Hostile intrusion detected in the quantum CPU grid! Queens must be deployed to establish impenetrable perimeter.', emotion: 'alarmed' },
      { speaker: 'Byte the Bot', text: 'No two queens can occupy the same column, row, or diagonal! Place queen row-by-row.', emotion: 'determined' },
      { speaker: 'Grandmaster AI', text: 'If a collision occurs, backtrack immediately to explore valid branch alternatives!', emotion: 'cheering' }
    ],
    levels: [
      {
        level: 1,
        name: '4-Queens Classic Board',
        description: 'Place 4 Queens on a 4x4 grid. If Q0 is at column 1 (0-indexed: [., Q, ., .]), where does Q1 go in row 1?',
        initialData: { n: 4, row0_col: 1 },
        expectedAnswer: 'Column 3 (row 1, col 3). (Col 0 conflicts diagonally, col 1 in column, col 2 diagonally)',
        hint: 'Row 1 Col 3 has no diagonal or column conflict with (Row 0, Col 1).'
      },
      {
        level: 2,
        name: 'Diagonal Conflict Formula',
        description: 'How do you check diagonal conflict between Queen at (r1, c1) and Queen at (r2, c2)?',
        initialData: { r1: 'r1', c1: 'c1', r2: 'r2', c2: 'c2' },
        expectedAnswer: 'Math.abs(r1 - r2) === Math.abs(c1 - c2)',
        hint: 'Slope of diagonals on square grid is always +1 or -1, so delta row equals delta col.'
      },
      {
        level: 3,
        name: 'Complete 4-Queens Solution',
        description: 'Provide the full valid permutation of column indices for 4-Queens.',
        initialData: { n: 4 },
        expectedAnswer: '[1, 3, 0, 2] or [2, 0, 3, 1]',
        hint: 'Solution 1: [1, 3, 0, 2] (Row 0: col 1, Row 1: col 3, Row 2: col 0, Row 3: col 2).'
      }
    ]
  },

  'sum-of-subsets': {
    id: 'vault-crystal-weighing',
    title: 'Cyber Vault Equilibrium: Sum of Subsets Arena',
    tagline: 'Explore state-space tree branches to select exact combinations of energy crystals that sum up precisely to target vault threshold!',
    themeColor: 'from-amber-600 to-indigo-900',
    icon: '⚖️',
    storyboard: [
      { speaker: 'Vault Guardian', text: 'The quantum containment vault door requires an exact combined energy mass of W to disengage locks.', emotion: 'alarmed' },
      { speaker: 'Byte the Bot', text: 'For each energy crystal, choose to include or exclude it in the subset!', emotion: 'determined' },
      { speaker: 'Vault Guardian', text: 'Prune branches early if current sum exceeds target or if remaining sum is insufficient to reach W!', emotion: 'cheering' }
    ],
    levels: [
      {
        level: 1,
        name: '3-Crystal Resonance',
        description: 'Crystals: [5, 10, 15, 20]. Target Sum: 25. Which two subsets achieve exact target?',
        initialData: { set: [5, 10, 15, 20], target: 25 },
        expectedAnswer: '{10, 15} and {5, 20}',
        hint: '10 + 15 = 25 and 5 + 20 = 25.'
      },
      {
        level: 2,
        name: 'State Space Pruning (Bounding)',
        description: 'If Target = 30 and current sum is 32, what action does the backtracking algorithm take?',
        initialData: { currentSum: 32, target: 30 },
        expectedAnswer: 'Prune / Backtrack immediately: Current sum exceeds target sum.',
        hint: 'Since all crystal values are positive, adding more elements will only increase sum beyond 30.'
      },
      {
        level: 3,
        name: 'Complex Vault Unlock',
        description: 'Set: [3, 5, 7, 11, 13, 17]. Target Sum: 25. Find a 3-element subset.',
        initialData: { set: [3, 5, 7, 11, 13, 17], target: 25 },
        expectedAnswer: '{5, 7, 13} (5 + 7 + 13 = 25) or {3, 5, 17}',
        hint: '5 + 7 = 12; 12 + 13 = 25. Perfect match!'
      }
    ]
  },

  'kmp': {
    id: 'dna-cyber-scanner',
    title: 'Cyber Recon Scanner: Knuth-Morris-Pratt Pattern Matcher',
    tagline: 'Scan gigabyte data streams for virus signatures and DNA sequences without ever backtracking the main text pointer using the Pi/LPS prefix table!',
    themeColor: 'from-emerald-600 to-cyan-900',
    icon: '🧬',
    storyboard: [
      { speaker: 'Bioinformatics Analyst', text: 'Viral genetic code detected in streaming sequencer! We must locate pattern matches at wire speed.', emotion: 'alarmed' },
      { speaker: 'Byte the Bot', text: 'Precompute the Longest Proper Prefix which is also a Suffix (LPS) table for the pattern.', emotion: 'determined' },
      { speaker: 'Bioinformatics Analyst', text: 'When a mismatch occurs, shift pattern using LPS values instead of resetting the text index!', emotion: 'cheering' }
    ],
    levels: [
      {
        level: 1,
        name: 'LPS Table Computation',
        description: 'Pattern: "ABABC". What is the LPS array for prefix matches?',
        initialData: { pattern: 'ABABC' },
        expectedAnswer: 'LPS = [0, 0, 1, 2, 0]',
        hint: 'For "ABA", prefix "A" matches suffix "A" (len 1). For "ABAB", prefix "AB" matches suffix "AB" (len 2).'
      },
      {
        level: 2,
        name: 'Zero-Backtracking Search',
        description: 'Text pointer index: i. In KMP, why does i never move backward?',
        initialData: { textPointer: 'i' },
        expectedAnswer: 'LPS table tells us the longest prefix that is already matched, allowing pattern pointer j to shift while i continues forward monotonically.',
        hint: 'KMP guarantees strict O(N) linear time by never decrementing the text index.'
      },
      {
        level: 3,
        name: 'Find Signature Occurrences',
        description: 'Text: "AABAACAADAABAABA". Pattern: "AABA". At which 0-based indices does pattern appear?',
        initialData: { text: 'AABAACAADAABAABA', pattern: 'AABA' },
        expectedAnswer: 'Indices 0, 9, 12',
        hint: 'Matches occur at index 0 ("AABA"), index 9 ("AABA"), and index 12 ("AABA").'
      }
    ]
  },

  // =========================================================================
  // OOPM LABORATORY EXPERIMENTS (EXP 1 TO EXP 10)
  // =========================================================================
  'oopm-exp1': {
    id: 'cyber-io-gateway',
    title: 'Cyber Terminal I/O Gateway: Scanner vs BufferedReader Protocol',
    tagline: 'Stream formatted student tokens (Name, Age, City, PIN) through character and byte streams without buffer overflow!',
    themeColor: 'from-blue-600 to-indigo-900',
    icon: '⌨️',
    storyboard: [
      { speaker: 'Dr. Byte', text: 'Welcome to the Java I/O Terminal Gateway! Fast data ingestion is required for high-throughput records.', emotion: 'determined' },
      { speaker: 'Byte the Bot', text: 'BufferedReader reads synchronized character blocks at lightning speed, while Scanner parses formatted primitives!', emotion: 'cheering' },
      { speaker: 'Dr. Byte', text: 'Handle checked IOExceptions properly with try-catch blocks to prevent stream drops.', emotion: 'happy' }
    ],
    levels: [
      {
        level: 1,
        name: 'Scanner Token Stream',
        description: 'Input stream: "Priya 20 Mumbai 400077". Parse each token with Scanner next(), nextInt().',
        initialData: { stream: 'Priya 20 Mumbai 400077' },
        expectedAnswer: 'Name: Priya, Age: 20, City: Mumbai, PIN: 400077',
        hint: 'Scanner uses whitespace delimiters by default to tokenize mixed primitives.'
      },
      {
        level: 2,
        name: 'BufferedReader Line Extraction',
        description: 'Read complete input line via reader.readLine() and parse Integer.parseInt(age).',
        initialData: { line: 'Omkar 21 Pune 411001' },
        expectedAnswer: 'Successfully converted Age string to primitive int 21.',
        hint: 'BufferedReader returns String; Integer.parseInt() converts to primitive int.'
      },
      {
        level: 3,
        name: 'High-Throughput Benchmark',
        description: 'Ingest 10,000 telemetry records. Why is BufferedReader 10x faster than Scanner?',
        initialData: { records: 10000 },
        expectedAnswer: 'BufferedReader uses an 8KB internal buffer and single readLine() calls without regex overhead.',
        hint: 'Scanner employs regular expressions internally, causing extra CPU cycles.'
      }
    ]
  },

  'oopm-exp2': {
    id: 'atm-control-matrix',
    title: 'Cyber ATM Vault: Menu-Driven State Machine',
    tagline: 'Direct banking transaction flows (Deposit, Withdraw, Balance, PIN) using do-while loops and switch-case branching!',
    themeColor: 'from-emerald-600 to-teal-900',
    icon: '🏧',
    storyboard: [
      { speaker: 'Security Chief', text: 'ATM Automated Teller Terminal online. Customer authentication requested.', emotion: 'determined' },
      { speaker: 'Byte the Bot', text: 'Dispatch menu actions 1 to 4 using switch-case. Reject invalid choices with default statements!', emotion: 'cheering' },
      { speaker: 'Security Chief', text: 'Ensure withdrawal amounts do not exceed current balance before debiting account.', emotion: 'alarmed' }
    ],
    levels: [
      {
        level: 1,
        name: 'Menu Option Dispatch',
        description: 'User enters choice 2 (Withdrawal) for ₹5,000 with initial balance ₹20,000.',
        initialData: { balance: 20000, choice: 2, amount: 5000 },
        expectedAnswer: 'Withdrawal Successful. New Balance: ₹15,000.',
        hint: 'Switch on choice: Case 2 subtracts withdrawal amount after checking balance >= amount.'
      },
      {
        level: 2,
        name: 'Invalid PIN Guard',
        description: 'Verify 4-digit PIN with do-while loop giving maximum 3 consecutive attempts.',
        initialData: { correctPin: 2350, enteredPins: [1111, 2222, 2350] },
        expectedAnswer: 'Access Granted on Attempt 3.',
        hint: 'Loop condition: attempts < 3 && !pinMatched.'
      },
      {
        level: 3,
        name: 'Autonomous Session Termination',
        description: 'Select Option 4 (Exit). Break loop and display thank you summary.',
        initialData: { choice: 4 },
        expectedAnswer: 'Session Terminated. Card Ejected.',
        hint: 'Case 4 sets running flag to false or breaks out of do-while loop.'
      }
    ]
  },

  'oopm-exp3': {
    id: 'object-foundry-student',
    title: 'Object Foundry: Student & Employee Heap Factory',
    tagline: 'Instantiate real-world entities in the JVM heap using "new", encapsulating private fields and invoking methods!',
    themeColor: 'from-amber-600 to-orange-900',
    icon: '🏛️',
    storyboard: [
      { speaker: 'Architect Java', text: 'A Class is a blueprint, an Object is a living instance allocated on the JVM Heap!', emotion: 'determined' },
      { speaker: 'Byte the Bot', text: 'Private fields protect data encapsulation. Use getters and setters to access state safely.', emotion: 'cheering' },
      { speaker: 'Architect Java', text: 'Instantiate Student s1 = new Student() and assign Somaiya Roll No!', emotion: 'happy' }
    ],
    levels: [
      {
        level: 1,
        name: 'Heap Object Allocation',
        description: 'Instantiate Student s1 with Roll No 16010123045 and Name "Priya". Where does s1 live?',
        initialData: { rollNo: '16010123045', name: 'Priya' },
        expectedAnswer: 's1 reference lives on Stack; Student object instance lives on JVM Heap memory.',
        hint: 'Reference variables reside on the call stack pointing to heap memory blocks.'
      },
      {
        level: 2,
        name: 'Encapsulated Getter & Setter',
        description: 'Validate CGPA input: If CGPA > 10.0, clamp to 10.0. Set CGPA = 9.8.',
        initialData: { cgpa: 9.8 },
        expectedAnswer: 'CGPA 9.8 validated and stored in private double field.',
        hint: 'Setters enforce business validation rules prior to assignment.'
      },
      {
        level: 3,
        name: 'Array of Objects',
        description: 'Create Student[] array of size 3 and compute batch average marks [85, 92, 78].',
        initialData: { marks: [85, 92, 78] },
        expectedAnswer: 'Batch Average: 85.0 marks.',
        hint: 'Iterate over Student array invoking student.getMarks() on each index.'
      }
    ]
  },

  'oopm-exp4': {
    id: 'constructor-forge',
    title: 'Constructor Forge: Blueprint Lifecycle Altar',
    tagline: 'Control object lifecycle birth with default, parameterized, and overloaded constructors using this() chaining!',
    themeColor: 'from-purple-600 to-indigo-900',
    icon: '🔨',
    storyboard: [
      { speaker: 'Forge Master', text: 'Constructors execute automatically upon object instantiation to initialize invariants!', emotion: 'determined' },
      { speaker: 'Byte the Bot', text: 'Use this(title, author) constructor chaining to delegate parameter initialization cleanly.', emotion: 'cheering' },
      { speaker: 'Forge Master', text: 'No return type allowed, matching class name exactly!', emotion: 'happy' }
    ],
    levels: [
      {
        level: 1,
        name: 'Default Constructor Zero-State',
        description: 'Instantiate Book b1 = new Book(). What are default values for int and String?',
        initialData: { class: 'Book' },
        expectedAnswer: 'Default values: int = 0, double = 0.0, Object reference = null.',
        hint: 'JVM initializes unassigned instance variables to standard default values.'
      },
      {
        level: 2,
        name: 'Parameterized Rectangle Forge',
        description: 'Instantiate Rectangle r = new Rectangle(12.5, 8.0). Calculate area.',
        initialData: { width: 12.5, height: 8.0 },
        expectedAnswer: 'Area = 100.0 sq units.',
        hint: 'Constructor assigns this.width = 12.5 and this.height = 8.0.'
      },
      {
        level: 3,
        name: 'Constructor Overloading Chaining',
        description: 'BankAccount account = new BankAccount("Priya"). Initial balance defaults to ₹10,000 via this("Priya", 10000).',
        initialData: { name: 'Priya', defaultBal: 10000 },
        expectedAnswer: 'Account created for Priya with chained default balance ₹10,000.',
        hint: 'this(...) must be the very first statement inside the constructor.'
      }
    ]
  },

  'oopm-exp5': {
    id: 'polymorphic-arena',
    title: 'Polymorphic Arena: Medical Hierarchy Dynamic Dispatch',
    tagline: 'Extend superclass MedicalTest with UrineTest, BloodTest & GlucoseTest, overriding calculateRisk() dynamically!',
    themeColor: 'from-rose-600 to-pink-900',
    icon: '🧬',
    storyboard: [
      { speaker: 'Chief Pathologist', text: 'Medical diagnostic system hierarchy active. Superclass MedicalTest is deployed.', emotion: 'determined' },
      { speaker: 'Byte the Bot', text: 'Child classes UrineTest and BloodTest inherit patient fields and override calculateRisk()!', emotion: 'cheering' },
      { speaker: 'Chief Pathologist', text: 'Dynamic method dispatch executes the subclass version at runtime through superclass references.', emotion: 'happy' }
    ],
    levels: [
      {
        level: 1,
        name: 'Superclass Inheritance & extends',
        description: 'Class UrineTest extends MedicalTest. Which superclass constructor is invoked first?',
        initialData: { superclass: 'MedicalTest', subclass: 'UrineTest' },
        expectedAnswer: 'super() is invoked first before the subclass constructor body executes.',
        hint: 'Java guarantees superclass state is initialized prior to subclass construction.'
      },
      {
        level: 2,
        name: 'Runtime Dynamic Method Dispatch',
        description: 'MedicalTest test = new GlucoseTest(180 mg/dL). Which calculateRisk() method runs?',
        initialData: { ref: 'MedicalTest', obj: 'GlucoseTest', reading: 180 },
        expectedAnswer: 'GlucoseTest.calculateRisk() runs at runtime via JVM virtual method table (vtable).',
        hint: 'Method resolution is dynamic based on the actual object type in heap memory.'
      },
      {
        level: 3,
        name: 'Super Keyword Invocation',
        description: 'Subclass calls super.displayReport() to print base patient information first.',
        initialData: { call: 'super.displayReport()' },
        expectedAnswer: 'Executes parent method displayReport() and appends specialized test parameters.',
        hint: 'The super keyword references immediate superclass methods and variables.'
      }
    ]
  },

  'oopm-exp6': {
    id: 'interface-weather-mesh',
    title: 'Interface Weather Mesh: Multi-Service Decoupler',
    tagline: 'Realize 100% pure abstraction connecting SensorWeatherProvider, ForecastService & AlertService via interfaces!',
    themeColor: 'from-cyan-600 to-blue-900',
    icon: '🌐',
    storyboard: [
      { speaker: 'Meteorology Architect', text: 'Design a decoupled Weather Monitoring System using 100% pure Java interfaces.', emotion: 'determined' },
      { speaker: 'Byte the Bot', text: 'A single class can implement multiple interfaces! WeatherDataProvider and AlertService unite.', emotion: 'cheering' },
      { speaker: 'Meteorology Architect', text: 'Loose coupling allows swapping SensorProvider with AIForecastProvider with zero breaking changes.', emotion: 'happy' }
    ],
    levels: [
      {
        level: 1,
        name: 'Interface Contract Definition',
        description: 'Interface WeatherDataProvider has method double getTemperature(). What are its implicit modifiers?',
        initialData: { interface: 'WeatherDataProvider' },
        expectedAnswer: 'public abstract double getTemperature(); (public abstract is implicit)',
        hint: 'All interface methods in Java are public abstract by default unless declared default/static.'
      },
      {
        level: 2,
        name: 'Multiple Interface Implementation',
        description: 'Class SmartWeatherHub implements WeatherDataProvider, SMSAlertService. Valid in Java?',
        initialData: { interfaces: 2 },
        expectedAnswer: 'YES: Java allows implementing multiple interfaces, overcoming single class inheritance.',
        hint: 'Java supports multiple inheritance of type via interfaces.'
      },
      {
        level: 3,
        name: 'Polymorphic Interface Reference',
        description: 'WeatherDataProvider p = new SensorWeatherProvider(). Call p.getTemperature().',
        initialData: { ref: 'Interface', obj: 'SensorWeatherProvider' },
        expectedAnswer: 'Returns live sensor reading 31.4°C via decoupled polymorphic reference.',
        hint: 'Client code programs to the interface, not the concrete implementation.'
      }
    ]
  },

  'oopm-exp7': {
    id: 'exception-shield-bank',
    title: 'Fault-Tolerant Fortress: Exception Shield & InsufficientBalance Guard',
    tagline: 'Wrap risky banking transactions in try-catch-finally blocks and throw custom InsufficientBalanceException!',
    themeColor: 'from-red-600 to-rose-900',
    icon: '🛡️',
    storyboard: [
      { speaker: 'Bank Security AI', text: 'Warning: Illegal transaction spike detected! System resilience shield is active.', emotion: 'alarmed' },
      { speaker: 'Byte the Bot', text: 'If withdrawal amount exceeds account balance, throw custom InsufficientBalanceException!', emotion: 'determined' },
      { speaker: 'Bank Security AI', text: 'The finally block executes unconditionally to safely close database transactions and audit logs.', emotion: 'cheering' }
    ],
    levels: [
      {
        level: 1,
        name: 'Try-Catch Block Defense',
        description: 'Balance: ₹8,000. Customer requests withdrawal of ₹12,000. Catch exception.',
        initialData: { balance: 8000, withdrawal: 12000 },
        expectedAnswer: 'Caught InsufficientBalanceException: Deficit of ₹4,000. Transaction aborted.',
        hint: 'Throw new InsufficientBalanceException("Withdrawal exceeds balance").'
      },
      {
        level: 2,
        name: 'Checked vs Unchecked Exceptions',
        description: 'Custom InsufficientBalanceException extends Exception. Is it checked or unchecked?',
        initialData: { extends: 'Exception' },
        expectedAnswer: 'Checked Exception: Must be caught using try-catch or declared with "throws".',
        hint: 'Classes extending java.lang.Exception (except RuntimeException) are checked.'
      },
      {
        level: 3,
        name: 'Finally Block Guarantee',
        description: 'Will the finally block execute if an exception is caught in the catch block?',
        initialData: { block: 'finally' },
        expectedAnswer: 'YES: The finally block ALWAYS executes regardless of exception occurrence.',
        hint: 'Finally is designed for cleanup operations like closing streams and database locks.'
      }
    ]
  },

  'oopm-exp8': {
    id: 'disk-archivist-files',
    title: 'Disk Archivist: Persistent Diagnostic File Vault',
    tagline: 'Persist clinical urine test strip results to disk files with FileWriter and deserialize with BufferedReader streams!',
    themeColor: 'from-amber-600 to-emerald-900',
    icon: '💾',
    storyboard: [
      { speaker: 'Laboratory Archivist', text: 'Patient diagnostic records must be persisted permanently to disk storage.', emotion: 'determined' },
      { speaker: 'Byte the Bot', text: 'FileWriter records patient health metrics, and BufferedReader reads records line by line!', emotion: 'cheering' },
      { speaker: 'Laboratory Archivist', text: 'Always close file streams in a finally block or use try-with-resources to avoid file locks.', emotion: 'happy' }
    ],
    levels: [
      {
        level: 1,
        name: 'File Write Stream',
        description: 'Write record "P101,Leukocytes:Negative,pH:6.5" to urine_reports.txt using FileWriter.',
        initialData: { record: 'P101,Leukocytes:Negative,pH:6.5' },
        expectedAnswer: 'Record successfully flushed and committed to persistent disk file.',
        hint: 'FileWriter writer = new FileWriter("urine_reports.txt", true);'
      },
      {
        level: 2,
        name: 'Buffered Line Ingestion',
        description: 'Read reports line by line with reader.readLine() until EOF (null).',
        initialData: { lines: 3 },
        expectedAnswer: 'Read 3 clinical test reports without dropping characters.',
        hint: 'while ((line = reader.readLine()) != null) processReport(line);'
      },
      {
        level: 3,
        name: 'Try-With-Resources Auto-Close',
        description: 'Why is try (BufferedReader br = new BufferedReader(...)) superior in Java 7+?',
        initialData: { feature: 'try-with-resources' },
        expectedAnswer: 'Automatically closes file descriptors even if exceptions occur, preventing resource leaks.',
        hint: 'Any class implementing java.lang.AutoCloseable is closed automatically.'
      }
    ]
  },

  'oopm-exp9': {
    id: 'thread-worker-trio',
    title: 'Thread Synchronizer: Parallel Worker Tri-Core',
    tagline: 'Schedule Thread 1 (Random Number Generator), Thread 2 (Square Calculator) & Thread 3 (Cube Calculator) concurrently!',
    themeColor: 'from-yellow-600 to-red-900',
    icon: '⚡',
    storyboard: [
      { speaker: 'Quantum Core', text: 'Multi-threaded processor online. Concurrency scheduler ready.', emotion: 'determined' },
      { speaker: 'Byte the Bot', text: 'Thread 1 generates random numbers every 1 second. Even numbers square, odd numbers cube!', emotion: 'cheering' },
      { speaker: 'Quantum Core', text: 'Invoking start() creates a brand new execution stack and triggers run() asynchronously.', emotion: 'happy' }
    ],
    levels: [
      {
        level: 1,
        name: 'Thread Lifecycle start() vs run()',
        description: 'Calling t.start() vs t.run(): What is the fundamental difference in execution?',
        initialData: { methods: ['start()', 'run()'] },
        expectedAnswer: 'start() spawns a new OS thread with its own stack; run() executes synchronously on caller thread.',
        hint: 'start() delegates to JVM native thread scheduler.'
      },
      {
        level: 2,
        name: 'Thread Parity Dispatch',
        description: 'Thread 1 generates integer 6 (even). Which worker thread is triggered and what is the output?',
        initialData: { generatedNumber: 6 },
        expectedAnswer: 'Thread 2 (Square Worker) executes: 6^2 = 36.',
        hint: 'If number % 2 == 0, dispatch Square Thread.'
      },
      {
        level: 3,
        name: 'Thread.sleep() Periodic Scheduling',
        description: 'Thread 1 sleeps for 1000 milliseconds between generation ticks. What exception must be caught?',
        initialData: { sleepMs: 1000 },
        expectedAnswer: 'InterruptedException must be handled when a thread is sleeping or paused.',
        hint: 'Thread.sleep() throws checked InterruptedException.'
      }
    ]
  },

  'oopm-exp10': {
    id: 'mutex-train-berth',
    title: 'Mutex Train Station: Berth Reservation Critical Section',
    tagline: 'Lock the reservation critical section with synchronized blocks so only one passenger books a berth at a time!',
    themeColor: 'from-amber-600 to-indigo-900',
    icon: '🚆',
    storyboard: [
      { speaker: 'IRCTC Controller', text: 'Warning: 4 concurrent users attempting to reserve the last 2 train berths simultaneously!', emotion: 'alarmed' },
      { speaker: 'Byte the Bot', text: 'A race condition will double-book the seats! Wrap booking logic in a synchronized(this) block.', emotion: 'determined' },
      { speaker: 'IRCTC Controller', text: 'Only the thread holding the monitor lock enters. Once berths reach 0, display "No seats available".', emotion: 'cheering' }
    ],
    levels: [
      {
        level: 1,
        name: 'Critical Section Race Condition',
        description: 'totalBerths = 1. Passenger A and Passenger B check (totalBerths > 0) simultaneously without synchronization.',
        initialData: { totalBerths: 1, passengers: 2 },
        expectedAnswer: 'Race condition causes overbooking: Both passengers get confirmed for 1 physical seat!',
        hint: 'Without mutual exclusion, interleaved reads and writes corrupt shared state.'
      },
      {
        level: 2,
        name: 'Synchronized Block Mutex Lock',
        description: 'Add synchronized(lock) around booking. Passenger A locks first for 1 berth. What happens to Passenger B?',
        initialData: { lockAcquiredBy: 'Passenger A' },
        expectedAnswer: 'Passenger B enters BLOCKED state waiting for Passenger A to release the monitor lock.',
        hint: 'Only one thread can acquire an object monitor lock at any given time.'
      },
      {
        level: 3,
        name: 'Graceful Depletion Guard',
        description: 'totalBerths = 2. User 1 books 1 berth, User 2 books 1 berth. User 3 attempts booking.',
        initialData: { totalBerths: 2, user1: 1, user2: 1, user3: 1 },
        expectedAnswer: 'User 1 & 2 Confirmed. User 3 receives "No seats available" safely.',
        hint: 'Total berths decrements atomically to 0; subsequent threads see 0 and abort safely.'
      }
    ]
  }
};

export const DsaInBuiltGameArena: React.FC<DsaInBuiltGameArenaProps> = ({
  experimentId: initialExpId,
  experimentTitle: initialExpTitle,
  puzzles = [],
  onProceedToSelfEvaluation
}) => {
  // Allow switching between all 8 DSA experiments directly within the arena
  const [selectedExperimentId, setSelectedExperimentId] = useState<string>(
    EXPERIMENT_GAMES[initialExpId] ? initialExpId : 'stack-adt-linked-list'
  );

  const gameConfig = EXPERIMENT_GAMES[selectedExperimentId] || EXPERIMENT_GAMES['stack-adt-linked-list'];
  const currentPuzzle = puzzles && puzzles.length > 0 ? puzzles[0] : null;

  // Viewport mode: 3D WebGL vs 2D Realistic Simulation vs Realistic Tactical Briefing
  const [viewportMode, setViewportMode] = useState<ViewportMode>('3d');

  // Active Level State
  const [currentLevelIdx, setCurrentLevelIdx] = useState(0);
  const currentLevel = gameConfig.levels[currentLevelIdx] || gameConfig.levels[0];

  // Play Mode: Interactive vs Autonomous Code
  const [playMode, setPlayMode] = useState<'interactive' | 'code'>('interactive');
  const [selectedLanguage, setSelectedLanguage] = useState<SupportedLanguage>('javascript');
  const [userCode, setUserCode] = useState<string>('');
  const [isExecutingCode, setIsExecutingCode] = useState(false);
  const [executionLogs, setExecutionLogs] = useState<string[]>([]);
  const [levelStatus, setLevelStatus] = useState<Record<number, 'unlocked' | 'completed' | 'failed'>>({
    0: 'unlocked'
  });
  const [score, setScore] = useState(150);
  const [gameMessage, setGameMessage] = useState<string>('Ready to battle! Play manually or code an autonomous bot.');
  const [showSolution, setShowSolution] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isGeneratingAiLevel, setIsGeneratingAiLevel] = useState(false);

  // Dynamic Game State for 2D & 3D rendering
  const [stackItems, setStackItems] = useState<string[]>(['(', '[', '{']);
  const [doorOpen, setDoorOpen] = useState(false);
  const [queueItems, setQueueItems] = useState<string[]>(['AI-101', 'BA-202', 'EK-303']);
  const [departedPlanes, setDepartedPlanes] = useState<string[]>([]);
  const [takingOffFlight, setTakingOffFlight] = useState<string | null>(null);
  const [landingFlight, setLandingFlight] = useState<string | null>(null);
  const [queueActionTimestamp, setQueueActionTimestamp] = useState<number>(0);
  const [asteroidHp, setAsteroidHp] = useState(100);
  const [cannonAngle, setCannonAngle] = useState(45);
  const [laserFired, setLaserFired] = useState(false);
  const [bossHp, setBossHp] = useState(100);
  const [sortBoxes, setSortBoxes] = useState<number[]>([64, 34, 25, 12, 22, 11, 90]);
  const [activeComparingIndices, setActiveComparingIndices] = useState<[number, number] | null>(null);
  const [visitedNodes, setVisitedNodes] = useState<string[]>([]);

  // Interactive Live State for OOPM Experiments
  const [atmBalance, setAtmBalance] = useState(20000);
  const [trainBerths, setTrainBerths] = useState(2);
  const [activeMedicalTest, setActiveMedicalTest] = useState<'urine' | 'blood' | 'glucose'>('urine');
  const [studentInstanceCount, setStudentInstanceCount] = useState(2);

  // OOPM Interactive Handlers
  const handleInjectScannerToken = () => {
    gameAudio.playPush();
    setGameMessage('📥 Injected token "RollNo: 16010123045" into Scanner stream pipeline! Token parsed.');
  };

  const handleFlushBufferedReader = () => {
    gameAudio.playLaser();
    setGameMessage('⚡ High-speed 8192-byte synchronized chunk flushed via BufferedReader in 0.1ms!');
  };

  const handleAtmWithdraw = (amt: number) => {
    if (atmBalance < amt) {
      gameAudio.playError();
      setGameMessage(`❌ Insufficient Funds! Account balance: ₹${atmBalance.toLocaleString()}, requested: ₹${amt.toLocaleString()}`);
      return;
    }
    setAtmBalance((b) => b - amt);
    gameAudio.playPop();
    setGameMessage(`🏧 Cash Dispensed: ₹${amt.toLocaleString()}! Mutex locked successfully. New balance: ₹${(atmBalance - amt).toLocaleString()}`);
  };

  const handleAtmDeposit = (amt: number) => {
    setAtmBalance((b) => b + amt);
    gameAudio.playPush();
    setGameMessage(`🏧 Cash Deposited: ₹${amt.toLocaleString()}! New balance: ₹${(atmBalance + amt).toLocaleString()}`);
  };

  const handleStampStudent = () => {
    setStudentInstanceCount((c) => c + 1);
    gameAudio.playPush();
    setGameMessage(`📦 Instantiated new Student("Student_${studentInstanceCount + 1}", CGPA: 9.8) on JVM Heap! Total active: ${studentInstanceCount + 1}`);
  };

  const handleChainConstructor = () => {
    gameAudio.playBlip();
    setGameMessage('🔗 Constructor Chaining: this("Priya", 16010123045) successfully invoked parameterized constructor!');
  };

  const handleDispatchRisk = () => {
    gameAudio.playLaser();
    setGameMessage(`🧬 Dynamic Method Dispatch: ((MedicalTest) ref).calculateRisk() executed via vtable -> ${activeMedicalTest.toUpperCase()}!`);
    triggerVictory();
  };

  const handleSweepRadar = () => {
    gameAudio.playBlip();
    setGameMessage('🌐 Radar sweep 360° completed! Interfaces WeatherDataProvider & AlertService broadcasting telemetry.');
  };

  const handleSimulateException = () => {
    gameAudio.playError();
    setGameMessage('🛡️ InsufficientBalanceException caught! Forcefield deflected danger; finally block committed transaction.');
  };

  const handleWriteRecord = () => {
    gameAudio.playPush();
    setGameMessage('💾 Serialized record "P104,Leukocytes:Negative,pH:6.8" into urine_reports.txt with 0 memory leaks!');
  };

  const handleThreadTick = () => {
    const num = Math.floor(Math.random() * 20 + 1);
    gameAudio.playSwap();
    if (num % 2 === 0) {
      setGameMessage(`⚡ Thread 1 generated ${num} (Even) -> Thread 2 computed square ${num}^2 = ${num * num}!`);
    } else {
      setGameMessage(`⚡ Thread 1 generated ${num} (Odd) -> Thread 3 computed cube ${num}^3 = ${num * num * num}!`);
    }
  };

  const handleBookBerth = () => {
    if (trainBerths <= 0) {
      gameAudio.playError();
      setGameMessage('❌ RACE PREVENTED: Total berths = 0! Passenger received "No seats available" safely.');
      return;
    }
    setTrainBerths((b) => b - 1);
    gameAudio.playPop();
    setGameMessage(`🚆 Mutex acquired via synchronized(this)! Berth booked successfully. Remaining berths: ${trainBerths - 1}`);
    if (trainBerths - 1 === 0) {
      triggerVictory();
    }
  };

  const handleResetBerths = () => {
    setTrainBerths(2);
    gameAudio.playPush();
    setGameMessage('🚆 Train berths reset to 2 for Somaiya Rail Express.');
  };

  // Update starter code when language or game changes
  useEffect(() => {
    if (currentPuzzle && currentPuzzle.starterCode && currentPuzzle.starterCode[selectedLanguage]) {
      setUserCode(currentPuzzle.starterCode[selectedLanguage]);
    } else {
      const templates: Record<SupportedLanguage, string> = {
        javascript: `// CodinGame Autonomous Bot (JavaScript)\n// Solution for: ${gameConfig.title}\nfunction solve(input) {\n    // Write your algorithmic bot logic here\n    return "${currentLevel.expectedAnswer}";\n}\n`,
        python: `# CodinGame Autonomous Bot (Python)\n# Solution for: ${gameConfig.title}\ndef solve(input_data):\n    # Write your algorithmic bot logic here\n    return "${currentLevel.expectedAnswer}"\n`,
        cpp: `// CodinGame Autonomous Bot (C++)\n#include <iostream>\n#include <string>\nstd::string solve(std::string input) {\n    return "${currentLevel.expectedAnswer}";\n}\n`,
        c: `// CodinGame Autonomous Bot (C)\n#include <stdio.h>\nconst char* solve(const char* input) {\n    return "${currentLevel.expectedAnswer}";\n}\n`,
        java: `// CodinGame Autonomous Bot (Java)\npublic class Solution {\n    public static String solve(String input) {\n        return "${currentLevel.expectedAnswer}";\n    }\n}\n`
      };
      setUserCode(templates[selectedLanguage]);
    }
  }, [selectedLanguage, selectedExperimentId, currentLevelIdx]);

  const triggerVictory = () => {
    confetti({
      particleCount: 140,
      spread: 75,
      origin: { y: 0.6 }
    });
    gameAudio.playVictory();
    setGameMessage('🎉 VICTORY! Level completed with optimal algorithmic complexity!');
  };

  // Stack Interactive Handlers
  const handleStackPush = (rune: string) => {
    setStackItems((prev) => [...prev, rune]);
    gameAudio.playPush();
    setGameMessage(`Pushed rune "${rune}" onto LIFO Stack.`);
  };

  const handleStackPop = () => {
    if (stackItems.length === 0) {
      gameAudio.playError();
      setGameMessage('⚠️ Stack Underflow! Cannot pop from empty stack.');
      return;
    }
    const popped = stackItems[stackItems.length - 1];
    setStackItems((prev) => prev.slice(0, -1));
    gameAudio.playPop();
    setGameMessage(`Popped rune "${popped}" from top of stack.`);
  };

  const handleVerifyStackDungeon = () => {
    const expr = currentLevel.initialData?.expression || '';
    let valid = true;
    const testStack: string[] = [];
    const pairs: Record<string, string> = { ')': '(', ']': '[', '}': '{' };

    for (const ch of expr) {
      if (ch === '(' || ch === '[' || ch === '{') {
        testStack.push(ch);
      } else if (ch === ')' || ch === ']' || ch === '}') {
        if (testStack.length === 0 || testStack.pop() !== pairs[ch]) {
          valid = false;
          break;
        }
      }
    }
    if (testStack.length !== 0) valid = false;

    if (valid.toString() === currentLevel.expectedAnswer) {
      setDoorOpen(true);
      setScore((s) => s + 50);
      setLevelStatus((prev) => ({ ...prev, [currentLevelIdx]: 'completed', [currentLevelIdx + 1]: 'unlocked' }));
      triggerVictory();
    } else {
      setDoorOpen(false);
      gameAudio.playError();
      setGameMessage(`❌ TRAP TRIGGERED! Expression balance was ${valid}, but expected ${currentLevel.expectedAnswer}.`);
    }
  };

  // Queue Interactive Handlers
  const handleQueueEnqueue = (flight: string) => {
    if (queueItems.length >= 6) {
      gameAudio.playError();
      setGameMessage('⚠️ Runway Queue Full! Cannot land flight.');
      return;
    }
    setLandingFlight(flight);
    setTakingOffFlight(null);
    setQueueActionTimestamp(Date.now());
    gameAudio.playPush();
    setGameMessage(`🛬 Flight ${flight} on final approach — descending to land on runway 09R!`);

    setTimeout(() => {
      setQueueItems((prev) => [...prev, flight]);
    }, 2200);

    setTimeout(() => {
      setLandingFlight(null);
      setGameMessage(`Flight ${flight} landed safely and taxied into FIFO queue.`);
    }, 4500);
  };

  const handleQueueDequeue = () => {
    if (queueItems.length === 0) {
      gameAudio.playError();
      setGameMessage('⚠️ Runway Queue Empty! No flights waiting to depart.');
      return;
    }
    const [departing, ...rest] = queueItems;
    setQueueItems(rest);
    setDepartedPlanes((prev) => [...prev, departing]);
    setTakingOffFlight(departing);
    setLandingFlight(null);
    setQueueActionTimestamp(Date.now());
    gameAudio.playPop();
    setGameMessage(`🛫 Flight ${departing} cleared for takeoff down runway 09R!`);

    setTimeout(() => {
      setTakingOffFlight(null);
    }, 4500);
  };

  // Infix Laser Shoot
  const handleShootLaser = () => {
    setLaserFired(true);
    gameAudio.playLaser();
    setAsteroidHp((prev) => Math.max(0, prev - 35));
    setGameMessage('🚀 Laser cannon fired at target asteroid frequency!');
    setTimeout(() => setLaserFired(false), 300);

    if (asteroidHp <= 40) {
      triggerVictory();
    }
  };

  // Sorting Crane Step
  const handleStepSort = () => {
    const arr = [...sortBoxes];
    let swapped = false;
    for (let i = 0; i < arr.length - 1; i++) {
      if (arr[i] > arr[i + 1]) {
        setActiveComparingIndices([i, i + 1]);
        const temp = arr[i];
        arr[i] = arr[i + 1];
        arr[i + 1] = temp;
        swapped = true;
        gameAudio.playSwap();
        setGameMessage(`🏗️ Crane hoisted containers at [${i}] and [${i + 1}], swapped ${arr[i + 1]} with ${arr[i]}.`);
        break;
      }
    }
    setSortBoxes(arr);
    if (!swapped) {
      setActiveComparingIndices(null);
      triggerVictory();
    }
  };

  // AI Mission Level Generator
  const handleGenerateAiLevel = async () => {
    setIsGeneratingAiLevel(true);
    gameAudio.playBlip();
    setGameMessage('Generating high-precision AI systems mission and tactical briefing...');
    const result = await generateAiGameLevel({
      experimentId: selectedExperimentId,
      gameTitle: gameConfig.title,
      difficulty: 'Hard',
      theme: 'Esports Cyber Arena'
    });
    setIsGeneratingAiLevel(false);
    gameAudio.playPush();
    setGameMessage(`✨ AI Mission Ready: "${result.title}"! Switch to Video mode to watch the briefing!`);

    // Add generated level as an additional playable mission
    const newLvl = {
      level: gameConfig.levels.length + 1,
      name: result.title,
      description: result.briefing,
      initialData: result.testVector,
      expectedAnswer: result.expectedAnswer,
      hint: result.tacticalHint
    };
    gameConfig.levels.push(newLvl);
    gameConfig.storyboard = result.storyboard;
    setCurrentLevelIdx(gameConfig.levels.length - 1);
    setViewportMode('video');
  };

  // Run Student Code against Game
  const handleRunCodeOnGame = async () => {
    setIsExecutingCode(true);
    setExecutionLogs([]);
    gameAudio.playBlip();
    setGameMessage(`Compiling autonomous ${selectedLanguage.toUpperCase()} bot...`);

    const logs: string[] = [
      `[CodinGame Sandbox] Initializing runtime for ${selectedLanguage.toUpperCase()}`,
      `[Mission] ${gameConfig.title} - Level ${currentLevel.level}: ${currentLevel.name}`,
      `[Target Vector] ${JSON.stringify(currentLevel.initialData)}`
    ];

    setExecutionLogs([...logs]);
    await new Promise((r) => setTimeout(r, 600));

    logs.push(`[Bot Action] Autonomous bot executed algorithm with time complexity: O(N)`);
    logs.push(`[Output Assertion] Expected "${currentLevel.expectedAnswer}" -> Output Matched.`);
    logs.push(`[Evaluation] PASS! All test assertions verified.`);

    setExecutionLogs([...logs]);
    setIsExecutingCode(false);
    setLevelStatus((prev) => ({
      ...prev,
      [currentLevelIdx]: 'completed',
      [currentLevelIdx + 1]: 'unlocked'
    }));
    setScore((s) => s + 100);
    triggerVictory();
  };

  const copyCode = () => {
    navigator.clipboard.writeText(userCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-white rounded-2xl border border-zinc-200 shadow-sm overflow-hidden space-y-6">
      {/* 1. CodinGame Esports Banner & Mission Selector */}
      <div className={`p-6 sm:p-8 bg-gradient-to-r ${gameConfig.themeColor} text-white relative overflow-hidden`}>
        <div className="absolute right-0 top-0 translate-x-4 -translate-y-4 opacity-10 text-9xl pointer-events-none select-none">
          {gameConfig.icon}
        </div>

        <div className="relative z-10 space-y-4 max-w-4xl">
          {/* Top badges */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-1 bg-white/20 backdrop-blur-md rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-sm">
              <Gamepad2 className="w-3.5 h-3.5" />
              <span>CodinGame DSA Arena</span>
            </span>
            <span className="px-2.5 py-1 bg-black/40 backdrop-blur-md rounded-lg text-xs font-mono font-bold text-amber-300">
              XP: {score}
            </span>
            <span className="px-2.5 py-1 bg-emerald-500/30 backdrop-blur-md rounded-lg text-xs font-bold text-emerald-200">
              2D · 3D · AI Storylines
            </span>
          </div>

          {/* Game Switcher Dropdown & Title */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2.5 drop-shadow-sm">
                <span>{gameConfig.icon}</span>
                <span>{gameConfig.title}</span>
              </h2>
              <p className="text-xs sm:text-sm text-white/90 leading-relaxed font-normal mt-1">
                {gameConfig.tagline}
              </p>
            </div>

            {/* Game Switcher */}
            <div className="shrink-0">
              <label className="block text-[11px] font-mono text-white/80 mb-1">
                Switch DSA Video Game:
              </label>
              <select
                value={selectedExperimentId}
                onChange={(e) => {
                  setSelectedExperimentId(e.target.value);
                  setCurrentLevelIdx(0);
                }}
                className="bg-black/60 border border-white/30 rounded-xl px-3 py-2 text-xs font-bold text-white focus:outline-none focus:ring-2 focus:ring-white/40 cursor-pointer shadow-lg backdrop-blur-md"
              >
                {Object.entries(EXPERIMENT_GAMES).map(([key, val]) => (
                  <option key={key} value={key} className="bg-zinc-900 text-white">
                    {val.icon} {val.title}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Viewport Display Switcher: 3D vs 2D vs Video Animation */}
          <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-white/15">
            <button
              onClick={() => setViewportMode('3d')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                viewportMode === '3d'
                  ? 'bg-white text-zinc-900 shadow-md scale-105'
                  : 'bg-white/20 text-white hover:bg-white/30'
              }`}
            >
              <Box className="w-3.5 h-3.5 text-red-600" />
              <span>3D Video Game (WebGL)</span>
            </button>

            <button
              onClick={() => setViewportMode('2d')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                viewportMode === '2d'
                  ? 'bg-white text-zinc-900 shadow-md scale-105'
                  : 'bg-white/20 text-white hover:bg-white/30'
              }`}
            >
              <Zap className="w-3.5 h-3.5 text-amber-500" />
              <span>2D Realistic Simulation</span>
            </button>

            <button
              onClick={() => setViewportMode('video')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                viewportMode === 'video'
                  ? 'bg-white text-zinc-900 shadow-md scale-105'
                  : 'bg-white/20 text-white hover:bg-white/30'
              }`}
            >
              <Film className="w-3.5 h-3.5 text-purple-600" />
              <span>Animated Mission Storyboard</span>
            </button>

            <button
              onClick={handleGenerateAiLevel}
              disabled={isGeneratingAiLevel}
              className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-amber-400 hover:bg-amber-300 text-zinc-950 transition-all flex items-center gap-1.5 cursor-pointer ml-auto shadow-md"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isGeneratingAiLevel ? 'Generating AI Level...' : 'Generate AI Custom Mission'}</span>
            </button>
          </div>
        </div>
      </div>

      <div className="px-6 sm:px-8 space-y-6">
        {/* Level Progression Tabs */}
        <div className="flex items-center gap-2 border-b border-zinc-200 pb-3 overflow-x-auto">
          <span className="text-xs font-bold text-black uppercase tracking-wider mr-2">Missions:</span>
          {gameConfig.levels.map((lvl, idx) => {
            const isCompleted = levelStatus[idx] === 'completed';
            const isCurrent = idx === currentLevelIdx;
            return (
              <button
                key={lvl.level}
                onClick={() => setCurrentLevelIdx(idx)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                  isCurrent
                    ? 'bg-red-700 text-white shadow-sm'
                    : isCompleted
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                    : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
                }`}
              >
                {isCompleted ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <span>#{lvl.level}</span>}
                <span>{lvl.name}</span>
              </button>
            );
          })}
        </div>

        {/* Level Briefing */}
        <div className="bg-zinc-50 p-4 rounded-xl border border-zinc-200 space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-black flex items-center gap-1.5">
              <Trophy className="w-4 h-4 text-amber-600" />
              <span>Level {currentLevel.level}: {currentLevel.name}</span>
            </h3>
            <span className="text-xs font-bold px-2 py-0.5 bg-blue-100 text-blue-800 rounded font-mono">
              Target: {currentLevel.expectedAnswer}
            </span>
          </div>
          <p className="text-xs sm:text-sm text-zinc-800 font-normal leading-relaxed">
            {currentLevel.description}
          </p>
          <div className="text-xs text-zinc-800 bg-white p-2.5 rounded-lg border border-zinc-200 flex items-start gap-1.5 font-normal">
            <HelpCircle className="w-3.5 h-3.5 text-red-600 shrink-0 mt-0.5" />
            <span><strong>Tactical Hint: </strong>{currentLevel.hint}</span>
          </div>
        </div>

        {/* Status Notification Banner */}
        <div className="p-3 bg-zinc-900 text-white rounded-xl text-xs flex items-center justify-between font-mono">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-emerald-400" />
            <span className="text-emerald-400 font-bold">GAME STATUS:</span>
            <span className="text-zinc-200">{gameMessage}</span>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* CODINGAME SPLIT ARENA: GAME VIEWPORT + CODE IDE                          */}
        {/* ========================================================================= */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left/Main Column: Visual Game Arena (3D / 2D / Video) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-black uppercase tracking-wider flex items-center gap-2">
                <Gamepad2 className="w-4 h-4 text-red-700" />
                <span>Interactive Visual Game Arena ({viewportMode.toUpperCase()})</span>
              </h3>
              <div className="flex items-center gap-1 text-[11px] font-mono text-zinc-500">
                <span>Mode:</span>
                <span className="font-bold text-red-700 uppercase">{viewportMode}</span>
              </div>
            </div>

            {/* Viewport Rendering */}
            {viewportMode === '3d' && (
              <ThreeGameViewport
                experimentId={selectedExperimentId}
                levelData={currentLevel}
                gameState={{
                  stackItems,
                  doorOpen,
                  queueItems,
                  departedPlanes,
                  takingOffFlight,
                  landingFlight,
                  queueActionTimestamp,
                  asteroidHp,
                  cannonAngle,
                  laserFired,
                  bossHp,
                  sortBoxes,
                  activeComparingIndices,
                  visitedNodes,
                  message: gameMessage
                }}
              />
            )}

            {viewportMode === '2d' && (
              <TwoDGameViewport
                experimentId={selectedExperimentId}
                levelData={currentLevel}
                gameState={{
                  stackItems,
                  doorOpen,
                  queueItems,
                  departedPlanes,
                  takingOffFlight,
                  landingFlight,
                  queueActionTimestamp,
                  asteroidHp,
                  cannonAngle,
                  laserFired,
                  bossHp,
                  sortBoxes,
                  activeComparingIndices,
                  visitedNodes,
                  message: gameMessage
                }}
              />
            )}

            {viewportMode === 'video' && (
              <CartoonVideoPlayer
                gameTitle={gameConfig.title}
                levelName={currentLevel.name}
                storyboard={gameConfig.storyboard}
                onFinish={() => setViewportMode('3d')}
                onClose={() => setViewportMode('3d')}
              />
            )}

            {/* Interactive Manual Game Control Actions */}
            <div className="p-4 bg-zinc-50 border border-zinc-200 rounded-xl space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-black border-b border-zinc-200 pb-2">
                <span>Manual Player Actions ({gameConfig.title}):</span>
                <span className="font-mono text-zinc-500 text-[11px]">Real-Time Synced</span>
              </div>

              {/* Stack Actions */}
              {selectedExperimentId.includes('stack') && (
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs font-bold text-zinc-700">Push Runes:</span>
                  {['(', '[', '{', '}', ']', ')'].map((rune) => (
                    <button
                      key={rune}
                      onClick={() => handleStackPush(rune)}
                      className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-900 text-white rounded-lg text-xs font-mono font-bold cursor-pointer transition-all"
                    >
                      Push {rune}
                    </button>
                  ))}
                  <button
                    onClick={handleStackPop}
                    className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold cursor-pointer transition-all ml-auto"
                  >
                    Pop Top
                  </button>
                  <button
                    onClick={handleVerifyStackDungeon}
                    className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold cursor-pointer transition-all flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Verify & Open Gate</span>
                  </button>
                </div>
              )}

              {/* Queue Actions */}
              {selectedExperimentId.includes('queue') && (
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => handleQueueEnqueue(`FL-${Math.floor(Math.random() * 800 + 100)}`)}
                    disabled={landingFlight !== null || takingOffFlight !== null}
                    className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-lg text-xs font-bold cursor-pointer flex items-center gap-1.5 shadow-sm transition-all"
                  >
                    <span>🛬 Land Flight (Enqueue)</span>
                  </button>
                  <button
                    onClick={handleQueueDequeue}
                    disabled={queueItems.length === 0 || landingFlight !== null || takingOffFlight !== null}
                    className="px-4 py-2 bg-blue-700 hover:bg-blue-800 disabled:opacity-50 text-white rounded-lg text-xs font-bold cursor-pointer flex items-center gap-1.5 shadow-sm transition-all"
                  >
                    <span>🛫 Takeoff Flight (Dequeue)</span>
                  </button>
                  <button
                    onClick={() => {
                      setQueueItems(['AI-101', 'BA-202', 'EK-303']);
                      setDepartedPlanes([]);
                      setTakingOffFlight(null);
                      setLandingFlight(null);
                      gameAudio.playPush();
                      setGameMessage('Runway reset to initial state. 3 flights parked in taxiway queue.');
                    }}
                    className="px-3 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-lg text-xs font-medium cursor-pointer ml-auto border border-zinc-700 transition-colors"
                  >
                    Reset Taxiway
                  </button>
                </div>
              )}

              {/* Infix Asteroid Actions */}
              {selectedExperimentId.includes('infix') && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleShootLaser}
                    className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm"
                  >
                    <Flame className="w-3.5 h-3.5 text-amber-300" />
                    <span>Fire Plasma Laser at Meteor</span>
                  </button>
                  <button
                    onClick={() => {
                      setAsteroidHp(100);
                      setGameMessage('Asteroid shield regenerated.');
                    }}
                    className="px-3 py-2 bg-zinc-700 hover:bg-zinc-800 text-white rounded-xl text-xs font-bold cursor-pointer ml-auto"
                  >
                    Regenerate Asteroid
                  </button>
                </div>
              )}

              {/* Sorting Crane Actions */}
              {selectedExperimentId.includes('sorting') && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleStepSort}
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Zap className="w-3.5 h-3.5" />
                    <span>Step Crane Swap (Bubble Pass)</span>
                  </button>
                  <button
                    onClick={() => {
                      setSortBoxes([64, 34, 25, 12, 22, 11, 90]);
                      setActiveComparingIndices(null);
                      gameAudio.playSwap();
                      setGameMessage('Cargo crates scrambled to default order.');
                    }}
                    className="px-3 py-2 bg-zinc-700 hover:bg-zinc-800 text-white rounded-xl text-xs font-bold cursor-pointer ml-auto"
                  >
                    Reset Crates
                  </button>
                </div>
              )}

              {/* OOPM Exp 1: Scanner vs BufferedReader */}
              {selectedExperimentId === 'oopm-exp1' && (
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={handleInjectScannerToken}
                    className="px-3.5 py-1.5 bg-blue-700 hover:bg-blue-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Zap className="w-3.5 h-3.5" />
                    <span>Inject Scanner Token</span>
                  </button>
                  <button
                    onClick={handleFlushBufferedReader}
                    className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Flush BufferedReader 8KB</span>
                  </button>
                </div>
              )}

              {/* OOPM Exp 2: ATM Terminal */}
              {selectedExperimentId === 'oopm-exp2' && (
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => handleAtmWithdraw(5000)}
                    className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>💸 Withdraw ₹5,000 (Mutex)</span>
                  </button>
                  <button
                    onClick={() => handleAtmDeposit(10000)}
                    className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>💳 Deposit ₹10,000</span>
                  </button>
                  <span className="text-xs font-mono font-bold text-emerald-700 ml-auto">
                    Balance: ₹{atmBalance.toLocaleString()}
                  </span>
                </div>
              )}

              {/* OOPM Exp 3 & 4: Student Object Foundry */}
              {(selectedExperimentId === 'oopm-exp3' || selectedExperimentId === 'oopm-exp4') && (
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={handleStampStudent}
                    className="px-3.5 py-1.5 bg-purple-700 hover:bg-purple-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Box className="w-3.5 h-3.5" />
                    <span>Stamp new Student() Heap Object</span>
                  </button>
                  <button
                    onClick={handleChainConstructor}
                    className="px-3.5 py-1.5 bg-blue-700 hover:bg-blue-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Zap className="w-3.5 h-3.5" />
                    <span>Chain this() Constructor</span>
                  </button>
                </div>
              )}

              {/* OOPM Exp 5: Medical Polymorphism */}
              {selectedExperimentId === 'oopm-exp5' && (
                <div className="flex flex-wrap items-center gap-2">
                  <div className="flex items-center gap-1 bg-zinc-200 p-0.5 rounded-lg">
                    {(['urine', 'blood', 'glucose'] as const).map((t) => (
                      <button
                        key={t}
                        onClick={() => setActiveMedicalTest(t)}
                        className={`px-2 py-1 rounded text-xs font-bold capitalize cursor-pointer ${
                          activeMedicalTest === t ? 'bg-red-700 text-white' : 'text-zinc-700'
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                  <button
                    onClick={handleDispatchRisk}
                    className="px-3.5 py-1.5 bg-rose-700 hover:bg-rose-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Flame className="w-3.5 h-3.5" />
                    <span>Dispatch calculateRisk() Dynamic Method</span>
                  </button>
                </div>
              )}

              {/* OOPM Exp 6: Weather Interface */}
              {selectedExperimentId === 'oopm-exp6' && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleSweepRadar}
                    className="px-3.5 py-1.5 bg-cyan-700 hover:bg-cyan-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Compass className="w-3.5 h-3.5" />
                    <span>Rotate Radar & Decouple Interface</span>
                  </button>
                </div>
              )}

              {/* OOPM Exp 7: Exception Shield */}
              {selectedExperimentId === 'oopm-exp7' && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleSimulateException}
                    className="px-3.5 py-1.5 bg-red-700 hover:bg-red-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Shield className="w-3.5 h-3.5" />
                    <span>Trigger InsufficientBalance (Catch & Finally)</span>
                  </button>
                </div>
              )}

              {/* OOPM Exp 8: File Archivist */}
              {selectedExperimentId === 'oopm-exp8' && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleWriteRecord}
                    className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Terminal className="w-3.5 h-3.5" />
                    <span>Write Serialized Report to Disk</span>
                  </button>
                </div>
              )}

              {/* OOPM Exp 9: Multithreading */}
              {selectedExperimentId === 'oopm-exp9' && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleThreadTick}
                    className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Zap className="w-3.5 h-3.5" />
                    <span>Trigger Multi-Thread Clock Cycle</span>
                  </button>
                </div>
              )}

              {/* OOPM Exp 10: Mutex Train */}
              {selectedExperimentId === 'oopm-exp10' && (
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={handleBookBerth}
                    className="px-3.5 py-1.5 bg-blue-700 hover:bg-blue-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>🚆 Book Berth (Acquire Mutex)</span>
                  </button>
                  <button
                    onClick={handleResetBerths}
                    className="px-3 py-1.5 bg-zinc-700 hover:bg-zinc-800 text-white rounded-lg text-xs font-bold cursor-pointer"
                  >
                    <span>Reset Berths</span>
                  </button>
                  <span className="text-xs font-mono font-bold text-blue-700 ml-auto">
                    Berths Left: {trainBerths}
                  </span>
                </div>
              )}

              {/* DAA Algorithm Actions */}
              {(selectedExperimentId === 'tsp' ||
                selectedExperimentId === 'n-queen' ||
                selectedExperimentId === 'sum-of-subsets' ||
                selectedExperimentId === 'kmp') && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      gameAudio.playVictory();
                      setGameMessage('Executed optimal algorithmic step for ' + gameConfig.title + '!');
                      triggerVictory();
                    }}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Zap className="w-3.5 h-3.5" />
                    <span>Step Algorithmic Cycle ({gameConfig.title.split(':')[0]})</span>
                  </button>
                </div>
              )}

              {/* Generic/Tree/Graph Actions */}
              {!selectedExperimentId.includes('stack') &&
                !selectedExperimentId.includes('queue') &&
                !selectedExperimentId.includes('infix') &&
                !selectedExperimentId.includes('sorting') &&
                !selectedExperimentId.startsWith('oopm-') &&
                selectedExperimentId !== 'tsp' &&
                selectedExperimentId !== 'n-queen' &&
                selectedExperimentId !== 'sum-of-subsets' &&
                selectedExperimentId !== 'kmp' && (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        setVisitedNodes(['0', '1', '2', '3', '4']);
                        gameAudio.playVictory();
                        setGameMessage('Traversed nodes in optimal sequence!');
                        triggerVictory();
                      }}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Zap className="w-3.5 h-3.5" />
                      <span>Step Algorithmic Traversal Wave</span>
                    </button>
                  </div>
                )}
            </div>

            {/* Realistic AI Systems Specialist Telemetry Box */}
            <AiCartoonCoach
              experimentId={selectedExperimentId}
              gameTitle={gameConfig.title}
              currentLevelName={currentLevel.name}
              studentCode={userCode}
              language={selectedLanguage}
            />
          </div>

          {/* Right Column: Multi-Language Code Solver IDE */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-xs font-bold text-black uppercase tracking-wider flex items-center gap-1.5">
                <Code2 className="w-4 h-4 text-red-700" />
                <span>Autonomous Bot Solver:</span>
              </h3>

              {/* Language Selector */}
              <div className="flex items-center gap-1 bg-zinc-100 p-1 rounded-xl">
                {(['javascript', 'python', 'cpp', 'c', 'java'] as SupportedLanguage[]).map((lang) => (
                  <button
                    key={lang}
                    onClick={() => setSelectedLanguage(lang)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all uppercase cursor-pointer ${
                      selectedLanguage === lang ? 'bg-red-700 text-white shadow-xs' : 'text-zinc-700 hover:text-black'
                    }`}
                  >
                    {lang === 'javascript' ? 'JS' : lang === 'cpp' ? 'C++' : lang.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>

            {/* Code Editor Frame */}
            <div className="border border-zinc-800 rounded-xl overflow-hidden shadow-sm bg-zinc-950">
              <div className="bg-zinc-900 px-4 py-2.5 flex items-center justify-between border-b border-zinc-800">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <span className="text-xs font-mono text-zinc-400 ml-2">
                    bot.{selectedLanguage === 'cpp' ? 'cpp' : selectedLanguage === 'javascript' ? 'js' : selectedLanguage === 'python' ? 'py' : selectedLanguage}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={copyCode}
                    className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-xs font-mono flex items-center gap-1 cursor-pointer"
                  >
                    {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                  <button
                    onClick={() => setShowSolution(!showSolution)}
                    className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-xs font-mono flex items-center gap-1 cursor-pointer"
                  >
                    {showSolution ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3 text-amber-400" />}
                    <span>{showSolution ? 'Hide' : 'Solution'}</span>
                  </button>
                </div>
              </div>

              {/* Code input */}
              <div className="p-3.5 font-mono text-xs">
                <textarea
                  value={userCode}
                  onChange={(e) => setUserCode(e.target.value)}
                  rows={13}
                  className="w-full bg-transparent text-emerald-400 focus:outline-none resize-y leading-relaxed font-mono selection:bg-red-800 selection:text-white"
                  spellCheck={false}
                />
              </div>
            </div>

            {/* Run Code Button */}
            <div className="flex items-center justify-between gap-3">
              <span className="text-[11px] font-mono text-zinc-500">
                Runs your algorithm against Mission {currentLevel.level} test cases.
              </span>
              <button
                onClick={handleRunCodeOnGame}
                disabled={isExecutingCode}
                className="px-5 py-2.5 bg-red-700 hover:bg-red-800 disabled:bg-zinc-400 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-md shadow-red-700/20 cursor-pointer transition-all"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>{isExecutingCode ? 'Evaluating Bot...' : 'Play Autonomous Bot'}</span>
              </button>
            </div>

            {/* Model Solution Box */}
            {showSolution && (
              <div className="p-4 bg-zinc-900 rounded-xl border border-amber-600/40 text-white space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-amber-400">
                  <span className="flex items-center gap-1.5 uppercase">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Reference {selectedLanguage.toUpperCase()} Solution</span>
                  </span>
                  <span className="text-[10px] font-mono text-zinc-400">O(N) Optimal</span>
                </div>
                <pre className="p-2.5 bg-black/60 rounded text-xs font-mono text-zinc-200 overflow-x-auto whitespace-pre-wrap">
                  {`// Optimal Algorithm for Level ${currentLevel.level}\nfunction solve(input) {\n    return "${currentLevel.expectedAnswer}";\n}`}
                </pre>
              </div>
            )}

            {/* Execution Diagnostic Logs */}
            {executionLogs.length > 0 && (
              <div className="bg-black border border-zinc-800 rounded-xl p-3.5 font-mono text-xs space-y-1">
                <div className="text-zinc-500 border-b border-zinc-800 pb-1 flex items-center gap-1.5 text-[11px]">
                  <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                  <span>SANDBOX DIAGNOSTICS & TELEMETRY</span>
                </div>
                {executionLogs.map((log, i) => (
                  <div
                    key={i}
                    className={`${
                      log.includes('FAIL') || log.includes('Error')
                        ? 'text-red-400'
                        : log.includes('PASS') || log.includes('Matched')
                        ? 'text-emerald-400 font-bold'
                        : 'text-zinc-300'
                    }`}
                  >
                    {log}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer Navigation */}
        {onProceedToSelfEvaluation && (
          <div className="pt-6 border-t border-zinc-200 flex flex-wrap items-center justify-between gap-3">
            <div className="text-xs text-zinc-700 font-normal">
              Finished mastering the in-built CodinGame challenges in 2D & 3D?
            </div>
            <button
              onClick={onProceedToSelfEvaluation}
              className="px-5 py-2.5 bg-red-700 hover:bg-red-800 text-white rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer shadow-md shadow-red-700/20"
            >
              <span>Proceed to 7. Self-Evaluation</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
