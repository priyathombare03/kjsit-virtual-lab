import Editor from "@monaco-editor/react";
import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import Markdown from 'react-markdown';
import {
  ArrowLeft, Play, X,
  ArrowRight,
  BookOpen,
  Cpu,
  CheckCircle2,
  Code2,
  HelpCircle,
  FileText,
  Copy,
  Check,
  Award,
  RotateCcw,
  Sparkles,
  Printer,
  Settings,
  FolderTree,
  Type,
  Minus,
  Plus,
  Sidebar,
  Save,
  Command,
  Keyboard,
  Clock,
  Activity,
  Sliders,
  Gamepad2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { findExperimentById, ALL_EXPERIMENTS } from '../data/allExperiments';
import { enrichExperimentQuiz } from '../utils/quizEnricher';
import { LAB_SUBJECTS } from '../data/subjects';
import { LabExperiment, UserSession } from '../types';
import { ExperimentSimulator } from './simulators/ExperimentSimulator';
import { UniversalExecutionTracer } from './simulators/common/UniversalExecutionTracer';
import { LabActiveTrackerBar } from './LabActiveTrackerBar';
import { useLabActiveTracker } from '../utils/useLabActiveTracker';
import { PrintLabManualModal } from './PrintLabManualModal';
import { getExperimentLaboratoryObjectives } from '../utils/experimentObjectives';
import { CodingamePuzzlesView } from './CodingamePuzzlesView';
import { getExperimentCodingamePuzzles } from '../data/dsaCodingamePuzzles';

interface ExperimentDetailViewProps {
  experimentId: string;
  onBackToLab: (labType: string) => void;
  onSelectExperiment: (expId: string) => void;
  userSession: UserSession | null;
  onUserSessionUpdate?: (session: UserSession) => void;
  onOpenLogin?: () => void;
}

type TabType = 'aim' | 'theory' | 'algorithm' | 'simulation' | 'code' | 'puzzles' | 'quiz' | 'conclusion';

export const ExperimentDetailView: React.FC<ExperimentDetailViewProps> = ({
  experimentId,
  onBackToLab,
  onSelectExperiment,
  userSession,
  onUserSessionUpdate,
  onOpenLogin
}) => {
  const lookup = findExperimentById(experimentId);
  const rawExperiment = lookup?.experiment || ALL_EXPERIMENTS[0];
  const experiment = useMemo(() => enrichExperimentQuiz(rawExperiment, 10), [rawExperiment]);
  const experimentList = lookup?.experimentList || ALL_EXPERIMENTS;
  const currentIndex = experimentList.findIndex((e) => e.id === experiment.id);
  const prevExperiment = currentIndex > 0 ? experimentList[currentIndex - 1] : null;
  const nextExperiment = currentIndex < experimentList.length - 1 ? experimentList[currentIndex + 1] : null;

  const subjectId = lookup?.subjectId || 'daa';
  const currentSubject = LAB_SUBJECTS.find((s) => s.id === subjectId || (s.id === 'webtech' && subjectId === 'fswc') || (s.id === 'cybersec' && subjectId === 'cns'));

  const isDsa = subjectId === 'dsa';
  const isDaa = subjectId === 'daa';
  const isOopm = subjectId === 'oopm';
  const codingamePuzzles = useMemo(() => {
    return experiment.codingamePuzzles || getExperimentCodingamePuzzles(experiment.id);
  }, [experiment.id, experiment.codingamePuzzles]);
  const hasPuzzles = isDsa || isDaa || isOopm || codingamePuzzles.length > 0;

  // Genuine Active Experiment Tracker
  const tracker = useLabActiveTracker({
    experimentId: experiment.id,
    subjectId,
    experimentTitle: experiment.title,
    userSession,
    onUserSessionUpdate
  });

  const getInitialLanguage = (): 'c' | 'cpp' | 'python' | 'java' | 'sql' | 'bash' | 'html' | 'css' | 'js' | 'ts' | 'json' => {
    if (experiment.code.python) return 'python';
    if (experiment.code.cpp) return 'cpp';
    if (experiment.code.c) return 'c';
    if (experiment.code.java) return 'java';
    if (experiment.code.sql) return 'sql';
    if (experiment.code.js) return 'js';
    if (experiment.code.html) return 'html';
    if (experiment.code.bash) return 'bash';
    if (experiment.code.json) return 'json';
    return 'c';
  };

  const [activeTab, setActiveTab] = useState<TabType>('aim');
  const [isSimulationFinished, setIsSimulationFinished] = useState<boolean>(false);
  const [simViewMode, setSimViewMode] = useState<'tracer' | 'canvas'>('tracer');
  const [codeLanguage, setCodeLanguage] = useState<'c' | 'cpp' | 'python' | 'java' | 'sql' | 'bash' | 'html' | 'css' | 'js' | 'ts' | 'json'>(
    getInitialLanguage()
  );
  const [copiedCode, setCopiedCode] = useState(false);

  // IDE features state
  const [editorTheme, setEditorTheme] = useState<'vs-dark' | 'vs-light' | 'hc-black'>('vs-dark');
  const [editorFontSize, setEditorFontSize] = useState<number>(14);
  const [showMinimap, setShowMinimap] = useState<boolean>(true);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saved'>('idle');
  const [saveToast, setSaveToast] = useState<string | null>(null);
  const [showShortcutsModal, setShowShortcutsModal] = useState<boolean>(false);
  const [showPrintModal, setShowPrintModal] = useState<boolean>(false);
  const [cursorPos, setCursorPos] = useState({ line: 1, column: 1 });

  // Compiler state
  const [editedCode, setEditedCode] = useState<Record<string, string>>({});
  const [isCompiling, setIsCompiling] = useState(false);
  const [compilerOutput, setCompilerOutput] = useState<string | null>(null);
  const [aiHint, setAiHint] = useState<string | null>(null);
  const [isFetchingHint, setIsFetchingHint] = useState(false);

  // Editor and Monaco instances
  const editorRef = useRef<any>(null);
  const monacoRef = useRef<any>(null);
  const saveHandlerRef = useRef<((code?: string) => void) | null>(null);

  // Default initial code is blank so students write their own implementation from scratch
  const defaultExpCode = '';

  // Reset or initialize code when language changes
  const currentCode = editedCode[codeLanguage] !== undefined 
    ? editedCode[codeLanguage] 
    : defaultExpCode;

  const handleCodeChange = (value: string | undefined) => {
    setEditedCode(prev => ({ ...prev, [codeLanguage]: value || '' }));
  };

  const handleSaveCode = useCallback((codeToSave?: string) => {
    const textToSave = codeToSave !== undefined 
      ? codeToSave 
      : (editorRef.current ? editorRef.current.getValue() : currentCode);
    
    setEditedCode(prev => ({ ...prev, [codeLanguage]: textToSave }));
    try {
      localStorage.setItem(`kjsit_code_${experiment.id}_${codeLanguage}`, textToSave);
      setSaveStatus('saved');
      const isMac = typeof navigator !== 'undefined' && /Mac|iPod|iPhone|iPad/.test(navigator.platform);
      setSaveToast(`Code saved to local workspace (${isMac ? '⌘S' : 'Ctrl+S'})`);
      setTimeout(() => setSaveStatus('idle'), 2500);
      setTimeout(() => setSaveToast(null), 3000);
    } catch (e) {
      console.error("Failed to save code to localStorage:", e);
    }
  }, [codeLanguage, experiment.id, currentCode]);

  useEffect(() => {
    saveHandlerRef.current = handleSaveCode;
  }, [handleSaveCode]);

  // Global Ctrl+S / Cmd+S handler when on the Code tab
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        if (activeTab === 'code') {
          e.preventDefault();
          if (saveHandlerRef.current) {
            saveHandlerRef.current();
          }
        }
      }
    };
    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [activeTab]);

  // Load saved code from local storage on mount / experiment change
  useEffect(() => {
    setIsSimulationFinished(false);
    try {
      const saved = localStorage.getItem(`kjsit_code_${experiment.id}_${codeLanguage}`);
      if (saved !== null && saved !== undefined) {
        setEditedCode(prev => ({ ...prev, [codeLanguage]: saved }));
      }
    } catch {
      // ignore
    }
  }, [experiment.id, codeLanguage]);

  // Configure Monaco keybindings matching VS Code
  const handleEditorDidMount = (editor: any, monaco: any) => {
    editorRef.current = editor;
    monacoRef.current = monaco;

    // Track real-time cursor position
    editor.onDidChangeCursorPosition((e: any) => {
      setCursorPos({ line: e.position.lineNumber, column: e.position.column });
    });

    // 1. Ctrl+S / Cmd+S (Save Code)
    editor.addAction({
      id: 'vscode-save-code',
      label: 'Save Code',
      keybindings: [
        monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS,
      ],
      precondition: undefined,
      keybindingContext: undefined,
      contextMenuGroupId: '1_modification',
      contextMenuOrder: 1,
      run: (ed: any) => {
        const val = ed.getValue();
        if (saveHandlerRef.current) {
          saveHandlerRef.current(val);
        }
      },
    });

    // 2. Ctrl+/ / Cmd+/ (Toggle Line Comment)
    editor.addAction({
      id: 'vscode-toggle-comment',
      label: 'Toggle Line Comment',
      keybindings: [
        monaco.KeyMod.CtrlCmd | monaco.KeyCode.Slash,
      ],
      precondition: '!editorReadonly',
      keybindingContext: undefined,
      contextMenuGroupId: '1_modification',
      contextMenuOrder: 2,
      run: (ed: any) => {
        ed.getAction('editor.action.commentLine')?.run();
      },
    });

    // 3. Ctrl+Shift+P / Cmd+Shift+P (Command Palette)
    editor.addAction({
      id: 'vscode-command-palette',
      label: 'Command Palette',
      keybindings: [
        monaco.KeyMod.CtrlCmd | monaco.KeyMod.Shift | monaco.KeyCode.KeyP,
      ],
      precondition: undefined,
      keybindingContext: undefined,
      contextMenuGroupId: 'navigation',
      contextMenuOrder: 1,
      run: (ed: any) => {
        ed.trigger('keyboard', 'editor.action.quickCommand', null);
      },
    });

    // 4. Block Comment (Shift+Alt+A / Option+Shift+A)
    editor.addAction({
      id: 'vscode-toggle-block-comment',
      label: 'Toggle Block Comment',
      keybindings: [
        monaco.KeyMod.Shift | monaco.KeyMod.Alt | monaco.KeyCode.KeyA,
      ],
      precondition: '!editorReadonly',
      contextMenuGroupId: '1_modification',
      contextMenuOrder: 3,
      run: (ed: any) => {
        ed.getAction('editor.action.blockComment')?.run();
      },
    });
  };

  const handleOpenCommandPalette = () => {
    if (editorRef.current) {
      editorRef.current.focus();
      editorRef.current.trigger('keyboard', 'editor.action.quickCommand', null);
    }
  };

  const handleToggleComment = () => {
    if (editorRef.current) {
      editorRef.current.focus();
      editorRef.current.getAction('editor.action.commentLine')?.run();
    }
  };

  const handleResetCode = () => {
    setEditedCode(prev => ({ ...prev, [codeLanguage]: '' }));
    try {
      localStorage.removeItem(`kjsit_code_${experiment.id}_${codeLanguage}`);
    } catch {
      // ignore
    }
    setSaveToast("Cleared editor to blank");
    setTimeout(() => setSaveToast(null), 2500);
  };
  
  const getMonacoLanguage = (lang: string) => {
    if (lang === 'js') return 'javascript';
    if (lang === 'ts') return 'typescript';
    if (lang === 'bash') return 'shell';
    if (lang === 'c') return 'c';
    return lang;
  };

  const handleGetHint = async () => {
    if (!currentCode.trim()) {
      setAiHint("Please write some code first before asking for a hint!");
      return;
    }
    setIsFetchingHint(true);
    setAiHint(null);
    try {
      const response = await fetch('/api/hint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: currentCode,
          language: codeLanguage,
          experiment: experiment.title,
          aim: experiment.aim
        })
      });
      const data = await response.json();
      if (data.hint) {
        setAiHint(data.hint);
      } else {
        setAiHint("Could not generate a hint at this time.");
      }
    } catch (error) {
      console.error(error);
      setAiHint("Could not reach the AI agent. Please try again.");
    } finally {
      setIsFetchingHint(false);
    }
  };

  const handleCompile = async () => {
    if (!currentCode || !currentCode.trim()) {
      setCompilerOutput("Error: No code provided to compile.");
      return;
    }
    setIsCompiling(true);
    setCompilerOutput(null);
    
    try {
      const response = await fetch('/api/compile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: currentCode,
          language: codeLanguage,
          experiment: experiment.title,
          aim: experiment.aim
        })
      });
      const data = await response.json();
      
      if (data.success) {
        setCompilerOutput(experiment.expectedOutput || 'Program exited with code 0.\nOutput: Success');
        tracker.setCodeVerified(true);
      } else {
        setCompilerOutput(data.output || data.error || 'Compilation failed.');
      }
    } catch (error) {
      console.error("Compilation error:", error);
      setCompilerOutput("Error: Could not reach the compilation server.");
    } finally {
      setIsCompiling(false);
    }
  };

  // Quiz state with per-experiment synchronization
  const [userAnswers, setUserAnswers] = useState<Record<number, number>>(() => {
    try {
      const userKey = userSession?.email || 'anon';
      const saved = localStorage.getItem(`kjsit_exp_quiz_answers_${userKey}_${experiment.id}`);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(() => {
    try {
      const userKey = userSession?.email || 'anon';
      return localStorage.getItem(`kjsit_exp_quiz_submitted_${userKey}_${experiment.id}`) === 'true';
    } catch {
      return false;
    }
  });

  // Re-sync quiz state when switching experiments
  useEffect(() => {
    const userKey = userSession?.email || 'anon';
    try {
      const isSub = localStorage.getItem(`kjsit_exp_quiz_submitted_${userKey}_${experiment.id}`) === 'true';
      setQuizSubmitted(isSub);
      const saved = localStorage.getItem(`kjsit_exp_quiz_answers_${userKey}_${experiment.id}`);
      setUserAnswers(saved ? JSON.parse(saved) : {});
    } catch {
      setQuizSubmitted(false);
      setUserAnswers({});
    }
  }, [experiment.id, userSession?.email]);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleSelectQuizOption = (questionId: number, optionIdx: number) => {
    if (quizSubmitted) return;
    setUserAnswers(prev => ({
      ...prev,
      [questionId]: optionIdx
    }));
  };

  const handleSubmitQuiz = () => {
    if (Object.keys(userAnswers).length < experiment.quiz.length) {
      return;
    }
    setQuizSubmitted(true);
    // calculate score
    let score = 0;
    experiment.quiz.forEach(q => {
      if (userAnswers[q.id] === q.correctAnswer) score++;
    });

    tracker.setQuizScore(score);

    const userKey = userSession?.email || 'anon';
    try {
      localStorage.setItem(`kjsit_exp_quiz_answers_${userKey}_${experiment.id}`, JSON.stringify(userAnswers));
      localStorage.setItem(`kjsit_exp_quiz_submitted_${userKey}_${experiment.id}`, 'true');
      localStorage.setItem(`kjsit_exp_quiz_${userKey}_${experiment.id}`, String(score));
    } catch {}

    if (score === experiment.quiz.length) {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 }
      });
    }
  };

  const handleResetQuiz = () => {
    setUserAnswers({});
    setQuizSubmitted(false);
    tracker.setQuizScore(null);
    const userKey = userSession?.email || 'anon';
    try {
      localStorage.removeItem(`kjsit_exp_quiz_answers_${userKey}_${experiment.id}`);
      localStorage.removeItem(`kjsit_exp_quiz_submitted_${userKey}_${experiment.id}`);
      localStorage.removeItem(`kjsit_exp_quiz_${userKey}_${experiment.id}`);
    } catch {}
  };

  const calculateScore = () => {
    let score = 0;
    experiment.quiz.forEach(q => {
      if (userAnswers[q.id] === q.correctAnswer) score++;
    });
    return score;
  };

  return (
    <div className="py-8 bg-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb & Navigation */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-zinc-200">
          <div className="flex items-center gap-3">
            <button
              onClick={() => onBackToLab(subjectId)}
              className="inline-flex items-center gap-2 px-3 py-1.5 bg-white border border-zinc-300 rounded-lg text-xs font-bold text-zinc-800 hover:bg-zinc-100 transition-colors shadow-2xs cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>{currentSubject ? `${currentSubject.name} (${currentSubject.code})` : 'Back to Laboratory'}</span>
            </button>
            <span className="text-xs text-zinc-400">/</span>
            <span className="text-xs font-mono font-bold text-zinc-600">Experiment #{experiment.num}</span>
            <span className="text-xs text-zinc-400">/</span>
            <span className="text-xs font-bold text-red-700 truncate max-w-[200px] sm:max-w-none">
              {experiment.title}
            </span>
          </div>

          {/* Quick Prev / Next Navigator */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (prevExperiment) {
                  onSelectExperiment(prevExperiment.id);
                  setActiveTab('aim');
                  setQuizSubmitted(false);
                  setUserAnswers({});
                }
              }}
              disabled={!prevExperiment}
              className="p-1.5 bg-white border border-zinc-300 rounded-lg text-zinc-700 hover:bg-zinc-100 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
              title="Previous Experiment"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                if (nextExperiment) {
                  onSelectExperiment(nextExperiment.id);
                  setActiveTab('aim');
                  setQuizSubmitted(false);
                  setUserAnswers({});
                }
              }}
              disabled={!nextExperiment}
              className="p-1.5 bg-white border border-zinc-300 rounded-lg text-zinc-700 hover:bg-zinc-100 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
              title="Next Experiment"
            >
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Active Lab Session Tracker & Verification Bar */}
        <div className="mb-6 rounded-xl overflow-hidden shadow-xs border border-zinc-800">
          <LabActiveTrackerBar
            status={tracker.status}
            sessionActiveSeconds={tracker.sessionActiveSeconds}
            formattedSessionTime={tracker.formattedSessionTime}
            simulationExecuted={tracker.simulationExecuted}
            codeVerified={tracker.codeVerified}
            quizScore={tracker.quizScore}
            isCompletedAlready={tracker.isCompletedAlready}
            isSubmitting={tracker.isSubmitting}
            onSubmit={tracker.submitExperimentCompletion}
            userSession={userSession}
            onOpenLogin={onOpenLogin || (() => {})}
            experimentTitle={experiment.title}
            onNavigateTab={(tab) => {
              setActiveTab(tab);
            }}
          />
        </div>

        {/* Experiment Title Header - Broad black text with experiment number & Print Lab Manual in right corner */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pt-1 pb-4 border-b border-zinc-200">
          <div className="max-w-4xl">
            <h1 className="text-xl sm:text-2xl lg:text-[28px] font-black text-black tracking-tight leading-snug">
              Experiment {experiment.num}: {experiment.title}
            </h1>
          </div>

          <div className="shrink-0 flex items-center">
            <button
              type="button"
              id="print-lab-manual-btn"
              onClick={() => setShowPrintModal(true)}
              className="px-4 py-2.5 bg-white hover:bg-zinc-50 border border-zinc-300 hover:border-red-600 text-zinc-900 hover:text-red-700 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all shadow-xs hover:shadow-md active:scale-95 cursor-pointer"
              title="Generate, Preview & Print Official Somaiya Lab Manual"
            >
              <Printer className="w-4 h-4 text-red-700" />
              <span>Print Lab Manual</span>
            </button>
          </div>
        </div>

        {/* Standard KJSIT Virtual Labs Tab Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 border-b border-zinc-200 mb-8 scrollbar-none">
          <button
            onClick={() => setActiveTab('aim')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'aim'
                ? 'bg-red-700 text-white shadow-md shadow-red-700/20'
                : 'bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-100'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>1. Aim</span>
          </button>

          <button
            onClick={() => setActiveTab('theory')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'theory'
                ? 'bg-red-700 text-white shadow-md shadow-red-700/20'
                : 'bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-100'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>2. Theory & Complexity</span>
          </button>

          <button
            onClick={() => setActiveTab('algorithm')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'algorithm'
                ? 'bg-red-700 text-white shadow-md shadow-red-700/20'
                : 'bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-100'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>3. Algorithm</span>
          </button>

          <button
            onClick={() => setActiveTab('simulation')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'simulation'
                ? 'bg-black text-white shadow-md shadow-black/20'
                : 'bg-zinc-100 border border-zinc-300 text-black hover:bg-zinc-200'
            }`}
          >
            <Cpu className="w-3.5 h-3.5 text-red-500" />
            <span>4. Interactive Simulator</span>
          </button>

          <button
            onClick={() => setActiveTab('code')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'code'
                ? 'bg-red-700 text-white shadow-md shadow-red-700/20'
                : 'bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-100'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>5. Multi-Language Code</span>
          </button>

          {/* PARAMETER 6: CodinGame Puzzles */}
          {hasPuzzles && (
            <button
              id="codingame-puzzles-tab"
              onClick={() => setActiveTab('puzzles')}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'puzzles'
                  ? 'bg-red-700 text-white shadow-md shadow-red-700/20'
                  : 'bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-100'
              }`}
            >
              <Gamepad2 className="w-3.5 h-3.5" />
              <span>6. In-Built Game & Puzzles</span>
            </button>
          )}

          {/* PARAMETER 7 (or 6): Self-Evaluation */}
          <button
            id="self-evaluation-tab"
            onClick={() => setActiveTab('quiz')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'quiz'
                ? 'bg-red-700 text-white shadow-md shadow-red-700/20'
                : 'bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-100'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>{hasPuzzles ? '7. Self-Evaluation' : '6. Self-Evaluation'}</span>
          </button>

          {/* PARAMETER 8 (or 7): Conclusion & References */}
          <button
            id="conclusion-tab"
            onClick={() => setActiveTab('conclusion')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'conclusion'
                ? 'bg-red-700 text-white shadow-md shadow-red-700/20'
                : 'bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-100'
            }`}
          >
            <Award className="w-3.5 h-3.5" />
            <span>{hasPuzzles ? '8. Conclusion & References' : '7. Conclusion & References'}</span>
          </button>
        </div>

        {/* TAB 1: AIM */}
        {activeTab === 'aim' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-zinc-200 shadow-xs space-y-6">
            <div>
              <h2 className="text-base font-bold text-black uppercase tracking-wider mb-2 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-red-600"></span>
                Experiment Aim
              </h2>
              <div className="bg-red-50/70 border border-red-200 p-4 rounded-xl text-zinc-900 text-sm leading-relaxed font-medium">
                {experiment.aim}
              </div>
            </div>

            {experiment.objective && (
              <div>
                <h2 className="text-base font-bold text-black uppercase tracking-wider mb-2 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                  Experiment Objective
                </h2>
                <div className="bg-blue-50/70 border border-blue-200 p-4 rounded-xl text-black text-sm leading-relaxed font-medium">
                  {experiment.objective}
                </div>
              </div>
            )}

            {experiment.software && (
              <div className="flex items-center gap-2.5 p-3.5 bg-emerald-50/80 border border-emerald-200 rounded-xl text-emerald-950">
                <Cpu className="w-4 h-4 text-emerald-700 shrink-0" />
                <div className="text-xs">
                  <span className="font-bold text-emerald-900">Required Software / Environment: </span>
                  <span className="font-mono font-bold bg-white px-2 py-0.5 rounded border border-emerald-300 text-emerald-800">
                    {experiment.software}
                  </span>
                </div>
              </div>
            )}

            {(() => {
              const objectives = getExperimentLaboratoryObjectives(experiment);
              if (!objectives || objectives.length === 0) return null;
              return (
                <div>
                  <h3 className="text-sm font-bold text-black mb-3">Laboratory Objectives:</h3>
                  <ul className="space-y-2 text-xs sm:text-sm text-black">
                    {objectives.map((obj, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                        <span className="text-black">{obj}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })()}

            <div className="pt-4 border-t border-zinc-100 flex justify-end">
              <button
                onClick={() => setActiveTab('theory')}
                className="px-4 py-2 bg-red-700 hover:bg-red-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer"
              >
                <span>Proceed to Theory & Complexity</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: THEORY */}
        {activeTab === 'theory' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-zinc-200 shadow-xs space-y-8">
            {/* Overview paragraphs */}
            <div>
              <h2 className="text-base font-bold text-black uppercase tracking-wider mb-4 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-red-600"></span>
                Theoretical Background
              </h2>
              <div className="space-y-3 text-xs sm:text-sm text-black leading-relaxed font-normal">
                {experiment.theory.overview.map((para, i) => (
                  <p key={i}>{para}</p>
                ))}
              </div>
            </div>

            {/* Complexity Table */}
            <div>
              <h3 className="text-sm font-bold text-black mb-3">
                Asymptotic Complexity & Algorithm Properties
              </h3>
              <div className="overflow-x-auto border border-zinc-200 rounded-xl">
                <table className="w-full text-xs text-left">
                  <thead className="bg-zinc-100 text-black font-semibold border-b border-zinc-200">
                    <tr>
                      <th className="py-2.5 px-4">Parameter</th>
                      <th className="py-2.5 px-4">Value / Asymptotic Bound</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-100">
                    {experiment.theory.complexityTable.map((row, idx) => (
                      <tr key={idx} className="hover:bg-zinc-50">
                        <td className="py-2.5 px-4 font-semibold text-black">{row.parameter}</td>
                        <td className="py-2.5 px-4 font-mono font-bold text-red-700">{row.value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Key Points */}
            <div>
              <h3 className="text-sm font-bold text-black mb-3">Key Design Principles</h3>
              <ul className="space-y-2 text-xs sm:text-sm text-black">
                {experiment.theory.keyPoints.map((pt, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-600 mt-2 shrink-0"></span>
                    <span>{pt}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Real World Applications */}
            <div className="bg-zinc-50 p-4 rounded-xl border border-zinc-200">
              <h3 className="text-xs font-bold text-black uppercase tracking-wider mb-2">
                Real-World Engineering Applications
              </h3>
              <ul className="space-y-1.5 text-xs text-black">
                {experiment.theory.realWorldApplications.map((app, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-red-600 shrink-0 mt-0.5" />
                    <span>{app}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="pt-4 border-t border-zinc-100 flex justify-between">
              <button
                onClick={() => setActiveTab('aim')}
                className="px-4 py-2 border border-zinc-300 rounded-lg text-xs font-semibold text-zinc-700 hover:bg-zinc-100 cursor-pointer"
              >
                &larr; Back to Aim
              </button>
              <button
                onClick={() => setActiveTab('simulation')}
                className="px-4 py-2 bg-red-700 hover:bg-red-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer"
              >
                <span>Launch Interactive Simulation</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* TAB 3: ALGORITHM */}
        {activeTab === 'algorithm' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-zinc-200 shadow-xs space-y-6">
            <div>
              <h2 className="text-base font-bold text-black uppercase tracking-wider mb-4 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-red-600"></span>
                Step-by-Step Algorithm & Pseudocode
              </h2>

              <div className="bg-black text-zinc-100 p-5 rounded-xl font-mono text-xs leading-relaxed overflow-x-auto border border-zinc-900 space-y-1">
                {experiment.algorithm.map((line, idx) => (
                  <div key={idx} className="whitespace-pre">
                    {line}
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-sm font-bold text-black mb-3">Virtual Laboratory Procedure</h3>
              <ol className="space-y-2 text-xs sm:text-sm text-black list-decimal list-inside">
                {experiment.procedure.map((proc, i) => (
                  <li key={i} className="leading-relaxed">{proc}</li>
                ))}
              </ol>
            </div>

            <div className="pt-4 border-t border-zinc-100 flex flex-wrap items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => {
                  setSimViewMode('tracer');
                  setActiveTab('simulation');
                }}
                className="px-4 py-2 bg-[#0F172A] hover:bg-[#1E293B] text-white text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer border border-[#0EA5E9]/40 shadow-sm transition-all active:scale-95"
              >
                <Activity className="w-4 h-4 text-[#00D8FF] animate-pulse" />
                <span>Run Live Code & Step Tracer</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setSimViewMode('canvas');
                  setActiveTab('simulation');
                }}
                className="px-4 py-2 bg-red-700 hover:bg-red-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer"
              >
                <span>Open Simulator</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* TAB 4: SIMULATION */}
        {activeTab === 'simulation' && (
          <div className="space-y-4">
            {/* Simulation Header with Completion Status */}
            <div className="flex items-center justify-between pb-3 border-b border-zinc-200">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-red-600 animate-pulse" />
                <h4 className="text-xs font-bold text-zinc-900 uppercase tracking-wider">
                  Interactive Graphical Simulation & Live Code Tracer
                </h4>
              </div>

              {tracker.simulationExecuted && (
                <div className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-lg text-xs font-bold shadow-2xs">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Simulation Completed</span>
                </div>
              )}
            </div>

            {/* Simulation View - Ticks Simulation as Completed on any control/button interaction */}
            <div
              onClickCapture={(e) => {
                const target = e.target as HTMLElement | null;
                if (
                  target &&
                  (target.closest('button') ||
                    target.closest('input') ||
                    target.closest('select') ||
                    target.closest('[role="button"]') ||
                    target.closest('[role="checkbox"]') ||
                    target.closest('[role="tab"]'))
                ) {
                  if (!tracker.simulationExecuted) {
                    tracker.setSimulationExecuted(true);
                  }
                }
              }}
              onChangeCapture={() => {
                if (!tracker.simulationExecuted) {
                  tracker.setSimulationExecuted(true);
                }
              }}
            >
              <ExperimentSimulator
                experimentId={experiment.id}
                onSimulationComplete={() => {
                  tracker.setSimulationExecuted(true);
                  setIsSimulationFinished(true);
                }}
              />
            </div>
          </div>
        )}

        {/* TAB 5: PROGRAM CODE */}
        {activeTab === 'code' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-zinc-200 shadow-xs space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-zinc-100">
              <div>
                <h2 className="text-base font-bold text-black uppercase tracking-wider">
                  Program Source Code
                </h2>
                <p className="text-xs text-zinc-500">
                  Ready-to-compile source code in multiple languages
                </p>
              </div>

              {/* Language Tabs */}
              <div className="flex items-center gap-1 bg-zinc-100 p-1 rounded-xl flex-wrap">
                {experiment.code.html && (
                  <button
                    onClick={() => setCodeLanguage('html')}
                    className={`px-3 py-1 text-xs font-mono font-bold rounded-lg uppercase transition-all cursor-pointer ${
                      codeLanguage === 'html'
                        ? 'bg-red-700 text-white shadow-xs'
                        : 'text-zinc-600 hover:text-zinc-900'
                    }`}
                  >
                    HTML5
                  </button>
                )}
                {experiment.code.css && (
                  <button
                    onClick={() => setCodeLanguage('css')}
                    className={`px-3 py-1 text-xs font-mono font-bold rounded-lg uppercase transition-all cursor-pointer ${
                      codeLanguage === 'css'
                        ? 'bg-red-700 text-white shadow-xs'
                        : 'text-zinc-600 hover:text-zinc-900'
                    }`}
                  >
                    CSS3
                  </button>
                )}
                {experiment.code.js && (
                  <button
                    onClick={() => setCodeLanguage('js')}
                    className={`px-3 py-1 text-xs font-mono font-bold rounded-lg uppercase transition-all cursor-pointer ${
                      codeLanguage === 'js'
                        ? 'bg-red-700 text-white shadow-xs'
                        : 'text-zinc-600 hover:text-zinc-900'
                    }`}
                  >
                    JavaScript (Node/ES6)
                  </button>
                )}
                {experiment.code.ts && (
                  <button
                    onClick={() => setCodeLanguage('ts')}
                    className={`px-3 py-1 text-xs font-mono font-bold rounded-lg uppercase transition-all cursor-pointer ${
                      codeLanguage === 'ts'
                        ? 'bg-red-700 text-white shadow-xs'
                        : 'text-zinc-600 hover:text-zinc-900'
                    }`}
                  >
                    TypeScript / React
                  </button>
                )}
                {experiment.code.json && (
                  <button
                    onClick={() => setCodeLanguage('json')}
                    className={`px-3 py-1 text-xs font-mono font-bold rounded-lg uppercase transition-all cursor-pointer ${
                      codeLanguage === 'json'
                        ? 'bg-red-700 text-white shadow-xs'
                        : 'text-zinc-600 hover:text-zinc-900'
                    }`}
                  >
                    JSON / Config
                  </button>
                )}
                {experiment.code.sql && (
                  <button
                    onClick={() => setCodeLanguage('sql')}
                    className={`px-3 py-1 text-xs font-mono font-bold rounded-lg uppercase transition-all cursor-pointer ${
                      codeLanguage === 'sql'
                        ? 'bg-red-700 text-white shadow-xs'
                        : 'text-zinc-600 hover:text-zinc-900'
                    }`}
                  >
                    SQL / DDL
                  </button>
                )}
                {experiment.code.bash && (
                  <button
                    onClick={() => setCodeLanguage('bash')}
                    className={`px-3 py-1 text-xs font-mono font-bold rounded-lg uppercase transition-all cursor-pointer ${
                      codeLanguage === 'bash'
                        ? 'bg-red-700 text-white shadow-xs'
                        : 'text-zinc-600 hover:text-zinc-900'
                    }`}
                  >
                    Bash / Shell
                  </button>
                )}
                {(['c', 'cpp', 'python', 'java'] as const).map((lang) => {
                  
                  return (
                    <button
                      key={lang}
                      onClick={() => setCodeLanguage(lang)}
                      className={`px-3 py-1 text-xs font-mono font-bold rounded-lg uppercase transition-all cursor-pointer ${
                        codeLanguage === lang
                          ? 'bg-red-700 text-white shadow-xs'
                          : 'text-zinc-600 hover:text-zinc-900'
                      }`}
                    >
                      {lang === 'cpp' ? 'C++' : lang}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Online Compiler IDE Box */}
            <div className="flex flex-col rounded-xl overflow-hidden border border-zinc-800 shadow-xl bg-zinc-950">
              {/* IDE Header Toolbar */}
              <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 bg-zinc-900 border-b border-zinc-800">
                <div className="flex items-center gap-3">
                  <div className="flex gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-red-500/20 border border-red-500/50"></div>
                    <div className="w-3 h-3 rounded-full bg-amber-500/20 border border-amber-500/50"></div>
                    <div className="w-3 h-3 rounded-full bg-emerald-500/20 border border-emerald-500/50"></div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-zinc-300 font-bold uppercase tracking-wider">{codeLanguage} Studio</span>
                    {saveStatus === 'saved' && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px] font-medium animate-fade-in">
                        <Check className="w-2.5 h-2.5" />
                        <span>Saved</span>
                      </span>
                    )}
                  </div>
                </div>

                {/* Toolbar Quick Actions */}
                <div className="flex items-center gap-1.5 flex-wrap">
                  {/* Reset to Blank */}
                  <button
                    onClick={handleResetCode}
                    title="Clear editor to blank"
                    className="p-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-zinc-200 text-xs rounded-md transition-colors border border-zinc-700 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>

                  {/* Copy Code */}
                  <button
                    onClick={handleCopyCode}
                    title="Copy all code to clipboard"
                    className="px-2.5 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white text-xs font-medium rounded-md flex items-center gap-1.5 transition-colors border border-zinc-700 cursor-pointer"
                  >
                    {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-zinc-400" />}
                    <span>{copiedCode ? 'Copied' : 'Copy'}</span>
                  </button>

                  {/* AI Hint */}
                  <button
                    onClick={handleGetHint}
                    disabled={isFetchingHint}
                    className="px-3 py-1.5 bg-indigo-900/40 hover:bg-indigo-800/60 disabled:opacity-50 text-indigo-300 hover:text-indigo-200 text-xs font-bold rounded-md flex items-center gap-1.5 transition-colors border border-indigo-700/50 cursor-pointer"
                  >
                    {isFetchingHint ? (
                      <div className="w-3.5 h-3.5 border-2 border-indigo-400/30 border-t-indigo-400 rounded-full animate-spin"></div>
                    ) : (
                      <Sparkles className="w-3.5 h-3.5" />
                    )}
                    <span>{isFetchingHint ? 'Thinking...' : 'AI Hint'}</span>
                  </button>

                  {/* Trace Execution */}
                  <button
                    type="button"
                    onClick={() => {
                      setSimViewMode('tracer');
                      setActiveTab('simulation');
                    }}
                    title="Trace execution step-by-step with line highlighting"
                    className="px-2.5 py-1.5 bg-[#0F172A] hover:bg-[#1E293B] text-[#00D8FF] hover:text-white text-xs font-bold rounded-md flex items-center gap-1.5 transition-colors border border-[#0EA5E9]/50 cursor-pointer shadow-xs"
                  >
                    <Activity className="w-3.5 h-3.5 text-[#00D8FF]" />
                    <span className="hidden sm:inline">Trace Execution</span>
                  </button>

                  {/* Run & AI Verify */}
                  <button
                    onClick={handleCompile}
                    disabled={isCompiling}
                    className="px-3.5 py-1.5 bg-red-700 hover:bg-red-600 disabled:opacity-50 disabled:cursor-not-allowed text-white text-xs font-bold rounded-md transition-colors shadow-md flex items-center gap-1.5 cursor-pointer"
                  >
                    {isCompiling ? (
                      <>
                        <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                        <span>AI Verifying...</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>Run & AI Verify</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* AI Hint Output */}
              {aiHint && (
                <div className="border-b border-indigo-900/50 bg-indigo-950/20 p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-indigo-400" />
                      <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider">AI Teaching Assistant</span>
                    </div>
                    <button onClick={() => setAiHint(null)} className="text-zinc-500 hover:text-zinc-300">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="text-sm text-zinc-300 leading-relaxed markdown-body">
                    <Markdown>{aiHint}</Markdown>
                  </div>
                </div>
              )}

              {/* IDE Workspace */}
              <div className="relative border-t border-zinc-800 bg-zinc-950 h-[480px] flex flex-col">
                {/* Monaco Editor */}
                <div className="flex-1 relative">
                  <Editor
                    height="100%"
                    language={getMonacoLanguage(codeLanguage)}
                    theme={editorTheme}
                    value={currentCode}
                    onChange={handleCodeChange}
                    onMount={handleEditorDidMount}
                    options={{
                      minimap: { enabled: showMinimap },
                      fontSize: editorFontSize,
                      scrollBeyondLastLine: false,
                      wordWrap: "on",
                      automaticLayout: true,
                      padding: { top: 16, bottom: 16 },
                      bracketPairColorization: { enabled: true, independentColorPoolPerBracketType: true },
                      formatOnPaste: true,
                      formatOnType: true,
                      suggestOnTriggerCharacters: true,
                      renderLineHighlight: "all",
                      folding: true,
                      showUnused: true,
                      matchBrackets: "always",
                      cursorBlinking: "smooth",
                      cursorSmoothCaretAnimation: "on",
                      smoothScrolling: true,
                      fontFamily: "'JetBrains Mono', 'Fira Code', 'Courier New', monospace",
                    }}
                    loading={<div className="flex items-center justify-center h-full text-zinc-500">Loading editor workspace...</div>}
                  />
                </div>

                {/* VS Code Style IDE Status Bar */}
                <div className="bg-zinc-900 border-t border-zinc-800 px-3 py-1.5 flex flex-wrap items-center justify-between text-[11px] font-mono text-zinc-400 select-none">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1.5 text-zinc-300">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                      <span>Ln {cursorPos.line}, Col {cursorPos.column}</span>
                    </div>
                    <span className="text-zinc-700">|</span>
                    <span>UTF-8</span>
                    <span className="text-zinc-700">|</span>
                    <span className="uppercase text-zinc-300 font-semibold">{getMonacoLanguage(codeLanguage)}</span>
                  </div>

                  <div className="flex items-center gap-2.5">
                    {saveToast && (
                      <span className="flex items-center gap-1 text-emerald-400 font-sans font-medium text-xs animate-pulse">
                        <Check className="w-3 h-3" />
                        <span>{saveToast}</span>
                      </span>
                    )}
                    <button
                      onClick={() => setShowShortcutsModal(true)}
                      title="View all VS Code Shortcuts"
                      className="p-1 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 rounded transition-colors cursor-pointer flex items-center gap-1"
                    >
                      <Keyboard className="w-3.5 h-3.5 text-zinc-400" />
                      <span className="hidden md:inline text-[10px] text-zinc-400">Shortcuts</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Terminal Output */}
              {(isCompiling || compilerOutput) && (
                <div className="border-t border-zinc-800 bg-zinc-950 p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Terminal Output</span>
                    {compilerOutput && (
                      <button onClick={() => setCompilerOutput(null)} className="text-zinc-500 hover:text-zinc-300">
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                  <div className="font-mono text-xs p-3 rounded-lg bg-black border border-zinc-900 text-zinc-300 min-h-[80px] whitespace-pre-wrap">
                    {isCompiling ? (
                      <span className="text-amber-500 animate-pulse">$ Compiling and executing...</span>
                    ) : (
                      <span className={compilerOutput?.match(/error|failed/i) ? 'text-red-400' : 'text-emerald-400'}>
                        {compilerOutput}
                      </span>
                    )}
                  </div>
                </div>
              )}

              {/* Bottom Navigation */}
              <div className="p-4 bg-zinc-950 border-t border-zinc-800 flex items-center justify-between">
                <span className="text-xs text-zinc-400">
                  {hasPuzzles ? 'Parameter 5 of 8 completed' : 'Parameter 5 of 7 completed'}
                </span>
                <button
                  onClick={() => setActiveTab(hasPuzzles ? 'puzzles' : 'quiz')}
                  className="px-4 py-2 bg-red-700 hover:bg-red-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-sm transition-all"
                >
                  <span>{hasPuzzles ? 'Proceed to 6. In-Built Game & Puzzles' : 'Proceed to Self-Evaluation'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* PARAMETER 6: IN-BUILT GAME & CODINGAME PUZZLES */}
        {activeTab === 'puzzles' && (
          <CodingamePuzzlesView
            experimentId={experiment.id}
            puzzles={codingamePuzzles}
            experimentTitle={experiment.title}
            onProceedToSelfEvaluation={() => setActiveTab('quiz')}
          />
        )}

        {/* PARAMETER 7 (or 6): SELF-EVALUATION / QUIZ */}
        {activeTab === 'quiz' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-zinc-200 shadow-xs space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-zinc-100">
              <div>
                <h2 className="text-base font-bold text-black uppercase tracking-wider">
                  {hasPuzzles ? 'Parameter 7: Post-Lab Self-Evaluation Quiz' : 'Parameter 6: Post-Lab Self-Evaluation Quiz'}
                </h2>
                <p className="text-xs text-zinc-500">
                  Test your understanding of algorithmic correctness and complexity
                </p>
              </div>

              {quizSubmitted && (
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold px-3 py-1 bg-red-100 text-red-800 rounded-lg border border-red-200">
                    Score: {calculateScore()} / {experiment.quiz.length} ({((calculateScore() / experiment.quiz.length) * 100).toFixed(0)}%)
                  </span>
                  <button
                    onClick={handleResetQuiz}
                    className="p-1.5 border border-zinc-300 rounded-lg hover:bg-zinc-100 text-zinc-700 text-xs flex items-center gap-1 cursor-pointer"
                    title="Retake Quiz"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            {/* Questions List */}
            <div className="space-y-6">
              {experiment.quiz.map((q, qIndex) => {
                const selectedOpt = userAnswers[q.id];
                const isAnswered = selectedOpt !== undefined;
                const isCorrect = selectedOpt === q.correctAnswer;

                let questionBoxStyle = 'bg-zinc-50 border-zinc-200';
                if (quizSubmitted) {
                  questionBoxStyle = isCorrect ? 'bg-emerald-50/50 border-emerald-200' : 'bg-red-50/50 border-red-200';
                }

                return (
                  <div
                    key={q.id}
                    className={`p-5 rounded-xl border transition-all ${questionBoxStyle}`}
                  >
                    <div className="flex items-start gap-2 mb-3">
                      <span className="w-6 h-6 rounded-full bg-black text-white font-mono text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                        Q{qIndex + 1}
                      </span>
                      <h3 className="text-sm font-bold text-black">{q.question}</h3>
                    </div>

                    {/* Options */}
                    <div className="space-y-2 pl-8">
                      {q.options.map((opt, optIdx) => {
                        const isOptionSelected = selectedOpt === optIdx;
                        const isThisCorrect = optIdx === q.correctAnswer;

                        let optStyle = 'bg-white border-zinc-200 text-zinc-700 hover:bg-zinc-100';
                        if (quizSubmitted) {
                          if (isThisCorrect) {
                            optStyle = 'bg-emerald-100 border-emerald-400 text-emerald-950 font-bold';
                          } else if (isOptionSelected && !isThisCorrect) {
                            optStyle = 'bg-red-100 border-red-300 text-red-950 line-through';
                          }
                        } else if (isOptionSelected) {
                          optStyle = 'bg-red-100 border-red-400 text-red-950 font-semibold ring-2 ring-red-500/20';
                        }

                        return (
                          <button
                            key={optIdx}
                            onClick={() => handleSelectQuizOption(q.id, optIdx)}
                            disabled={quizSubmitted}
                            className={`w-full text-left p-3 rounded-lg border text-xs flex items-center justify-between transition-all cursor-pointer ${optStyle}`}
                          >
                            <span>{opt}</span>
                            {quizSubmitted && isThisCorrect && (
                              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {/* Explanation */}
                    {quizSubmitted && (
                      <div className="mt-3 pl-8 text-xs text-zinc-600 bg-white/80 p-2.5 rounded-lg border border-zinc-200">
                        <strong className="text-black">Explanation:</strong> {q.explanation}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {!quizSubmitted ? (
              <div className="pt-4 border-t border-zinc-100 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="text-xs text-zinc-500">
                  {Object.keys(userAnswers).length === experiment.quiz.length ? (
                    <span className="text-emerald-700 font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      All {experiment.quiz.length} questions answered! Ready to submit.
                    </span>
                  ) : (
                    <span>
                      Answer all questions to complete: {Object.keys(userAnswers).length} of {experiment.quiz.length} answered
                    </span>
                  )}
                </div>
                <button
                  onClick={handleSubmitQuiz}
                  disabled={Object.keys(userAnswers).length < experiment.quiz.length}
                  className="px-5 py-2.5 bg-red-700 hover:bg-red-800 disabled:opacity-40 disabled:cursor-not-allowed text-white text-xs font-bold rounded-lg shadow-sm flex items-center gap-2 cursor-pointer transition-all"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Submit & Verify Answers ({Object.keys(userAnswers).length}/{experiment.quiz.length})</span>
                </button>
              </div>
            ) : (
              <div className="pt-4 border-t border-zinc-100 flex justify-between items-center">
                <button
                  onClick={handleResetQuiz}
                  className="px-4 py-2 border border-zinc-300 rounded-lg text-xs font-semibold text-zinc-700 hover:bg-zinc-100 cursor-pointer"
                >
                  Retake Quiz
                </button>
                <button
                  onClick={() => setActiveTab('conclusion')}
                  className="px-4 py-2 bg-red-700 hover:bg-red-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer"
                >
                  <span>{hasPuzzles ? 'Proceed to 8. Conclusion & References' : 'View Conclusion'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* PARAMETER 8 (or 7): CONCLUSION & REFERENCES */}
        {activeTab === 'conclusion' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-zinc-200 shadow-xs space-y-6">
            <div>
              <h2 className="text-base font-bold text-black uppercase tracking-wider mb-2 flex items-center gap-2">
                <Award className="w-5 h-5 text-red-600" />
                {hasPuzzles ? 'Parameter 8: Experimental Conclusion' : 'Experimental Conclusion'}
              </h2>
              <div className="bg-zinc-50 border border-zinc-200 p-4 rounded-xl text-black text-sm leading-relaxed">
                {experiment.conclusion}
              </div>
            </div>

            {experiment.postLabQuestions && experiment.postLabQuestions.length > 0 && (
              <div className="space-y-3 pt-2">
                <h3 className="text-sm font-bold text-black flex items-center gap-2">
                  <HelpCircle className="w-4 h-4 text-red-600" />
                  <span>Official Post-Lab Viva & Assessment Questions (Lab Manual)</span>
                </h3>
                <div className="space-y-3">
                  {experiment.postLabQuestions.map((item, idx) => (
                    <div key={idx} className="bg-red-50/40 border border-red-200/80 rounded-xl p-4 space-y-2">
                      <div className="text-xs sm:text-sm font-bold text-black flex items-start gap-2">
                        <span className="text-red-700 font-mono font-bold">Q{idx + 1}.</span>
                        <span>{item.question}</span>
                      </div>
                      {item.answer && (
                        <div className="text-xs sm:text-sm text-black bg-white p-3 rounded-lg border border-red-100 leading-relaxed">
                          <strong className="text-emerald-700">Model Answer: </strong>
                          {item.answer}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div>
              <h3 className="text-sm font-bold text-black mb-3">Academic References & Citations</h3>
              <ul className="space-y-2 text-xs text-black">
                {experiment.references.map((ref, i) => (
                  <li key={i} className="flex items-start gap-2 bg-zinc-50 p-3 rounded-lg border border-zinc-200">
                    <span className="font-bold text-black">[{i + 1}]</span>
                    <span className="text-black font-normal">{ref}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="pt-4 border-t border-zinc-100 flex justify-between">
              <button
                onClick={() => onBackToLab(subjectId)}
                className="px-4 py-2 border border-zinc-300 rounded-lg text-xs font-semibold text-zinc-700 hover:bg-zinc-100 cursor-pointer"
              >
                &larr; Return to {currentSubject?.name || 'Laboratory'}
              </button>
              {nextExperiment && (
                <button
                  onClick={() => {
                    onSelectExperiment(nextExperiment.id);
                    setActiveTab('aim');
                    setQuizSubmitted(false);
                    setUserAnswers({});
                  }}
                  className="px-4 py-2 bg-red-700 hover:bg-red-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer"
                >
                  <span>Next Experiment: #{nextExperiment.num} {nextExperiment.title}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        )}
        {/* VS Code Keyboard Shortcuts Modal */}
        {showShortcutsModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fade-in">
            <div className="bg-zinc-900 border border-zinc-700 rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden text-zinc-200">
              <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-950">
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 bg-red-600/20 text-red-400 rounded-lg">
                    <Keyboard className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-white">Monaco & VS Code Shortcuts</h3>
                    <p className="text-[11px] text-zinc-400">Standard desktop keybindings active in the editor</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowShortcutsModal(false)}
                  className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto font-sans text-xs">
                {/* Standard Requested Shortcuts */}
                <div>
                  <h4 className="font-bold text-[11px] uppercase tracking-wider text-emerald-400 mb-2.5">
                    Essential Keybindings
                  </h4>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-2.5 bg-zinc-950 rounded-lg border border-zinc-800">
                      <span className="text-zinc-300 font-medium">Save Code locally</span>
                      <div className="flex items-center gap-1 font-mono">
                        <kbd className="px-2 py-1 bg-zinc-800 text-zinc-200 border border-zinc-700 rounded text-xs font-bold">Ctrl</kbd>
                        <span>+</span>
                        <kbd className="px-2 py-1 bg-zinc-800 text-zinc-200 border border-zinc-700 rounded text-xs font-bold">S</kbd>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-2.5 bg-zinc-950 rounded-lg border border-zinc-800">
                      <span className="text-zinc-300 font-medium">Toggle Line Comment</span>
                      <div className="flex items-center gap-1 font-mono">
                        <kbd className="px-2 py-1 bg-zinc-800 text-zinc-200 border border-zinc-700 rounded text-xs font-bold">Ctrl</kbd>
                        <span>+</span>
                        <kbd className="px-2 py-1 bg-zinc-800 text-zinc-200 border border-zinc-700 rounded text-xs font-bold">/</kbd>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-2.5 bg-zinc-950 rounded-lg border border-zinc-800">
                      <span className="text-zinc-300 font-medium">Command Palette (Quick Actions)</span>
                      <div className="flex items-center gap-1 font-mono">
                        <kbd className="px-2 py-1 bg-zinc-800 text-zinc-200 border border-zinc-700 rounded text-xs font-bold">Ctrl</kbd>
                        <span>+</span>
                        <kbd className="px-2 py-1 bg-zinc-800 text-zinc-200 border border-zinc-700 rounded text-xs font-bold">Shift</kbd>
                        <span>+</span>
                        <kbd className="px-2 py-1 bg-zinc-800 text-zinc-200 border border-zinc-700 rounded text-xs font-bold">P</kbd>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Additional VS Code Standard Shortcuts */}
                <div>
                  <h4 className="font-bold text-[11px] uppercase tracking-wider text-zinc-400 mb-2.5">
                    Editing & Navigation
                  </h4>
                  <div className="space-y-2 text-zinc-300">
                    <div className="flex items-center justify-between p-2 bg-zinc-950/60 rounded-lg border border-zinc-800/80">
                      <span>Toggle Block Comment</span>
                      <div className="flex items-center gap-1 font-mono text-[11px]">
                        <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700">Shift</kbd>+
                        <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700">Alt</kbd>+
                        <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700">A</kbd>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-2 bg-zinc-950/60 rounded-lg border border-zinc-800/80">
                      <span>Find in Code</span>
                      <div className="flex items-center gap-1 font-mono text-[11px]">
                        <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700">Ctrl</kbd>+
                        <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700">F</kbd>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-2 bg-zinc-950/60 rounded-lg border border-zinc-800/80">
                      <span>Find and Replace</span>
                      <div className="flex items-center gap-1 font-mono text-[11px]">
                        <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700">Ctrl</kbd>+
                        <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700">H</kbd>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-2 bg-zinc-950/60 rounded-lg border border-zinc-800/80">
                      <span>Add Multi-Cursor to Next Match</span>
                      <div className="flex items-center gap-1 font-mono text-[11px]">
                        <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700">Ctrl</kbd>+
                        <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700">D</kbd>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-2 bg-zinc-950/60 rounded-lg border border-zinc-800/80">
                      <span>Move Line Up / Down</span>
                      <div className="flex items-center gap-1 font-mono text-[11px]">
                        <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700">Alt</kbd>+
                        <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700">↑ / ↓</kbd>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-2 bg-zinc-950/60 rounded-lg border border-zinc-800/80">
                      <span>Trigger Autocomplete / Intellisense</span>
                      <div className="flex items-center gap-1 font-mono text-[11px]">
                        <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700">Ctrl</kbd>+
                        <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700">Space</kbd>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="px-6 py-3 bg-zinc-950 border-t border-zinc-800 flex justify-end">
                <button
                  onClick={() => setShowShortcutsModal(false)}
                  className="px-4 py-1.5 bg-red-700 hover:bg-red-600 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer"
                >
                  Got It
                </button>
              </div>
            </div>
          </div>
        )}
        {/* Official Lab Manual Print & Export Modal */}
        <PrintLabManualModal
          isOpen={showPrintModal}
          onClose={() => setShowPrintModal(false)}
          experiment={experiment}
          userSession={userSession}
          subjectName={experiment.category || 'Virtual Laboratory'}
        />
      </div>
    </div>
  );
};
