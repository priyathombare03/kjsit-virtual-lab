import React, { useState } from 'react';
import {
  Cpu,
  Database,
  Terminal,
  Network,
  Sparkles,
  ShieldCheck,
  Globe,
  Layers,
  ArrowRight,
  Lock,
  Search,
  BookOpen,
  BrainCircuit,
  Filter,
  X,
  Code2,
  FileText,
  BarChart2,
  GraduationCap
} from 'lucide-react';
import { LAB_SUBJECTS } from '../data/subjects';
import { LabSubject } from '../types';

interface VirtualLabsGridProps {
  onSelectSubject: (subjectId: string) => void;
}

export const VirtualLabsGrid: React.FC<VirtualLabsGridProps> = ({ onSelectSubject }) => {
  const [filter, setFilter] = useState<'all' | 'functional' | 'aids'>('all');
  const [selectedSemester, setSelectedSemester] = useState<string>('all');
  const [search, setSearch] = useState('');

  const getSubjectIcon = (iconName: string) => {
    switch (iconName) {
      case 'Cpu': return <Cpu className="w-6 h-6" />;
      case 'Database': return <Database className="w-6 h-6" />;
      case 'Terminal': return <Terminal className="w-6 h-6" />;
      case 'Network': return <Network className="w-6 h-6" />;
      case 'Sparkles': return <Sparkles className="w-6 h-6" />;
      case 'ShieldCheck': return <ShieldCheck className="w-6 h-6" />;
      case 'Globe': return <Globe className="w-6 h-6" />;
      case 'Layers': return <Layers className="w-6 h-6" />;
      case 'BrainCircuit': return <BrainCircuit className="w-6 h-6" />;
      case 'Code2': return <Code2 className="w-6 h-6" />;
      case 'FileText': return <FileText className="w-6 h-6" />;
      case 'BarChart2': return <BarChart2 className="w-6 h-6" />;
      default: return <BookOpen className="w-6 h-6" />;
    }
  };

  const filteredSubjects = LAB_SUBJECTS.filter((s) => {
    if (filter === 'functional' && !s.isFunctional) return false;
    if (filter === 'aids' && !s.department.includes('Artificial Intelligence')) return false;

    if (selectedSemester !== 'all') {
      const semRegexMap: Record<string, RegExp> = {
        sem1: /\bSemester I\b/i,
        sem2: /\bSemester II\b/i,
        sem3: /\bSemester III\b/i,
        sem4: /\bSemester IV\b/i,
        sem5: /\bSemester V\b/i,
        sem6: /\bSemester VI\b/i,
        sem7: /\bSemester VII\b/i,
        sem8: /\bSemester VIII\b/i,
      };
      const regex = semRegexMap[selectedSemester];
      if (regex && !regex.test(s.semester)) return false;
    }

    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        s.name.toLowerCase().includes(q) ||
        s.code.toLowerCase().includes(q) ||
        s.description.toLowerCase().includes(q) ||
        s.tags.some(t => t.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const activeLabsCount = LAB_SUBJECTS.filter(s => s.isFunctional).length;

  const semesters = [
    { id: 'all', label: 'All Semesters' },
    { id: 'sem3', label: 'Sem III' },
    { id: 'sem4', label: 'Sem IV' },
    { id: 'sem5', label: 'Sem V' },
    { id: 'sem6', label: 'Sem VI' },
    { id: 'sem7', label: 'Sem VII' },
    { id: 'sem8', label: 'Sem VIII' }
  ];

  const displayedSubjects = filteredSubjects;

  return (
    <section className="py-16 bg-white border-t border-zinc-200" id="virtual-labs-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8 pb-6 border-b border-zinc-200">
          <div>
            <h2 className="text-2xl sm:text-3xl font-black text-black tracking-tight">
              Virtual Laboratory Workstations
            </h2>
            <p className="text-sm text-zinc-600 mt-1">
              Select a discipline below to access interactive algorithm simulators and laboratory experiments.
            </p>
          </div>

          {/* Filter Status Badge */}
          <div className="flex items-center gap-2 text-xs font-bold text-zinc-500">
            <Filter className="w-3.5 h-3.5 text-red-700" />
            <span>Showing {filteredSubjects.length} labs</span>
          </div>
        </div>

        {/* Top Controls: Search Bar & Filter Buttons */}
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4 mb-8 bg-zinc-50 p-4 rounded-2xl border border-zinc-200">
          {/* Search Button & Input */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by subject name, code (e.g. CSC501), or topic..."
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
              }}
              className="w-full pl-10 pr-10 py-2 text-xs bg-white border border-zinc-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-600 shadow-2xs"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-black cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Filter Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-bold text-zinc-400 flex items-center gap-1 mr-1">
              <Filter className="w-3 h-3" /> Filters:
            </span>
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                filter === 'all'
                  ? 'bg-black text-white shadow-2xs'
                  : 'bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-100'
              }`}
            >
              All Labs ({LAB_SUBJECTS.length})
            </button>
            <button
              onClick={() => setFilter('functional')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer ${
                filter === 'functional'
                  ? 'bg-red-700 text-white shadow-2xs'
                  : 'bg-white border border-red-200 text-red-700 hover:bg-red-50'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-red-500"></span>
              Active Labs ({activeLabsCount})
            </button>
            <button
              onClick={() => setFilter('aids')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                filter === 'aids'
                  ? 'bg-black text-white shadow-2xs'
                  : 'bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-100'
              }`}
            >
              Dept of AI & DS
            </button>
          </div>
        </div>

        {/* Semester Quick Filter Bar */}
        <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-2 scrollbar-none">
          <span className="text-xs font-bold text-zinc-500 flex items-center gap-1.5 whitespace-nowrap mr-1">
            <GraduationCap className="w-3.5 h-3.5 text-red-600" /> By Semester:
          </span>
          {semesters.map((sem) => (
            <button
              key={sem.id}
              onClick={() => setSelectedSemester(sem.id)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                selectedSemester === sem.id
                  ? 'bg-red-700 text-white shadow-xs ring-2 ring-red-700/20'
                  : 'bg-white text-zinc-700 hover:bg-zinc-100 border border-zinc-200'
              }`}
            >
              {sem.label}
            </button>
          ))}
        </div>

        {/* Subjects Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {displayedSubjects.map((subject) => {
            const isFunctional = subject.isFunctional;

            return (
              <div
                key={subject.id}
                className={`group rounded-3xl flex flex-col justify-between overflow-hidden relative transition-all duration-500 ${
                  isFunctional
                    ? 'bg-red-900/90 backdrop-blur-md border border-red-500/30 shadow-[0_8px_32px_rgba(185,28,28,0.4)] hover:bg-white/10 hover:backdrop-blur-xl hover:border-zinc-200 hover:shadow-[0_8px_32px_rgba(0,0,0,0.05)] hover:-translate-y-1'
                    : 'bg-white border border-zinc-200 opacity-75 grayscale-[0.4] hover:opacity-90 hover:grayscale-0'
                }`}
              >
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    {/* Header line: Icon + Badge */}
                    <div className="flex items-center justify-between gap-3 mb-3">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
                          isFunctional
                            ? 'bg-red-950/50 text-red-100 border border-red-800/50 group-hover:bg-red-50 group-hover:text-red-700 group-hover:border-red-100'
                            : 'bg-zinc-100 text-zinc-400'
                        }`}
                      >
                        {getSubjectIcon(subject.iconName)}
                      </div>

                      {isFunctional ? (
                        <div className="flex items-center gap-1.5">
                          <span className="px-2 py-0.5 bg-white/20 text-white rounded-full text-[10px] font-extrabold uppercase tracking-wider border border-white/20 shadow-sm transition-colors group-hover:bg-red-100 group-hover:text-red-800 group-hover:border-red-200">
                            ACTIVE ({subject.experimentCount})
                          </span>
                        </div>
                      ) : (
                        <span className="px-2 py-0.5 bg-zinc-100 text-zinc-500 rounded-full text-[10px] font-medium uppercase tracking-wider flex items-center gap-1">
                          <Lock className="w-2.5 h-2.5" />
                          Coming Soon
                        </span>
                      )}
                    </div>

                    {/* Subject Name & Code */}
                    <div className="mb-1.5">
                      <span className="text-[10px] font-mono font-bold text-red-200/80 uppercase tracking-wider transition-colors group-hover:text-red-700">
                        {subject.code} • {subject.semester}
                      </span>
                      <h3 className="text-base font-bold text-white leading-snug mt-0.5 transition-colors group-hover:text-zinc-900">
                        {subject.name}
                      </h3>
                    </div>

                    {/* Description */}
                    <p className="text-[11px] text-red-100/90 line-clamp-2 leading-relaxed mb-4 transition-colors group-hover:text-zinc-600">
                      {subject.description}
                    </p>
                  </div>

                  <div>
                    {/* Action Button */}
                    {isFunctional ? (
                      <button
                        onClick={() => onSelectSubject(subject.id)}
                        className="w-full py-2.5 bg-white/10 text-white text-xs font-bold rounded-xl shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer group-hover:bg-red-900/90 group-hover:backdrop-blur-md group-hover:border-red-500/30 group-hover:text-white group-hover:shadow-[0_4px_16px_rgba(185,28,28,0.4)] border border-white/10 hover:!bg-white/80 hover:!backdrop-blur-xl hover:!text-red-700 hover:!border-red-300 hover:!shadow-[0_8px_24px_rgba(185,28,28,0.3)]"
                      >
                        <span>ENTER LAB</span>
                        <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                      </button>
                    ) : (
                      <button
                        disabled
                        className="w-full py-2 bg-zinc-200 text-zinc-500 text-xs font-bold rounded-lg cursor-not-allowed"
                      >
                        COMING SOON
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Empty state if search has no match */}
        {filteredSubjects.length === 0 && (
          <div className="text-center py-12 bg-zinc-50 rounded-2xl border border-dashed border-zinc-300">
            <Search className="w-8 h-8 text-zinc-400 mx-auto mb-2" />
            <p className="text-sm font-bold text-zinc-700">No laboratory subjects match your search.</p>
            <p className="text-xs text-zinc-500 mt-1">Try a different keyword or reset filters.</p>
            <button
              onClick={() => {
                setSearch('');
                setFilter('all');
              }}
              className="mt-3 px-4 py-1.5 bg-red-700 text-white text-xs font-bold rounded-lg hover:bg-red-800 transition-colors cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

