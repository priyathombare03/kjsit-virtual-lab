import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Search,
  Filter,
  Flame,
  Clock,
  CheckCircle2,
  GraduationCap,
  Download,
  Calendar,
  Building,
  ArrowUpDown,
  BookOpen,
  Award,
  ChevronDown,
  ChevronUp,
  Users,
  BarChart3,
  RefreshCw,
  Sparkles,
  School,
  FileSpreadsheet,
  Layers,
  PieChart,
  ShieldCheck,
  SlidersHorizontal,
  Check,
  X
} from 'lucide-react';
import { UserSession } from '../types';
import { SomaiyaEmblem } from './SomaiyaLogo';

interface StudentOverviewItem {
  id: string;
  name: string;
  email: string;
  studentId: string;
  department: string;
  year?: 'FY' | 'SY' | 'TY' | 'LY' | string;
  role: string;
  totalActiveSeconds: number;
  currentStreak: number;
  longestStreak: number;
  lastCompletionDate: string | null;
  completionDates?: string[];
  completedCount?: number;
  completedExperiments: {
    experimentId: string;
    subjectId: string;
    title: string;
    activeSeconds: number;
    completedAt: string;
    score?: number;
  }[];
  createdAt: string;
}

interface HodOverviewPageProps {
  onBackToLabs?: () => void;
  userSession: UserSession | null;
}

export const HodOverviewPage: React.FC<HodOverviewPageProps> = ({
  onBackToLabs,
  userSession
}) => {
  const [students, setStudents] = useState<StudentOverviewItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'students' | 'cohort-analytics' | 'experiments-matrix'>('students');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedYear, setSelectedYear] = useState<'ALL' | 'FY' | 'SY' | 'TY' | 'LY'>('ALL');
  const [selectedTimeRange, setSelectedTimeRange] = useState<'ALL' | '<1h' | '1-3h' | '3-5h' | '>5h'>('ALL');
  const [sortBy, setSortBy] = useState<'time-desc' | 'time-asc' | 'exps-desc' | 'streak-desc' | 'name-asc' | 'year-asc'>('time-desc');
  const [expandedStudentId, setExpandedStudentId] = useState<string | null>(null);

  // Personalized CSV Export States
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [showCustomExportModal, setShowCustomExportModal] = useState(false);
  const exportMenuRef = useRef<HTMLDivElement>(null);

  const [customExportYears, setCustomExportYears] = useState<{ FY: boolean; SY: boolean; TY: boolean; LY: boolean }>({
    FY: true,
    SY: true,
    TY: true,
    LY: true
  });
  const [customExportActivity, setCustomExportActivity] = useState<'ALL' | 'ACTIVE' | 'HIGH' | 'INACTIVE'>('ALL');
  const [customExportTimeRange, setCustomExportTimeRange] = useState<'ALL' | '<1h' | '1-3h' | '>3h'>('ALL');
  const [customExportSearch, setCustomExportSearch] = useState('');
  const [customExportColumns, setCustomExportColumns] = useState({
    rollNo: true,
    name: true,
    email: true,
    year: true,
    department: true,
    completedCount: true,
    activeMinutes: true,
    formattedDuration: true,
    streaks: true,
    lastActiveDate: true,
    experimentTitles: true
  });

  // Close dropdown on outside click or Escape key
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (exportMenuRef.current && !exportMenuRef.current.contains(e.target as Node)) {
        setShowExportMenu(false);
      }
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setShowExportMenu(false);
        setShowCustomExportModal(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  // Fetch live student overview records
  const fetchOverviewData = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/hod/students');
      if (res.ok) {
        const data = await res.json();
        setStudents(data.students || []);
      }
    } catch (err) {
      console.error('Failed to load HOD student overview data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchOverviewData();
  }, []);

  // Format seconds into human readable duration
  const formatDuration = (totalSeconds: number): string => {
    if (!totalSeconds || totalSeconds <= 0) return '0 mins';
    const hours = Math.floor(totalSeconds / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    if (hours === 0) return `${mins}m`;
    if (mins === 0) return `${hours}h`;
    return `${hours}h ${mins}m`;
  };

  // Filtered and sorted students list
  const filteredStudents = useMemo(() => {
    return students
      .filter((s) => {
        // 1. Academic Year Filter
        if (selectedYear !== 'ALL') {
          const sYear = (s.year || '').toUpperCase();
          if (sYear !== selectedYear) return false;
        }

        // 2. Time Spent Filter
        const secs = s.totalActiveSeconds || 0;
        if (selectedTimeRange === '<1h' && secs >= 3600) return false;
        if (selectedTimeRange === '1-3h' && (secs < 3600 || secs > 10800)) return false;
        if (selectedTimeRange === '3-5h' && (secs <= 10800 || secs > 18000)) return false;
        if (selectedTimeRange === '>5h' && secs <= 18000) return false;

        // 3. Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchName = s.name.toLowerCase().includes(q);
          const matchId = (s.studentId || '').toLowerCase().includes(q);
          const matchEmail = s.email.toLowerCase().includes(q);
          const matchDept = (s.department || '').toLowerCase().includes(q);
          if (!matchName && !matchId && !matchEmail && !matchDept) return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'time-desc') {
          return (b.totalActiveSeconds || 0) - (a.totalActiveSeconds || 0);
        }
        if (sortBy === 'time-asc') {
          return (a.totalActiveSeconds || 0) - (b.totalActiveSeconds || 0);
        }
        if (sortBy === 'exps-desc') {
          const aCount = a.completedExperiments?.length || 0;
          const bCount = b.completedExperiments?.length || 0;
          return bCount - aCount;
        }
        if (sortBy === 'streak-desc') {
          return (b.currentStreak || 0) - (a.currentStreak || 0);
        }
        if (sortBy === 'name-asc') {
          return a.name.localeCompare(b.name);
        }
        if (sortBy === 'year-asc') {
          const order: Record<string, number> = { FY: 1, SY: 2, TY: 3, LY: 4 };
          const aY = order[(a.year || '').toUpperCase()] || 99;
          const bY = order[(b.year || '').toUpperCase()] || 99;
          return aY - bY;
        }
        return 0;
      });
  }, [students, selectedYear, selectedTimeRange, searchQuery, sortBy]);

  // Aggregate statistics across filtered students
  const aggregateStats = useMemo(() => {
    const count = filteredStudents.length;
    const totalSecs = filteredStudents.reduce((acc, s) => acc + (s.totalActiveSeconds || 0), 0);
    const totalCompleted = filteredStudents.reduce(
      (acc, s) => acc + (s.completedExperiments ? s.completedExperiments.length : 0),
      0
    );
    const activeStreaks = filteredStudents.filter((s) => (s.currentStreak || 0) > 0).length;
    const avgMins = count > 0 ? Math.round(totalSecs / 60 / count) : 0;

    return {
      count,
      totalSecs,
      totalCompleted,
      activeStreaks,
      avgMins
    };
  }, [filteredStudents]);

  // Cohort statistics by Year
  const yearCohorts = useMemo(() => {
    const cohorts = ['FY', 'SY', 'TY', 'LY'] as const;
    return cohorts.map((yr) => {
      const cohortStudents = students.filter((s) => (s.year || '').toUpperCase() === yr);
      const totalExps = cohortStudents.reduce((acc, s) => acc + (s.completedExperiments?.length || 0), 0);
      const totalSecs = cohortStudents.reduce((acc, s) => acc + (s.totalActiveSeconds || 0), 0);
      const avgSecs = cohortStudents.length > 0 ? Math.round(totalSecs / cohortStudents.length) : 0;
      return {
        year: yr,
        count: cohortStudents.length,
        totalExps,
        avgDuration: formatDuration(avgSecs),
        activeStreaks: cohortStudents.filter((s) => (s.currentStreak || 0) > 0).length
      };
    });
  }, [students]);

  // Experiment popularity breakdown
  const experimentRankings = useMemo(() => {
    const counts: Record<string, { title: string; subject: string; count: number }> = {};
    students.forEach((s) => {
      (s.completedExperiments || []).forEach((e) => {
        if (!counts[e.experimentId]) {
          counts[e.experimentId] = {
            title: e.title,
            subject: e.subjectId.toUpperCase(),
            count: 0
          };
        }
        counts[e.experimentId].count += 1;
      });
    });
    return Object.entries(counts)
      .map(([id, data]) => ({ id, ...data }))
      .sort((a, b) => b.count - a.count);
  }, [students]);

  // Academic Year Counts
  const yearCounts = useMemo(() => {
    const counts = { FY: 0, SY: 0, TY: 0, LY: 0, ALL: students.length };
    students.forEach((s) => {
      const y = (s.year || '').toUpperCase();
      if (y === 'FY') counts.FY += 1;
      else if (y === 'SY') counts.SY += 1;
      else if (y === 'TY') counts.TY += 1;
      else if (y === 'LY') counts.LY += 1;
    });
    return counts;
  }, [students]);

  // Filtered Students for the Custom Export Modal
  const customModalFilteredStudents = useMemo(() => {
    return students.filter((s) => {
      const y = (s.year || '').toUpperCase();
      const yearMatches =
        (y === 'FY' && customExportYears.FY) ||
        (y === 'SY' && customExportYears.SY) ||
        (y === 'TY' && customExportYears.TY) ||
        (y === 'LY' && customExportYears.LY) ||
        (!['FY', 'SY', 'TY', 'LY'].includes(y) &&
          (customExportYears.FY || customExportYears.SY || customExportYears.TY || customExportYears.LY));
      if (!yearMatches) return false;

      const completedCount = s.completedExperiments?.length || 0;
      if (customExportActivity === 'ACTIVE' && completedCount < 1) return false;
      if (customExportActivity === 'HIGH' && completedCount < 3) return false;
      if (customExportActivity === 'INACTIVE' && completedCount > 0) return false;

      const secs = s.totalActiveSeconds || 0;
      if (customExportTimeRange === '<1h' && secs >= 3600) return false;
      if (customExportTimeRange === '1-3h' && (secs < 3600 || secs > 10800)) return false;
      if (customExportTimeRange === '>3h' && secs <= 10800) return false;

      if (customExportSearch.trim()) {
        const q = customExportSearch.toLowerCase();
        const matchesName = s.name.toLowerCase().includes(q);
        const matchesRoll = (s.studentId || '').toLowerCase().includes(q);
        const matchesEmail = s.email.toLowerCase().includes(q);
        if (!matchesName && !matchesRoll && !matchesEmail) return false;
      }

      return true;
    });
  }, [students, customExportYears, customExportActivity, customExportTimeRange, customExportSearch]);

  // Universal CSV Exporter with Column and Personalization Control
  const exportStudentsToCSV = (
    listToExport: StudentOverviewItem[],
    reportLabel: string,
    cols = customExportColumns
  ) => {
    if (!listToExport || listToExport.length === 0) {
      alert(`No student records available for ${reportLabel}.`);
      return;
    }

    const headers: string[] = [];
    if (cols.rollNo) headers.push('Roll / SVVNet ID');
    if (cols.name) headers.push('Student Name');
    if (cols.email) headers.push('Somaiya Email');
    if (cols.year) headers.push('Academic Year');
    if (cols.department) headers.push('Department');
    if (cols.completedCount) headers.push('Experiments Completed Count');
    if (cols.activeMinutes) headers.push('Total Active Minutes');
    if (cols.formattedDuration) headers.push('Total Active Formatted');
    if (cols.streaks) headers.push('Current Streak (Days)', 'Longest Streak (Days)');
    if (cols.lastActiveDate) headers.push('Last Completion Date');
    if (cols.experimentTitles) headers.push('Completed Experiment Titles');

    const rows = listToExport.map((s) => {
      const row: (string | number)[] = [];
      if (cols.rollNo) row.push(`"${s.studentId || ''}"`);
      if (cols.name) row.push(`"${s.name.replace(/"/g, '""')}"`);
      if (cols.email) row.push(`"${s.email}"`);
      if (cols.year) row.push(`"${s.year || ''}"`);
      if (cols.department) row.push(`"${s.department || ''}"`);
      if (cols.completedCount) row.push(s.completedExperiments?.length || 0);
      if (cols.activeMinutes) row.push(Math.round((s.totalActiveSeconds || 0) / 60));
      if (cols.formattedDuration) row.push(`"${formatDuration(s.totalActiveSeconds || 0)}"`);
      if (cols.streaks) {
        row.push(s.currentStreak || 0);
        row.push(s.longestStreak || 0);
      }
      if (cols.lastActiveDate) row.push(`"${s.lastCompletionDate || 'None'}"`);
      if (cols.experimentTitles) {
        row.push(`"${(s.completedExperiments || []).map((e) => e.title.replace(/"/g, '""')).join('; ')}"`);
      }
      return row;
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    const sanitizedLabel = reportLabel.replace(/[^a-zA-Z0-9_-]/g, '_');
    link.setAttribute('download', `KJSIT_HOD_Report_${sanitizedLabel}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportByYear = (year: 'ALL' | 'FY' | 'SY' | 'TY' | 'LY') => {
    if (year === 'ALL') {
      exportStudentsToCSV(students, 'All_Cohorts_FY_SY_TY_LY');
    } else {
      const filtered = students.filter((s) => (s.year || '').toUpperCase() === year);
      exportStudentsToCSV(filtered, `${year}_Cohort`);
    }
  };

  const handleExportCurrentView = () => {
    exportStudentsToCSV(filteredStudents, `Current_Filtered_View_${selectedYear}`);
  };

  const getYearBadgeStyle = (year?: string) => {
    switch ((year || '').toUpperCase()) {
      case 'FY':
        return 'bg-sky-100 text-sky-800 border-sky-300';
      case 'SY':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'TY':
        return 'bg-purple-100 text-purple-800 border-purple-300';
      case 'LY':
        return 'bg-amber-100 text-amber-900 border-amber-300';
      default:
        return 'bg-zinc-100 text-zinc-800 border-zinc-300';
    }
  };

  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-900 pb-16">
      {/* Top Banner / Breadcrumbs */}
      <div className="bg-linear-to-r from-red-950 via-red-900 to-amber-950 text-white border-b border-red-800/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
          {/* Breadcrumb row */}
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <div className="flex items-center gap-2 text-xs text-red-200/80 flex-wrap font-medium">
              <span>Somaiya Vidyavihar</span>
              <span>/</span>
              <span>KJSIT Autonomous</span>
              <span>/</span>
              <span>Dept. of Artificial Intelligence & Data Science</span>
              <span>/</span>
              <span className="text-amber-300 font-bold">HOD Academic Dashboard</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={fetchOverviewData}
                disabled={isLoading}
                className="px-3 py-1.5 rounded-lg bg-red-900/70 hover:bg-red-800 text-white text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 border border-red-700/60 shadow-xs"
                title="Refresh Live Student Records"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                <span>Sync Live Logs</span>
              </button>
            </div>
          </div>

          {/* Heading with Somaiya Emblem */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-start sm:items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-white p-2 shadow-lg flex items-center justify-center shrink-0 border border-red-100">
                <SomaiyaEmblem className="w-full h-full" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
                  Department Student Lab Overview & Progress
                </h1>
                <p className="text-sm text-red-100/90 font-medium mt-0.5">
                  {userSession?.name || 'Dr. Milind Nemade (HOD AI & DS)'} • {userSession?.department || 'Department of Artificial Intelligence and Data Science'}
                </p>
              </div>
            </div>

            {/* Personalized Export CTA with Academic Year & Filter Options */}
            <div className="relative self-start md:self-auto" ref={exportMenuRef}>
              <button
                id="export-official-csv-btn"
                onClick={() => setShowExportMenu((prev) => !prev)}
                className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-zinc-950 font-black text-xs rounded-xl shadow-md transition-all active:scale-95 cursor-pointer flex items-center gap-2 select-none"
                title="Download personalized CSV reports by Year (FY, SY, TY, LY), Current View, or Custom Filters"
              >
                <Download className="w-4 h-4 text-zinc-950" />
                <span>Export Official CSV Report</span>
                {selectedYear !== 'ALL' && (
                  <span className="px-1.5 py-0.5 rounded bg-zinc-950/15 text-zinc-950 text-[10px] font-black uppercase">
                    {selectedYear}
                  </span>
                )}
                <ChevronDown
                  className={`w-3.5 h-3.5 text-zinc-950 transition-transform duration-200 ${
                    showExportMenu ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {/* Personalized Export Dropdown Menu */}
              {showExportMenu && (
                <div
                  id="export-csv-dropdown-menu"
                  className="absolute right-0 mt-2 w-80 sm:w-88 bg-white rounded-2xl border border-zinc-200 shadow-2xl z-50 p-3.5 text-zinc-900 animate-in fade-in slide-in-from-top-2 duration-150"
                >
                  <div className="flex items-center justify-between pb-2.5 border-b border-zinc-100">
                    <div>
                      <div className="text-xs font-black text-zinc-900">Personalized CSV Export</div>
                      <div className="text-[11px] text-zinc-500 font-medium">Download reports filtered by Academic Year</div>
                    </div>
                    <button
                      onClick={() => setShowExportMenu(false)}
                      className="text-zinc-400 hover:text-zinc-700 p-1 rounded-lg text-xs cursor-pointer"
                      title="Close menu"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {/* 1-Click Academic Year Options */}
                  <div className="py-2.5">
                    <div className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-2">
                      Download by Academic Year:
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {/* FY Button */}
                      <button
                        type="button"
                        onClick={() => {
                          handleExportByYear('FY');
                          setShowExportMenu(false);
                        }}
                        className="p-2.5 rounded-xl border border-sky-200 bg-sky-50/70 hover:bg-sky-100 transition-colors text-left flex items-center justify-between group cursor-pointer"
                        title={`Download First Year (FY) CSV report (${yearCounts.FY} students)`}
                      >
                        <div>
                          <div className="text-xs font-black text-sky-900 flex items-center gap-1">
                            <span className="w-2 h-2 rounded-full bg-sky-500"></span>
                            <span>FY Students</span>
                          </div>
                          <div className="text-[10px] text-sky-700 font-semibold">{yearCounts.FY} Records</div>
                        </div>
                        <Download className="w-3.5 h-3.5 text-sky-600 group-hover:translate-y-0.5 transition-transform" />
                      </button>

                      {/* SY Button */}
                      <button
                        type="button"
                        onClick={() => {
                          handleExportByYear('SY');
                          setShowExportMenu(false);
                        }}
                        className="p-2.5 rounded-xl border border-emerald-200 bg-emerald-50/70 hover:bg-emerald-100 transition-colors text-left flex items-center justify-between group cursor-pointer"
                        title={`Download Second Year (SY) CSV report (${yearCounts.SY} students)`}
                      >
                        <div>
                          <div className="text-xs font-black text-emerald-900 flex items-center gap-1">
                            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                            <span>SY Students</span>
                          </div>
                          <div className="text-[10px] text-emerald-700 font-semibold">{yearCounts.SY} Records</div>
                        </div>
                        <Download className="w-3.5 h-3.5 text-emerald-600 group-hover:translate-y-0.5 transition-transform" />
                      </button>

                      {/* TY Button */}
                      <button
                        type="button"
                        onClick={() => {
                          handleExportByYear('TY');
                          setShowExportMenu(false);
                        }}
                        className="p-2.5 rounded-xl border border-purple-200 bg-purple-50/70 hover:bg-purple-100 transition-colors text-left flex items-center justify-between group cursor-pointer"
                        title={`Download Third Year (TY) CSV report (${yearCounts.TY} students)`}
                      >
                        <div>
                          <div className="text-xs font-black text-purple-900 flex items-center gap-1">
                            <span className="w-2 h-2 rounded-full bg-purple-500"></span>
                            <span>TY Students</span>
                          </div>
                          <div className="text-[10px] text-purple-700 font-semibold">{yearCounts.TY} Records</div>
                        </div>
                        <Download className="w-3.5 h-3.5 text-purple-600 group-hover:translate-y-0.5 transition-transform" />
                      </button>

                      {/* LY Button */}
                      <button
                        type="button"
                        onClick={() => {
                          handleExportByYear('LY');
                          setShowExportMenu(false);
                        }}
                        className="p-2.5 rounded-xl border border-amber-200 bg-amber-50/70 hover:bg-amber-100 transition-colors text-left flex items-center justify-between group cursor-pointer"
                        title={`Download Final Year (LY) CSV report (${yearCounts.LY} students)`}
                      >
                        <div>
                          <div className="text-xs font-black text-amber-900 flex items-center gap-1">
                            <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                            <span>LY Students</span>
                          </div>
                          <div className="text-[10px] text-amber-800 font-semibold">{yearCounts.LY} Records</div>
                        </div>
                        <Download className="w-3.5 h-3.5 text-amber-700 group-hover:translate-y-0.5 transition-transform" />
                      </button>
                    </div>

                    {/* All Cohorts */}
                    <button
                      type="button"
                      onClick={() => {
                        handleExportByYear('ALL');
                        setShowExportMenu(false);
                      }}
                      className="w-full mt-2 p-2.5 rounded-xl border border-zinc-200 bg-zinc-50/80 hover:bg-zinc-100 transition-colors text-left flex items-center justify-between group cursor-pointer"
                      title="Download complete department CSV report with all students"
                    >
                      <div className="flex items-center gap-2">
                        <GraduationCap className="w-4 h-4 text-zinc-700" />
                        <div>
                          <div className="text-xs font-bold text-zinc-900">All Cohorts (FY + SY + TY + LY)</div>
                          <div className="text-[10px] text-zinc-500">{yearCounts.ALL} Total Enrolled Students</div>
                        </div>
                      </div>
                      <Download className="w-3.5 h-3.5 text-zinc-600 group-hover:translate-y-0.5 transition-transform" />
                    </button>
                  </div>

                  {/* Current Active Filter View */}
                  <div className="pt-2 border-t border-zinc-100">
                    <button
                      type="button"
                      onClick={() => {
                        handleExportCurrentView();
                        setShowExportMenu(false);
                      }}
                      className="w-full p-2.5 rounded-xl bg-red-50 hover:bg-red-100/80 border border-red-200 transition-colors text-left flex items-center justify-between group cursor-pointer"
                      title="Download students matching your current table filters and search"
                    >
                      <div>
                        <div className="text-xs font-black text-red-900 flex items-center gap-1.5">
                          <Filter className="w-3.5 h-3.5 text-red-700" />
                          <span>Current Filtered View ({filteredStudents.length} Students)</span>
                        </div>
                        <div className="text-[10px] text-red-700 font-medium mt-0.5 truncate">
                          Year: {selectedYear} • Time: {selectedTimeRange} {searchQuery ? `• "${searchQuery}"` : ''}
                        </div>
                      </div>
                      <Download className="w-3.5 h-3.5 text-red-700 group-hover:translate-y-0.5 transition-transform" />
                    </button>
                  </div>

                  {/* Advanced Custom Filters Button */}
                  <div className="pt-2 mt-2 border-t border-zinc-100">
                    <button
                      type="button"
                      onClick={() => {
                        setShowExportMenu(false);
                        setShowCustomExportModal(true);
                      }}
                      className="w-full py-2 px-3 rounded-xl text-xs font-bold text-zinc-700 hover:text-zinc-950 hover:bg-zinc-100 transition-colors flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <SlidersHorizontal className="w-3.5 h-3.5 text-zinc-600" />
                      <span>Custom Filters & Column Selection...</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        {/* KPI Metrics Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {/* Total Filtered Students */}
          <div className="p-4 bg-white rounded-2xl border border-zinc-200 shadow-xs flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-red-50 border border-red-100 flex items-center justify-center text-red-700 shrink-0 shadow-2xs">
              <Users className="w-6 h-6" />
            </div>
            <div className="min-w-0">
              <div className="text-xs font-bold text-zinc-500 uppercase tracking-wider truncate">Students Enrolled</div>
              <div className="text-2xl font-black text-zinc-900">
                {aggregateStats.count} <span className="text-xs font-normal text-zinc-400">/ {students.length}</span>
              </div>
            </div>
          </div>

          {/* Experiments Completed */}
          <div className="p-4 bg-white rounded-2xl border border-zinc-200 shadow-xs flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-700 shrink-0 shadow-2xs">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div className="min-w-0">
              <div className="text-xs font-bold text-zinc-500 uppercase tracking-wider truncate">Practical Exps Done</div>
              <div className="text-2xl font-black text-emerald-800">
                {aggregateStats.totalCompleted}
              </div>
            </div>
          </div>

          {/* Average Lab Duration */}
          <div className="p-4 bg-white rounded-2xl border border-zinc-200 shadow-xs flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-700 shrink-0 shadow-2xs">
              <Clock className="w-6 h-6" />
            </div>
            <div className="min-w-0">
              <div className="text-xs font-bold text-zinc-500 uppercase tracking-wider truncate">Avg Time / Student</div>
              <div className="text-2xl font-black text-zinc-900">
                {formatDuration(aggregateStats.avgMins * 60)}
              </div>
            </div>
          </div>

          {/* Daily Continuous Streaks */}
          <div className="p-4 bg-white rounded-2xl border border-zinc-200 shadow-xs flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600 shrink-0 shadow-2xs">
              <Flame className="w-6 h-6 fill-amber-500" />
            </div>
            <div className="min-w-0">
              <div className="text-xs font-bold text-zinc-500 uppercase tracking-wider truncate">Active Daily Streaks</div>
              <div className="text-2xl font-black text-amber-800">
                {aggregateStats.activeStreaks} <span className="text-xs font-normal text-zinc-400">students</span>
              </div>
            </div>
          </div>
        </div>

        {/* Dedicated Page Tabs: [Students Roster, Cohort Analytics, Experiment Matrix] */}
        <div className="bg-white rounded-2xl border border-zinc-200 shadow-xs mb-6 overflow-hidden">
          <div className="flex border-b border-zinc-200 px-4 sm:px-6 pt-3 gap-3 overflow-x-auto bg-zinc-50/70">
            <button
              onClick={() => setActiveTab('students')}
              className={`pb-3 px-3 text-sm font-bold border-b-2 transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap ${
                activeTab === 'students'
                  ? 'border-red-700 text-red-700'
                  : 'border-transparent text-zinc-500 hover:text-zinc-800 hover:border-zinc-300'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Student Roster & Transcripts</span>
              <span className="px-2 py-0.5 rounded-full text-xs font-black bg-red-100 text-red-800">
                {filteredStudents.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('cohort-analytics')}
              className={`pb-3 px-3 text-sm font-bold border-b-2 transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap ${
                activeTab === 'cohort-analytics'
                  ? 'border-red-700 text-red-700'
                  : 'border-transparent text-zinc-500 hover:text-zinc-800 hover:border-zinc-300'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              <span>Cohort Analytics (FY, SY, TY, LY)</span>
            </button>

            <button
              onClick={() => setActiveTab('experiments-matrix')}
              className={`pb-3 px-3 text-sm font-bold border-b-2 transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap ${
                activeTab === 'experiments-matrix'
                  ? 'border-red-700 text-red-700'
                  : 'border-transparent text-zinc-500 hover:text-zinc-800 hover:border-zinc-300'
              }`}
            >
              <Award className="w-4 h-4" />
              <span>Experiment Completion Matrix</span>
              <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-zinc-200 text-zinc-700">
                {experimentRankings.length}
              </span>
            </button>
          </div>

          {/* TAB 1: Student Roster with Filters */}
          {activeTab === 'students' && (
            <div className="p-4 sm:p-6 space-y-5">
              {/* Filter and Control Bar */}
              <div className="space-y-4">
                {/* Search & Sort Row */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                  <div className="relative flex-1 max-w-lg">
                    <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search student name, Roll No (160101...), email, department..."
                      className="w-full pl-10 pr-9 py-2.5 text-sm border border-zinc-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-700 font-medium bg-white"
                    />
                    {searchQuery && (
                      <button
                        onClick={() => setSearchQuery('')}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-700 cursor-pointer text-xs"
                      >
                        ✕
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-auto">
                    <div className="flex items-center gap-1.5 text-xs text-zinc-600 bg-zinc-50 px-3 py-1.5 rounded-xl border border-zinc-200">
                      <ArrowUpDown className="w-3.5 h-3.5 text-zinc-500" />
                      <span className="font-semibold">Sort by:</span>
                      <select
                        value={sortBy}
                        onChange={(e: any) => setSortBy(e.target.value)}
                        className="bg-transparent font-bold text-zinc-800 focus:outline-none cursor-pointer"
                      >
                        <option value="time-desc">Time Spent: Highest first</option>
                        <option value="time-asc">Time Spent: Lowest first</option>
                        <option value="exps-desc">Experiments: Most completed</option>
                        <option value="streak-desc">Streak: Highest continuous</option>
                        <option value="name-asc">Student Name: A to Z</option>
                        <option value="year-asc">Year: FY to LY</option>
                      </select>
                    </div>

                    {(selectedYear !== 'ALL' || selectedTimeRange !== 'ALL' || searchQuery) && (
                      <button
                        onClick={() => {
                          setSelectedYear('ALL');
                          setSelectedTimeRange('ALL');
                          setSearchQuery('');
                        }}
                        className="px-3 py-2 text-xs font-bold text-red-700 hover:bg-red-50 rounded-xl transition-colors cursor-pointer"
                      >
                        Reset Filters
                      </button>
                    )}
                  </div>
                </div>

                {/* Dual Filter Selector Bars */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 pt-3 border-t border-zinc-100">
                  {/* Filter by Academic Year */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-[11px] font-bold text-zinc-600 flex items-center gap-1.5 uppercase tracking-wider">
                        <Filter className="w-3.5 h-3.5 text-red-700" />
                        <span>Filter by Academic Year (FY, SY, TY, LY):</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => handleExportByYear(selectedYear)}
                        className="text-[11px] font-bold text-red-700 hover:text-red-900 flex items-center gap-1 hover:underline cursor-pointer"
                        title={`Download CSV report for ${selectedYear === 'ALL' ? 'all cohorts' : selectedYear}`}
                      >
                        <Download className="w-3 h-3" />
                        <span>Download {selectedYear === 'ALL' ? 'All' : selectedYear} CSV</span>
                      </button>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      {(['ALL', 'FY', 'SY', 'TY', 'LY'] as const).map((year) => {
                        const count =
                          year === 'ALL'
                            ? students.length
                            : students.filter((s) => (s.year || '').toUpperCase() === year).length;
                        const isSelected = selectedYear === year;
                        return (
                          <button
                            key={year}
                            onClick={() => setSelectedYear(year)}
                            className={`px-3.5 py-1.5 text-xs font-bold rounded-xl border transition-all cursor-pointer flex items-center gap-2 ${
                              isSelected
                                ? 'bg-red-700 text-white border-red-700 shadow-sm'
                                : 'bg-white text-zinc-700 border-zinc-200 hover:bg-zinc-50'
                            }`}
                          >
                            <span>{year === 'ALL' ? 'All Cohorts' : `${year} Students`}</span>
                            <span
                              className={`text-[10px] px-1.5 py-0.2 rounded-full font-black ${
                                isSelected ? 'bg-white/20 text-white' : 'bg-zinc-100 text-zinc-700'
                              }`}
                            >
                              {count}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Filter by Time Spent in Labs */}
                  <div>
                    <label className="text-[11px] font-bold text-zinc-600 mb-2 flex items-center gap-1.5 uppercase tracking-wider">
                      <Clock className="w-3.5 h-3.5 text-red-700" />
                      <span>Filter by Time Spent in Practical Labs:</span>
                    </label>
                    <div className="flex flex-wrap items-center gap-2">
                      {[
                        { id: 'ALL', label: 'All Durations' },
                        { id: '<1h', label: '< 1 Hour' },
                        { id: '1-3h', label: '1 – 3 Hours' },
                        { id: '3-5h', label: '3 – 5 Hours' },
                        { id: '>5h', label: '> 5 Hours' }
                      ].map((item) => {
                        const isSelected = selectedTimeRange === item.id;
                        return (
                          <button
                            key={item.id}
                            onClick={() => setSelectedTimeRange(item.id as any)}
                            className={`px-3 py-1.5 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-zinc-900 text-white border-zinc-900 shadow-sm'
                                : 'bg-white text-zinc-700 border-zinc-200 hover:bg-zinc-50'
                            }`}
                          >
                            {item.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>

              {/* Student Cards List */}
              {filteredStudents.length === 0 ? (
                <div className="text-center py-16 px-4 bg-zinc-50 rounded-2xl border border-dashed border-zinc-300">
                  <div className="w-12 h-12 rounded-full bg-red-100 text-red-700 flex items-center justify-center mx-auto mb-3">
                    <Filter className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-bold text-zinc-900">No student records found</h3>
                  <p className="text-xs text-zinc-500 mt-1 max-w-md mx-auto">
                    Try clearing search query or switching your academic year ({selectedYear}) and time filters ({selectedTimeRange}).
                  </p>
                  <button
                    onClick={() => {
                      setSelectedYear('ALL');
                      setSelectedTimeRange('ALL');
                      setSearchQuery('');
                    }}
                    className="mt-4 px-4 py-2 bg-red-700 hover:bg-red-800 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
                  >
                    Reset All Filters
                  </button>
                </div>
              ) : (
                <div className="space-y-3.5">
                  {filteredStudents.map((student, idx) => {
                    const isExpanded = expandedStudentId === student.id;
                    const expsCount = student.completedExperiments?.length || 0;
                    const streak = student.currentStreak || 0;
                    const timeSecs = student.totalActiveSeconds || 0;

                    return (
                      <div
                        key={student.id || student.email}
                        className="bg-white rounded-2xl border border-zinc-200 hover:border-zinc-300 shadow-xs transition-all overflow-hidden"
                      >
                        {/* Summary Bar */}
                        <div className="p-4 sm:p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                          {/* Left: Student Identity */}
                          <div className="flex items-start sm:items-center gap-3.5 min-w-0">
                            <div className="w-11 h-11 rounded-full bg-red-700 text-white font-black text-sm flex items-center justify-center shrink-0 shadow-xs">
                              {student.name.charAt(0)}
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <h4 className="text-base font-bold text-zinc-900 leading-tight">
                                  {student.name}
                                </h4>
                                {student.year && (
                                  <span
                                    className={`text-[10px] font-black px-2.5 py-0.5 rounded-md border ${getYearBadgeStyle(
                                      student.year
                                    )}`}
                                  >
                                    {student.year}
                                  </span>
                                )}
                                <span className="text-xs text-zinc-400 font-mono">
                                  #{idx + 1}
                                </span>
                              </div>
                              <div className="text-xs text-zinc-500 font-mono flex items-center gap-2 mt-1 flex-wrap">
                                <span className="font-bold text-red-700">{student.studentId || 'SVVNet'}</span>
                                <span>•</span>
                                <span className="truncate">{student.email}</span>
                                <span>•</span>
                                <span className="text-zinc-600">{student.department || 'AI & DS'}</span>
                              </div>
                            </div>
                          </div>

                          {/* Right: Academic Metrics */}
                          <div className="flex items-center gap-4 sm:gap-8 shrink-0 justify-between lg:justify-end border-t lg:border-t-0 pt-3 lg:pt-0 border-zinc-100">
                            {/* Experiments Completed */}
                            <div className="text-left lg:text-center">
                              <div className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">
                                Experiments
                              </div>
                              <div className="text-base sm:text-lg font-black text-zinc-900 flex items-center gap-1.5">
                                <BookOpen className="w-4 h-4 text-red-700" />
                                <span>{expsCount}</span>
                                <span className="text-xs font-normal text-zinc-400">done</span>
                              </div>
                            </div>

                            {/* Active Time Spent */}
                            <div className="text-left lg:text-center">
                              <div className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">
                                Time Spent
                              </div>
                              <div className="text-base sm:text-lg font-black text-zinc-900 flex items-center gap-1.5">
                                <Clock className="w-4 h-4 text-blue-600" />
                                <span>{formatDuration(timeSecs)}</span>
                              </div>
                            </div>

                            {/* Daily Continuous Streak */}
                            <div className="text-left lg:text-center">
                              <div className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">
                                Daily Streak
                              </div>
                              <div className="flex items-center gap-1">
                                <div className="text-base sm:text-lg font-black text-amber-700 flex items-center gap-1">
                                  <Flame className="w-4 h-4 text-amber-500 fill-amber-500" />
                                  <span>{streak}d</span>
                                </div>
                                {student.longestStreak > 0 && (
                                  <span className="text-[11px] text-zinc-400 font-medium hidden sm:inline">
                                    (Max {student.longestStreak}d)
                                  </span>
                                )}
                              </div>
                            </div>

                            {/* Toggle Details Button */}
                            <button
                              onClick={() => setExpandedStudentId(isExpanded ? null : student.id)}
                              className={`px-3.5 py-2 rounded-xl border text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                                isExpanded
                                  ? 'bg-zinc-900 text-white border-zinc-900 shadow-sm'
                                  : 'bg-zinc-50 hover:bg-red-50 hover:text-red-800 hover:border-red-200 border-zinc-200 text-zinc-700'
                              }`}
                            >
                              <span>{isExpanded ? 'Hide Details' : 'View Exps'}</span>
                              {isExpanded ? (
                                <ChevronUp className="w-4 h-4" />
                              ) : (
                                <ChevronDown className="w-4 h-4" />
                              )}
                            </button>
                          </div>
                        </div>

                        {/* Expanded Experiment Records Drawer */}
                        {isExpanded && (
                          <div className="p-4 sm:p-5 bg-zinc-50 border-t border-zinc-200">
                            <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                              <div className="text-xs font-bold text-zinc-800 flex items-center gap-2">
                                <Award className="w-4 h-4 text-red-700" />
                                <span>Verified Practical Experiment Logs ({expsCount}):</span>
                              </div>
                              <div className="text-xs text-zinc-500 font-mono">
                                Last Completion: {student.lastCompletionDate || 'Recently Active'}
                              </div>
                            </div>

                            {expsCount === 0 ? (
                              <div className="p-4 bg-white rounded-xl border border-dashed border-zinc-200 text-center text-xs text-zinc-500">
                                Student has not yet completed and submitted any experiment quizzes. Total active lab time logged: {formatDuration(timeSecs)}.
                              </div>
                            ) : (
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                {student.completedExperiments.map((exp, expIdx) => (
                                  <div
                                    key={`${exp.experimentId}-${expIdx}`}
                                    className="p-3.5 bg-white rounded-xl border border-zinc-200 flex items-start justify-between gap-3 shadow-2xs"
                                  >
                                    <div className="min-w-0">
                                      <div className="text-[10px] font-bold text-red-700 uppercase tracking-wider font-mono">
                                        {exp.subjectId.toUpperCase()} • {exp.experimentId}
                                      </div>
                                      <div className="text-sm font-bold text-zinc-900 truncate">
                                        {exp.title}
                                      </div>
                                      <div className="text-xs text-zinc-500 mt-1 flex items-center gap-2 flex-wrap">
                                        <span className="flex items-center gap-1">
                                          <Clock className="w-3.5 h-3.5 text-zinc-400" />
                                          {formatDuration(exp.activeSeconds || 1200)}
                                        </span>
                                        <span>•</span>
                                        <span>{new Date(exp.completedAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                                      </div>
                                    </div>

                                    <div className="text-right shrink-0">
                                      <span className="px-2.5 py-1 rounded-md bg-emerald-50 border border-emerald-200 text-emerald-800 font-black text-xs">
                                        {exp.score !== undefined ? `${exp.score}/5` : 'Pass'}
                                      </span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: Cohort Analytics (FY, SY, TY, LY) */}
          {activeTab === 'cohort-analytics' && (
            <div className="p-4 sm:p-6 space-y-6">
              <div>
                <h3 className="text-base font-bold text-zinc-900">Academic Year Cohort Performance Matrix</h3>
                <p className="text-xs text-zinc-500 mt-0.5">
                  Aggregated virtual lab performance across First Year (FY), Second Year (SY), Third Year (TY), and Final Year (LY).
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {yearCohorts.map((cohort) => (
                  <div
                    key={cohort.year}
                    className="p-5 bg-white rounded-2xl border border-zinc-200 shadow-xs hover:border-red-300 transition-all"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <span className={`text-xs font-black px-2.5 py-1 rounded-lg border ${getYearBadgeStyle(cohort.year)}`}>
                        {cohort.year} Cohort
                      </span>
                      <span className="text-xs text-zinc-400 font-medium">AI & DS</span>
                    </div>

                    <div className="space-y-2.5">
                      <div>
                        <div className="text-xs text-zinc-400 font-bold uppercase">Enrolled Students</div>
                        <div className="text-2xl font-black text-zinc-900">{cohort.count}</div>
                      </div>

                      <div className="pt-2 border-t border-zinc-100 flex justify-between items-center text-xs">
                        <span className="text-zinc-500">Completed Exps:</span>
                        <span className="font-bold text-emerald-700">{cohort.totalExps}</span>
                      </div>

                      <div className="flex justify-between items-center text-xs">
                        <span className="text-zinc-500">Avg Time / Student:</span>
                        <span className="font-bold text-blue-700">{cohort.avgDuration}</span>
                      </div>

                      <div className="flex justify-between items-center text-xs">
                        <span className="text-zinc-500">Active Daily Streaks:</span>
                        <span className="font-bold text-amber-700">{cohort.activeStreaks}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Department Accreditation & Audit Note */}
              <div className="p-4 bg-red-50/50 rounded-2xl border border-red-200/80 flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-red-700 shrink-0 mt-0.5" />
                <div className="text-xs text-zinc-700 space-y-1">
                  <div className="font-bold text-red-950">Autonomous Continuous Evaluation Compliance</div>
                  <div>
                    This live data feed tracks practical lab assignments directly aligned with the Somaiya autonomous curriculum. The records are cryptographically timestamped and ready for Continuous Assessment (CA), Term Work, and NAAC/NBA criteria documentation.
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Experiments Matrix */}
          {activeTab === 'experiments-matrix' && (
            <div className="p-4 sm:p-6 space-y-4">
              <div>
                <h3 className="text-base font-bold text-zinc-900">Virtual Lab Experiment Completion Frequency</h3>
                <p className="text-xs text-zinc-500 mt-0.5">
                  Ranked by student practical quiz submissions and simulation completions across all subjects.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {experimentRankings.map((exp, idx) => (
                  <div
                    key={exp.id}
                    className="p-4 bg-white rounded-xl border border-zinc-200 flex items-center justify-between gap-3 shadow-2xs"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="w-7 h-7 rounded-lg bg-red-50 text-red-700 font-black text-xs flex items-center justify-center shrink-0">
                        #{idx + 1}
                      </span>
                      <div className="min-w-0">
                        <div className="text-[10px] font-bold text-red-700 uppercase font-mono">
                          {exp.subject}
                        </div>
                        <div className="text-xs sm:text-sm font-bold text-zinc-900 truncate">
                          {exp.title}
                        </div>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="text-sm font-black text-zinc-900">{exp.count}</div>
                      <div className="text-[10px] text-zinc-400 uppercase font-bold">Submissions</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Advanced Personalized Export Modal */}
      {showCustomExportModal && (
        <div
          id="custom-export-modal"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowCustomExportModal(false);
          }}
        >
          <div className="bg-white rounded-3xl border border-zinc-200 shadow-2xl max-w-xl w-full flex flex-col max-h-[90vh] overflow-hidden">
            {/* Modal Header */}
            <div className="p-5 border-b border-zinc-100 flex items-center justify-between bg-zinc-50/70">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-red-100 text-red-700 flex items-center justify-center">
                  <SlidersHorizontal className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-zinc-900">Personalized CSV Export Generator</h3>
                  <p className="text-xs text-zinc-500 font-medium">Filter by academic years, student lab engagement, and select columns</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowCustomExportModal(false)}
                className="w-8 h-8 rounded-full bg-zinc-100 hover:bg-zinc-200 text-zinc-600 flex items-center justify-center transition-colors cursor-pointer"
                title="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Content Body */}
            <div className="p-6 overflow-y-auto space-y-6 text-sm">
              {/* Year Filter Section */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-black text-zinc-800 uppercase tracking-wider flex items-center gap-1.5">
                    <GraduationCap className="w-4 h-4 text-red-700" />
                    <span>Include Academic Cohorts (FY, SY, TY, LY)</span>
                  </label>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setCustomExportYears({ FY: true, SY: true, TY: true, LY: true })}
                      className="text-[11px] font-bold text-red-700 hover:underline cursor-pointer"
                    >
                      Select All
                    </button>
                    <span className="text-zinc-300">|</span>
                    <button
                      type="button"
                      onClick={() => setCustomExportYears({ FY: false, SY: false, TY: false, LY: false })}
                      className="text-[11px] font-bold text-zinc-500 hover:underline cursor-pointer"
                    >
                      Clear
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {(['FY', 'SY', 'TY', 'LY'] as const).map((yr) => {
                    const isChecked = customExportYears[yr];
                    return (
                      <button
                        key={yr}
                        type="button"
                        onClick={() =>
                          setCustomExportYears((prev) => ({
                            ...prev,
                            [yr]: !prev[yr]
                          }))
                        }
                        className={`p-3 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                          isChecked
                            ? 'bg-red-50/80 border-red-300 text-red-950 font-bold shadow-xs ring-1 ring-red-400/40'
                            : 'bg-zinc-50 border-zinc-200 text-zinc-500 hover:bg-zinc-100'
                        }`}
                      >
                        <div>
                          <div className="text-xs font-black">{yr} Cohort</div>
                          <div className="text-[10px] opacity-75">{yearCounts[yr]} Students</div>
                        </div>
                        <div
                          className={`w-4 h-4 rounded flex items-center justify-center ${
                            isChecked ? 'bg-red-700 text-white' : 'border border-zinc-300'
                          }`}
                        >
                          {isChecked && <Check className="w-3 h-3" />}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Lab Activity Filter */}
              <div>
                <label className="text-xs font-black text-zinc-800 uppercase tracking-wider block mb-2">
                  Filter by Lab Practicals Completed
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: 'ALL', label: 'All Students' },
                    { id: 'ACTIVE', label: 'Completed ≥ 1' },
                    { id: 'HIGH', label: 'Completed ≥ 3' },
                    { id: 'INACTIVE', label: '0 Completed' }
                  ].map((act) => (
                    <button
                      key={act.id}
                      type="button"
                      onClick={() => setCustomExportActivity(act.id as any)}
                      className={`p-2.5 rounded-xl border text-xs font-bold transition-all text-center cursor-pointer ${
                        customExportActivity === act.id
                          ? 'bg-red-700 text-white border-red-700 shadow-xs'
                          : 'bg-zinc-50 border-zinc-200 text-zinc-700 hover:bg-zinc-100'
                      }`}
                    >
                      {act.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Time Range Filter */}
              <div>
                <label className="text-xs font-black text-zinc-800 uppercase tracking-wider block mb-2">
                  Filter by Total Lab Time
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { id: 'ALL', label: 'Any Time' },
                    { id: '<1h', label: '< 1 Hour' },
                    { id: '1-3h', label: '1 - 3 Hours' },
                    { id: '>3h', label: '> 3 Hours' }
                  ].map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setCustomExportTimeRange(t.id as any)}
                      className={`p-2 rounded-xl border text-xs font-bold transition-all text-center cursor-pointer ${
                        customExportTimeRange === t.id
                          ? 'bg-zinc-900 text-white border-zinc-900'
                          : 'bg-zinc-50 border-zinc-200 text-zinc-700 hover:bg-zinc-100'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Optional Search Query */}
              <div>
                <label className="text-xs font-black text-zinc-800 uppercase tracking-wider block mb-2">
                  Search Filter (Optional)
                </label>
                <div className="relative">
                  <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={customExportSearch}
                    onChange={(e) => setCustomExportSearch(e.target.value)}
                    placeholder="Search by student name, roll number, or email..."
                    className="w-full pl-10 pr-4 py-2 bg-zinc-50 border border-zinc-200 rounded-xl text-xs text-zinc-900 placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-red-600 focus:bg-white transition-all"
                  />
                  {customExportSearch && (
                    <button
                      type="button"
                      onClick={() => setCustomExportSearch('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600 p-0.5 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Columns to Include in CSV */}
              <div>
                <label className="text-xs font-black text-zinc-800 uppercase tracking-wider block mb-2">
                  Columns to Include in CSV
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { key: 'rollNo', label: 'Roll / SVVNet ID' },
                    { key: 'name', label: 'Student Name' },
                    { key: 'email', label: 'Somaiya Email' },
                    { key: 'year', label: 'Academic Year' },
                    { key: 'department', label: 'Department' },
                    { key: 'completedCount', label: 'Experiments Count' },
                    { key: 'activeMinutes', label: 'Active Minutes' },
                    { key: 'formattedDuration', label: 'Formatted Duration' },
                    { key: 'streaks', label: 'Activity Streaks' },
                    { key: 'lastActiveDate', label: 'Last Completion' },
                    { key: 'experimentTitles', label: 'Experiment Titles' }
                  ].map((col) => {
                    const isChecked = (customExportColumns as any)[col.key];
                    return (
                      <button
                        key={col.key}
                        type="button"
                        onClick={() =>
                          setCustomExportColumns((prev) => ({
                            ...prev,
                            [col.key]: !(prev as any)[col.key]
                          }))
                        }
                        className={`p-2 rounded-lg border text-left text-xs flex items-center gap-2 cursor-pointer transition-colors ${
                          isChecked
                            ? 'bg-zinc-900 text-white border-zinc-900 font-medium'
                            : 'bg-white text-zinc-600 border-zinc-200 hover:bg-zinc-50'
                        }`}
                      >
                        <div
                          className={`w-3.5 h-3.5 rounded flex items-center justify-center shrink-0 ${
                            isChecked ? 'bg-white text-zinc-950' : 'border border-zinc-300'
                          }`}
                        >
                          {isChecked && <Check className="w-2.5 h-2.5" />}
                        </div>
                        <span className="truncate">{col.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Live Preview Count Banner */}
              <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3.5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="w-4 h-4 text-amber-700" />
                  <span className="text-xs font-bold text-amber-950">
                    Ready to export {customModalFilteredStudents.length} of {students.length} students
                  </span>
                </div>
                <span className="text-[11px] font-black px-2 py-0.5 rounded-full bg-amber-200/70 text-amber-900">
                  {Object.values(customExportYears).filter(Boolean).length} Cohorts Selected
                </span>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-zinc-100 bg-zinc-50 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setShowCustomExportModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-zinc-600 hover:bg-zinc-200 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={customModalFilteredStudents.length === 0}
                onClick={() => {
                  const selectedYearsList =
                    Object.entries(customExportYears)
                      .filter(([_, sel]) => sel)
                      .map(([yr]) => yr)
                      .join('_') || 'Custom';
                  exportStudentsToCSV(
                    customModalFilteredStudents,
                    `Custom_${selectedYearsList}`
                  );
                  setShowCustomExportModal(false);
                }}
                className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-zinc-950 font-black text-xs shadow-md transition-all active:scale-95 flex items-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4 text-zinc-950" />
                <span>Download Filtered CSV ({customModalFilteredStudents.length})</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
