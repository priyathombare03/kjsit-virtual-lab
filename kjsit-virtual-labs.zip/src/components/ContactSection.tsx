import React, { useState } from 'react';
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  Send,
  CheckCircle2,
  Building,
  User,
  MessageSquare
} from 'lucide-react';
import { INSTITUTE_INFO } from '../data/instituteData';
import { SomaiyaEmblem } from './SomaiyaLogo';

export const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    department: 'Department of Artificial Intelligence and Data Science',
    subject: 'Virtual Lab Feedback',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;
    setSubmitted(true);
  };

  return (
    <section id="contact-section" className="py-16 bg-white border-t border-zinc-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <h2 className="text-2xl sm:text-3xl font-black text-black tracking-tight">
            Contact Virtual Labs Department
          </h2>
          <p className="text-sm text-zinc-600 mt-2">
            Have questions about laboratory simulations, experiment syllabus, or need technical assistance? Reach out to our academic department team.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Contact Information Card */}
          <div className="lg:col-span-5 bg-red-900 text-white rounded-2xl p-6 sm:p-8 shadow-sm border border-red-800 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-3.5 mb-6 pb-6 border-b border-red-800/80">
                <SomaiyaEmblem size={48} className="shadow-sm" />
                <div>
                  <h3 className="text-base font-bold text-white leading-tight">
                    {INSTITUTE_INFO.name}
                  </h3>
                  <p className="text-xs text-red-200 font-semibold mt-0.5">
                    Department of Artificial Intelligence and Data Science
                  </p>
                </div>
              </div>

              <div className="space-y-5 text-xs sm:text-sm">
                <div className="flex items-start gap-3.5">
                  <div className="p-2 bg-red-950/70 rounded-lg text-amber-300 shrink-0 mt-0.5 border border-red-800/80">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-amber-200 block text-xs uppercase tracking-wider mb-0.5">
                      Campus Address
                    </span>
                    <p className="text-red-100 leading-relaxed">
                      {INSTITUTE_INFO.contact.address}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="p-2 bg-red-950/70 rounded-lg text-amber-300 shrink-0 mt-0.5 border border-red-800/80">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-amber-200 block text-xs uppercase tracking-wider mb-0.5">
                      Telephone Helpline
                    </span>
                    <p className="text-red-100 font-mono">
                      {INSTITUTE_INFO.contact.phone}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="p-2 bg-red-950/70 rounded-lg text-amber-300 shrink-0 mt-0.5 border border-red-800/80">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-amber-200 block text-xs uppercase tracking-wider mb-0.5">
                      Institutional Email
                    </span>
                    <p className="text-red-100 font-mono">
                      {INSTITUTE_INFO.contact.email}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="p-2 bg-red-950/70 rounded-lg text-amber-300 shrink-0 mt-0.5 border border-red-800/80">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-amber-200 block text-xs uppercase tracking-wider mb-0.5">
                      Lab Portal Availability
                    </span>
                    <p className="text-red-100">
                      24×7 Online Access for Students & Faculty
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-4 border-t border-red-800/80 bg-red-950/80 -mx-2 -mb-2 p-4 rounded-xl">
              <div>
                <span className="text-[11px] font-bold text-amber-300 uppercase tracking-wider block mb-1">
                  Designed & Developed By
                </span>
                <p className="text-xs text-white font-semibold">
                  Priya Thombare and Vaishnavi Shinde
                </p>
                <p className="text-[11px] text-red-200 mt-0.5">
                  Department of Artificial Intelligence and Data Science, KJSIT
                </p>
              </div>
            </div>
          </div>

          {/* Interactive Inquiry Form */}
          <div className="lg:col-span-7 bg-white rounded-2xl p-6 sm:p-8 border border-zinc-200 shadow-xs">
            {submitted ? (
              <div className="py-12 flex flex-col items-center justify-center text-center">
                <div className="w-16 h-16 rounded-full bg-red-100 text-red-700 flex items-center justify-center mb-4">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-bold text-black mb-1">
                  Inquiry Dispatched Successfully
                </h3>
                <p className="text-xs text-zinc-600 max-w-md mb-6">
                  Thank you for contacting KJSIT Virtual Labs portal. Our laboratory team will get back to you at <strong>{formData.email}</strong> shortly.
                </p>
                <button
                  onClick={() => {
                    setSubmitted(false);
                    setFormData({
                      name: '',
                      email: '',
                      department: 'Computer Engineering',
                      subject: 'Virtual Lab Feedback',
                      message: ''
                    });
                  }}
                  className="px-4 py-2 bg-black text-white rounded-lg text-xs font-bold hover:bg-zinc-800 transition-colors cursor-pointer"
                >
                  Submit Another Feedback
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <h3 className="text-base font-bold text-black mb-1">
                  Send a Message to Virtual Lab Team
                </h3>
                <p className="text-xs text-zinc-500 mb-4">
                  Submit experiment inquiries, bug reports, or student curriculum questions.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-zinc-700 block mb-1">
                      Your Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g. Rahul Sharma"
                      className="w-full text-xs px-3 py-2 border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-600"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-zinc-700 block mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="e.g. rahul@somaiya.edu"
                      className="w-full text-xs px-3 py-2 border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-600"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-zinc-700 block mb-1">
                      Department
                    </label>
                    <select
                      value={formData.department}
                      onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                      className="w-full text-xs px-3 py-2 border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-600 bg-white"
                    >
                      <option>Department of Artificial Intelligence and Data Science</option>
                      <option>Department of Computer Engineering</option>
                      <option>Department of Information Technology</option>
                      <option>Department of Electronics & Telecommunication</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-zinc-700 block mb-1">
                      Subject
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      className="w-full text-xs px-3 py-2 border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-600"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-zinc-700 block mb-1">
                    Your Message / Question *
                  </label>
                  <textarea
                    rows={4}
                    required
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Describe your inquiry, simulation question, or feedback..."
                    className="w-full text-xs px-3 py-2 border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-600"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full sm:w-auto px-6 py-2.5 bg-red-700 hover:bg-red-800 text-white text-xs font-bold rounded-lg shadow-sm hover:shadow transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send Laboratory Inquiry</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
