import React, { useState, useMemo } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Search,
  BookOpen,
  CheckCircle2,
  GraduationCap
} from 'lucide-react';
import { LabSubject, LabExperiment, UserSession } from '../types';
import { LaunchLabArrow } from './LaunchLabArrow';

interface SubjectLabViewProps {
  subject: LabSubject;
  experiments: LabExperiment[];
  onSelectExperiment: (experimentId: string) => void;
  onBackToLabs: () => void;
  userSession: UserSession | null;
}

export const SubjectLabView: React.FC<SubjectLabViewProps> = ({
  subject,
  experiments,
  onSelectExperiment,
  onBackToLabs,
  userSession
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [search, setSearch] = useState<string>('');

  const categories = useMemo(() => {
    const set = new Set<string>();
    experiments.forEach((e) => {
      if (e.category) set.add(e.category);
    });
    return ['All', ...Array.from(set)];
  }, [experiments]);

  const filteredExperiments = useMemo(() => {
    return experiments.filter((exp) => {
      if (selectedCategory !== 'All' && exp.category !== selectedCategory) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        return (
          exp.title.toLowerCase().includes(q) ||
          exp.subtitle.toLowerCase().includes(q) ||
          (exp.category && exp.category.toLowerCase().includes(q)) ||
          exp.aim.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [experiments, selectedCategory, search]);

  return (
    <div className="py-10 bg-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb & Navigation */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <button
            onClick={onBackToLabs}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-white border border-zinc-300 rounded-xl text-xs font-bold text-zinc-800 hover:bg-zinc-100 transition-colors shadow-2xs cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to All Laboratories</span>
          </button>

          <div className="flex items-center gap-2 text-xs text-zinc-500">
            <span>Home</span>
            <span>/</span>
            <span>Virtual Labs</span>
            <span>/</span>
            <span className="font-bold text-red-700">{subject.name} ({subject.code})</span>
          </div>
        </div>

        {/* Subject Header Banner */}
        <div className="bg-black text-white rounded-2xl p-6 sm:p-8 shadow-sm mb-8 relative overflow-hidden border border-zinc-900">
          <div className="max-w-3xl relative z-10">
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight mb-2">
              {subject.name}
            </h2>
            <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed max-w-2xl mb-5">
              {subject.description}
            </p>

            {/* Quick stats */}
            <div className="flex flex-wrap gap-3 text-xs font-medium text-zinc-300">
              <div className="flex items-center gap-1.5 bg-zinc-900 border border-zinc-800 px-3 py-1.5 rounded-lg text-zinc-200 text-xs">
                <BookOpen className="w-3.5 h-3.5 text-red-500" />
                <span>{experiments.length} Interactive Experiments</span>
              </div>
              <div className="flex items-center gap-1.5 bg-zinc-900 border border-zinc-800 px-3 py-1.5 rounded-lg text-zinc-200 text-xs">
                <CheckCircle2 className="w-3.5 h-3.5 text-red-500" />
                <span>Theory & Self-Assessment Quizzes</span>
              </div>
              <div className="flex items-center gap-1.5 bg-zinc-900 border border-zinc-800 px-3 py-1.5 rounded-lg text-zinc-200 text-xs">
                <GraduationCap className="w-3.5 h-3.5 text-red-500" />
                <span>Course Code: {subject.code}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Filters & Search */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 mb-8 bg-white p-4 rounded-2xl border border-zinc-200 shadow-2xs">
          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-red-700 text-white shadow-xs'
                    : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative min-w-[240px]">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search experiments by name or keyword..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-zinc-50 border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-600"
            />
          </div>
        </div>

        {/* Experiments Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredExperiments.map((exp) => (
            <div
              key={exp.id}
              onClick={() => onSelectExperiment(exp.id)}
              className="bg-red-900/90 backdrop-blur-md border border-red-500/30 rounded-xl flex flex-col justify-between hover:border-red-400 hover:shadow-[0_8px_32px_rgba(185,28,28,0.4)] transition-all group cursor-pointer relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>

              <div className="p-4 relative z-10">
                <div className="flex items-start gap-2.5 mb-2">
                  <span className="w-6 h-6 rounded-md bg-white/20 text-white font-mono text-[11px] font-bold flex items-center justify-center shrink-0 mt-0.5 border border-white/20 shadow-inner">
                    #{exp.num}
                  </span>
                  <div className="min-w-0 flex-1">
                    <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-black/30 text-red-200 mb-1">
                      {exp.category || 'Core'}
                    </span>
                    <h3 className="text-sm font-extrabold text-white group-hover:text-red-100 transition-colors leading-snug drop-shadow-sm">
                      {exp.title}
                    </h3>
                  </div>
                </div>
              </div>

              {/* Card Footer */}
              <div className="px-4 py-2.5 bg-red-950/60 border-t border-red-800/50 flex items-center justify-end mt-auto relative z-10">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectExperiment(exp.id);
                  }}
                  className="launch-lab-btn w-full sm:w-auto px-3.5 py-2 sm:py-1.5 bg-white/15 hover:bg-white/25 active:bg-white/35 text-white text-xs font-bold rounded-lg border border-white/20 hover:border-white/35 shadow-xs hover:shadow-md transition-all duration-200 flex items-center justify-center gap-2 active:scale-95 cursor-pointer backdrop-blur-sm select-none"
                  title={`Launch Lab: ${exp.title}`}
                >
                  <span>Launch Lab</span>
                  <LaunchLabArrow />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
