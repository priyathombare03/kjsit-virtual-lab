import React, { useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  Send,
  Flame,
  Award,
  Sparkles,
  ShieldCheck,
  Lock,
  ArrowUpRight
} from 'lucide-react';
import { LabActivityStatus, UserSession } from '../types';

interface LabActiveTrackerBarProps {
  status: LabActivityStatus;
  sessionActiveSeconds: number;
  formattedSessionTime: string;
  simulationExecuted: boolean;
  codeVerified: boolean;
  quizScore: number | null;
  isCompletedAlready: boolean;
  isSubmitting: boolean;
  onSubmit: () => Promise<{ success: boolean; message: string }>;
  userSession: UserSession | null;
  onOpenLogin: () => void;
  experimentTitle: string;
  onNavigateTab?: (tab: 'simulation' | 'code' | 'quiz') => void;
}

export const LabActiveTrackerBar: React.FC<LabActiveTrackerBarProps> = ({
  status,
  sessionActiveSeconds,
  formattedSessionTime,
  simulationExecuted,
  codeVerified,
  quizScore,
  isCompletedAlready,
  isSubmitting,
  onSubmit,
  userSession,
  onOpenLogin,
  experimentTitle,
  onNavigateTab
}) => {
  const [submissionFeedback, setSubmissionFeedback] = useState<{
    show: boolean;
    success: boolean;
    message: string;
  } | null>(null);

  // Strict 3-parameter requirement: Simulation, IDE Code, and Quiz MUST all be completed
  const isSimDone = simulationExecuted;
  const isCodeDone = codeVerified;
  const isQuizDone = quizScore !== null && quizScore !== undefined;
  const completedCount = (isSimDone ? 1 : 0) + (isCodeDone ? 1 : 0) + (isQuizDone ? 1 : 0);
  const allThreeDone = isSimDone && isCodeDone && isQuizDone;

  const handleTriggerSubmit = async () => {
    if (!userSession) {
      onOpenLogin();
      return;
    }

    if (!allThreeDone && !isCompletedAlready) {
      const missing: string[] = [];
      if (!isSimDone) missing.push("1. Simulation");
      if (!isCodeDone) missing.push("2. IDE Code Execution");
      if (!isQuizDone) missing.push("3. Quiz Submission");

      setSubmissionFeedback({
        show: true,
        success: false,
        message: `Cannot submit yet (${completedCount}/3 done). You must complete all 3 parameters: ${missing.join(', ')}.`
      });
      setTimeout(() => {
        setSubmissionFeedback(null);
      }, 7000);
      return;
    }

    const result = await onSubmit();
    setSubmissionFeedback({
      show: true,
      success: result.success,
      message: result.message
    });
    setTimeout(() => {
      setSubmissionFeedback(null);
    }, 6000);
  };

  return (
    <div className="bg-zinc-900 border-y border-zinc-800 text-white px-4 py-2.5 sm:px-6 shadow-md transition-all">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        {/* Lab Timer */}
        <div className="flex items-center gap-3.5 flex-wrap">
          {/* Active Timer Display - Persisted & Continues from where it stopped */}
          <div className="flex items-center gap-1.5 text-xs font-mono text-zinc-300 bg-zinc-950 px-2.5 py-1 rounded-md border border-zinc-800" title="Accumulated active lab time on this experiment (persisted and resumes automatically)">
            <Clock className="w-3.5 h-3.5 text-red-500" />
            <span className="text-zinc-400 text-[11px]">Lab Time:</span>
            <span className="font-bold text-white tracking-wider">{formattedSessionTime}</span>
          </div>
        </div>

        {/* Steps Completed Checklist & Submission Action */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end flex-wrap sm:flex-nowrap">
          {/* 3 Parameter Required Checklist */}
          <div className="flex items-center gap-1.5 text-[11px] text-zinc-400">
            <span className="text-[10px] uppercase font-bold text-zinc-500 mr-1 hidden sm:inline">
              Reqs ({completedCount}/3):
            </span>

            {/* Parameter 1: Simulation */}
            <button
              type="button"
              onClick={() => onNavigateTab && onNavigateTab('simulation')}
              className={`flex items-center gap-1 px-2 py-0.5 rounded border transition-all cursor-pointer ${
                isSimDone
                  ? 'bg-emerald-950/70 border-emerald-500/40 text-emerald-300 shadow-2xs'
                  : 'bg-zinc-950 border-zinc-700/80 text-zinc-400 hover:border-red-500/40 hover:text-zinc-200'
              }`}
              title={isSimDone ? "Parameter 1: Simulation Executed ✓" : "Parameter 1: Simulation Pending (Click to go to Simulation tab)"}
            >
              <CheckCircle2 className={`w-3 h-3 ${isSimDone ? 'text-emerald-400' : 'text-zinc-600'}`} />
              <span className={isSimDone ? 'font-medium' : ''}>1. Simulation</span>
            </button>

            {/* Parameter 2: IDE Code */}
            <button
              type="button"
              onClick={() => onNavigateTab && onNavigateTab('code')}
              className={`flex items-center gap-1 px-2 py-0.5 rounded border transition-all cursor-pointer ${
                isCodeDone
                  ? 'bg-emerald-950/70 border-emerald-500/40 text-emerald-300 shadow-2xs'
                  : 'bg-zinc-950 border-zinc-700/80 text-zinc-400 hover:border-red-500/40 hover:text-zinc-200'
              }`}
              title={isCodeDone ? "Parameter 2: IDE Code Tested ✓" : "Parameter 2: IDE Code Pending (Click to go to Code tab and run code)"}
            >
              <CheckCircle2 className={`w-3 h-3 ${isCodeDone ? 'text-emerald-400' : 'text-zinc-600'}`} />
              <span className={isCodeDone ? 'font-medium' : ''}>2. IDE Code</span>
            </button>

            {/* Parameter 3: Quiz */}
            <button
              type="button"
              onClick={() => onNavigateTab && onNavigateTab('quiz')}
              className={`flex items-center gap-1 px-2 py-0.5 rounded border transition-all cursor-pointer ${
                isQuizDone
                  ? 'bg-emerald-950/70 border-emerald-500/40 text-emerald-300 shadow-2xs'
                  : 'bg-zinc-950 border-zinc-700/80 text-zinc-400 hover:border-red-500/40 hover:text-zinc-200'
              }`}
              title={isQuizDone ? `Parameter 3: Quiz Done (Score: ${quizScore}) ✓` : "Parameter 3: Quiz Pending (Click to go to Quiz tab and submit answers)"}
            >
              <CheckCircle2 className={`w-3 h-3 ${isQuizDone ? 'text-emerald-400' : 'text-zinc-600'}`} />
              <span className={isQuizDone ? 'font-medium' : ''}>3. Quiz</span>
            </button>
          </div>

          {/* Submit / Verification Button */}
          {isCompletedAlready ? (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950/90 text-emerald-300 border border-emerald-500/40 text-xs font-bold shadow-xs shrink-0">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Verified & Completed</span>
            </div>
          ) : (
            <button
              type="button"
              onClick={handleTriggerSubmit}
              disabled={isSubmitting || !allThreeDone}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs shrink-0 ${
                allThreeDone
                  ? 'bg-red-700 hover:bg-red-800 text-white ring-2 ring-red-500/30 animate-pulse active:scale-98 cursor-pointer'
                  : 'bg-zinc-950 text-zinc-400 border border-zinc-800 hover:border-zinc-700 cursor-not-allowed opacity-85'
              }`}
              title={allThreeDone ? "All 3 tasks complete! Submit this experiment to your Somaiya profile." : `Complete all 3 tasks (${completedCount}/3 done) before submitting`}
            >
              {isSubmitting ? (
                <>
                  <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                  <span>Verifying Lab...</span>
                </>
              ) : allThreeDone ? (
                <>
                  <Send className="w-3.5 h-3.5 text-white" />
                  <span>Submit Experiment (3/3)</span>
                </>
              ) : (
                <>
                  <Lock className="w-3.5 h-3.5 text-zinc-500" />
                  <span>Submit Experiment ({completedCount}/3)</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>

      {/* Submission Feedback Toast */}
      {submissionFeedback && (
        <div
          className={`mt-2 p-2.5 rounded-lg text-xs font-semibold flex items-center justify-between border animate-in fade-in slide-in-from-top-1 ${
            submissionFeedback.success
              ? 'bg-emerald-950 text-emerald-200 border-emerald-500/50'
              : 'bg-red-950 text-red-200 border-red-500/50'
          }`}
        >
          <div className="flex items-center gap-2">
            {submissionFeedback.success ? (
              <Flame className="w-4 h-4 text-amber-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            )}
            <span>{submissionFeedback.message}</span>
          </div>
          <button
            onClick={() => setSubmissionFeedback(null)}
            className="text-zinc-400 hover:text-white text-xs px-1 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}
    </div>
  );
};
