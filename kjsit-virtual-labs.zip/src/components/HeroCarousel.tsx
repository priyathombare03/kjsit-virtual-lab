import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Play, ArrowRight, BookOpen, Award, ShieldCheck, CheckCircle2, BrainCircuit, Database, Terminal } from 'lucide-react';
import { HERO_SLIDES, INSTITUTE_INFO } from '../data/instituteData';

interface HeroCarouselProps {
  onExploreLabs: () => void;
  onLaunchDAA?: () => void;
  onLaunchDSA?: () => void;
  onLaunchML?: () => void;
  onLaunchDBMS?: () => void;
  onLaunchOS?: () => void;
}

export const HeroCarousel: React.FC<HeroCarouselProps> = ({
  onExploreLabs,
  onLaunchDAA,
  onLaunchDSA,
  onLaunchML,
  onLaunchDBMS,
  onLaunchOS
}) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  useEffect(() => {
    if (!isAutoPlaying) return;
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % HERO_SLIDES.length);
    }, 5500);
    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  const slide = HERO_SLIDES[currentSlide];

  return (
    <section className="relative bg-black overflow-hidden">
      {/* Full-width Carousel Frame */}
      <div className="relative min-h-[480px] sm:min-h-[540px] lg:min-h-[580px] flex items-center">
        {/* Background Image with Dark Vignette Gradient */}
        {HERO_SLIDES.map((s, idx) => (
          <div
            key={s.id}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              idx === currentSlide ? 'opacity-100' : 'opacity-0 pointer-events-none'
            }`}
          >
            <img
              src={s.image}
              alt={s.title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center scale-105 filter brightness-45 contrast-115"
            />
            {/* Gradient Overlays for High-Contrast Readability */}
            <div className="absolute inset-0 bg-gradient-to-r from-black via-black/85 to-black/40"></div>
            <div className="absolute inset-0 bg-radial-at-c from-transparent via-black/60 to-black/90"></div>
          </div>
        ))}

        {/* Content Container */}
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 z-10 w-full">
          <div className="max-w-3xl">
            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight mb-4 drop-shadow-md">
              {slide.title}
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-zinc-200 font-medium mb-4 leading-relaxed">
              {slide.subtitle}
            </p>

            {/* Tagline paragraph */}
            <p className="text-xs sm:text-sm text-zinc-300 mb-8 max-w-2xl leading-relaxed">
              {slide.tagline}
            </p>

            {/* CTA Action Button */}
            <div className="flex flex-wrap items-center gap-3.5">
              <button
                onClick={onExploreLabs}
                className="px-6 py-3.5 bg-red-700 hover:bg-red-800 text-white font-bold text-sm rounded-full shadow-lg shadow-red-950/40 transition-all flex items-center gap-2 hover:gap-3 group active:scale-95 cursor-pointer"
              >
                <BookOpen className="w-4 h-4 text-amber-300" />
                <span>Explore All Virtual Labs</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Carousel Navigation Arrows */}
        <button
          onClick={() => {
            setIsAutoPlaying(false);
            setCurrentSlide((prev) => (prev - 1 + HERO_SLIDES.length) % HERO_SLIDES.length);
          }}
          className="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-black/70 hover:bg-black border border-white/15 text-white flex items-center justify-center backdrop-blur-xs transition-all opacity-80 hover:opacity-100 cursor-pointer"
          aria-label="Previous Slide"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <button
          onClick={() => {
            setIsAutoPlaying(false);
            setCurrentSlide((prev) => (prev + 1) % HERO_SLIDES.length);
          }}
          className="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-black/70 hover:bg-black border border-white/15 text-white flex items-center justify-center backdrop-blur-xs transition-all opacity-80 hover:opacity-100 cursor-pointer"
          aria-label="Next Slide"
        >
          <ChevronRight className="w-5 h-5" />
        </button>

        {/* Carousel Indicator Dots */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2 bg-black/70 backdrop-blur-xs px-3 py-1.5 rounded-full border border-white/10">
          {HERO_SLIDES.map((_, idx) => (
            <button
              key={idx}
              onClick={() => {
                setIsAutoPlaying(false);
                setCurrentSlide(idx);
              }}
              className={`h-2 rounded-full transition-all duration-300 cursor-pointer ${
                idx === currentSlide
                  ? 'w-6 bg-red-600'
                  : 'w-2 bg-white/40 hover:bg-white/70'
              }`}
              aria-label={`Go to slide ${idx + 1}`}
            />
          ))}
        </div>
      </div>

      {/* Stats Ribbon */}
      <div className="border-t border-zinc-900 bg-black text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 divide-y md:divide-y-0 md:divide-x divide-zinc-900">
            {INSTITUTE_INFO.stats.map((stat, i) => (
              <div key={i} className="flex flex-col items-center text-center px-4 pt-2 md:pt-0">
                <span className="text-xl sm:text-2xl font-black text-red-500 tracking-tight">
                  {stat.value}
                </span>
                <span className="text-xs font-bold text-zinc-200 mt-0.5">
                  {stat.label}
                </span>
                <span className="text-[11px] text-zinc-400">
                  {stat.sub}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
