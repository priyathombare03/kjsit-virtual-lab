import React, { useEffect } from 'react';
import {
  X,
  Flame,
  Trophy,
  Clock,
  CheckCircle2,
  Calendar,
  Award,
  GraduationCap,
  Sparkles,
  ChevronRight,
  BookOpen,
  ArrowUpRight,
  Check,
  ShieldCheck,
  Building
} from 'lucide-react';
import { UserSession } from '../types';
import { SomaiyaEmblem } from './SomaiyaLogo';

interface StudentDashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  userSession: UserSession | null;
  onSelectExperiment?: (expId: string) => void;
}

export const StudentDashboardModal: React.FC<StudentDashboardModalProps> = ({
  isOpen,
  onClose,
  userSession,
  onSelectExperiment
}) => {
  // Listen for Escape key press to dismiss modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen || !userSession) return null;

  const totalSecs = userSession.totalActiveSeconds || 0;
  const hours = Math.floor(totalSecs / 3600);
  const minutes = Math.floor((totalSecs % 3600) / 60);
  const seconds = totalSecs % 60;
  const formattedTotalTime = `${hours > 0 ? `${hours}h ` : ''}${minutes}m ${seconds}s`;

  const todayStr = new Date().toISOString().split('T')[0];
  const isCompletedToday = userSession.lastCompletionDate === todayStr || 
    userSession.completionDates?.includes(todayStr);

  const completedList = (userSession.completedExperiments || []).map((item: any) => {
    if (typeof item === 'string') {
      return {
        experimentId: item,
        subjectId: 'General',
        title: item.split('-').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(' '),
        activeSeconds: 1200,
        completedAt: new Date().toISOString(),
        score: 5
      };
    }
    return item;
  });

  const completedCount = completedList.length;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-md animate-in fade-in duration-300 overflow-y-auto cursor-pointer"
      onClick={onClose}
    >
      {/* Background Ambient Glow Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/3 w-96 h-96 bg-red-600/15 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/3 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl" />
      </div>

      <div 
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-3xl max-w-3xl w-full shadow-[0_25px_60px_-15px_rgba(0,0,0,0.3)] border border-zinc-200 overflow-hidden relative my-auto max-h-[92vh] flex flex-col animate-in zoom-in-95 duration-200 cursor-default"
      >
        {/* Header Ribbon with Red Glassmorphic Look */}
        <div className="bg-linear-to-r from-red-950/95 via-red-900/90 to-rose-950/95 backdrop-blur-2xl text-white p-5 sm:p-6 relative border-b border-red-500/20 shrink-0 overflow-hidden">
          {/* Glossy top highlight & ambient red glass reflections */}
          <div className="absolute inset-x-0 top-0 h-[1.5px] bg-linear-to-r from-red-500/20 via-white/40 to-red-500/20 pointer-events-none" />
          <div className="absolute -top-10 right-1/4 w-60 h-32 bg-red-500/25 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute -bottom-10 left-10 w-48 h-24 bg-amber-500/15 rounded-full blur-2xl pointer-events-none" />
          
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onClose();
            }}
            className="absolute top-4 right-4 text-white/90 hover:text-white p-2.5 rounded-full bg-white/10 hover:bg-white/25 border border-white/20 backdrop-blur-md transition-all cursor-pointer shadow-sm z-30 hover:scale-105 active:scale-95"
            title="Close Dashboard"
            aria-label="Close Dashboard"
          >
            <X className="w-4 h-4 pointer-events-none" />
          </button>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10 pr-14">
            <div className="flex items-center gap-3.5">
              <div className="p-2.5 bg-white/10 backdrop-blur-md rounded-2xl border border-white/25 shadow-[0_4px_20px_rgba(0,0,0,0.25)] shrink-0 ring-1 ring-white/10">
                <SomaiyaEmblem size={44} />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-lg sm:text-xl font-bold text-white tracking-tight drop-shadow-xs">
                    {userSession.name}
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-full bg-white/15 backdrop-blur-md text-white text-[10px] font-bold uppercase tracking-wider shadow-xs border border-white/25">
                    {userSession.role}
                  </span>
                </div>
                <p className="text-xs text-red-200 font-semibold mt-1 flex items-center gap-2 flex-wrap">
                  <span className="bg-black/30 backdrop-blur-sm px-2.5 py-0.5 rounded-lg border border-white/15 font-mono text-red-100 shadow-2xs">
                    {userSession.studentId || userSession.idNumber || 'SVVNet Student'}
                  </span>
                  <span className="text-red-300/60">•</span>
                  <span className="text-red-100/90 font-normal">{userSession.email}</span>
                </p>
                <p className="text-[11px] text-red-200/80 mt-1 flex items-center gap-1.5 flex-wrap">
                  <span>{userSession.department || 'Artificial Intelligence and Data Science'}</span>
                  {userSession.year && (
                    <>
                      <span>•</span>
                      <span className="px-2 py-0.5 rounded bg-amber-400/20 border border-amber-300/30 text-amber-200 font-bold">
                        {userSession.year}
                      </span>
                    </>
                  )}
                  <span>•</span>
                  <span className="text-amber-300 font-medium">KJSIT Autonomous</span>
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Dashboard Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 flex-1 bg-linear-to-b from-zinc-50/50 via-white/70 to-zinc-100/60 backdrop-blur-lg">
          {/* Core Metrics Grid - Glass Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
            {/* Total Active Lab Time */}
            <div className="bg-white/65 hover:bg-white/80 transition-all p-4 rounded-2xl border border-white/80 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] backdrop-blur-md flex flex-col justify-between group">
              <div className="flex items-center justify-between text-zinc-500 mb-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-600">Total Lab Time</span>
                <div className="p-1.5 rounded-lg bg-red-50 text-red-700 group-hover:scale-105 transition-transform">
                  <Clock className="w-3.5 h-3.5" />
                </div>
              </div>
              <div>
                <div className="text-lg sm:text-xl font-extrabold text-zinc-900 font-mono tracking-tight">
                  {formattedTotalTime}
                </div>
                <span className="text-[10px] text-zinc-500 font-medium">Active experiment focus</span>
              </div>
            </div>

            {/* Experiments Completed */}
            <div className="bg-white/65 hover:bg-white/80 transition-all p-4 rounded-2xl border border-white/80 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] backdrop-blur-md flex flex-col justify-between group">
              <div className="flex items-center justify-between text-zinc-500 mb-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-600">Experiments</span>
                <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700 group-hover:scale-105 transition-transform">
                  <Award className="w-3.5 h-3.5" />
                </div>
              </div>
              <div>
                <div className="text-lg sm:text-xl font-extrabold text-zinc-900">
                  {completedCount} <span className="text-xs text-zinc-500 font-normal">Labs</span>
                </div>
                <span className="text-[10px] text-zinc-500 font-medium">Verified & submitted</span>
              </div>
            </div>

            {/* Current Streak - Glowing Glass Highlight */}
            <div className="bg-linear-to-br from-amber-500/15 via-red-500/10 to-amber-500/5 p-4 rounded-2xl border border-amber-300/60 shadow-[0_4px_20px_-4px_rgba(245,158,11,0.15)] backdrop-blur-md flex flex-col justify-between relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-16 h-16 bg-amber-400/20 rounded-full blur-xl pointer-events-none" />
              <div className="flex items-center justify-between text-amber-900 mb-2 relative z-10">
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-900">Daily Streak</span>
                <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-700 group-hover:scale-110 transition-transform">
                  <Flame className="w-3.5 h-3.5 text-amber-600 fill-amber-500 animate-pulse" />
                </div>
              </div>
              <div className="relative z-10">
                <div className="text-lg sm:text-xl font-black text-zinc-900 flex items-center gap-1">
                  <span>{userSession.currentStreak || 0}</span>
                  <span className="text-xs text-amber-800 font-extrabold">Days 🔥</span>
                </div>
                <span className="text-[10px] text-amber-800/80 font-semibold">1 exp/day goal</span>
              </div>
            </div>

            {/* Longest Streak */}
            <div className="bg-white/65 hover:bg-white/80 transition-all p-4 rounded-2xl border border-white/80 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] backdrop-blur-md flex flex-col justify-between group">
              <div className="flex items-center justify-between text-zinc-500 mb-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-600">Max Record</span>
                <div className="p-1.5 rounded-lg bg-amber-50 text-amber-600 group-hover:scale-105 transition-transform">
                  <Trophy className="w-3.5 h-3.5" />
                </div>
              </div>
              <div>
                <div className="text-lg sm:text-xl font-extrabold text-zinc-900">
                  {userSession.longestStreak || 0} <span className="text-xs text-zinc-500 font-normal">Days</span>
                </div>
                <span className="text-[10px] text-zinc-500 font-medium">Personal best record</span>
              </div>
            </div>
          </div>

          {/* Today's Streak Status Frosted Banner */}
          <div
            className={`p-4 rounded-2xl border backdrop-blur-md transition-all shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
              isCompletedToday
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-950'
                : 'bg-amber-500/10 border-amber-500/30 text-amber-950'
            }`}
          >
            <div className="flex items-start gap-3.5">
              <div
                className={`p-2.5 rounded-xl shadow-xs shrink-0 ${
                  isCompletedToday
                    ? 'bg-linear-to-br from-emerald-600 to-teal-700 text-white'
                    : 'bg-linear-to-br from-amber-500 to-red-600 text-white'
                }`}
              >
                {isCompletedToday ? <Check className="w-5 h-5" /> : <Flame className="w-5 h-5 fill-white/80" />}
              </div>
              <div>
                <h4 className="text-sm font-bold tracking-tight">
                  {isCompletedToday
                    ? "Today's Daily Streak Secured! 🔥"
                    : "Today's Daily Streak Incomplete"}
                </h4>
                <p className="text-xs mt-0.5 text-zinc-700 leading-relaxed max-w-xl">
                  {isCompletedToday
                    ? "You have completed at least 1 experiment today. Your streak is verified and synced with Somaiya servers."
                    : "Complete and submit at least one Virtual Lab experiment today (execute interactive simulation or Monaco IDE code + quiz) to extend your streak."}
                </p>
              </div>
            </div>

            <div className="shrink-0 text-right">
              <span
                className={`inline-flex items-center gap-1 px-3.5 py-1.5 rounded-full text-xs font-bold shadow-2xs border ${
                  isCompletedToday
                    ? 'bg-emerald-100/90 text-emerald-900 border-emerald-300/60'
                    : 'bg-amber-100/90 text-amber-900 border-amber-300/60'
                }`}
              >
                {isCompletedToday ? 'Streak Maintained ✅' : 'Pending Today ⏳'}
              </span>
            </div>
          </div>

          {/* Academic Lab Transcript / Activity Log */}
          <div>
            <div className="flex items-center justify-between mb-3 px-1">
              <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-700 flex items-center gap-1.5">
                <GraduationCap className="w-4 h-4 text-red-700" />
                <span>Verified Experiment Transcript ({completedList.length})</span>
              </h4>
              <span className="text-[11px] text-zinc-500 font-medium">Official KJSIT Academic Record</span>
            </div>

            {completedList.length === 0 ? (
              <div className="p-8 text-center bg-white/50 backdrop-blur-md rounded-2xl border border-dashed border-zinc-300 shadow-2xs">
                <BookOpen className="w-8 h-8 text-zinc-400 mx-auto mb-2" />
                <p className="text-xs font-semibold text-zinc-700">No experiments submitted yet.</p>
                <p className="text-[11px] text-zinc-500 mt-1 max-w-sm mx-auto">
                  Launch any lab subject, run the interactive algorithm simulation or write code in the Monaco IDE, and submit your completion!
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {completedList.map((exp: any, idx: number) => {
                  const m = Math.floor((exp.activeSeconds || 1200) / 60);
                  const s = (exp.activeSeconds || 1200) % 60;
                  const dateStr = exp.completedAt
                    ? new Date(exp.completedAt).toLocaleDateString(undefined, {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric'
                      })
                    : 'Recently Completed';

                  return (
                    <div
                      key={idx}
                      className="bg-white/75 hover:bg-white/95 backdrop-blur-md p-3.5 sm:p-4 rounded-2xl border border-white/80 hover:border-red-200/80 shadow-[0_2px_12px_-2px_rgba(0,0,0,0.04)] hover:shadow-md transition-all flex items-center justify-between gap-3 group"
                    >
                      <div className="flex items-center gap-3.5">
                        <div className="w-8 h-8 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-700 flex items-center justify-center font-bold text-xs shrink-0 group-hover:scale-105 transition-transform">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs font-bold text-zinc-900 group-hover:text-red-700 transition-colors cursor-pointer">
                              {exp.title}
                            </span>
                            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-zinc-100 text-zinc-700 border border-zinc-200/50">
                              {exp.subjectId?.toUpperCase() || 'CS'}
                            </span>
                          </div>
                          <div className="flex items-center gap-2.5 text-[11px] text-zinc-500 mt-1 flex-wrap font-medium">
                            <span>Completed: {dateStr}</span>
                            <span>•</span>
                            <span className="font-mono text-zinc-700">Lab Time: {m}m {s}s</span>
                            {exp.score !== undefined && (
                              <>
                                <span>•</span>
                                <span className="text-emerald-700 font-semibold bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200/50">
                                  Score: {exp.score}/5
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      {onSelectExperiment && (
                        <button
                          onClick={() => {
                            onSelectExperiment(exp.experimentId);
                            onClose();
                          }}
                          className="text-xs font-semibold text-red-700 hover:text-white hover:bg-red-700 p-2 rounded-xl border border-red-200/60 hover:border-red-700 transition-all flex items-center gap-1 cursor-pointer shrink-0 shadow-2xs"
                          title="Open experiment workbench"
                        >
                          <span className="hidden sm:inline">Review</span>
                          <ArrowUpRight className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Footer info bar with Glass Styling */}
        <div className="bg-zinc-100/80 backdrop-blur-md px-6 py-3.5 border-t border-white/60 dark:border-white/10 flex flex-col sm:flex-row items-center justify-between text-[11px] text-zinc-600 gap-2 shrink-0">
          <div className="flex items-center gap-2">
            <Building className="w-4 h-4 text-red-700/80 shrink-0" />
            <span className="font-medium">K. J. Somaiya Institute of Technology • Autonomous Engineering College</span>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-linear-to-r from-red-700/90 via-red-600/85 to-rose-700/90 hover:from-red-600 hover:via-red-500 hover:to-rose-600 text-white text-xs font-bold rounded-xl border border-white/30 backdrop-blur-md shadow-[0_4px_16px_-2px_rgba(220,38,38,0.4)] hover:shadow-[0_6px_20px_rgba(220,38,38,0.55)] active:scale-[0.98] transition-all cursor-pointer flex items-center gap-1.5"
          >
            <span>Close Dashboard</span>
          </button>
        </div>
      </div>
    </div>
  );
};
