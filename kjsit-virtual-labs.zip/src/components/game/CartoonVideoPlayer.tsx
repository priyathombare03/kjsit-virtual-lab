import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  SkipForward,
  Volume2,
  VolumeX,
  Sparkles,
  Tv,
  Film,
  MessageSquare
} from 'lucide-react';
import { gameAudio } from '../../utils/gameAudio';
import { CartoonScene } from '../../utils/aiGameService';
import { CartoonRoboticFace } from './RealisticRoboticFace';

interface CartoonVideoPlayerProps {
  gameTitle: string;
  levelName: string;
  storyboard: CartoonScene[];
  onFinish?: () => void;
  onClose?: () => void;
}

export const CartoonVideoPlayer: React.FC<CartoonVideoPlayerProps> = ({
  gameTitle,
  levelName,
  storyboard,
  onFinish,
  onClose
}) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [currentSceneIdx, setCurrentSceneIdx] = useState(0);
  const [displayedText, setDisplayedText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [isMuted, setIsMuted] = useState(gameAudio.isMuted());

  const currentScene = storyboard[currentSceneIdx] || storyboard[0] || {
    speaker: 'Byte the Bot',
    text: 'Mission initialized! Let us solve this algorithmic puzzle step by step.',
    emotion: 'happy'
  };

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Typewriter effect for speech
  useEffect(() => {
    if (!currentScene) return;
    setIsTyping(true);
    setDisplayedText('');
    let charIdx = 0;
    const fullText = currentScene.text;

    if (timerRef.current) clearInterval(timerRef.current);

    const speedMs = Math.max(12, Math.floor(26 / playbackSpeed));

    timerRef.current = setInterval(() => {
      charIdx++;
      setDisplayedText(fullText.slice(0, charIdx));
      if (charIdx % 3 === 0) {
        gameAudio.playBlip();
      }
      if (charIdx >= fullText.length) {
        if (timerRef.current) clearInterval(timerRef.current);
        setIsTyping(false);
      }
    }, speedMs);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [currentSceneIdx, currentScene.text, playbackSpeed]);

  // Auto advance scenes when playing
  useEffect(() => {
    if (!isPlaying || isTyping) return;

    const delay = Math.max(1200, Math.floor(2400 / playbackSpeed));
    const advanceTimeout = setTimeout(() => {
      if (currentSceneIdx < storyboard.length - 1) {
        setCurrentSceneIdx((prev) => prev + 1);
      } else {
        setIsPlaying(false);
        if (onFinish) onFinish();
      }
    }, delay);

    return () => clearTimeout(advanceTimeout);
  }, [isPlaying, isTyping, currentSceneIdx, storyboard.length, playbackSpeed, onFinish]);

  const handleNextScene = () => {
    if (currentSceneIdx < storyboard.length - 1) {
      setCurrentSceneIdx((prev) => prev + 1);
    } else {
      setIsPlaying(false);
      if (onFinish) onFinish();
    }
  };

  const handlePrevScene = () => {
    if (currentSceneIdx > 0) {
      setCurrentSceneIdx((prev) => prev - 1);
    }
  };

  const handleRestart = () => {
    setCurrentSceneIdx(0);
    setIsPlaying(true);
  };

  const toggleSound = () => {
    const next = gameAudio.toggleMute();
    setIsMuted(next);
  };

  const isAlarmed = currentScene.emotion === 'alarmed';

  return (
    <div className="rounded-2xl overflow-hidden border border-zinc-800 bg-zinc-950 text-white shadow-xl relative font-sans">
      {/* Top Header - Clean, Minimalist Dark Graphite */}
      <div className="px-5 py-3 bg-zinc-900 border-b border-zinc-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-7 h-7 rounded-lg bg-zinc-800 border border-zinc-700 flex items-center justify-center text-zinc-300">
            <Tv className="w-3.5 h-3.5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold tracking-wide text-zinc-200">
                Mission Storyboard Briefing
              </span>
              <span className="px-2 py-0.5 rounded bg-zinc-800 text-zinc-400 text-[10px] font-semibold border border-zinc-700/80">
                STORYBOARD
              </span>
            </div>
            <p className="text-[11px] text-zinc-400 font-normal truncate max-w-xs">{gameTitle}</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleSound}
            className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 transition-colors cursor-pointer"
            title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>
          {onClose && (
            <button
              onClick={onClose}
              className="px-2.5 py-1 text-xs font-semibold bg-zinc-800 hover:bg-zinc-700 rounded-lg text-zinc-300 border border-zinc-700 transition-colors cursor-pointer"
            >
              Skip
            </button>
          )}
        </div>
      </div>

      {/* Main Clean Stage */}
      <div className="p-6 sm:p-7 min-h-[290px] flex flex-col justify-between relative bg-zinc-950">
        {/* Scene Indicator & Emotion Pills */}
        <div className="flex items-center justify-between text-xs font-medium mb-4">
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-zinc-900 text-zinc-300 border border-zinc-800 text-[11px] font-mono">
              <Film className="w-3 h-3 text-amber-400" />
              <span>SCENE {currentSceneIdx + 1} OF {storyboard.length}</span>
            </span>
            <span className="text-zinc-600">•</span>
            <span className="text-zinc-300 font-semibold">{levelName}</span>
          </div>

          <span
            className={`px-2.5 py-0.5 rounded-md text-[10px] font-bold uppercase border ${
              isAlarmed
                ? 'bg-red-500/10 border-red-500/30 text-red-400'
                : 'bg-zinc-900 border-zinc-800 text-amber-400'
            }`}
          >
            {currentScene.emotion || 'NORMAL'}
          </span>
        </div>

        {/* Robot Character & Speech Bubble */}
        <div className="flex flex-col sm:flex-row items-center gap-5 sm:gap-6 my-auto">
          {/* Cartoon Robot Avatar Container */}
          <div className="shrink-0 flex flex-col items-center">
            <div className="p-1 rounded-2xl bg-zinc-900 border border-zinc-800 shadow-sm">
              <CartoonRoboticFace
                emotion={currentScene.emotion as any}
                isAnalyzing={isTyping}
                size={82}
              />
            </div>

            <div className="mt-2 text-center">
              <div className="text-[11px] font-bold px-2.5 py-0.5 rounded bg-zinc-800 border border-zinc-700 text-zinc-200">
                {currentScene.speaker}
              </div>
              <span className="text-[10px] text-zinc-500 font-medium block mt-0.5">
                AI Coding Coach
              </span>
            </div>
          </div>

          {/* Dialogue Speech Card */}
          <div className="flex-1 bg-zinc-900 text-zinc-100 p-5 rounded-2xl border border-zinc-800 relative shadow-sm min-w-0">
            <div className="flex items-center gap-2 mb-2 text-zinc-400 text-xs font-medium">
              <MessageSquare className="w-3.5 h-3.5 text-amber-400" />
              <span>Mission Dialogue</span>
            </div>

            <p className="text-sm sm:text-base font-medium leading-relaxed text-zinc-100 min-h-[50px]">
              {displayedText}
              {isTyping && <span className="inline-block w-2 h-4 bg-amber-400 ml-1.5 animate-pulse rounded-sm" />}
            </p>

            <div className="mt-3.5 flex items-center justify-between text-xs text-zinc-500 border-t border-zinc-800/80 pt-2.5">
              <span className="flex items-center gap-1.5 text-zinc-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                <span>{isTyping ? 'Speaking...' : 'Ready'}</span>
              </span>
              <span className="text-[11px] text-zinc-400 font-mono">
                CodinGame Level
              </span>
            </div>
          </div>
        </div>

        {/* Clean Timeline Progress Bar */}
        <div className="w-full bg-zinc-900 h-1 rounded-full overflow-hidden mt-6 relative border border-zinc-800/60">
          <div
            className="bg-amber-400 h-full transition-all duration-300"
            style={{
              width: `${((currentSceneIdx + 1) / storyboard.length) * 100}%`
            }}
          />
        </div>
      </div>

      {/* Clean Bottom Playback Controls */}
      <div className="px-5 py-3 bg-zinc-900 border-t border-zinc-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="px-3.5 py-1.5 bg-white hover:bg-zinc-200 text-zinc-950 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current" />}
            <span>{isPlaying ? 'PAUSE' : 'PLAY'}</span>
          </button>

          <button
            onClick={handleRestart}
            className="p-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-lg text-xs transition-colors cursor-pointer border border-zinc-700"
            title="Replay Storyboard"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={handlePrevScene}
            disabled={currentSceneIdx === 0}
            className="px-2.5 py-1.5 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 text-zinc-300 rounded-lg text-xs transition-colors cursor-pointer font-medium border border-zinc-700"
          >
            PREV
          </button>

          <button
            onClick={handleNextScene}
            className="px-2.5 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-lg text-xs transition-colors cursor-pointer font-medium border border-zinc-700 flex items-center gap-1"
          >
            <span>NEXT</span>
            <SkipForward className="w-3 h-3" />
          </button>
        </div>

        {/* Clean Speed Selector */}
        <div className="flex items-center gap-1.5 text-xs font-medium text-zinc-400">
          <span>Speed:</span>
          {[1, 1.5, 2].map((s) => (
            <button
              key={s}
              onClick={() => setPlaybackSpeed(s)}
              className={`px-2 py-0.5 rounded text-xs font-semibold transition-colors cursor-pointer ${
                playbackSpeed === s
                  ? 'bg-zinc-200 text-zinc-950 font-bold'
                  : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700 hover:text-zinc-200'
              }`}
            >
              {s}x
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export const RealisticTacticalBriefing = CartoonVideoPlayer;
