import React, { useState } from 'react';
import {
  Sparkles,
  Lightbulb,
  RefreshCw,
  Bot
} from 'lucide-react';
import { askAiCoach, AiCoachResponse } from '../../utils/aiGameService';
import { gameAudio } from '../../utils/gameAudio';
import { CartoonRoboticFace } from './RealisticRoboticFace';

interface AiCartoonCoachProps {
  experimentId: string;
  gameTitle: string;
  currentLevelName: string;
  studentCode: string;
  language: string;
}

export const AiCartoonCoach: React.FC<AiCartoonCoachProps> = ({
  experimentId,
  gameTitle,
  currentLevelName,
  studentCode,
  language
}) => {
  const [coachResponse, setCoachResponse] = useState<AiCoachResponse>({
    coach: 'Byte the Bot',
    emotion: 'happy',
    advice: 'Ready to analyze your algorithmic code! Click "Ask Byte for Hint" whenever you need guidance.'
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleAskAdvice = async () => {
    setIsLoading(true);
    gameAudio.playBlip();
    const res = await askAiCoach({
      experimentId,
      gameTitle,
      currentLevel: currentLevelName,
      studentCode,
      language
    });
    setCoachResponse(res);
    setIsLoading(false);
    gameAudio.playPush();
  };

  return (
    <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-5 text-white shadow-lg relative font-sans">
      <div className="relative z-10 flex flex-col sm:flex-row items-center sm:items-start gap-5">
        {/* Cartoon Robot Face Container */}
        <div className="shrink-0 flex flex-col items-center">
          <div className="p-1 rounded-2xl bg-zinc-900 border border-zinc-800 shadow-sm">
            <CartoonRoboticFace
              emotion={coachResponse.emotion}
              isAnalyzing={isLoading}
              size={80}
            />
          </div>

          <div className="flex flex-col items-center mt-2">
            <span className="text-xs font-bold text-zinc-200">
              {coachResponse.coach || 'Byte the Bot'}
            </span>
            <span className="text-[10px] text-zinc-500 font-medium">
              AI Robot Coach
            </span>
          </div>
        </div>

        {/* Speech & Hint Box */}
        <div className="flex-1 space-y-3 text-center sm:text-left min-w-0">
          <div className="flex items-center justify-between gap-2 border-b border-zinc-800 pb-2">
            <div className="flex items-center gap-2">
              <Bot className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-semibold text-zinc-200">
                Byte's Algorithmic Guidance
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] font-medium text-emerald-400">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              <span>ACTIVE</span>
            </div>
          </div>

          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-3.5 relative text-xs sm:text-sm text-zinc-200 leading-relaxed shadow-sm">
            <p className="font-normal text-zinc-200">{coachResponse.advice}</p>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
            <div className="flex items-center gap-2 text-xs font-medium text-zinc-400">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Gemini AI Tutor</span>
            </div>

            <button
              onClick={handleAskAdvice}
              disabled={isLoading}
              className="px-4 py-2 bg-white hover:bg-zinc-200 disabled:opacity-50 text-zinc-950 font-bold rounded-xl text-xs flex items-center gap-2 transition-colors cursor-pointer shadow-sm"
            >
              {isLoading ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-zinc-800" />
              ) : (
                <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
              )}
              <span>{isLoading ? 'Thinking...' : 'Ask Byte for Hint'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export const RealisticAiCoach = AiCartoonCoach;
