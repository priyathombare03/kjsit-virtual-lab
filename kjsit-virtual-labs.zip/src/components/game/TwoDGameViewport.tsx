import React, { useEffect, useRef, useState } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  SkipForward,
  SkipBack,
  Volume2,
  VolumeX,
  Activity,
  Layers,
  Cpu,
  Radio,
  Gauge,
  Sliders,
  Terminal,
  Crosshair
} from 'lucide-react';
import { gameAudio } from '../../utils/gameAudio';

interface TwoDGameViewportProps {
  experimentId: string;
  levelData: any;
  gameState: {
    stackItems?: string[];
    doorOpen?: boolean;
    queueItems?: string[];
    departedPlanes?: string[];
    asteroidHp?: number;
    cannonAngle?: number;
    laserFired?: boolean;
    bossHp?: number;
    sortBoxes?: number[];
    activeComparingIndices?: [number, number] | null;
    visitedNodes?: string[];
    message?: string;
    // OOPM Interactive State
    atmBalance?: number;
    studentInstanceCount?: number;
    activeMedicalTest?: string;
    radarSweeping?: boolean;
    exceptionTriggered?: boolean;
    recordsWritten?: number;
    threadStep?: number;
    trainBerths?: number;
    bufferFlushed?: boolean;
  };
  onAction?: (actionType: string, payload?: any) => void;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  alpha: number;
  decay: number;
}

export const TwoDGameViewport: React.FC<TwoDGameViewportProps> = ({
  experimentId,
  levelData,
  gameState,
  onAction
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [isMuted, setIsMuted] = useState(gameAudio.isMuted());
  const particlesRef = useRef<Particle[]>([]);
  const frameCountRef = useRef(0);

  const isPlayingRef = useRef(isPlaying);
  const playbackSpeedRef = useRef(playbackSpeed);

  useEffect(() => {
    isPlayingRef.current = isPlaying;
  }, [isPlaying]);

  useEffect(() => {
    playbackSpeedRef.current = playbackSpeed;
  }, [playbackSpeed]);

  // Spawn visual physical particles
  const spawnParticles = (x: number, y: number, color: string, count = 12) => {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 4 + 1.5;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color,
        size: Math.random() * 3 + 1.5,
        alpha: 1,
        decay: Math.random() * 0.03 + 0.015
      });
    }
  };

  // 60FPS Game Loop with Realistic Physics & Continuous Motion
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const render = () => {
      if (isPlayingRef.current) {
        frameCountRef.current += playbackSpeedRef.current;
      }
      const frame = frameCountRef.current;
      const t = frame * 0.035;

      const width = canvas.width;
      const height = canvas.height;

      // Realistic Dark Carbon & Technical Blueprint Background
      ctx.fillStyle = '#0a0d14';
      ctx.fillRect(0, 0, width, height);

      // Precision technical grid
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.06)';
      ctx.lineWidth = 1;
      const gridSize = 24;
      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // CRT Scanline emulation
      ctx.fillStyle = 'rgba(0, 0, 0, 0.15)';
      for (let y = 0; y < height; y += 4) {
        ctx.fillRect(0, y, width, 1.5);
      }

      // Precision Telemetry Graticule Markers
      ctx.fillStyle = 'rgba(148, 163, 184, 0.35)';
      ctx.font = '8px monospace';
      ctx.fillText(`SYS_TIME: ${(frame * 0.016).toFixed(2)}s | CLK: 60.0Hz | PRECISION: REAL-TIME`, 12, 16);
      ctx.fillText(`TELEMETRY: [EXPERIMENT: ${experimentId.toUpperCase()}]`, width - 240, 16);

      // Route to experiment-specific realistic physics simulation
      if (experimentId.startsWith('oopm-')) {
        renderOopmScene(ctx, width, height, frame, t, experimentId);
      } else {
        renderDsaDaaScene(ctx, width, height, frame, t, experimentId);
      }

      // Update and render physical particles
      particlesRef.current.forEach((p, idx) => {
        p.x += p.vx;
        p.y += p.vy;
        p.alpha -= p.decay;
        ctx.save();
        ctx.globalAlpha = Math.max(0, p.alpha);
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });
      particlesRef.current = particlesRef.current.filter((p) => p.alpha > 0);

      animId = requestAnimationFrame(render);
    };

    render();

    return () => cancelAnimationFrame(animId);
  }, [experimentId, gameState]);

  // =========================================================================
  // REALISTIC SCENE RENDERERS: DSA & DAA
  // =========================================================================

  const renderDsaDaaScene = (
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    frame: number,
    t: number,
    expId: string
  ) => {
    switch (expId) {
      case 'stack-adt-linked-list':
      case 'stack-array':
        renderStackScene(ctx, width, height, frame, t);
        break;
      case 'queue-adt-array':
      case 'queue-linked-list':
        renderQueueScene(ctx, width, height, frame, t);
        break;
      case 'selection-sort':
      case 'insertion-sort':
      case 'bubble-sort':
      case 'merge-sort':
      case 'quick-sort':
        renderSortingScene(ctx, width, height, frame, t);
        break;
      case 'binary-tree-traversal':
      case 'binary-search-tree':
      case 'avl-tree':
        renderTreeScene(ctx, width, height, frame, t);
        break;
      case 'graph-dfs-bfs':
      case 'dijkstra-algo':
      case 'prims-algo':
      case 'kruskals':
      case 'bellman-ford':
      case 'tsp':
        renderGraphScene(ctx, width, height, frame, t);
        break;
      case 'kmp-algo':
      case 'fractional-knapsack':
      case 'knapsack-dp':
        renderKmpScene(ctx, width, height, frame, t);
        break;
      case 'n-queens':
        renderNQueensScene(ctx, width, height, frame, t);
        break;
      default:
        renderGenericLabScene(ctx, width, height, frame, t);
        break;
    }
  };

  // 1. Stack: Realistic High-Pressure Hydraulic Memory Ram & Titanium Register Cells
  const renderStackScene = (ctx: CanvasRenderingContext2D, width: number, height: number, frame: number, t: number) => {
    const chamberX = width * 0.65;
    const baseY = height - 40;

    // Heavy Industrial Structural Frame
    ctx.fillStyle = '#1e293b';
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(chamberX - 85, baseY - 220, 170, 220, 6);
    ctx.fill();
    ctx.stroke();

    // Hazard warning stripes at chamber base
    const stripeW = 14;
    ctx.save();
    ctx.beginPath();
    ctx.rect(chamberX - 85, baseY - 12, 170, 12);
    ctx.clip();
    for (let sx = chamberX - 100; sx < chamberX + 100; sx += stripeW * 2) {
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.moveTo(sx, baseY);
      ctx.lineTo(sx + stripeW, baseY);
      ctx.lineTo(sx + stripeW - 10, baseY - 12);
      ctx.lineTo(sx - 10, baseY - 12);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.moveTo(sx + stripeW, baseY);
      ctx.lineTo(sx + stripeW * 2, baseY);
      ctx.lineTo(sx + stripeW * 2 - 10, baseY - 12);
      ctx.lineTo(sx + stripeW - 10, baseY - 12);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();

    // Stack Register Rails (Stainless steel vertical guides)
    ctx.strokeStyle = '#64748b';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(chamberX - 65, baseY - 200);
    ctx.lineTo(chamberX - 65, baseY - 15);
    ctx.moveTo(chamberX + 65, baseY - 200);
    ctx.lineTo(chamberX + 65, baseY - 15);
    ctx.stroke();

    // Bourdon High-Pressure Gauge (Animated needle oscillating realistically)
    const gaugeX = chamberX - 120;
    const gaugeY = baseY - 140;
    ctx.fillStyle = '#0f172a';
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(gaugeX, gaugeY, 24, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Dial markings
    for (let a = 0; a < 6; a++) {
      const ang = Math.PI * 0.75 + (a / 5) * Math.PI * 1.5;
      const x1 = gaugeX + Math.cos(ang) * 18;
      const y1 = gaugeY + Math.sin(ang) * 18;
      const x2 = gaugeX + Math.cos(ang) * 21;
      const y2 = gaugeY + Math.sin(ang) * 21;
      ctx.strokeStyle = a > 4 ? '#ef4444' : '#38bdf8';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
    }

    // Needle trembling realistically
    const needleAng = Math.PI * 1.2 + Math.sin(t * 8) * 0.08 + Math.cos(t * 3) * 0.04;
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(gaugeX, gaugeY);
    ctx.lineTo(gaugeX + Math.cos(needleAng) * 16, gaugeY + Math.sin(needleAng) * 16);
    ctx.stroke();
    ctx.fillStyle = '#94a3b8';
    ctx.font = '8px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('185 BAR', gaugeX, gaugeY + 34);

    // Hydraulic Ram Piston Arm (Chrome rod extending/retracting)
    const pistonExtension = Math.sin(t * 2) * 8;
    const pistonX = chamberX;
    const pistonY = baseY - 220;
    ctx.fillStyle = '#94a3b8';
    ctx.fillRect(pistonX - 8, pistonY - 20, 16, 40 + pistonExtension);

    // Stack Memory Titanium Blocks
    const items = gameState.stackItems || ['0x7FFF_A0', '0x7FFF_98', '0x7FFF_90'];
    items.forEach((item, idx) => {
      const bob = Math.sin(t * 3 + idx * 0.8) * 1.5;
      const blockY = baseY - 32 - idx * 34 + bob;

      // Machined metallic block with brushed bevel
      const grad = ctx.createLinearGradient(chamberX - 58, blockY - 14, chamberX + 58, blockY + 14);
      grad.addColorStop(0, '#334155');
      grad.addColorStop(0.5, '#475569');
      grad.addColorStop(1, '#1e293b');
      ctx.fillStyle = grad;
      ctx.strokeStyle = idx === items.length - 1 ? '#38bdf8' : '#64748b';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(chamberX - 58, blockY - 14, 116, 28, 4);
      ctx.fill();
      ctx.stroke();

      // Green LED status pin
      ctx.fillStyle = '#10b981';
      ctx.beginPath();
      ctx.arc(chamberX - 48, blockY, 3, 0, Math.PI * 2);
      ctx.fill();

      // Hex Register Data Text
      ctx.fillStyle = '#f8fafc';
      ctx.font = 'bold 11px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(item, chamberX + 6, blockY + 4);

      if (idx === items.length - 1) {
        ctx.fillStyle = '#38bdf8';
        ctx.font = 'bold 9px monospace';
        ctx.fillText('◄ TOP_PTR (SP)', chamberX + 98, blockY + 3);
      }
    });

    // Hydraulic Pressure Line & Telemetry Readout
    ctx.fillStyle = '#94a3b8';
    ctx.font = '9px monospace';
    ctx.textAlign = 'left';
    ctx.fillText('HYDRAULIC LIFO ACTUATOR: ARMED', width * 0.12, baseY - 180);
    ctx.fillText(`ACTIVE CELLS: ${items.length} / 8`, width * 0.12, baseY - 165);
    ctx.fillText('BUS ARBITRATION: SYNCHRONIZED', width * 0.12, baseY - 150);

    // Vault Door Locking Status
    const isOpen = gameState.doorOpen;
    ctx.fillStyle = isOpen ? '#10b981' : '#ef4444';
    ctx.font = 'bold 11px monospace';
    ctx.fillText(isOpen ? 'INTERLOCK: DISENGAGED (PASS)' : 'INTERLOCK: ENGAGED (HOLD)', width * 0.12, baseY - 120);
  };

  // 2. Queue: Realistic Airport Runway & Tactical Jet Transports (FIFO Service)
  const renderQueueScene = (ctx: CanvasRenderingContext2D, width: number, height: number, frame: number, t: number) => {
    const runwayY = height * 0.52;

    // Asphalt Runway with realistic expansion joints
    ctx.fillStyle = '#181e29';
    ctx.fillRect(0, runwayY - 50, width, 100);

    // Concrete shoulders
    ctx.fillStyle = '#334155';
    ctx.fillRect(0, runwayY - 54, width, 4);
    ctx.fillRect(0, runwayY + 50, width, 4);

    // Runway Centerline moving stripes (Simulating high-speed approach/taxi)
    ctx.strokeStyle = '#f8fafc';
    ctx.lineWidth = 3;
    ctx.setLineDash([20, 14]);
    ctx.lineDashOffset = -frame * 2.2;
    ctx.beginPath();
    ctx.moveTo(0, runwayY);
    ctx.lineTo(width, runwayY);
    ctx.stroke();
    ctx.setLineDash([]);

    // Blinking Runway Edge Lights (Amber & Blue taxiway prisms)
    for (let lx = 15; lx < width; lx += 45) {
      const isLit = (Math.floor(frame * 0.1 + lx / 45) % 2) === 0;
      ctx.fillStyle = isLit ? '#38bdf8' : '#0369a1';
      ctx.beginPath();
      ctx.arc(lx, runwayY - 48, 2.5, 0, Math.PI * 2);
      ctx.arc(lx, runwayY + 46, 2.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // Realistic Jet Transports lined up in strict FIFO queue
    const planes = gameState.queueItems || ['FLIGHT_901', 'FLIGHT_412', 'FLIGHT_118'];
    planes.forEach((flight, idx) => {
      const planeBob = Math.sin(t * 3 + idx * 1.2) * 1.5;
      const planeX = width * 0.22 + idx * 125;
      const py = runwayY - 22 + planeBob;

      // Fuselage (Matte Titanium / Aerospace Grey)
      const grad = ctx.createLinearGradient(planeX - 45, py, planeX + 45, py + 44);
      grad.addColorStop(0, idx === 0 ? '#1e3a5f' : '#273549');
      grad.addColorStop(1, '#0f172a');
      ctx.fillStyle = grad;
      ctx.strokeStyle = idx === 0 ? '#38bdf8' : '#64748b';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(planeX - 42, py, 84, 44, 6);
      ctx.fill();
      ctx.stroke();

      // Swept Wings
      ctx.fillStyle = '#334155';
      ctx.beginPath();
      ctx.moveTo(planeX - 10, py);
      ctx.lineTo(planeX - 35, py - 18);
      ctx.lineTo(planeX + 15, py);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(planeX - 10, py + 44);
      ctx.lineTo(planeX - 35, py + 62);
      ctx.lineTo(planeX + 15, py + 44);
      ctx.closePath();
      ctx.fill();

      // Wingtip Navigation Strobes (Port: Red, Starboard: Green, Anticollision: White pulse)
      const strobe = Math.sin(t * 10 + idx) > 0.7;
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(planeX - 34, py - 18, 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#10b981';
      ctx.beginPath();
      ctx.arc(planeX - 34, py + 62, 2, 0, Math.PI * 2);
      ctx.fill();
      if (strobe) {
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(planeX + 42, py + 22, 3, 0, Math.PI * 2);
        ctx.fill();
      }

      // Turbofan Engine Exhaust Shimmer
      const flameLen = 6 + Math.random() * 8;
      ctx.fillStyle = 'rgba(56, 189, 248, 0.4)';
      ctx.beginPath();
      ctx.moveTo(planeX - 42, py + 16);
      ctx.lineTo(planeX - 42 - flameLen, py + 22);
      ctx.lineTo(planeX - 42, py + 28);
      ctx.closePath();
      ctx.fill();

      // Flight Callout Tag
      ctx.fillStyle = '#f8fafc';
      ctx.font = 'bold 9px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(flight, planeX, py + 26);

      if (idx === 0) {
        ctx.fillStyle = '#10b981';
        ctx.font = 'bold 9px monospace';
        ctx.fillText('◄ CLEARED FOR TAKEOFF (HEAD)', planeX, py - 26);
      }
    });

    // Radar Tracking Telemetry
    ctx.fillStyle = '#94a3b8';
    ctx.font = '9px monospace';
    ctx.textAlign = 'left';
    ctx.fillText('GROUND CONTROL FIFO DISPATCH', 16, height - 35);
    ctx.fillText(`QUEUE HEAD: ${planes[0] || 'NONE'} | RUNWAY STATUS: OCCUPIED`, 16, height - 20);
  };

  // 3. Sorting: Heavy Industrial Overhead Gantry Crane & Steel Billets
  const renderSortingScene = (ctx: CanvasRenderingContext2D, width: number, height: number, frame: number, t: number) => {
    const craneY = 48;
    const deckY = height - 55;

    // Structural Yellow/Black Overhead Crane Gantry Truss
    ctx.fillStyle = '#eab308';
    ctx.fillRect(20, craneY, width - 40, 16);
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(20, craneY + 16, width - 40, 3);

    // Crane Trolley gliding horizontally along track
    const comparing = gameState.activeComparingIndices || [1, 2];
    const targetIdx = comparing ? comparing[0] : 1;
    const trolleyX = width * 0.18 + targetIdx * 75;

    ctx.fillStyle = '#334155';
    ctx.strokeStyle = '#64748b';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(trolleyX - 22, craneY - 6, 44, 28, 4);
    ctx.fill();
    ctx.stroke();

    // Motorized Hoist Winch Drum with wound steel cables
    ctx.fillStyle = '#94a3b8';
    ctx.fillRect(trolleyX - 12, craneY + 14, 24, 10);

    // Steel Wire Rope hanging down with Hook
    const hookY = deckY - 95 + Math.sin(t * 3) * 6;
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(trolleyX - 6, craneY + 24);
    ctx.lineTo(trolleyX - 6, hookY);
    ctx.moveTo(trolleyX + 6, craneY + 24);
    ctx.lineTo(trolleyX + 6, hookY);
    ctx.stroke();

    // Heavy Forged Steel Crane Hook
    ctx.fillStyle = '#e2e8f0';
    ctx.beginPath();
    ctx.arc(trolleyX, hookY + 8, 8, 0, Math.PI);
    ctx.lineTo(trolleyX - 3, hookY);
    ctx.lineTo(trolleyX + 3, hookY);
    ctx.closePath();
    ctx.fill();

    // Red Laser Alignment Target Beam pointing to active billet
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.4)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(trolleyX, hookY + 12);
    ctx.lineTo(trolleyX, deckY - 10);
    ctx.stroke();
    ctx.setLineDash([]);

    // Machined Steel & Copper Alloy Ingots
    const boxes = gameState.sortBoxes || [45, 12, 89, 33, 67, 21, 95];
    boxes.forEach((val, idx) => {
      const bx = width * 0.18 + idx * 75;
      const bHeight = 24 + (val / 100) * 85;
      const by = deckY - bHeight;
      const isComparing = comparing && comparing.includes(idx);

      // Ingot material gradient
      const grad = ctx.createLinearGradient(bx - 22, by, bx + 22, deckY);
      if (isComparing) {
        grad.addColorStop(0, '#f59e0b');
        grad.addColorStop(0.5, '#b45309');
        grad.addColorStop(1, '#78350f');
      } else {
        grad.addColorStop(0, '#475569');
        grad.addColorStop(0.5, '#334155');
        grad.addColorStop(1, '#1e293b');
      }
      ctx.fillStyle = grad;
      ctx.strokeStyle = isComparing ? '#fbbf24' : '#64748b';
      ctx.lineWidth = isComparing ? 2 : 1;
      ctx.beginPath();
      ctx.roundRect(bx - 22, by, 44, bHeight, 3);
      ctx.fill();
      ctx.stroke();

      // Top stamp plate
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(bx - 18, by + 4, 36, 16);

      ctx.fillStyle = '#f8fafc';
      ctx.font = 'bold 10px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(`${val}kg`, bx, by + 16);

      // Index label below deck
      ctx.fillStyle = '#64748b';
      ctx.font = '8px monospace';
      ctx.fillText(`[${idx}]`, bx, deckY + 16);
    });

    // Roller Conveyor Deck Bed
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(20, deckY, width - 40, 6);
    for (let rx = 30; rx < width - 30; rx += 20) {
      ctx.fillStyle = '#475569';
      ctx.beginPath();
      ctx.arc(rx, deckY + 3, 2, 0, Math.PI * 2);
      ctx.fill();
    }
  };

  // 4. Trees & Graphs: High-Fidelity Optical Network Switchboard & Substation Telemetry
  const renderTreeScene = (ctx: CanvasRenderingContext2D, width: number, height: number, frame: number, t: number) => {
    // Hierarchical Fiber-Optic Nodes
    const nodes = [
      { id: 'ROOT', val: '50', x: width * 0.5, y: 70 },
      { id: 'L1', val: '25', x: width * 0.3, y: 140 },
      { id: 'R1', val: '75', x: width * 0.7, y: 140 },
      { id: 'L2A', val: '12', x: width * 0.2, y: 215 },
      { id: 'L2B', val: '38', x: width * 0.4, y: 215 },
      { id: 'R2A', val: '62', x: width * 0.6, y: 215 },
      { id: 'R2B', val: '88', x: width * 0.8, y: 215 }
    ];

    const edges = [
      [0, 1], [0, 2],
      [1, 3], [1, 4],
      [2, 5], [2, 6]
    ];

    // Pulsating Fiber Optic Cables
    edges.forEach(([from, to]) => {
      const p1 = nodes[from];
      const p2 = nodes[to];

      ctx.strokeStyle = '#1e3a5f';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();

      // Traveling light photon packets along fiber cable
      const pulseT = ((frame * 0.03 + from * 0.4) % 1);
      const px = p1.x + (p2.x - p1.x) * pulseT;
      const py = p1.y + (p2.y - p1.y) * pulseT;
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(px, py, 3.5, 0, Math.PI * 2);
      ctx.fill();
    });

    // Hardware Microcontroller Server Nodes
    nodes.forEach((n, idx) => {
      const isRoot = idx === 0;
      ctx.fillStyle = isRoot ? '#0369a1' : '#1e293b';
      ctx.strokeStyle = isRoot ? '#38bdf8' : '#64748b';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(n.x - 22, n.y - 16, 44, 32, 6);
      ctx.fill();
      ctx.stroke();

      // Activity LED
      ctx.fillStyle = (frame + idx * 7) % 15 < 8 ? '#10b981' : '#065f46';
      ctx.beginPath();
      ctx.arc(n.x - 14, n.y - 8, 2, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 11px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(n.val, n.x + 3, n.y + 4);
    });

    // Telemetry footer
    ctx.fillStyle = '#94a3b8';
    ctx.font = '9px monospace';
    ctx.textAlign = 'left';
    ctx.fillText('BALANCED BST TOPOLOGY · OPTICAL BACKBONE: 100Gbps', 16, height - 20);
  };

  // 5. Graph WAN Topography
  const renderGraphScene = (ctx: CanvasRenderingContext2D, width: number, height: number, frame: number, t: number) => {
    const nodes = [
      { id: 'MUMBAI_01', x: width * 0.25, y: 110, latency: '1.2ms' },
      { id: 'DELHI_02', x: width * 0.52, y: 75, latency: '12.4ms' },
      { id: 'BANGALORE_03', x: width * 0.42, y: 220, latency: '8.6ms' },
      { id: 'CHENNAI_04', x: width * 0.72, y: 195, latency: '14.1ms' },
      { id: 'KOLKATA_05', x: width * 0.8, y: 110, latency: '19.8ms' }
    ];

    const edges = [
      [0, 1, 14], [0, 2, 9], [1, 2, 17],
      [1, 4, 21], [2, 3, 6], [3, 4, 18]
    ];

    // Grid Coordinates Overlay
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.15)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(width * 0.5, height * 0.5, 110, 0, Math.PI * 2);
    ctx.stroke();

    edges.forEach(([u, v, cost]) => {
      const p1 = nodes[u];
      const p2 = nodes[v];
      ctx.strokeStyle = '#1e3a5f';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();

      // Traveling packets
      const progress = ((frame * 0.02 + u * 0.3) % 1);
      const px = p1.x + (p2.x - p1.x) * progress;
      const py = p1.y + (p2.y - p1.y) * progress;
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(px, py, 2.5, 0, Math.PI * 2);
      ctx.fill();

      // Weight badge
      const midX = (p1.x + p2.x) / 2;
      const midY = (p1.y + p2.y) / 2;
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(midX - 12, midY - 7, 24, 14);
      ctx.fillStyle = '#38bdf8';
      ctx.font = '8px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(`${cost}ms`, midX, midY + 4);
    });

    nodes.forEach((n) => {
      ctx.fillStyle = '#1e293b';
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(n.x, n.y, 14, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 9px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(n.id.slice(0, 3), n.x, n.y + 3);
      ctx.fillStyle = '#94a3b8';
      ctx.font = '8px monospace';
      ctx.fillText(n.latency, n.x, n.y + 24);
    });
  };

  // 6. KMP & Knapsack: Precision Mechanical Analytical Balance Scale
  const renderKmpScene = (ctx: CanvasRenderingContext2D, width: number, height: number, frame: number, t: number) => {
    const pivotX = width * 0.5;
    const pivotY = 110;
    const armLen = 140;

    // Heavy Cast Iron Pedestal
    ctx.fillStyle = '#1e293b';
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(pivotX - 35, height - 40);
    ctx.lineTo(pivotX + 35, height - 40);
    ctx.lineTo(pivotX + 12, pivotY);
    ctx.lineTo(pivotX - 12, pivotY);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Scale Beam oscillating realistically
    const tilt = Math.sin(t * 1.5) * 0.07;
    const leftX = pivotX - Math.cos(tilt) * armLen;
    const leftY = pivotY - Math.sin(tilt) * armLen;
    const rightX = pivotX + Math.cos(tilt) * armLen;
    const rightY = pivotY + Math.sin(tilt) * armLen;

    ctx.strokeStyle = '#fbbf24';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(leftX, leftY);
    ctx.lineTo(rightX, rightY);
    ctx.stroke();

    // Agate Knife Edge Fulcrum
    ctx.fillStyle = '#d97706';
    ctx.beginPath();
    ctx.arc(pivotX, pivotY, 8, 0, Math.PI * 2);
    ctx.fill();

    // Left Pan with Steel Suspension Chains
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(leftX, leftY);
    ctx.lineTo(leftX - 25, leftY + 70);
    ctx.moveTo(leftX, leftY);
    ctx.lineTo(leftX + 25, leftY + 70);
    ctx.stroke();

    ctx.fillStyle = '#d97706';
    ctx.beginPath();
    ctx.arc(leftX, leftY + 72, 30, 0, Math.PI);
    ctx.fill();

    // Inscribed Calibrated Weights
    ctx.fillStyle = '#475569';
    ctx.fillRect(leftX - 16, leftY + 54, 32, 18);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 9px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('W: 15kg', leftX, leftY + 66);

    // Right Pan with Suspension Chains
    ctx.strokeStyle = '#94a3b8';
    ctx.beginPath();
    ctx.moveTo(rightX, rightY);
    ctx.lineTo(rightX - 25, rightY + 70);
    ctx.moveTo(rightX, rightY);
    ctx.lineTo(rightX + 25, rightY + 70);
    ctx.stroke();

    ctx.fillStyle = '#d97706';
    ctx.beginPath();
    ctx.arc(rightX, rightY + 72, 30, 0, Math.PI);
    ctx.fill();

    ctx.fillStyle = '#475569';
    ctx.fillRect(rightX - 16, rightY + 54, 32, 18);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 9px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('VAL: ₹240', rightX, rightY + 66);
  };

  // 7. N-Queens: High-Security Laser Sensor Matrix & Titanium Containment
  const renderNQueensScene = (ctx: CanvasRenderingContext2D, width: number, height: number, frame: number, t: number) => {
    const boardSize = 4;
    const cellSize = 54;
    const startX = width * 0.5 - (boardSize * cellSize) / 2;
    const startY = 55;

    // Laser Security Chamber Frame
    ctx.fillStyle = '#0f172a';
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(startX - 15, startY - 15, boardSize * cellSize + 30, boardSize * cellSize + 30, 8);
    ctx.fill();
    ctx.stroke();

    // Chessboard Substrate
    for (let r = 0; r < boardSize; r++) {
      for (let c = 0; c < boardSize; c++) {
        const isDark = (r + c) % 2 === 1;
        ctx.fillStyle = isDark ? '#1e293b' : '#334155';
        ctx.fillRect(startX + c * cellSize, startY + r * cellSize, cellSize, cellSize);

        // Grid coordinate microtext
        ctx.fillStyle = '#64748b';
        ctx.font = '7px monospace';
        ctx.fillText(`${String.fromCharCode(65 + c)}${boardSize - r}`, startX + c * cellSize + 4, startY + r * cellSize + 10);
      }
    }

    // Active Queen Positions (Solution arrangement)
    const queens = [{ r: 0, c: 1 }, { r: 1, c: 3 }, { r: 2, c: 0 }, { r: 3, c: 2 }];
    queens.forEach((q) => {
      const qx = startX + q.c * cellSize + cellSize / 2;
      const qy = startY + q.r * cellSize + cellSize / 2;

      // Realistic Optical Laser Tripwires radiating along row, col, diag
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.45)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(startX, qy);
      ctx.lineTo(startX + boardSize * cellSize, qy);
      ctx.moveTo(qx, startY);
      ctx.lineTo(qx, startY + boardSize * cellSize);
      ctx.stroke();

      // Precision Machined Titanium Queen Turret
      ctx.fillStyle = '#0284c7';
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(qx, qy, 14, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Rotating targeting emitter
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(qx, qy, 4, 0, Math.PI * 2);
      ctx.fill();
    });
  };

  const renderGenericLabScene = (ctx: CanvasRenderingContext2D, width: number, height: number, frame: number, t: number) => {
    ctx.fillStyle = '#38bdf8';
    ctx.font = '12px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('REALISTIC COMPUTATIONAL PHYSICS PIPELINE ACTIVE', width * 0.5, height * 0.5);
  };

  // =========================================================================
  // REALISTIC SCENE RENDERERS: OOPM EXPERIMENTS (EXP 1 to EXP 10)
  // =========================================================================

  const renderOopmScene = (
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    frame: number,
    t: number,
    expId: string
  ) => {
    switch (expId) {
      case 'oopm-exp1':
        renderOopmExp1(ctx, width, height, frame, t);
        break;
      case 'oopm-exp2':
        renderOopmExp2(ctx, width, height, frame, t);
        break;
      case 'oopm-exp3':
        renderOopmExp3(ctx, width, height, frame, t);
        break;
      case 'oopm-exp4':
        renderOopmExp4(ctx, width, height, frame, t);
        break;
      case 'oopm-exp5':
        renderOopmExp5(ctx, width, height, frame, t);
        break;
      case 'oopm-exp6':
        renderOopmExp6(ctx, width, height, frame, t);
        break;
      case 'oopm-exp7':
        renderOopmExp7(ctx, width, height, frame, t);
        break;
      case 'oopm-exp8':
        renderOopmExp8(ctx, width, height, frame, t);
        break;
      case 'oopm-exp9':
        renderOopmExp9(ctx, width, height, frame, t);
        break;
      case 'oopm-exp10':
        renderOopmExp10(ctx, width, height, frame, t);
        break;
      default:
        renderGenericLabScene(ctx, width, height, frame, t);
        break;
    }
  };

  // EXP 1: Hardware Silicon Microprocessor Bus & 8KB L1 SRAM Cache (Scanner vs BufferedReader)
  const renderOopmExp1 = (ctx: CanvasRenderingContext2D, width: number, height: number, frame: number, t: number) => {
    const isFlushed = gameState.bufferFlushed;

    // Green FR-4 Silicon PCB Motherboard Substrate
    ctx.fillStyle = '#064e3b';
    ctx.fillRect(20, 35, width - 40, height - 70);

    // Copper Traces with gold pads
    ctx.strokeStyle = '#d97706';
    ctx.lineWidth = 1.5;
    for (let py = 60; py < height - 70; py += 35) {
      ctx.beginPath();
      ctx.moveTo(35, py);
      ctx.lineTo(width - 35, py);
      ctx.stroke();
    }

    // CPU Socket with Aluminum Fin Heat Sink and Spinning Fan
    const cpuX = width * 0.28;
    const cpuY = height * 0.5;
    ctx.fillStyle = '#1e293b';
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(cpuX - 50, cpuY - 50, 100, 100, 8);
    ctx.fill();
    ctx.stroke();

    // 7-Blade Cooling Fan Spinning
    ctx.save();
    ctx.translate(cpuX, cpuY);
    ctx.rotate(t * 8);
    for (let b = 0; b < 7; b++) {
      ctx.fillStyle = '#64748b';
      ctx.beginPath();
      ctx.ellipse(0, -22, 6, 18, (b / 7) * Math.PI * 2, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.fillStyle = '#0f172a';
    ctx.beginPath();
    ctx.arc(0, 0, 12, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 9px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('JAVA JVM CORE', cpuX, cpuY + 68);

    // 8KB SRAM L1 Cache Chip (BufferedReader)
    const cacheX = width * 0.72;
    const cacheY = height * 0.5;
    ctx.fillStyle = '#0f172a';
    ctx.strokeStyle = isFlushed ? '#10b981' : '#38bdf8';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(cacheX - 60, cacheY - 45, 120, 90, 6);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = isFlushed ? '#34d399' : '#38bdf8';
    ctx.font = 'bold 11px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('8KB L1 BUFFER', cacheX, cacheY - 14);
    ctx.fillStyle = '#94a3b8';
    ctx.font = '9px monospace';
    ctx.fillText('BURST: 8192 BYTES', cacheX, cacheY + 6);
    ctx.fillText(isFlushed ? 'STATUS: FLUSHED' : 'STATUS: CACHED', cacheX, cacheY + 24);

    // High-Speed Data Packet Bus (High frequency electron stream)
    const pulseCount = 8;
    for (let p = 0; p < pulseCount; p++) {
      const prog = ((frame * 0.04 + p / pulseCount) % 1);
      const px = cpuX + 50 + (cacheX - 60 - (cpuX + 50)) * prog;
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(px, cpuY, 3, 0, Math.PI * 2);
      ctx.fill();
    }
  };

  // EXP 2: Diebold Nixdorf Bank-Grade ATM & High-Security Mutex Vault
  const renderOopmExp2 = (ctx: CanvasRenderingContext2D, width: number, height: number, frame: number, t: number) => {
    const atmX = width * 0.35;
    const vaultX = width * 0.72;
    const cy = height * 0.5;
    const balance = gameState.atmBalance ?? 25000;

    // ATM Brushed Titanium Bezel
    ctx.fillStyle = '#1e293b';
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.roundRect(atmX - 70, cy - 100, 140, 200, 8);
    ctx.fill();
    ctx.stroke();

    // LCD Monitor Display with Security Status
    ctx.fillStyle = '#0284c7';
    ctx.fillRect(atmX - 55, cy - 85, 110, 65);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 10px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('SOMAIYA BANK ATM', atmX, cy - 65);
    ctx.font = 'bold 13px monospace';
    ctx.fillText(`₹${balance.toLocaleString()}`, atmX, cy - 45);
    ctx.fillStyle = '#bae6fd';
    ctx.font = '8px monospace';
    ctx.fillText('THREAD-SAFE MUTEX: ACTIVE', atmX, cy - 28);

    // EMV Chip Card Slot with Glowing Green Ingestion Arrow
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(atmX - 45, cy - 5, 90, 10);
    ctx.fillStyle = '#10b981';
    ctx.beginPath();
    ctx.moveTo(atmX, cy);
    ctx.lineTo(atmX - 6, cy - 4);
    ctx.lineTo(atmX + 6, cy - 4);
    ctx.closePath();
    ctx.fill();

    // Tactile Keypad with Privacy Shield
    ctx.fillStyle = '#334155';
    ctx.fillRect(atmX - 35, cy + 20, 70, 45);
    for (let kr = 0; kr < 3; kr++) {
      for (let kc = 0; kc < 3; kc++) {
        ctx.fillStyle = '#94a3b8';
        ctx.fillRect(atmX - 30 + kc * 22, cy + 24 + kr * 13, 16, 9);
      }
    }

    // Heavy Bank Vault Door with Radial Chrome Locking Bolts
    ctx.fillStyle = '#1e293b';
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(vaultX, cy, 65, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Radial locking bolts
    for (let a = 0; a < 6; a++) {
      const ang = (a / 6) * Math.PI * 2;
      const bx = vaultX + Math.cos(ang) * 65;
      const by = cy + Math.sin(ang) * 65;
      ctx.fillStyle = '#cbd5e1';
      ctx.beginPath();
      ctx.arc(bx, by, 7, 0, Math.PI * 2);
      ctx.fill();
    }

    // Rotating Precision Combination Dial
    ctx.save();
    ctx.translate(vaultX, cy);
    ctx.rotate(t * 0.6);
    ctx.fillStyle = '#0f172a';
    ctx.strokeStyle = '#fbbf24';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 0, 24, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, -24);
    ctx.lineTo(0, -14);
    ctx.stroke();
    ctx.restore();
  };

  // EXP 3: 6-Axis Industrial Assembly Robot & Laser Inspection Station (Student Object Foundry)
  const renderOopmExp3 = (ctx: CanvasRenderingContext2D, width: number, height: number, frame: number, t: number) => {
    const robotBaseX = width * 0.3;
    const robotBaseY = height - 50;
    const count = gameState.studentInstanceCount ?? 1;

    // Heavy Industrial Robot Base Pedestal
    ctx.fillStyle = '#1e293b';
    ctx.strokeStyle = '#64748b';
    ctx.lineWidth = 2;
    ctx.fillRect(robotBaseX - 30, robotBaseY - 15, 60, 25);

    // Articulated Robot Arm Joints (Kinematic simulation)
    const arm1Angle = -Math.PI * 0.35 + Math.sin(t * 2) * 0.15;
    const arm1Len = 65;
    const j1X = robotBaseX;
    const j1Y = robotBaseY - 15;
    const j2X = j1X + Math.cos(arm1Angle) * arm1Len;
    const j2Y = j1Y + Math.sin(arm1Angle) * arm1Len;

    const arm2Angle = Math.PI * 0.45 + Math.cos(t * 2) * 0.12;
    const arm2Len = 55;
    const endX = j2X + Math.cos(arm2Angle) * arm2Len;
    const endY = j2Y + Math.sin(arm2Angle) * arm2Len;

    // Arm Link 1
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.moveTo(j1X, j1Y);
    ctx.lineTo(j2X, j2Y);
    ctx.stroke();
    ctx.fillStyle = '#334155';
    ctx.beginPath();
    ctx.arc(j2X, j2Y, 7, 0, Math.PI * 2);
    ctx.fill();

    // Arm Link 2
    ctx.strokeStyle = '#d97706';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(j2X, j2Y);
    ctx.lineTo(endX, endY);
    ctx.stroke();

    // Red Laser Profiler Beam sweeping down onto assembly line
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.6)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(endX, endY);
    ctx.lineTo(endX - 25, height - 55);
    ctx.moveTo(endX, endY);
    ctx.lineTo(endX + 25, height - 55);
    ctx.stroke();

    // Industrial Conveyor Belt
    const conveyorY = height - 50;
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(width * 0.5, conveyorY, width * 0.45, 14);

    // Stamped Student Object Blocks traveling along belt
    for (let i = 0; i < Math.min(count, 5); i++) {
      const bx = width * 0.55 + i * 55;
      ctx.fillStyle = '#0284c7';
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(bx - 20, conveyorY - 26, 40, 26, 4);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 8px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(`STD_${i + 1}`, bx, conveyorY - 10);
    }
  };

  // EXP 4: Hospital ICU 12-Lead ECG Patient Monitor & Spectrometer (Medical Polymorphism)
  const renderOopmExp4 = (ctx: CanvasRenderingContext2D, width: number, height: number, frame: number, t: number) => {
    const monitorX = width * 0.5;
    const monitorY = height * 0.48;

    // Medical Monitor Chassis (Matte Hospital White / Medical Bezel)
    ctx.fillStyle = '#0f172a';
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.roundRect(monitorX - 240, monitorY - 110, 480, 220, 10);
    ctx.fill();
    ctx.stroke();

    // Realistic Green Phosphor ECG Tracing (P-QRS-T complex)
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 2;
    ctx.beginPath();
    const ecgStartX = monitorX - 220;
    const ecgW = 320;
    const baseY = monitorY - 20;

    for (let x = 0; x < ecgW; x += 3) {
      const phase = (x - (frame * 3) % ecgW + ecgW) % ecgW;
      let yOffset = 0;
      if (phase > 80 && phase < 95) {
        yOffset = -Math.sin(((phase - 80) / 15) * Math.PI) * 10; // P wave
      } else if (phase >= 100 && phase < 105) {
        yOffset = 8; // Q wave
      } else if (phase >= 105 && phase < 115) {
        yOffset = -45; // R peak
      } else if (phase >= 115 && phase < 120) {
        yOffset = 16; // S dip
      } else if (phase >= 135 && phase < 160) {
        yOffset = -Math.sin(((phase - 135) / 25) * Math.PI) * 16; // T wave
      }
      if (x === 0) ctx.moveTo(ecgStartX + x, baseY + yOffset);
      else ctx.lineTo(ecgStartX + x, baseY + yOffset);
    }
    ctx.stroke();

    // Telemetry Vitals Readout Side Panel
    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 20px monospace';
    ctx.textAlign = 'left';
    ctx.fillText('72', monitorX + 130, monitorY - 60);
    ctx.font = '9px monospace';
    ctx.fillText('HR (BPM)', monitorX + 130, monitorY - 45);

    ctx.fillStyle = '#10b981';
    ctx.font = 'bold 18px monospace';
    ctx.fillText('99%', monitorX + 130, monitorY - 10);
    ctx.font = '9px monospace';
    ctx.fillText('SpO2', monitorX + 130, monitorY + 5);

    ctx.fillStyle = '#f59e0b';
    ctx.font = 'bold 16px monospace';
    ctx.fillText('120/80', monitorX + 130, monitorY + 40);
    ctx.font = '9px monospace';
    ctx.fillText('NIBP mmHg', monitorX + 130, monitorY + 55);

    ctx.fillStyle = '#94a3b8';
    ctx.font = 'bold 10px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(`POLYMORPHIC DISPATCH: calculateRisk() → ${gameState.activeMedicalTest?.toUpperCase() || 'CARDIAC'}`, monitorX, monitorY + 95);
  };

  // EXP 5: Military Doppler Weather Radar PPI Scope (Interface Weather Mesh)
  const renderOopmExp5 = (ctx: CanvasRenderingContext2D, width: number, height: number, frame: number, t: number) => {
    const radarX = width * 0.5;
    const radarY = height * 0.5;
    const radius = 95;

    // Circular Radar Plan Position Indicator (PPI) Scope
    ctx.fillStyle = '#022c22';
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(radarX, radarY, radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Range rings (10km, 25km, 50km)
    for (let r = 1; r <= 3; r++) {
      ctx.strokeStyle = 'rgba(16, 185, 129, 0.3)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(radarX, radarY, (radius / 3) * r, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Rotating 360-Degree Phased Array Sweep Beam
    const sweepAngle = t * 2.5;
    const beamGrad = ctx.createRadialGradient(radarX, radarY, 0, radarX, radarY, radius);
    beamGrad.addColorStop(0, 'rgba(52, 211, 153, 0.4)');
    beamGrad.addColorStop(1, 'rgba(52, 211, 153, 0)');

    ctx.save();
    ctx.beginPath();
    ctx.moveTo(radarX, radarY);
    ctx.arc(radarX, radarY, radius, sweepAngle - 0.4, sweepAngle);
    ctx.closePath();
    ctx.fillStyle = beamGrad;
    ctx.fill();
    ctx.restore();

    // Doppler Storm Cell Reflectivity Blobs
    ctx.fillStyle = 'rgba(239, 68, 68, 0.7)';
    ctx.beginPath();
    ctx.arc(radarX + 45, radarY - 35, 12, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(245, 158, 11, 0.8)';
    ctx.beginPath();
    ctx.arc(radarX + 40, radarY - 30, 8, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#34d399';
    ctx.font = '9px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('AZ: 284° | WIND: 32 KTS | BARO: 1012 hPa', radarX, radarY + radius + 20);
  };

  // EXP 6: High-Voltage Magnetohydrodynamic Containment Chamber (Exception Shield)
  const renderOopmExp6 = (ctx: CanvasRenderingContext2D, width: number, height: number, frame: number, t: number) => {
    const cx = width * 0.5;
    const cy = height * 0.5;

    // Heavy Faraday Cage Ring
    ctx.strokeStyle = '#64748b';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(cx, cy, 90, 0, Math.PI * 2);
    ctx.stroke();

    // High-Frequency Tesla Coil Electric Arcs (Realistic branching lightning)
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.5;
    for (let a = 0; a < 5; a++) {
      const ang = (a / 5) * Math.PI * 2 + t;
      let currX = cx;
      let currY = cy;
      ctx.beginPath();
      ctx.moveTo(currX, currY);
      for (let s = 0; s < 4; s++) {
        currX += Math.cos(ang) * 22 + (Math.random() - 0.5) * 12;
        currY += Math.sin(ang) * 22 + (Math.random() - 0.5) * 12;
        ctx.lineTo(currX, currY);
      }
      ctx.stroke();
    }

    // Try-Catch Hexagonal Core
    ctx.fillStyle = '#0f172a';
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 3;
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
      const hAng = (i / 6) * Math.PI * 2;
      const hx = cx + Math.cos(hAng) * 45;
      const hy = cy + Math.sin(hAng) * 45;
      if (i === 0) ctx.moveTo(hx, hy);
      else ctx.lineTo(hx, hy);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 10px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('TRY-CATCH', cx, cy - 4);
    ctx.fillStyle = '#10b981';
    ctx.font = '8px monospace';
    ctx.fillText('SHIELD ARMED', cx, cy + 12);
  };

  // EXP 7: Disassembled Enterprise Hard Disk Drive (Disk Archivist)
  const renderOopmExp7 = (ctx: CanvasRenderingContext2D, width: number, height: number, frame: number, t: number) => {
    const platterX = width * 0.42;
    const platterY = height * 0.5;
    const pRadius = 85;

    // HDD Cast Aluminum Chassis
    ctx.fillStyle = '#1e293b';
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.roundRect(width * 0.22, height * 0.15, width * 0.56, height * 0.7, 12);
    ctx.fill();
    ctx.stroke();

    // Mirror-Polished Aluminum Magnetic Platter spinning at 15,000 RPM
    ctx.save();
    ctx.translate(platterX, platterY);
    ctx.rotate(t * 12);
    const platterGrad = ctx.createRadialGradient(0, 0, 10, 0, 0, pRadius);
    platterGrad.addColorStop(0, '#94a3b8');
    platterGrad.addColorStop(0.5, '#f8fafc');
    platterGrad.addColorStop(1, '#64748b');
    ctx.fillStyle = platterGrad;
    ctx.beginPath();
    ctx.arc(0, 0, pRadius, 0, Math.PI * 2);
    ctx.fill();

    // Concentric Magnetic Track Reflections
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
    ctx.lineWidth = 1;
    for (let r = 25; r < pRadius; r += 12) {
      ctx.beginPath();
      ctx.arc(0, 0, r, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();

    // Voice Coil Motor (VCM) Actuator Arm Sweeping across Tracks
    const vcmPivotX = width * 0.68;
    const vcmPivotY = height * 0.5;
    const armSweep = Math.sin(t * 3) * 0.25;

    ctx.fillStyle = '#0f172a';
    ctx.beginPath();
    ctx.arc(vcmPivotX, vcmPivotY, 18, 0, Math.PI * 2);
    ctx.fill();

    const headX = vcmPivotX - Math.cos(armSweep) * 110;
    const headY = vcmPivotY - Math.sin(armSweep) * 110;

    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(vcmPivotX, vcmPivotY);
    ctx.lineTo(headX, headY);
    ctx.stroke();

    // Aerodynamic Slider Read/Write Head
    ctx.fillStyle = '#ef4444';
    ctx.fillRect(headX - 4, headY - 4, 8, 8);
  };

  // EXP 8: Multi-Core Server Processor Die (Multithreading Tri-Core)
  const renderOopmExp8 = (ctx: CanvasRenderingContext2D, width: number, height: number, frame: number, t: number) => {
    const cores = ['THREAD-A', 'THREAD-B', 'THREAD-C'];
    const cy = height * 0.5;

    cores.forEach((core, idx) => {
      const cx = width * 0.25 + idx * (width * 0.25);
      const isWorking = ((Math.floor(frame * 0.1) + idx) % 3) === 0;

      ctx.fillStyle = '#0f172a';
      ctx.strokeStyle = isWorking ? '#38bdf8' : '#64748b';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(cx - 50, cy - 65, 100, 130, 8);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 11px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(core, cx, cy - 35);

      // Core Load Meter
      const load = 40 + Math.sin(t * 4 + idx) * 35;
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(cx - 35, cy, 70, 14);
      ctx.fillStyle = isWorking ? '#10b981' : '#38bdf8';
      ctx.fillRect(cx - 35, cy, (70 * load) / 100, 14);

      ctx.fillStyle = '#94a3b8';
      ctx.font = '8px monospace';
      ctx.fillText(`FREQ: ${(3.8 + idx * 0.2).toFixed(1)} GHz`, cx, cy + 35);
      ctx.fillText(`LOAD: ${Math.round(load)}%`, cx, cy + 50);
    });
  };

  // EXP 9: 42U Datacenter Server Rack & Modular Backplane (Package Library)
  const renderOopmExp9 = (ctx: CanvasRenderingContext2D, width: number, height: number, frame: number, t: number) => {
    const rackX = width * 0.5;
    const rackY = height * 0.5;

    ctx.fillStyle = '#0f172a';
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.roundRect(rackX - 160, rackY - 110, 320, 220, 6);
    ctx.fill();
    ctx.stroke();

    // 4x 2U Server Blades
    for (let u = 0; u < 4; u++) {
      const uy = rackY - 85 + u * 45;
      ctx.fillStyle = '#1e293b';
      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(rackX - 145, uy, 290, 36, 4);
      ctx.fill();
      ctx.stroke();

      // RJ45 Port Activity LEDs
      for (let p = 0; p < 8; p++) {
        const isBlinking = ((frame + p * 3 + u * 7) % 12) < 6;
        ctx.fillStyle = isBlinking ? '#10b981' : '#065f46';
        ctx.beginPath();
        ctx.arc(rackX - 120 + p * 12, uy + 18, 2, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 9px monospace';
      ctx.textAlign = 'right';
      ctx.fillText(`PKG.SOMAIYA.MOD_${u + 1}`, rackX + 130, uy + 22);
    }
  };

  // EXP 10: Realistic Indian Railways WAP-7 Class Heavy Electric Locomotive (Mutex Booking)
  const renderOopmExp10 = (ctx: CanvasRenderingContext2D, width: number, height: number, frame: number, t: number) => {
    const trackY = height - 60;
    const trainX = ((frame * 2.8) % (width + 300)) - 150;
    const berths = gameState.trainBerths ?? 42;

    // Crushed Stone Ballast Railway Bed
    ctx.fillStyle = '#334155';
    ctx.fillRect(0, trackY, width, 40);

    // Concrete Sleepers
    for (let sx = 0; sx < width; sx += 22) {
      ctx.fillStyle = '#64748b';
      ctx.fillRect(sx, trackY, 8, 20);
    }

    // Steel Rails (Continuous welded rail with metallic sheen)
    ctx.fillStyle = '#cbd5e1';
    ctx.fillRect(0, trackY + 2, width, 4);

    // 25kV AC Overhead Catenary Wire
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, 45);
    ctx.lineTo(width, 45);
    ctx.stroke();

    // WAP-7 Locomotive Body (Realistic Aerodynamic Cab)
    ctx.fillStyle = '#dc2626'; // High-visibility red livery
    ctx.beginPath();
    ctx.moveTo(trainX - 90, trackY - 65);
    ctx.lineTo(trainX + 80, trackY - 65);
    ctx.lineTo(trainX + 110, trackY - 15);
    ctx.lineTo(trainX - 90, trackY - 15);
    ctx.closePath();
    ctx.fill();

    // White Racing Stripe
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(trainX - 90, trackY - 35, 195, 6);

    // Pantograph drawing from catenary wire
    ctx.strokeStyle = '#f8fafc';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(trainX, trackY - 65);
    ctx.lineTo(trainX - 15, 45);
    ctx.lineTo(trainX + 15, 45);
    ctx.stroke();

    // Electrical Pantograph Sparks
    if (Math.sin(t * 15) > 0.6) {
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(trainX, 45, 3.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // Heavy Cast Steel Bogie Wheels (Rotating realistically)
    [-60, -35, 35, 60].forEach((wx) => {
      ctx.save();
      ctx.translate(trainX + wx, trackY - 2);
      ctx.rotate(t * 12);
      ctx.fillStyle = '#0f172a';
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 0, 11, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(-11, 0);
      ctx.lineTo(11, 0);
      ctx.stroke();
      ctx.restore();
    });

    // High-Intensity Twin-Beam Headlight projecting beam
    ctx.fillStyle = 'rgba(254, 240, 138, 0.25)';
    ctx.beginPath();
    ctx.moveTo(trainX + 105, trackY - 35);
    ctx.lineTo(trainX + 320, trackY - 75);
    ctx.lineTo(trainX + 320, trackY + 15);
    ctx.closePath();
    ctx.fill();

    // Indian Railways Somaiya Express HUD & Semaphore
    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 11px monospace';
    ctx.textAlign = 'left';
    ctx.fillText(`IR WAP-7 #30248 · SOMAIYA EXPRESS (MUTEX SAFE)`, 16, 28);
    ctx.fillStyle = '#10b981';
    ctx.fillText(`AVAILABLE BERTHS: ${berths} (SYNCHRONIZED)`, 16, 42);
  };

  const toggleSound = () => {
    const next = gameAudio.toggleMute();
    setIsMuted(next);
  };

  return (
    <div className="rounded-2xl overflow-hidden border border-zinc-800 bg-zinc-950 shadow-2xl relative font-sans">
      {/* 2D Realistic Simulation Canvas */}
      <canvas
        ref={canvasRef}
        width={720}
        height={340}
        className="w-full h-[280px] sm:h-[340px] block"
      />

      {/* Floating Clean HUD Header */}
      <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none z-10">
        <span className="px-2.5 py-1 bg-zinc-950/80 backdrop-blur-md rounded-lg text-xs font-mono font-bold text-zinc-300 border border-zinc-800 flex items-center gap-2 shadow-sm">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>2D SIMULATION ACTIVE (PHYSICS 60FPS)</span>
        </span>

        <button
          onClick={toggleSound}
          className="p-1.5 rounded-lg bg-zinc-900/90 hover:bg-zinc-800 text-zinc-300 transition-colors cursor-pointer pointer-events-auto border border-zinc-750 backdrop-blur-md"
          title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
        >
          {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* Turn-by-Turn Playback Controls */}
      <div className="px-4 py-3 bg-zinc-900 border-t border-zinc-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="px-3.5 py-1.5 bg-white hover:bg-zinc-200 text-zinc-950 rounded-lg text-xs font-mono font-bold flex items-center gap-1.5 cursor-pointer shadow-sm transition-colors"
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current" />}
            <span>{isPlaying ? 'PAUSE MOTION' : 'RESUME MOTION'}</span>
          </button>

          <button
            onClick={() => onAction && onAction('step_back')}
            className="p-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-lg text-xs cursor-pointer transition-colors border border-zinc-700"
            title="Step Backward"
          >
            <SkipBack className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => onAction && onAction('step_forward')}
            className="p-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-lg text-xs cursor-pointer transition-colors border border-zinc-700"
            title="Step Forward"
          >
            <SkipForward className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => onAction && onAction('reset')}
            className="p-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-lg text-xs cursor-pointer transition-colors border border-zinc-700"
            title="Reset Simulation"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Speed Selector */}
        <div className="flex items-center gap-1.5 text-xs font-mono text-zinc-400">
          <span>CLOCK:</span>
          {[0.5, 1, 2, 4].map((s) => (
            <button
              key={s}
              onClick={() => setPlaybackSpeed(s)}
              className={`px-2 py-0.5 rounded text-xs transition-colors cursor-pointer font-mono ${
                playbackSpeed === s ? 'bg-zinc-200 text-zinc-950 font-bold' : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700 hover:text-zinc-200'
              }`}
            >
              {s}x
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
