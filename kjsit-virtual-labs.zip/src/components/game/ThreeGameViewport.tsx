import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import {
  RotateCcw,
  Maximize2,
  Minimize2,
  Eye,
  Sparkles,
  HelpCircle,
  Compass,
  Play,
  Flame,
  Zap,
  RefreshCw
} from 'lucide-react';
import { gameAudio } from '../../utils/gameAudio';

interface ThreeGameViewportProps {
  experimentId: string;
  levelData: any;
  gameState: {
    stackItems?: string[];
    doorOpen?: boolean;
    queueItems?: string[];
    departedPlanes?: string[];
    asteroidHp?: number;
    cannonAngle?: number;
    laserFired?: boolean;
    bossHp?: number;
    sortBoxes?: number[];
    activeComparingIndices?: [number, number] | null;
    visitedNodes?: string[];
    message?: string;
  };
  onAction?: (actionType: string, payload?: any) => void;
}

export const ThreeGameViewport: React.FC<ThreeGameViewportProps> = ({
  experimentId,
  levelData,
  gameState,
  onAction
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [autoRotate, setAutoRotate] = useState(true);
  const [wireframe, setWireframe] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // References for Three.js objects
  const autoRotateRef = useRef(true);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const dynamicGroupRef = useRef<THREE.Group | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const isDraggingRef = useRef(false);
  const prevMouseRef = useRef({ x: 0, y: 0 });
  const cameraRotRef = useRef({ theta: 0.8, phi: 0.6, radius: 18 });

  // Sync autoRotate state with ref
  useEffect(() => {
    autoRotateRef.current = autoRotate;
  }, [autoRotate]);

  // Init Three.js Scene
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x090d16);
    scene.fog = new THREE.FogExp2(0x090d16, 0.035);
    sceneRef.current = scene;

    // 2. Camera
    const aspect = container.clientWidth / container.clientHeight;
    const camera = new THREE.PerspectiveCamera(45, aspect, 0.1, 100);
    cameraRef.current = camera;
    updateCameraPosition();

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 4. Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight.position.set(12, 20, 15);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    scene.add(dirLight);

    const coloredLight = new THREE.PointLight(0xef4444, 1.5, 30);
    coloredLight.position.set(-8, 6, -8);
    scene.add(coloredLight);

    const cyanLight = new THREE.PointLight(0x06b6d4, 1.5, 30);
    cyanLight.position.set(8, 6, 8);
    scene.add(cyanLight);

    // 5. Ground Grid
    const gridHelper = new THREE.GridHelper(30, 30, 0xef4444, 0x1e293b);
    gridHelper.position.y = -0.01;
    scene.add(gridHelper);

    // Ground reflective floor
    const floorGeo = new THREE.PlaneGeometry(40, 40);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.8,
      metalness: 0.2
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    scene.add(floor);

    // 6. Dynamic Objects Container
    const dynamicGroup = new THREE.Group();
    scene.add(dynamicGroup);
    dynamicGroupRef.current = dynamicGroup;

    // Mouse drag handlers for Orbiting
    const handleMouseDown = (e: MouseEvent) => {
      isDraggingRef.current = true;
      prevMouseRef.current = { x: e.clientX, y: e.clientY };
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!isDraggingRef.current) return;
      const deltaX = e.clientX - prevMouseRef.current.x;
      const deltaY = e.clientY - prevMouseRef.current.y;
      prevMouseRef.current = { x: e.clientX, y: e.clientY };

      cameraRotRef.current.theta -= deltaX * 0.008;
      cameraRotRef.current.phi = Math.max(0.1, Math.min(Math.PI / 2 - 0.05, cameraRotRef.current.phi - deltaY * 0.008));
      updateCameraPosition();
    };

    const handleMouseUp = () => {
      isDraggingRef.current = false;
    };

    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      cameraRotRef.current.radius = Math.max(8, Math.min(32, cameraRotRef.current.radius + e.deltaY * 0.02));
      updateCameraPosition();
    };

    const domElement = renderer.domElement;
    domElement.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    domElement.addEventListener('wheel', handleWheel, { passive: false });

    // Window resize
    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    // Animation Loop
    const clock = new THREE.Clock();
    const animate = () => {
      animFrameRef.current = requestAnimationFrame(animate);
      const delta = Math.min(clock.getDelta(), 0.08);
      const time = clock.getElapsedTime();

      // Smooth cinematic continuous camera rotation if enabled
      if (autoRotateRef.current && !isDraggingRef.current) {
        cameraRotRef.current.theta += delta * 0.22;
        updateCameraPosition();
      }

      // Continuous dynamic recursive animation traversal across all 3D scene objects
      if (dynamicGroupRef.current) {
        dynamicGroupRef.current.traverse((child) => {
          // 1. Custom scene animation callback
          if (child.userData?.animate) {
            child.userData.animate(time, delta, child);
          }

          // 2. Continuous 3D rotation
          if (child.userData?.isRotating) {
            const speed = child.userData.rotateSpeed ?? 0.8;
            if (child.userData.rotateAxis === 'z') {
              child.rotation.z += delta * speed;
            } else if (child.userData.rotateAxis === 'x') {
              child.rotation.x += delta * speed;
            } else {
              child.rotation.y += delta * speed;
            }
          }

          // 3. Smooth harmonic floating/bobbing (sine wave hovering)
          if (child.userData?.isBobbing) {
            if (child.userData.baseY === undefined) {
              child.userData.baseY = child.position.y;
            }
            const speed = child.userData.bobSpeed ?? 2.4;
            const amp = child.userData.bobAmp ?? 0.22;
            const offset = child.userData.bobOffset ?? 0;
            child.position.y = child.userData.baseY + Math.sin(time * speed + offset) * amp;
          }

          // 4. Glowing energy pulsation
          if (child.userData?.isPulsing) {
            const mat = (child as THREE.Mesh).material as THREE.MeshStandardMaterial;
            if (mat && mat.emissiveIntensity !== undefined) {
              const speed = child.userData.pulseSpeed ?? 3.2;
              const minInt = child.userData.minIntensity ?? 0.3;
              const maxInt = child.userData.maxIntensity ?? 1.2;
              mat.emissiveIntensity = minInt + (Math.sin(time * speed + (child.userData.pulseOffset ?? 0)) * 0.5 + 0.5) * (maxInt - minInt);
            }
          }
        });
      }

      renderer.render(scene, camera);
    };
    animate();

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      domElement.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      domElement.removeEventListener('wheel', handleWheel);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, []);

  useEffect(() => {
    autoRotateRef.current = autoRotate;
  }, [autoRotate]);

  const updateCameraPosition = () => {
    if (!cameraRef.current) return;
    const { theta, phi, radius } = cameraRotRef.current;
    const x = radius * Math.sin(phi) * Math.cos(theta);
    const y = radius * Math.cos(phi);
    const z = radius * Math.sin(phi) * Math.sin(theta);
    cameraRef.current.position.set(x, y, z);
    cameraRef.current.lookAt(0, 2, 0);
  };

  const handleResetCamera = () => {
    cameraRotRef.current = { theta: 0.8, phi: 0.6, radius: 18 };
    updateCameraPosition();
  };

  // Re-build 3D objects whenever experimentId or gameState updates
  useEffect(() => {
    const group = dynamicGroupRef.current;
    if (!group) return;

    // Clear previous dynamic meshes
    while (group.children.length > 0) {
      const obj = group.children[0];
      group.remove(obj);
      if ((obj as THREE.Mesh).geometry) (obj as THREE.Mesh).geometry.dispose();
    }

    // Build specific 3D Game World
    if (experimentId.includes('stack')) {
      buildStackDungeon3D(group, gameState);
    } else if (experimentId.includes('queue')) {
      buildQueueRunway3D(group, gameState);
    } else if (experimentId.includes('infix')) {
      buildAsteroidBlaster3D(group, gameState);
    } else if (experimentId.includes('polynomial')) {
      buildSpellAlchemy3D(group, gameState);
    } else if (experimentId.includes('binary-tree') || experimentId.includes('traversal')) {
      buildWorldTree3D(group, gameState);
    } else if (experimentId.includes('binary-search-tree')) {
      buildBstVault3D(group, gameState);
    } else if (experimentId.includes('graph')) {
      buildCyberMatrix3D(group, gameState);
    } else if (experimentId === 'selection-sort') {
      buildSelectionWeather3D(group, gameState);
    } else if (experimentId === 'insertion-sort') {
      buildInsertionMoisture3D(group, gameState);
    } else if (experimentId === 'merge-sort') {
      buildMergeVillage3D(group, gameState);
    } else if (experimentId === 'quick-sort') {
      buildQuickHeatwave3D(group, gameState);
    } else if (experimentId === 'kruskals') {
      buildKruskalSensor3D(group, gameState);
    } else if (experimentId === 'tsp') {
      buildTspTour3D(group, gameState);
    } else if (experimentId === 'n-queen') {
      buildNQueenMatrix3D(group, gameState);
    } else if (experimentId === 'sum-of-subsets') {
      buildSubsetsVault3D(group, gameState);
    } else if (experimentId === 'kmp') {
      buildKmpScanner3D(group, gameState);
    } else if (experimentId === 'oopm-exp1') {
      buildTerminalGateway3D(group, gameState);
    } else if (experimentId === 'oopm-exp2') {
      buildAtmMachine3D(group, gameState);
    } else if (experimentId === 'oopm-exp3' || experimentId === 'oopm-exp4') {
      buildObjectFoundry3D(group, gameState);
    } else if (experimentId === 'oopm-exp5') {
      buildMedicalPolymorphism3D(group, gameState);
    } else if (experimentId === 'oopm-exp6') {
      buildInterfaceWeather3D(group, gameState);
    } else if (experimentId === 'oopm-exp7') {
      buildExceptionShield3D(group, gameState);
    } else if (experimentId === 'oopm-exp8') {
      buildDiskArchivist3D(group, gameState);
    } else if (experimentId === 'oopm-exp9') {
      buildThreadTriCore3D(group, gameState);
    } else if (experimentId === 'oopm-exp10') {
      buildMutexTrain3D(group, gameState);
    } else if (experimentId.includes('sorting')) {
      buildCargoCrane3D(group, gameState);
    } else {
      buildDefaultGame3D(group, gameState);
    }
  }, [experimentId, gameState, wireframe]);

  // =========================================================================
  // 3D SCENE BUILDERS
  // =========================================================================

  // 1. Stack ADT: 3D Dungeon Vault Altar
  const buildStackDungeon3D = (group: THREE.Group, state: any) => {
    // Altar pedestal
    const altarGeo = new THREE.CylinderGeometry(2.5, 3, 1, 16);
    const altarMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.3, wireframe });
    const altar = new THREE.Mesh(altarGeo, altarMat);
    altar.position.set(0, 0.5, 0);
    altar.receiveShadow = true;
    group.add(altar);

    // Stone Pillars around
    const pillarPositions = [
      [-6, 0, -6],
      [6, 0, -6],
      [-6, 0, 6],
      [6, 0, 6]
    ];
    pillarPositions.forEach(([px, py, pz]) => {
      const pillarGeo = new THREE.CylinderGeometry(0.6, 0.8, 8, 12);
      const pillarMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.9, wireframe });
      const pillar = new THREE.Mesh(pillarGeo, pillarMat);
      pillar.position.set(px, 4, pz);
      pillar.castShadow = true;
      group.add(pillar);

      // Glowing crystal on top
      const torchGeo = new THREE.OctahedronGeometry(0.4, 0);
      const torchMat = new THREE.MeshStandardMaterial({
        color: 0xef4444,
        emissive: 0xef4444,
        emissiveIntensity: 0.9,
        wireframe
      });
      const torch = new THREE.Mesh(torchGeo, torchMat);
      torch.position.set(px, 8.4, pz);
      torch.userData = {
        isRotating: true,
        rotateSpeed: 1.4,
        isPulsing: true,
        pulseSpeed: 3.5,
        pulseOffset: py,
        minIntensity: 0.6,
        maxIntensity: 1.6
      };
      group.add(torch);
    });

    // 3D Portcullis Vault Door (smooth animated opening/closing)
    const doorGroup = new THREE.Group();
    doorGroup.position.set(0, state.doorOpen ? 5.5 : 0, -8);
    const gateFrameGeo = new THREE.BoxGeometry(6, 6, 0.4);
    const gateFrameMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.7, wireframe });
    const gateFrame = new THREE.Mesh(gateFrameGeo, gateFrameMat);
    gateFrame.position.y = 3;
    doorGroup.add(gateFrame);

    // Iron bars
    for (let bx = -2.4; bx <= 2.4; bx += 0.6) {
      const barGeo = new THREE.CylinderGeometry(0.08, 0.08, 5.8, 8);
      const barMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9, wireframe });
      const bar = new THREE.Mesh(barGeo, barMat);
      bar.position.set(bx, 3, 0);
      doorGroup.add(bar);
    }
    doorGroup.userData = {
      animate: (time: number, delta: number) => {
        const targetY = state.doorOpen ? 5.5 : 0;
        doorGroup.position.y += (targetY - doorGroup.position.y) * 0.08;
      }
    };
    group.add(doorGroup);

    // 3D Hero Wizard with live breathing & staff waving
    const wizardGroup = new THREE.Group();
    wizardGroup.position.set(-3.5, 0, 3.5);
    // Robe
    const robeGeo = new THREE.ConeGeometry(0.7, 2, 12);
    const robeMat = new THREE.MeshStandardMaterial({ color: 0x2563eb, roughness: 0.5, wireframe });
    const robe = new THREE.Mesh(robeGeo, robeMat);
    robe.position.y = 1;
    wizardGroup.add(robe);
    // Wizard Hat
    const hatGeo = new THREE.ConeGeometry(0.6, 1.2, 8);
    const hatMat = new THREE.MeshStandardMaterial({ color: 0x1e3a8a, wireframe });
    const hat = new THREE.Mesh(hatGeo, hatMat);
    hat.position.y = 2.4;
    wizardGroup.add(hat);
    // Staff
    const staffGeo = new THREE.CylinderGeometry(0.05, 0.05, 2.5, 8);
    const staffMat = new THREE.MeshStandardMaterial({ color: 0x78350f, wireframe });
    const staff = new THREE.Mesh(staffGeo, staffMat);
    staff.position.set(0.6, 1.25, 0.2);
    wizardGroup.add(staff);
    // Staff glowing orb
    const orbGeo = new THREE.SphereGeometry(0.2, 12, 12);
    const orbMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x38bdf8,
      emissiveIntensity: 1.2,
      wireframe
    });
    const orb = new THREE.Mesh(orbGeo, orbMat);
    orb.position.set(0.6, 2.5, 0.2);
    wizardGroup.add(orb);

    wizardGroup.userData = {
      animate: (time: number) => {
        // Continuous breathing and staff waving
        wizardGroup.position.y = Math.sin(time * 2.2) * 0.12;
        staff.rotation.z = Math.sin(time * 2.6) * 0.15;
        orb.scale.setScalar(1 + Math.sin(time * 4) * 0.2);
        orbMat.emissiveIntensity = 0.8 + Math.sin(time * 6) * 0.5;
      }
    };
    group.add(wizardGroup);

    // Dynamic Pulsing Spell Energy Beam (Shooting from wizard staff to stack altar)
    const beamGeo = new THREE.CylinderGeometry(0.04, 0.08, 4.5, 8);
    const beamMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      emissiveIntensity: 1.0,
      transparent: true,
      opacity: 0.7,
      wireframe
    });
    const spellBeam = new THREE.Mesh(beamGeo, beamMat);
    spellBeam.position.set(-1.75, 2.3, 1.75);
    spellBeam.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(3.5, -0.6, -3.5).normalize());
    spellBeam.userData = {
      animate: (time: number) => {
        beamMat.opacity = 0.4 + Math.sin(time * 8) * 0.35;
        spellBeam.scale.x = 1 + Math.sin(time * 12) * 0.25;
        spellBeam.scale.z = spellBeam.scale.x;
      }
    };
    group.add(spellBeam);

    // 3D Stacked Rune Blocks
    const items = state.stackItems || ['(', '[', '{'];
    const colors = [0xef4444, 0xf59e0b, 0x10b981, 0x3b82f6, 0x8b5cf6, 0xec4899];

    items.forEach((item: string, idx: number) => {
      const isTop = idx === items.length - 1;
      const blockGeo = new THREE.BoxGeometry(1.8, 0.6, 1.8);
      const color = colors[idx % colors.length];
      const blockMat = new THREE.MeshStandardMaterial({
        color,
        emissive: color,
        emissiveIntensity: isTop ? 0.7 : 0.35,
        roughness: 0.2,
        metalness: 0.6,
        wireframe
      });
      const block = new THREE.Mesh(blockGeo, blockMat);
      const baseY = 1.3 + idx * 0.7;
      block.position.set(0, baseY, 0);
      block.castShadow = true;
      block.receiveShadow = true;

      // Top block levitates and hovers with a magic halo
      if (isTop) {
        block.userData = {
          isBobbing: true,
          bobSpeed: 2.5,
          bobAmp: 0.2,
          isRotating: true,
          rotateSpeed: 0.6,
          isPulsing: true,
          pulseSpeed: 3.5,
          minIntensity: 0.5,
          maxIntensity: 1.1
        };

        // Rotating Magic Rune Halo Ring
        const halo = new THREE.Mesh(
          new THREE.TorusGeometry(1.5, 0.05, 12, 32),
          new THREE.MeshStandardMaterial({
            color,
            emissive: color,
            emissiveIntensity: 1.0,
            wireframe
          })
        );
        halo.position.set(0, baseY, 0);
        halo.rotation.x = Math.PI / 2;
        halo.userData = {
          isBobbing: true,
          bobSpeed: 2.5,
          bobAmp: 0.2,
          isRotating: true,
          rotateSpeed: -1.5,
          rotateAxis: 'z'
        };
        group.add(halo);
      } else {
        block.userData = {
          isPulsing: true,
          pulseSpeed: 2.0,
          pulseOffset: idx,
          minIntensity: 0.2,
          maxIntensity: 0.6
        };
      }

      group.add(block);
    });

    // Swirling Magical Rune Motes Orbiting the Altar in Real-Time
    for (let i = 0; i < 6; i++) {
      const mote = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.14, 0),
        new THREE.MeshStandardMaterial({
          color: colors[i % colors.length],
          emissive: colors[i % colors.length],
          emissiveIntensity: 1.0,
          wireframe
        })
      );
      const angleOffset = (i * Math.PI * 2) / 6;
      mote.userData = {
        animate: (time: number) => {
          const a = angleOffset + time * 1.0;
          const radius = 2.6 + Math.sin(time * 2 + i) * 0.3;
          mote.position.x = Math.cos(a) * radius;
          mote.position.z = Math.sin(a) * radius;
          mote.position.y = 1.4 + Math.sin(time * 3 + i) * 0.6;
          mote.rotation.x += 0.05;
          mote.rotation.y += 0.05;
        }
      };
      group.add(mote);
    }
  };

  // 2. Queue ADT: 3D Airport Runway ATC with Active Taking Off & Landing Dynamics
  const buildQueueRunway3D = (group: THREE.Group, state: any) => {
    // 1. Main Asphalt Runway & Parallel Taxiway
    const runwayWidth = 8;
    const runwayLength = 48;
    const runwayGeo = new THREE.BoxGeometry(runwayWidth, 0.1, runwayLength);
    const runwayMat = new THREE.MeshStandardMaterial({
      color: 0x181e29,
      roughness: 0.9,
      metalness: 0.1,
      wireframe
    });
    const runway = new THREE.Mesh(runwayGeo, runwayMat);
    runway.position.set(0, 0.05, 0);
    runway.receiveShadow = true;
    group.add(runway);

    // Parallel Taxiway
    const taxiwayGeo = new THREE.BoxGeometry(5, 0.08, runwayLength * 0.7);
    const taxiwayMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.95, wireframe });
    const taxiway = new THREE.Mesh(taxiwayGeo, taxiwayMat);
    taxiway.position.set(8.5, 0.04, -2);
    taxiway.receiveShadow = true;
    group.add(taxiway);

    // Connector Taxiway Links
    [-10, 8].forEach((cz) => {
      const linkGeo = new THREE.BoxGeometry(6, 0.08, 4);
      const link = new THREE.Mesh(linkGeo, taxiwayMat);
      link.position.set(4.5, 0.04, cz);
      group.add(link);
    });

    // Runway Centerline dashed stripes
    for (let z = -20; z <= 20; z += 3.5) {
      const stripeGeo = new THREE.PlaneGeometry(0.35, 1.8);
      const stripeMat = new THREE.MeshBasicMaterial({ color: 0xf8fafc });
      const stripe = new THREE.Mesh(stripeGeo, stripeMat);
      stripe.rotation.x = -Math.PI / 2;
      stripe.position.set(0, 0.11, z);
      group.add(stripe);
    }

    // Runway Threshold Piano Keys (White threshold bars at approach ends)
    [-21, 21].forEach((endZ) => {
      for (let k = -2.8; k <= 2.8; k += 0.8) {
        const keyGeo = new THREE.PlaneGeometry(0.45, 2.2);
        const keyMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
        const key = new THREE.Mesh(keyGeo, keyMat);
        key.rotation.x = -Math.PI / 2;
        key.position.set(k, 0.11, endZ);
        group.add(key);
      }
    });

    // Runway Edge Lights (Prism ground lights)
    [-4.2, 4.2].forEach((x) => {
      for (let z = -22; z <= 22; z += 3) {
        const isThreshold = Math.abs(z) > 19;
        const lightGeo = new THREE.SphereGeometry(0.09, 8, 8);
        const lightMat = new THREE.MeshBasicMaterial({
          color: isThreshold ? (z < 0 ? 0x10b981 : 0xef4444) : 0xfbbf24
        });
        const light = new THREE.Mesh(lightGeo, lightMat);
        light.position.set(x, 0.15, z);
        group.add(light);
      }
    });

    // Taxiway Edge Lights (Blue taxiway edge lights)
    [6.2, 11.2].forEach((tx) => {
      for (let tz = -18; tz <= 14; tz += 3.5) {
        const lightGeo = new THREE.SphereGeometry(0.07, 8, 8);
        const lightMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
        const light = new THREE.Mesh(lightGeo, lightMat);
        light.position.set(tx, 0.14, tz);
        group.add(light);
      }
    });

    // Approach Lighting Gantry (PAPI / Sequential Flashers "Rabbit Lights")
    for (let ap = 1; ap <= 6; ap++) {
      const gantryZ = -24 - ap * 3;
      const poleGeo = new THREE.CylinderGeometry(0.04, 0.04, 1.2 + ap * 0.3, 6);
      const poleMat = new THREE.MeshStandardMaterial({ color: 0x475569 });
      const pole = new THREE.Mesh(poleGeo, poleMat);
      pole.position.set(0, (1.2 + ap * 0.3) / 2, gantryZ);
      group.add(pole);

      const strobeGeo = new THREE.SphereGeometry(0.12, 8, 8);
      const strobeMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
      const strobe = new THREE.Mesh(strobeGeo, strobeMat);
      strobe.position.set(0, 1.2 + ap * 0.3, gantryZ);
      strobe.userData = {
        animate: (t: number) => {
          // Sequential running flash toward threshold
          const flashPhase = Math.floor((t * 6) % 6);
          const isFlash = flashPhase === (6 - ap);
          strobe.scale.setScalar(isFlash ? 1.8 : 0.8);
          strobeMat.color.setHex(isFlash ? 0xffffff : 0x475569);
        }
      };
      group.add(strobe);
    }

    // Airport Surveillance Radar (ASR) Tower with Rotating Dish
    const radarTower = new THREE.Group();
    radarTower.position.set(-8.5, 0, -4);
    const mastGeo = new THREE.CylinderGeometry(0.2, 0.4, 4.5, 8);
    const mastMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.8 });
    const mast = new THREE.Mesh(mastGeo, mastMat);
    mast.position.y = 2.25;
    radarTower.add(mast);

    const dishGroup = new THREE.Group();
    dishGroup.position.y = 4.6;
    const dishGeo = new THREE.CylinderGeometry(1.2, 0.2, 0.3, 16);
    const dishMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.6 });
    const dish = new THREE.Mesh(dishGeo, dishMat);
    dish.rotation.x = Math.PI / 2;
    dishGroup.add(dish);
    dishGroup.userData = {
      isRotating: true,
      rotateSpeed: 2.4,
      rotateAxis: 'y'
    };
    radarTower.add(dishGroup);
    group.add(radarTower);

    // Airport Control Tower Cab in the distance
    const towerGroup = new THREE.Group();
    towerGroup.position.set(13.5, 0, 8);
    const towerShaftGeo = new THREE.CylinderGeometry(1.2, 1.6, 9, 12);
    const towerShaftMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.8 });
    const towerShaft = new THREE.Mesh(towerShaftGeo, towerShaftMat);
    towerShaft.position.y = 4.5;
    towerGroup.add(towerShaft);

    const cabGeo = new THREE.CylinderGeometry(2.2, 1.6, 2, 12);
    const cabMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      metalness: 0.9,
      roughness: 0.1,
      transparent: true,
      opacity: 0.85
    });
    const cab = new THREE.Mesh(cabGeo, cabMat);
    cab.position.y = 9.8;
    towerGroup.add(cab);
    group.add(towerGroup);

    // =========================================================================
    // HELPER: CREATE DETAILED 3D JET AIRLINER
    // =========================================================================
    const createAirliner3D = (flightCode: string, mainColor: number, accentColor: number) => {
      const plane = new THREE.Group();

      // Fuselage Body
      const fuseGeo = new THREE.CylinderGeometry(0.35, 0.38, 3.4, 16);
      const fuseMat = new THREE.MeshStandardMaterial({
        color: mainColor,
        roughness: 0.3,
        metalness: 0.4,
        wireframe
      });
      const fuse = new THREE.Mesh(fuseGeo, fuseMat);
      fuse.rotation.x = Math.PI / 2;
      fuse.castShadow = true;
      plane.add(fuse);

      // Aerodynamic Nose Radome
      const noseGeo = new THREE.ConeGeometry(0.35, 0.9, 16);
      const noseMat = new THREE.MeshStandardMaterial({ color: accentColor, roughness: 0.4 });
      const nose = new THREE.Mesh(noseGeo, noseMat);
      nose.rotation.x = -Math.PI / 2;
      nose.position.set(0, 0, 2.1);
      plane.add(nose);

      // Cockpit Windshield (Tinted glass visor)
      const windGeo = new THREE.BoxGeometry(0.48, 0.16, 0.35);
      const windMat = new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.1, metalness: 0.9 });
      const wind = new THREE.Mesh(windGeo, windMat);
      wind.position.set(0, 0.22, 1.65);
      plane.add(wind);

      // Swept Wings with Dihedral
      const wingGroup = new THREE.Group();
      wingGroup.position.set(0, -0.05, 0.2);

      const leftWingGeo = new THREE.BoxGeometry(2.2, 0.06, 0.9);
      const wingMat = new THREE.MeshStandardMaterial({ color: mainColor, roughness: 0.4, metalness: 0.3 });
      const leftWing = new THREE.Mesh(leftWingGeo, wingMat);
      leftWing.position.set(-1.2, 0.05, 0);
      leftWing.rotation.z = 0.06;
      leftWing.rotation.y = 0.22;
      wingGroup.add(leftWing);

      const rightWing = leftWing.clone();
      rightWing.position.set(1.2, 0.05, 0);
      rightWing.rotation.z = -0.06;
      rightWing.rotation.y = -0.22;
      wingGroup.add(rightWing);

      // Winglet vertical tips
      const wingletGeo = new THREE.BoxGeometry(0.04, 0.35, 0.25);
      const wingletMat = new THREE.MeshStandardMaterial({ color: accentColor });
      const leftWinglet = new THREE.Mesh(wingletGeo, wingletMat);
      leftWinglet.position.set(-2.28, 0.2, -0.25);
      wingGroup.add(leftWinglet);

      const rightWinglet = leftWinglet.clone();
      rightWinglet.position.set(2.28, 0.2, -0.25);
      wingGroup.add(rightWinglet);

      // Navigation lights: Port (Red), Starboard (Green), Strobe (White)
      const portLight = new THREE.Mesh(
        new THREE.SphereGeometry(0.06, 8, 8),
        new THREE.MeshBasicMaterial({ color: 0xef4444 })
      );
      portLight.position.set(-2.3, 0.38, -0.25);
      wingGroup.add(portLight);

      const stbdLight = new THREE.Mesh(
        new THREE.SphereGeometry(0.06, 8, 8),
        new THREE.MeshBasicMaterial({ color: 0x10b981 })
      );
      stbdLight.position.set(2.3, 0.38, -0.25);
      wingGroup.add(stbdLight);
      plane.add(wingGroup);

      // Twin Turbofan Jet Engines
      const engines: THREE.Mesh[] = [];
      const exhaustCones: THREE.Mesh[] = [];
      [-0.95, 0.95].forEach((ex) => {
        const engCowlingGeo = new THREE.CylinderGeometry(0.22, 0.24, 0.95, 12);
        const engMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.8, roughness: 0.2 });
        const engine = new THREE.Mesh(engCowlingGeo, engMat);
        engine.rotation.x = Math.PI / 2;
        engine.position.set(ex, -0.28, 0.2);

        // Spinner / Fan blade disk
        const fanGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.05, 8);
        const fanMat = new THREE.MeshStandardMaterial({ color: 0x09090b });
        const fan = new THREE.Mesh(fanGeo, fanMat);
        fan.position.y = 0.48;
        engine.add(fan);
        engines.push(fan);

        // Glowing jet exhaust afterburner cone
        const thrustGeo = new THREE.ConeGeometry(0.18, 0.9, 12);
        const thrustMat = new THREE.MeshBasicMaterial({
          color: 0x38bdf8,
          transparent: true,
          opacity: 0.7
        });
        const thrust = new THREE.Mesh(thrustGeo, thrustMat);
        thrust.position.y = -0.7;
        thrust.rotation.x = Math.PI;
        thrust.visible = false;
        engine.add(thrust);
        exhaustCones.push(thrust);

        plane.add(engine);
      });

      // Tail Section (Vertical Stabilizer & Horizontal Tailplanes)
      const tailFinGeo = new THREE.BoxGeometry(0.08, 1.1, 0.9);
      const tailFinMat = new THREE.MeshStandardMaterial({ color: accentColor });
      const tailFin = new THREE.Mesh(tailFinGeo, tailFinMat);
      tailFin.position.set(0, 0.65, -1.3);
      tailFin.rotation.x = 0.35;
      plane.add(tailFin);

      const hTailGeo = new THREE.BoxGeometry(1.6, 0.05, 0.55);
      const hTail = new THREE.Mesh(hTailGeo, wingMat);
      hTail.position.set(0, 0.25, -1.45);
      hTail.rotation.y = 0.15;
      plane.add(hTail);

      // Top Red Anti-Collision Beacon
      const beaconGeo = new THREE.SphereGeometry(0.06, 8, 8);
      const beaconMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
      const beacon = new THREE.Mesh(beaconGeo, beaconMat);
      beacon.position.set(0, 0.42, 0.2);
      plane.add(beacon);

      // Tricycle Landing Gear (Nose + Dual Main Gears)
      const landingGearGroup = new THREE.Group();
      // Nose Gear
      const noseStrutGeo = new THREE.CylinderGeometry(0.03, 0.03, 0.4, 6);
      const gearMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.9 });
      const noseStrut = new THREE.Mesh(noseStrutGeo, gearMat);
      noseStrut.position.set(0, -0.4, 1.4);
      landingGearGroup.add(noseStrut);

      const wheelGeo = new THREE.CylinderGeometry(0.08, 0.08, 0.06, 8);
      const wheelMat = new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.9 });
      const noseWheel = new THREE.Mesh(wheelGeo, wheelMat);
      noseWheel.rotation.z = Math.PI / 2;
      noseWheel.position.set(0, -0.55, 1.4);
      landingGearGroup.add(noseWheel);

      // Main Gear Left & Right
      [-0.65, 0.65].forEach((gx) => {
        const mainStrut = new THREE.Mesh(noseStrutGeo, gearMat);
        mainStrut.position.set(gx, -0.4, 0);
        landingGearGroup.add(mainStrut);

        const mainWheel = new THREE.Mesh(wheelGeo, wheelMat);
        mainWheel.rotation.z = Math.PI / 2;
        mainWheel.position.set(gx, -0.55, 0);
        landingGearGroup.add(mainWheel);
      });
      plane.add(landingGearGroup);

      return {
        plane,
        engines,
        exhaustCones,
        landingGearGroup,
        beacon
      };
    };

    // =========================================================================
    // 2. ACTIVE TAKING OFF AIRPLANE (High-speed roll, rotation, liftoff, climb)
    // =========================================================================
    const takeoffFlightId = state.departedPlanes?.[state.departedPlanes.length - 1] || 'FL-301';
    const takeoffAircraft = createAirliner3D(takeoffFlightId, 0xf1f5f9, 0xef4444);
    const takeoffPlane = takeoffAircraft.plane;
    group.add(takeoffPlane);

    // Touchdown / Jet Smoke Particles for Takeoff & Landing
    const smokeParticles: THREE.Mesh[] = [];
    const smokeMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.6
    });
    for (let s = 0; s < 12; s++) {
      const sp = new THREE.Mesh(new THREE.SphereGeometry(0.25, 6, 6), smokeMat);
      sp.visible = false;
      group.add(sp);
      smokeParticles.push(sp);
    }

    // Attach full Takeoff Lifecycle Animation Callback
    takeoffPlane.userData = {
      animate: (time: number) => {
        // Continuous 8.5-second takeoff cycle
        const period = 8.5;
        const phase = (time % period);

        // Spin turbofan engine blades
        takeoffAircraft.engines.forEach((fan) => {
          fan.rotation.y += 0.35;
        });

        // Beacon blinking
        takeoffAircraft.beacon.visible = Math.sin(time * 8) > 0;

        if (phase < 1.6) {
          // Phase 1: Line up on runway threshold & spool up engines
          takeoffPlane.position.set(0, 0.58, -8);
          takeoffPlane.rotation.set(0, 0, 0);
          takeoffAircraft.landingGearGroup.scale.set(1, 1, 1);
          takeoffAircraft.exhaustCones.forEach((c) => {
            c.visible = true;
            c.scale.setScalar(0.7 + Math.random() * 0.3);
          });
        } else if (phase < 4.2) {
          // Phase 2: High-speed ground takeoff roll down runway
          const rollProgress = (phase - 1.6) / 2.6; // 0 to 1
          const zPos = -8 + rollProgress * 20; // -8 to +12
          const bounce = Math.sin(rollProgress * 24) * 0.03;
          takeoffPlane.position.set(0, 0.58 + bounce, zPos);
          takeoffPlane.rotation.set(0, 0, 0);
          takeoffAircraft.landingGearGroup.scale.set(1, 1, 1);
          takeoffAircraft.exhaustCones.forEach((c) => {
            c.visible = true;
            c.scale.setScalar(1.2 + Math.random() * 0.4);
          });
        } else if (phase < 6.2) {
          // Phase 3: ROTATION & LIFTOFF! Nose pitches up, climbs steeply, gear retracts
          const liftProgress = (phase - 4.2) / 2.0; // 0 to 1
          const zPos = 12 + liftProgress * 18; // 12 to 30
          const yPos = 0.58 + Math.pow(liftProgress, 1.4) * 9.5; // 0.58 to 10.0
          const pitchAngle = Math.min(0.35, liftProgress * 0.42); // Nose up ~22 deg

          takeoffPlane.position.set(0, yPos, zPos);
          takeoffPlane.rotation.set(-pitchAngle, 0, 0);

          // Retract landing gear smoothly
          const gearScale = Math.max(0.1, 1 - liftProgress * 2);
          takeoffAircraft.landingGearGroup.scale.set(gearScale, gearScale, gearScale);

          takeoffAircraft.exhaustCones.forEach((c) => {
            c.visible = true;
            c.scale.setScalar(1.4 + Math.random() * 0.3);
          });
        } else {
          // Phase 4: High altitude climb & bank away into the sky
          const bankProgress = (phase - 6.2) / 2.3; // 0 to 1
          const zPos = 30 + bankProgress * 24;
          const yPos = 10.0 + bankProgress * 8;
          const xPos = -bankProgress * 12; // Bank left
          const bankAngle = Math.sin(bankProgress * Math.PI) * 0.4;

          takeoffPlane.position.set(xPos, yPos, zPos);
          takeoffPlane.rotation.set(-0.25, -bankAngle * 0.5, bankAngle);

          takeoffAircraft.landingGearGroup.scale.set(0, 0, 0);
          takeoffAircraft.exhaustCones.forEach((c) => {
            c.visible = true;
            c.scale.setScalar(1.1);
          });
        }
      }
    };

    // =========================================================================
    // 3. ACTIVE LANDING AIRPLANE (Approach, flare, touchdown smoke, rollout)
    // =========================================================================
    const landingAircraft = createAirliner3D('FL-INBOUND', 0xe2e8f0, 0x10b981);
    const landingPlane = landingAircraft.plane;
    group.add(landingPlane);

    landingPlane.userData = {
      animate: (time: number) => {
        // Continuous 8.5-second landing cycle (offset from takeoff)
        const period = 8.5;
        const phase = ((time + 4.25) % period);

        landingAircraft.engines.forEach((fan) => {
          fan.rotation.y += 0.28;
        });
        landingAircraft.beacon.visible = Math.sin(time * 8) > 0;

        if (phase < 3.2) {
          // Phase 1: High glide slope approach (-Z to threshold)
          const appProgress = phase / 3.2; // 0 to 1
          const zPos = -38 + appProgress * 22; // -38 to -16
          const yPos = 12 - appProgress * 11.4; // 12 to 0.6
          const flare = 0.08 + (1 - appProgress) * 0.06; // Pitch flare angle

          landingPlane.position.set(0, yPos, zPos);
          landingPlane.rotation.set(-flare, 0, 0);
          landingAircraft.landingGearGroup.scale.set(1, 1, 1);
          landingAircraft.exhaustCones.forEach((c) => (c.visible = false));
        } else if (phase < 3.5) {
          // Phase 2: TOUCHDOWN! Contact with runway threshold + tire smoke
          const touchProgress = (phase - 3.2) / 0.3;
          landingPlane.position.set(0, 0.58, -16 + touchProgress * 4);
          landingPlane.rotation.set(0.04 * (1 - touchProgress), 0, 0);
          landingAircraft.landingGearGroup.scale.set(1, 1, 1);

          // Trigger smoke puff
          smokeParticles.forEach((sp, i) => {
            sp.visible = true;
            sp.position.set(
              (Math.random() - 0.5) * 1.5,
              0.4 + Math.random() * 0.3,
              -16 + i * 0.3
            );
            sp.scale.setScalar(0.4 + touchProgress * 0.6);
          });
        } else if (phase < 6.8) {
          // Phase 3: High-speed rollout & reverse thruster deceleration
          const rollProgress = (phase - 3.5) / 3.3; // 0 to 1
          const zPos = -12 + rollProgress * 18; // -12 to +6
          landingPlane.position.set(0, 0.58, zPos);
          landingPlane.rotation.set(0, 0, 0);
          landingAircraft.landingGearGroup.scale.set(1, 1, 1);

          // Fade smoke
          smokeParticles.forEach((sp) => {
            sp.visible = false;
          });
          // Reverse thruster amber glow
          landingAircraft.exhaustCones.forEach((c) => {
            c.visible = rollProgress < 0.6;
            c.scale.setScalar(0.5);
          });
        } else {
          // Phase 4: Turn off runway onto taxiway to join the queue
          const turnProgress = (phase - 6.8) / 1.7; // 0 to 1
          const xPos = turnProgress * 8.5; // Turn towards taxiway
          const zPos = 6 - turnProgress * 8;
          const turnAngle = Math.sin(turnProgress * Math.PI) * 0.65;

          landingPlane.position.set(xPos, 0.58, zPos);
          landingPlane.rotation.set(0, turnAngle, 0);
          landingAircraft.landingGearGroup.scale.set(1, 1, 1);
          landingAircraft.exhaustCones.forEach((c) => (c.visible = false));
        }
      }
    };

    // =========================================================================
    // 4. QUEUED AIRPLANES ON TAXIWAY (Waiting in strict FIFO order)
    // =========================================================================
    const queueFlights = state.queueItems || ['AI-101', 'BA-202', 'EK-303'];
    queueFlights.forEach((flight: string, idx: number) => {
      const colors = [0x0284c7, 0xd97706, 0x7c3aed, 0x059669];
      const qAircraft = createAirliner3D(flight, 0xf8fafc, colors[idx % colors.length]);
      const qPlane = qAircraft.plane;

      // Position parked along parallel taxiway in FIFO sequence
      const targetZ = -4 - idx * 4.8;
      qPlane.position.set(8.5, 0.58, targetZ);
      qPlane.rotation.set(0, Math.PI, 0); // Facing forward along taxiway
      qPlane.castShadow = true;

      qPlane.userData = {
        animate: (time: number) => {
          // Idle engine turbine rotation & beacon blink
          qAircraft.engines.forEach((fan) => (fan.rotation.y += 0.12));
          qAircraft.beacon.visible = Math.sin(time * 6 + idx) > 0;

          // Gentle idling vibration
          qPlane.position.y = 0.58 + Math.sin(time * 4 + idx) * 0.015;
        }
      };

      group.add(qPlane);
    });
  };

  // 3. Infix to Postfix: 3D Asteroid Defense Cannon
  const buildAsteroidBlaster3D = (group: THREE.Group, state: any) => {
    // Cannon Base Platform
    const baseGeo = new THREE.CylinderGeometry(2, 2.5, 0.8, 16);
    const baseMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.8, wireframe });
    const base = new THREE.Mesh(baseGeo, baseMat);
    base.position.set(0, 0.4, 6);
    group.add(base);

    // Rotating Cannon Turret
    const turretGroup = new THREE.Group();
    turretGroup.position.set(0, 1.2, 6);
    const angle = (state.cannonAngle || 45) * (Math.PI / 180);
    turretGroup.rotation.x = -angle * 0.4;

    // Dual Barrels
    [-0.4, 0.4].forEach((bx) => {
      const barrelGeo = new THREE.CylinderGeometry(0.18, 0.22, 3, 12);
      const barrelMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.9, wireframe });
      const barrel = new THREE.Mesh(barrelGeo, barrelMat);
      barrel.rotation.x = Math.PI / 2;
      barrel.position.set(bx, 0, -1.2);
      turretGroup.add(barrel);
    });
    group.add(turretGroup);

    // 3D Laser Beam if firing
    if (state.laserFired) {
      const laserGeo = new THREE.CylinderGeometry(0.08, 0.08, 14, 8);
      const laserMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
      const laser = new THREE.Mesh(laserGeo, laserMat);
      laser.rotation.x = Math.PI / 2;
      laser.position.set(0, 1.5, -1);
      group.add(laser);
    }

    // Floating 3D Glowing Asteroids
    const asteroidPositions = [
      [0, 3.5, -6],
      [-4, 4.5, -8],
      [4, 3, -7]
    ];
    asteroidPositions.forEach(([ax, ay, az], i) => {
      const astGeo = new THREE.DodecahedronGeometry(1.4 + (i === 0 ? 0.4 : 0), 1);
      const astMat = new THREE.MeshStandardMaterial({
        color: 0x7c3aed,
        emissive: 0x4c1d95,
        emissiveIntensity: 0.4,
        roughness: 0.9,
        wireframe
      });
      const asteroid = new THREE.Mesh(astGeo, astMat);
      asteroid.position.set(ax, ay, az);
      asteroid.userData = { isRotating: true, isFloating: true };
      group.add(asteroid);
    });
  };

  // 4. Polynomial Arithmetic: 3D Spell Alchemy
  const buildSpellAlchemy3D = (group: THREE.Group, state: any) => {
    // Alchemy Cauldron
    const cauldronGeo = new THREE.SphereGeometry(2, 16, 16, 0, Math.PI * 2, 0, Math.PI * 0.7);
    const cauldronMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8, roughness: 0.3, wireframe });
    const cauldron = new THREE.Mesh(cauldronGeo, cauldronMat);
    cauldron.rotation.x = Math.PI;
    cauldron.position.set(0, 2, 0);
    group.add(cauldron);

    // Glowing liquid inside
    const liquidGeo = new THREE.CylinderGeometry(1.8, 1.8, 0.1, 16);
    const liquidMat = new THREE.MeshBasicMaterial({ color: 0x10b981 });
    const liquid = new THREE.Mesh(liquidGeo, liquidMat);
    liquid.position.set(0, 1.8, 0);
    group.add(liquid);

    // Orbiting 3D Spell Power Orbs (Terms x^3, x^2, x)
    const orbs = [
      { name: '4x^3', color: 0xef4444, pos: [-3, 3.5, 0] },
      { name: '2x^2', color: 0x3b82f6, pos: [3, 3.5, 0] },
      { name: '5', color: 0xf59e0b, pos: [0, 4.5, -2] }
    ];
    orbs.forEach((o) => {
      const orbGeo = new THREE.OctahedronGeometry(0.7, 2);
      const orbMat = new THREE.MeshStandardMaterial({
        color: o.color,
        emissive: o.color,
        emissiveIntensity: 0.6,
        wireframe
      });
      const orbMesh = new THREE.Mesh(orbGeo, orbMat);
      orbMesh.position.set(o.pos[0], o.pos[1], o.pos[2]);
      orbMesh.userData = { isRotating: true, isFloating: true };
      group.add(orbMesh);
    });

    // 3D Boss Monster in background
    const bossGroup = new THREE.Group();
    bossGroup.position.set(0, 1, -8);
    const bossBody = new THREE.Mesh(
      new THREE.BoxGeometry(4, 5, 2),
      new THREE.MeshStandardMaterial({ color: 0x991b1b, roughness: 0.5, wireframe })
    );
    bossBody.position.y = 2.5;
    bossGroup.add(bossBody);
    group.add(bossGroup);
  };

  // 5. Binary Tree Traversals: 3D Sacred World Tree
  const buildWorldTree3D = (group: THREE.Group, state: any) => {
    // Tree Trunk
    const trunkGeo = new THREE.CylinderGeometry(0.6, 1.2, 5, 12);
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.9, wireframe });
    const trunk = new THREE.Mesh(trunkGeo, trunkMat);
    trunk.position.set(0, 2.5, 0);
    group.add(trunk);

    // Tree Node Coordinates (Root, Left, Right, Leaves)
    const nodes = [
      { id: '4', x: 0, y: 5.5, z: 0, isRoot: true },
      { id: '2', x: -3, y: 4, z: 0 },
      { id: '6', x: 3, y: 4, z: 0 },
      { id: '1', x: -4.5, y: 2.2, z: 0 },
      { id: '3', x: -1.5, y: 2.2, z: 0 },
      { id: '5', x: 1.5, y: 2.2, z: 0 },
      { id: '7', x: 4.5, y: 2.2, z: 0 }
    ];

    // Branch Connections (Cylinders)
    const branches = [
      [0, 1],
      [0, 2],
      [1, 3],
      [1, 4],
      [2, 5],
      [2, 6]
    ];
    branches.forEach(([from, to]) => {
      const p1 = new THREE.Vector3(nodes[from].x, nodes[from].y, nodes[from].z);
      const p2 = new THREE.Vector3(nodes[to].x, nodes[to].y, nodes[to].z);
      const dist = p1.distanceTo(p2);
      const branchGeo = new THREE.CylinderGeometry(0.12, 0.16, dist, 8);
      const branchMat = new THREE.MeshStandardMaterial({ color: 0x92400e, wireframe });
      const branch = new THREE.Mesh(branchGeo, branchMat);
      branch.position.copy(p1).lerp(p2, 0.5);
      branch.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), p2.clone().sub(p1).normalize());
      group.add(branch);
    });

    // 3D Glowing Node Crystals
    nodes.forEach((node) => {
      const isVisited = state.visitedNodes?.includes(node.id);
      const nodeGeo = new THREE.SphereGeometry(0.55, 16, 16);
      const nodeMat = new THREE.MeshStandardMaterial({
        color: isVisited ? 0x10b981 : node.isRoot ? 0xf59e0b : 0x06b6d4,
        emissive: isVisited ? 0x10b981 : 0x06b6d4,
        emissiveIntensity: 0.7,
        wireframe
      });
      const nodeMesh = new THREE.Mesh(nodeGeo, nodeMat);
      nodeMesh.position.set(node.x, node.y, node.z);
      nodeMesh.userData = { isRotating: true };
      group.add(nodeMesh);
    });
  };

  // 6. Binary Search Tree: 3D Crystal Storage Vault
  const buildBstVault3D = (group: THREE.Group, state: any) => {
    // Tiered pedestals (Level 0, Level 1, Level 2)
    const bstPositions = [
      { val: 50, x: 0, y: 5, z: 0 },
      { val: 30, x: -3.5, y: 3.2, z: 0 },
      { val: 70, x: 3.5, y: 3.2, z: 0 },
      { val: 20, x: -5, y: 1.5, z: 0 },
      { val: 40, x: -2, y: 1.5, z: 0 }
    ];

    bstPositions.forEach((pos) => {
      // Pedestal
      const pedGeo = new THREE.CylinderGeometry(1, 1.2, pos.y, 16);
      const pedMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.6, wireframe });
      const ped = new THREE.Mesh(pedGeo, pedMat);
      ped.position.set(pos.x, pos.y / 2, pos.z);
      group.add(ped);

      // Gemstone on top
      const gemGeo = new THREE.OctahedronGeometry(0.65, 0);
      const gemMat = new THREE.MeshStandardMaterial({
        color: 0x06b6d4,
        emissive: 0x0891b2,
        emissiveIntensity: 0.8,
        metalness: 0.9,
        roughness: 0.1,
        wireframe
      });
      const gem = new THREE.Mesh(gemGeo, gemMat);
      gem.position.set(pos.x, pos.y + 0.65, pos.z);
      gem.userData = { isRotating: true };
      group.add(gem);
    });
  };

  // 7. Graph Traversals: 3D Cyber Matrix
  const buildCyberMatrix3D = (group: THREE.Group, state: any) => {
    // 5 Cyber Nodes in a pentagram/cluster
    const cyberNodes = [
      { id: 0, x: 0, y: 4, z: 0 },
      { id: 1, x: -4, y: 3, z: -2 },
      { id: 2, x: 4, y: 3, z: -2 },
      { id: 3, x: -3, y: 1.5, z: 3 },
      { id: 4, x: 3, y: 1.5, z: 3 }
    ];

    // Edges
    const edges = [
      [0, 1],
      [0, 2],
      [1, 3],
      [2, 4],
      [3, 4]
    ];
    edges.forEach(([u, v]) => {
      const p1 = new THREE.Vector3(cyberNodes[u].x, cyberNodes[u].y, cyberNodes[u].z);
      const p2 = new THREE.Vector3(cyberNodes[v].x, cyberNodes[v].y, cyberNodes[v].z);
      const dist = p1.distanceTo(p2);
      const tubeGeo = new THREE.CylinderGeometry(0.08, 0.08, dist, 8);
      const tubeMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
      const tube = new THREE.Mesh(tubeGeo, tubeMat);
      tube.position.copy(p1).lerp(p2, 0.5);
      tube.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), p2.clone().sub(p1).normalize());
      group.add(tube);
    });

    // Spheres
    cyberNodes.forEach((cn) => {
      const sphereGeo = new THREE.SphereGeometry(0.7, 16, 16);
      const sphereMat = new THREE.MeshStandardMaterial({
        color: 0x06b6d4,
        emissive: 0x06b6d4,
        emissiveIntensity: 0.6,
        wireframe
      });
      const sphere = new THREE.Mesh(sphereGeo, sphereMat);
      sphere.position.set(cn.x, cn.y, cn.z);
      sphere.userData = { isRotating: true };
      group.add(sphere);
    });
  };

  // 8. Sorting: 3D Harbor Cargo Crane
  const buildCargoCrane3D = (group: THREE.Group, state: any) => {
    // Crane Rails
    [-5, 5].forEach((z) => {
      const railGeo = new THREE.BoxGeometry(16, 0.2, 0.4);
      const railMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.9, wireframe });
      const rail = new THREE.Mesh(railGeo, railMat);
      rail.position.set(0, 0.1, z);
      group.add(rail);
    });

    // 3D Shipping Containers
    const boxes = state.sortBoxes || [64, 34, 25, 12, 22, 11, 90];
    const comparing = state.activeComparingIndices || [];

    boxes.forEach((val: number, idx: number) => {
      const isComp = comparing.includes(idx);
      const h = Math.max(1, (val / 90) * 4);
      const boxGeo = new THREE.BoxGeometry(1.2, h, 2.2);
      const boxMat = new THREE.MeshStandardMaterial({
        color: isComp ? 0xf59e0b : 0xd97706,
        emissive: isComp ? 0xf59e0b : 0x000000,
        emissiveIntensity: isComp ? 0.5 : 0,
        roughness: 0.4,
        metalness: 0.7,
        wireframe
      });
      const box = new THREE.Mesh(boxGeo, boxMat);
      const xPos = (idx - Math.floor(boxes.length / 2)) * 1.7;
      box.position.set(xPos, h / 2, 0);
      box.castShadow = true;
      group.add(box);
    });

    // 3D Gantry Crane Arch
    const craneGroup = new THREE.Group();
    // Legs
    [
      [-3, -4],
      [-3, 4],
      [3, -4],
      [3, 4]
    ].forEach(([cx, cz]) => {
      const legGeo = new THREE.CylinderGeometry(0.15, 0.2, 7, 8);
      const legMat = new THREE.MeshStandardMaterial({ color: 0xef4444, metalness: 0.8, wireframe });
      const leg = new THREE.Mesh(legGeo, legMat);
      leg.position.set(cx, 3.5, cz);
      craneGroup.add(leg);
    });
    // Top Girder
    const girderGeo = new THREE.BoxGeometry(8, 0.5, 9);
    const girderMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, metalness: 0.8, wireframe });
    const girder = new THREE.Mesh(girderGeo, girderMat);
    girder.position.y = 7;
    craneGroup.add(girder);
    group.add(craneGroup);
  };

  // =========================================================================
  // DAA 3D ALGORITHM GAME WORLDS
  // =========================================================================

  // 1. Selection Sort: Weather Telemetry Thermal Calibrator
  const buildSelectionWeather3D = (group: THREE.Group, state: any) => {
    // Weather station base platform
    const baseGeo = new THREE.CylinderGeometry(8, 8.5, 0.5, 32);
    const baseMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8, wireframe });
    const base = new THREE.Mesh(baseGeo, baseMat);
    base.position.y = 0.25;
    group.add(base);

    // Weather Mast Tower
    const mastGeo = new THREE.CylinderGeometry(0.2, 0.4, 8, 16);
    const mastMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.9, wireframe });
    const mast = new THREE.Mesh(mastGeo, mastMat);
    mast.position.set(0, 4, -4);
    group.add(mast);

    // Rotating Anemometer Cups on top of mast
    const anemometer = new THREE.Group();
    anemometer.position.set(0, 8, -4);
    for (let i = 0; i < 3; i++) {
      const armGeo = new THREE.CylinderGeometry(0.04, 0.04, 1.2, 8);
      const arm = new THREE.Mesh(armGeo, new THREE.MeshStandardMaterial({ color: 0xef4444, wireframe }));
      arm.rotation.z = Math.PI / 2;
      arm.rotation.y = (i * Math.PI * 2) / 3;
      anemometer.add(arm);
    }
    anemometer.userData = { isRotating: true };
    group.add(anemometer);

    // Temperature Columns
    const temps = state.sortBoxes || [38, 22, 45, 19, 31, 27];
    const comparing = state.activeComparingIndices || [];
    temps.forEach((tVal: number, idx: number) => {
      const isComp = comparing.includes(idx);
      const height = Math.max(1, (tVal / 50) * 5);
      const colGeo = new THREE.CylinderGeometry(0.6, 0.6, height, 16);
      const colColor = isComp ? 0xef4444 : tVal > 35 ? 0xf97316 : tVal > 25 ? 0xeab308 : 0x06b6d4;
      const colMat = new THREE.MeshStandardMaterial({
        color: colColor,
        emissive: isComp ? 0xef4444 : 0x000000,
        emissiveIntensity: isComp ? 0.6 : 0.1,
        metalness: 0.5,
        wireframe
      });
      const col = new THREE.Mesh(colGeo, colMat);
      const xPos = (idx - Math.floor(temps.length / 2)) * 1.8;
      col.position.set(xPos, height / 2 + 0.5, 0);
      group.add(col);

      // Probe indicator above column
      if (isComp) {
        const probeGeo = new THREE.ConeGeometry(0.3, 0.8, 8);
        const probeMat = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xef4444, wireframe });
        const probe = new THREE.Mesh(probeGeo, probeMat);
        probe.rotation.x = Math.PI;
        probe.position.set(xPos, height + 1.2, 0);
        group.add(probe);
      }
    });
  };

  // 2. Insertion Sort: Soil Moisture Sensor Conveyor
  const buildInsertionMoisture3D = (group: THREE.Group, state: any) => {
    // Soil field base
    const fieldGeo = new THREE.BoxGeometry(16, 0.4, 8);
    const fieldMat = new THREE.MeshStandardMaterial({ color: 0x3f2e1a, roughness: 0.9, wireframe });
    const field = new THREE.Mesh(fieldGeo, fieldMat);
    field.position.y = 0.2;
    group.add(field);

    // Irrigation pipes along the edge
    const pipeGeo = new THREE.CylinderGeometry(0.15, 0.15, 16, 16);
    const pipeMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.8, wireframe });
    const pipe = new THREE.Mesh(pipeGeo, pipeMat);
    pipe.rotation.z = Math.PI / 2;
    pipe.position.set(0, 0.5, -3.5);
    group.add(pipe);

    // Moisture Sensor Pods
    const readings = state.sortBoxes || [42, 15, 68, 33, 21, 55];
    const comparing = state.activeComparingIndices || [];
    readings.forEach((mVal: number, idx: number) => {
      const isComp = comparing.includes(idx);
      const h = Math.max(0.8, (mVal / 80) * 4);
      const podGeo = new THREE.BoxGeometry(1.2, h, 1.4);
      const podMat = new THREE.MeshStandardMaterial({
        color: isComp ? 0x10b981 : 0x059669,
        emissive: isComp ? 0x34d399 : 0x000000,
        emissiveIntensity: isComp ? 0.7 : 0.1,
        metalness: 0.6,
        wireframe
      });
      const pod = new THREE.Mesh(podGeo, podMat);
      const x = (idx - Math.floor(readings.length / 2)) * 1.8;
      pod.position.set(x, h / 2 + 0.4, 0);
      group.add(pod);

      // Antenna probe
      const antGeo = new THREE.CylinderGeometry(0.04, 0.04, 1.2, 8);
      const ant = new THREE.Mesh(antGeo, new THREE.MeshStandardMaterial({ color: 0x94a3b8, wireframe }));
      ant.position.set(x, h + 1, 0);
      group.add(ant);
    });
  };

  // 3. Merge Sort: Dual Conveyor Granary Merge Silo
  const buildMergeVillage3D = (group: THREE.Group, state: any) => {
    // Twin intake conveyors (Left wing, Right wing)
    [-4, 4].forEach((xSide) => {
      const convGeo = new THREE.BoxGeometry(4.5, 0.3, 3);
      const convMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.7, wireframe });
      const conv = new THREE.Mesh(convGeo, convMat);
      conv.position.set(xSide, 0.8, -2);
      group.add(conv);
    });

    // Central Grand Silo / Grain Elevator
    const siloGeo = new THREE.CylinderGeometry(2, 2.4, 6, 24);
    const siloMat = new THREE.MeshStandardMaterial({ color: 0xca8a04, metalness: 0.6, wireframe });
    const silo = new THREE.Mesh(siloGeo, siloMat);
    silo.position.set(0, 3, 2);
    group.add(silo);

    // Silo Dome
    const domeGeo = new THREE.SphereGeometry(2, 24, 16, 0, Math.PI * 2, 0, Math.PI / 2);
    const dome = new THREE.Mesh(domeGeo, new THREE.MeshStandardMaterial({ color: 0xa16207, wireframe }));
    dome.position.set(0, 6, 2);
    group.add(dome);

    // Sorted Grain Crates
    const boxes = state.sortBoxes || [12, 19, 24, 35, 48, 56, 72];
    const comparing = state.activeComparingIndices || [];
    boxes.forEach((bVal: number, idx: number) => {
      const isComp = comparing.includes(idx);
      const cGeo = new THREE.BoxGeometry(0.9, 0.9, 0.9);
      const cMat = new THREE.MeshStandardMaterial({
        color: isComp ? 0xeab308 : 0x854d0e,
        emissive: isComp ? 0xfacc15 : 0x000000,
        emissiveIntensity: isComp ? 0.6 : 0,
        wireframe
      });
      const crate = new THREE.Mesh(cGeo, cMat);
      const x = (idx - Math.floor(boxes.length / 2)) * 1.3;
      crate.position.set(x, 0.6, 5);
      group.add(crate);
    });
  };

  // 4. Quick Sort: Thermal Pivot & Zone Partitioner
  const buildQuickHeatwave3D = (group: THREE.Group, state: any) => {
    // Partition Zones (Left Cooler = Blue, Right Warmer = Red)
    const leftZone = new THREE.Mesh(
      new THREE.BoxGeometry(7, 0.1, 8),
      new THREE.MeshStandardMaterial({ color: 0x0284c7, transparent: true, opacity: 0.3, wireframe })
    );
    leftZone.position.set(-4, 0.05, 0);
    group.add(leftZone);

    const rightZone = new THREE.Mesh(
      new THREE.BoxGeometry(7, 0.1, 8),
      new THREE.MeshStandardMaterial({ color: 0xdc2626, transparent: true, opacity: 0.3, wireframe })
    );
    rightZone.position.set(4, 0.05, 0);
    group.add(rightZone);

    // Central Pivot Tower
    const pivotTower = new THREE.Mesh(
      new THREE.CylinderGeometry(0.6, 0.8, 5, 16),
      new THREE.MeshStandardMaterial({ color: 0xf59e0b, emissive: 0xd97706, emissiveIntensity: 0.7, wireframe })
    );
    pivotTower.position.set(0, 2.5, 0);
    pivotTower.userData = { isRotating: true };
    group.add(pivotTower);

    // Heatwave Sensors
    const temps = state.sortBoxes || [52, 28, 77, 19, 64, 43];
    temps.forEach((t: number, idx: number) => {
      const h = Math.max(1, (t / 80) * 4);
      const sMesh = new THREE.Mesh(
        new THREE.CylinderGeometry(0.4, 0.5, h, 12),
        new THREE.MeshStandardMaterial({
          color: t > 45 ? 0xef4444 : 0x38bdf8,
          emissive: t > 45 ? 0xb91c1c : 0x0369a1,
          emissiveIntensity: 0.4,
          wireframe
        })
      );
      const x = (idx - Math.floor(temps.length / 2)) * 1.8;
      sMesh.position.set(x, h / 2, 2.5);
      group.add(sMesh);
    });
  };

  // 5. Kruskal's MST: Island Wireless Sensor Grid
  const buildKruskalSensor3D = (group: THREE.Group, state: any) => {
    // Water ground plane
    const waterGeo = new THREE.PlaneGeometry(24, 24);
    const waterMat = new THREE.MeshStandardMaterial({ color: 0x0369a1, metalness: 0.8, roughness: 0.2, wireframe });
    const water = new THREE.Mesh(waterGeo, waterMat);
    water.rotation.x = -Math.PI / 2;
    group.add(water);

    // Sensor Islands
    const islands = [
      { id: 'S1', x: -5, z: -4 },
      { id: 'S2', x: 0, z: -5 },
      { id: 'S3', x: 5, z: -3 },
      { id: 'S4', x: -4, z: 2 },
      { id: 'S5', x: 1, z: 4 },
      { id: 'S6', x: 5, z: 3 }
    ];

    islands.forEach((isl) => {
      // Island rock
      const rock = new THREE.Mesh(
        new THREE.CylinderGeometry(1.6, 2.2, 1, 16),
        new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.8, wireframe })
      );
      rock.position.set(isl.x, 0.5, isl.z);
      group.add(rock);

      // Antenna tower
      const ant = new THREE.Mesh(
        new THREE.CylinderGeometry(0.08, 0.15, 3.5, 8),
        new THREE.MeshStandardMaterial({ color: 0x38bdf8, metalness: 0.9, wireframe })
      );
      ant.position.set(isl.x, 2.5, isl.z);
      group.add(ant);

      // Beacon beacon sphere
      const beacon = new THREE.Mesh(
        new THREE.SphereGeometry(0.3, 12, 12),
        new THREE.MeshStandardMaterial({ color: 0x22c55e, emissive: 0x16a34a, emissiveIntensity: 0.9, wireframe })
      );
      beacon.position.set(isl.x, 4.4, isl.z);
      beacon.userData = { isRotating: true };
      group.add(beacon);
    });

    // Spanning Tree Laser Links
    const edges = [
      [-5, -4, 0, -5],
      [0, -5, 5, -3],
      [-5, -4, -4, 2],
      [-4, 2, 1, 4],
      [1, 4, 5, 3]
    ];
    edges.forEach(([x1, z1, x2, z2]) => {
      const p1 = new THREE.Vector3(x1, 3.5, z1);
      const p2 = new THREE.Vector3(x2, 3.5, z2);
      const dist = p1.distanceTo(p2);
      const beamGeo = new THREE.CylinderGeometry(0.06, 0.06, dist, 8);
      const beamMat = new THREE.MeshStandardMaterial({
        color: 0x10b981,
        emissive: 0x34d399,
        emissiveIntensity: 0.8,
        wireframe
      });
      const beam = new THREE.Mesh(beamGeo, beamMat);
      beam.position.copy(p1.clone().add(p2).multiplyScalar(0.5));
      beam.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), p2.clone().sub(p1).normalize());
      group.add(beam);
    });
  };

  // 6. TSP: Logistics Drone Routing Hub
  const buildTspTour3D = (group: THREE.Group, state: any) => {
    // City map grid
    const grid = new THREE.GridHelper(20, 20, 0xef4444, 0x334155);
    group.add(grid);

    // City Skyscrapers
    const cities = [
      { name: 'Hub A', x: -6, z: -4, h: 4 },
      { name: 'City B', x: -2, z: 5, h: 6 },
      { name: 'City C', x: 5, z: 4, h: 5 },
      { name: 'City D', x: 6, z: -5, h: 7 },
      { name: 'City E', x: 1, z: -2, h: 3 }
    ];

    cities.forEach((c) => {
      const bldg = new THREE.Mesh(
        new THREE.BoxGeometry(1.6, c.h, 1.6),
        new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.7, wireframe })
      );
      bldg.position.set(c.x, c.h / 2, c.z);
      group.add(bldg);

      // Rooftop helipad/beacon
      const pad = new THREE.Mesh(
        new THREE.CylinderGeometry(0.8, 0.8, 0.1, 16),
        new THREE.MeshStandardMaterial({ color: 0xf59e0b, emissive: 0xb45309, emissiveIntensity: 0.5, wireframe })
      );
      pad.position.set(c.x, c.h + 0.05, c.z);
      group.add(pad);
    });

    // Animated Delivery Drone Tour Line
    for (let i = 0; i < cities.length; i++) {
      const c1 = cities[i];
      const c2 = cities[(i + 1) % cities.length];
      const v1 = new THREE.Vector3(c1.x, c1.h + 1, c1.z);
      const v2 = new THREE.Vector3(c2.x, c2.h + 1, c2.z);
      const dist = v1.distanceTo(v2);
      const flightPath = new THREE.Mesh(
        new THREE.CylinderGeometry(0.04, 0.04, dist, 8),
        new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x0284c7, emissiveIntensity: 0.8, wireframe })
      );
      flightPath.position.copy(v1.clone().add(v2).multiplyScalar(0.5));
      flightPath.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), v2.clone().sub(v1).normalize());
      group.add(flightPath);
    }
  };

  // 7. N-Queens: Holographic Chess Matrix
  const buildNQueenMatrix3D = (group: THREE.Group, state: any) => {
    const n = 4;
    const tileSize = 2;
    // 3D Checkerboard
    for (let r = 0; r < n; r++) {
      for (let c = 0; c < n; c++) {
        const isWhite = (r + c) % 2 === 0;
        const tile = new THREE.Mesh(
          new THREE.BoxGeometry(tileSize - 0.1, 0.3, tileSize - 0.1),
          new THREE.MeshStandardMaterial({
            color: isWhite ? 0xe2e8f0 : 0x1e293b,
            metalness: 0.6,
            wireframe
          })
        );
        const x = (c - (n - 1) / 2) * tileSize;
        const z = (r - (n - 1) / 2) * tileSize;
        tile.position.set(x, 0.15, z);
        group.add(tile);
      }
    }

    // Holographic Queens positioned
    const queens = [
      { r: 0, c: 1 },
      { r: 1, c: 3 },
      { r: 2, c: 0 },
      { r: 3, c: 2 }
    ];

    queens.forEach((q) => {
      const x = (q.c - (n - 1) / 2) * tileSize;
      const z = (q.r - (n - 1) / 2) * tileSize;

      const queenGroup = new THREE.Group();
      queenGroup.position.set(x, 0.3, z);

      // Crown Base
      const qBase = new THREE.Mesh(
        new THREE.CylinderGeometry(0.5, 0.7, 1.8, 16),
        new THREE.MeshStandardMaterial({
          color: 0xa855f7,
          emissive: 0x7e22ce,
          emissiveIntensity: 0.7,
          wireframe
        })
      );
      qBase.position.y = 0.9;
      queenGroup.add(qBase);

      // Crown points
      const crown = new THREE.Mesh(
        new THREE.ConeGeometry(0.6, 0.8, 8),
        new THREE.MeshStandardMaterial({ color: 0xfacc15, wireframe })
      );
      crown.position.y = 2.2;
      queenGroup.add(crown);

      queenGroup.userData = { isRotating: true };
      group.add(queenGroup);
    });
  };

  // 8. Sum of Subsets: Holographic Vault Scale
  const buildSubsetsVault3D = (group: THREE.Group, state: any) => {
    // Vault pedestal
    const pGeo = new THREE.CylinderGeometry(5, 5.5, 0.6, 24);
    const pMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8, wireframe });
    const ped = new THREE.Mesh(pGeo, pMat);
    ped.position.y = 0.3;
    group.add(ped);

    // Balance scale pillar
    const postGeo = new THREE.CylinderGeometry(0.3, 0.4, 6, 16);
    const post = new THREE.Mesh(postGeo, new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9, wireframe }));
    post.position.set(0, 3.3, 0);
    group.add(post);

    // Horizontal Balance Beam
    const beamGeo = new THREE.BoxGeometry(8, 0.25, 0.4);
    const beam = new THREE.Mesh(beamGeo, new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.8, wireframe }));
    beam.position.set(0, 6.2, 0);
    group.add(beam);

    // Left and Right Weighing Pans
    [-3.8, 3.8].forEach((xPan) => {
      const chain = new THREE.Mesh(
        new THREE.CylinderGeometry(0.04, 0.04, 2.5, 8),
        new THREE.MeshStandardMaterial({ color: 0x94a3b8, wireframe })
      );
      chain.position.set(xPan, 4.95, 0);
      group.add(chain);

      const pan = new THREE.Mesh(
        new THREE.CylinderGeometry(1.5, 0.2, 0.3, 16),
        new THREE.MeshStandardMaterial({ color: 0xca8a04, metalness: 0.7, wireframe })
      );
      pan.position.set(xPan, 3.7, 0);
      group.add(pan);
    });

    // Energy Weight Crystals (Subsets)
    const weights = [3, 5, 7, 11, 13];
    weights.forEach((w, idx) => {
      const crystal = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.3 + (w / 15) * 0.4, 0),
        new THREE.MeshStandardMaterial({
          color: 0x38bdf8,
          emissive: 0x0284c7,
          emissiveIntensity: 0.6,
          wireframe
        })
      );
      const ang = (idx * Math.PI * 2) / weights.length;
      crystal.position.set(Math.cos(ang) * 3, 1.2, Math.sin(ang) * 3);
      crystal.userData = { isRotating: true };
      group.add(crystal);
    });
  };

  // 9. KMP String Matcher: Cyber Holographic Scanner
  const buildKmpScanner3D = (group: THREE.Group, state: any) => {
    // Cyber Data Grid
    const cyberGrid = new THREE.GridHelper(18, 18, 0x06b6d4, 0x0f172a);
    group.add(cyberGrid);

    // Streamer Rail
    const rail = new THREE.Mesh(
      new THREE.BoxGeometry(14, 0.3, 0.8),
      new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.9, wireframe })
    );
    rail.position.set(0, 1.5, 0);
    group.add(rail);

    // Text Characters as Holographic cubes
    const sampleText = ['A', 'B', 'A', 'B', 'C', 'A', 'B', 'A'];
    sampleText.forEach((char, idx) => {
      const isMatch = idx >= 2 && idx <= 5;
      const charBlock = new THREE.Mesh(
        new THREE.BoxGeometry(1, 1, 1),
        new THREE.MeshStandardMaterial({
          color: isMatch ? 0x10b981 : 0x0284c7,
          emissive: isMatch ? 0x059669 : 0x0369a1,
          emissiveIntensity: isMatch ? 0.7 : 0.2,
          metalness: 0.7,
          wireframe
        })
      );
      const x = (idx - Math.floor(sampleText.length / 2)) * 1.5;
      charBlock.position.set(x, 2.5, 0);
      group.add(charBlock);
    });

    // Holographic Scanning Ring Arch
    const ringGeo = new THREE.TorusGeometry(2.5, 0.15, 16, 32);
    const ringMat = new THREE.MeshStandardMaterial({
      color: 0xef4444,
      emissive: 0xdc2626,
      emissiveIntensity: 0.8,
      wireframe
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.position.set(0, 2.5, 0);
    ring.userData = { isRotating: true };
    group.add(ring);
  };

  // =========================================================================
  // OOPM 3D OBJECT-ORIENTED WORLDS
  // =========================================================================

  // Exp 1: Cyber Terminal I/O Gateway (Scanner vs BufferedReader)
  const buildTerminalGateway3D = (group: THREE.Group, state: any) => {
    // Console Desk Platform
    const desk = new THREE.Mesh(
      new THREE.BoxGeometry(10, 0.4, 5),
      new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8, wireframe })
    );
    desk.position.set(0, 1, 0);
    group.add(desk);

    // Twin Holographic Input Tubes (Scanner = Cyan, BufferedReader = Emerald)
    [-3, 3].forEach((x, idx) => {
      const tube = new THREE.Mesh(
        new THREE.CylinderGeometry(0.8, 0.8, 5, 16),
        new THREE.MeshStandardMaterial({
          color: idx === 0 ? 0x06b6d4 : 0x10b981,
          transparent: true,
          opacity: 0.5,
          wireframe
        })
      );
      tube.position.set(x, 3.5, 0);
      group.add(tube);

      // Data Packet floating and moving up and down in tube
      const packet = new THREE.Mesh(
        new THREE.BoxGeometry(0.8, 0.8, 0.8),
        new THREE.MeshStandardMaterial({
          color: idx === 0 ? 0x38bdf8 : 0x34d399,
          emissive: idx === 0 ? 0x0284c7 : 0x059669,
          emissiveIntensity: 0.7,
          wireframe
        })
      );
      packet.position.set(x, 3.5, 0);
      packet.userData = {
        animate: (t: number, delta: number, mesh: THREE.Mesh) => {
          mesh.position.y = 3.5 + Math.sin(t * 3 + idx * 1.5) * 1.6;
          mesh.rotation.y += delta * 1.8;
          mesh.rotation.x += delta * 1.2;
        }
      };
      group.add(packet);
    });

    // Holographic Terminal Display Screen with animated pulse
    const screen = new THREE.Mesh(
      new THREE.BoxGeometry(4.5, 3, 0.2),
      new THREE.MeshStandardMaterial({ color: 0x0f172a, emissive: 0x1e3a8a, emissiveIntensity: 0.6, wireframe })
    );
    screen.position.set(0, 3.5, -1.5);
    screen.userData = {
      animate: (t: number, delta: number, mesh: THREE.Mesh) => {
        const mat = mesh.material as THREE.MeshStandardMaterial;
        mat.emissiveIntensity = 0.4 + Math.sin(t * 4) * 0.25;
      }
    };
    group.add(screen);
  };

  // Exp 2: Cyber ATM Vault (Menu-Driven State Machine)
  const buildAtmMachine3D = (group: THREE.Group, state: any) => {
    // ATM Kiosk Pillar
    const kiosk = new THREE.Mesh(
      new THREE.BoxGeometry(3.5, 6, 3),
      new THREE.MeshStandardMaterial({ color: 0x064e3b, metalness: 0.8, wireframe })
    );
    kiosk.position.set(0, 3, 0);
    group.add(kiosk);

    // Glowing ATM Monitor Display with scanline pulse
    const monitor = new THREE.Mesh(
      new THREE.BoxGeometry(2.4, 1.8, 0.2),
      new THREE.MeshStandardMaterial({ color: 0x10b981, emissive: 0x059669, emissiveIntensity: 0.8, wireframe })
    );
    monitor.position.set(0, 4.2, 1.55);
    group.add(monitor);

    // Digital Keypad Tray
    const keypad = new THREE.Mesh(
      new THREE.BoxGeometry(2.2, 0.2, 1.2),
      new THREE.MeshStandardMaterial({ color: 0x047857, metalness: 0.9, wireframe })
    );
    keypad.position.set(0, 2.8, 1.8);
    keypad.rotation.x = 0.4;
    group.add(keypad);

    // Cash Dispenser Slot & Animated Sliding Currency Bundle
    const cash = new THREE.Mesh(
      new THREE.BoxGeometry(1.6, 0.3, 0.8),
      new THREE.MeshStandardMaterial({ color: 0xfacc15, emissive: 0xeab308, emissiveIntensity: 0.7, wireframe })
    );
    cash.position.set(0, 1.8, 1.6);
    cash.userData = {
      animate: (t: number, delta: number, mesh: THREE.Mesh) => {
        mesh.position.z = 1.6 + Math.sin(t * 2.2) * 0.45;
      }
    };
    group.add(cash);

    // ATM Card sliding in and out
    const card = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, 0.08, 0.7),
      new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x0284c7, wireframe })
    );
    card.position.set(0.9, 3.4, 1.6);
    card.userData = {
      animate: (t: number, delta: number, mesh: THREE.Mesh) => {
        mesh.position.z = 1.6 + Math.sin(t * 2.5) * 0.35;
      }
    };
    group.add(card);

    // Rotating Vault Dial Cog on top
    const dial = new THREE.Mesh(
      new THREE.CylinderGeometry(0.7, 0.7, 0.15, 16),
      new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.9, wireframe })
    );
    dial.position.set(0, 5.3, 1.55);
    dial.rotation.x = Math.PI / 2;
    dial.userData = {
      animate: (t: number, delta: number, mesh: THREE.Mesh) => {
        mesh.rotation.z += delta * 1.6;
      }
    };
    group.add(dial);
  };

  // Exp 3 & 4: Object Foundry & Constructor Forge
  const buildObjectFoundry3D = (group: THREE.Group, state: any) => {
    // JVM Heap Platform
    const heap = new THREE.Mesh(
      new THREE.CylinderGeometry(6, 6.5, 0.6, 32),
      new THREE.MeshStandardMaterial({ color: 0x312e81, metalness: 0.8, wireframe })
    );
    heap.position.set(0, 0.3, 0);
    group.add(heap);

    // Central Blueprint Crystal spinning and pulsing
    const crystal = new THREE.Mesh(
      new THREE.OctahedronGeometry(1.8, 0),
      new THREE.MeshStandardMaterial({ color: 0x818cf8, emissive: 0x4f46e5, emissiveIntensity: 0.8, wireframe })
    );
    crystal.position.set(0, 4, 0);
    crystal.userData = {
      animate: (t: number, delta: number, mesh: THREE.Mesh) => {
        mesh.rotation.y += delta * 1.5;
        mesh.rotation.x += delta * 0.8;
        mesh.position.y = 4 + Math.sin(t * 2.5) * 0.3;
      }
    };
    group.add(crystal);

    // Robotic Stamper piston arm moving down and up
    const stamper = new THREE.Mesh(
      new THREE.CylinderGeometry(0.35, 0.5, 2, 16),
      new THREE.MeshStandardMaterial({ color: 0xf43f5e, metalness: 0.8, wireframe })
    );
    stamper.position.set(0, 3, 2.5);
    stamper.userData = {
      animate: (t: number, delta: number, mesh: THREE.Mesh) => {
        mesh.position.y = 2.8 + Math.abs(Math.sin(t * 2.5)) * 1.2;
      }
    };
    group.add(stamper);

    // Instantiated Object Blocks on Heap (Student instances bobbing & sliding)
    [-3.5, 0, 3.5].forEach((xPos, idx) => {
      const obj = new THREE.Mesh(
        new THREE.BoxGeometry(1.5, 1.5, 1.5),
        new THREE.MeshStandardMaterial({
          color: idx === 0 ? 0xf59e0b : idx === 1 ? 0x10b981 : 0xec4899,
          metalness: 0.6,
          wireframe
        })
      );
      obj.position.set(xPos, 1.2, 2.5);
      obj.userData = {
        animate: (t: number, delta: number, mesh: THREE.Mesh) => {
          mesh.rotation.y += delta * 0.8;
          mesh.position.y = 1.2 + Math.sin(t * 2.5 + idx) * 0.25;
        }
      };
      group.add(obj);

      // Reference pointer from stack to heap
      const beam = new THREE.Mesh(
        new THREE.CylinderGeometry(0.04, 0.04, 3, 8),
        new THREE.MeshStandardMaterial({ color: 0xa5b4fc, emissive: 0x6366f1, wireframe })
      );
      beam.position.set(xPos * 0.5, 2.6, 1.25);
      beam.rotation.x = 0.5;
      group.add(beam);
    });
  };

  // Exp 5: Medical Hierarchy Polymorphism
  const buildMedicalPolymorphism3D = (group: THREE.Group, state: any) => {
    // Diagnostic Stand
    const stand = new THREE.Mesh(
      new THREE.CylinderGeometry(5, 5.5, 0.5, 24),
      new THREE.MeshStandardMaterial({ color: 0x881337, metalness: 0.7, wireframe })
    );
    stand.position.set(0, 0.25, 0);
    group.add(stand);

    // Revolving Carousel Holding Test Tubes
    const carousel = new THREE.Group();
    carousel.position.set(0, 0, 0);
    carousel.userData = {
      animate: (t: number, delta: number, g: THREE.Group) => {
        g.rotation.y += delta * 0.7;
      }
    };
    group.add(carousel);

    // 3 Test Tubes in Carousel (Urine, Blood, Glucose)
    const tubeColors = [0xfacc15, 0xdc2626, 0x38bdf8];
    [-2.5, 0, 2.5].forEach((x, idx) => {
      const tubeGeo = new THREE.CylinderGeometry(0.5, 0.5, 3.5, 16);
      const tubeMat = new THREE.MeshStandardMaterial({
        color: tubeColors[idx],
        emissive: tubeColors[idx],
        emissiveIntensity: 0.5,
        transparent: true,
        opacity: 0.7,
        wireframe
      });
      const tube = new THREE.Mesh(tubeGeo, tubeMat);
      tube.position.set(x, 2.2, 0);
      carousel.add(tube);
    });

    // Dynamic Dispatch Scanning Laser Arch oscillating back and forth
    const arch = new THREE.Mesh(
      new THREE.TorusGeometry(3.5, 0.1, 16, 32, Math.PI),
      new THREE.MeshStandardMaterial({ color: 0xf43f5e, emissive: 0xe11d48, emissiveIntensity: 0.8, wireframe })
    );
    arch.position.set(0, 2, 0);
    arch.userData = {
      animate: (t: number, delta: number, mesh: THREE.Mesh) => {
        mesh.rotation.y = Math.sin(t * 1.8) * 0.5;
      }
    };
    group.add(arch);
  };

  // Exp 6: Interface Weather Mesh
  const buildInterfaceWeather3D = (group: THREE.Group, state: any) => {
    // Weather Sensor Base
    const base = new THREE.Mesh(
      new THREE.BoxGeometry(8, 0.4, 8),
      new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.8, wireframe })
    );
    base.position.set(0, 0.2, 0);
    group.add(base);

    // Central Weather Antenna Mast
    const mast = new THREE.Mesh(
      new THREE.CylinderGeometry(0.15, 0.3, 7, 12),
      new THREE.MeshStandardMaterial({ color: 0x38bdf8, metalness: 0.9, wireframe })
    );
    mast.position.set(0, 3.5, 0);
    group.add(mast);

    // Radar dish spinning 360 degrees
    const dish = new THREE.Mesh(
      new THREE.ConeGeometry(1.2, 0.6, 16),
      new THREE.MeshStandardMaterial({ color: 0x38bdf8, wireframe })
    );
    dish.position.set(0, 7.2, 0);
    dish.userData = {
      animate: (t: number, delta: number, mesh: THREE.Mesh) => {
        mesh.rotation.y += delta * 2.2;
      }
    };
    group.add(dish);

    // Decoupled Interface Contract Rings bobbing and rotating
    [2, 4, 6].forEach((yPos, i) => {
      const ring = new THREE.Mesh(
        new THREE.TorusGeometry(1.6 + i * 0.4, 0.08, 12, 24),
        new THREE.MeshStandardMaterial({
          color: 0x06b6d4,
          emissive: 0x0891b2,
          emissiveIntensity: 0.7,
          wireframe
        })
      );
      ring.position.set(0, yPos, 0);
      ring.rotation.x = Math.PI / 2;
      ring.userData = {
        animate: (t: number, delta: number, mesh: THREE.Mesh) => {
          mesh.rotation.z += delta * (i % 2 === 0 ? 1.2 : -1.2);
          mesh.position.y = yPos + Math.sin(t * 2 + i) * 0.35;
        }
      };
      group.add(ring);
    });
  };

  // Exp 7: Exception Shield & InsufficientBalance Guard
  const buildExceptionShield3D = (group: THREE.Group, state: any) => {
    // Bank Core Vault
    const vault = new THREE.Mesh(
      new THREE.BoxGeometry(3, 3, 3),
      new THREE.MeshStandardMaterial({ color: 0xca8a04, metalness: 0.9, roughness: 0.2, wireframe })
    );
    vault.position.set(0, 2, 0);
    group.add(vault);

    // Hexagonal Protective Forcefield Dome rotating and pulsating
    const shield = new THREE.Mesh(
      new THREE.IcosahedronGeometry(3.5, 1),
      new THREE.MeshStandardMaterial({
        color: 0xef4444,
        emissive: 0xdc2626,
        emissiveIntensity: 0.6,
        transparent: true,
        opacity: 0.4,
        wireframe: true
      })
    );
    shield.position.set(0, 2, 0);
    shield.userData = {
      animate: (t: number, delta: number, mesh: THREE.Mesh) => {
        mesh.rotation.y += delta * 0.8;
        mesh.rotation.x += delta * 0.5;
        const scale = 1 + Math.sin(t * 4) * 0.08;
        mesh.scale.set(scale, scale, scale);
      }
    };
    group.add(shield);

    // Deflected Exception Lightning Spikes
    for (let i = 0; i < 4; i++) {
      const spike = new THREE.Mesh(
        new THREE.ConeGeometry(0.2, 2, 8),
        new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xef4444, wireframe })
      );
      const ang = (i * Math.PI) / 2;
      spike.position.set(Math.cos(ang) * 4.2, 2, Math.sin(ang) * 4.2);
      spike.rotation.z = Math.PI / 2;
      spike.userData = {
        animate: (t: number, delta: number, mesh: THREE.Mesh) => {
          mesh.rotation.x += delta * 3;
        }
      };
      group.add(spike);
    }
  };

  // Exp 8: Disk Archivist File Vault
  const buildDiskArchivist3D = (group: THREE.Group, state: any) => {
    // Hard Drive Chassis
    const chassis = new THREE.Mesh(
      new THREE.BoxGeometry(8, 0.8, 8),
      new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.9, wireframe })
    );
    chassis.position.set(0, 0.4, 0);
    group.add(chassis);

    // Magnetic Storage Platter spinning fast
    const platter = new THREE.Mesh(
      new THREE.CylinderGeometry(3.2, 3.2, 0.2, 32),
      new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.95, roughness: 0.1, wireframe })
    );
    platter.position.set(0, 1.0, 0);
    platter.userData = {
      animate: (t: number, delta: number, mesh: THREE.Mesh) => {
        mesh.rotation.y += delta * 8;
      }
    };
    group.add(platter);

    // Laser Read/Write Head Arm sweeping back and forth
    const arm = new THREE.Mesh(
      new THREE.BoxGeometry(3.5, 0.1, 0.4),
      new THREE.MeshStandardMaterial({ color: 0xef4444, emissive: 0xdc2626, emissiveIntensity: 0.7, wireframe })
    );
    arm.position.set(1.5, 1.4, 1.2);
    arm.rotation.y = -0.5;
    arm.userData = {
      animate: (t: number, delta: number, mesh: THREE.Mesh) => {
        mesh.rotation.y = -0.5 + Math.sin(t * 2.5) * 0.35;
      }
    };
    group.add(arm);
  };

  // Exp 9: Thread Worker Trio (Random, Square, Cube)
  const buildThreadTriCore3D = (group: THREE.Group, state: any) => {
    // CPU Socket Plate
    const cpu = new THREE.Mesh(
      new THREE.BoxGeometry(8, 0.4, 8),
      new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.9, wireframe })
    );
    cpu.position.set(0, 0.2, 0);
    group.add(cpu);

    // 3 Thread Cores (Thread 1: Random, Thread 2: Square, Thread 3: Cube)
    const threadColors = [0x10b981, 0x06b6d4, 0xf59e0b];
    const threadPositions = [
      [-2.5, 1.5, 0],
      [2.5, 1.5, -2],
      [2.5, 1.5, 2]
    ];

    threadPositions.forEach(([tx, ty, tz], idx) => {
      const core = new THREE.Mesh(
        new THREE.CylinderGeometry(1.2, 1.4, 2.5, 16),
        new THREE.MeshStandardMaterial({
          color: threadColors[idx],
          emissive: threadColors[idx],
          emissiveIntensity: 0.6,
          metalness: 0.6,
          wireframe
        })
      );
      core.position.set(tx, ty, tz);
      core.userData = {
        animate: (t: number, delta: number, mesh: THREE.Mesh) => {
          mesh.position.y = ty + Math.sin(t * 3 + idx * 1.8) * 0.3;
        }
      };
      group.add(core);

      // Rotating Energy Orbit on Core
      const orbit = new THREE.Mesh(
        new THREE.TorusGeometry(1.6, 0.06, 8, 24),
        new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: threadColors[idx], wireframe })
      );
      orbit.position.set(tx, ty + 1.5, tz);
      orbit.userData = {
        animate: (t: number, delta: number, mesh: THREE.Mesh) => {
          mesh.rotation.x += delta * (idx + 1) * 1.5;
          mesh.rotation.y += delta * (idx + 1) * 1.0;
        }
      };
      group.add(orbit);
    });
  };

  // Exp 10: Mutex Train Station (Berth Booking Critical Section)
  const buildMutexTrain3D = (group: THREE.Group, state: any) => {
    // Railway Track Rails
    [-1.5, 1.5].forEach((z) => {
      const rail = new THREE.Mesh(
        new THREE.BoxGeometry(14, 0.2, 0.3),
        new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.9, wireframe })
      );
      rail.position.set(0, 0.1, z);
      group.add(rail);
    });

    // Train Group moving forward and backward along track
    const trainGroup = new THREE.Group();
    trainGroup.position.set(0, 0, 0);
    trainGroup.userData = {
      animate: (t: number, delta: number, g: THREE.Group) => {
        g.position.x = Math.sin(t * 0.9) * 4.5;
      }
    };
    group.add(trainGroup);

    // Train Carriage
    const carriage = new THREE.Mesh(
      new THREE.BoxGeometry(9, 3.2, 3),
      new THREE.MeshStandardMaterial({ color: 0x1e3a8a, metalness: 0.7, wireframe })
    );
    carriage.position.set(0, 1.8, 0);
    trainGroup.add(carriage);

    // Glowing Berth Compartment Windows (Berth 1 and Berth 2)
    [-2, 2].forEach((x) => {
      const win = new THREE.Mesh(
        new THREE.BoxGeometry(1.4, 1.2, 3.1),
        new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x0284c7, emissiveIntensity: 0.8, wireframe })
      );
      win.position.set(x, 2.2, 0);
      trainGroup.add(win);
    });

    // Spinning Wheels on train
    [-3, 0, 3].forEach((wx) => {
      const wheel = new THREE.Mesh(
        new THREE.CylinderGeometry(0.5, 0.5, 0.2, 16),
        new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.8, wireframe })
      );
      wheel.position.set(wx, 0.5, 1.6);
      wheel.rotation.x = Math.PI / 2;
      wheel.userData = {
        animate: (t: number, delta: number, mesh: THREE.Mesh) => {
          mesh.rotation.z += delta * 8 * Math.cos(t * 0.9);
        }
      };
      trainGroup.add(wheel);
    });

    // Steam Puffs rising from locomotive chimney
    for (let p = 0; p < 3; p++) {
      const puff = new THREE.Mesh(
        new THREE.SphereGeometry(0.4, 8, 8),
        new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0.5, wireframe })
      );
      puff.position.set(3.5, 3.6, 0);
      puff.userData = {
        animate: (t: number, delta: number, mesh: THREE.Mesh) => {
          mesh.position.y = 3.6 + ((t * 2.5 + p * 0.9) % 3);
          const s = 0.3 + ((t * 2.5 + p * 0.9) % 3) * 0.35;
          mesh.scale.set(s, s, s);
        }
      };
      trainGroup.add(puff);
    }

    // Mutex Turnstile Barrier
    const turnstile = new THREE.Mesh(
      new THREE.CylinderGeometry(0.3, 0.4, 3, 12),
      new THREE.MeshStandardMaterial({ color: 0xef4444, emissive: 0xdc2626, emissiveIntensity: 0.8, wireframe })
    );
    turnstile.position.set(-5.5, 1.5, 2.5);
    group.add(turnstile);
  };

  const buildDefaultGame3D = (group: THREE.Group, state: any) => {
    const geo = new THREE.TorusKnotGeometry(2, 0.6, 64, 16);
    const mat = new THREE.MeshStandardMaterial({ color: 0xef4444, wireframe });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.y = 3;
    mesh.userData = { isRotating: true };
    group.add(mesh);
  };

  return (
    <div
      className={`relative rounded-2xl overflow-hidden border border-zinc-800 bg-zinc-950 shadow-2xl ${
        isFullscreen ? 'fixed inset-0 z-50 rounded-none' : 'w-full h-[380px] sm:h-[460px]'
      }`}
    >
      {/* Three.js Canvas Container */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Floating 3D HUD Header */}
      <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none z-10">
        <div className="flex items-center gap-2 pointer-events-auto">
          <span className="px-2.5 py-1 bg-black/60 backdrop-blur-md rounded-lg text-xs font-mono font-bold text-red-400 border border-red-500/30 flex items-center gap-1.5 shadow-lg">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span>3D WEBGL ENGINE ACTIVE</span>
          </span>
          <span className="hidden sm:inline-block px-2.5 py-1 bg-black/60 backdrop-blur-md rounded-lg text-[11px] font-mono text-zinc-300 border border-zinc-800">
            Drag to Rotate · Scroll to Zoom
          </span>
        </div>

        {/* 3D Controls */}
        <div className="flex items-center gap-1.5 pointer-events-auto">
          <button
            onClick={() => setAutoRotate(!autoRotate)}
            className={`p-1.5 rounded-lg text-xs transition-colors cursor-pointer backdrop-blur-md border ${
              autoRotate
                ? 'bg-red-700 text-white border-red-500'
                : 'bg-black/60 text-zinc-300 border-zinc-700 hover:bg-zinc-800'
            }`}
            title="Toggle Auto-Orbit Rotation"
          >
            <Compass className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setWireframe(!wireframe)}
            className={`p-1.5 rounded-lg text-xs transition-colors cursor-pointer backdrop-blur-md border ${
              wireframe
                ? 'bg-amber-600 text-white border-amber-500'
                : 'bg-black/60 text-zinc-300 border-zinc-700 hover:bg-zinc-800'
            }`}
            title="Toggle Wireframe View"
          >
            <Eye className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={handleResetCamera}
            className="p-1.5 bg-black/60 hover:bg-zinc-800 text-zinc-300 rounded-lg text-xs transition-colors cursor-pointer backdrop-blur-md border border-zinc-700"
            title="Reset Camera View"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-1.5 bg-black/60 hover:bg-zinc-800 text-zinc-300 rounded-lg text-xs transition-colors cursor-pointer backdrop-blur-md border border-zinc-700"
            title={isFullscreen ? 'Exit Fullscreen' : 'Enter 3D Fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Floating Bottom Status HUD */}
      <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between pointer-events-none z-10 text-xs font-mono">
        <div className="px-3 py-1.5 bg-black/75 backdrop-blur-md rounded-xl text-zinc-200 border border-zinc-800 pointer-events-auto max-w-md truncate">
          <span className="text-emerald-400 font-bold mr-1">3D ACTION:</span>
          <span>{gameState.message || 'Scene initialized in real-time WebGL.'}</span>
        </div>

        <div className="hidden sm:flex items-center gap-2 px-2.5 py-1 bg-black/75 backdrop-blur-md rounded-xl text-zinc-400 border border-zinc-800 text-[10px]">
          <span>60 FPS</span>
          <span>·</span>
          <span>Perspective: 45°</span>
        </div>
      </div>
    </div>
  );
};
