import React from 'react';

interface CartoonRoboticFaceProps {
  emotion?: 'cool' | 'thinking' | 'alarmed' | 'happy' | 'determined' | 'cheering';
  isAnalyzing?: boolean;
  size?: number;
  className?: string;
}

export const CartoonRoboticFace: React.FC<CartoonRoboticFaceProps> = ({
  emotion = 'happy',
  isAnalyzing = false,
  size = 76,
  className = ''
}) => {
  const isAlarmed = emotion === 'alarmed';
  const isThinking = emotion === 'thinking' || isAnalyzing;
  const isCheering = emotion === 'cheering' || emotion === 'happy';

  // Warm, clean LED accents (Warm amber/gold, clean white, or soft red on alarm - no neon blue)
  const eyeColor = isAlarmed ? '#ef4444' : isThinking ? '#f59e0b' : '#fbbf24';

  return (
    <div
      className={`relative flex items-center justify-center select-none ${className}`}
      style={{ width: size, height: size }}
    >
      {/* Subtle clean neutral backdrop ring (no neon glow) */}
      <div className="absolute inset-0 rounded-2xl bg-zinc-900/80 border border-zinc-800" />

      {/* Clean Cartoon Robot Visage SVG */}
      <svg
        viewBox="0 0 100 100"
        className="w-[90%] h-[90%] relative z-10 drop-shadow-sm"
      >
        <defs>
          {/* Clean Ceramic / Titanium Metallic Head Gradient */}
          <linearGradient id="cleanRobotHeadGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#f8fafc" />
            <stop offset="70%" stopColor="#e2e8f0" />
            <stop offset="100%" stopColor="#cbd5e1" />
          </linearGradient>

          {/* Clean Dark Onyx Visor Screen */}
          <linearGradient id="cleanRobotScreenGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#18181b" />
            <stop offset="100%" stopColor="#09090b" />
          </linearGradient>

          {/* Clean Ear Dials Gradient */}
          <linearGradient id="cleanEarGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#94a3b8" />
            <stop offset="100%" stopColor="#64748b" />
          </linearGradient>
        </defs>

        {/* 1. Antenna */}
        <line
          x1="50"
          y1="23"
          x2="50"
          y2="9"
          stroke="#94a3b8"
          strokeWidth="3"
          strokeLinecap="round"
        />
        {/* Antenna Base Collar */}
        <rect x="46" y="20" width="8" height="4" rx="1.5" fill="#64748b" />
        {/* Antenna Bulb (Warm amber/gold LED) */}
        <circle
          cx="50"
          cy="8"
          r="5"
          fill={eyeColor}
          className={isThinking ? 'animate-bounce' : ''}
        />

        {/* 2. Side Ear Bolts / Audio Sensors */}
        <rect x="11" y="39" width="7" height="22" rx="3" fill="url(#cleanEarGrad)" stroke="#475569" strokeWidth="1" />
        <circle cx="14.5" cy="50" r="2" fill={eyeColor} opacity="0.9" />
        <rect x="82" y="39" width="7" height="22" rx="3" fill="url(#cleanEarGrad)" stroke="#475569" strokeWidth="1" />
        <circle cx="85.5" cy="50" r="2" fill={eyeColor} opacity="0.9" />

        {/* 3. Main Sleek Rounded Robot Head */}
        <rect
          x="17"
          y="23"
          width="66"
          height="60"
          rx="16"
          fill="url(#cleanRobotHeadGrad)"
          stroke="#94a3b8"
          strokeWidth="2"
        />

        {/* Top Gloss Highlight */}
        <path
          d="M 28 27 Q 50 24 72 27"
          stroke="rgba(255, 255, 255, 0.9)"
          strokeWidth="2.5"
          strokeLinecap="round"
          fill="none"
        />

        {/* 4. Dark Visor Screen */}
        <rect
          x="25"
          y="33"
          width="50"
          height="34"
          rx="10"
          fill="url(#cleanRobotScreenGrad)"
          stroke="#3f3f46"
          strokeWidth="1.5"
        />

        {/* 5. Animated Warm Amber Eyes inside Screen */}
        {isAlarmed ? (
          /* Alarmed / Shocked wide glowing eyes */
          <g>
            <circle cx="38" cy="48" r="7" fill="#ef4444" stroke="#ffffff" strokeWidth="1.5" />
            <circle cx="62" cy="48" r="7" fill="#ef4444" stroke="#ffffff" strokeWidth="1.5" />
            <circle cx="38" cy="48" r="2.5" fill="#ffffff" />
            <circle cx="62" cy="48" r="2.5" fill="#ffffff" />
          </g>
        ) : isThinking ? (
          /* Thinking Eyes: Inquiring eye + raised brow */
          <g>
            <line x1="33" y1="49" x2="43" y2="49" stroke="#fbbf24" strokeWidth="3" strokeLinecap="round" />
            <circle cx="61" cy="48" r="5.5" fill="#fbbf24" />
            <circle cx="63" cy="46" r="2" fill="#ffffff" />
            <path d="M 56 38 Q 62 34 68 38" stroke="#fbbf24" strokeWidth="2" fill="none" strokeLinecap="round" />
          </g>
        ) : isCheering ? (
          /* Cheerful Happy Arc Eyes (^_^) */
          <g>
            <path
              d="M 33 50 Q 38 42 43 50"
              stroke="#fbbf24"
              strokeWidth="3.5"
              fill="none"
              strokeLinecap="round"
            />
            <path
              d="M 57 50 Q 62 42 67 50"
              stroke="#fbbf24"
              strokeWidth="3.5"
              fill="none"
              strokeLinecap="round"
            />
            {/* Soft subtle cheek blush */}
            <ellipse cx="30" cy="57" rx="3" ry="1.5" fill="#f87171" opacity="0.6" />
            <ellipse cx="70" cy="57" rx="3" ry="1.5" fill="#f87171" opacity="0.6" />
          </g>
        ) : (
          /* Friendly Crisp Eyes */
          <g>
            <ellipse cx="38" cy="48" rx="5" ry="5.5" fill="#fbbf24" />
            <ellipse cx="62" cy="48" rx="5" ry="5.5" fill="#fbbf24" />
            <circle cx="39" cy="46" r="1.8" fill="#ffffff" />
            <circle cx="63" cy="46" r="1.8" fill="#ffffff" />
          </g>
        )}

        {/* 6. Friendly Mouth */}
        {isAlarmed ? (
          <ellipse cx="50" cy="60" rx="3.5" ry="2.5" fill="#ef4444" />
        ) : isThinking ? (
          <line x1="46" y1="60" x2="54" y2="60" stroke="#fbbf24" strokeWidth="2" strokeLinecap="round" />
        ) : (
          <path
            d="M 44 58 Q 50 64 56 58"
            stroke="#fbbf24"
            strokeWidth="2.5"
            fill="none"
            strokeLinecap="round"
          />
        )}

        {/* 7. Bottom Neck Joint */}
        <rect x="43" y="83" width="14" height="6" rx="2" fill="#64748b" stroke="#475569" strokeWidth="1" />
      </svg>
    </div>
  );
};

export const RealisticRoboticFace = CartoonRoboticFace;
