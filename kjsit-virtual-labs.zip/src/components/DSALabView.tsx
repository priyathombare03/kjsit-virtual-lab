import React, { useState } from 'react';
import {
  Layers,
  ArrowLeft,
  ArrowRight,
  Search,
  BookOpen,
  CheckCircle2,
  Filter,
  Sparkles,
  GraduationCap,
  Gamepad2,
  Box,
  Zap,
  Film
} from 'lucide-react';
import { DSA_EXPERIMENTS } from '../data/dsaExperiments';
import { LabExperiment, UserSession } from '../types';
import { LaunchLabArrow } from './LaunchLabArrow';
import { DsaInBuiltGameArena, EXPERIMENT_GAMES } from './DsaInBuiltGameArena';

interface DSALabViewProps {
  onSelectExperiment: (experimentId: string) => void;
  onBackToLabs: () => void;
  userSession: UserSession | null;
}

export const DSALabView: React.FC<DSALabViewProps> = ({
  onSelectExperiment,
  onBackToLabs,
  userSession
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [search, setSearch] = useState<string>('');
  const [showGameArena, setShowGameArena] = useState<boolean>(false);
  const [activeGameExpId, setActiveGameExpId] = useState<string>('stack-adt-linked-list');

  const categories = [
    'All',
    'Linear Data Structures',
    'Trees & Hierarchical',
    'Graph Algorithms',
    'Sorting & Searching'
  ];

  const filteredExperiments = DSA_EXPERIMENTS.filter((exp) => {
    if (selectedCategory !== 'All' && exp.category !== selectedCategory) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        exp.title.toLowerCase().includes(q) ||
        exp.subtitle.toLowerCase().includes(q) ||
        exp.category.toLowerCase().includes(q) ||
        exp.aim.toLowerCase().includes(q) ||
        (exp.software && exp.software.toLowerCase().includes(q)) ||
        (exp.iitReference && exp.iitReference.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const getCategoryBadgeColor = (category: string) => {
    switch (category) {
      case 'Linear Data Structures':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Trees & Hierarchical':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'Graph Algorithms':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Sorting & Searching':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  return (
    <div className="py-10 bg-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb & Navigation */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <button
            onClick={onBackToLabs}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-white border border-zinc-300 rounded-xl text-xs font-bold text-zinc-800 hover:bg-zinc-100 transition-colors shadow-2xs cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to All Laboratories</span>
          </button>

          <div className="flex items-center gap-2 text-xs text-zinc-500">
            <span>Home</span>
            <span>/</span>
            <span>Virtual Labs</span>
            <span>/</span>
            <span className="font-bold text-red-700">DSA Laboratory (AIL302)</span>
          </div>
        </div>

        {/* If Game Arena Mode is Active */}
        {showGameArena ? (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-zinc-200">
              <button
                onClick={() => setShowGameArena(false)}
                className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-zinc-300 rounded-xl text-xs font-bold text-zinc-800 hover:bg-zinc-100 transition-colors shadow-2xs cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back to DSA Experiments Grid</span>
              </button>

              <div className="flex items-center gap-2 text-xs font-mono text-zinc-500">
                <Gamepad2 className="w-4 h-4 text-red-600" />
                <span>CodinGame 2D/3D Video Game Arena</span>
              </div>
            </div>

            <DsaInBuiltGameArena
              experimentId={activeGameExpId}
              experimentTitle={
                DSA_EXPERIMENTS.find((e) => e.id === activeGameExpId)?.title ||
                EXPERIMENT_GAMES[activeGameExpId]?.title ||
                'DSA Algorithmic Game'
              }
              onProceedToSelfEvaluation={() => setShowGameArena(false)}
            />
          </div>
        ) : (
          <>
            {/* Subject Header Banner */}
            <div className="bg-black text-white rounded-2xl p-6 sm:p-8 shadow-sm mb-6 relative overflow-hidden border border-zinc-900">
              <div className="max-w-3xl relative z-10">
                <h2 className="text-2xl sm:text-3xl font-black tracking-tight mb-2">
                  Data Structure and Algorithms Laboratory
                </h2>
                <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed max-w-2xl mb-5">
                  Master stacks, linear queues, infix-to-postfix expression parsing, polynomial arithmetic with dynamic linked lists, binary search trees, graph traversals, and applied sorting algorithms.
                </p>

                {/* Quick stats */}
                <div className="flex flex-wrap gap-3 text-xs font-medium">
                  <div className="flex items-center gap-1.5 bg-zinc-900 border border-zinc-800 px-3 py-1.5 rounded-lg text-zinc-200">
                    <BookOpen className="w-3.5 h-3.5 text-red-500" />
                    <span>8 Curriculum Experiments</span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-zinc-900 border border-zinc-800 px-3 py-1.5 rounded-lg text-zinc-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-red-500" />
                    <span>Interactive DOM Simulators Active</span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-zinc-900 border border-zinc-800 px-3 py-1.5 rounded-lg text-zinc-200">
                    <GraduationCap className="w-3.5 h-3.5 text-red-500" />
                    <span>Course Code: AIL302</span>
                  </div>
                </div>
              </div>

              <div className="absolute right-0 top-0 bottom-0 w-1/3 opacity-10 flex items-center justify-end pointer-events-none pr-8">
                <Layers className="w-72 h-72 text-white" />
              </div>
            </div>

            {/* CodinGame Video Game Arena Showcase Banner */}
            <div className="bg-gradient-to-r from-red-950 via-zinc-900 to-black border border-red-500/30 rounded-2xl p-6 sm:p-7 mb-8 text-white shadow-lg relative overflow-hidden">
              <div className="absolute right-0 top-0 bottom-0 w-1/2 opacity-15 pointer-events-none flex items-center justify-end pr-6">
                <Gamepad2 className="w-64 h-64 text-red-400" />
              </div>

              <div className="relative z-10 max-w-2xl space-y-3">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-2.5 py-1 bg-red-600/30 border border-red-500/40 rounded-lg text-xs font-bold text-red-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-red-400" />
                    <span>Enhanced CodinGame Gaming Hub</span>
                  </span>
                  <span className="px-2.5 py-1 bg-white/10 rounded-lg text-xs font-mono text-zinc-300">
                    8 Algorithmic Video Games
                  </span>
                  <span className="px-2.5 py-1 bg-sky-500/20 text-sky-300 rounded-lg text-xs font-bold">
                    3D WebGL · 2D Arcade · AI Video Cutscenes
                  </span>
                </div>

                <h3 className="text-xl sm:text-2xl font-black tracking-tight text-white drop-shadow-sm">
                  CodinGame Video Game Arena & 3D Arcade
                </h3>
                <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed font-normal">
                  Challenge yourself with immersive 2D/3D video simulations, realistic cinematic mission briefings, real-time particle simulations, and multi-language bot solvers for all 8 DSA experiments!
                </p>

                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <button
                    onClick={() => {
                      setActiveGameExpId('stack-adt-linked-list');
                      setShowGameArena(true);
                    }}
                    className="px-5 py-2.5 bg-red-700 hover:bg-red-800 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-md shadow-red-700/30 transition-all cursor-pointer hover:scale-105"
                  >
                    <Gamepad2 className="w-4 h-4" />
                    <span>Launch 2D/3D Gaming Arena</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <div className="flex items-center gap-1.5 overflow-x-auto py-1">
                    {[
                      { id: 'stack-adt-linked-list', label: 'Bracket Dungeon' },
                      { id: 'linear-queue-adt', label: 'Runway ATC' },
                      { id: 'infix-to-postfix', label: 'Asteroid Cannon' },
                      { id: 'sorting-algorithms-application', label: 'Cargo Crane' }
                    ].map((g) => (
                      <button
                        key={g.id}
                        onClick={() => {
                          setActiveGameExpId(g.id);
                          setShowGameArena(true);
                        }}
                        className="px-3 py-1.5 bg-white/10 hover:bg-white/20 border border-white/10 rounded-lg text-xs font-medium text-zinc-200 transition-colors cursor-pointer whitespace-nowrap"
                      >
                        {g.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

        {/* Search and Category Filters */}
        <div className="bg-white border border-zinc-200 rounded-xl p-4 mb-8 shadow-2xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
            <Filter className="w-4 h-4 text-zinc-400 mr-1 shrink-0" />
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-red-700 text-white shadow-2xs'
                    : 'text-zinc-700 hover:bg-zinc-100'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative min-w-[240px]">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search DSA experiment or topic..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-zinc-50 border border-zinc-300 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-600 focus:bg-white transition-all"
            />
          </div>
        </div>

        {/* Experiments Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {filteredExperiments.map((exp, index) => (
            <div
              key={exp.id}
              onClick={() => onSelectExperiment(exp.id)}
              className="bg-red-900/90 backdrop-blur-md border border-red-500/30 rounded-xl flex flex-col justify-between hover:border-red-400 hover:shadow-[0_8px_32px_rgba(185,28,28,0.4)] transition-all group cursor-pointer relative overflow-hidden"
            >
              {/* Optional glassy reflection layer */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
              
              <div className="p-3.5 relative z-10">
                {/* Exp Number + Title beside it */}
                <div className="flex items-start gap-2.5">
                  <span className="w-6 h-6 rounded-md bg-white/20 text-white font-mono text-[11px] font-bold flex items-center justify-center shrink-0 mt-0.5 border border-white/20 shadow-inner">
                    #{exp.num}
                  </span>
                  <div className="min-w-0 flex-1">
                    <h3 className="text-sm font-extrabold text-white group-hover:text-red-100 transition-colors leading-tight drop-shadow-sm">
                      {exp.title}
                    </h3>
                  </div>
                </div>
              </div>

              {/* Card Footer */}
              <div className="px-3.5 py-2.5 bg-red-950/60 border-t border-red-800/50 flex items-center justify-between gap-2 mt-auto relative z-10">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveGameExpId(exp.id);
                    setShowGameArena(true);
                  }}
                  className="px-2.5 py-1.5 bg-red-700/80 hover:bg-red-600 text-white text-[11px] font-bold rounded-lg border border-red-500/40 shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
                  title={`Play CodinGame: ${exp.title}`}
                >
                  <Gamepad2 className="w-3.5 h-3.5" />
                  <span>Play 2D/3D</span>
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectExperiment(exp.id);
                  }}
                  className="launch-lab-btn px-3 py-1.5 bg-white/15 hover:bg-white/25 active:bg-white/35 text-white text-xs font-bold rounded-lg border border-white/20 hover:border-white/35 shadow-xs hover:shadow-md transition-all duration-200 flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer backdrop-blur-sm select-none"
                  title={`Launch Lab: ${exp.title}`}
                >
                  <span>Launch Lab</span>
                  <LaunchLabArrow />
                </button>
              </div>
            </div>
          ))}
        </div>

        {filteredExperiments.length === 0 && (
          <div className="bg-white border border-zinc-200 rounded-2xl p-12 text-center text-zinc-500">
            <Layers className="w-12 h-12 text-zinc-300 mx-auto mb-3" />
            <h4 className="text-sm font-bold text-zinc-700 mb-1">No DSA Experiments Found</h4>
            <p className="text-xs text-zinc-400">
              Try adjusting your search keywords or filter category.
            </p>
          </div>
        )}
      </>
    )}
  </div>
</div>
);
};
