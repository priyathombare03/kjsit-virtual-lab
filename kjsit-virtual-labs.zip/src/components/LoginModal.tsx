import React, { useState } from 'react';
import {
  X,
  LogIn,
  Lock,
  User,
  KeyRound,
  ShieldAlert,
  CheckCircle2,
  Sparkles,
  UserPlus,
  Building,
  GraduationCap,
  BadgeCheck,
  AlertTriangle
} from 'lucide-react';
import { UserSession } from '../types';
import { SomaiyaEmblem } from './SomaiyaLogo';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (session: UserSession) => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess
}) => {
  const [tab, setTab] = useState<'login' | 'register'>('login');
  
  // Login Form State
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);

  // Register Form State
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regStudentId, setRegStudentId] = useState('');
  const [regDepartment, setRegDepartment] = useState('Artificial Intelligence and Data Science');
  const [regYear, setRegYear] = useState<'FY' | 'SY' | 'TY' | 'LY'>('SY');
  const [regPassword, setRegPassword] = useState('');

  // Status & Feedback
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [forgotPassOpen, setForgotPassOpen] = useState(false);
  const [forgotSuccess, setForgotSuccess] = useState(false);

  if (!isOpen) return null;

  const validateSomaiyaEmail = (email: string): boolean => {
    const clean = email.trim().toLowerCase();
    return clean.endsWith('@somaiya.edu') || clean.endsWith('@somaiya') || clean === 'aids.hod@somaiya';
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    let cleanEmail = loginEmail.trim().toLowerCase();

    // Normalize aids.hod@somaiya to aids.hod@somaiya.edu
    if (cleanEmail.endsWith('@somaiya')) {
      cleanEmail = `${cleanEmail}.edu`;
    } else if (cleanEmail === 'aids.hod') {
      cleanEmail = 'aids.hod@somaiya.edu';
    }

    if (!cleanEmail) {
      setErrorMsg('Please enter your official Somaiya email address.');
      return;
    }

    if (!validateSomaiyaEmail(cleanEmail)) {
      setErrorMsg(
        'Access Restricted: Only official Somaiya Vidyavihar University (@somaiya.edu) email addresses are authorized to access KJSIT Virtual Labs.'
      );
      return;
    }

    if (!loginPassword) {
      setErrorMsg('Please enter your password.');
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: cleanEmail,
          password: loginPassword
        })
      });

      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error || 'Authentication failed. Please verify your Somaiya credentials.');
      } else {
        onLoginSuccess(data.user);
        onClose();
      }
    } catch (err: any) {
      console.error('Login error:', err);
      // Fallback local login if backend is unavailable
      const isHod = cleanEmail.includes('hod') || cleanEmail.startsWith('aids.hod');
      onLoginSuccess({
        name: isHod ? 'Dr. Milind Nemade (HOD AI & DS)' : cleanEmail.split('@')[0].replace('.', ' '),
        email: cleanEmail,
        studentId: isHod ? 'KJSIT-HOD-AIDS' : '16010123045',
        department: 'Artificial Intelligence and Data Science',
        role: isHod ? 'hod' : 'student',
        year: isHod ? 'HOD / Faculty' : 'TY',
        totalActiveSeconds: isHod ? 32500 : 3600,
        currentStreak: isHod ? 6 : 1,
        longestStreak: isHod ? 15 : 2,
        lastCompletionDate: null,
        completedExperiments: []
      });
      onClose();
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!regName.trim()) {
      setErrorMsg('Please provide your full student name as per KJSIT records.');
      return;
    }

    const cleanEmail = regEmail.trim().toLowerCase();
    if (!cleanEmail) {
      setErrorMsg('Please enter your official Somaiya student email.');
      return;
    }

    if (!validateSomaiyaEmail(cleanEmail)) {
      setErrorMsg(
        'Registration Rejected: You must use an official Somaiya Vidyavihar email (@somaiya.edu). Personal emails (Gmail, Yahoo, Outlook) are strictly not permitted.'
      );
      return;
    }

    if (!regStudentId.trim()) {
      setErrorMsg('Please enter your unique Somaiya Roll Number or SVVNet ID.');
      return;
    }

    if (!regPassword || regPassword.length < 8) {
      setErrorMsg('Password must be at least 8 characters in length.');
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: regName,
          email: cleanEmail,
          studentId: regStudentId,
          department: regDepartment,
          year: regYear,
          password: regPassword
        })
      });

      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error || 'Registration failed.');
      } else {
        setSuccessMsg('Account registered successfully! Logging you in...');
        setTimeout(() => {
          onLoginSuccess(data.user);
          onClose();
        }, 1200);
      }
    } catch (err: any) {
      console.error('Registration error:', err);
      // Fallback local registration if server is unavailable
      onLoginSuccess({
        name: regName,
        email: cleanEmail,
        studentId: regStudentId,
        department: regDepartment,
        year: regYear,
        role: 'student',
        totalActiveSeconds: 0,
        currentStreak: 1,
        longestStreak: 1,
        lastCompletionDate: null,
        completedExperiments: []
      });
      onClose();
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickDemo = (demo: 'priya' | 'vaishnavi' | 'rahul' | 'hod') => {
    setTab('login');
    if (demo === 'priya') {
      setLoginEmail('priya.thombare@somaiya.edu');
      setLoginPassword('somaiya2026');
    } else if (demo === 'vaishnavi') {
      setLoginEmail('vaishnavi.shinde@somaiya.edu');
      setLoginPassword('somaiya2026');
    } else if (demo === 'rahul') {
      setLoginEmail('rahul.somaiya@somaiya.edu');
      setLoginPassword('kjsit2026');
    } else if (demo === 'hod') {
      setLoginEmail('aids.hod@somaiya.edu');
      setLoginPassword('HodSomaiya@2026');
    }
    setErrorMsg('');
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-md animate-in fade-in duration-300 overflow-y-auto cursor-pointer"
      onClick={onClose}
    >
      {/* Ambient background glows */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/3 left-1/3 w-80 h-80 bg-red-600/15 rounded-full blur-3xl" />
        <div className="absolute bottom-1/3 right-1/3 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl" />
      </div>

      <div 
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-3xl max-w-md w-full shadow-[0_25px_60px_-15px_rgba(0,0,0,0.3)] border border-zinc-200 overflow-hidden relative my-auto animate-in zoom-in-95 duration-200 cursor-default"
      >
        {/* Top Accent Strip */}
        <div className="h-1 bg-linear-to-r from-red-600 via-amber-500 to-red-600" />

        {/* Header Ribbon with Red Glassmorphic Styling */}
        <div className="bg-linear-to-r from-red-950/95 via-red-900/90 to-rose-950/95 backdrop-blur-2xl text-white p-5 sm:p-6 relative border-b border-red-500/20 shrink-0 overflow-hidden">
          {/* Glossy highlight line & ambient reflections */}
          <div className="absolute inset-x-0 top-0 h-[1.5px] bg-linear-to-r from-red-500/20 via-white/40 to-red-500/20 pointer-events-none" />
          <div className="absolute -top-10 right-1/4 w-48 h-24 bg-red-500/25 rounded-full blur-2xl pointer-events-none" />

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onClose();
            }}
            className="absolute top-4 right-4 text-white/80 hover:text-white p-2.5 rounded-full bg-white/10 hover:bg-white/25 border border-white/20 backdrop-blur-md transition-all cursor-pointer shadow-sm z-30 hover:scale-105 active:scale-95"
            title="Close"
            aria-label="Close"
          >
            <X className="w-4 h-4 pointer-events-none" />
          </button>

          <div className="flex items-center gap-3.5 mb-1 relative z-10 pr-12">
            <div className="p-2 bg-white/10 backdrop-blur-md rounded-2xl border border-white/25 shadow-[0_4px_20px_rgba(0,0,0,0.25)] shrink-0 ring-1 ring-white/10">
              <SomaiyaEmblem size={36} />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white tracking-tight drop-shadow-xs">
                KJSIT Virtual Lab Portal
              </h3>
              <p className="text-xs text-red-200 font-semibold flex items-center gap-1.5 mt-0.5">
                <span>Somaiya Student Authentication</span>
                <span className="text-[10px] bg-black/30 backdrop-blur-sm text-red-100 px-2 py-0.5 rounded-full font-mono font-bold border border-white/15">@somaiya.edu</span>
              </p>
            </div>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6">
          {forgotPassOpen ? (
            <div>
              <h4 className="text-sm font-bold text-black mb-2 flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-red-700" />
                Somaiya SVVNet Password Recovery
              </h4>
              <p className="text-xs text-zinc-600 mb-4 leading-relaxed">
                Enter your registered official Somaiya email address (e.g. <code>username@somaiya.edu</code>). A password reset verification token will be dispatched to your institutional inbox.
              </p>

              {forgotSuccess ? (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 flex items-center gap-2 mb-4">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Reset instructions dispatched to your Somaiya email!</span>
                </div>
              ) : (
                <div className="space-y-3 mb-4">
                  <input
                    type="email"
                    placeholder="student.name@somaiya.edu"
                    className="w-full text-xs px-3 py-2 border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-600"
                  />
                  <button
                    onClick={() => setForgotSuccess(true)}
                    className="w-full py-2 bg-red-700 text-white text-xs font-bold rounded-lg hover:bg-red-800 transition-colors cursor-pointer"
                  >
                    Send Recovery Instructions
                  </button>
                </div>
              )}

              <button
                onClick={() => {
                  setForgotPassOpen(false);
                  setForgotSuccess(false);
                }}
                className="text-xs text-red-700 font-semibold hover:underline cursor-pointer"
              >
                &larr; Back to Portal Sign In
              </button>
            </div>
          ) : (
            <div>
              {/* Tab Selector: Sign In vs Register */}
              <div className="flex p-1 bg-zinc-100 rounded-xl text-xs mb-4">
                <button
                  type="button"
                  onClick={() => {
                    setTab('login');
                    setErrorMsg('');
                    setSuccessMsg('');
                  }}
                  className={`flex-1 py-2 rounded-lg font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                    tab === 'login'
                      ? 'bg-white text-zinc-900 shadow-xs border border-zinc-200/80'
                      : 'text-zinc-500 hover:text-zinc-900'
                  }`}
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Student Sign In</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setTab('register');
                    setErrorMsg('');
                    setSuccessMsg('');
                  }}
                  className={`flex-1 py-2 rounded-lg font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                    tab === 'register'
                      ? 'bg-white text-zinc-900 shadow-xs border border-zinc-200/80'
                      : 'text-zinc-500 hover:text-zinc-900'
                  }`}
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>New Registration</span>
                </button>
              </div>

              {/* Error Box */}
              {errorMsg && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-start gap-2 mb-3.5">
                  <ShieldAlert className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                  <span className="leading-snug">{errorMsg}</span>
                </div>
              )}

              {/* Success Box */}
              {successMsg && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-700 flex items-start gap-2 mb-3.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{successMsg}</span>
                </div>
              )}

              {/* 1. SIGN IN FORM */}
              {tab === 'login' && (
                <form onSubmit={handleLoginSubmit} className="space-y-3.5">
                  {/* Email Input */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-bold text-zinc-700">
                        Somaiya Official Email
                      </label>
                      <span className="text-[10px] text-red-700 font-bold">@somaiya.edu only</span>
                    </div>
                    <div className="relative">
                      <User className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="email"
                        value={loginEmail}
                        onChange={(e) => {
                          setLoginEmail(e.target.value);
                          setErrorMsg('');
                        }}
                        placeholder="e.g. priya.thombare@somaiya.edu"
                        className="w-full pl-9 pr-3 py-2 text-xs border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-600 font-medium"
                      />
                    </div>
                  </div>

                  {/* Password Input */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-bold text-zinc-700">
                        Password
                      </label>
                      <button
                        type="button"
                        onClick={() => setForgotPassOpen(true)}
                        className="text-[11px] text-red-700 hover:underline cursor-pointer font-semibold"
                      >
                        Forgot?
                      </button>
                    </div>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="password"
                        value={loginPassword}
                        onChange={(e) => {
                          setLoginPassword(e.target.value);
                          setErrorMsg('');
                        }}
                        placeholder="••••••••••••"
                        className="w-full pl-9 pr-3 py-2 text-xs border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-600 font-medium"
                      />
                    </div>
                  </div>

                  {/* Remember Me */}
                  <div className="flex items-center justify-between text-xs pt-1">
                    <label className="flex items-center gap-1.5 cursor-pointer text-zinc-600">
                      <input
                        type="checkbox"
                        checked={rememberMe}
                        onChange={(e) => setRememberMe(e.target.checked)}
                        className="rounded border-zinc-300 text-red-700 focus:ring-red-500"
                      />
                      <span>Keep me signed in</span>
                    </label>
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-2.5 bg-red-700 hover:bg-red-800 disabled:opacity-50 text-white text-xs font-bold rounded-lg shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer mt-2"
                  >
                    {isLoading ? (
                      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    ) : (
                      <>
                        <LogIn className="w-4 h-4" />
                        <span>Sign In to Virtual Labs</span>
                      </>
                    )}
                  </button>

                  {/* Quick Somaiya Demo Accounts */}
                  <div className="pt-3 border-t border-zinc-100">
                    <div className="text-[11px] font-bold text-zinc-500 mb-2 flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-red-600" />
                      <span>1-Click Somaiya Demo Accounts:</span>
                    </div>
                    <div className="grid grid-cols-3 gap-1.5 mb-2">
                      <button
                        type="button"
                        onClick={() => handleQuickDemo('priya')}
                        className="p-1.5 bg-zinc-50 hover:bg-red-50 hover:border-red-200 border border-zinc-200 text-zinc-800 text-[10px] font-semibold rounded text-center transition-colors cursor-pointer truncate"
                      >
                        Priya T. (AI-DS)
                      </button>
                      <button
                        type="button"
                        onClick={() => handleQuickDemo('vaishnavi')}
                        className="p-1.5 bg-zinc-50 hover:bg-red-50 hover:border-red-200 border border-zinc-200 text-zinc-800 text-[10px] font-semibold rounded text-center transition-colors cursor-pointer truncate"
                      >
                        Vaishnavi S.
                      </button>
                      <button
                        type="button"
                        onClick={() => handleQuickDemo('rahul')}
                        className="p-1.5 bg-zinc-50 hover:bg-red-50 hover:border-red-200 border border-zinc-200 text-zinc-800 text-[10px] font-semibold rounded text-center transition-colors cursor-pointer truncate"
                      >
                        Rahul S. (Comps)
                      </button>
                    </div>

                    {/* HOD Quick Access Card */}
                    <div className="p-2 bg-linear-to-r from-red-950 via-red-900 to-amber-950 rounded-lg text-white border border-red-500/30 flex items-center justify-between gap-2 shadow-xs">
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="w-6 h-6 rounded-full bg-amber-400/20 border border-amber-300/40 flex items-center justify-center shrink-0">
                          <GraduationCap className="w-3.5 h-3.5 text-amber-300" />
                        </div>
                        <div className="truncate">
                          <div className="text-[11px] font-bold text-amber-200 leading-tight truncate">
                            HOD Portal (AI & DS)
                          </div>
                          <div className="text-[9px] text-red-200 font-mono truncate">
                            aids.hod@somaiya • HodSomaiya@2026
                          </div>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleQuickDemo('hod')}
                        className="px-2.5 py-1 bg-amber-400 hover:bg-amber-300 text-zinc-950 rounded text-[10px] font-black transition-transform active:scale-95 cursor-pointer shrink-0 shadow-xs"
                      >
                        Sign in as HOD
                      </button>
                    </div>
                  </div>
                </form>
              )}

              {/* 2. REGISTRATION FORM */}
              {tab === 'register' && (
                <form onSubmit={handleRegisterSubmit} className="space-y-3">
                  {/* Full Name */}
                  <div>
                    <label className="text-xs font-bold text-zinc-700 block mb-1">
                      Student Full Name
                    </label>
                    <input
                      type="text"
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                      placeholder="e.g. Priya Thombare"
                      className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-600"
                    />
                  </div>

                  {/* Somaiya Email */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-bold text-zinc-700">
                        Somaiya Student Email
                      </label>
                      <span className="text-[10px] text-red-700 font-bold">Must end in @somaiya.edu</span>
                    </div>
                    <input
                      type="email"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="e.g. priya.thombare@somaiya.edu"
                      className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-600"
                    />
                  </div>

                  {/* Unique Student ID / Roll Number & Department */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div>
                      <label className="text-xs font-bold text-zinc-700 block mb-1">
                        Student ID / Roll No
                      </label>
                      <input
                        type="text"
                        value={regStudentId}
                        onChange={(e) => setRegStudentId(e.target.value)}
                        placeholder="e.g. 16010123045"
                        className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-600"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-zinc-700 block mb-1">
                        Department / Branch
                      </label>
                      <select
                        value={regDepartment}
                        onChange={(e) => setRegDepartment(e.target.value)}
                        className="w-full px-2 py-2 text-xs border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-600 bg-white"
                      >
                        <option value="Artificial Intelligence and Data Science">AI & Data Science</option>
                        <option value="Computer Engineering">Computer Engg</option>
                        <option value="Information Technology">Information Tech</option>
                        <option value="Electronics & Telecomm">EXTC Engg</option>
                      </select>
                    </div>
                  </div>

                  {/* Year Selection (FY, SY, TY, LY) */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-bold text-zinc-700 flex items-center gap-1.5">
                        <GraduationCap className="w-3.5 h-3.5 text-red-700" />
                        <span>Academic Year</span>
                      </label>
                      <span className="text-[10px] text-zinc-500 font-medium">
                        Selected: <strong className="text-red-700">{regYear}</strong> ({
                          regYear === 'FY' ? '1st Year' :
                          regYear === 'SY' ? '2nd Year' :
                          regYear === 'TY' ? '3rd Year' : 'Final Year'
                        })
                      </span>
                    </div>
                    <div className="grid grid-cols-4 gap-2">
                      {(['FY', 'SY', 'TY', 'LY'] as const).map((y) => {
                        const isSelected = regYear === y;
                        const subLabels: Record<string, string> = {
                          FY: '1st Year',
                          SY: '2nd Year',
                          TY: '3rd Year',
                          LY: 'Final Year'
                        };
                        return (
                          <button
                            key={y}
                            type="button"
                            onClick={() => setRegYear(y)}
                            className={`py-2 px-1 rounded-lg text-xs font-bold transition-all border flex flex-col items-center justify-center cursor-pointer ${
                              isSelected
                                ? 'bg-red-700 text-white border-red-700 shadow-sm ring-2 ring-red-500/25'
                                : 'bg-white text-zinc-700 border-zinc-300 hover:border-zinc-400 hover:bg-zinc-50'
                            }`}
                          >
                            <span className="text-xs font-extrabold tracking-wide">{y}</span>
                            <span className={`text-[9px] font-normal leading-none mt-0.5 ${isSelected ? 'text-red-100' : 'text-zinc-500'}`}>
                              {subLabels[y]}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Password (Minimum 8 Characters) */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-bold text-zinc-700 flex items-center gap-1">
                        <Lock className="w-3.5 h-3.5 text-zinc-500" />
                        <span>Create Password</span>
                      </label>
                      <span className={`text-[10px] font-semibold transition-colors ${
                        regPassword.length >= 8 
                          ? 'text-emerald-700 font-bold' 
                          : regPassword.length > 0 
                            ? 'text-amber-700 font-bold' 
                            : 'text-zinc-500'
                      }`}>
                        {regPassword.length >= 8 ? '✓ Minimum 8 chars met' : `${regPassword.length}/8 chars minimum`}
                      </span>
                    </div>
                    <input
                      type="password"
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      placeholder="Minimum 8 characters"
                      minLength={8}
                      className="w-full px-3 py-2 text-xs border border-zinc-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-600"
                    />
                  </div>

                  {/* Register Action */}
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-2.5 bg-red-700 hover:bg-red-800 disabled:opacity-50 text-white text-xs font-bold rounded-lg shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer mt-3"
                  >
                    {isLoading ? (
                      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    ) : (
                      <>
                        <UserPlus className="w-4 h-4" />
                        <span>Register Somaiya Student Account</span>
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
