import React, { useState } from 'react';
import {
  Menu,
  X,
  LogIn,
  LogOut,
  UserCheck,
  Search,
  BookOpen,
  GraduationCap,
  Sparkles,
  ExternalLink,
  ChevronDown,
  Clock,
  Award
} from 'lucide-react';
import { UserSession } from '../types';
import { SomaiyaEmblem } from './SomaiyaLogo';
import { ALL_EXPERIMENTS } from '../data/allExperiments';

interface NavbarProps {
  activeView: string;
  activeSection?: 'home' | 'labs' | 'contact';
  setActiveView: (view: string) => void;
  onOpenLogin: () => void;
  onOpenDashboard?: () => void;
  onOpenHodOverview?: () => void;
  userSession: UserSession | null;
  onLogout: () => void;
  onSelectExperiment?: (expId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeView,
  activeSection = 'home',
  setActiveView,
  onOpenLogin,
  onOpenDashboard,
  onOpenHodOverview,
  userSession,
  onLogout,
  onSelectExperiment
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchFocused, setSearchFocused] = useState(false);

  const formatActiveTime = (secs: number = 0) => {
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    if (h > 0) return `${h}h ${m}m`;
    return `${m}m`;
  };

  const experimentSearchList = ALL_EXPERIMENTS.map((exp) => ({
    id: exp.id,
    title: exp.title,
    cat: exp.category || exp.subjectId.toUpperCase()
  }));

  const filteredExperiments = searchQuery.trim()
    ? experimentSearchList.filter(e =>
        e.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        e.cat.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  const scrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      const navOffset = 70;
      const targetPos = el.getBoundingClientRect().top + window.scrollY - navOffset;
      window.scrollTo({ top: targetPos, behavior: 'smooth' });
    }
  };

  const handleNavClick = (viewName: string) => {
    setMobileMenuOpen(false);
    if (viewName === 'home') {
      if (activeView === 'home') {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else {
        setActiveView('home');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    } else if (viewName === 'labs') {
      if (activeView === 'home') {
        scrollToSection('virtual-labs-section');
      } else {
        setActiveView('home');
        setTimeout(() => scrollToSection('virtual-labs-section'), 80);
      }
    } else if (viewName === 'contact') {
      if (activeView === 'home') {
        scrollToSection('contact-section');
      } else {
        setActiveView('home');
        setTimeout(() => scrollToSection('contact-section'), 80);
      }
    } else {
      setActiveView(viewName);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const isHomeActive = activeView === 'home' && (!activeSection || activeSection === 'home');
  const isLabsActive =
    (activeView === 'home' && activeSection === 'labs') ||
    ['labs', 'daa', 'dsa', 'aiml', 'dbms', 'os', 'oopm', 'aoa', 'ai', 'dwm', 'se', 'ann', 'dav', 'nlp', 'dl', 'rpa', 'rl'].includes(activeView);
  const isContactActive = (activeView === 'home' && activeSection === 'contact') || activeView === 'contact';

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-zinc-200 shadow-2xs">
      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-18">
          {/* Logo & Title */}
          <div
            onClick={() => {
              if (userSession?.role === 'hod') {
                if (onOpenHodOverview) onOpenHodOverview();
                else setActiveView('hod-overview');
              } else {
                handleNavClick('home');
              }
            }}
            className="flex items-center gap-3.5 cursor-pointer group"
          >
            {/* Somaiya / KJSIT Custom Emblem */}
            <SomaiyaEmblem size={44} className="transition-transform group-hover:scale-105" />

            <div className="flex flex-col leading-tight">
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-black tracking-tight text-base sm:text-lg group-hover:text-red-700 transition-colors">
                  KJSIT Virtual Labs
                </h1>
              </div>
              <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-semibold">
                Somaiya Trust Excellence • Sion, Mumbai
              </span>
            </div>
          </div>

          {/* Search bar (Desktop) - Only for Students / Guests */}
          {userSession?.role !== 'hod' && (
            <div className="hidden lg:block relative w-64">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search experiments..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onFocus={() => setSearchFocused(true)}
                  onBlur={() => setTimeout(() => setSearchFocused(false), 250)}
                  className="w-full pl-8 pr-3 py-1.5 text-xs bg-zinc-50 border border-zinc-200 rounded-full focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-600 transition-all placeholder:text-zinc-400"
                />
              </div>

              {/* Quick search dropdown */}
              {searchFocused && filteredExperiments.length > 0 && (
                <div className="absolute top-full left-0 right-0 mt-1.5 bg-white border border-zinc-200 rounded-xl shadow-xl p-1.5 z-50">
                  <div className="text-[10px] font-bold text-zinc-400 px-2.5 py-1 uppercase tracking-wider">
                    Matching Experiments
                  </div>
                  {filteredExperiments.map(item => (
                    <button
                      key={item.id}
                      onClick={() => {
                        if (onSelectExperiment) onSelectExperiment(item.id);
                        setSearchQuery('');
                      }}
                      className="w-full text-left px-2.5 py-1.5 hover:bg-red-50 rounded-lg text-xs flex items-center justify-between text-zinc-800 transition-colors"
                    >
                      <span className="font-semibold text-zinc-900">{item.title}</span>
                      <span className="text-[10px] bg-red-100 text-red-900 px-1.5 py-0.5 rounded font-mono font-bold">
                        {item.cat}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Desktop Nav Links: Only HOD Dashboard when HOD is logged in */}
          <nav className="hidden md:flex items-center gap-7">
            {userSession?.role === 'hod' ? (
              <button
                onClick={() => {
                  if (onOpenHodOverview) onOpenHodOverview();
                  else setActiveView('hod-overview');
                }}
                className="text-sm font-bold text-red-700 border-b-2 border-red-700 pb-0.5 flex items-center gap-2 cursor-pointer"
                title="HOD Academic Department Dashboard"
              >
                <GraduationCap className="w-4.5 h-4.5 text-amber-600" />
                <span>HOD Dashboard</span>
              </button>
            ) : (
              <>
                <button
                  onClick={() => handleNavClick('home')}
                  className={`text-sm font-semibold transition-colors cursor-pointer ${
                    isHomeActive
                      ? 'text-red-700 font-bold border-b-2 border-red-700 pb-0.5'
                      : 'text-zinc-700 hover:text-red-700'
                  }`}
                >
                  Home
                </button>
                <button
                  onClick={() => handleNavClick('labs')}
                  className={`text-sm font-semibold transition-colors cursor-pointer ${
                    isLabsActive
                      ? 'text-red-700 font-bold border-b-2 border-red-700 pb-0.5'
                      : 'text-zinc-700 hover:text-red-700'
                  }`}
                >
                  Virtual Labs
                </button>
                <button
                  onClick={() => handleNavClick('contact')}
                  className={`text-sm font-semibold transition-colors cursor-pointer ${
                    isContactActive
                      ? 'text-red-700 font-bold border-b-2 border-red-700 pb-0.5'
                      : 'text-zinc-700 hover:text-red-700'
                  }`}
                >
                  Contact
                </button>
              </>
            )}
          </nav>

          {/* Right Action: Login / User Profile */}
          <div className="hidden md:flex items-center gap-2.5">
            {userSession ? (
              <div className="flex items-center gap-2">
                {/* Modern Student / HOD Profile & Dashboard Pill */}
                <div className="flex items-center gap-1.5 bg-white hover:border-zinc-300 border border-zinc-200/90 rounded-full shadow-2xs p-1 pl-1.5 pr-2 transition-all whitespace-nowrap">
                  <button
                    onClick={userSession.role === 'hod' && onOpenHodOverview ? onOpenHodOverview : onOpenDashboard}
                    className="flex items-center gap-2.5 text-left cursor-pointer group px-1 py-0.5 rounded-full hover:bg-zinc-50 transition-colors"
                    title={userSession.role === 'hod' ? 'Open HOD Overview' : 'Open Student Dashboard'}
                  >
                    {/* Avatar */}
                    <div className="shrink-0">
                      <div
                        className={`w-7 h-7 rounded-full text-white flex items-center justify-center font-bold text-xs shadow-xs transition-transform group-hover:scale-105 ${
                          userSession.role === 'hod'
                            ? 'bg-linear-to-tr from-amber-600 to-amber-500'
                            : 'bg-linear-to-tr from-red-700 to-red-600'
                        }`}
                      >
                        {userSession.role === 'hod' ? (
                          <GraduationCap className="w-3.5 h-3.5" />
                        ) : (
                          userSession.name.trim().charAt(0).toUpperCase()
                        )}
                      </div>
                    </div>

                    {/* User Identity Details */}
                    <div className="flex flex-col min-w-0 pr-1">
                      <span className="text-xs font-bold text-zinc-900 group-hover:text-red-700 transition-colors truncate max-w-[130px] leading-tight">
                        {userSession.role === 'hod'
                          ? userSession.name.replace(/\s*\([^)]*\)/g, '').trim()
                          : userSession.name}
                      </span>
                      {userSession.role === 'hod' ? (
                        <span className="flex items-center gap-1 text-[10px] text-zinc-500 font-medium leading-none mt-0.5">
                          <span className="px-1 py-0.2 bg-amber-100 text-amber-900 rounded font-bold text-[9px] uppercase tracking-wider">
                            HOD
                          </span>
                          <span>AI & DS</span>
                        </span>
                      ) : (
                        <div className="text-[10px] text-zinc-500 font-mono leading-none mt-0.5">
                          <span className="tracking-tight text-zinc-600 font-semibold">
                            {userSession.studentId || userSession.idNumber || 'Student'}
                          </span>
                        </div>
                      )}
                    </div>
                  </button>

                  {/* Subtle Vertical Divider */}
                  <div className="w-[1px] h-4 bg-zinc-200 shrink-0" />

                  {/* Sleek Logout Button */}
                  <button
                    onClick={onLogout}
                    className="flex items-center gap-1 px-2 py-1 rounded-full text-zinc-500 hover:text-red-700 hover:bg-red-50/80 text-[11px] font-semibold transition-colors cursor-pointer shrink-0"
                    title="Sign out of account"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Exit</span>
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={onOpenLogin}
                className="bg-red-700 text-white px-5 py-2 rounded-full text-xs sm:text-sm font-bold hover:bg-red-800 transition-colors shadow-sm flex items-center gap-2 active:scale-98 cursor-pointer"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Student Login</span>
              </button>
            )}
          </div>

          {/* Mobile menu toggle */}
          <div className="flex md:hidden items-center gap-2">
            {userSession ? (
              <button
                onClick={userSession.role === 'hod' && onOpenHodOverview ? onOpenHodOverview : onOpenDashboard}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-bold border transition-colors ${
                  userSession.role === 'hod'
                    ? 'bg-amber-50 border-amber-200 text-amber-900'
                    : 'bg-red-50 border-red-200 text-red-800'
                }`}
                title={userSession.role === 'hod' ? 'HOD Dashboard' : 'User Profile'}
              >
                {userSession.role === 'hod' ? (
                  <GraduationCap className="w-4 h-4 text-amber-700" />
                ) : (
                  <div className="w-2 h-2 rounded-full bg-emerald-500" />
                )}
                <span>{userSession.role === 'hod' ? 'HOD' : userSession.name.split(' ')[0]}</span>
              </button>
            ) : (
              <button
                onClick={onOpenLogin}
                className="p-2 bg-red-50 text-red-700 rounded-lg text-xs font-semibold"
              >
                <LogIn className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-zinc-700 hover:text-black hover:bg-zinc-100 rounded-lg"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-zinc-200 bg-white px-4 pt-3 pb-6 space-y-2 shadow-xl">
          {userSession?.role === 'hod' ? (
            <button
              onClick={() => {
                if (onOpenHodOverview) onOpenHodOverview();
                else setActiveView('hod-overview');
                setMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-bold bg-red-50 text-red-700 flex items-center gap-2 cursor-pointer"
            >
              <GraduationCap className="w-4.5 h-4.5 text-amber-600" />
              <span>HOD Dashboard</span>
            </button>
          ) : (
            <>
              <div className="mb-3">
                <input
                  type="text"
                  placeholder="Search experiments..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-zinc-50 border border-zinc-200 rounded-lg focus:outline-none focus:border-red-600"
                />
              </div>

              <button
                onClick={() => handleNavClick('home')}
                className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold transition-colors cursor-pointer ${
                  isHomeActive ? 'bg-red-50 text-red-700 font-bold' : 'text-zinc-800 hover:bg-zinc-50'
                }`}
              >
                Home
              </button>
              <button
                onClick={() => handleNavClick('labs')}
                className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold transition-colors cursor-pointer ${
                  isLabsActive ? 'bg-red-50 text-red-700 font-bold' : 'text-zinc-800 hover:bg-zinc-50'
                }`}
              >
                Virtual Labs
              </button>
              <button
                onClick={() => handleNavClick('contact')}
                className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold transition-colors cursor-pointer ${
                  isContactActive ? 'bg-red-50 text-red-700 font-bold' : 'text-zinc-800 hover:bg-zinc-50'
                }`}
              >
                Contact
              </button>
            </>
          )}

          <div className="pt-3 border-t border-zinc-100">
            {userSession ? (
              <div className="p-3 bg-zinc-50 rounded-xl space-y-2.5 border border-zinc-200">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-full text-white flex items-center justify-center font-bold text-sm shadow-xs shrink-0 ${
                      userSession.role === 'hod'
                        ? 'bg-linear-to-tr from-amber-600 to-amber-500'
                        : 'bg-linear-to-tr from-red-700 to-red-600'
                    }`}
                  >
                    {userSession.role === 'hod' ? (
                      <GraduationCap className="w-4 h-4" />
                    ) : (
                      userSession.name.trim().charAt(0).toUpperCase()
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-bold text-zinc-900 truncate">
                      {userSession.role === 'hod'
                        ? userSession.name.replace(/\s*\([^)]*\)/g, '').trim()
                        : userSession.name}
                    </div>
                    {userSession.role === 'hod' ? (
                      <div className="text-[10px] text-zinc-500 flex items-center gap-1.5 mt-0.5">
                        <span className="px-1.5 py-0.2 bg-amber-100 text-amber-900 border border-amber-300/60 rounded font-black text-[9px] uppercase">
                          HOD
                        </span>
                        <span className="font-semibold text-zinc-600">AI & DS • Somaiya</span>
                      </div>
                    ) : (
                      <div className="text-[10px] text-zinc-500 font-mono flex items-center gap-1.5 mt-0.5">
                        <span>{userSession.studentId || userSession.idNumber || userSession.email}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex gap-2 pt-1">
                  {userSession.role === 'hod' && onOpenHodOverview ? (
                    <button
                      onClick={() => {
                        setMobileMenuOpen(false);
                        onOpenHodOverview();
                      }}
                      className="flex-1 py-1.5 bg-linear-to-r from-amber-600 to-red-800 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <GraduationCap className="w-3.5 h-3.5 text-amber-200" />
                      <span>HOD Student Overview</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        setMobileMenuOpen(false);
                        if (onOpenDashboard) onOpenDashboard();
                      }}
                      className="flex-1 py-1.5 bg-red-700 hover:bg-red-800 text-white rounded-lg text-xs font-bold cursor-pointer transition-colors"
                    >
                      Student Dashboard
                    </button>
                  )}
                  <button
                    onClick={onLogout}
                    className="flex items-center gap-1 px-3 py-1.5 bg-white border border-zinc-200 text-zinc-600 hover:text-red-700 hover:border-red-200 rounded-lg text-xs font-semibold cursor-pointer transition-colors"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Exit</span>
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenLogin();
                }}
                className="w-full py-2.5 bg-red-700 text-white rounded-full text-xs font-bold flex items-center justify-center gap-2 shadow-sm hover:bg-red-800 transition-colors"
              >
                <LogIn className="w-4 h-4" />
                Login to Portal
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
