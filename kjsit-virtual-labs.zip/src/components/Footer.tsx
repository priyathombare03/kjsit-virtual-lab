import React from 'react';
import {
  MapPin,
  Phone,
  Mail,
  Linkedin,
  Youtube,
  Twitter,
  Facebook,
  Instagram,
  ArrowUp,
  BookOpen,
  Building2,
  GraduationCap
} from 'lucide-react';
import { INSTITUTE_INFO } from '../data/instituteData';
import { SomaiyaEmblem } from './SomaiyaLogo';
import { UserSession } from '../types';

interface FooterProps {
  onNavigate: (view: string) => void;
  onOpenLogin: () => void;
  onSelectExperiment?: (expId: string) => void;
  userSession?: UserSession | null;
}

export const Footer: React.FC<FooterProps> = ({
  onNavigate,
  onOpenLogin,
  onSelectExperiment,
  userSession
}) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-red-900 text-white border-t border-red-800">
      {/* Upper Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-14 pb-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 lg:gap-12">
          {/* Column 1: College Emblem & Bio */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3.5">
              <SomaiyaEmblem size={44} className="shadow-sm" />
              <div>
                <h3 className="text-base font-bold text-white leading-tight">
                  {INSTITUTE_INFO.name}
                </h3>
                <p className="text-xs text-red-200 font-semibold">
                  Autonomous Institute • NAAC 'A' Grade (3.21 CGPA)
                </p>
              </div>
            </div>

            <p className="text-xs text-red-100/90 leading-relaxed">
              Somaiya Vidyavihar's premier engineering college, fostering experiential algorithmic education, cloud-based virtual laboratories, and technological innovation.
            </p>

            <div className="text-xs text-amber-200 font-serif italic">
              "{INSTITUTE_INFO.mottoSanskrit}" — {INSTITUTE_INFO.mottoEnglish}
            </div>

            {/* Social Icons */}
            <div className="flex items-center gap-2 pt-2">
              <a
                href="https://www.linkedin.com/school/k-j-somaiya-institute-of-engineering-and-information-technology/"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-lg bg-red-950/70 hover:bg-white text-red-100 hover:text-red-900 flex items-center justify-center transition-colors border border-red-800/80"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-4 h-4" />
              </a>
              <a
                href="https://www.youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-lg bg-red-950/70 hover:bg-white text-red-100 hover:text-red-900 flex items-center justify-center transition-colors border border-red-800/80"
                aria-label="YouTube"
              >
                <Youtube className="w-4 h-4" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-lg bg-red-950/70 hover:bg-white text-red-100 hover:text-red-900 flex items-center justify-center transition-colors border border-red-800/80"
                aria-label="Twitter / X"
              >
                <Twitter className="w-4 h-4" />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-lg bg-red-950/70 hover:bg-white text-red-100 hover:text-red-900 flex items-center justify-center transition-colors border border-red-800/80"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-lg bg-red-950/70 hover:bg-white text-red-100 hover:text-red-900 flex items-center justify-center transition-colors border border-red-800/80"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-300">
              {userSession?.role === 'hod' ? 'HOD Quick Navigation' : 'Quick Navigation'}
            </h4>
            <ul className="space-y-2 text-xs text-red-100">
              {userSession?.role === 'hod' ? (
                <>
                  <li>
                    <button
                      onClick={() => onNavigate('hod-overview')}
                      className="hover:text-white transition-colors cursor-pointer font-bold text-amber-200 flex items-center gap-1.5"
                    >
                      <GraduationCap className="w-3.5 h-3.5 text-amber-400" />
                      <span>HOD Dashboard</span>
                    </button>
                  </li>
                  <li>
                    <a
                      href="https://kjsit.somaiya.edu/en"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-white transition-colors cursor-pointer"
                    >
                      Somaiya Institute Portal
                    </a>
                  </li>
                  <li>
                    <span className="text-red-200/80">
                      Dept: Artificial Intelligence & Data Science
                    </span>
                  </li>
                </>
              ) : (
                <>
                  <li>
                    <button
                      onClick={() => onNavigate('home')}
                      className="hover:text-white transition-colors cursor-pointer"
                    >
                      Home Portal
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => onNavigate('labs')}
                      className="hover:text-white transition-colors cursor-pointer"
                    >
                      Virtual Labs
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={onOpenLogin}
                      className="hover:text-white transition-colors cursor-pointer"
                    >
                      Student / Faculty Login
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => onNavigate('contact')}
                      className="hover:text-white transition-colors cursor-pointer"
                    >
                      Contact & Support
                    </button>
                  </li>
                </>
              )}
            </ul>
          </div>

          {/* Column 3: Address & Helpline */}
          <div className="lg:col-span-4 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-300">
              Campus Address
            </h4>
            <div className="space-y-2.5 text-xs text-red-100">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" />
                <span>{INSTITUTE_INFO.contact.address}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-red-200 shrink-0" />
                <span className="font-mono">{INSTITUTE_INFO.contact.phone}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-amber-300 shrink-0" />
                <span className="font-mono">{INSTITUTE_INFO.contact.email}</span>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={scrollToTop}
                className="w-full py-2 bg-red-950 hover:bg-white text-white hover:text-red-900 text-xs font-bold rounded-lg border border-red-800 flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-sm"
              >
                <ArrowUp className="w-3.5 h-3.5" />
                <span>Back to Top</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Legal Ribbon */}
      <div className="border-t border-red-950 bg-red-950 py-4 px-4 sm:px-6 lg:px-8 text-xs text-red-200">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <div>
            <p className="text-white font-medium">© 2026 KJSIT (K. J. Somaiya Institute of Technology). All Rights Reserved.</p>
            <p className="text-[11px] text-red-300/80 mt-0.5">
              Designed & Developed by Priya Thombare and Vaishnavi Shinde — Department of Artificial Intelligence and Data Science, KJSIT
            </p>
          </div>
          <div className="flex items-center gap-4 text-[11px] text-red-200">
            <span>Autonomous Status</span>
            <span>•</span>
            <span className="text-amber-300 font-bold">NAAC 'A' Grade</span>
            <span>•</span>
            <span>AICTE Approved</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
