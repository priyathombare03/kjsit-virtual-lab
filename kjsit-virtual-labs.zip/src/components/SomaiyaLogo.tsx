import React from 'react';

interface SomaiyaLogoProps {
  className?: string;
  size?: number | string;
  variant?: 'emblem' | 'full' | 'badge';
  inverted?: boolean;
}

export const SomaiyaEmblem: React.FC<{ size?: number; className?: string; inverted?: boolean }> = ({
  size = 44,
  className = '',
  inverted = false
}) => {
  const brandRed = inverted ? '#ffffff' : '#9B1B1E';
  const bgColor = inverted ? '#9B1B1E' : '#ffffff';

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 200 200"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`shrink-0 ${className}`}
      aria-label="Somaiya Vidyavihar Logo"
    >
      <defs>
        {/* Curved text paths */}
        {/* Top outer arc for 'Knowledge Alone Liberates' */}
        <path
          id="topOuterArc"
          d="M 28 100 A 72 72 0 0 1 172 100"
          fill="none"
        />
        {/* Top inner arc for 'ज्ञानादेव तु कैवल्यम्' */}
        <path
          id="topInnerArc"
          d="M 40 102 A 60 60 0 0 1 160 102"
          fill="none"
        />
        {/* Bottom arc for 'Somaiya Vidyavihar' */}
        <path
          id="bottomArc"
          d="M 28 102 A 72 72 0 0 0 172 102"
          fill="none"
        />
        <filter id="subtleGlow" x="-10%" y="-10%" width="120%" height="120%">
          <feDropShadow dx="0" dy="1" stdDeviation="1.5" floodColor="#000000" floodOpacity="0.12" />
        </filter>
      </defs>

      {/* Outer circular badge background */}
      <circle cx="100" cy="100" r="96" fill={bgColor} stroke={inverted ? '#7E1518' : '#F3C5C7'} strokeWidth="2" filter="url(#subtleGlow)" />

      {/* Top Arc Text: English Motto */}
      <text
        fill={brandRed}
        fontSize="10"
        fontFamily="sans-serif"
        fontWeight="bold"
        letterSpacing="1.8"
      >
        <textPath href="#topOuterArc" startOffset="50%" textAnchor="middle">
          Knowledge Alone Liberates
        </textPath>
      </text>

      {/* Inner Arc Text: Sanskrit Motto */}
      <text
        fill={brandRed}
        fontSize="11.5"
        fontFamily="serif"
        fontWeight="bold"
        letterSpacing="1.2"
      >
        <textPath href="#topInnerArc" startOffset="50%" textAnchor="middle">
          ज्ञानादेव तु कैवल्यम्
        </textPath>
      </text>

      {/* Center Diya Flame */}
      <g transform="translate(0, -2)">
        {/* Teardrop Flame with elegant taper */}
        <path
          d="M 100 68 C 105 76 112 85 110 97 C 108 106 102 110 100 110 C 98 110 92 106 90 97 C 88 85 95 76 100 68 Z"
          fill={brandRed}
        />
        <path
          d="M 100 75 C 103 81 107 88 106 96 C 104 102 101 105 100 105 C 99 105 96 102 94 96 C 93 88 97 81 100 75 Z"
          fill={inverted ? '#9B1B1E' : '#FFFFFF'}
          opacity="0.18"
        />

        {/* Diya Base (Crescent oil reservoir) */}
        <path
          d="M 58 102 C 68 126 84 139 100 139 C 116 139 132 126 142 102 C 130 119 116 127 100 127 C 84 127 70 119 58 102 Z"
          fill={brandRed}
        />
      </g>

      {/* Bottom Arc Text: Somaiya Vidyavihar */}
      <text
        fill={brandRed}
        fontSize="13"
        fontFamily="serif"
        fontWeight="bold"
        letterSpacing="2.2"
      >
        <textPath href="#bottomArc" startOffset="50%" textAnchor="middle">
          Somaiya Vidyavihar
        </textPath>
      </text>
    </svg>
  );
};

export const SomaiyaLogoHorizontal: React.FC<{ height?: number; className?: string; inverted?: boolean }> = ({
  height = 48,
  className = '',
  inverted = false
}) => {
  const textColor = inverted ? '#ffffff' : '#9B1B1E';
  const subColor = inverted ? '#FCA5A5' : '#9B1B1E';

  return (
    <div className={`inline-flex items-center gap-3.5 ${className}`}>
      <SomaiyaEmblem size={height} inverted={inverted} />
      <div className="flex flex-col justify-center">
        <span
          className="font-serif font-black tracking-wider leading-none text-xl sm:text-2xl"
          style={{ color: textColor }}
        >
          SOMAIYA
        </span>
        <span
          className="font-sans font-bold tracking-widest text-[9px] sm:text-[10.5px] uppercase mt-1 leading-none"
          style={{ color: subColor }}
        >
          VIDYAVIHAR UNIVERSITY
        </span>
      </div>
    </div>
  );
};

export const SomaiyaLogo: React.FC<SomaiyaLogoProps> = ({
  className = '',
  size = 44,
  variant = 'emblem',
  inverted = false
}) => {
  if (variant === 'full') {
    return <SomaiyaLogoHorizontal height={typeof size === 'number' ? size : 48} className={className} inverted={inverted} />;
  }
  return <SomaiyaEmblem size={typeof size === 'number' ? size : 44} className={className} inverted={inverted} />;
};

export default SomaiyaLogo;
