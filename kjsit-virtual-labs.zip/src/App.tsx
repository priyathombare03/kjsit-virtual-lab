/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HeroCarousel } from './components/HeroCarousel';
import { VirtualLabsGrid } from './components/VirtualLabsGrid';
import { DAALabView } from './components/DAALabView';
import { DSALabView } from './components/DSALabView';
import { MLLabView } from './components/MLLabView';
import { DBMSLabView } from './components/DBMSLabView';
import { OSLabView } from './components/OSLabView';
import { OOPMLabView } from './components/OOPMLabView';
import { SubjectLabView } from './components/SubjectLabView';
import { LAB_SUBJECTS } from './data/subjects';
import { getExperimentsForSubject } from './data/allExperiments';
import { ExperimentDetailView } from './components/ExperimentDetailView';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { LoginModal } from './components/LoginModal';
import { StudentDashboardModal } from './components/StudentDashboardModal';
import { HodOverviewPage } from './components/HodOverviewPage';
import { UserSession } from './types';

export default function App() {
  const [activeView, setActiveView] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const view = params.get('view');
      if (view === 'hod' || view === 'hod-overview') {
        return 'hod-overview';
      }
    }
    return 'home';
  });
  const [selectedExperimentId, setSelectedExperimentId] = useState<string>('singly-linked-list');
  const [activeHomeSection, setActiveHomeSection] = useState<'home' | 'labs' | 'contact'>('home');
  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);
  const [isStudentDashboardOpen, setIsStudentDashboardOpen] = useState<boolean>(false);
  const [userSession, setUserSession] = useState<UserSession | null>({
    name: 'Priya Thombare',
    email: 'priya.thombare@somaiya.edu',
    studentId: '16010123045',
    department: 'Artificial Intelligence and Data Science',
    year: 'TY',
    role: 'student',
    idNumber: '16010123045',
    totalActiveSeconds: 7420,
    currentStreak: 3,
    longestStreak: 5,
    lastCompletionDate: new Date().toISOString().split('T')[0],
    completionDates: [
      new Date().toISOString().split('T')[0],
      new Date(Date.now() - 86400000).toISOString().split('T')[0],
      new Date(Date.now() - 172800000).toISOString().split('T')[0]
    ],
    completedExperiments: [
      {
        experimentId: 'merge-sort',
        subjectId: 'daa',
        title: 'Merge Sort Algorithm',
        activeSeconds: 1540,
        completedAt: new Date(Date.now() - 172800000).toISOString(),
        score: 5
      },
      {
        experimentId: 'singly-linked-list',
        subjectId: 'dsa',
        title: 'Singly Linked List Operations',
        activeSeconds: 1820,
        completedAt: new Date(Date.now() - 86400000).toISOString(),
        score: 5
      },
      {
        experimentId: 'linear-regression',
        subjectId: 'aiml',
        title: 'Linear Regression & Gradient Descent',
        activeSeconds: 2100,
        completedAt: new Date().toISOString(),
        score: 5
      }
    ]
  });

  // Fetch verified student session from server on mount
  useEffect(() => {
    const fetchCurrentStudent = async () => {
      try {
        const email = userSession?.email || 'priya.thombare@somaiya.edu';
        const res = await fetch(`/api/auth/me?email=${encodeURIComponent(email)}`);
        if (res.ok) {
          const data = await res.json();
          if (data.user) {
            setUserSession(data.user);
          }
        }
      } catch (err) {
        console.error("Could not sync with student server:", err);
      }
    };
    fetchCurrentStudent();
  }, []);

  // Track active section on scroll when on home view
  useEffect(() => {
    if (activeView !== 'home') return;

    const handleScroll = () => {
      // 1. Top of page
      if (window.scrollY < 120) {
        setActiveHomeSection('home');
        return;
      }

      // 2. Near bottom of page -> contact
      if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 70) {
        setActiveHomeSection('contact');
        return;
      }

      const contactEl = document.getElementById('contact-section');
      const labsEl = document.getElementById('virtual-labs-section');

      const triggerThreshold = 220; // comfort zone under sticky navbar

      if (contactEl) {
        const rect = contactEl.getBoundingClientRect();
        if (rect.top <= triggerThreshold && rect.bottom > 80) {
          setActiveHomeSection('contact');
          return;
        }
      }

      if (labsEl) {
        const rect = labsEl.getBoundingClientRect();
        if (rect.top <= triggerThreshold && rect.bottom > 80) {
          setActiveHomeSection('labs');
          return;
        }
      }

      setActiveHomeSection('home');
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [activeView]);

  const handleSelectSubject = (subjectId: string) => {
    setActiveView(subjectId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectExperiment = (expId: string) => {
    setSelectedExperimentId(expId);
    setActiveView('experiment');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-white text-zinc-900 flex flex-col font-sans selection:bg-red-700 selection:text-white">
      {/* Top Navigation */}
      <Navbar
        activeView={activeView}
        activeSection={activeHomeSection}
        setActiveView={(view) => {
          setActiveView(view);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenLogin={() => setIsLoginModalOpen(true)}
        onOpenDashboard={() => setIsStudentDashboardOpen(true)}
        onOpenHodOverview={() => {
          setActiveView('hod-overview');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        userSession={userSession}
        onLogout={() => setUserSession(null)}
        onSelectExperiment={handleSelectExperiment}
      />

      {/* Main View Router */}
      <main className="flex-1">
        {userSession?.role === 'hod' ? (
          <HodOverviewPage
            userSession={userSession}
          />
        ) : (
          <>
            {activeView === 'home' && (
              <>
                <div id="home-section">
                  <HeroCarousel
                    onExploreLabs={() => {
                      const el = document.getElementById('virtual-labs-section');
                      if (el) {
                        const navHeight = 70;
                        const pos = el.getBoundingClientRect().top + window.scrollY - navHeight;
                        window.scrollTo({ top: pos, behavior: 'smooth' });
                      } else {
                        setActiveView('labs');
                      }
                    }}
                    onLaunchDAA={() => setActiveView('daa')}
                    onLaunchDSA={() => setActiveView('dsa')}
                    onLaunchML={() => setActiveView('aiml')}
                    onLaunchDBMS={() => setActiveView('dbms')}
                    onLaunchOS={() => setActiveView('os')}
                  />
                </div>

                <div id="virtual-labs-section">
                  <VirtualLabsGrid onSelectSubject={handleSelectSubject} />
                </div>

                <ContactSection />
              </>
            )}

            {activeView === 'labs' && (
              <VirtualLabsGrid onSelectSubject={handleSelectSubject} />
            )}

            {activeView === 'daa' && (
              <DAALabView
                onSelectExperiment={handleSelectExperiment}
                onBackToLabs={() => {
                  setActiveView('labs');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                userSession={userSession}
              />
            )}

            {activeView === 'dsa' && (
              <DSALabView
                onSelectExperiment={handleSelectExperiment}
                onBackToLabs={() => {
                  setActiveView('labs');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                userSession={userSession}
              />
            )}

            {(activeView === 'aiml' || activeView === 'ml') && (
              <MLLabView
                onSelectExperiment={handleSelectExperiment}
                onBackToLabs={() => {
                  setActiveView('labs');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                userSession={userSession}
              />
            )}

            {activeView === 'dbms' && (
              <DBMSLabView
                onSelectExperiment={handleSelectExperiment}
                onBackToLabs={() => {
                  setActiveView('labs');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                userSession={userSession}
              />
            )}

            {activeView === 'os' && (
              <OSLabView
                onSelectExperiment={handleSelectExperiment}
                onBackToLabs={() => {
                  setActiveView('labs');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                userSession={userSession}
              />
            )}

            {activeView === 'oopm' && (
              <OOPMLabView
                onSelectExperiment={handleSelectExperiment}
                onBackToLabs={() => {
                  setActiveView('labs');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                userSession={userSession}
              />
            )}

            {/* Comprehensive Workstations for labs: AOA, AI, DWM, SE, ANN, DAV, NLP, DL, RPA, RL */}
            {['aoa', 'ai', 'dwm', 'se', 'ann', 'dav', 'nlp', 'dl', 'rpa', 'rl'].includes(activeView) && (() => {
              const currentSubj = LAB_SUBJECTS.find((s) => s.id === activeView);
              if (!currentSubj) return null;
              return (
                <SubjectLabView
                  subject={currentSubj}
                  experiments={getExperimentsForSubject(activeView)}
                  onSelectExperiment={handleSelectExperiment}
                  onBackToLabs={() => {
                    setActiveView('labs');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  userSession={userSession}
                />
              );
            })()}

            {activeView === 'experiment' && (
              <ExperimentDetailView
                experimentId={selectedExperimentId}
                onBackToLab={(lab) => {
                  setActiveView(lab);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                onSelectExperiment={handleSelectExperiment}
                userSession={userSession}
                onUserSessionUpdate={(updated) => setUserSession(updated)}
                onOpenLogin={() => setIsLoginModalOpen(true)}
              />
            )}

            {activeView === 'contact' && <ContactSection />}

            {activeView === 'hod-overview' && (
              <HodOverviewPage
                userSession={userSession}
              />
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <Footer
        onNavigate={(view) => {
          if (userSession?.role === 'hod') {
            setActiveView('hod-overview');
          } else {
            setActiveView(view);
          }
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenLogin={() => setIsLoginModalOpen(true)}
        onSelectExperiment={handleSelectExperiment}
        userSession={userSession}
      />

      {/* Login Modal */}
      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onLoginSuccess={(session) => {
          setUserSession(session);
          if (session.role === 'hod') {
            setActiveView('hod-overview');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }
        }}
      />

      {/* Student Academic & Streak Dashboard Modal */}
      <StudentDashboardModal
        isOpen={isStudentDashboardOpen}
        onClose={() => setIsStudentDashboardOpen(false)}
        userSession={userSession}
        onSelectExperiment={handleSelectExperiment}
      />
    </div>
  );
}
