import { LabExperiment } from '../types';

export const AOA_EXPERIMENTS: LabExperiment[] = [
  {
    id: 'aoa-exp1',
    num: 1,
    subjectId: 'aoa',
    title: 'Divide & Conquer: Merge Sort & Recurrence Analysis',
    subtitle: 'Divide-and-Conquer Recurrence T(n) = 2T(n/2) + O(n), Master Theorem & Stability',
    category: 'Divide & Conquer',
    iitReference: 'Autonomous Curriculum Standards / Data Structures & Algorithms Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/aoa-lab/',
    aim: 'To implement Merge Sort using the Divide and Conquer strategy and empirically verify its O(n log n) time complexity against theoretical recurrences.',
    theory: {
      overview: [
        'Merge Sort is an asymptotically optimal comparison-based sorting algorithm based on the Divide and Conquer design paradigm.',
        'Divide: Split the unsorted array of size n into two halves of size n/2.',
        'Conquer: Recursively sort each sub-array until the base case of 1 element is reached.',
        'Combine: Merge the two sorted sub-arrays into a single sorted array by comparing front elements.',
        'Recurrence Relation: T(n) = 2T(n/2) + cn. By Case 2 of the Master Theorem (log_b(a) = log_2(2) = 1), T(n) = Θ(n log n) across best, average, and worst cases.'
      ],
      complexityTable: [
        { parameter: 'Best Case Time', value: 'O(n log n)' },
        { parameter: 'Average Case Time', value: 'O(n log n)' },
        { parameter: 'Worst Case Time', value: 'O(n log n)' },
        { parameter: 'Space Complexity', value: 'O(n) auxiliary memory for merge buffer' }
      ],
      keyPoints: [
        'Stable Sorting: Equal keys maintain their original relative order.',
        'External Sorting: Ideal for sorting gigabyte-scale datasets on secondary storage (magnetic tapes, SSDs).'
      ],
      realWorldApplications: [
        'Database engine external sorting and GNU sort utility.',
        'E-commerce product catalog sorting with secondary sort stability.'
      ]
    },
    algorithm: [
      '1. Function MergeSort(arr, low, high):',
      '2. If low < high:',
      '    a. mid = low + (high - low) / 2.',
      '    b. MergeSort(arr, low, mid).',
      '    c. MergeSort(arr, mid + 1, high).',
      '    d. Merge(arr, low, mid, high).',
      '3. Function Merge(arr, low, mid, high):',
      '    a. Copy elements into temporary arrays Left and Right.',
      '    b. Iterate with pointers i and j, copying smaller element into arr[k].',
      '    c. Copy remaining trailing elements.'
    ],
    procedure: [
      '1. Open Merge Sort Simulator.',
      '2. Select input array or generate random sequence.',
      '3. Step through recursive subdivision down to atomic leaf pairs.',
      '4. Observe the two-finger pointer merge phase combining sorted subarrays.',
      '5. Review comparison and swap counters.'
    ],
    code: {
      cpp: `#include <iostream>
#include <vector>

void merge(std::vector<int>& arr, int l, int m, int r) {
    int n1 = m - l + 1, n2 = r - m;
    std::vector<int> L(n1), R(n2);
    for (int i = 0; i < n1; i++) L[i] = arr[l + i];
    for (int j = 0; j < n2; j++) R[j] = arr[m + 1 + j];
    int i = 0, j = 0, k = l;
    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) arr[k++] = L[i++];
        else arr[k++] = R[j++];
    }
    while (i < n1) arr[k++] = L[i++];
    while (j < n2) arr[k++] = R[j++];
}

void mergeSort(std::vector<int>& arr, int l, int r) {
    if (l < r) {
        int m = l + (r - l) / 2;
        mergeSort(arr, l, m);
        mergeSort(arr, m + 1, r);
        merge(arr, l, m, r);
    }
}`,
      python: `def merge_sort(arr):
    if len(arr) <= 1:
        return arr
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    
    merged = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            merged.append(left[i]); i += 1
        else:
            merged.append(right[j]); j += 1
    merged.extend(left[i:])
    merged.extend(right[j:])
    return merged`,
      java: `// Java MergeSort implementation`,
      c: `// C MergeSort implementation`
    },
    sampleInput: 'Array: [38, 27, 43, 3, 9, 82, 10]',
    expectedOutput: 'Sorted Array: [3, 9, 10, 27, 38, 43, 82] in 14 comparisons.',
    references: ['Thomas H. Cormen, Charles E. Leiserson, Ronald L. Rivest, and Clifford Stein, Introduction to Algorithms (CLRS), MIT Press'],
    conclusion: 'Merge Sort achieved predictable O(n log n) comparisons across all permutations while preserving relative key stability.',
    quiz: [
      {
        id: 1,
        question: 'What is the auxiliary space complexity of standard standard Merge Sort on an array of size n?',
        options: ['O(n)', 'O(1)', 'O(log n)', 'O(n^2)'],
        correctAnswer: 0,
        explanation: 'Merge sort requires O(n) auxiliary space to store temporary sub-arrays during the merge combination phase.'
      }
    ]
  },
  {
    id: 'aoa-exp2',
    num: 2,
    subjectId: 'aoa',
    title: 'Greedy Method: Fractional Knapsack Problem',
    subtitle: 'Value-to-Weight Ratio, Greedy Choice Property & Optimal Substructure',
    category: 'Greedy Strategy',
    iitReference: 'Autonomous Curriculum Standards / Data Structures & Algorithms Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/aoa-lab/',
    aim: 'To formulate and solve the Fractional Knapsack problem using the Greedy approach by sorting items by density (value/weight ratio).',
    theory: {
      overview: [
        'In the Fractional Knapsack problem, an item can be broken into fractional parts. The thief has a knapsack with maximum weight capacity W.',
        'Greedy Choice Property: A globally optimal solution can be arrived at by making locally optimal greedy choices.',
        'Optimal Strategy: Calculate the value-to-weight ratio (v_i / w_i) for each item, sort descending, and greedily take as much of the highest-ratio item as possible until the knapsack is full.',
        'Time Complexity is dominated by sorting: O(n log n).'
      ],
      complexityTable: [
        { parameter: 'Time Complexity', value: 'O(n log n) for ratio sorting' },
        { parameter: 'Space Complexity', value: 'O(1) auxiliary in-place sorting' }
      ],
      keyPoints: [
        'Fractional knapsack is solvable by Greedy; 0/1 knapsack requires Dynamic Programming.',
        'Fractional strategy achieves the theoretical upper bound on profit.'
      ],
      realWorldApplications: [
        'Resource bandwidth allocation in communications networks.',
        'Cargo container freight optimization where commodities can be subdivided (grain, liquids).'
      ]
    },
    algorithm: [
      '1. For each item i, compute ratio = value[i] / weight[i].',
      '2. Sort all items in non-increasing order of their ratio.',
      '3. Initialize current_weight = 0, total_value = 0.',
      '4. For each sorted item i:',
      '    a. If current_weight + weight[i] <= W:',
      '        i. Add full item: current_weight += weight[i], total_value += value[i].',
      '    b. Else (remaining capacity available):',
      '        i. fraction = (W - current_weight) / weight[i].',
      '        ii. total_value += value[i] * fraction; current_weight = W; break.',
      '5. Return total_value.'
    ],
    procedure: [
      '1. Open Fractional Knapsack Simulator.',
      '2. Set Knapsack Capacity W = 50 kg.',
      '3. Define items with weights and values.',
      '4. Observe items ranked by Value/Weight density.',
      '5. View step-by-step knapsack filling with fractional breakdown.'
    ],
    code: {
      python: `def fractional_knapsack(capacity, items):
    # items = [(value, weight)]
    sorted_items = sorted(items, key=lambda x: x[0]/x[1], reverse=True)
    total_val = 0.0
    for val, wt in sorted_items:
        if capacity >= wt:
            capacity -= wt
            total_val += val
        else:
            total_val += val * (capacity / wt)
            break
    return total_val`,
      cpp: `// C++ Greedy Fractional Knapsack`
    },
    sampleInput: 'Capacity: 50, Items: (val: 60, wt: 10), (val: 100, wt: 20), (val: 120, wt: 30)',
    expectedOutput: 'Total Maximum Value: 240.0 (Item 1: 100%, Item 2: 100%, Item 3: 66.7%).',
    references: ['CLRS Chapter 16: Greedy Algorithms'],
    conclusion: 'Greedy value/weight density prioritization yielded the provably optimal solution for fractional packing.',
    quiz: [
      {
        id: 1,
        question: 'Why does the greedy strategy fail for the 0/1 Knapsack problem while succeeding for Fractional Knapsack?',
        options: [
          'Because items cannot be subdivided, leaving empty capacity that higher-density items might not efficiently fill compared to combinations of other items',
          'Because greedy algorithms cannot compare integers',
          'Because 0/1 knapsack has no optimal substructure',
          'Because sorting takes too long'
        ],
        correctAnswer: 0,
        explanation: 'In 0/1 knapsack, taking a high-ratio item might leave unused space that could have held two items with higher combined value; this indivisibility necessitates dynamic programming.'
      }
    ]
  },
  {
    id: 'aoa-exp3',
    num: 3,
    subjectId: 'aoa',
    title: 'Dynamic Programming: 0/1 Knapsack & Bellman Optimality',
    subtitle: 'Overlapping Subproblems, Memoization Table & Backtracking Decision Path',
    category: 'Dynamic Programming',
    iitReference: 'Autonomous Curriculum Standards / Data Structures & Algorithms Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/aoa-lab/',
    aim: 'To implement the 0/1 Knapsack problem using 2D tabular Dynamic Programming and reconstruct the exact chosen item subset.',
    theory: {
      overview: [
        'The 0/1 Knapsack problem restricts each item to either being taken completely (1) or left behind (0).',
        'Principle of Optimality: An optimal solution contains within it optimal solutions to subproblems.',
        'Recurrence: dp[i][w] = dp[i-1][w] if wt[i] > w; else max(dp[i-1][w], val[i] + dp[i-1][w - wt[i]]).',
        'Pseudo-polynomial time complexity O(n * W).'
      ],
      complexityTable: [
        { parameter: 'Time Complexity', value: 'O(n * W) where n is item count, W is capacity' },
        { parameter: 'Space Complexity', value: 'O(n * W) table (can be optimized to O(W))' }
      ],
      keyPoints: [
        'Table entries dp[i][w] store maximum value using subset of first i items within weight budget w.',
        'Backtracking from dp[n][W] recovers the chosen items.'
      ],
      realWorldApplications: [
        'Capital budgeting and investment portfolio selection under constrained liquidity.',
        'Hardware memory partition management.'
      ]
    },
    algorithm: [
      '1. Create 2D array dp of size (n + 1) x (W + 1) initialized to 0.',
      '2. For i from 1 to n:',
      '    a. For w from 1 to W:',
      '        i. If wt[i-1] <= w: dp[i][w] = max(dp[i-1][w], val[i-1] + dp[i-1][w - wt[i-1]]).',
      '        ii. Else: dp[i][w] = dp[i-1][w].',
      '3. Reconstruct items: traverse backwards from (n, W). If dp[i][w] != dp[i-1][w], item i was included; w -= wt[i-1].',
      '4. Return dp[n][W] and list of included items.'
    ],
    procedure: [
      '1. Open 0/1 Knapsack Simulator.',
      '2. Input Capacity W = 8 and items [(1, 2), (2, 3), (5, 4), (6, 5)].',
      '3. Step through cell evaluations of the 2D DP matrix.',
      '4. Highlight the optimal path traced backwards from bottom-right.'
    ],
    code: {
      cpp: `#include <vector>
#include <algorithm>

int knapsack01(int W, const std::vector<int>& wt, const std::vector<int>& val, int n) {
    std::vector<std::vector<int>> dp(n + 1, std::vector<int>(W + 1, 0));
    for (int i = 1; i <= n; i++) {
        for (int w = 1; w <= W; w++) {
            if (wt[i-1] <= w)
                dp[i][w] = std::max(dp[i-1][w], val[i-1] + dp[i-1][w - wt[i-1]]);
            else
                dp[i][w] = dp[i-1][w];
        }
    }
    return dp[n][W];
}`,
      python: `def knapsack_01(W, wt, val, n):
    dp = [[0 for _ in range(W + 1)] for _ in range(n + 1)]
    for i in range(1, n + 1):
        for w in range(1, W + 1):
            if wt[i-1] <= w:
                dp[i][w] = max(dp[i-1][w], val[i-1] + dp[i-1][w - wt[i-1]])
            else:
                dp[i][w] = dp[i-1][w]
    return dp[n][W]`
    },
    sampleInput: 'W = 7, wt = [1, 3, 4, 5], val = [1, 4, 5, 7]',
    expectedOutput: 'Maximum Value: 9 (Items with weight 3 and 4 chosen).',
    references: ['Richard Bellman (1957), Dynamic Programming, Princeton University Press'],
    conclusion: 'Dynamic programming avoided exponential 2^n combinatorial explosion by memoizing subproblem solutions in an O(n*W) table.',
    quiz: [
      {
        id: 1,
        question: 'What is the time complexity of the standard Dynamic Programming solution to the 0/1 Knapsack problem?',
        options: ['O(n * W) pseudo-polynomial', 'O(2^n)', 'O(n log n)', 'O(W^2)'],
        correctAnswer: 0,
        explanation: 'The standard DP table algorithm runs in O(n * W) time, which is pseudo-polynomial because its runtime depends on the numeric value of W rather than the number of bits.'
      }
    ]
  }
];
