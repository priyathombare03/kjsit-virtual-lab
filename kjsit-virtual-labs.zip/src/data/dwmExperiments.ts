import { LabExperiment } from '../types';

export const DWM_EXPERIMENTS: LabExperiment[] = [
  {
    id: 'dwm-exp1',
    num: 1,
    subjectId: 'dwm',
    title: 'Multidimensional Data Modeling: Star & Snowflake Schemas',
    subtitle: 'Fact Tables, Dimension Hierarchies, Measures & Surrogate Keys',
    category: 'Data Warehousing',
    iitReference: 'Autonomous Curriculum Standards / Data Warehousing Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/dwm-lab/',
    aim: 'To design and evaluate Multidimensional Data Schemas (Star Schema, Snowflake Schema, and Fact Constellation) for an enterprise sales analytical warehouse.',
    theory: {
      overview: [
        'A Data Warehouse is a subject-oriented, integrated, time-variant, and non-volatile collection of data in support of management decision-making.',
        'Star Schema consists of a centralized Fact Table containing numeric additive measures surrounded by denormalized Dimension Tables.',
        'Snowflake Schema normalizes dimension tables into sub-dimensions to eliminate data redundancy, trading query join performance for storage efficiency.',
        'Fact Constellation (Galaxy Schema) contains multiple fact tables sharing common dimension tables.'
      ],
      complexityTable: [
        { parameter: 'Star Schema Query Joins', value: 'O(k) single-level joins with dimensions' },
        { parameter: 'Snowflake Query Joins', value: 'O(k * d) multi-tier joins across normalized hierarchies' },
        { parameter: 'Maintenance Overhead', value: 'Higher update anomaly in Star due to redundancy' }
      ],
      keyPoints: [
        'Fact Table: Grain, foreign keys to dimensions, additive/semi-additive measures (revenue, quantity).',
        'Surrogate Keys: System-generated integer keys isolating analytics from source OLTP changes.'
      ],
      realWorldApplications: [
        'Retail e-commerce revenue analytics across time, store location, and product hierarchy.',
        'Healthcare patient stay analytics tracking diagnoses, hospital wards, and insurance payouts.'
      ]
    },
    algorithm: [
      '1. Identify the business process (e.g., Retail Sales Transaction).',
      '2. Declare the grain: one row per product sold on each sales invoice line.',
      '3. Identify the dimensions: DateDim, CustomerDim, ProductDim, StoreDim.',
      '4. Identify numerical measures: quantity_sold, unit_price, discount_amount, total_revenue.',
      '5. Construct Star Schema SQL DDL with surrogate primary keys and foreign key relationships.',
      '6. Generate Snowflake normalized hierarchy for Product -> Category -> Department.'
    ],
    procedure: [
      '1. Open Multidimensional Schema Designer in DWM Simulator.',
      '2. Drag and drop Fact and Dimension tables onto the canvas.',
      '3. Connect foreign keys and inspect SQL DDL generation.',
      '4. Toggle between Star and Snowflake architectures to observe join graph complexity.'
    ],
    code: {
      sql: `-- Star Schema DDL for Enterprise Sales Mart
CREATE TABLE Dim_Date (
    date_key INT PRIMARY KEY,
    full_date DATE NOT NULL,
    day_of_week VARCHAR(15),
    fiscal_quarter CHAR(2),
    fiscal_year INT
);

CREATE TABLE Dim_Product (
    product_key INT PRIMARY KEY,
    product_sku VARCHAR(50),
    product_name VARCHAR(255),
    category_name VARCHAR(100),
    unit_cost DECIMAL(10,2)
);

CREATE TABLE Fact_Sales (
    sales_id BIGINT PRIMARY KEY,
    date_key INT REFERENCES Dim_Date(date_key),
    product_key INT REFERENCES Dim_Product(product_key),
    store_key INT,
    quantity_sold INT,
    gross_revenue DECIMAL(12,2),
    net_profit DECIMAL(12,2)
);`,
      python: `import pandas as pd
# Python OLAP dimensional modeling using pandas and sqlite3`,
      cpp: `// C++ Data warehouse engine`
    },
    sampleInput: 'Fact Sales Grain: Hourly item sales across 5 regional stores',
    expectedOutput: 'Star Schema with 1 Fact table and 4 Dimension tables generated and validated.',
    references: ['Ralph Kimball and Margy Ross, The Data Warehouse Toolkit (3rd Edition), Wiley'],
    conclusion: 'Star Schema provided optimal analytical query join performance with intuitive business dimension navigability.',
    quiz: [
      {
        id: 1,
        question: 'What distinguishes a Snowflake Schema from a Star Schema?',
        options: [
          'In a Snowflake Schema, dimension tables are normalized into sub-dimensions, whereas in a Star Schema, dimension tables are denormalized',
          'A Snowflake schema cannot have numeric measures',
          'A Snowflake schema contains no fact tables',
          'A Star schema only operates on SQLite'
        ],
        correctAnswer: 0,
        explanation: 'The snowflake schema normalizes dimension tables into multiple related hierarchies to reduce redundancy, while the star schema leaves dimension tables completely denormalized.'
      }
    ]
  },
  {
    id: 'dwm-exp2',
    num: 2,
    subjectId: 'dwm',
    title: 'OLAP Operations: Roll-Up, Drill-Down, Slice, Dice & Pivot',
    subtitle: 'Multidimensional Data Cube Navigations and Aggregations',
    category: 'OLAP Operations',
    iitReference: 'Autonomous Curriculum Standards / Data Warehousing Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/dwm-lab/',
    aim: 'To perform online analytical processing (OLAP) multidimensional operations: Roll-Up, Drill-Down, Slice, Dice, and Pivot on a 3D Sales Data Cube.',
    theory: {
      overview: [
        'An OLAP Data Cube is a multidimensional data representation that enables rapid analytical querying across multiple orthogonal axes (e.g., Time x Product x Location).',
        'Roll-Up: Aggregates data by climbing up a concept hierarchy or reducing dimensionality (e.g., Day -> Month -> Year).',
        'Drill-Down: Navigates from higher-level summary data to lower-level detailed data (e.g., Country -> State -> City).',
        'Slice: Selects a single dimension value to produce a 2D sub-cube. Dice: Selects a sub-cube by specifying range filters across multiple dimensions.',
        'Pivot (Rotate): Reorients the dimensional axes of the analytical view.'
      ],
      complexityTable: [
        { parameter: 'MOLAP Pre-computed Query', value: 'O(1) array index access' },
        { parameter: 'ROLAP SQL Aggregation', value: 'O(n log n) with GROUP BY CUBE / ROLLUP' }
      ],
      keyPoints: [
        'Concept Hierarchy: Predefined ordering of attributes from general to specific.',
        'MOLAP (Multidimensional OLAP) vs ROLAP (Relational OLAP) vs HOLAP (Hybrid OLAP).'
      ],
      realWorldApplications: [
        'Business Intelligence executive dashboards (PowerBI, Tableau).',
        'Supply chain inventory visibility across regional fulfillment centers.'
      ]
    },
    algorithm: [
      '1. Instantiate a 3D Sales Cube: Dimensions = [Location (Mumbai, Pune, Delhi), Time (Q1, Q2, Q3, Q4), Product (Laptop, Phone, Tablet)].',
      '2. Execute Slice: Filter Location = "Mumbai" to extract 2D Time x Product matrix.',
      '3. Execute Dice: Filter Location IN ("Mumbai", "Pune") AND Time IN ("Q1", "Q2") AND Product = "Laptop".',
      '4. Execute Roll-Up: Aggregate sales over Time across all locations, collapsing location axis.',
      '5. Execute Drill-Down: Expand Product category into specific sub-models.',
      '6. Execute Pivot: Swap Time and Product axes for cross-tabulated reporting.'
    ],
    procedure: [
      '1. Open the Interactive 3D OLAP Cube Simulator.',
      '2. Select an operation button (Slice, Dice, Roll-Up, Drill-Down, Pivot).',
      '3. Observe the highlighted cube sub-matrix and updated tabular aggregation.',
      '4. View the corresponding ANSI SQL GROUP BY CUBE syntax.'
    ],
    code: {
      sql: `-- ANSI SQL OLAP Aggregation using CUBE and ROLLUP
SELECT 
    COALESCE(l.region, 'ALL REGIONS') as region,
    COALESCE(t.quarter, 'ALL QUARTERS') as quarter,
    COALESCE(p.category, 'ALL PRODUCTS') as category,
    SUM(f.gross_revenue) as total_revenue
FROM Fact_Sales f
JOIN Dim_Location l ON f.location_key = l.location_key
JOIN Dim_Time t ON f.time_key = t.time_key
JOIN Dim_Product p ON f.product_key = p.product_key
GROUP BY CUBE(l.region, t.quarter, p.category);`,
      python: `import pandas as pd
# Python OLAP Pivot & Slicing
df = pd.DataFrame(...)
pivot_table = pd.pivot_table(df, values='sales', index=['region'], columns=['quarter'], aggfunc='sum')`
    },
    sampleInput: '3D Cube [Location: 3, Time: 4, Product: 3]. Execute Slice(Location="Mumbai")',
    expectedOutput: '2D Matrix (4 Quarters x 3 Products) with sliced cell values displayed.',
    references: ['Jiawei Han, Micheline Kamber, and Jian Pei, Data Mining: Concepts and Techniques (3rd Edition), Morgan Kaufmann'],
    conclusion: 'OLAP cube operations demonstrated instantaneous drill-down and multidimensional slice-and-dice data exploration.',
    quiz: [
      {
        id: 1,
        question: 'Which OLAP operation navigates from less detailed data to more detailed data along a concept hierarchy?',
        options: ['Drill-Down', 'Roll-Up', 'Slice', 'Pivot'],
        correctAnswer: 0,
        explanation: 'Drill-down climbs down the concept hierarchy (e.g. from Year to Quarter to Month) to reveal finer granularity details.'
      }
    ]
  },
  {
    id: 'dwm-exp3',
    num: 3,
    subjectId: 'dwm',
    title: 'Association Rule Mining: Apriori Algorithm',
    subtitle: 'Frequent Itemset Discovery, Support, Confidence & Lift Metrics',
    category: 'Data Mining',
    iitReference: 'Autonomous Curriculum Standards / Data Mining Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/dwm-lab/',
    aim: 'To discover frequent itemsets and generate strong association rules using the Apriori property on retail market basket transaction datasets.',
    theory: {
      overview: [
        'Association Rule Mining seeks to uncover interesting relationships and correlations among sets of items in transaction databases.',
        'An association rule is an implication of the form X -> Y, where X and Y are disjoint itemsets.',
        'Support = count(X ∪ Y) / N: Fraction of transactions containing both X and Y.',
        'Confidence = Support(X ∪ Y) / Support(X): Probability that transaction contains Y given it contains X.',
        'The Apriori Property: All non-empty subsets of a frequent itemset must also be frequent (anti-monotonicity of support). If an itemset is infrequent, all its supersets will also be infrequent.'
      ],
      complexityTable: [
        { parameter: 'Candidate Generation', value: 'O(2^d) worst case where d is distinct items' },
        { parameter: 'Apriori Pruning', value: 'Dramatically prunes candidate search tree at each level k' }
      ],
      keyPoints: [
        'Lift = Confidence(X -> Y) / Support(Y): Measures dependency (> 1 indicates positive correlation).',
        'Frequent itemset generation dominates algorithm runtime.'
      ],
      realWorldApplications: [
        'Supermarket shelf layout optimization (Market Basket Analysis).',
        'Cross-selling recommendation systems in e-commerce (Customers who bought X also bought Y).'
      ]
    },
    algorithm: [
      '1. Scan database D to find support for each 1-itemset; filter by min_support to obtain L1.',
      '2. For k = 2; while L(k-1) is not empty; k++:',
      '    a. Join Step: Candidate itemset Ck = L(k-1) ⋈ L(k-1) on first k-2 shared items.',
      '    b. Prune Step: Remove any candidate in Ck having a (k-1) subset that is not in L(k-1).',
      '    c. Scan database to compute actual support for remaining candidates in Ck.',
      '    d. Filter candidates meeting min_support to form Lk.',
      '3. From all frequent itemsets L, generate rules X -> (L - X) meeting min_confidence.'
    ],
    procedure: [
      '1. Open Apriori Simulator.',
      '2. Load market basket dataset (Transactions with Bread, Butter, Milk, Eggs).',
      '3. Set Minimum Support (e.g. 30%) and Minimum Confidence (e.g. 60%).',
      '4. Step through Level 1, Level 2, and Level 3 candidate generation and pruning.',
      '5. View generated rules sorted by Lift.'
    ],
    code: {
      python: `from itertools import combinations
from typing import List, Set, Dict

def get_support(itemset: Set[str], transactions: List[Set[str]]) -> float:
    return sum(1 for t in transactions if itemset.issubset(t)) / len(transactions)

def apriori(transactions: List[Set[str]], min_sup: float, min_conf: float):
    items = set.union(*transactions)
    # L1
    L1 = {frozenset([item]): get_support({item}, transactions) for item in items}
    L1 = {k: v for k, v in L1.items() if v >= min_sup}
    
    current_L = L1
    all_frequent = dict(L1)
    k = 2
    
    while current_L:
        # Candidate Generation
        prev_items = list(current_L.keys())
        candidates = set()
        for i in range(len(prev_items)):
            for j in range(i + 1, len(prev_items)):
                union_set = prev_items[i] | prev_items[j]
                if len(union_set) == k:
                    candidates.add(union_set)
        
        # Pruning & Support calculation
        next_L = {}
        for cand in candidates:
            sup = get_support(set(cand), transactions)
            if sup >= min_sup:
                next_L[cand] = sup
        all_frequent.update(next_L)
        current_L = next_L
        k += 1
        
    return all_frequent`
    },
    sampleInput: 'Transactions: {Bread, Milk}, {Bread, Diaper, Beer, Eggs}, {Milk, Diaper, Beer, Cola}, {Bread, Milk, Diaper, Beer}',
    expectedOutput: 'Frequent Itemsets: {Diaper, Beer} (Sup: 75%), Rule: Diaper -> Beer (Conf: 100%, Lift: 1.33)',
    references: ['Rakesh Agrawal and Ramakrishnan Srikant (1994), Fast Algorithms for Mining Association Rules'],
    conclusion: 'Apriori anti-monotonicity pruned millions of infeasible candidate itemsets, discovering actionable purchase correlations.',
    quiz: [
      {
        id: 1,
        question: 'According to the Apriori property, if an itemset {A, B} is found to be INFREQUENT (below min_support), what can be concluded about {A, B, C}?',
        options: [
          '{A, B, C} must also be infrequent and can be immediately pruned without scanning the database',
          '{A, B, C} must be frequent',
          'Its support must be calculated manually',
          'It depends on the value of min_confidence'
        ],
        correctAnswer: 0,
        explanation: 'The Apriori property states that all supersets of an infrequent itemset are guaranteed to be infrequent, allowing the algorithm to prune them immediately.'
      }
    ]
  },
  {
    id: 'dwm-exp4',
    num: 4,
    subjectId: 'dwm',
    title: 'Cluster Analysis: K-Means Partitioning & Elbow Method',
    subtitle: 'Iterative Centroid Relocation, Euclidean Distance & Inertia Minimization',
    category: 'Unsupervised Mining',
    iitReference: 'Autonomous Curriculum Standards / Data Mining Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/dwm-lab/',
    aim: 'To implement K-Means clustering from scratch, visualize 2D centroid trajectories, and determine optimal k using the Within-Cluster Sum of Squares (WCSS) Elbow curve.',
    theory: {
      overview: [
        'Clustering is the unsupervised task of grouping a set of objects such that objects in the same group (cluster) are more similar to each other than to those in other groups.',
        'K-Means partitions n observations into k clusters, with each observation belonging to the cluster with the nearest mean (centroid).',
        'Objective Function: Minimize Within-Cluster Sum of Squares (WCSS) J = Σ Σ ||x - μ_i||^2.',
        'Elbow Method plots WCSS against k; the "elbow" bend represents the point of diminishing returns in cluster compactness.'
      ],
      complexityTable: [
        { parameter: 'Time Complexity', value: 'O(t * k * n * d) where t is iterations, k is clusters, n is points, d is dimensions' },
        { parameter: 'Space Complexity', value: 'O(n * d + k * d) - Compact memory footprint' }
      ],
      keyPoints: [
        'K-Means++ initialization spreads initial centroids apart, avoiding poor local minima.',
        'Sensitive to outliers and assumes spherical clusters with equal variance.'
      ],
      realWorldApplications: [
        'Customer segmentation for targeted marketing campaigns.',
        'Color quantization in image processing and image compression.'
      ]
    },
    algorithm: [
      '1. Choose number of clusters k.',
      '2. Initialize k centroids randomly or using K-Means++.',
      '3. Repeat until centroids do not change (or max_iter reached):',
      '    a. Assignment Step: Assign each data point xi to the closest centroid cj based on Euclidean distance.',
      '    b. Update Step: Recompute centroid cj as the arithmetic mean of all points assigned to cluster j.',
      '4. Compute total WCSS across all clusters.',
      '5. Repeat for k = 1..8 and plot Elbow Curve.'
    ],
    procedure: [
      '1. Open K-Means Simulator.',
      '2. Generate synthetic customer dataset with clusters.',
      '3. Select k = 3 and click "Step" to observe centroid movement.',
      '4. Inspect Voronoi partition boundaries.',
      '5. Click "Elbow Analysis" to evaluate the optimal k.'
    ],
    code: {
      python: `import numpy as np

def kmeans(X: np.ndarray, k: int, max_iter: int = 100):
    # K-Means++ or random initialization
    np.random.seed(42)
    centroids = X[np.random.choice(len(X), k, replace=False)]
    
    for _ in range(max_iter):
        # Distance calculation
        distances = np.linalg.norm(X[:, np.newaxis] - centroids, axis=2)
        labels = np.argmin(distances, axis=1)
        
        # Centroid update
        new_centroids = np.array([X[labels == i].mean(axis=0) if len(X[labels == i]) > 0 else centroids[i] for i in range(k)])
        
        if np.allclose(centroids, new_centroids):
            break
        centroids = new_centroids
        
    wcss = sum(np.sum((X[labels == i] - centroids[i]) ** 2) for i in range(k))
    return centroids, labels, wcss`
    },
    sampleInput: 'Dataset with 300 2D customer vectors (Annual Income, Spending Score). Target k = 3.',
    expectedOutput: 'Final Centroids: [[25.1, 79.3], [86.5, 82.1], [55.2, 49.8]], Total WCSS: 1423.85, Optimal k = 3.',
    references: [
      'MacQueen, J. (1967). Some methods for classification and analysis of multivariate observations. Proc. 5th Berkeley Symp.',
      'Arthur, D., & Vassilvitskii, S. (2007). k-means++: The advantages of careful seeding. SODA.',
      'Han, J., Kamber, M., & Pei, J. Data Mining: Concepts and Techniques (3rd ed.). Morgan Kaufmann.'
    ],
    conclusion: 'Successfully partitioned multi-dimensional customer data into cohesive clusters and determined optimal cluster count using the Elbow Method.',
    quiz: [
      {
        id: 1,
        question: 'What metric does the Elbow method analyze to find the optimal number of clusters?',
        options: [
          'Within-Cluster Sum of Squares (WCSS) / Inertia',
          'Silhouette Score',
          'Davies-Bouldin Index',
          'Entropy'
        ],
        correctAnswer: 0,
        explanation: 'The Elbow method plots WCSS (Within-Cluster Sum of Squares) against the number of clusters k to identify where the rate of decrease sharply slows down.'
      },
      {
        id: 2,
        question: 'How does K-Means++ improve standard K-Means clustering?',
        options: [
          'By running more iterations',
          'By smartly initializing centroids far from each other with probability proportional to squared distance',
          'By transforming features into higher-dimensional space',
          'By eliminating the need to specify k'
        ],
        correctAnswer: 1,
        explanation: 'K-Means++ samples initial centroids with probability proportional to the squared Euclidean distance from the nearest existing centroid, dramatically reducing the probability of bad clusterings.'
      }
    ]
  }
];
