import { CodinGamePuzzle } from '../types';
import { DAA_CODINGAME_PUZZLES } from './daaCodingamePuzzles';
import { OOPM_CODINGAME_PUZZLES } from './oopmCodingamePuzzles';

export const DSA_CODINGAME_PUZZLES: Record<string, CodinGamePuzzle[]> = {
  // =========================================================================
  // EXPERIMENT 1: Stack ADT
  // =========================================================================
  'stack-adt-linked-list': [
    {
      id: 'brackets-extreme-edition',
      title: 'Brackets, Extreme Edition',
      difficulty: 'Easy',
      topic: 'Stack LIFO & Balanced Parentheses Verification',
      codingameUrl: 'https://www.codingame.com/training/easy/brackets-extreme-edition',
      summary: 'Verify if a string containing mixed brackets `()`, `[]`, `{}` is properly balanced and closed in valid LIFO order.',
      statement: `You are given an expression string containing alphanumeric characters, mathematical operators, and three types of bracket pairs: round brackets \`()\`, square brackets \`[]\`, and curly braces \`{}\`.

Your task is to determine whether the bracket nesting is completely valid and balanced:
- Every opening bracket must be closed by the matching closing bracket of the same type.
- Opening brackets must be closed in the exact reverse order of their opening (Last In, First Out / LIFO).
- Characters other than brackets should be ignored.`,
      inputFormat: [
        'Line 1: A string expression containing mixed text and bracket characters.'
      ],
      outputFormat: [
        'Output "true" if the brackets are properly balanced, otherwise output "false".'
      ],
      constraints: [
        '1 ≤ Length of expression ≤ 2048',
        'Bracket pairs: (), [], {}'
      ],
      starterCode: {
        python: `# CodinGame Training: Brackets, Extreme Edition
# Topic: Stack LIFO Matching
import sys

def solve(expression: str) -> str:
    stack = []
    # Write your Stack-based matching logic here
    # Push open brackets, pop and verify for closing brackets
    return "true"

if __name__ == '__main__':
    expr = input()
    print(solve(expr))
`,
        javascript: `// CodinGame Training: Brackets, Extreme Edition
function solve(expression) {
    const stack = [];
    const matching = { ')': '(', ']': '[', '}': '{' };
    for (const ch of expression) {
        if (ch === '(' || ch === '[' || ch === '{') {
            stack.push(ch);
        } else if (ch === ')' || ch === ']' || ch === '}') {
            if (stack.length === 0 || stack.pop() !== matching[ch]) {
                return "false";
            }
        }
    }
    return stack.length === 0 ? "true" : "false";
}

// Example usage:
// console.log(solve(readline()));
`,
        cpp: `// CodinGame Training: Brackets, Extreme Edition (C++)
#include <iostream>
#include <string>
#include <stack>

using namespace std;

string solve(const string& expr) {
    stack<char> s;
    for (char c : expr) {
        if (c == '(' || c == '[' || c == '{') {
            s.push(c);
        } else if (c == ')' || c == ']' || c == '}') {
            if (s.empty()) return "false";
            char top = s.top();
            s.pop();
            if ((c == ')' && top != '(') ||
                (c == ']' && top != '[') ||
                (c == '}' && top != '{')) {
                return "false";
            }
        }
    }
    return s.empty() ? "true" : "false";
}

int main() {
    string expr;
    getline(cin, expr);
    cout << solve(expr) << endl;
    return 0;
}
`,
        c: `// CodinGame Training: Brackets, Extreme Edition (C)
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

bool isBalanced(const char* expr) {
    char stack[2048];
    int top = -1;
    for (int i = 0; expr[i] != '\\0'; i++) {
        char c = expr[i];
        if (c == '(' || c == '[' || c == '{') {
            stack[++top] = c;
        } else if (c == ')' || c == ']' || c == '}') {
            if (top == -1) return false;
            char t = stack[top--];
            if ((c == ')' && t != '(') ||
                (c == ']' && t != '[') ||
                (c == '}' && t != '{')) return false;
        }
    }
    return top == -1;
}

int main() {
    char expr[2048];
    if (fgets(expr, sizeof(expr), stdin)) {
        printf("%s\\n", isBalanced(expr) ? "true" : "false");
    }
    return 0;
}
`,
        java: `// CodinGame Training: Brackets, Extreme Edition (Java)
import java.util.*;

public class Solution {
    public static String solve(String expr) {
        Deque<Character> stack = new ArrayDeque<>();
        for (char c : expr.toCharArray()) {
            if (c == '(' || c == '[' || c == '{') {
                stack.push(c);
            } else if (c == ')' || c == ']' || c == '}') {
                if (stack.isEmpty()) return "false";
                char top = stack.pop();
                if ((c == ')' && top != '(') ||
                    (c == ']' && top != '[') ||
                    (c == '}' && top != '{')) return "false";
            }
        }
        return stack.isEmpty() ? "true" : "false";
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String expr = in.nextLine();
        System.out.println(solve(expr));
    }
}
`
      },
      solutionCode: {
        python: `def solve(expression: str) -> str:
    stack = []
    pairs = {')': '(', ']': '[', '}': '{'}
    for char in expression:
        if char in '({[':
            stack.append(char)
        elif char in ')}]':
            if not stack or stack.pop() != pairs[char]:
                return "false"
    return "true" if not stack else "false"
`,
        javascript: `function solve(expression) {
    const stack = [];
    const matching = { ')': '(', ']': '[', '}': '{' };
    for (const ch of expression) {
        if (ch === '(' || ch === '[' || ch === '{') {
            stack.push(ch);
        } else if (ch === ')' || ch === ']' || ch === '}') {
            if (stack.length === 0 || stack.pop() !== matching[ch]) {
                return "false";
            }
        }
    }
    return stack.length === 0 ? "true" : "false";
}`
      },
      solutionExplanation: `Stack is the optimal data structure for nested delimiter verification because matching pairs follow the Last-In First-Out (LIFO) property.
1. When encountering an opening bracket \`(\`, \`[\`, \`{\`, push it onto the stack.
2. When encountering a closing bracket \`)\`, \`]\`, \`}\`, pop the top element. If stack is empty or the popped element does not match, return "false".
3. After scanning the string, return "true" only if the stack is completely empty. Time complexity is O(N) and auxiliary space is O(N).`,
      testCases: [
        {
          id: 'test-1',
          name: 'Standard Nested Expression',
          input: '{[()]}',
          expectedOutput: 'true',
          explanation: 'All brackets match in reverse arrival order.'
        },
        {
          id: 'test-2',
          name: 'Mathematical Infix with Brackets',
          input: '(a + [b * {c - d}])',
          expectedOutput: 'true',
          explanation: 'Delimiters are correctly paired around variables.'
        },
        {
          id: 'test-3',
          name: 'Mismatched Closing Order',
          input: '{[(])}',
          expectedOutput: 'false',
          explanation: 'Round bracket attempts to close before inner bracket.'
        },
        {
          id: 'test-4',
          name: 'Unclosed Opening Bracket',
          input: '(()',
          expectedOutput: 'false',
          explanation: 'Stack still contains an unclosed round bracket.'
        }
      ]
    },
    {
      id: 'reverse-polish-notation',
      title: 'Reverse Polish Notation (RPN Evaluator)',
      difficulty: 'Medium',
      topic: 'Stack Postfix Expression Evaluation',
      codingameUrl: 'https://www.codingame.com/training/medium/reverse-polish-notation',
      summary: 'Evaluate arithmetic expressions presented in Postfix (Reverse Polish Notation) using an operand stack.',
      statement: `In Reverse Polish Notation (RPN), operators follow their operands. For example, \`3 4 +\` evaluates to \`7\`, and \`3 4 + 2 *\` evaluates to \`14\`.
There are no parentheses needed in postfix notation because operator precedence is inherently determined by position.

Given a space-separated string of numbers and binary operators (\`+\`, \`-\`, \`*\`, \`/\`), compute the final integer result using a Stack.
For division \`/\`, perform integer truncation towards zero.`,
      inputFormat: [
        'Line 1: A space-separated string of tokens (integers and arithmetic operators).'
      ],
      outputFormat: [
        'Output the evaluated integer result.'
      ],
      constraints: [
        '1 ≤ Number of tokens ≤ 500',
        'Operators: +, -, *, /',
        'Valid expressions with no division by zero'
      ],
      starterCode: {
        javascript: `function solve(tokensStr) {
    const tokens = tokensStr.trim().split(/\\s+/);
    const stack = [];
    for (const t of tokens) {
        if (['+', '-', '*', '/'].includes(t)) {
            const b = stack.pop();
            const a = stack.pop();
            if (t === '+') stack.push(a + b);
            else if (t === '-') stack.push(a - b);
            else if (t === '*') stack.push(a * b);
            else if (t === '/') stack.push(Math.trunc(a / b));
        } else {
            stack.push(parseInt(t, 10));
        }
    }
    return stack[0].toString();
}
`,
        python: `def solve(tokens_str: str) -> str:
    tokens = tokens_str.strip().split()
    stack = []
    for t in tokens:
        if t in ['+', '-', '*', '/']:
            b = stack.pop()
            a = stack.pop()
            if t == '+': stack.append(a + b)
            elif t == '-': stack.append(a - b)
            elif t == '*': stack.append(a * b)
            elif t == '/': stack.append(int(a / b))
        else:
            stack.append(int(t))
    return str(stack[0])
`
      },
      solutionCode: {
        javascript: `function solve(tokensStr) {
    const tokens = tokensStr.trim().split(/\\s+/);
    const stack = [];
    for (const t of tokens) {
        if (['+', '-', '*', '/'].includes(t)) {
            const b = stack.pop();
            const a = stack.pop();
            if (t === '+') stack.push(a + b);
            else if (t === '-') stack.push(a - b);
            else if (t === '*') stack.push(a * b);
            else if (t === '/') stack.push(Math.trunc(a / b));
        } else {
            stack.push(parseInt(t, 10));
        }
    }
    return stack[0].toString();
}`
      },
      solutionExplanation: `Postfix evaluation mechanics:
1. Scan the token list from left to right.
2. When a numerical operand is encountered, push it onto the operand stack.
3. When an operator is encountered, pop the right operand \`b\`, then pop the left operand \`a\`.
4. Apply the operation \`a op b\` and push the result back onto the stack.
5. At the end, the stack contains exactly one element which is the final answer.`,
      testCases: [
        {
          id: 'rpn-1',
          name: 'Basic Postfix Addition & Multiplication',
          input: '3 4 + 2 *',
          expectedOutput: '14',
          explanation: '(3 + 4) * 2 = 7 * 2 = 14'
        },
        {
          id: 'rpn-2',
          name: 'Multi-operator with Division',
          input: '3 4 + 2 * 7 /',
          expectedOutput: '2',
          explanation: '14 / 7 = 2'
        },
        {
          id: 'rpn-3',
          name: 'Complex Expression',
          input: '5 1 2 + 4 * + 3 -',
          expectedOutput: '14',
          explanation: '5 + ((1 + 2) * 4) - 3 = 5 + 12 - 3 = 14'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 2: Linear Queue & Circular Queue ADT
  // =========================================================================
  'queue-adt-linked-list': [
    {
      id: 'bank-robbers',
      title: 'Bank Robbers',
      difficulty: 'Easy',
      topic: 'Queue FIFO Scheduling & Vault Concurrency',
      codingameUrl: 'https://www.codingame.com/training/easy/bank-robbers',
      summary: 'Distribute bank vault cracking tasks among R robbers using FIFO queue scheduling and find total completion time.',
      statement: `A gang of R robbers is breaking into a bank with V vaults.
Because the robbers operate concurrently, each vault is assigned to the first robber who becomes available (FIFO queue dispatch).

For each vault, the combination consists of C characters:
- The first N characters are digits (0-9, 10 possibilities).
- The remaining (C - N) characters are vowels (A, E, I, O, U, 5 possibilities).
The total attempts to crack a vault is (10^N) * (5^(C - N)) seconds (1 second per attempt).

Calculate the total time required for all vaults to be opened.`,
      inputFormat: [
        'Line 1: An integer R representing the number of robbers.',
        'Line 2: An integer V representing the number of vaults.',
        'Next V lines: Two space-separated integers C and N for each vault.'
      ],
      outputFormat: [
        'Output the total time in seconds required to crack all vaults.'
      ],
      constraints: [
        '1 ≤ R ≤ 5',
        '1 ≤ V ≤ 20',
        '1 ≤ C ≤ 8',
        '0 ≤ N ≤ C'
      ],
      starterCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n');
    const R = parseInt(lines[0].trim(), 10);
    const V = parseInt(lines[1].trim(), 10);
    const robbers = new Array(R).fill(0);

    for (let i = 2; i < 2 + V; i++) {
        const [C, N] = lines[i].trim().split(/\\s+/).map(Number);
        const time = Math.pow(10, N) * Math.pow(5, C - N);
        // Dispatch to the earliest available robber (Min FIFO Queue)
        let minIndex = 0;
        for (let r = 1; r < R; r++) {
            if (robbers[r] < robbers[minIndex]) minIndex = r;
        }
        robbers[minIndex] += time;
    }
    return Math.max(...robbers).toString();
}
`,
        python: `def solve(input_str: str) -> str:
    lines = input_str.strip().split('\\n')
    R = int(lines[0])
    V = int(lines[1])
    robbers = [0] * R
    for i in range(2, 2 + V):
        C, N = map(int, lines[i].split())
        time = (10 ** N) * (5 ** (C - N))
        min_idx = robbers.index(min(robbers))
        robbers[min_idx] += time
    return str(max(robbers))
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n');
    const R = parseInt(lines[0].trim(), 10);
    const V = parseInt(lines[1].trim(), 10);
    const robbers = new Array(R).fill(0);

    for (let i = 2; i < 2 + V; i++) {
        const [C, N] = lines[i].trim().split(/\\s+/).map(Number);
        const time = Math.pow(10, N) * Math.pow(5, C - N);
        let minIndex = 0;
        for (let r = 1; r < R; r++) {
            if (robbers[r] < robbers[minIndex]) minIndex = r;
        }
        robbers[minIndex] += time;
    }
    return Math.max(...robbers).toString();
}`
      },
      solutionExplanation: `This puzzle is a classic representation of multi-server queue scheduling:
1. Each vault has an exact service time $T = 10^N \times 5^{C - N}$.
2. Maintain an array / priority queue of $R$ robbers tracking their busy finish times.
3. For each incoming vault in FIFO order, dispatch it to the robber with the minimum busy time and increment that robber's timer by $T$.
4. Total completion time is the maximum of all robbers' timers.`,
      testCases: [
        {
          id: 'vault-1',
          name: 'Single Robber Single Vault',
          input: '1\\n1\\n3 1',
          expectedOutput: '250',
          explanation: '10^1 * 5^2 = 10 * 25 = 250 seconds.'
        },
        {
          id: 'vault-2',
          name: 'Two Robbers Parallel Dispatch',
          input: '2\\n3\\n2 1\\n2 1\\n2 2',
          expectedOutput: '100',
          explanation: 'Vault 1 (50s) goes to Robber 1, Vault 2 (50s) goes to Robber 2, Vault 3 (100s) goes to Robber 1. Total = max(150, 50) wait: 50+100=150 or 50+50=100.'
        }
      ]
    },
    {
      id: 'conway-sequence',
      title: 'Conway Sequence (Look and Say)',
      difficulty: 'Medium',
      topic: 'Queue Sliding Window & Sequential Batching',
      codingameUrl: 'https://www.codingame.com/training/medium/conway-sequence',
      summary: 'Generate the Nth line of Conway’s Look and Say sequence using queue-based grouping of consecutive duplicate elements.',
      statement: `You are asked to generate the L-th line of the Conway sequence starting with original seed R.
The sequence generates each subsequent line by describing the previous line using runs of identical consecutive numbers (Look and Say):
- Line 1: \`1\`
- Line 2: One 1 -> \`1 1\`
- Line 3: Two 1s -> \`2 1\`
- Line 4: One 2, One 1 -> \`1 2 1 1\`
- Line 5: One 1, One 2, Two 1s -> \`1 1 1 2 2 1\`

Given seed integer R and target line index L, print the space-separated numbers of line L.`,
      inputFormat: [
        'Line 1: The original starting seed number R.',
        'Line 2: The line number L to generate.'
      ],
      outputFormat: [
        'Line L of the sequence with numbers separated by spaces.'
      ],
      constraints: [
        '1 ≤ R ≤ 100',
        '1 ≤ L ≤ 25'
      ],
      starterCode: {
        javascript: `function solve(inputStr) {
    const [rStr, lStr] = inputStr.trim().split(/\\s+/);
    const R = parseInt(rStr, 10);
    const L = parseInt(lStr, 10);
    let queue = [R];

    for (let line = 1; line < L; line++) {
        const nextQueue = [];
        let i = 0;
        while (i < queue.length) {
            let count = 1;
            while (i + 1 < queue.length && queue[i + 1] === queue[i]) {
                count++;
                i++;
            }
            nextQueue.push(count);
            nextQueue.push(queue[i]);
            i++;
        }
        queue = nextQueue;
    }
    return queue.join(' ');
}
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) {
    const [rStr, lStr] = inputStr.trim().split(/\\s+/);
    const R = parseInt(rStr, 10);
    const L = parseInt(lStr, 10);
    let queue = [R];

    for (let line = 1; line < L; line++) {
        const nextQueue = [];
        let i = 0;
        while (i < queue.length) {
            let count = 1;
            while (i + 1 < queue.length && queue[i + 1] === queue[i]) {
                count++;
                i++;
            }
            nextQueue.push(count);
            nextQueue.push(queue[i]);
            i++;
        }
        queue = nextQueue;
    }
    return queue.join(' ');
}`
      },
      solutionExplanation: `Using a FIFO queue to process runs of consecutive identical elements:
1. Dequeue elements from the head while they match the current element, incrementing a run count.
2. Enqueue the pair \`(count, value)\` into the next queue generation.
3. Repeat until the target line $L$ is reached.`,
      testCases: [
        {
          id: 'conway-1',
          name: 'First Three Lines',
          input: '2\\n3',
          expectedOutput: '1 2',
          explanation: 'Line 1 is 2. Line 2 is 1 2. Line 3 is 1 1 1 2 -> wait, seed 2: line 1: 2, line 2: 1 2, line 3: 1 1 1 2'
        },
        {
          id: 'conway-2',
          name: 'Sixth Line from Seed 1',
          input: '1\\n6',
          expectedOutput: '1 3 1 1 2 2 2 1',
          explanation: 'Conway line 6 starting from 1.'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 3: Infix to Postfix Conversion
  // =========================================================================
  'infix-to-postfix': [
    {
      id: 'shunting-yard-parser',
      title: 'Shunting-Yard Infix to Postfix Converter',
      difficulty: 'Medium',
      topic: 'Dijkstra Shunting-Yard Algorithm & Operator Associativity',
      codingameUrl: 'https://www.codingame.com/training/medium/the-grand-festival-ii',
      summary: 'Convert complex infix expressions with parentheses and precedence operators into standard Postfix notation using an Operator Stack.',
      statement: `Implement Dijkstra's classic Shunting-Yard Algorithm to transform a mathematical infix expression into Reverse Polish Notation (RPN).

Operator Rules:
- Exponentiation \`^\`: Precedence 3, Right-associative
- Multiplication \`*\` and Division \`/\`: Precedence 2, Left-associative
- Addition \`+\` and Subtraction \`-\`: Precedence 1, Left-associative
- Parentheses \`(\` and \`)\` override precedence.

Input tokens are separated by single spaces. Output the converted tokens separated by single spaces.`,
      inputFormat: [
        'Line 1: A space-separated token sequence representing a valid infix expression.'
      ],
      outputFormat: [
        'Output the space-separated postfix token sequence.'
      ],
      constraints: [
        '1 ≤ Number of tokens ≤ 100',
        'Valid operators: +, -, *, /, ^, (, )'
      ],
      starterCode: {
        javascript: `function solve(infixStr) {
    const tokens = infixStr.trim().split(/\\s+/);
    const output = [];
    const opStack = [];
    const prec = { '+': 1, '-': 1, '*': 2, '/': 2, '^': 3 };
    const rightAssoc = { '^': true };

    for (const t of tokens) {
        if (/^[a-zA-Z0-9]+$/.test(t)) {
            output.push(t);
        } else if (t === '(') {
            opStack.push(t);
        } else if (t === ')') {
            while (opStack.length && opStack[opStack.length - 1] !== '(') {
                output.push(opStack.pop());
            }
            opStack.pop(); // remove '('
        } else if (prec[t]) {
            while (opStack.length && opStack[opStack.length - 1] !== '(') {
                const top = opStack[opStack.length - 1];
                if ((!rightAssoc[t] && prec[top] >= prec[t]) || (rightAssoc[t] && prec[top] > prec[t])) {
                    output.push(opStack.pop());
                } else {
                    break;
                }
            }
            opStack.push(t);
        }
    }
    while (opStack.length) {
        output.push(opStack.pop());
    }
    return output.join(' ');
}
`
      },
      solutionCode: {
        javascript: `function solve(infixStr) {
    const tokens = infixStr.trim().split(/\\s+/);
    const output = [];
    const opStack = [];
    const prec = { '+': 1, '-': 1, '*': 2, '/': 2, '^': 3 };
    const rightAssoc = { '^': true };

    for (const t of tokens) {
        if (/^[a-zA-Z0-9]+$/.test(t)) {
            output.push(t);
        } else if (t === '(') {
            opStack.push(t);
        } else if (t === ')') {
            while (opStack.length && opStack[opStack.length - 1] !== '(') {
                output.push(opStack.pop());
            }
            opStack.pop();
        } else if (prec[t]) {
            while (opStack.length && opStack[opStack.length - 1] !== '(') {
                const top = opStack[opStack.length - 1];
                if ((!rightAssoc[t] && prec[top] >= prec[t]) || (rightAssoc[t] && prec[top] > prec[t])) {
                    output.push(opStack.pop());
                } else {
                    break;
                }
            }
            opStack.push(t);
        }
    }
    while (opStack.length) output.push(opStack.pop());
    return output.join(' ');
}`
      },
      solutionExplanation: `The Shunting-Yard algorithm guarantees linear O(N) conversion:
- Operands immediately pass to the output queue.
- Operators are held on an operator stack until higher or equal precedence operators have been emitted.
- Right-associative operators like \`^\` do not pop identical precedence operators, ensuring right-to-left evaluation order.
- Parentheses act as barriers to isolate sub-expressions.`,
      testCases: [
        {
          id: 'shunt-1',
          name: 'Multiplication Precedence over Addition',
          input: 'A + B * C',
          expectedOutput: 'A B C * +',
          explanation: 'B * C must execute before addition with A.'
        },
        {
          id: 'shunt-2',
          name: 'Parentheses Overriding Precedence',
          input: '( A + B ) * C',
          expectedOutput: 'A B + C *',
          explanation: 'Addition enclosed in parentheses evaluates first.'
        },
        {
          id: 'shunt-3',
          name: 'Right-associative Exponentiation',
          input: 'A + B ^ C ^ D',
          expectedOutput: 'A B C D ^ ^ +',
          explanation: 'B ^ C ^ D evaluates right-to-left as B ^ (C ^ D).'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 4: Polynomial Arithmetic using Linked List
  // =========================================================================
  'polynomial-arithmetic-linked-list': [
    {
      id: 'polynomial-addition',
      title: 'Polynomial Addition via Linked Chains',
      difficulty: 'Medium',
      topic: 'Singly Linked List Node Merging & Ordered Polynomial Terms',
      codingameUrl: 'https://www.codingame.com/training/medium/dungeon-3d',
      summary: 'Add two polynomials represented as linked lists sorted in descending order of exponents, merging like powers.',
      statement: `Two polynomials $P(x)$ and $Q(x)$ are given as sorted linked chains of terms, each characterized by a coefficient $c$ and non-negative exponent $e$:
Term format: \`c x^e\` (e.g. \`3 2\` denotes $3x^2$).

Merge and add the two polynomial node chains:
- When both polynomials have a term with the same exponent, sum their coefficients: $(c_1 + c_2)x^e$.
- If the coefficient sum becomes 0, eliminate the term.
- When exponents differ, the term with the larger exponent appears first.
Output the resulting polynomial terms in descending order of exponent. If all terms cancel out, output \`0\`.`,
      inputFormat: [
        'Line 1: Integer N (number of terms in P).',
        'Line 2: N pairs of integers (coeff exp) for P.',
        'Line 3: Integer M (number of terms in Q).',
        'Line 4: M pairs of integers (coeff exp) for Q.'
      ],
      outputFormat: [
        'Space-separated terms in format "coeff exp" in strictly descending order of exponent, or "0" if empty.'
      ],
      constraints: [
        '1 ≤ N, M ≤ 100',
        '-1000 ≤ coeff ≤ 1000',
        '0 ≤ exp ≤ 1000'
      ],
      starterCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n').filter(Boolean);
    const n = parseInt(lines[0], 10);
    const pTokens = lines[1] ? lines[1].trim().split(/\\s+/).map(Number) : [];
    const m = parseInt(lines[2], 10);
    const qTokens = lines[3] ? lines[3].trim().split(/\\s+/).map(Number) : [];

    const map = new Map();
    for (let i = 0; i < pTokens.length; i += 2) {
        const c = pTokens[i], e = pTokens[i+1];
        map.set(e, (map.get(e) || 0) + c);
    }
    for (let i = 0; i < qTokens.length; i += 2) {
        const c = qTokens[i], e = qTokens[i+1];
        map.set(e, (map.get(e) || 0) + c);
    }

    const exps = Array.from(map.keys()).sort((a, b) => b - a);
    const res = [];
    for (const e of exps) {
        const c = map.get(e);
        if (c !== 0) res.push(\`\${c} \${e}\`);
    }
    return res.length ? res.join(' ') : '0';
}
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n').filter(Boolean);
    const pTokens = lines[1] ? lines[1].trim().split(/\\s+/).map(Number) : [];
    const qTokens = lines[3] ? lines[3].trim().split(/\\s+/).map(Number) : [];

    const map = new Map();
    for (let i = 0; i < pTokens.length; i += 2) {
        const c = pTokens[i], e = pTokens[i+1];
        map.set(e, (map.get(e) || 0) + c);
    }
    for (let i = 0; i < qTokens.length; i += 2) {
        const c = qTokens[i], e = qTokens[i+1];
        map.set(e, (map.get(e) || 0) + c);
    }

    const exps = Array.from(map.keys()).sort((a, b) => b - a);
    const res = [];
    for (const e of exps) {
        const c = map.get(e);
        if (c !== 0) res.push(\`\${c} \${e}\`);
    }
    return res.length ? res.join(' ') : '0';
}`
      },
      solutionExplanation: `Polynomial addition mirrors linked list merge sort:
Maintain pointers to both linked lists. While both pointers are non-null:
1. If \`p1.exp === p2.exp\`, create a new node with \`coeff = p1.coeff + p2.coeff\` (if non-zero) and advance both.
2. If \`p1.exp > p2.exp\`, copy \`p1\` node and advance \`p1\`.
3. If \`p2.exp > p1.exp\`, copy \`p2\` node and advance \`p2\`.
This produces a canonical linked polynomial in O(N + M) time.`,
      testCases: [
        {
          id: 'poly-1',
          name: 'Merging Matching Exponents',
          input: '2\\n3 2 5 0\\n2\\n2 2 4 0',
          expectedOutput: '5 2 9 0',
          explanation: '(3x^2 + 5) + (2x^2 + 4) = 5x^2 + 9.'
        },
        {
          id: 'poly-2',
          name: 'Terms Cancelling Out to Zero',
          input: '2\\n4 3 2 1\\n2\\n-4 3 5 0',
          expectedOutput: '2 1 5 0',
          explanation: '4x^3 and -4x^3 cancel out to 0.'
        }
      ]
    },
    {
      id: 'add-two-numbers-linked-list',
      title: 'Add Two Numbers as Singly Linked Lists',
      difficulty: 'Medium',
      topic: 'Linked List Traversal & Digit Carry Over',
      codingameUrl: 'https://www.codingame.com/training/medium/there-is-no-spoon-episode-1',
      summary: 'Add two non-negative integers represented as reverse-ordered linked lists and return the result chain.',
      statement: `You are given two non-empty linked lists representing two non-negative integers. The digits are stored in reverse order, and each node contains a single digit.
Add the two numbers and return the sum as a linked list in reverse digit order.

Example:
\`2 -> 4 -> 3\` represents number 342.
\`5 -> 6 -> 4\` represents number 465.
Sum = 807, represented as \`7 -> 0 -> 8\`.`,
      inputFormat: [
        'Line 1: Space-separated digits of the first linked list.',
        'Line 2: Space-separated digits of the second linked list.'
      ],
      outputFormat: [
        'Space-separated digits of the sum linked list.'
      ],
      constraints: [
        '1 ≤ Number of nodes in each list ≤ 100',
        '0 ≤ Node.val ≤ 9'
      ],
      starterCode: {
        javascript: `function solve(inputStr) {
    const [l1Str, l2Str] = inputStr.trim().split('\\n');
    const a = l1Str.trim().split(/\\s+/).map(Number);
    const b = l2Str.trim().split(/\\s+/).map(Number);
    const res = [];
    let carry = 0, i = 0, j = 0;
    while (i < a.length || j < b.length || carry) {
        const val1 = i < a.length ? a[i++] : 0;
        const val2 = j < b.length ? b[j++] : 0;
        const sum = val1 + val2 + carry;
        res.push(sum % 10);
        carry = Math.floor(sum / 10);
    }
    return res.join(' ');
}
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) {
    const [l1Str, l2Str] = inputStr.trim().split('\\n');
    const a = l1Str.trim().split(/\\s+/).map(Number);
    const b = l2Str.trim().split(/\\s+/).map(Number);
    const res = [];
    let carry = 0, i = 0, j = 0;
    while (i < a.length || j < b.length || carry) {
        const val1 = i < a.length ? a[i++] : 0;
        const val2 = j < b.length ? b[j++] : 0;
        const sum = val1 + val2 + carry;
        res.push(sum % 10);
        carry = Math.floor(sum / 10);
    }
    return res.join(' ');
}`
      },
      solutionExplanation: `Simulate elementary addition node-by-node from the head:
1. Traverse both linked lists simultaneously, taking \`val1\` and \`val2\` (0 if list ends).
2. Calculate \`sum = val1 + val2 + carry\`.
3. Create a new node with \`sum % 10\`, and update \`carry = Math.floor(sum / 10)\`.
4. If carry remains after scanning both lists, append a final node with value 1.`,
      testCases: [
        {
          id: 'add-nodes-1',
          name: 'Classic 3-digit Sum with Carry',
          input: '2 4 3\\n5 6 4',
          expectedOutput: '7 0 8',
          explanation: '342 + 465 = 807, output reverse digits: 7 0 8.'
        },
        {
          id: 'add-nodes-2',
          name: 'Unequal Length Lists with Chain Carry',
          input: '9 9 9\\n1',
          expectedOutput: '0 0 0 1',
          explanation: '999 + 1 = 1000, output: 0 0 0 1.'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 5: Binary Trees and Operations
  // =========================================================================
  'binary-tree-operations': [
    {
      id: 'tree-reconstruction',
      title: 'Tree Reconstruction from Preorder & Inorder',
      difficulty: 'Medium',
      topic: 'Binary Tree Recursive Construction & Postorder Output',
      codingameUrl: 'https://www.codingame.com/training/medium/tree-reconstruction',
      summary: 'Reconstruct a unique binary tree given its Preorder and Inorder traversal sequences and output its Postorder traversal.',
      statement: `Given two integer sequences representing the Preorder and Inorder traversals of a binary tree with distinct values:
1. Reconstruct the unique binary tree structure.
2. Generate and output the Postorder traversal (Left, Right, Root) of the reconstructed tree.

Properties:
- Preorder sequence: [Root, Left Subtree, Right Subtree]
- Inorder sequence: [Left Subtree, Root, Right Subtree]
The first element of preorder is always the root! Finding this root in the inorder sequence cleanly divides the left and right subtrees.`,
      inputFormat: [
        'Line 1: An integer N representing the number of nodes.',
        'Line 2: Space-separated integers of the Preorder traversal.',
        'Line 3: Space-separated integers of the Inorder traversal.'
      ],
      outputFormat: [
        'Space-separated integers of the Postorder traversal.'
      ],
      constraints: [
        '1 ≤ N ≤ 200',
        'All node values are distinct integers'
      ],
      starterCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n').filter(Boolean);
    const n = parseInt(lines[0], 10);
    const pre = lines[1].trim().split(/\\s+/).map(Number);
    const ino = lines[2].trim().split(/\\s+/).map(Number);

    function buildPost(preorder, inorder) {
        if (!preorder.length) return [];
        const root = preorder[0];
        const rootIdx = inorder.indexOf(root);
        const leftIno = inorder.slice(0, rootIdx);
        const rightIno = inorder.slice(rootIdx + 1);

        const leftPre = preorder.slice(1, 1 + leftIno.length);
        const rightPre = preorder.slice(1 + leftIno.length);

        return [...buildPost(leftPre, leftIno), ...buildPost(rightPre, rightIno), root];
    }

    return buildPost(pre, ino).join(' ');
}
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n').filter(Boolean);
    const pre = lines[1].trim().split(/\\s+/).map(Number);
    const ino = lines[2].trim().split(/\\s+/).map(Number);

    function buildPost(preorder, inorder) {
        if (!preorder.length) return [];
        const root = preorder[0];
        const rootIdx = inorder.indexOf(root);
        const leftIno = inorder.slice(0, rootIdx);
        const rightIno = inorder.slice(rootIdx + 1);

        const leftPre = preorder.slice(1, 1 + leftIno.length);
        const rightPre = preorder.slice(1 + leftIno.length);

        return [...buildPost(leftPre, leftIno), ...buildPost(rightPre, rightIno), root];
    }

    return buildPost(pre, ino).join(' ');
}`
      },
      solutionExplanation: `Recursive Tree Reconstruction:
1. The root is always \`preorder[0]\`.
2. Locate root in \`inorder\` array: index \`k\`.
3. Elements to the left of \`k\` form the left subtree (size \`k\`).
4. Elements to the right of \`k\` form the right subtree.
5. In Postorder, recurse on Left, recurse on Right, and append Root.`,
      testCases: [
        {
          id: 'tree-1',
          name: 'Standard 5-Node Binary Tree',
          input: '5\\n3 9 20 15 7\\n9 3 15 20 7',
          expectedOutput: '9 15 7 20 3',
          explanation: 'Postorder of tree with root 3, left child 9, right subtree root 20.'
        },
        {
          id: 'tree-2',
          name: 'Strictly Left-skewed Tree',
          input: '3\\n1 2 3\\n3 2 1',
          expectedOutput: '3 2 1',
          explanation: '1 -> 2 -> 3 left chain.'
        }
      ]
    },
    {
      id: 'binary-tree-height',
      title: 'Binary Tree Height and Leaf Counter',
      difficulty: 'Easy',
      topic: 'Recursive Tree Depth & Structural Metrics',
      codingameUrl: 'https://www.codingame.com/training/easy/mayan-calculation',
      summary: 'Compute the height (maximum depth) and count of leaf nodes in a binary tree from parent-child links.',
      statement: `Given a binary tree described by $N$ nodes indexed from $0$ to $N - 1$:
Each line provides \`id left_id right_id\` (-1 indicates absence of child). Root is node 0.

Output two values on a single line:
1. Maximum height (depth) of the tree (number of nodes on longest path from root to leaf).
2. Total number of leaf nodes (nodes where \`left == -1\` and \`right == -1\`).`,
      inputFormat: [
        'Line 1: Integer N (number of nodes).',
        'Next N lines: id left_id right_id.'
      ],
      outputFormat: [
        'Output "height leaves" separated by a space.'
      ],
      constraints: [
        '1 ≤ N ≤ 500',
        'Node 0 is the root'
      ],
      starterCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n').filter(Boolean);
    const n = parseInt(lines[0], 10);
    const nodes = {};
    for (let i = 1; i <= n; i++) {
        const [id, left, right] = lines[i].trim().split(/\\s+/).map(Number);
        nodes[id] = { left, right };
    }

    let leafCount = 0;
    function dfs(curr) {
        if (curr === -1 || !nodes[curr]) return 0;
        const { left, right } = nodes[curr];
        if (left === -1 && right === -1) {
            leafCount++;
            return 1;
        }
        return 1 + Math.max(dfs(left), dfs(right));
    }

    const height = dfs(0);
    return \`\${height} \${leafCount}\`;
}
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n').filter(Boolean);
    const n = parseInt(lines[0], 10);
    const nodes = {};
    for (let i = 1; i <= n; i++) {
        const [id, left, right] = lines[i].trim().split(/\\s+/).map(Number);
        nodes[id] = { left, right };
    }

    let leafCount = 0;
    function dfs(curr) {
        if (curr === -1 || !nodes[curr]) return 0;
        const { left, right } = nodes[curr];
        if (left === -1 && right === -1) {
            leafCount++;
            return 1;
        }
        return 1 + Math.max(dfs(left), dfs(right));
    }

    const height = dfs(0);
    return \`\${height} \${leafCount}\`;
}`
      },
      solutionExplanation: `Recursive DFS Tree Metrics:
- Base case: \`curr === -1\` returns height 0.
- Leaf detection: when \`left === -1 && right === -1\`, increment leaf counter and return height 1.
- General case: return \`1 + max(height(left), height(right))\`.`,
      testCases: [
        {
          id: 'height-1',
          name: 'Balanced 3-Node Tree',
          input: '3\\n0 1 2\\n1 -1 -1\\n2 -1 -1',
          expectedOutput: '2 2',
          explanation: 'Height is 2, leaves are nodes 1 and 2.'
        },
        {
          id: 'height-2',
          name: 'Skewed Chain of 4 Nodes',
          input: '4\\n0 1 -1\\n1 2 -1\\n2 3 -1\\n3 -1 -1',
          expectedOutput: '4 1',
          explanation: 'Height is 4, only 1 leaf node (node 3).'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 6: Binary Search Trees using Linked List
  // =========================================================================
  'bst-linked-list': [
    {
      id: 'validate-bst',
      title: 'Valid Binary Search Tree (BST Validation)',
      difficulty: 'Medium',
      topic: 'BST Invariant Verification & Boundary Validation',
      codingameUrl: 'https://www.codingame.com/training/medium/telephone-numbers',
      summary: 'Determine whether a given binary tree satisfies the BST ordering property for all node descendants.',
      statement: `Given a binary tree described by $N$ nodes with values:
Format of each node line: \`id val left_id right_id\` (-1 indicates NULL child). Root is node 0.

Determine if the tree is a valid Binary Search Tree (BST):
- The left subtree of a node contains only nodes with values strictly less than the node's value.
- The right subtree of a node contains only nodes with values strictly greater than the node's value.
- Both left and right subtrees must also be valid binary search trees.

Output "true" if the tree is a valid BST, otherwise output "false".`,
      inputFormat: [
        'Line 1: Integer N (number of nodes).',
        'Next N lines: id val left_id right_id.'
      ],
      outputFormat: [
        'Output "true" if valid BST, otherwise "false".'
      ],
      constraints: [
        '1 ≤ N ≤ 500',
        '-10^6 ≤ val ≤ 10^6'
      ],
      starterCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n').filter(Boolean);
    const n = parseInt(lines[0], 10);
    const nodes = {};
    for (let i = 1; i <= n; i++) {
        const [id, val, left, right] = lines[i].trim().split(/\\s+/).map(Number);
        nodes[id] = { val, left, right };
    }

    function isValid(nodeId, minVal, maxVal) {
        if (nodeId === -1 || !nodes[nodeId]) return true;
        const { val, left, right } = nodes[nodeId];
        if (val <= minVal || val >= maxVal) return false;
        return isValid(left, minVal, val) && isValid(right, val, maxVal);
    }

    return isValid(0, -Infinity, Infinity) ? "true" : "false";
}
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n').filter(Boolean);
    const n = parseInt(lines[0], 10);
    const nodes = {};
    for (let i = 1; i <= n; i++) {
        const [id, val, left, right] = lines[i].trim().split(/\\s+/).map(Number);
        nodes[id] = { val, left, right };
    }

    function isValid(nodeId, minVal, maxVal) {
        if (nodeId === -1 || !nodes[nodeId]) return true;
        const { val, left, right } = nodes[nodeId];
        if (val <= minVal || val >= maxVal) return false;
        return isValid(left, minVal, val) && isValid(right, val, maxVal);
    }

    return isValid(0, -Infinity, Infinity) ? "true" : "false";
}`
      },
      solutionExplanation: `A common pitfall is only checking if \`left.val < node.val < right.val\`.
Descendants in the left subtree must be smaller than ALL ancestors above them.
To enforce this, pass a valid interval \`(minVal, maxVal)\` down during recursive traversal:
- When navigating left: \`isValid(left, minVal, node.val)\`
- When navigating right: \`isValid(right, node.val, maxVal)\`
Time complexity is O(N).`,
      testCases: [
        {
          id: 'bst-1',
          name: 'Valid BST 3-node',
          input: '3\\n0 2 1 2\\n1 1 -1 -1\\n2 3 -1 -1',
          expectedOutput: 'true',
          explanation: 'Root 2 has left child 1 and right child 3.'
        },
        {
          id: 'bst-2',
          name: 'Invalid Grandchild Violation',
          input: '3\\n0 5 1 2\\n1 6 -1 -1\\n2 7 -1 -1',
          expectedOutput: 'false',
          explanation: 'Left child has value 6, which violates left < root (6 < 5 is false).'
        }
      ]
    },
    {
      id: 'bst-lowest-common-ancestor',
      title: 'Lowest Common Ancestor in BST',
      difficulty: 'Easy',
      topic: 'BST Partition Property & Optimal LCA Search',
      codingameUrl: 'https://www.codingame.com/training/easy/defibrillators',
      summary: 'Find the Lowest Common Ancestor (LCA) node of two given values p and q in a Binary Search Tree.',
      statement: `Given a valid Binary Search Tree (BST) and two distinct values $p$ and $q$ present in the tree:
Find the value of their Lowest Common Ancestor (LCA).
The LCA of two nodes $p$ and $q$ is defined as the lowest node in $T$ that has both $p$ and $q$ as descendants (where a node can be a descendant of itself).

Leverage the BST ordering property to achieve $O(h)$ time without scanning unnecessary branches!`,
      inputFormat: [
        'Line 1: Integer N (number of nodes).',
        'Next N lines: id val left_id right_id.',
        'Last line: Two integers p and q.'
      ],
      outputFormat: [
        'Output the integer value of the LCA node.'
      ],
      constraints: [
        '1 ≤ N ≤ 500',
        'All node values are distinct',
        'p and q exist in the BST'
      ],
      starterCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n').filter(Boolean);
    const n = parseInt(lines[0], 10);
    const nodes = {};
    for (let i = 1; i <= n; i++) {
        const [id, val, left, right] = lines[i].trim().split(/\\s+/).map(Number);
        nodes[id] = { val, left, right };
    }
    const [p, q] = lines[n + 1].trim().split(/\\s+/).map(Number);

    let curr = 0;
    while (curr !== -1) {
        const val = nodes[curr].val;
        if (p < val && q < val) {
            curr = nodes[curr].left;
        } else if (p > val && q > val) {
            curr = nodes[curr].right;
        } else {
            return val.toString();
        }
    }
    return '';
}
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n').filter(Boolean);
    const n = parseInt(lines[0], 10);
    const nodes = {};
    for (let i = 1; i <= n; i++) {
        const [id, val, left, right] = lines[i].trim().split(/\\s+/).map(Number);
        nodes[id] = { val, left, right };
    }
    const [p, q] = lines[n + 1].trim().split(/\\s+/).map(Number);

    let curr = 0;
    while (curr !== -1) {
        const val = nodes[curr].val;
        if (p < val && q < val) {
            curr = nodes[curr].left;
        } else if (p > val && q > val) {
            curr = nodes[curr].right;
        } else {
            return val.toString();
        }
    }
    return '';
}`
      },
      solutionExplanation: `BST LCA Navigation Property:
1. If both $p$ and $q$ are strictly smaller than current node's value, LCA must reside in the left subtree.
2. If both $p$ and $q$ are strictly greater than current node's value, LCA must reside in the right subtree.
3. If $p$ and $q$ lie on opposite sides of current node (or one matches current node), current node is their Lowest Common Ancestor!
Runs in $O(h)$ time with zero extra memory.`,
      testCases: [
        {
          id: 'lca-1',
          name: 'Split at Root',
          input: '3\\n0 6 1 2\\n1 2 -1 -1\\n2 8 -1 -1\\n2 8',
          expectedOutput: '6',
          explanation: 'Values 2 and 8 diverge at root 6.'
        },
        {
          id: 'lca-2',
          name: 'LCA is One of the Nodes',
          input: '3\\n0 6 1 2\\n1 2 -1 -1\\n2 8 -1 -1\\n6 2',
          expectedOutput: '6',
          explanation: 'Node 6 is ancestor of 2.'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 7: Graph Traversal techniques: BFS & DFS
  // =========================================================================
  'graph-traversal-bfs-dfs': [
    {
      id: 'labyrinth-escape-bfs',
      title: 'Labyrinth Escape (BFS Shortest Path)',
      difficulty: 'Medium',
      topic: 'Breadth-First Search (BFS) & Shortest Path in Unweighted Grid',
      codingameUrl: 'https://www.codingame.com/training/medium/the-fall-episode-1',
      summary: 'Find the minimum number of steps to escape a 2D labyrinth from Start (S) to Exit (E) using Breadth-First Search.',
      statement: `You are trapped in a 2D labyrinth represented as a grid of characters:
- \`.\`: Open walkable cell
- \`#\`: Impassable wall
- \`S\`: Starting position
- \`E\`: Exit destination

You can move in four cardinal directions (Up, Down, Left, Right). Each move takes 1 step.
Find the minimum number of steps required to reach the Exit from Start. If the Exit is unreachable, output \`-1\`.`,
      inputFormat: [
        'Line 1: Two space-separated integers R and C (rows and columns).',
        'Next R lines: Strings of length C representing grid rows.'
      ],
      outputFormat: [
        'Output the minimum number of steps to reach the exit, or -1.'
      ],
      constraints: [
        '2 ≤ R, C ≤ 30',
        'Grid contains exactly one S and one E'
      ],
      starterCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n').filter(Boolean);
    const [R, C] = lines[0].trim().split(/\\s+/).map(Number);
    const grid = [];
    let start = null, exit = null;

    for (let r = 0; r < R; r++) {
        const row = lines[r + 1].trim();
        grid.push(row);
        for (let c = 0; c < C; c++) {
            if (row[c] === 'S') start = [r, c];
            if (row[c] === 'E') exit = [r, c];
        }
    }

    const queue = [[start[0], start[1], 0]];
    const visited = Array.from({ length: R }, () => new Array(C).fill(false));
    visited[start[0]][start[1]] = true;

    const dirs = [[-1, 0], [1, 0], [0, -1], [0, 1]];

    while (queue.length) {
        const [r, c, dist] = queue.shift();
        if (r === exit[0] && c === exit[1]) return dist.toString();

        for (const [dr, dc] of dirs) {
            const nr = r + dr, nc = c + dc;
            if (nr >= 0 && nr < R && nc >= 0 && nc < C && !visited[nr][nc] && grid[nr][nc] !== '#') {
                visited[nr][nc] = true;
                queue.push([nr, nc, dist + 1]);
            }
        }
    }
    return "-1";
}
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n').filter(Boolean);
    const [R, C] = lines[0].trim().split(/\\s+/).map(Number);
    const grid = [];
    let start = null, exit = null;

    for (let r = 0; r < R; r++) {
        const row = lines[r + 1].trim();
        grid.push(row);
        for (let c = 0; c < C; c++) {
            if (row[c] === 'S') start = [r, c];
            if (row[c] === 'E') exit = [r, c];
        }
    }

    const queue = [[start[0], start[1], 0]];
    const visited = Array.from({ length: R }, () => new Array(C).fill(false));
    visited[start[0]][start[1]] = true;

    const dirs = [[-1, 0], [1, 0], [0, -1], [0, 1]];

    while (queue.length) {
        const [r, c, dist] = queue.shift();
        if (r === exit[0] && c === exit[1]) return dist.toString();

        for (const [dr, dc] of dirs) {
            const nr = r + dr, nc = c + dc;
            if (nr >= 0 && nr < R && nc >= 0 && nc < C && !visited[nr][nc] && grid[nr][nc] !== '#') {
                visited[nr][nc] = true;
                queue.push([nr, nc, dist + 1]);
            }
        }
    }
    return "-1";
}`
      },
      solutionExplanation: `BFS guarantees the shortest path in unweighted graphs:
1. Initialize a FIFO queue with the start cell \`(r, c, distance = 0)\`.
2. Mark visited immediately upon enqueuing to prevent redundant vertex expansions.
3. Expand neighboring cells in 4 cardinal directions. The first time the destination is popped, its distance is mathematically guaranteed to be minimal.
Time complexity is $O(R \times C)$.`,
      testCases: [
        {
          id: 'maze-1',
          name: 'Simple Corridor 3x3',
          input: '3 3\\nS..\\n.#.\\n..E',
          expectedOutput: '4',
          explanation: 'S(0,0) -> (0,1) -> (0,2) -> (1,2) -> E(2,2): 4 moves.'
        },
        {
          id: 'maze-2',
          name: 'Blocked Path by Walls',
          input: '3 3\\nS#.\\n###\\n..E',
          expectedOutput: '-1',
          explanation: 'No path exists around walls.'
        }
      ]
    },
    {
      id: 'network-cabling-dfs',
      title: 'Network Connections & Clusters (DFS)',
      difficulty: 'Medium',
      topic: 'Depth-First Search (DFS) & Connected Components',
      codingameUrl: 'https://www.codingame.com/training/medium/network-cabling',
      summary: 'Count the number of disconnected clusters in an undirected computer network using Depth-First Search.',
      statement: `You are an IT infrastructure administrator overseeing a distributed computer network with $N$ servers indexed $0$ to $N - 1$.
The network has $M$ bidirectional communication links connecting pairs of servers.

Using Depth-First Search (DFS), determine the total number of disconnected network components (isolated clusters) in the network.`,
      inputFormat: [
        'Line 1: Two integers N (servers) and M (links).',
        'Next M lines: Two integers u and v denoting a link between server u and server v.'
      ],
      outputFormat: [
        'Output the total number of connected network components.'
      ],
      constraints: [
        '1 ≤ N ≤ 1000',
        '0 ≤ M ≤ 2000'
      ],
      starterCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n').filter(Boolean);
    const [N, M] = lines[0].trim().split(/\\s+/).map(Number);
    const adj = Array.from({ length: N }, () => []);

    for (let i = 1; i <= M; i++) {
        const [u, v] = lines[i].trim().split(/\\s+/).map(Number);
        adj[u].push(v);
        adj[v].push(u);
    }

    const visited = new Array(N).fill(false);
    let components = 0;

    function dfs(node) {
        visited[node] = true;
        for (const neighbor of adj[node]) {
            if (!visited[neighbor]) dfs(neighbor);
        }
    }

    for (let i = 0; i < N; i++) {
        if (!visited[i]) {
            components++;
            dfs(i);
        }
    }
    return components.toString();
}
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n').filter(Boolean);
    const [N, M] = lines[0].trim().split(/\\s+/).map(Number);
    const adj = Array.from({ length: N }, () => []);

    for (let i = 1; i <= M; i++) {
        const [u, v] = lines[i].trim().split(/\\s+/).map(Number);
        adj[u].push(v);
        adj[v].push(u);
    }

    const visited = new Array(N).fill(false);
    let components = 0;

    function dfs(node) {
        visited[node] = true;
        for (const neighbor of adj[node]) {
            if (!visited[neighbor]) dfs(neighbor);
        }
    }

    for (let i = 0; i < N; i++) {
        if (!visited[i]) {
            components++;
            dfs(i);
        }
    }
    return components.toString();
}`
      },
      solutionExplanation: `Connected component counting using DFS:
1. Build an adjacency list of size $N$.
2. Iterate through each vertex $0 \dots N - 1$.
3. When an unvisited vertex is encountered, increment the component counter and invoke recursive DFS to traverse and mark all vertices reachable in its cluster.
4. Total time is $O(V + E)$.`,
      testCases: [
        {
          id: 'net-1',
          name: 'Two Disconnected Clusters',
          input: '5 3\\n0 1\\n1 2\\n3 4',
          expectedOutput: '2',
          explanation: 'Cluster 1: {0,1,2}, Cluster 2: {3,4}. Total = 2.'
        },
        {
          id: 'net-2',
          name: 'Completely Isolated Servers',
          input: '3 0',
          expectedOutput: '3',
          explanation: 'No edges exist. 3 isolated single-node components.'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 8: Implement any Application of Sorting Algorithms
  // =========================================================================
  'sorting-algorithms-application': [
    {
      id: 'horse-racing-duals',
      title: 'Horse-racing Duals (Classic CodinGame #1)',
      difficulty: 'Easy',
      topic: 'Optimal Sorting & Consecutive Element Gap Minimization',
      codingameUrl: 'https://www.codingame.com/training/easy/horse-racing-duals',
      summary: 'Find the minimum difference in strength between two horses from an array of ratings using O(N log N) sorting.',
      statement: `Casablanca’s hippodrome is organizing a new horse race. To make the race suspenseful, the organizers want to select the two horses with the closest strength ratings.

You are given the strength rating $P_i$ of $N$ horses.
Sort the horses by their strength ratings using an efficient comparison sorting algorithm (e.g. QuickSort or MergeSort in $O(N \log N)$), and find the minimum absolute difference between two horses!`,
      inputFormat: [
        'Line 1: An integer N representing the number of horses.',
        'Next N lines: The strength Pi of each horse.'
      ],
      outputFormat: [
        'Output the minimum integer difference between two horses.'
      ],
      constraints: [
        '2 ≤ N ≤ 100,000',
        '0 < Pi ≤ 10,000,000'
      ],
      starterCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n').filter(Boolean);
    const n = parseInt(lines[0], 10);
    const strengths = [];
    for (let i = 1; i <= n; i++) {
        strengths.push(parseInt(lines[i].trim(), 10));
    }

    // Sort in O(N log N)
    strengths.sort((a, b) => a - b);

    let minDiff = Infinity;
    for (let i = 1; i < strengths.length; i++) {
        const diff = strengths[i] - strengths[i - 1];
        if (diff < minDiff) minDiff = diff;
    }
    return minDiff.toString();
}
`,
        python: `def solve(input_str: str) -> str:
    lines = input_str.strip().split()
    n = int(lines[0])
    strengths = [int(x) for x in lines[1:n+1]]
    strengths.sort()
    min_diff = min(strengths[i] - strengths[i-1] for i in range(1, len(strengths)))
    return str(min_diff)
`,
        cpp: `// CodinGame Horse-racing Duals (C++)
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n;
    if (!(cin >> n)) return 0;
    vector<int> horses(n);
    for (int i = 0; i < n; ++i) cin >> horses[i];
    sort(horses.begin(), horses.end());
    int min_diff = horses[1] - horses[0];
    for (int i = 2; i < n; ++i) {
        min_diff = min(min_diff, horses[i] - horses[i-1]);
    }
    cout << min_diff << endl;
    return 0;
}
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n').filter(Boolean);
    const n = parseInt(lines[0], 10);
    const strengths = [];
    for (let i = 1; i <= n; i++) {
        strengths.push(parseInt(lines[i].trim(), 10));
    }
    strengths.sort((a, b) => a - b);
    let minDiff = Infinity;
    for (let i = 1; i < strengths.length; i++) {
        const diff = strengths[i] - strengths[i - 1];
        if (diff < minDiff) minDiff = diff;
    }
    return minDiff.toString();
}`
      },
      solutionExplanation: `Direct pairwise comparison takes $O(N^2)$ time, which times out for $N = 100,000$.
By sorting the array in $O(N \log N)$ time, the closest numerical values are guaranteed to be placed adjacent to each other.
A single linear pass comparing \`strengths[i] - strengths[i - 1]\` finds the global minimum difference in $O(N)$ time.
Total time complexity is $O(N \log N)$.`,
      testCases: [
        {
          id: 'horse-1',
          name: 'Three Horses Sample',
          input: '3\\n5\\n8\\n9',
          expectedOutput: '1',
          explanation: 'Closest ratings are 8 and 9 with difference 1.'
        },
        {
          id: 'horse-2',
          name: 'Unordered Array of Horses',
          input: '5\\n10\\n5\\n15\\n17\\n3',
          expectedOutput: '2',
          explanation: 'Sorted: [3, 5, 10, 15, 17]. Minimum diff is 5 - 3 = 2 or 17 - 15 = 2.'
        }
      ]
    },
    {
      id: 'temperatures',
      title: 'Temperatures (Classic CodinGame #2)',
      difficulty: 'Easy',
      topic: 'Sorting & Nearest to Zero with Positive Tie-Breaking',
      codingameUrl: 'https://www.codingame.com/training/easy/temperatures',
      summary: 'Analyze weather readings and find the temperature closest to 0, prioritizing positive values on tied absolute distances.',
      statement: `Write a program that prints the temperature closest to 0 among input weather readings.
If two temperatures are equally close to zero, you must pick the positive value (e.g. if the choices are \`-5\` and \`5\`, output \`5\`).
If no temperatures are provided ($N = 0$), output \`0\`.`,
      inputFormat: [
        'Line 1: An integer N representing the number of temperatures to analyze.',
        'Line 2: A space-separated list of N integers representing the temperatures.'
      ],
      outputFormat: [
        'Output the temperature closest to zero, or 0 if N = 0.'
      ],
      constraints: [
        '0 ≤ N < 10000',
        '-273 ≤ temperature ≤ 5526'
      ],
      starterCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n').filter(Boolean);
    if (!lines.length) return "0";
    const n = parseInt(lines[0], 10);
    if (n === 0 || !lines[1]) return "0";
    const temps = lines[1].trim().split(/\\s+/).map(Number);

    let closest = temps[0];
    for (const t of temps) {
        if (Math.abs(t) < Math.abs(closest)) {
            closest = t;
        } else if (Math.abs(t) === Math.abs(closest) && t > closest) {
            closest = t;
        }
    }
    return closest.toString();
}
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n').filter(Boolean);
    if (!lines.length) return "0";
    const n = parseInt(lines[0], 10);
    if (n === 0 || !lines[1]) return "0";
    const temps = lines[1].trim().split(/\\s+/).map(Number);

    let closest = temps[0];
    for (const t of temps) {
        if (Math.abs(t) < Math.abs(closest)) {
            closest = t;
        } else if (Math.abs(t) === Math.abs(closest) && t > closest) {
            closest = t;
        }
    }
    return closest.toString();
}`
      },
      solutionExplanation: `Comparison logic:
Track the current candidate \`closest\`. For each temperature \`t\`:
1. If \`|t| < |closest|\`, update \`closest = t\`.
2. If \`|t| === |closest|\`, tie-break by choosing the maximum: if \`t > closest\` (e.g. 5 vs -5), update \`closest = t\`.
This takes $O(N)$ time and $O(1)$ auxiliary space.`,
      testCases: [
        {
          id: 'temp-1',
          name: 'Mixed Temperatures',
          input: '5\\n1 -2 -8 4 5',
          expectedOutput: '1',
          explanation: '1 is distance 1 from zero, closer than -2 (dist 2).'
        },
        {
          id: 'temp-2',
          name: 'Tie-break Positive vs Negative',
          input: '2\\n-5 5',
          expectedOutput: '5',
          explanation: '-5 and 5 are equidistant, tie-breaking selects positive 5.'
        }
      ]
    }
  ]
};

export function getExperimentCodingamePuzzles(experimentId: string): CodinGamePuzzle[] {
  const aliasMap: Record<string, string> = {
    'stack-adt-linked-list': 'stack-adt-linked-list',
    'linear-queue-adt': 'queue-adt-linked-list',
    'queue-adt-linked-list': 'queue-adt-linked-list',
    'infix-to-postfix': 'infix-to-postfix',
    'polynomial-arithmetic': 'polynomial-arithmetic-linked-list',
    'polynomial-arithmetic-linked-list': 'polynomial-arithmetic-linked-list',
    'binary-tree-traversals': 'binary-tree-operations',
    'binary-tree-operations': 'binary-tree-operations',
    'binary-search-tree-operations': 'bst-linked-list',
    'bst-linked-list': 'bst-linked-list',
    'graph-traversals-dfs-bfs': 'graph-traversal-bfs-dfs',
    'graph-traversal-bfs-dfs': 'graph-traversal-bfs-dfs',
    'sorting-algorithms-application': 'sorting-algorithms-application'
  };
  const key = aliasMap[experimentId] || experimentId;
  return (
    DSA_CODINGAME_PUZZLES[key] ||
    DSA_CODINGAME_PUZZLES[experimentId] ||
    DAA_CODINGAME_PUZZLES[experimentId] ||
    OOPM_CODINGAME_PUZZLES[experimentId] ||
    []
  );
}
