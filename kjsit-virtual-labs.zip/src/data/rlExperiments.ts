import { LabExperiment } from '../types';

export const RL_EXPERIMENTS: LabExperiment[] = [
  {
    id: 'rl-exp1',
    num: 1,
    subjectId: 'rl',
    title: 'Markov Decision Processes (MDP) & Dynamic Programming',
    subtitle: 'Bellman Expectation/Optimality Equations, Policy Iteration & Value Iteration',
    category: 'Markov Decision Processes',
    iitReference: 'Autonomous Curriculum Standards / Reinforcement Learning Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/rl-lab/',
    aim: 'To formulate a 4x4 GridWorld as a finite Markov Decision Process (MDP) and compute optimal state-value functions V*(s) and policy π*(s) using Value Iteration and Policy Iteration.',
    theory: {
      overview: [
        'A Markov Decision Process (MDP) provides a mathematical framework for modeling decision-making in discrete-time stochastic environments.',
        'Formal Tuple: (S, A, P, R, γ) where S = states, A = actions, P(s\'|s, a) = transition probabilities, R(s, a, s\') = rewards, and γ ∈ [0, 1) is the discount factor.',
        'Markov Property: Future dynamics depend solely upon the current state and action, independent of preceding history.',
        'Bellman Optimality Equation for V*(s): V*(s) = max_a Σ P(s\'|s, a) [ R(s, a, s\') + γ * V*(s\') ].',
        'Value Iteration iteratively updates state values until convergence: ||V_{k+1} - V_k|| < θ.',
        'Policy Iteration alternates between Policy Evaluation (computing V^π) and Policy Improvement (acting greedily with respect to V^π).'
      ],
      complexityTable: [
        { parameter: 'Value Iteration per step', value: 'O(|A| * |S|^2) state-action transitions' },
        { parameter: 'Policy Evaluation Exact', value: 'O(|S|^3) matrix inversion' }
      ],
      keyPoints: [
        'Discount factor γ determines agent foresight (γ ≈ 0 is short-sighted; γ ≈ 1 values future rewards).',
        'Guaranteed convergence to unique optimal value function V* via Banach Fixed-Point Theorem.'
      ],
      realWorldApplications: [
        'Automated warehouse mobile robot dispatching and traffic signal phase scheduling.',
        'Hydropower water reservoir storage management across seasonal rainfall cycles.'
      ]
    },
    algorithm: [
      '1. Initialize V(s) = 0 for all states s ∈ S, with V(terminal) = 0.',
      '2. Set discount factor γ = 0.9, convergence threshold θ = 1e-4.',
      '3. Loop (Value Iteration):',
      '    a. Δ = 0.',
      '    b. For each non-terminal state s ∈ S:',
      '        i. v = V(s).',
      '        ii. V(s) = max_a Σ P(s\'|s, a) [ R(s, a, s\') + γ * V(s\') ].',
      '        iii. Δ = max(Δ, |v - V(s)|).',
      '    c. Until Δ < θ.',
      '4. Output deterministic greedy policy π*(s) = argmax_a Σ P(s\'|s, a) [ R + γ * V*(s\') ].'
    ],
    procedure: [
      '1. Open GridWorld MDP Simulator.',
      '2. Configure grid dimensions (4x4), pitfall traps (-10 reward), and goal state (+10 reward).',
      '3. Set discount factor γ (0.9) and click "Run Value Iteration".',
      '4. Observe state values V(s) converging across color-coded heat tiles.',
      '5. Inspect optimal policy arrows pointing towards the goal avoiding hazard cells.'
    ],
    code: {
      python: `import numpy as np

def value_iteration(grid_size=4, gamma=0.9, theta=1e-4):
    V = np.zeros((grid_size, grid_size))
    # Terminal states
    terminals = [(0, 0), (grid_size-1, grid_size-1)]
    actions = [(-1, 0), (1, 0), (0, -1), (0, 1)] # Up, Down, Left, Right
    
    while True:
        delta = 0
        for r in range(grid_size):
            for c in range(grid_size):
                if (r, c) in terminals:
                    continue
                v = V[r, c]
                action_values = []
                for dr, dc in actions:
                    nr, nc = min(max(r + dr, 0), grid_size - 1), min(max(c + dc, 0), grid_size - 1)
                    reward = -1.0 # step cost
                    action_values.append(reward + gamma * V[nr, nc])
                V[r, c] = max(action_values)
                delta = max(delta, abs(v - V[r, c]))
        if delta < theta:
            break
    return np.round(V, 2)`
    },
    sampleInput: '4x4 GridWorld, Step Cost = -1.0, Terminals at (0,0) and (3,3), γ = 0.9',
    expectedOutput: 'Converged in 14 iterations. V*(0,1) = -1.0, V*(1,1) = -1.9; Optimal policy extracted.',
    references: ['Richard S. Sutton and Andrew G. Barto, Reinforcement Learning: An Introduction (2nd Edition), MIT Press'],
    conclusion: 'Value Iteration computed the optimal state-value function and policy without requiring trial-and-error environment interaction.',
    quiz: [
      {
        id: 1,
        question: 'What does the discount factor γ (gamma) control in a Markov Decision Process?',
        options: [
          'The relative weighting of immediate rewards versus future cumulative rewards',
          'The learning rate of the gradient descent optimizer',
          'The physical dimensions of the grid world',
          'The number of actions available'
        ],
        correctAnswer: 0,
        explanation: 'Gamma γ ∈ [0, 1) discounts rewards received in future time steps, making immediate rewards more valuable when γ is smaller and prioritizing long-term rewards as γ approaches 1.'
      }
    ]
  },
  {
    id: 'rl-exp2',
    num: 2,
    subjectId: 'rl',
    title: 'Model-Free Temporal Difference: Q-Learning & SARSA',
    subtitle: 'Off-Policy vs On-Policy TD Control, Epsilon-Greedy Exploration & Q-Table Updates',
    category: 'Temporal Difference Learning',
    iitReference: 'Autonomous Curriculum Standards / Reinforcement Learning Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/rl-lab/',
    aim: 'To implement Q-Learning (Off-Policy TD) and SARSA (On-Policy TD) algorithms from scratch on Cliff Walking / FrozenLake environments and evaluate policy safety.',
    theory: {
      overview: [
        'Model-Free Reinforcement Learning learns directly from experience episodes without requiring prior transition dynamics P(s\'|s, a) or reward functions.',
        'Temporal Difference (TD) combines Monte Carlo sampling with Dynamic Programming bootstrapping: updating estimates based on other learned estimates without waiting for a final outcome.',
        'SARSA (On-Policy): Updates action-value using the action actually taken by the current ε-greedy policy: Q(s, a) ← Q(s, a) + α [ R + γ * Q(s\', a\') - Q(s, a) ].',
        'Q-Learning (Off-Policy): Updates action-value using the greedy maximum possible action in the next state, regardless of the behavior policy: Q(s, a) ← Q(s, a) + α [ R + γ * max_a\' Q(s\', a\') - Q(s, a) ].',
        'Exploration vs Exploitation: ε-Greedy policy chooses a random action with probability ε, and the best known action with probability 1 - ε.'
      ],
      complexityTable: [
        { parameter: 'Q-Table Memory', value: 'O(|S| * |A|) table entries' },
        { parameter: 'Per-Step Update Time', value: 'O(|A|) max calculation for Q-Learning' }
      ],
      keyPoints: [
        'Cliff Walking Experiment: Q-Learning learns the optimal short path along the cliff edge; SARSA learns the safer longer path avoiding cliff drops.',
        'Exploration decay: Decreasing ε from 1.0 down to 0.05 allows initial exploration and eventual exploitation.'
      ],
      realWorldApplications: [
        'Game AI playing Atari and retro arcade simulations.',
        'Dynamic packet routing protocols in congested mesh telecommunication networks.'
      ]
    },
    algorithm: [
      '1. Initialize Q(s, a) arbitrarily (e.g. zeros) for all s ∈ S, a ∈ A, and Q(terminal, ·) = 0.',
      '2. For each training episode = 1..M:',
      '    a. Initialize state s.',
      '    b. For each step of episode:',
      '        i. Choose action a from s using ε-greedy policy derived from Q.',
      '        ii. Take action a, observe reward R and next state s\'.',
      '        iii. [Q-Learning]: Q(s, a) ← Q(s, a) + α * [ R + γ * max_{a\'} Q(s\', a\') - Q(s, a) ].',
      '        iv. [SARSA]: Choose next action a\' from s\' via ε-greedy; Q(s, a) ← Q(s, a) + α * [ R + γ * Q(s\', a\') - Q(s, a) ]; a = a\'.',
      '        v. s = s\'.',
      '        vi. If s is terminal: break.'
    ],
    procedure: [
      '1. Open Cliff Walking RL Playground.',
      '2. Toggle between Q-Learning (Off-Policy) and SARSA (On-Policy).',
      '3. Set Learning Rate α = 0.1, Discount γ = 0.99, Initial Epsilon ε = 0.2.',
      '4. Click "Train 500 Episodes" and watch the agent navigate the grid.',
      '5. Inspect the episode cumulative reward graph showing SARSA taking the safe upper path while Q-Learning hugs the risky cliff.'
    ],
    code: {
      python: `import numpy as np

def q_learning(env_states, env_actions, step_fn, episodes=500, alpha=0.1, gamma=0.99, epsilon=0.1):
    Q = np.zeros((env_states, env_actions))
    
    for ep in range(episodes):
        s = 0 # start state
        done = False
        while not done:
            # Epsilon-greedy
            if np.random.rand() < epsilon:
                a = np.random.randint(env_actions)
            else:
                a = np.argmax(Q[s])
                
            next_s, reward, done = step_fn(s, a)
            
            # Off-policy TD update
            best_next_a = np.argmax(Q[next_s])
            td_target = reward + gamma * Q[next_s, best_next_a]
            td_error = td_target - Q[s, a]
            Q[s, a] += alpha * td_error
            s = next_s
            
    return Q`
    },
    sampleInput: 'Cliff Walking Environment: 4x12 grid with cliff hazard along bottom row',
    expectedOutput: 'Q-Learning achieves optimal path (Reward -13); SARSA achieves safe roundabout path (Reward -17) with 0 cliff falls during evaluation.',
    references: ['Christopher Watkins (1989), Learning from Delayed Rewards (Doctoral dissertation introducing Q-learning)'],
    conclusion: 'Q-Learning off-policy updates converged to the globally optimal shortest path, while on-policy SARSA accounted for exploration risk to learn safer trajectories.',
    quiz: [
      {
        id: 1,
        question: 'Why is Q-Learning classified as an "Off-Policy" Reinforcement Learning algorithm?',
        options: [
          'Because its target value uses the greedy maximum action max_a\' Q(s\', a\'), regardless of which action the behavior exploration policy actually chose',
          'Because it runs when the computer is offline',
          'Because it does not use a reward function',
          'Because it requires no states'
        ],
        correctAnswer: 0,
        explanation: 'Q-learning is off-policy because the target policy being evaluated and improved is the greedy policy (taking max_a Q), which differs from the epsilon-greedy behavior policy used to generate actions.'
      }
    ]
  },
  {
    id: 'rl-exp3',
    num: 3,
    subjectId: 'rl',
    title: 'Deep Q-Networks (DQN) & Experience Replay',
    subtitle: 'Deep Q-Learning, Target Networks, Loss Minimization & CartPole Stabilization',
    category: 'Deep Reinforcement Learning',
    iitReference: 'Autonomous Curriculum Standards / Reinforcement Learning Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/rl-lab/',
    aim: 'To solve continuous state space control problems (Inverted Pendulum / CartPole) using Deep Q-Networks (DQN) with Experience Replay buffer and Target Network stabilization.',
    theory: {
      overview: [
        'Tabular Q-learning fails in continuous or high-dimensional state spaces due to the curse of dimensionality.',
        'Deep Q-Networks (DQN, Mnih et al., DeepMind 2015) use deep neural networks parameterized by θ to approximate the action-value function: Q(s, a; θ) ≈ Q*(s, a).',
        'Deadly Triad of RL Instability: Function approximation + Bootstrapping + Off-policy learning can lead to divergence.',
        'DQN introduces two key stabilization mechanisms:',
        '1. Experience Replay Buffer D: Stores transitions (s, a, r, s\', done). Random mini-batches break temporal correlation between consecutive training samples.',
        '2. Target Network Q(s, a; θ^-): Maintains frozen weights updated periodically to stabilize the non-stationary moving target y_i = r + γ * max_a\' Q(s\', a\'; θ^-).'
      ],
      complexityTable: [
        { parameter: 'Replay Buffer Memory', value: 'O(N * (|S| + |A|)) FIFO buffer (e.g. 100,000 transitions)' },
        { parameter: 'Training Mini-Batch', value: 'O(B * |θ|) neural network backpropagation pass' }
      ],
      keyPoints: [
        'Loss function: L(θ) = E_{(s, a, r, s\') ~ D} [ (r + γ * max_a\' Q(s\', a\'; θ^-) - Q(s, a; θ))^2 ].',
        'Double DQN and Dueling DQN further reduce overestimation bias.'
      ],
      realWorldApplications: [
        'Autonomous drone hovering stabilization in turbulent cross-winds.',
        'Robotic arm grasping and manipulation in industrial logistics.'
      ]
    },
    algorithm: [
      '1. Initialize replay memory D to capacity N.',
      '2. Initialize Q-network with random weights θ, and target network with weights θ^- = θ.',
      '3. For episode = 1..M:',
      '    a. Receive initial state s.',
      '    b. For step t = 1..T:',
      '        i. With probability ε select random action a; otherwise select a = argmax_a Q(s, a; θ).',
      '        ii. Execute action a in CartPole environment, observe reward r and next state s\'.',
      '        iii. Store transition (s, a, r, s\', done) in buffer D.',
      '        iv. Sample random mini-batch of transitions from D.',
      '        v. Set target y_j = r_j if done else r_j + γ * max_a\' Q(s\'_j, a\'; θ^-).',
      '        vi. Perform gradient descent step on (y_j - Q(s_j, a_j; θ))^2 with respect to θ.',
      '        vii. Every C steps, synchronize target network: θ^- ← θ.',
      '        viii. s = s\'; if done, break.'
    ],
    procedure: [
      '1. Open CartPole DQN Interactive Workbench.',
      '2. Observe the mechanical cart balancing an upright pole.',
      '3. Click "Start DQN Training" and watch the cart learn to oscillate left/right.',
      '4. Observe the pole balancing indefinitely (Episode reward reaches maximum 500 steps).',
      '5. Inspect the Experience Replay sampling buffer visualizer.'
    ],
    code: {
      python: `import random
from collections import deque
import torch
import torch.nn as nn
import torch.optim as optim

class DQN(nn.Module):
    def __init__(self, state_dim=4, action_dim=2):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, action_dim)
        )
    def forward(self, x): return self.net(x)

class ReplayBuffer:
    def __init__(self, capacity=10000):
        self.buffer = deque(maxlen=capacity)
    def push(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))
    def sample(self, batch_size=64):
        return random.sample(self.buffer, batch_size)
    def __len__(self): return len(self.buffer)`
    },
    sampleInput: 'CartPole-v1 environment: 4 continuous state variables [cart_pos, cart_vel, pole_angle, pole_vel]',
    expectedOutput: 'DQN agent masters balance after 120 episodes, maintaining pole upright for > 495 steps consistently.',
    references: ['Volodymyr Mnih et al. (2015), Human-level control through deep reinforcement learning, Nature'],
    conclusion: 'DQN with experience replay and target networks effectively solved continuous state space non-linear stabilization.',
    quiz: [
      {
        id: 1,
        question: 'What is the primary reason for utilizing an Experience Replay Buffer in Deep Q-Networks (DQN)?',
        options: [
          'It breaks the temporal correlation between consecutive training transitions, stabilizing gradient descent updates',
          'It stores code backups to GitHub',
          'It replaces neural network backpropagation entirely',
          'It makes the screen refresh faster'
        ],
        correctAnswer: 0,
        explanation: 'Consecutive transitions in RL are strongly correlated, which violates the i.i.d. assumption of stochastic gradient descent. Sampling random transitions from a replay buffer eliminates correlation and stabilizes training.'
      }
    ]
  }
];
