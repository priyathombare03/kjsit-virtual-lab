import { LabExperiment } from '../types';
import { OOPM_CODINGAME_PUZZLES } from './oopmCodingamePuzzles';
import { oopmExp1 } from './oopm/exp1';
import { oopmExp2 } from './oopm/exp2';
import { oopmExp3 } from './oopm/exp3';
import { oopmExp4 } from './oopm/exp4';
import { oopmExp5 } from './oopm/exp5';
import { oopmExp6 } from './oopm/exp6';
import { oopmExp7 } from './oopm/exp7';
import { oopmExp8 } from './oopm/exp8';
import { oopmExp9 } from './oopm/exp9';
import { oopmExp10 } from './oopm/exp10';

export const OOPM_EXPERIMENTS: LabExperiment[] = [
  oopmExp1,
  oopmExp2,
  oopmExp3,
  oopmExp4,
  oopmExp5,
  oopmExp6,
  oopmExp7,
  oopmExp8,
  oopmExp9,
  oopmExp10
];

// Attach CodinGame Puzzles to all OOPM experiments
OOPM_EXPERIMENTS.forEach((exp) => {
  exp.codingamePuzzles = OOPM_CODINGAME_PUZZLES[exp.id] || [];
});

export {
  oopmExp1,
  oopmExp2,
  oopmExp3,
  oopmExp4,
  oopmExp5,
  oopmExp6,
  oopmExp7,
  oopmExp8,
  oopmExp9,
  oopmExp10
};
