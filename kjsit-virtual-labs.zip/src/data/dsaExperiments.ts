import { DSAExperiment } from '../types';

export const DSA_EXPERIMENTS: DSAExperiment[] = [
  // =========================================================================
  // EXPERIMENT 1: Implement Stack ADT using an array/linked list
  // =========================================================================
  {
    id: 'stack-adt-linked-list',
    num: 1,
    subjectId: 'dsa',
    title: 'Implement Stack ADT using an array/linked list',
    subtitle: 'LIFO Mechanics, Push, Pop, Peek, Array vs Linked List Implementation',
    category: 'Linear Data Structures',
    iitReference: 'Autonomous Curriculum Standards / KJSIT AIL302 Data Structure and Algorithms Lab',
    iitLabUrl: 'https://vlab.co.in/data-structures-1/',
    aim: 'Implementation of Stacks using array/linked list.',
    objective: 'Explore concept of Stack ADT and write C code to implement stack ADT using a Linked List.',
    software: 'GCC / Turbo C / Online C Compiler',
    postLabQuestions: [
      {
        question: 'What is the condition for stack overflow in array-based vs linked list-based implementation?',
        answer: 'In an array-based stack, overflow occurs when top == capacity - 1 because the contiguous buffer is fixed. In a linked list stack, overflow only occurs when heap memory is exhausted and malloc() returns NULL.'
      },
      {
        question: 'Explain why a linked list-based stack does not require a predefined capacity.',
        answer: 'Linked list nodes are dynamically allocated on the heap one at a time as elements arrive. Memory grows and shrinks on demand, eliminating fixed upper-bound restrictions.'
      },
      {
        question: 'Compare the time and space complexity of array-based stack and linked list stack.',
        answer: 'Both offer O(1) time complexity for Push, Pop, Peek, and isEmpty. However, linked lists incur an extra pointer overhead (4 to 8 bytes per node), whereas arrays allocate contiguous space upfront.'
      },
      {
        question: 'What are the common real-world applications of the Stack data structure?',
        answer: 'Function call stack / recursion management, expression parsing (infix to postfix), syntax verification (balanced parentheses), undo/redo buffers, and graph DFS backtracking.'
      }
    ],
    theory: {
      overview: [
        'Stack is a linear data structure which follows LIFO principle. In Array-based approach, all stack-related operations are executed using arrays.',
        'Implement Stack using Array: 1. Initialize an array to represent the stack. 2. Use the end of the array to represent the top of the stack. 3. Implement push (add to end), pop (remove from the end), and peek (check end) operations, ensuring to handle empty and full stack conditions.',
        'Push Operation in Stack: Adds an item to the stack. If the stack is full (top == capacity - 1), then it is said to be an Overflow condition.',
        'Pop Operation in Stack: Removes an item from the stack. The items are popped in the reversed order in which they are pushed. If the stack is empty (top == -1), then it is said to be an Underflow condition.',
        'Top or Peek Operation in Stack: Returns the top element of the stack. If top == -1, simply print "Stack is empty"; otherwise return the element stored at index = top.',
        'isEmpty Operation in Stack: Returns true if the stack is empty (top == -1), else false. isFull Operation in Stack: Returns true if the stack is full (top == capacity - 1), else false.',
        'Advantages of Array Implementation: Easy to implement; Memory is saved as pointers are not involved.',
        'Disadvantages of Array Implementation: It is not dynamic i.e., it doesn’t grow and shrink depending on needs at runtime; The total size of the stack must be defined beforehand.',
        'Implementation of Stack using Linked List in C: Stack is generally implemented using an array but the limitation of this kind of stack is that the memory occupied by the array is fixed no matter what are the number of elements in the stack. In the stack implemented using linked list implementation, the size occupied by the linked list will be equal to the number of elements in the stack. Moreover, its size is dynamic. It means that the size is change automatically according to the elements present.',
        'Representation of Linked Stack in C: In C, the stack that is implemented using a linked list can be represented by the pointer to the head node of the linked list. Each node in that linked list represents the element of the stack. The type of linked list here is a singly linked list in which each node consists of a data field and the next pointer: struct Node { type data; Node* next; }. The topmost element will be present at the head of the linked list.'
      ],
      complexityTable: [
        { parameter: 'peek', value: 'O(1)' },
        { parameter: 'is_empty', value: 'O(1)' },
        { parameter: 'is_full', value: 'O(1)' },
        { parameter: 'push', value: 'O(1)' },
        { parameter: 'pop', value: 'O(1)' },
        { parameter: 'Auxiliary Space', value: 'O(n), where n is the number of items in the stack' }
      ],
      keyPoints: [
        'LIFO Principle: Follows Last In, First Out order where the element entered last is the one that is removed first via one active end (top).',
        'Array Advantages: Easy to implement; Memory is saved as pointers are not involved.',
        'Array Disadvantages: Not dynamic (size fixed beforehand, cannot grow/shrink at runtime).',
        'Dynamic Linked Stack: Memory size automatically adjusts according to elements present; overflow only occurs on heap allocation failure.',
        'Push Overflow Guard: Check if (top == capacity - 1) before pushing in array stack.',
        'Pop Underflow Guard: Check if (top == -1) in array stack or (head == NULL) in linked list stack.'
      ],
      realWorldApplications: [
        'Prefix notation of an expression tree, expression parsing, and syntax evaluation.',
        'Well form-ness of Parenthesis verification.',
        'Infix to Postfix conversion and Postfix Evaluation.',
        'Recursion handling and runtime call stack management.'
      ]
    },
    algorithm: [
      'Algorithm for Push Operation (Array):',
      '1. If top == capacity - 1, print "Stack Overflow" and exit.',
      '2. Increment top: top = top + 1.',
      '3. Assign stack[top] = value.',
      'Algorithm for Pop Operation (Array):',
      '1. If top == -1, print "Stack Underflow" and exit.',
      '2. Retrieve item = stack[top].',
      '3. Decrement top: top = top - 1. Return item.',
      'Algorithm for Linked List Stack Push:',
      '1. Allocate new node: newNode = (struct Node*)malloc(sizeof(struct Node)).',
      '2. If newNode == NULL, print "Heap Overflow" and exit.',
      '3. newNode->data = value; newNode->next = top.',
      '4. top = newNode.',
      'Algorithm for Linked List Stack Pop:',
      '1. If top == NULL, print "Stack Underflow" and exit.',
      '2. temp = top; item = top->data.',
      '3. top = top->next; free(temp); Return item.'
    ],
    procedure: [
      'Step 1: Open the interactive Stack Simulator below and choose between Array or Linked List mode.',
      'Step 2: Enter an integer into the input field and click "Push" to observe the Top pointer increment.',
      'Step 3: Push elements until capacity is reached to witness the Stack Overflow guard condition.',
      'Step 4: Click "Pop" to remove elements in reverse arrival order (LIFO) until Stack Underflow occurs.',
      'Step 5: Inspect the Peek operation returning stack[top] without mutating the stack.'
    ],
    code: {
      c: `#include <stdio.h>
#include <stdlib.h>

// Singly Linked List Node for Stack
struct Node {
    int data;
    struct Node* next;
};

struct Node* top = NULL;

void push(int value) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        printf("Stack Overflow! Heap memory exhausted.\\n");
        return;
    }
    newNode->data = value;
    newNode->next = top;
    top = newNode;
    printf("Pushed %d onto stack.\\n", value);
}

int pop() {
    if (top == NULL) {
        printf("Stack Underflow! Stack is empty.\\n");
        return -1;
    }
    struct Node* temp = top;
    int poppedVal = temp->data;
    top = top->next;
    free(temp);
    return poppedVal;
}

int peek() {
    if (top == NULL) {
        printf("Stack is empty!\\n");
        return -1;
    }
    return top->data;
}

int isEmpty() {
    return top == NULL;
}

void display() {
    struct Node* ptr = top;
    printf("Stack (TOP -> BOTTOM): ");
    while (ptr != NULL) {
        printf("%d -> ", ptr->data);
        ptr = ptr->next;
    }
    printf("NULL\\n");
}

int main() {
    push(10);
    push(20);
    push(30);
    display();
    printf("Top element: %d\\n", peek());
    printf("Popped element: %d\\n", pop());
    display();
    return 0;
}`,
      python: `class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedStack:
    def __init__(self):
        self.top = None

    def push(self, data):
        new_node = Node(data)
        new_node.next = self.top
        self.top = new_node
        print(f"Pushed {data}")

    def pop(self):
        if self.is_empty():
            print("Stack Underflow!")
            return None
        popped = self.top.data
        self.top = self.top.next
        return popped

    def peek(self):
        return None if self.is_empty() else self.top.data

    def is_empty(self):
        return self.top is None`
    },
    sampleInput: 'push(10), push(20), push(30), peek(), pop(), display()',
    expectedOutput: `Pushed 10 onto stack.
Pushed 20 onto stack.
Pushed 30 onto stack.
Stack (TOP -> BOTTOM): 30 -> 20 -> 10 -> NULL
Top element: 30
Popped element: 30
Stack (TOP -> BOTTOM): 20 -> 10 -> NULL`,
    references: [
      'Aaron M Tenenbaum, Yedidyah Langsam, Moshe J Augenstein, "Data Structures Using C", Pearson Publication.',
      'Reema Thareja, "Data Structures using C", Oxford Press.',
      'Granville Barnett and Luca Del Tongo, "Data Structures and Algorithms: Annotated Reference with Examples", 2008.'
    ],
    conclusion: 'The stack is the simplest linear data structure and easiest to implement as a program. It uses the LIFO approach where elements entered last are removed first via a single active end (top).',
    quiz: [
      {
        id: 1,
        question: 'In an array-based stack of size N, what condition indicates stack overflow?',
        options: ['top == 0', 'top == N - 1', 'top == N', 'top == -1'],
        correctAnswer: 1,
        explanation: 'In zero-indexed arrays of size N, the last index is N - 1. When top reaches N - 1, the stack has reached maximum capacity.'
      },
      {
        id: 2,
        question: 'What is the time complexity of the pop operation in a linked list implementation of a stack?',
        options: ['O(n)', 'O(log n)', 'O(1)', 'O(n^2)'],
        correctAnswer: 2,
        explanation: 'Pop removes the head node by reassigning head = head->next, which takes O(1) constant time without any traversal.'
      },
      {
        id: 3,
        question: 'Which of the following real-world applications inherently relies on a Stack (LIFO) data structure?',
        options: ['Breadth-First Search (BFS) graph traversal', 'Function call recursion and call stack activation frames', 'Operating system printer spooler queue', 'CPU Round-Robin process scheduling'],
        correctAnswer: 1,
        explanation: 'The runtime environment uses a call stack to save return addresses, local variables, and register states across nested and recursive function invocations.'
      },
      {
        id: 4,
        question: 'When converting the infix expression "A + B * C" to postfix notation, what is the resulting string?',
        options: ['+ A * B C', 'A B C * +', 'A B + C *', 'A B C + *'],
        correctAnswer: 1,
        explanation: 'Due to operator precedence, multiplication (*) takes priority over addition (+), yielding subexpression BC*, which is subsequently appended with A and + to form ABC*+.'
      },
      {
        id: 5,
        question: 'In an array-based stack initialized with top = -1, what condition signifies stack underflow?',
        options: ['Attempting a pop() or peek() operation when top == -1', 'Attempting a push() operation when top == 0', 'Attempting a push() operation when top == N - 1', 'Attempting a peek() operation when top == 1'],
        correctAnswer: 0,
        explanation: 'Stack underflow occurs when an algorithm attempts to pop or peek an element from an empty stack (top == -1).'
      },
      {
        id: 6,
        question: 'In a linked-list implementation of a stack, why are elements inserted at the head rather than the tail?',
        options: ['Tail insertion is forbidden in C', 'Head insertion runs in O(1) time without requiring list traversal', 'Linked lists can only store data at the head node', 'It prevents memory leaks in the operating system'],
        correctAnswer: 1,
        explanation: 'Inserting at the head takes O(1) constant time because the head pointer directly references the top node. Traversal to the tail of a singly linked list would require O(N) time.'
      },
      {
        id: 7,
        question: 'If the sequence of operations push(10), push(20), pop(), push(30), push(40), pop(), peek() is executed, what value is returned by peek()?',
        options: ['10', '20', '30', '40'],
        correctAnswer: 2,
        explanation: 'Trace: push(10) -> [10]; push(20) -> [10, 20]; pop() removes 20 -> [10]; push(30) -> [10, 30]; push(40) -> [10, 30, 40]; pop() removes 40 -> [10, 30]; peek() returns 30.'
      },
      {
        id: 8,
        question: 'What is the auxiliary space complexity of verifying balanced parentheses in a string of length N using a stack?',
        options: ['O(1)', 'O(log N)', 'O(N)', 'O(N^2)'],
        correctAnswer: 2,
        explanation: 'In the worst case (e.g. string consisting entirely of opening brackets "((((..."), all N characters are pushed onto the stack, requiring O(N) auxiliary memory.'
      },
      {
        id: 9,
        question: 'What is the value of the postfix expression "6 3 / 4 2 * +" evaluated using an operand stack?',
        options: ['10', '14', '16', '24'],
        correctAnswer: 0,
        explanation: '6 3 / evaluates to 6 / 3 = 2. Then 4 2 * evaluates to 4 * 2 = 8. Finally 2 8 + evaluates to 2 + 8 = 10.'
      },
      {
        id: 10,
        question: 'What is the primary trade-off when using a dynamically allocated linked list stack over a fixed-size array stack?',
        options: ['Linked list has faster push/pop operations', 'Linked list avoids fixed capacity limits but incurs additional pointer memory overhead per node', 'Linked list cannot store user-defined structures', 'Linked list requires continuous memory allocation in physical RAM'],
        correctAnswer: 1,
        explanation: 'A linked list stack grows and shrinks dynamically preventing overflow, but requires extra memory per node for pointer references and incurs minor pointer dereference overhead.'
      }
    ]
  },

  // =========================================================================
  // EXPERIMENT 2: Implement Linear Queue ADT using an array/linked list
  // =========================================================================
  {
    id: 'linear-queue-adt',
    num: 2,
    subjectId: 'dsa',
    title: 'Implement Linear Queue ADT using an array/linked list',
    subtitle: 'FIFO Mechanics, Enqueue, Dequeue, Circular Queue Resolution',
    category: 'Linear Data Structures',
    iitReference: 'Autonomous Curriculum Standards / KJSIT AIL302 Data Structure and Algorithms Lab',
    iitLabUrl: 'https://vlab.co.in/data-structures-1/',
    aim: '2A. Implementation of Queues ADT using arrays. 2B. Implementation of Queues ADT using linked list.',
    objective: 'Explore concept of Queue ADT and write C code to implement Queue ADT using a Linked List.',
    software: 'GCC / Turbo C / Online C Compiler',
    postLabQuestions: [
      {
        question: 'What is the primary limitation of a linear array implementation of a queue and how does a circular queue solve it?',
        answer: 'In a linear array queue, dequeuing elements leaves empty spaces at the beginning that cannot be reused because rear reaches capacity - 1 (index drift). A circular queue solves this by wrapping indices around using modulo arithmetic: rear = (rear + 1) % capacity.'
      },
      {
        question: 'How do enqueue and dequeue operations differ in time complexity between an array and a linked list implementation?',
        answer: 'Both array (circular) and linked list (with front and rear pointers) execute enqueue and dequeue in O(1) constant time.'
      },
      {
        question: 'Explain the state of a queue when front = 1 and rear = 6. How many elements are currently in the queue?',
        answer: 'When front = 1 and rear = 6 in an array queue, exactly (rear - front + 1) = 6 - 1 + 1 = 6 elements occupy indices 1 through 6.'
      },
      {
        question: 'What happens when front = 10 and rear = 9 in a 10-element circular queue?',
        answer: 'When (rear + 1) % capacity == front, the circular queue is completely full and triggers an overflow condition.'
      }
    ],
    theory: {
      overview: [
        'Queue is a linear data structure that follows a particular order in which the operations are performed for storing data. The order is First in First out (FIFO). One can imagine a queue as a line of people waiting to receive something in sequential order which starts from the beginning of the line.',
        'It is an ordered list in which insertions are done at one end which is known as the rear and deletions are done from the other end known as the front. A good example of a queue is any queue of consumers for a resource where the consumer that came first is served first.',
        'The difference between stacks and queues is in removing. In a stack we remove the item the most recently added; in a queue, we remove the item the least recently added.',
        'Implement Queue using array: Basic Operations on Queue: 1. enqueue(): Inserts an element at the end of the queue i.e. at the rear end. 2. dequeue(): This operation removes and returns an element that is at the front end of the queue. 3. isEmpty(): This operation indicates whether the queue is empty or not. 4. isFull(): This operation indicates whether the queue is full or not. 5. size(): This operation returns the size of the queue i.e. the total number of elements it contains. 6. peek(): This operation return first element of the queue. 7. Print(): This operation return all elements of the queue.',
        'Array implementation of Queue: For implementing a queue, we need to keep track of two indices, front and rear. We enqueue an item at the rear and dequeue an item from the front. If we simply increment front and rear indices, then there may be problems, the front may reach the end of the array. The solution to this problem is to increase front and rear in a circular manner.',
        'Linked List implementation of Queue: For implementing a queue, we need to keep track of two indices, front and rear. We enqueue an item at the rear and dequeue an item from the front. If we simply increment front and rear indices, then there may be problems, the front may reach the end of the array. The solution to this problem is to increase front and rear in a circular manner. Operations: 1. enqueue(), 2. dequeue(), 3. peek(), 4. print().'
      ],
      complexityTable: [
        { parameter: 'enqueue()', value: 'O(1) - Inserts an element at the rear end' },
        { parameter: 'dequeue()', value: 'O(1) - Removes and returns element at front end' },
        { parameter: 'peek()', value: 'O(1) - Returns first element of the queue' },
        { parameter: 'isEmpty()', value: 'O(1) - Indicates whether the queue is empty or not' },
        { parameter: 'isFull()', value: 'O(1) - Indicates whether the queue is full or not' },
        { parameter: 'size()', value: 'O(1) - Returns total number of elements contained' },
        { parameter: 'Print()', value: 'O(n) - Returns all elements of the queue' }
      ],
      keyPoints: [
        'FIFO Principle: First in First out order where the consumer that came first is served first.',
        'Removal Difference: In a stack we remove the item the most recently added; in a queue, we remove the item the least recently added.',
        'Two Indices: Front end for removing (dequeue) and Rear end for inserting (enqueue).',
        'Circular Increase Solution: If we simply increment front and rear, front may reach the end of the array; the solution is to increase front and rear in a circular manner.',
        'Array vs Linked List: Both support constant-time operations; linked list dynamically manages nodes without fixed boundary limits.'
      ],
      realWorldApplications: [
        'Any queue of consumers for a resource where the consumer that came first is served first.',
        'Operating system task and I/O printer queue scheduling.',
        'Network packet transmission buffers and message queues.'
      ]
    },
    algorithm: [
      'Algorithm for Enqueue (Array):',
      '1. If (rear + 1) % capacity == front, print "Queue Overflow" and exit.',
      '2. If front == -1, set front = 0, rear = 0.',
      '3. Else rear = (rear + 1) % capacity.',
      '4. queue[rear] = value.',
      'Algorithm for Dequeue (Array):',
      '1. If front == -1, print "Queue Underflow" and exit.',
      '2. value = queue[front].',
      '3. If front == rear, set front = -1, rear = -1 (queue becomes empty).',
      '4. Else front = (front + 1) % capacity. Return value.'
    ],
    procedure: [
      'Step 1: Open the Queue Simulator below to observe FIFO operations.',
      'Step 2: Enqueue items (e.g. 20, 40, 60) and observe front and rear pointers advancing.',
      'Step 3: Dequeue an item and observe that 20 (the earliest element) is removed first.',
      'Step 4: Test queue boundary conditions (Underflow when empty, Overflow when capacity reached).'
    ],
    code: {
      c: `#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
};

struct Node* front = NULL;
struct Node* rear = NULL;

void enqueue(int value) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = value;
    newNode->next = NULL;
    if (front == NULL && rear == NULL) {
        front = rear = newNode;
        return;
    }
    rear->next = newNode;
    rear = newNode;
    printf("Enqueued: %d\\n", value);
}

int dequeue() {
    if (front == NULL) {
        printf("Queue Underflow!\\n");
        return -1;
    }
    struct Node* temp = front;
    int val = temp->data;
    front = front->next;
    if (front == NULL) rear = NULL;
    free(temp);
    return val;
}

void display() {
    struct Node* ptr = front;
    printf("Queue (FRONT -> REAR): ");
    while (ptr != NULL) {
        printf("%d -> ", ptr->data);
        ptr = ptr->next;
    }
    printf("NULL\\n");
}

int main() {
    enqueue(20);
    enqueue(40);
    enqueue(60);
    display();
    printf("Dequeued: %d\\n", dequeue());
    display();
    return 0;
}`,
      python: `class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedQueue:
    def __init__(self):
        self.front = None
        self.rear = None

    def enqueue(self, data):
        new_node = Node(data)
        if self.rear is None:
            self.front = self.rear = new_node
            return
        self.rear.next = new_node
        self.rear = new_node

    def dequeue(self):
        if self.front is None:
            return None
        val = self.front.data
        self.front = self.front.next
        if self.front is None:
            self.rear = None
        return val`
    },
    sampleInput: 'enqueue(20), enqueue(40), enqueue(60), dequeue(), display()',
    expectedOutput: `Enqueued: 20
Enqueued: 40
Enqueued: 60
Queue (FRONT -> REAR): 20 -> 40 -> 60 -> NULL
Dequeued: 20
Queue (FRONT -> REAR): 40 -> 60 -> NULL`,
    references: [
      'Aaron M Tenenbaum, Yedidyah Langsam, Moshe J Augenstein, "Data Structures Using C", Pearson Publication.',
      'Reema Thareja, "Data Structures using C", Oxford Press.',
      'Granville Barnett and Luca Del Tongo, "Data Structures and Algorithms: Annotated Reference with Examples", 2008.'
    ],
    conclusion: 'The queue data structure is a linear structure storing elements in FIFO order. Arrays and linked lists can both be used; circular arrays solve linear index exhaustion.',
    quiz: [
      {
        id: 1,
        question: 'Which end is used for removing elements from a standard linear queue?',
        options: ['Rear', 'Front', 'Top', 'Middle'],
        correctAnswer: 1,
        explanation: 'In a queue, elements are enqueued at the Rear and removed (dequeued) from the Front.'
      }
    ]
  },

  // =========================================================================
  // EXPERIMENT 3: Implementation of Infix to Postfix conversion
  // =========================================================================
  {
    id: 'infix-to-postfix',
    num: 3,
    subjectId: 'dsa',
    title: 'Implementation of Infix to Postfix conversion',
    subtitle: 'Operator Precedence, Associativity & Expression Parsing using Stack',
    category: 'Linear Data Structures',
    iitReference: 'Autonomous Curriculum Standards / KJSIT AIL302 Data Structure and Algorithms Lab',
    iitLabUrl: 'https://vlab.co.in/data-structures-1/',
    aim: 'Implementation of Infix to Postfix conversion.',
    objective: 'Explore the concept of Infix to postfix conversion and write C code to implement Infix to Postfix conversion using stack.',
    software: 'GCC / Turbo C / Online C Compiler',
    postLabQuestions: [
      {
        question: 'Why is postfix notation preferred over infix notation by computer compilers and interpreters?',
        answer: 'Postfix notation eliminates ambiguities associated with operator precedence and associativity without requiring parentheses. Expressions can be evaluated in a single linear scan using an operand stack in O(n) time.'
      },
      {
        question: 'Convert the expression A + B * (C - D) / E to postfix step by step.',
        answer: '1. Scan A -> output: A. 2. Push +. 3. Scan B -> output: AB. 4. Push *. 5. Push (. 6. Scan C -> output: ABC. 7. Push -. 8. Scan D -> output: ABCD. 9. Encounter ) -> pop -: ABCD-. 10. Scan / (same precedence as *): pop * to output: ABCD-* and push /. 11. Scan E -> output: ABCD-*E. 12. Pop remaining / and + -> final postfix: AB C D - * E / +.'
      },
      {
        question: 'How does operator associativity affect stack popping behavior during conversion?',
        answer: 'For left-to-right associative operators (+, -, *, /), an incoming operator pops stack operators of equal or higher precedence. For right-to-left operators (^ exponentiation), an incoming operator does not pop an operator of equal precedence.'
      },
      {
        question: 'What is the time and space complexity of the infix-to-postfix conversion algorithm?',
        answer: 'Time complexity is O(n) because each character is scanned once and each operator is pushed and popped at most once. Auxiliary space is O(n) for the operator stack and output string.'
      }
    ],
    theory: {
      overview: [
        'Application of Stack ADT: Infix to Postfix conversion and Postfix Evaluation (Module 2.1 Stack ADT & Applications).',
        'Infix Notation: Operators are placed between operands (e.g., A + B). While conventional for human reading, evaluating infix expressions computationally requires checking operator precedence, associativity, and multiple levels of nested parentheses.',
        'Postfix Notation (Reverse Polish Notation / RPN): Operators are placed immediately after their respective operands (e.g., AB+). Postfix expressions do not require parentheses and can be evaluated sequentially in a single left-to-right pass using a stack.',
        'Conversion Strategy using Stack ADT: As the infix expression is scanned character by character: Operands are output directly to the postfix expression; Left parenthesis "(" is pushed to the operator stack; Right parenthesis ")" pops operators from the stack to the output until matching "(" is popped; Operators (+, -, *, /, ^) pop higher or equal precedence operators from the stack before being pushed.'
      ],
      complexityTable: [
        { parameter: 'Scan / Conversion Time', value: 'O(N) - Single linear scan of infix string' },
        { parameter: 'Stack Push / Pop Operations', value: 'O(1) - Each operator pushed & popped at most once' },
        { parameter: 'Auxiliary Space (Operator Stack)', value: 'O(N) - Stack stores operators during nesting' },
        { parameter: 'Postfix Expression Space', value: 'O(N) - Output buffer storing converted expression' }
      ],
      keyPoints: [
        'Stack ADT Application: Leverages LIFO property of stacks to reverse operator evaluation order based on precedence.',
        'Operator Precedence Order: Exponentiation (^) > Multiplication & Division (*, /) > Addition & Subtraction (+, -).',
        'Parentheses Rule: "(" has highest priority for pushing but lowest inside the stack; ")" forces popping until "(".',
        'Direct Operand Emission: Operands retain their exact relative ordering from infix to postfix.'
      ],
      realWorldApplications: [
        'Compiler intermediate code generation and expression parsing engines.',
        'Postfix evaluation in electronic scientific calculators and arithmetic logic units (ALUs).',
        'Stack-based virtual machines (e.g., Java Virtual Machine bytecode execution).'
      ]
    },
    algorithm: [
      'Algorithm for Infix to Postfix Conversion:',
      '1. Initialize an empty stack of characters for operators.',
      '2. Scan the infix string from left to right, character by character:',
      '   a. If character is an operand (letter/digit), append it to the postfix output.',
      '   b. If character is "(", push it to the stack.',
      '   c. If character is ")", pop from stack to output until "(" is popped. Discard "(".',
      '   d. If character is an operator (+, -, *, /, ^):',
      '      While stack is not empty, top != "(", and precedence(stack[top]) >= precedence(char):',
      '         Pop operator from stack and append to output.',
      '      Push current operator onto stack.',
      '3. After the entire infix string is scanned, pop all remaining operators from the stack to the output.',
      '4. Return the resulting postfix string.'
    ],
    procedure: [
      'Step 1: Navigate to the interactive Stack Simulator below and switch to "Infix to Postfix" mode.',
      'Step 2: Enter an infix expression such as `A + B * (C - D)` or click preset examples.',
      'Step 3: Click "Step Forward" to observe token scanning, stack state, and postfix accumulator growth.',
      'Step 4: Verify the generated postfix string against operator precedence tables.'
    ],
    code: {
      c: `#include <stdio.h>
#include <ctype.h>
#include <string.h>

#define MAX 100

char stack[MAX];
int top = -1;

void push(char c) { stack[++top] = c; }
char pop() { return stack[top--]; }
char peek() { return stack[top]; }
int isEmpty() { return top == -1; }

int precedence(char op) {
    if (op == '^') return 3;
    if (op == '*' || op == '/') return 2;
    if (op == '+' || op == '-') return 1;
    return 0;
}

void infixToPostfix(char* infix, char* postfix) {
    int k = 0;
    for (int i = 0; infix[i] != '\\0'; i++) {
        char ch = infix[i];
        if (isalnum(ch)) {
            postfix[k++] = ch;
        } else if (ch == '(') {
            push(ch);
        } else if (ch == ')') {
            while (!isEmpty() && peek() != '(') {
                postfix[k++] = pop();
            }
            pop(); // Discard '('
        } else {
            while (!isEmpty() && precedence(peek()) >= precedence(ch)) {
                postfix[k++] = pop();
            }
            push(ch);
        }
    }
    while (!isEmpty()) {
        postfix[k++] = pop();
    }
    postfix[k] = '\\0';
}

int main() {
    char infix[] = "A+B*(C-D)";
    char postfix[MAX];
    infixToPostfix(infix, postfix);
    printf("Infix:   %s\\n", infix);
    printf("Postfix: %s\\n", postfix);
    return 0;
}`,
      python: `def infix_to_postfix(expression):
    precedence = {'+': 1, '-': 1, '*': 2, '/': 2, '^': 3}
    stack = []
    output = []
    
    for char in expression:
        if char.isalnum():
            output.append(char)
        elif char == '(':
            stack.append(char)
        elif char == ')':
            while stack and stack[-1] != '(':
                output.append(stack.pop())
            stack.pop()
        else:
            while stack and stack[-1] != '(' and precedence.get(stack[-1], 0) >= precedence.get(char, 0):
                output.append(stack.pop())
            stack.append(char)
            
    while stack:
        output.append(stack.pop())
    return ''.join(output)`
    },
    sampleInput: 'A + B * (C - D)',
    expectedOutput: `Infix:   A+B*(C-D)
Postfix: ABCD-*+`,
    references: [
      'Aaron M Tenenbaum, Yedidyah Langsam, Moshe J Augenstein, "Data Structures Using C", Pearson Publication.',
      'Reema Thareja, "Data Structures using C", Oxford Press.',
      'Granville Barnett and Luca Del Tongo, "Data Structures and Algorithms: Annotated Reference with Examples", 2008.'
    ],
    conclusion: 'Infix to postfix conversion successfully decouples mathematical evaluation from parenthesis nesting, enabling fast execution via a single stack scan.',
    quiz: [
      {
        id: 1,
        question: 'What is the postfix form of the infix expression: (A + B) * C ?',
        options: ['AB+C*', 'ABC+*', '+AB*C', 'AB*C+'],
        correctAnswer: 0,
        explanation: 'Because of the parentheses, A+B is evaluated first producing AB+, which is then multiplied by C giving AB+C*.'
      }
    ]
  },

  // =========================================================================
  // EXPERIMENT 4: Implementation of Polynomial arithmetic using linked list
  // =========================================================================
  {
    id: 'polynomial-arithmetic',
    num: 4,
    subjectId: 'dsa',
    title: 'Implementation of Polynomial arithmetic using linked list',
    subtitle: 'Dynamic Polynomial Representation, Addition & Subtraction using Pointers',
    category: 'Linear Data Structures',
    iitReference: 'Autonomous Curriculum Standards / KJSIT AIL302 Data Structure and Algorithms Lab',
    iitLabUrl: 'https://vlab.co.in/data-structures-1/',
    aim: 'Implementation addition of Polynomial arithmetic using linked list. List.',
    objective: 'Explore the concept of representing polynomials using a linked list, write C code to perform polynomial addition, subtraction, and understand the importance of dynamic memory allocation.',
    software: 'GCC / Turbo C / Online C Compiler',
    postLabQuestions: [
      {
        question: 'Why is an array an inefficient data structure for representing sparse polynomials like P(x) = 100x^1000 + 1?',
        answer: 'An array representation requires an index for every possible power from 0 to 1000, allocating 1001 elements when only 2 terms have non-zero coefficients. A linked list uses exactly 2 nodes, eliminating memory wastage.'
      },
      {
        question: 'Explain the three cases considered while adding two polynomials represented as linked lists.',
        answer: 'Case 1 (ptr1->expo == ptr2->expo): Add coefficients and advance both pointers. Case 2 (ptr1->expo > ptr2->expo): Copy ptr1 term and advance ptr1. Case 3 (ptr1->expo < ptr2->expo): Copy ptr2 term and advance ptr2.'
      },
      {
        question: 'What is the time complexity of adding two polynomials with m and n non-zero terms?',
        answer: 'O(m + n) time complexity because each term in both sorted linked lists is visited at most once using two traversal pointers.'
      },
      {
        question: 'How can polynomial multiplication be implemented using linked lists?',
        answer: 'Multiply every term of polynomial 1 with every term of polynomial 2 (multiplying coefficients and adding exponents), then insert each resulting term into a sorted linked list while combining like terms.'
      }
    ],
    theory: {
      overview: [
        'A polynomial is an algebraic expression consisting of terms that include variables raised to powers and coefficients, e.g., P(x) = 5x^3 + 4x^2 + 2x + 7.',
        'Polynomials can be represented using a linked list, where each node contains: 1. Coefficient, 2. Exponent, 3. Pointer to next term.',
        'Why Linked List Representation? 1. Dynamic memory allocation (efficient storage). 2. Easy to insert/delete terms. 3. Handles polynomials of any degree.',
        'Addition of Polynomials: Let we have two polynomials: 3x^2 + 2x + 1 and 5x^2 - x + 2. Addition of two polynomials involves combining like terms present in the two polynomials. Means adding terms having same variables and same exponents. Combined result: 8x^2 + x + 3.',
        'Arrangement Order: Addition of two polynomials becomes easier if the terms are arranged in descending order.',
        'Procedure for adding two polynomials (e.g. P1 = 5x^6 + 6x^4 + 2x^3 and P2 = 8x^6 + 3x^2 + 4x + 5): Linked lists are scanned using pointers ptr1 and ptr2. Case 1 (ptr1->expo == ptr2->expo): Add coefficients, insert into RESULT, move both pointers. Case 2 (ptr1->expo > ptr2->expo): Insert ptr1 term into RESULT, move ptr1. Case 3 (ptr1->expo < ptr2->expo): Insert ptr2 term into RESULT, move ptr2. If one polynomial finishes earlier, remaining terms of the other are copied directly.'
      ],
      complexityTable: [
        { parameter: 'Polynomial Addition', value: 'O(m + n) - Single pass through both linked lists' },
        { parameter: 'Term Comparison', value: 'O(1) - Direct comparison of exponents' },
        { parameter: 'Node Insertion', value: 'O(1) - Appending term at end of RESULT list' },
        { parameter: 'Auxiliary Space', value: 'O(m + n) - Maximum number of nodes in RESULT list' }
      ],
      keyPoints: [
        'Node Structure: struct Node { int coeff; int expo; struct Node* next; };',
        'Descending Order: Arranging terms in descending order of exponents enables single-pass linear addition.',
        'Combining Like Terms: Terms with identical exponents have their coefficients summed: coeff = ptr1->coeff + ptr2->coeff.',
        'Dynamic Allocation: Linked lists allocate memory only for non-zero terms, avoiding huge wasted arrays for sparse polynomials.'
      ],
      realWorldApplications: [
        'Computer Algebra Systems (CAS) performing symbolic mathematical calculations.',
        'Signal processing equations and polynomial filter representations.',
        'Curve fitting, interpolation, and numerical analysis algorithms.'
      ]
    },
    algorithm: [
      'Procedure for adding two polynomials arranged in descending order:',
      '1. Initialize pointers ptr1 and ptr2 to the heads of the two polynomial linked lists.',
      '2. Create an empty linked list RESULT.',
      '3. Repeat until (ptr1 != NULL and ptr2 != NULL):',
      '   Case 1: If ptr1->expo == ptr2->expo:',
      '      Add coefficients: coeff = ptr1->coeff + ptr2->coeff.',
      '      If coeff != 0, insert (coeff, ptr1->expo) into RESULT.',
      '      Move both pointers: ptr1 = ptr1->next, ptr2 = ptr2->next.',
      '   Case 2: If ptr1->expo > ptr2->expo:',
      '      Insert (ptr1->coeff, ptr1->expo) into RESULT.',
      '      Move ptr1 = ptr1->next.',
      '   Case 3: If ptr1->expo < ptr2->expo:',
      '      Insert (ptr2->coeff, ptr2->expo) into RESULT.',
      '      Move ptr2 = ptr2->next.',
      '4. If one polynomial finishes earlier:',
      '   Repeat until ptr1 != NULL: Insert (ptr1->coeff, ptr1->expo) into RESULT; ptr1 = ptr1->next.',
      '   Repeat until ptr2 != NULL: Insert (ptr2->coeff, ptr2->expo) into RESULT; ptr2 = ptr2->next.',
      '5. Return RESULT linked list.'
    ],
    procedure: [
      'Step 1: Open the Polynomial Arithmetic Simulator below.',
      'Step 2: Choose an example from the manual (e.g. 5x^6 + 6x^4 + 2x^3 and 8x^6 + 3x^2 + 4x + 5).',
      'Step 3: Click "Next Step" to trace ptr1 and ptr2 comparing node exponents at each iteration.',
      'Step 4: Observe Case 1 combining 5x^6 + 8x^6 into 13x^6, followed by Case 2 and Case 3 handling remaining terms.',
      'Step 5: View the resulting dynamically allocated polynomial linked list.'
    ],
    code: {
      c: `#include <stdio.h>
#include <stdlib.h>

struct Node {
    int coeff;
    int expo;
    struct Node* next;
};

struct Node* createNode(int coeff, int expo) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->coeff = coeff;
    newNode->expo = expo;
    newNode->next = NULL;
    return newNode;
}

void insertTerm(struct Node** head, int coeff, int expo) {
    struct Node* newNode = createNode(coeff, expo);
    if (*head == NULL) {
        *head = newNode;
        return;
    }
    struct Node* temp = *head;
    while (temp->next != NULL) temp = temp->next;
    temp->next = newNode;
}

struct Node* addPolynomials(struct Node* p1, struct Node* p2) {
    struct Node* result = NULL;
    while (p1 != NULL && p2 != NULL) {
        if (p1->expo == p2->expo) {
            int sum = p1->coeff + p2->coeff;
            if (sum != 0) insertTerm(&result, sum, p1->expo);
            p1 = p1->next;
            p2 = p2->next;
        } else if (p1->expo > p2->expo) {
            insertTerm(&result, p1->coeff, p1->expo);
            p1 = p1->next;
        } else {
            insertTerm(&result, p2->coeff, p2->expo);
            p2 = p2->next;
        }
    }
    while (p1 != NULL) {
        insertTerm(&result, p1->coeff, p1->expo);
        p1 = p1->next;
    }
    while (p2 != NULL) {
        insertTerm(&result, p2->coeff, p2->expo);
        p2 = p2->next;
    }
    return result;
}

void displayPoly(struct Node* head) {
    while (head != NULL) {
        printf("%dx^%d", head->coeff, head->expo);
        if (head->next != NULL && head->next->coeff >= 0) printf(" + ");
        else if (head->next != NULL) printf(" ");
        head = head->next;
    }
    printf("\\n");
}

int main() {
    struct Node *p1 = NULL, *p2 = NULL;
    // P1 = 5x^6 + 6x^4 + 2x^3
    insertTerm(&p1, 5, 6);
    insertTerm(&p1, 6, 4);
    insertTerm(&p1, 2, 3);

    // P2 = 8x^6 + 3x^2 + 4x + 5
    insertTerm(&p2, 8, 6);
    insertTerm(&p2, 3, 2);
    insertTerm(&p2, 4, 1);
    insertTerm(&p2, 5, 0);

    printf("Poly 1: "); displayPoly(p1);
    printf("Poly 2: "); displayPoly(p2);

    struct Node* sum = addPolynomials(p1, p2);
    printf("Sum:    "); displayPoly(sum);
    return 0;
}`,
      python: `class TermNode:
    def __init__(self, coeff, expo):
        self.coeff = coeff
        self.expo = expo
        self.next = None

def add_polynomials(p1, p2):
    dummy = TermNode(0, 0)
    tail = dummy
    while p1 and p2:
        if p1.expo == p2.expo:
            s = p1.coeff + p2.coeff
            if s != 0:
                tail.next = TermNode(s, p1.expo)
                tail = tail.next
            p1 = p1.next
            p2 = p2.next
        elif p1.expo > p2.expo:
            tail.next = TermNode(p1.coeff, p1.expo)
            tail = tail.next
            p1 = p1.next
        else:
            tail.next = TermNode(p2.coeff, p2.expo)
            tail = tail.next
            p2 = p2.next
    while p1:
        tail.next = TermNode(p1.coeff, p1.expo)
        tail = tail.next
        p1 = p1.next
    while p2:
        tail.next = TermNode(p2.coeff, p2.expo)
        tail = tail.next
        p2 = p2.next
    return dummy.next`
    },
    sampleInput: 'P1: 5x^6 + 6x^4 + 2x^3\nP2: 8x^6 + 3x^2 + 4x + 5',
    expectedOutput: `Poly 1: 5x^6 + 6x^4 + 2x^3
Poly 2: 8x^6 + 3x^2 + 4x + 5x^0
Sum:    13x^6 + 6x^4 + 2x^3 + 3x^2 + 4x + 5`,
    references: [
      'Aaron M. Tenenbaum, Yedidyah Langsam, Moshe J. Augenstein, "Data Structures Using C", Pearson Publication.',
      'Reema Thareja, "Data Structures using C", Oxford Press.',
      'Granville Barnett, Luca Del Tongo, "Data Structures and Algorithms: Annotated Reference with Examples", 2008.'
    ],
    conclusion: 'Polynomial arithmetic can be efficiently performed using linked lists. This approach allows dynamic handling of terms, supports large degrees, and avoids wasted memory compared to array implementations.',
    quiz: [
      {
        id: 1,
        question: 'When adding two polynomial terms with identical exponents (expo1 == expo2), what happens?',
        options: [
          'The exponents are added together',
          'The coefficients are added together and both pointers advance',
          'Only the first pointer advances',
          'The node is deleted'
        ],
        correctAnswer: 1,
        explanation: 'For terms with equal exponents, their coefficients are algebraically summed and both polynomial pointers advance to their next terms.'
      }
    ]
  },

  // =========================================================================
  // EXPERIMENT 5: Implementation of Binary Trees and operations of Binary Trees
  // =========================================================================
  {
    id: 'binary-tree-traversals',
    num: 5,
    subjectId: 'dsa',
    title: 'Implementation of Binary Trees and operations of Binary Trees',
    subtitle: 'Hierarchical Node Structures, Mathematical Properties & Recursive Traversals',
    category: 'Trees & Hierarchical',
    iitReference: 'Autonomous Curriculum Standards / KJSIT AIL302 Data Structure and Algorithms Lab',
    iitLabUrl: 'https://vlab.co.in/data-structures-1/',
    aim: 'Implementation of Binary Trees and traversing Techniques.',
    objective: 'Explore the concept of Binary Search Trees using Linked List and write C code to implement Binary Search using Linked List.',
    software: 'GCC / Turbo C / Online C Compiler',
    postLabQuestions: [
      {
        question: 'Differentiate between a full binary tree, a complete binary tree, and a skewed binary tree.',
        answer: 'A full binary tree is one where every node has 0 or 2 children. A complete binary tree has all levels filled except possibly the last, which is filled from left to right. A skewed binary tree has all nodes with only one child (purely left or purely right).'
      },
      {
        question: 'What traversal of a Binary Search Tree produces elements in ascending sorted order?',
        answer: 'In-order traversal (Left -> Root -> Right) visits nodes in strictly ascending sorted order for any valid BST.'
      },
      {
        question: 'What is the relation between the number of leaf nodes and internal nodes with two children in a binary tree?',
        answer: 'The total number of leaf nodes L equals the number of nodes with two children T_2 plus one: L = T_2 + 1.'
      },
      {
        question: 'Write the recursive call order for Pre-order, In-order, and Post-order traversals.',
        answer: 'Pre-order: Root -> Left -> Right. In-order: Left -> Root -> Right. Post-order: Left -> Right -> Root.'
      }
    ],
    theory: {
      overview: [
        'Part A: Binary Tree: Binary tree is a tree data structure (non-linear) in which each node can have at most two children which are referred to as the left child and the right child. The topmost node in a binary tree is called the root, and the bottom-most nodes are called leaves. A binary tree can be visualized as a hierarchical structure with the root at the top and the leaves at the bottom.',
        'Representation of Binary Tree: Each node in a Binary Tree has three parts: 1. Data, 2. Pointer to the left child, 3. Pointer to the right child.',
        'Properties of Binary Tree: 1) The maximum number of nodes at level L of a binary tree is 2^L. 2) The maximum number of nodes in a binary tree of height H is 2^H - 1. 3) Total number of leaf nodes in a binary tree = total number of nodes with 2 children + 1. 4) In a Binary Tree with N nodes, the minimum possible height or the minimum number of levels is Log2(N+1). 5) A Binary Tree with L leaves has at least |Log2L| + 1 levels.',
        'Part B: Operation on Binary Tree: 1. Traversal in Binary Tree, 2. Insertion in Binary Tree, 3. Deletion in Binary Tree.',
        'Traversal in Binary Tree involves visiting all the nodes of the binary tree: 1. Pre-order Traversal (current-left-right): Visiting root node first, then recursively left subtree, followed by recursive right subtree. Used for creating a copy of the tree, prefix notation of an expression tree. 2. In-order Traversal (left-current-right): Recursive left subtree, visits root node, then recursive right subtree. Mainly used for Binary Search Trees where it returns values in ascending order. 3. Post-order Traversal (left-right-current): Recursively traverses left subtree first, then right subtree, and finally visits root node. Often used in expression tree evaluation.'
      ],
      complexityTable: [
        { parameter: 'Tree Traversal (Pre/In/Post)', value: 'O(N) - Visits all N nodes once' },
        { parameter: 'Maximum Nodes at Level L', value: '2^L' },
        { parameter: 'Maximum Nodes of Height H', value: '2^H - 1' },
        { parameter: 'Relation of Leaves to Degree-2 Nodes', value: 'Leaf nodes = (nodes with 2 children) + 1' },
        { parameter: 'Minimum Height with N Nodes', value: 'Log2(N + 1)' },
        { parameter: 'Auxiliary Stack Space', value: 'O(H), where H is the height of tree' }
      ],
      keyPoints: [
        'Non-Linear Structure: Topmost node is root, bottom-most nodes without children are leaves.',
        'Node Representation: struct Node { int data; struct Node* left; struct Node* right; };',
        'Pre-Order (Current - Left - Right): Node visited before recursive subtrees; used for prefix expression & copying trees.',
        'In-Order (Left - Current - Right): Node visited in between subtrees; yields ascending sorted keys in BST.',
        'Post-Order (Left - Right - Current): Node visited after subtrees; used in bottom-up destruction & postfix expression evaluation.'
      ],
      realWorldApplications: [
        'Expression Trees for evaluating mathematical formulas and compiler parsing.',
        'Huffman coding trees used in lossless data compression algorithms.',
        'Hierarchical directory file systems and syntax trees in language interpreters.'
      ]
    },
    algorithm: [
      'Algorithm for Pre-order Traversal (Recursive):',
      'Step 1: If TREE == NULL, then return.',
      'Step 2: Visit (print/process) TREE -> DATA.',
      'Step 3: Call PREORDER(TREE -> LEFT).',
      'Step 4: Call PREORDER(TREE -> RIGHT).',
      'Step 5: End.',
      'Algorithm for In-order Traversal (Recursive):',
      'Step 1: If TREE == NULL, then return.',
      'Step 2: Call INORDER(TREE -> LEFT).',
      'Step 3: Visit (print/process) TREE -> DATA.',
      'Step 4: Call INORDER(TREE -> RIGHT).',
      'Step 5: End.',
      'Algorithm for Post-order Traversal (Recursive):',
      'Step 1: If TREE == NULL, then return.',
      'Step 2: Call POSTORDER(TREE -> LEFT).',
      'Step 3: Call POSTORDER(TREE -> RIGHT).',
      'Step 4: Visit (print/process) TREE -> DATA.',
      'Step 5: End.'
    ],
    procedure: [
      'Step 1: Open the Binary Tree Simulator below.',
      'Step 2: Observe the default hierarchical binary tree structure with nodes 20, 30, 40, 50, 60, 70, 80.',
      'Step 3: Click "Inorder Traversal" to view the left-root-right recursion and verify sorted output.',
      'Step 4: Click "Preorder" and "Postorder" to observe node visit sequences.'
    ],
    code: {
      c: `#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* left;
    struct Node* right;
};

struct Node* newNode(int data) {
    struct Node* node = (struct Node*)malloc(sizeof(struct Node));
    node->data = data;
    node->left = NULL;
    node->right = NULL;
    return node;
}

void preorder(struct Node* root) {
    if (root == NULL) return;
    printf("%d ", root->data);
    preorder(root->left);
    preorder(root->right);
}

void inorder(struct Node* root) {
    if (root == NULL) return;
    inorder(root->left);
    printf("%d ", root->data);
    inorder(root->right);
}

void postorder(struct Node* root) {
    if (root == NULL) return;
    postorder(root->left);
    postorder(root->right);
    printf("%d ", root->data);
}

int main() {
    /* Constructed tree:
            50
          /    \\
        30      70
       /  \\    /  \\
      20  40  60  80
    */
    struct Node* root = newNode(50);
    root->left = newNode(30);
    root->right = newNode(70);
    root->left->left = newNode(20);
    root->left->right = newNode(40);
    root->right->left = newNode(60);
    root->right->right = newNode(80);

    printf("Preorder:  "); preorder(root); printf("\\n");
    printf("Inorder:   "); inorder(root); printf("\\n");
    printf("Postorder: "); postorder(root); printf("\\n");
    return 0;
}`,
      python: `class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None

def preorder(root):
    if not root: return []
    return [root.val] + preorder(root.left) + preorder(root.right)

def inorder(root):
    if not root: return []
    return inorder(root.left) + [root.val] + inorder(root.right)

def postorder(root):
    if not root: return []
    return postorder(root.left) + postorder(root.right) + [root.val]`
    },
    sampleInput: 'Tree nodes: 50, 30, 70, 20, 40, 60, 80',
    expectedOutput: `Preorder:  50 30 20 40 70 60 80 
Inorder:   20 30 40 50 60 70 80 
Postorder: 20 40 30 60 80 70 50 `,
    references: [
      'Aaron M. Tenenbaum, Yedidyah Langsam, Moshe J. Augenstein, "Data Structures Using C", Pearson Publication.',
      'Reema Thareja, "Data Structures using C", Oxford University Press.',
      'Seymour Lipschutz, "Data Structures with C", Schaum\'s Outlines, McGraw Hill.',
      'Mark Allen Weiss, "Data Structures and Algorithm Analysis in C", Pearson Education.'
    ],
    conclusion: 'Binary trees provide an efficient way to organize hierarchical data, and traversal operations (inorder, preorder, postorder) enable systematic node visiting essential for searching, sorting, and expression evaluation.',
    quiz: [
      {
        id: 1,
        question: 'What is the maximum number of nodes in a binary tree of height H?',
        options: ['2^H', '2^H - 1', '2^(H-1)', 'H^2'],
        correctAnswer: 1,
        explanation: 'Summing maximum nodes across all levels 0 to H-1 yields 2^0 + 2^1 + ... + 2^(H-1) = 2^H - 1.'
      }
    ]
  },

  // =========================================================================
  // EXPERIMENT 6: Implementation of Binary Search Trees using Linked List
  // =========================================================================
  {
    id: 'binary-search-tree-operations',
    num: 6,
    subjectId: 'dsa',
    title: 'Implementation of Binary Search Trees using Linked List',
    subtitle: 'BST Ordering Property, Dynamic Node Pointers, Search, Insert & Deletion',
    category: 'Trees & Hierarchical',
    iitReference: 'Autonomous Curriculum Standards / KJSIT AIL302 Data Structure and Algorithms Lab',
    iitLabUrl: 'https://vlab.co.in/data-structures-1/',
    aim: 'Implementation of Binary Search Trees using Linked List',
    objective: 'Understand the concept of Binary Search Tree (BST) and its properties, implement a linked list–based representation of tree nodes, write and execute algorithms for insertion, searching, and traversals.',
    software: 'GCC / Turbo C / Online C Compiler',
    postLabQuestions: [
      {
        question: 'What is the best-case, average-case, and worst-case time complexity of search in a BST?',
        answer: 'Best case: O(1) when the target is at the root. Average case: O(log n) for a balanced tree. Worst case: O(n) for a completely skewed degenerate tree.'
      },
      {
        question: 'Explain the process of deleting a node with two children in a BST.',
        answer: 'Find either the inorder successor (smallest in right subtree) or inorder predecessor (largest in left subtree). Copy its key to the target node, then recursively delete that successor/predecessor node (which has at most one child).'
      },
      {
        question: 'Why does inserting elements in sorted order degrade a BST into a degenerate/skewed tree?',
        answer: 'Inserting strictly sorted elements always appends to the right child, forming a linear linked list of height N, causing operations to degrade from O(log n) to O(n).'
      },
      {
        question: 'How do self-balancing trees like AVL or Red-Black trees solve BST degradation?',
        answer: 'They enforce balance invariants via tree rotations (LL, RR, LR, RL) during insertion and deletion, guaranteeing O(log n) height.'
      }
    ],
    theory: {
      overview: [
        'Introduction to Binary Search Tree: Binary Search Tree is a data structure used in computer science for organizing and storing data in a sorted manner. Binary search tree follows all properties of binary tree and its left child contains values less than the parent node and the right child contains values greater than the parent node. This hierarchical structure allows for efficient Searching, Insertion, and Deletion operations on the data stored in the tree.',
        'What is Binary Search Tree? Binary Search Tree (BST) is a special type of binary tree in which the left child of a node has a value less than the node’s value and the right child has a value greater than the node’s value. This property is called the BST property and it makes it possible to efficiently search, insert, and delete elements in the tree.',
        'Properties of Binary Search Tree: 1. The left subtree of a node contains only nodes with keys lesser than the node’s key. 2. The right subtree of a node contains only nodes with keys greater than the node’s key. 3. The left and right subtree each must also be a binary search tree. 4. There must be no duplicate nodes.',
        'Searching a node in BST: Searching in BST means to locate a specific node in the data structure. In Binary search tree, searching a node is easy because of its specific order: 1. First, compare the element to be searched with the root element: If root is matched with the target element, then return the node’s location; If it is not matched, then check whether the item is less than the root element: if it is smaller, move to the left subtree; if it is larger, move to the right subtree. 2. Repeat the above procedure recursively until the match is found. 3. If the element is not found or not present in the tree, then return NULL.'
      ],
      complexityTable: [
        { parameter: 'Search Time (Average / Balanced)', value: 'O(log n)' },
        { parameter: 'Search Time (Worst / Skewed Tree)', value: 'O(n)' },
        { parameter: 'Insertion Time (Average)', value: 'O(log n)' },
        { parameter: 'Deletion Time (Average)', value: 'O(log n)' },
        { parameter: 'In-order Traversal Time', value: 'O(n) - Outputs nodes in ascending sorted order' },
        { parameter: 'Auxiliary Space (Recursive Call Stack)', value: 'O(h), where h is the tree height' }
      ],
      keyPoints: [
        'BST Property: Left subtree keys < Node key < Right subtree keys.',
        'Recursive Search: Element comparison branches either strictly left or strictly right, halving search space in balanced trees.',
        'No Duplicate Keys: Standard BST definition enforces distinct keys for unambiguous ordering.',
        'Subtree Invariance: Both left and right subtrees must independently satisfy all BST properties.'
      ],
      realWorldApplications: [
        'Dynamic symbol tables and dictionary lookup structures in compilers.',
        'Database indexing and B-tree storage foundation.',
        'Fast range searching and numerical data indexing.'
      ]
    },
    algorithm: [
      'Algorithm for Searching a Node in BST:',
      '1. Compare search key with root element.',
      '   a. If key == root->data, return node found.',
      '   b. If key < root->data, recursively search left subtree.',
      '   c. If key > root->data, recursively search right subtree.',
      '2. If pointer reaches NULL, return NULL (key not present).',
      'Algorithm for Insertion in BST:',
      '1. If root is NULL, allocate new node and return as root.',
      '2. If key < root->data, root->left = insert(root->left, key).',
      '3. If key > root->data, root->right = insert(root->right, key).',
      '4. Return root.'
    ],
    procedure: [
      'Step 1: Open the BST Simulator below.',
      'Step 2: Enter a number (e.g. 65) into the input box and click "Insert".',
      'Step 3: Watch the algorithm branch: compare with 50 (go right), compare with 70 (go left), compare with 60 (go right) and insert.',
      'Step 4: Test searching for existing key (60) and non-existent key (25).'
    ],
    code: {
      c: `#include <stdio.h>
#include <stdlib.h>

struct Node {
    int key;
    struct Node *left, *right;
};

struct Node* newNode(int item) {
    struct Node* temp = (struct Node*)malloc(sizeof(struct Node));
    temp->key = item;
    temp->left = temp->right = NULL;
    return temp;
}

struct Node* insert(struct Node* node, int key) {
    if (node == NULL) return newNode(key);
    if (key < node->key) node->left = insert(node->left, key);
    else if (key > node->key) node->right = insert(node->right, key);
    return node;
}

struct Node* search(struct Node* root, int key) {
    if (root == NULL || root->key == key) return root;
    if (key < root->key) return search(root->left, key);
    return search(root->right, key);
}

void inorder(struct Node* root) {
    if (root != NULL) {
        inorder(root->left);
        printf("%d ", root->key);
        inorder(root->right);
    }
}

int main() {
    struct Node* root = NULL;
    root = insert(root, 50);
    insert(root, 30);
    insert(root, 20);
    insert(root, 40);
    insert(root, 70);
    insert(root, 60);
    insert(root, 80);

    printf("BST Inorder: ");
    inorder(root);
    printf("\\n");

    int key = 60;
    struct Node* found = search(root, key);
    if (found) printf("Key %d found in BST!\\n", key);
    else printf("Key %d not found!\\n", key);
    return 0;
}`,
      python: `class Node:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None

def insert(root, key):
    if root is None:
        return Node(key)
    if key < root.key:
        root.left = insert(root.left, key)
    elif key > root.key:
        root.right = insert(root.right, key)
    return root

def search(root, key):
    if root is None or root.key == key:
        return root
    if key < root.key:
        return search(root.left, key)
    return search(root.right, key)`
    },
    sampleInput: 'Insert: 50, 30, 20, 40, 70, 60, 80. Search: 60',
    expectedOutput: `BST Inorder: 20 30 40 50 60 70 80 
Key 60 found in BST!`,
    references: [
      'Aaron M. Tenenbaum, Yedidyah Langsam, Moshe J. Augenstein, "Data Structures Using C", Pearson Publication.',
      'Reema Thareja, "Data Structures using C", Oxford University Press.',
      'Mark Allen Weiss, "Data Structures and Algorithm Analysis in C", Pearson Education.'
    ],
    conclusion: 'The experiment successfully implemented a BST using linked lists, demonstrating insertion, search, and traversal. It reinforced understanding of recursion, self-referential structures, and tree-based data organization.',
    quiz: [
      {
        id: 1,
        question: 'Which node replaces a deleted node that has two children in a BST?',
        options: ['Root node', 'Inorder successor or predecessor', 'First leaf found', 'Left child directly'],
        correctAnswer: 1,
        explanation: 'A node with two children is replaced by either its inorder successor (minimum in right subtree) or inorder predecessor (maximum in left subtree) to maintain BST invariants.'
      }
    ]
  },

  // =========================================================================
  // EXPERIMENT 7: Implement Graph Traversal techniques: DFS & BFS
  // =========================================================================
  {
    id: 'graph-traversals-dfs-bfs',
    num: 7,
    subjectId: 'dsa',
    title: 'Implement Graph Traversal techniques: Depth First Search & Breadth First Search',
    subtitle: 'Graph Representations (Matrix/List), BFS Level-Order & DFS Depth-First Exploration',
    category: 'Graph Algorithms',
    iitReference: 'Autonomous Curriculum Standards / KJSIT AIL302 Data Structure and Algorithms Lab',
    iitLabUrl: 'https://vlab.co.in/data-structures-1/',
    aim: 'Implement Graph Traversal techniques: a) Depth First Search b) Breadth First Search.',
    objective: 'Explore the concept of Graph Traversal techniques and write C code to implement Graph Traversal techniques.',
    software: 'GCC / Turbo C / Online C Compiler',
    postLabQuestions: [
      {
        question: 'Compare BFS and DFS in terms of data structures used, space complexity, and typical applications.',
        answer: 'BFS uses a Queue and visits nodes level by level (breadth-first), ideal for finding the shortest path in unweighted graphs. DFS uses a Stack (or recursion) to explore as deep as possible before backtracking, ideal for cycle detection and topological sorting.'
      },
      {
        question: 'Which traversal algorithm is best suited for finding the shortest path in an unweighted graph, and why?',
        answer: 'BFS is guaranteed to find the shortest path in unweighted graphs because it explores all vertices at distance k before any vertex at distance k+1.'
      },
      {
        question: 'What is the time complexity of BFS and DFS when implemented using an Adjacency Matrix vs an Adjacency List?',
        answer: 'With an Adjacency Matrix, both require O(V^2) time to scan all V row entries for each node. With an Adjacency List, both require O(V + E) time, which is much faster for sparse graphs.'
      },
      {
        question: 'How can DFS be used to detect a cycle in a directed graph?',
        answer: 'By tracking nodes in the current recursion call stack (using an active recursion array `inStack[]`). If an adjacent node is already visited and is currently in the call stack (back-edge), a cycle exists.'
      }
    ],
    theory: {
      overview: [
        'A graph is a non-linear data structure consisting of a set of vertices (V) and edges (E). It can be represented in two standard ways: 1. Adjacency Matrix Representation: A 2D array of size V x V where each cell (i, j) is 1 if there is an edge from vertex i to j, otherwise 0. Simple but requires O(V^2) space. 2. Adjacency List Representation: An array of linked lists where each vertex points to a list of its adjacent vertices. Saves memory for sparse graphs and requires O(V + E) space.',
        'Graph Traversal: 1. Breadth First Search (BFS): Visits all neighbors first (level-order traversal). Uses Queue data structure. 2. Depth First Search (DFS): Explores as deep as possible before backtracking. Uses Recursion or Stack.',
        'Sample 5-Node Graph (A, B, C, D, E) Representation from Manual: Adjacency Matrix: A: [0,1,1,1,0], B: [1,0,0,0,0], C: [1,0,0,0,0], D: [1,0,0,0,1], E: [0,0,0,1,0]. Adjacency List: A -> B -> C -> D, B -> A, C -> A, D -> A -> E, E -> D.',
        'BFS explores vertices level-by-level using a FIFO queue to guarantee the shortest path in unweighted graphs. DFS plunges deep along each branch until dead ends are reached, using recursion or an explicit stack to backtrack.'
      ],
      complexityTable: [
        { parameter: 'BFS Time (Adjacency Matrix)', value: 'O(V^2)' },
        { parameter: 'BFS Time (Adjacency List)', value: 'O(V + E)' },
        { parameter: 'DFS Time (Adjacency Matrix)', value: 'O(V^2)' },
        { parameter: 'DFS Time (Adjacency List)', value: 'O(V + E)' },
        { parameter: 'Space (Adjacency Matrix)', value: 'O(V^2)' },
        { parameter: 'Space (Adjacency List)', value: 'O(V + E)' }
      ],
      keyPoints: [
        'Adjacency Matrix: V x V 2D array, fast O(1) edge lookup, high O(V^2) memory footprint.',
        'Adjacency List: Array of linked lists, optimal memory O(V + E) for sparse graphs.',
        'BFS (Breadth First): Level-order traversal using a Queue data structure.',
        'DFS (Depth First): Deep branch exploration before backtracking using Recursion or a Stack.',
        'Visited Array: Tracks visited vertices to prevent infinite cycles in cyclic graphs.'
      ],
      realWorldApplications: [
        'BFS: Shortest path finding in unweighted graphs and GPS navigation networks.',
        'DFS: Cycle detection, topological sorting, and solving maze pathfinding.',
        'Social network connection analysis (degrees of separation) and web crawling.'
      ]
    },
    algorithm: [
      'Algorithm BFS(Graph G, start_vertex):',
      '1. Create an empty queue Q.',
      '2. Mark all vertices as unvisited.',
      '3. Mark start_vertex as visited and Enqueue(start_vertex, Q).',
      '4. While Q is not empty do:',
      '   a. vertex = Dequeue(Q). Print vertex.',
      '   b. For each adjacent_node in Adj[vertex] do:',
      '      If adjacent_node is not visited then:',
      '         Mark adjacent_node as visited; Enqueue(adjacent_node, Q).',
      'Algorithm DFS(Graph G, start_vertex):',
      '1. Mark all vertices as unvisited.',
      '2. Call Recursive_DFS(start_vertex):',
      '   Procedure Recursive_DFS(vertex):',
      '      a. Mark vertex as visited. Print vertex.',
      '      b. For each adjacent_node in Adj[vertex] do:',
      '         If adjacent_node is not visited then Recursive_DFS(adjacent_node).'
    ],
    procedure: [
      'Step 1: Open the Graph Traversal Simulator below.',
      'Step 2: View the 5-node graph from the manual (A, B, C, D, E).',
      'Step 3: Click "Run BFS" to observe queue operations and level-by-level color transitions.',
      'Step 4: Click "Run DFS" to observe depth exploration along branches and backtracking.'
    ],
    code: {
      c: `#include <stdio.h>
#include <stdlib.h>

#define MAX 10

int adj[MAX][MAX];
int visited[MAX];
int n = 5; // 5 vertices: 0=A, 1=B, 2=C, 3=D, 4=E

void bfs(int start) {
    int queue[MAX], front = 0, rear = 0;
    for (int i = 0; i < n; i++) visited[i] = 0;

    visited[start] = 1;
    queue[rear++] = start;

    printf("BFS Order: ");
    while (front < rear) {
        int u = queue[front++];
        printf("%c ", 'A' + u);

        for (int v = 0; v < n; v++) {
            if (adj[u][v] && !visited[v]) {
                visited[v] = 1;
                queue[rear++] = v;
            }
        }
    }
    printf("\\n");
}

void dfs(int u) {
    visited[u] = 1;
    printf("%c ", 'A' + u);
    for (int v = 0; v < n; v++) {
        if (adj[u][v] && !visited[v]) {
            dfs(v);
        }
    }
}

int main() {
    // Sample Graph from KJSIT manual:
    // A-B, A-C, A-D, D-E
    adj[0][1] = adj[1][0] = 1;
    adj[0][2] = adj[2][0] = 1;
    adj[0][3] = adj[3][0] = 1;
    adj[3][4] = adj[4][3] = 1;

    bfs(0);

    for (int i = 0; i < n; i++) visited[i] = 0;
    printf("DFS Order: ");
    dfs(0);
    printf("\\n");
    return 0;
}`,
      python: `from collections import deque

def bfs(graph, start):
    visited = set([start])
    queue = deque([start])
    order = []
    while queue:
        u = queue.popleft()
        order.append(u)
        for v in graph[u]:
            if v not in visited:
                visited.add(v)
                queue.append(v)
    return order

def dfs(graph, start, visited=None):
    if visited is None: visited = set()
    visited.add(start)
    order = [start]
    for v in graph[start]:
        if v not in visited:
            order.extend(dfs(graph, v, visited))
    return order`
    },
    sampleInput: 'Graph: A-(B,C,D), D-E. Start: A',
    expectedOutput: `BFS Order: A B C D E 
DFS Order: A B C D E `,
    references: [
      'Aaron M. Tenenbaum, Yedidyah Langsam, Moshe J. Augenstein, "Data Structures Using C", Pearson Publication.',
      'Reema Thareja, "Data Structures Using C", Oxford University Press.',
      'Seymour Lipschutz, "Data Structures with C", Schaum\'s Outlines, McGraw Hill.',
      'Narasimha Karumanchi, "Data Structures and Algorithms Made Easy", CareerMonk Publications.'
    ],
    conclusion: 'Graphs can be represented using Adjacency Matrix or Adjacency List. Both BFS and DFS were successfully implemented: BFS is ideal for shortest paths in unweighted graphs; DFS is ideal for connectivity and cycle detection.',
    quiz: [
      {
        id: 1,
        question: 'Which data structure is fundamentally employed in Breadth First Search (BFS)?',
        options: ['Stack', 'Queue', 'Binary Heap', 'Hash Table'],
        correctAnswer: 1,
        explanation: 'BFS uses a FIFO Queue to discover and visit vertices in order of their increasing distance from the starting node.'
      }
    ]
  },

  // =========================================================================
  // EXPERIMENT 8: Implement any Application of Sorting Algorithms
  // =========================================================================
  {
    id: 'sorting-algorithms-application',
    num: 8,
    subjectId: 'dsa',
    title: 'Implement any Application of Sorting Algorithms',
    subtitle: 'Bubble, Selection, Insertion, Merge, Quick Sort for Real-World Problem Domains',
    category: 'Sorting & Searching',
    iitReference: 'Autonomous Curriculum Standards / KJSIT AIL302 Data Structure and Algorithms Lab',
    iitLabUrl: 'https://vlab.co.in/data-structures-1/',
    aim: 'Implement any Application of Sorting Algorithms.',
    objective: 'Explore the concept of sorting and its algorithm; develop a program that reads a list of numerical values (marks, salaries, or prices) and sorts them using a chosen sorting algorithm.',
    software: 'GCC / Turbo C / Online C Compiler',
    postLabQuestions: [
      {
        question: 'What is the difference between a stable and an unstable sorting algorithm? Give examples of each.',
        answer: 'A stable sorting algorithm preserves the relative input order of records with equal keys (e.g. Merge Sort, Insertion Sort, Bubble Sort). An unstable sorting algorithm may reorder equal keys (e.g. Quick Sort, Selection Sort, Heap Sort).'
      },
      {
        question: 'Under what condition does Insertion Sort achieve O(n) time complexity?',
        answer: 'When the input array is already sorted or nearly sorted, each element requires only one comparison with its immediate left predecessor, completing in linear O(n) time.'
      },
      {
        question: 'When would you choose Merge Sort over Quick Sort despite Merge Sort requiring O(n) auxiliary space?',
        answer: 'Merge Sort is preferred when a strict worst-case O(n log n) guarantee is required (e.g. real-time medical systems), for external sorting of large files on disk, or when sorting linked lists where no auxiliary array is needed.'
      },
      {
        question: 'How does sorting improve the efficiency of searching in large datasets?',
        answer: 'Sorting transforms an unstructured list (which requires O(n) linear search) into an ordered dataset that supports O(log n) Binary Search or Interpolation Search.'
      }
    ],
    theory: {
      overview: [
        'Problem Statement: Develop a program that reads a list of numerical values (e.g., marks, salaries, or prices) and sorts them using any one sorting algorithm chosen by the student. The sorted result should be displayed as output.',
        'Theory of Sorting: Sorting is the process of arranging elements in a specific order (ascending or descending). It is a fundamental operation in computer science used in data organization, searching, and optimization.',
        'Common Sorting Algorithms (Table 1 from Lab Manual): 1. Bubble Sort (Array, Best: O(n), Worst: O(n^2), Comparison-based), 2. Selection Sort (Array, Best: O(n^2), Worst: O(n^2), Comparison-based), 3. Insertion Sort (Array, Best: O(n), Worst: O(n^2), Adaptive), 4. Merge Sort (Array, Best: O(n log n), Worst: O(n log n), Divide & Conquer), 5. Quick Sort (Array, Best: O(n log n), Worst: O(n^2), Divide & Conquer).',
        'Applications of Sorting: 1. Arranging student results by marks, 2. Organizing products by price in an e-commerce system, 3. Ranking players or participants by score, 4. Preparing datasets for binary search.'
      ],
      complexityTable: [
        { parameter: 'Bubble Sort (Comparison-based)', value: 'Data Structure: Array | Best: O(n) | Worst: O(n^2)' },
        { parameter: 'Selection Sort (Comparison-based)', value: 'Data Structure: Array | Best: O(n^2) | Worst: O(n^2)' },
        { parameter: 'Insertion Sort (Adaptive)', value: 'Data Structure: Array | Best: O(n) | Worst: O(n^2)' },
        { parameter: 'Merge Sort (Divide & Conquer)', value: 'Data Structure: Array | Best: O(n log n) | Worst: O(n log n)' },
        { parameter: 'Quick Sort (Divide & Conquer)', value: 'Data Structure: Array | Best: O(n log n) | Worst: O(n^2)' }
      ],
      keyPoints: [
        'Fundamental Operation: Arranging elements into ascending or descending sequence for searching and optimization.',
        'Comparison vs Divide & Conquer: Bubble/Selection/Insertion compare adjacent/selected items; Merge/Quick recursively divide.',
        'Adaptive Nature: Insertion sort detects pre-sorted arrays to complete in O(n) linear time.',
        'Divide & Conquer Scaling: Merge sort guarantees O(n log n) worst-case performance on large numerical datasets.'
      ],
      realWorldApplications: [
        'Arranging student results by marks.',
        'Organizing products by price in an e-commerce system.',
        'Ranking players or participants by score.',
        'Preparing datasets for binary search.'
      ]
    },
    algorithm: [
      'Generic Application Sorting Algorithm:',
      '1. Start.',
      '2. Input the number of elements N and the numerical values (e.g., marks/salaries/prices).',
      '3. Choose a sorting algorithm (Bubble, Selection, Insertion, Merge, Quick).',
      '4. Apply the algorithm to sort the list in ascending order.',
      '5. Display the sorted list and computation metrics.',
      '6. Stop.'
    ],
    procedure: [
      'Step 1: Open the Sorting Application Simulator below.',
      'Step 2: Select a domain dataset (Student Marks, Employee Salaries, or Product Prices).',
      'Step 3: Select an algorithm (Bubble Sort, Selection Sort, or Insertion Sort).',
      'Step 4: Click "Execute Sort" to watch the animated bar comparisons and real-time swap/shift counters.',
      'Step 5: Review the official Table 1 algorithm comparison matrix.'
    ],
    code: {
      c: `#include <stdio.h>

// Application: Sorting Student Marks using Bubble Sort
void bubbleSortMarks(float marks[], int n) {
    for (int i = 0; i < n - 1; i++) {
        int swapped = 0;
        for (int j = 0; j < n - i - 1; j++) {
            if (marks[j] > marks[j + 1]) {
                float temp = marks[j];
                marks[j] = marks[j + 1];
                marks[j + 1] = temp;
                swapped = 1;
            }
        }
        if (!swapped) break; // Optimized adaptive pass
    }
}

int main() {
    float marks[] = {78.5, 45.0, 92.0, 88.5, 64.0, 55.5, 98.0, 71.0};
    int n = sizeof(marks) / sizeof(marks[0]);

    printf("Unsorted Student Marks:\\n");
    for (int i = 0; i < n; i++) printf("%.1f ", marks[i]);
    printf("\\n\\n");

    bubbleSortMarks(marks, n);

    printf("Sorted Student Marks (Ascending Merit List):\\n");
    for (int i = 0; i < n; i++) printf("%.1f ", marks[i]);
    printf("\\n");
    return 0;
}`,
      python: `def sort_application_dataset(records, algo='bubble'):
    arr = list(records)
    n = len(arr)
    if algo == 'bubble':
        for i in range(n - 1):
            for j in range(n - i - 1):
                if arr[j] > arr[j + 1]:
                    arr[j], arr[j + 1] = arr[j + 1], arr[j]
    elif algo == 'selection':
        for i in range(n - 1):
            min_idx = i
            for j in range(i + 1, n):
                if arr[j] < arr[min_idx]:
                    min_idx = j
            arr[i], arr[min_idx] = arr[min_idx], arr[i]
    return arr`
    },
    sampleInput: 'Student Marks: 78.5, 45.0, 92.0, 88.5, 64.0, 55.5, 98.0, 71.0',
    expectedOutput: `Unsorted Student Marks:
78.5 45.0 92.0 88.5 64.0 55.5 98.0 71.0 

Sorted Student Marks (Ascending Merit List):
45.0 55.5 64.0 71.0 78.5 88.5 92.0 98.0 `,
    references: [
      'Aaron M. Tenenbaum, Yedidyah Langsam, Moshe J. Augenstein, "Data Structures Using C", Pearson Publication.',
      'Reema Thareja, "Data Structures Using C", Oxford University Press.',
      'Seymour Lipschutz, "Data Structures with C", Schaum\'s Outlines, McGraw Hill.',
      'Mark Allen Weiss, "Data Structures and Algorithm Analysis in C", Pearson Education.'
    ],
    conclusion: 'Sorting algorithms help organize and process real-world domain records efficiently. Different algorithms can be chosen depending on input distribution, stability needs, and memory bounds.',
    quiz: [
      {
        id: 1,
        question: 'Which sorting algorithm has a guaranteed worst-case time complexity of O(n log n)?',
        options: ['Bubble Sort', 'Quick Sort', 'Merge Sort', 'Selection Sort'],
        correctAnswer: 2,
        explanation: 'Merge Sort consistently divides the array into halves and merges in linear time, guaranteeing O(n log n) in all cases.'
      }
    ]
  }
];
