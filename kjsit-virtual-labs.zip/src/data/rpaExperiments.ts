import { LabExperiment } from '../types';

export const RPA_EXPERIMENTS: LabExperiment[] = [
  {
    id: 'rpa-exp1',
    num: 1,
    subjectId: 'rpa',
    title: 'RPA Workflow Architectures: Sequence & Flowchart Bots',
    subtitle: 'Activity Lifecycles, Variable Scopes, Argument Direction (In/Out) & Logging',
    category: 'Bot Design & Architecture',
    iitReference: 'Autonomous Curriculum Standards / Robotic Process Automation Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/rpa-lab/',
    aim: 'To design, simulate, and execute deterministic RPA workflows utilizing Sequence, Flowchart, and State Machine constructs with strict variable scoping and error logging.',
    theory: {
      overview: [
        'Robotic Process Automation (RPA) uses software robots ("bots") to emulate human interactions with digital applications to execute rule-based repetitive business processes.',
        'Sequence: Linear step-by-step workflow suited for straightforward procedural tasks.',
        'Flowchart: Non-linear branching workflow with decision nodes, loops, and parallel paths for complex decision logic.',
        'State Machine: Event-driven architecture with defined States, Transitions, and Exit actions (standard in the UiPath Robotic Enterprise Framework - REFramework).',
        'Variables & Arguments: Variables store local process state; Arguments pass data across modular workflows (Direction: In, Out, In/Out).'
      ],
      complexityTable: [
        { parameter: 'Bot Execution Latency', value: 'Deterministic sub-second step transitions' },
        { parameter: 'Audit Logging', value: 'O(1) streaming structured JSON execution telemetry' }
      ],
      keyPoints: [
        'Unattended Bots: Run autonomously on scheduled servers without human intervention.',
        'Attended Bots: Triggered by and work alongside human operators on desktop sessions.'
      ],
      realWorldApplications: [
        'Automated accounts payable invoice reconciliation against enterprise ERPs (SAP, Oracle).',
        'Employee onboarding account provisioning across Active Directory and HR portals.'
      ]
    },
    algorithm: [
      '1. Define workflow entry point and initialize configuration dictionary (Config.xlsx).',
      '2. Instantiate variables: in_TransactionItem, io_TransactionNumber, out_Status.',
      '3. In Sequence container, execute sequential activities: LogMessage("Starting Task"), Assign, ReadRange.',
      '4. In Flowchart container, evaluate FlowDecision condition: if TransactionCount > 0 proceed to ProcessTransaction; else EndProcess.',
      '5. Capture execution exceptions in TryCatch block and append audit trail.',
      '6. Output final robot status report.'
    ],
    procedure: [
      '1. Open RPA Workflow Simulator.',
      '2. Drag and connect Sequence and Flowchart activities onto the visual canvas.',
      '3. Configure variable bindings and condition branches.',
      '4. Click "Execute Bot" to observe real-time step execution highlighting and debug logs.',
      '5. Inspect execution metrics (Duration, Success Rate, Steps Completed).'
    ],
    code: {
      python: `import time
import logging

logging.basicConfig(level=logging.INFO, format="[%(asctime)s] [%(levelname)s] %(message)s")

class SequenceBot:
    def __init__(self, bot_name: str):
        self.name = bot_name
        self.context = {}

    def log(self, activity: str, status: str):
        logging.info(f"Bot '{self.name}' -> Activity: {activity} | Status: {status}")

    def execute_workflow(self, input_data: dict):
        self.log("InitAllSettings", "SUCCESS")
        self.context["config"] = {"Timeout": 30, "MaxRetry": 3}
        
        self.log("GetTransactionData", "SUCCESS")
        transactions = input_data.get("items", [])
        
        for idx, item in enumerate(transactions, start=1):
            try:
                self.log(f"ProcessTransaction #{idx} ({item['id']})", "RUNNING")
                time.sleep(0.1) # Simulate task execution
                self.log(f"ProcessTransaction #{idx}", "SUCCESS")
            except Exception as e:
                self.log(f"ProcessTransaction #{idx}", f"FAILED: {str(e)}")
        
        self.log("CloseAllApplications", "COMPLETED")
        return {"status": "COMPLETED", "processed": len(transactions)}`
    },
    sampleInput: 'Input Transaction Batch: 5 Invoice IDs [INV-101 .. INV-105]',
    expectedOutput: 'All 5 transactions processed in Sequence workflow; Audit logs recorded with 0 errors.',
    references: ['Alok Mani Tripathi, Learning Robotic Process Automation, Packt Publishing'],
    conclusion: 'RPA workflow orchestration successfully executed deterministic rule-based steps with full structured telemetry.',
    quiz: [
      {
        id: 1,
        question: 'What is the primary architectural advantage of the State Machine workflow over a simple Sequence in enterprise RPA?',
        options: [
          'It provides a robust event-driven framework with defined States and Transitions, ideal for handling complex transaction retries and global error recovery (REFramework)',
          'It requires no variables',
          'It runs without electricity',
          'It only supports Python scripts'
        ],
        correctAnswer: 0,
        explanation: 'State machines allow bots to transition smoothly between Initialization, Get Transaction, Process, and End states with built-in retry and error handling.'
      }
    ]
  },
  {
    id: 'rpa-exp2',
    num: 2,
    subjectId: 'rpa',
    title: 'UI Automation, Dynamic Selectors & Fuzzy Matching',
    subtitle: 'DOM Selectors, Wildcards (*, ?), Anchor Base & Computer Vision Fallbacks',
    category: 'UI Automation',
    iitReference: 'Autonomous Curriculum Standards / Robotic Process Automation Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/rpa-lab/',
    aim: 'To build robust UI automation bots capable of locating and interacting with volatile web and desktop UI elements using dynamic selectors, wildcards, and anchor base targeting.',
    theory: {
      overview: [
        'UI Automation interacts with application interfaces by inspecting the underlying visual tree hierarchy (Active Accessibility, UI Automation, DOM HTML).',
        'A Selector is an XML fragment specifying the path from application root to target UI element: e.g., `<html app="chrome.exe"/><webctrl id="submit-btn" tag="BUTTON"/>`.',
        'Volatile Elements: Elements with dynamically generated IDs (e.g. `id="btn_482910"`) break static selectors. Resolved using Wildcards (`*` for multiple characters, `?` for single character) or Regex.',
        'Anchor Base: Couples a volatile target input field with a nearby reliable anchor element (e.g. "Customer Email:" label).',
        'Fuzzy Selectors: Use Levenshtein distance matching to locate elements despite minor attribute changes.'
      ],
      complexityTable: [
        { parameter: 'Selector Evaluation Time', value: 'O(log N) UI tree search traversal' },
        { parameter: 'Fuzzy Match Fallback', value: 'O(M * K) string distance calculation across sibling candidates' }
      ],
      keyPoints: [
        'Full Selectors contain window parent info; Partial Selectors omit parent when nested inside container activities.',
        'Strictness: Selectors must be unique (targeting exactly 1 element) yet robust against cosmetic UI updates.'
      ],
      realWorldApplications: [
        'Automated CRM customer record entry into legacy web forms.',
        'Web data extraction and multi-page pagination scrapers.'
      ]
    },
    algorithm: [
      '1. Inspect target UI elements using the UI Explorer tree tool.',
      '2. Identify unstable dynamic attributes (session IDs, timestamp indices).',
      '3. Replace volatile substrings with wildcard asterisks: `<webctrl id="btn_order_*" tag="BUTTON"/>`.',
      '4. Bind Anchor Base activity: find fixed label "Invoice Total:" as anchor and attach Right-adjacent Input Box.',
      '5. Configure Click and TypeInto activities with SimulateType / SendWindowMessages flags for background execution.',
      '6. Execute bot and verify accurate click and typing without screen focus requirements.'
    ],
    procedure: [
      '1. Open Dynamic Selector Simulator.',
      '2. Examine synthetic dynamic form where element IDs mutate on every refresh.',
      '3. Construct a wildcard selector string.',
      '4. Test selector validation indicator (Green = Valid, Red = Not Found).',
      '5. Run bot to fill and submit the dynamic form automatically.'
    ],
    code: {
      python: `import re

class SelectorEngine:
    @staticmethod
    def match_selector(element_attrs: dict, selector_rules: dict) -> bool:
        for attr, pattern in selector_rules.items():
            if attr not in element_attrs:
                return False
            # Convert wildcard * to regex .*
            regex_pattern = "^" + pattern.replace("*", ".*").replace("?", ".") + "$"
            if not re.match(regex_pattern, str(element_attrs[attr])):
                return False
        return True

# Test Dynamic Element
dom_element = {"tag": "INPUT", "id": "txt_amount_84920", "class": "form-control"}
selector = {"tag": "INPUT", "id": "txt_amount_*"}

print("Selector Matched:", SelectorEngine.match_selector(dom_element, selector))`
    },
    sampleInput: 'Target Input Field with dynamic ID: "usr_email_938129"',
    expectedOutput: 'Wildcard selector `<webctrl id="usr_email_*" tag="INPUT"/>` validated and targeted successfully.',
    references: ['Frank Casale, Introduction to Robotic Process Automation, The Institute for Robotic Process Automation'],
    conclusion: 'Dynamic wildcard selectors and anchor base targeting prevented bot failures on volatile dynamic user interfaces.',
    quiz: [
      {
        id: 1,
        question: 'Which wildcard character in RPA selectors matches zero or more arbitrary characters?',
        options: ['Asterisk (*)', 'Question Mark (?)', 'Ampersand (&)', 'Hash (#)'],
        correctAnswer: 0,
        explanation: 'The asterisk (*) wildcard matches zero or more characters in RPA selector attributes, making it ideal for dynamic IDs.'
      }
    ]
  },
  {
    id: 'rpa-exp3',
    num: 3,
    subjectId: 'rpa',
    title: 'Excel & Data Table Automation Pipeline',
    subtitle: 'Spreadsheet Manipulation, LINQ Filtering, Data Scraping & Automated Reporting',
    category: 'Data Automation',
    iitReference: 'Autonomous Curriculum Standards / Robotic Process Automation Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/rpa-lab/',
    aim: 'To extract tabular records from spreadsheets, execute in-memory filtering and transformations via LINQ/DataTable queries, and generate automated executive summary reports.',
    theory: {
      overview: [
        'Data Tables in RPA represent in-memory two-dimensional tables with rows and typed columns.',
        'Excel Automation integrates via Excel Application Scope (requires desktop Excel) or Workbook Activities (runs in background without Excel installed).',
        'LINQ (Language Integrated Query) enables declarative in-memory filtering, grouping, and aggregation across thousands of rows in milliseconds.',
        'Data Scraping extracts structured data from multi-page web tables directly into a DataTable variable.'
      ],
      complexityTable: [
        { parameter: 'LINQ Query Filter', value: 'O(N) single-pass in-memory stream filtering' },
        { parameter: 'Workbook Read/Write', value: 'O(N * C) disk buffer serialization' }
      ],
      keyPoints: [
        'Filtering rows in memory before writing back to Excel is 100x faster than cell-by-cell row iteration.',
        'Always close and release Excel workbook streams upon completion.'
      ],
      realWorldApplications: [
        'Monthly vendor balance sheet reconciliation across disparate bank statements.',
        'Sales pipeline summary aggregation generating automated executive email PDFs.'
      ]
    },
    algorithm: [
      '1. Read source spreadsheet into DataTable dt_Employees using ReadRange.',
      '2. Apply in-memory filter: Department = "Engineering" AND PerformanceRating >= 4.',
      '3. Calculate summary metrics: Average Salary, Total Headcount, Bonus Pool.',
      '4. Add new calculated column "BonusAmount" = Salary * 0.15.',
      '5. Write transformed DataTable to Report_Summary.xlsx using WriteRange.',
      '6. Trigger automated email activity with report attachment.'
    ],
    procedure: [
      '1. Open Excel RPA Workbench.',
      '2. Upload or inspect 1,000-row employee payroll spreadsheet.',
      '3. Construct LINQ query filter condition.',
      '4. Run bot and observe instant in-memory transformation.',
      '5. Download generated report and verify calculations.'
    ],
    code: {
      python: `import pandas as pd

def process_payroll_rpa(input_file: str, output_file: str):
    # Read Workbook Range
    df = pd.read_csv(input_file)
    
    # In-memory transformation & filtering (Analogous to RPA LINQ)
    filtered = df[(df['Department'] == 'AI & DS') & (df['Rating'] >= 4)].copy()
    filtered['Bonus'] = filtered['Salary'] * 0.15
    
    summary = {
        "Total_Candidates": len(filtered),
        "Total_Bonus_Disbursed": filtered['Bonus'].sum(),
        "Avg_Salary": filtered['Salary'].mean()
    }
    
    filtered.to_csv(output_file, index=False)
    return summary`
    },
    sampleInput: '1,000-row Payroll Sheet: Filter Dept="AI & DS" and Rating >= 4',
    expectedOutput: 'Filtered 142 records; Total bonus calculated ₹21,30,000; Output report saved.',
    references: ['Srikanth Merianda, Robotic Process Automation with Blue Prism Quick Start Guide, Packt'],
    conclusion: 'In-memory DataTable automation processed 1,000 records in sub-second time with zero manual intervention.',
    quiz: [
      {
        id: 1,
        question: 'What is the primary advantage of Workbook activities over Excel Application Scope in RPA?',
        options: [
          'Workbook activities do not require Microsoft Excel to be installed on the machine and execute rapidly in the background',
          'Workbook activities only support text files',
          'Workbook activities require double the RAM',
          'Workbook activities cannot read numbers'
        ],
        correctAnswer: 0,
        explanation: 'Workbook activities manipulate raw .xlsx file packages directly in the background without needing Microsoft Excel installed or launched.'
      }
    ]
  }
];
