import { LabExperiment } from '../types';

export const ANN_EXPERIMENTS: LabExperiment[] = [
  {
    id: 'ann-exp1',
    num: 1,
    subjectId: 'ann',
    title: 'McCulloch-Pitts Neuron & Hebbian Learning',
    subtitle: 'Binary Threshold Units, Logic Gates (AND, OR, NOT) & Synaptic Plasticity',
    category: 'Foundational Neural Models',
    iitReference: 'Autonomous Curriculum Standards / Neural Networks Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/ann-lab/',
    aim: 'To design and evaluate the McCulloch-Pitts (M-P) neuron model for linearly separable Boolean logic functions and simulate Hebbian unsupervised synaptic weight adaptation.',
    theory: {
      overview: [
        'The McCulloch-Pitts neuron (1943) is the earliest mathematical abstraction of a biological neuron. It operates with binary inputs and outputs (0 or 1), excitatory and inhibitory inputs, and a predefined threshold θ.',
        'Net input z = Σ w_i * x_i. The output y = 1 if z >= θ, else 0. If any inhibitory input is active, the neuron is inhibited (output = 0).',
        'Hebbian Learning Rule (1949): "Neurons that fire together, wire together." Synaptic weight increases when pre-synaptic and post-synaptic neurons fire concurrently: Δw_i = η * x_i * y.'
      ],
      complexityTable: [
        { parameter: 'Inference Time', value: 'O(d) dot product where d is input dimensionality' },
        { parameter: 'Learning Update', value: 'O(d) constant vector addition' }
      ],
      keyPoints: [
        'M-P neurons have fixed analytical weights and thresholds (no iterative training algorithm).',
        'Cannot solve non-linearly separable functions like XOR without intermediate hidden layers.'
      ],
      realWorldApplications: [
        'Neuromorphic spike-based edge computing chips (Intel Loihi, IBM TrueNorth).',
        'Associative memory models and hardware logic gates.'
      ]
    },
    algorithm: [
      '1. For Boolean logic AND gate: set excitatory weights w1 = 1, w2 = 1, threshold θ = 2.',
      '2. For Boolean logic OR gate: set excitatory weights w1 = 1, w2 = 1, threshold θ = 1.',
      '3. For Boolean logic NOT gate: set inhibitory weight w1 on negation input with threshold θ = 0.',
      '4. Evaluate net input net = w1*x1 + w2*x2 for all input combinations (00, 01, 10, 11).',
      '5. Verify output y matches truth table output.',
      '6. Implement Hebbian learning update rule Δw = η * x * y on training vectors.'
    ],
    procedure: [
      '1. Open M-P Neuron Simulator.',
      '2. Select Logic Gate: AND, OR, NAND, NOR.',
      '3. Adjust Synaptic Weights (w1, w2) and Threshold θ slider.',
      '4. Toggle inputs x1 and x2 and observe neuron activation firing status.',
      '5. Switch to Hebbian tab to observe continuous weight reinforcement.'
    ],
    code: {
      python: `import numpy as np

class McCullochPittsNeuron:
    def __init__(self, weights, threshold, has_inhibitory=False):
        self.weights = np.array(weights)
        self.threshold = threshold
        self.has_inhibitory = has_inhibitory

    def activate(self, inputs, inhibitory_active=False):
        if self.has_inhibitory and inhibitory_active:
            return 0
        net = np.dot(inputs, self.weights)
        return 1 if net >= self.threshold else 0

# AND Gate configuration
mp_and = McCullochPittsNeuron(weights=[1, 1], threshold=2)
# OR Gate configuration
mp_or = McCullochPittsNeuron(weights=[1, 1], threshold=1)

print("AND(0, 1):", mp_and.activate([0, 1]))
print("AND(1, 1):", mp_and.activate([1, 1]))
print("OR(0, 1):", mp_or.activate([0, 1]))`,
      cpp: `// C++ M-P neuron implementation`
    },
    sampleInput: 'Inputs: [(0,0), (0,1), (1,0), (1,1)] to AND neuron (w=[1,1], θ=2)',
    expectedOutput: 'Outputs: [0, 0, 0, 1] successfully reproducing Boolean AND.',
    references: ['Warren McCulloch and Walter Pitts (1943), A Logical Calculus of the Ideas Immanent in Nervous Activity'],
    conclusion: 'McCulloch-Pitts neuron accurately represented fundamental linearly separable logic functions.',
    quiz: [
      {
        id: 1,
        question: 'Why can a single McCulloch-Pitts neuron or Single-Layer Perceptron NOT solve the XOR problem?',
        options: [
          'Because XOR is not linearly separable and cannot be separated by a single hyperplane in 2D space',
          'Because threshold θ cannot be negative',
          'Because binary weights cannot exceed 10',
          'Because M-P neurons cannot process zero inputs'
        ],
        correctAnswer: 0,
        explanation: 'XOR outputs 1 for (0,1) and (1,0), and 0 for (0,0) and (1,1). No single straight line (hyperplane) can separate the 1s from the 0s in 2D Euclidean space.'
      }
    ]
  },
  {
    id: 'ann-exp2',
    num: 2,
    subjectId: 'ann',
    title: 'Multi-Layer Perceptron (MLP) & Error Backpropagation',
    subtitle: 'Gradient Descent, Chain Rule, Hidden Layers & Non-Linear Decision Boundaries',
    category: 'Feedforward Architectures',
    iitReference: 'Autonomous Curriculum Standards / Neural Networks Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/ann-lab/',
    aim: 'To implement a Multi-Layer Perceptron (MLP) from scratch with Forward Propagation and Backpropagation using the gradient descent chain rule to solve the non-linear XOR problem.',
    theory: {
      overview: [
        'A Multi-Layer Perceptron (MLP) consists of an input layer, one or more hidden layers with non-linear activation functions, and an output layer.',
        'Universal Approximation Theorem: An MLP with a single hidden layer containing sufficient non-linear neurons can approximate any continuous function.',
        'Backpropagation computes the gradient of the loss function E with respect to each weight w_ij using the calculus chain rule: ∂E/∂w_ij = (∂E/∂y) * (∂y/∂z) * (∂z/∂w_ij).',
        'Weights are updated in the direction of steepest descent: w_new = w_old - η * ∇E.'
      ],
      complexityTable: [
        { parameter: 'Forward Pass Complexity', value: 'O(Σ N_l * N_{l+1}) matrix-vector multiplications' },
        { parameter: 'Backward Pass Complexity', value: 'O(Σ N_l * N_{l+1}) exact transpose gradient multiplications' }
      ],
      keyPoints: [
        'Hidden layer non-linearity (e.g. Sigmoid, ReLU) transforms the coordinate space, making XOR linearly separable at the output.',
        'Learning rate η controls step size; too large causes divergence, too small causes slow convergence.'
      ],
      realWorldApplications: [
        'Handwritten digit recognition (MNIST benchmark).',
        'Credit risk assessment and multi-class tabular classification.'
      ]
    },
    algorithm: [
      '1. Initialize weights W1 (2x2), b1 (2x1), W2 (1x2), b2 (1x1) with small random values.',
      '2. Forward Pass: compute hidden layer activations Z1 = W1*X + b1, A1 = Sigmoid(Z1).',
      '3. Compute output activation Z2 = W2*A1 + b2, A2 = Sigmoid(Z2).',
      '4. Compute Mean Squared Error (MSE) loss E = 0.5 * (Y - A2)^2.',
      '5. Backward Pass: compute output error delta2 = (A2 - Y) * A2 * (1 - A2).',
      '6. Compute hidden layer error delta1 = (W2^T * delta2) * A1 * (1 - A1).',
      '7. Update weights: W2 = W2 - η * (delta2 * A1^T), W1 = W1 - η * (delta1 * X^T).',
      '8. Iterate for 5,000 epochs until loss converges below 0.005.'
    ],
    procedure: [
      '1. Open the Interactive MLP Neural Network Playground.',
      '2. Select XOR Dataset.',
      '3. Set 2 hidden neurons, Learning Rate = 0.5, Sigmoid Activation.',
      '4. Click "Train Network" and watch the decision boundary contour bend to isolate XOR points.',
      '5. Observe loss curve smoothly descending to 0.'
    ],
    code: {
      python: `import numpy as np

def sigmoid(x): return 1 / (1 + np.exp(-x))
def d_sigmoid(x): return x * (1 - x)

# XOR Dataset
X = np.array([[0,0], [0,1], [1,0], [1,1]])
y = np.array([[0], [1], [1], [0]])

np.random.seed(42)
W1 = np.random.uniform(-1, 1, (2, 2))
b1 = np.zeros((1, 2))
W2 = np.random.uniform(-1, 1, (2, 1))
b2 = np.zeros((1, 1))
lr = 0.5

for epoch in range(10000):
    # Forward Pass
    a1 = sigmoid(np.dot(X, W1) + b1)
    a2 = sigmoid(np.dot(a1, W2) + b2)
    
    # Backpropagation
    error = a2 - y
    d2 = error * d_sigmoid(a2)
    d1 = np.dot(d2, W2.T) * d_sigmoid(a1)
    
    # Weight Updates
    W2 -= lr * np.dot(a1.T, d2)
    b2 -= lr * np.sum(d2, axis=0, keepdims=True)
    W1 -= lr * np.dot(X.T, d1)
    b1 -= lr * np.sum(d1, axis=0, keepdims=True)

print("Trained XOR Predictions:")
print(np.round(a2, 3))`
    },
    sampleInput: 'XOR truth table: (0,0)->0, (0,1)->1, (1,0)->1, (1,1)->0',
    expectedOutput: 'Trained Predictions: [[0.012], [0.985], [0.984], [0.018]] with Loss < 0.001.',
    references: ['David Rumelhart, Geoffrey Hinton, and Ronald Williams (1986), Learning representations by back-propagating errors, Nature'],
    conclusion: 'Error backpropagation in a 2-2-1 MLP resolved the classical XOR parity limitation by synthesizing non-linear decision regions.',
    quiz: [
      {
        id: 1,
        question: 'What mathematical principle enables backpropagation to calculate error gradients across multiple hidden layers?',
        options: [
          'The differential calculus Chain Rule',
          'Bayes Theorem',
          'L\'Hopital\'s Rule',
          'Pythagorean Theorem'
        ],
        correctAnswer: 0,
        explanation: 'The calculus chain rule allows the derivative of the composite loss function to be computed layer-by-layer backwards from output to input.'
      }
    ]
  },
  {
    id: 'ann-exp3',
    num: 3,
    subjectId: 'ann',
    title: 'Activation Functions & Vanishing Gradient Analysis',
    subtitle: 'Sigmoid, Tanh, ReLU, Leaky ReLU, Softmax & Gradient Flow Profiles',
    category: 'Network Optimization',
    iitReference: 'Autonomous Curriculum Standards / Neural Networks Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/ann-lab/',
    aim: 'To implement and compare mathematical activation functions (Sigmoid, Tanh, ReLU, Leaky ReLU, Softmax) and analyze the vanishing gradient problem in deep networks.',
    theory: {
      overview: [
        'Activation functions introduce non-linearity into neural networks, enabling them to learn arbitrary complex representations.',
        'Sigmoid σ(z) = 1 / (1 + e^-z): S-shaped curve mapping to (0, 1). Its derivative maxes out at 0.25, causing vanishing gradients in deep networks.',
        'Tanh tanh(z) = (e^z - e^-z) / (e^z + e^-z): Zero-centered mapping to (-1, 1). Derivative maxes out at 1.0.',
        'Rectified Linear Unit (ReLU) f(z) = max(0, z): Solves vanishing gradient for positive values (derivative = 1), but suffers from "Dying ReLU" when activations become strictly negative.',
        'Softmax σ(z)_i = e^{z_i} / Σ e^{z_j}: Normalizes vector into a probability distribution summing to 1.0.'
      ],
      complexityTable: [
        { parameter: 'ReLU Evaluation', value: 'O(1) simple threshold comparison' },
        { parameter: 'Sigmoid / Tanh Evaluation', value: 'O(1) with transcendental exp() calculation' },
        { parameter: 'Softmax Vector Evaluation', value: 'O(d) across entire class vector' }
      ],
      keyPoints: [
        'Vanishing Gradient: In deep networks with saturating activations, repeated multiplication of small derivatives (< 0.25) drives early layer gradients to zero.',
        'Exploding Gradient: Uncontrolled large weights compound exponentially, resolved using Gradient Clipping.'
      ],
      realWorldApplications: [
        'Deep Convolutional and Transformer networks (GELU, Swish, ReLU activations).',
        'Multi-class categorization output heads (Softmax).'
      ]
    },
    algorithm: [
      '1. Implement forward mathematical functions: Sigmoid, Tanh, ReLU, Leaky ReLU, Softmax.',
      '2. Implement respective first-order analytical derivatives.',
      '3. Simulate an 8-layer deep MLP with random weights.',
      '4. Propagate gradients backwards from layer 8 down to layer 1.',
      '5. Compare gradient magnitude at Layer 1 using Sigmoid vs ReLU.',
      '6. Plot gradient decay curve across layer depth.'
    ],
    procedure: [
      '1. Open Activation Function Analyzer.',
      '2. Switch between Sigmoid, Tanh, ReLU, and Softmax.',
      '3. Inspect function curves and corresponding derivative graphs.',
      '4. Run the 10-layer Vanishing Gradient visualizer to observe gradient signal extinction.'
    ],
    code: {
      python: `import numpy as np

def sigmoid(z): return 1 / (1 + np.exp(-np.clip(z, -500, 500)))
def d_sigmoid(z): s = sigmoid(z); return s * (1 - s)

def tanh(z): return np.tanh(z)
def d_tanh(z): return 1 - np.tanh(z)**2

def relu(z): return np.maximum(0, z)
def d_relu(z): return (z > 0).astype(float)

def leaky_relu(z, alpha=0.01): return np.where(z > 0, z, alpha * z)

def softmax(z):
    e = np.exp(z - np.max(z, axis=-1, keepdims=True))
    return e / np.sum(e, axis=-1, keepdims=True)`
    },
    sampleInput: 'Input z = [-3, -1, 0, 1, 3] through Sigmoid, Tanh, and ReLU',
    expectedOutput: 'ReLU derivative constant 1.0 for positive inputs, preventing gradient extinction.',
    references: ['Alex Krizhevsky, Ilya Sutskever, and Geoffrey Hinton (2012), ImageNet Classification with Deep Convolutional Neural Networks'],
    conclusion: 'ReLU activation preserved steady unit gradient flow across deep architectures, effectively resolving vanishing gradients.',
    quiz: [
      {
        id: 1,
        question: 'Why does ReLU mitigate the vanishing gradient problem compared to the Sigmoid activation function?',
        options: [
          'Because its derivative is constant 1 for any positive input, preventing gradient attenuation during backpropagation',
          'Because ReLU outputs negative numbers',
          'Because ReLU requires complex exponential operations',
          'Because ReLU normalizes the sum to 1'
        ],
        correctAnswer: 0,
        explanation: 'For all positive inputs (z > 0), the derivative of ReLU is exactly 1. Multiplying by 1 across multiple layers prevents gradients from shrinking exponentially.'
      }
    ]
  }
];
