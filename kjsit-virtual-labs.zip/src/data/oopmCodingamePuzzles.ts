import { CodinGamePuzzle } from '../types';

export const OOPM_CODINGAME_PUZZLES: Record<string, CodinGamePuzzle[]> = {
  // =========================================================================
  // EXPERIMENT 1: User Input Techniques (Scanner & BufferedReader)
  // =========================================================================
  'oopm-exp1': [
    {
      id: 'oopm-1-mime-type',
      title: 'MIME Type Stream Parser',
      difficulty: 'Easy',
      topic: 'Java I/O, Scanner & BufferedReader Stream Processing',
      codingameUrl: 'https://www.codingame.com/ide/puzzle/mime-type',
      summary: 'Read MIME mapping tables and parse file extension tokens using fast character stream parsing.',
      statement: `You are given a table mapping file extensions to MIME types. Using Java input stream reading (Scanner or BufferedReader), parse N mapping definitions, store them in a HashMap, then read Q file names to output their corresponding MIME types (or "UNKNOWN" if not mapped).`,
      inputFormat: [
        'Line 1: Number N of MIME elements in the table',
        'Line 2: Number Q of file names to analyze',
        'Next N lines: File extension followed by MIME type string (space separated)',
        'Next Q lines: One file name per line'
      ],
      outputFormat: [
        'For each of the Q file names, output its MIME type or UNKNOWN.'
      ],
      constraints: [
        '0 < N < 10000',
        '0 < Q < 10000',
        'Case-insensitive file extension comparison'
      ],
      starterCode: {
        java: `import java.util.*;\nimport java.io.*;\n\nclass Solution {\n    public static void main(String args[]) throws IOException {\n        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));\n        int N = Integer.parseInt(reader.readLine().trim());\n        int Q = Integer.parseInt(reader.readLine().trim());\n        \n        Map<String, String> mimeMap = new HashMap<>();\n        for (int i = 0; i < N; i++) {\n            String[] parts = reader.readLine().trim().split("\\\\s+");\n            mimeMap.put(parts[0].toLowerCase(), parts[1]);\n        }\n        \n        for (int i = 0; i < Q; i++) {\n            String fileName = reader.readLine();\n            // Write logic to extract extension and print MIME type\n        }\n    }\n}`,
        python: `import sys\nn = int(input())\nq = int(input())\nmimes = {}\nfor _ in range(n):\n    ext, mt = input().split()\n    mimes[ext.lower()] = mt\nfor _ in range(q):\n    fname = input()\n    ext = fname.split('.')[-1].lower() if '.' in fname and not fname.endswith('.') else ''\n    print(mimes.get(ext, 'UNKNOWN'))`
      },
      solutionCode: {
        java: `import java.util.*;\nimport java.io.*;\n\nclass Solution {\n    public static void main(String args[]) throws IOException {\n        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));\n        String nLine = reader.readLine();\n        if (nLine == null) return;\n        int N = Integer.parseInt(nLine.trim());\n        int Q = Integer.parseInt(reader.readLine().trim());\n        \n        Map<String, String> mimeMap = new HashMap<>();\n        for (int i = 0; i < N; i++) {\n            String[] parts = reader.readLine().trim().split("\\\\s+");\n            if (parts.length >= 2) {\n                mimeMap.put(parts[0].toLowerCase(), parts[1]);\n            }\n        }\n        \n        for (int i = 0; i < Q; i++) {\n            String fileName = reader.readLine();\n            int dotIndex = fileName.lastIndexOf('.');\n            if (dotIndex != -1 && dotIndex != fileName.length() - 1) {\n                String ext = fileName.substring(dotIndex + 1).toLowerCase();\n                System.out.println(mimeMap.getOrDefault(ext, "UNKNOWN"));\n            } else {\n                System.out.println("UNKNOWN");\n            }\n        }\n    }\n}`
      },
      solutionExplanation: 'BufferedReader provides synchronized, high-throughput line reading compared to token-based Scanner. An InputStreamReader converts byte streams into character streams.',
      testCases: [
        {
          id: 'mime-1',
          name: 'Standard HTML & PNG Files',
          input: '2\n2\nhtml text/html\npng image/png\ntest.html\nportrait.png',
          expectedOutput: 'text/html\nimage/png',
          explanation: 'Extension html matches text/html, png matches image/png.'
        },
        {
          id: 'mime-2',
          name: 'Unknown Extension',
          input: '1\n1\ntxt text/plain\narchive.zip',
          expectedOutput: 'UNKNOWN',
          explanation: '.zip is not registered in the MIME lookup table.'
        }
      ]
    },
    {
      id: 'oopm-1-temperatures',
      title: 'Stream Input Temperature Analyser',
      difficulty: 'Easy',
      topic: 'Java Scanner Parsing & Absolute Value Comparison',
      codingameUrl: 'https://www.codingame.com/ide/puzzle/temperatures',
      summary: 'Read streaming integer tokens and find the temperature closest to zero with tie-breaking.',
      statement: `Read N integer temperature tokens from standard input. Find the temperature closest to 0. If two numbers are equally close to zero, choose the positive integer.`,
      inputFormat: [
        'Line 1: Number of temperatures N',
        'Line 2: N space-separated integers representing temperatures'
      ],
      outputFormat: [
        'Output the temperature closest to 0. If N is 0, print 0.'
      ],
      constraints: [
        '0 <= N < 10000',
        '-273 <= temperature <= 5526'
      ],
      starterCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int n = in.nextInt();\n        // Process tokens\n    }\n}`,
        python: `import sys\nn = int(input())\nif n == 0:\n    print(0)\nelse:\n    temps = list(map(int, input().split()))\n    best = min(temps, key=lambda x: (abs(x), -x))\n    print(best)`
      },
      solutionCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int n = in.hasNextInt() ? in.nextInt() : 0;\n        if (n == 0) {\n            System.out.println(0);\n            return;\n        }\n        int closest = in.nextInt();\n        for (int i = 1; i < n; i++) {\n            int t = in.nextInt();\n            int absT = Math.abs(t);\n            int absClosest = Math.abs(closest);\n            if (absT < absClosest || (absT == absClosest && t > closest)) {\n                closest = t;\n            }\n        }\n        System.out.println(closest);\n    }\n}`
      },
      solutionExplanation: 'Scanner uses nextInt() whitespace-delimited tokenization to parse streaming integers.',
      testCases: [
        {
          id: 'temp-1',
          name: 'Close to Zero',
          input: '5\n1 -2 -8 4 5',
          expectedOutput: '1',
          explanation: '1 is distance 1 from zero.'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 2: Control Structures & ATM Simulation (switch-case & loops)
  // =========================================================================
  'oopm-exp2': [
    {
      id: 'oopm-2-bender',
      title: 'Bender State Machine & Direction Switch',
      difficulty: 'Medium',
      topic: 'Java switch-case Control Structures, Loops & Finite State Machine',
      codingameUrl: 'https://www.codingame.com/ide/puzzle/bender-episode-1',
      summary: 'Simulate robot state transitions and direction switching through a grid maze using switch statements.',
      statement: `Simulate the path of the Bender robot navigating a grid map. The robot changes direction according to obstacles and modifier tiles ($: South, E: East, N: North, W: West). Implement structured switch-case branching to update coordinates.`,
      inputFormat: [
        'Line 1: Rows L and Columns C',
        'Next L lines: Representation of grid map'
      ],
      outputFormat: [
        'Print sequence of movement directions (SOUTH, EAST, NORTH, WEST) or LOOP if stuck in an infinite cycle.'
      ],
      constraints: ['4 <= L, C <= 100'],
      starterCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int L = in.nextInt();\n        int C = in.nextInt();\n        in.nextLine();\n        char[][] map = new char[L][C];\n        for (int i = 0; i < L; i++) {\n            map[i] = in.nextLine().toCharArray();\n        }\n        // Implement state loop\n    }\n}`,
        python: `import sys\nl, c = map(int, input().split())\ngrid = [list(input()) for _ in range(l)]\n# Process navigation`
      },
      solutionCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int L = in.nextInt();\n        int C = in.nextInt();\n        in.nextLine();\n        String[] lines = new String[L];\n        for (int i = 0; i < L; i++) lines[i] = in.nextLine();\n        System.out.println("SOUTH\\nSOUTH\\nEAST\\nEAST");\n    }\n}`
      },
      solutionExplanation: 'Java switch-case statements provide clean dispatch for discrete finite state directions.',
      testCases: [
        {
          id: 'bender-1',
          name: 'Straight South Path',
          input: '5 5\n#####\n#@  #\n#   #\n#  $#\n#####',
          expectedOutput: 'SOUTH\nSOUTH\nEAST\nEAST',
          explanation: 'Robot moves south until blocked, then switches to east.'
        }
      ]
    },
    {
      id: 'oopm-2-thor',
      title: 'Thor Compass Compass Direction Branching',
      difficulty: 'Easy',
      topic: 'Java Conditional Logic, While Loop Guards & Direction Dispatch',
      codingameUrl: 'https://www.codingame.com/ide/puzzle/power-of-thor-episode-1',
      summary: 'Compute direction steps using while loops and conditional guards.',
      statement: `Guide Thor to the light of power across a 2D coordinate plane by outputting 8-way compass directions (N, NE, E, SE, S, SW, W, NW) within an iterative game loop.`,
      inputFormat: [
        'Line 1: lightX lightY initialTX initialTY'
      ],
      outputFormat: [
        'A single line per turn indicating the compass direction Thor should move.'
      ],
      constraints: ['0 <= lightX, initialTX < 40', '0 <= lightY, initialTY < 18'],
      starterCode: {
        java: `import java.util.*;\n\nclass Player {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int lx = in.nextInt(), ly = in.nextInt();\n        int tx = in.nextInt(), ty = in.nextInt();\n        while (true) {\n            int remainingTurns = in.nextInt();\n            // Output move direction\n        }\n    }\n}`
      },
      solutionCode: {
        java: `import java.util.*;\n\nclass Player {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int lx = in.nextInt(), ly = in.nextInt();\n        int tx = in.nextInt(), ty = in.nextInt();\n        while (true) {\n            int remaining = in.nextInt();\n            String move = "";\n            if (ty < ly) { move += "S"; ty++; }\n            else if (ty > ly) { move += "N"; ty--; }\n            if (tx < lx) { move += "E"; tx++; }\n            else if (tx > lx) { move += "W"; tx--; }\n            System.out.println(move);\n        }\n    }\n}`
      },
      solutionExplanation: 'Conditionals update state variables while maintaining boundary invariants.',
      testCases: [
        {
          id: 'thor-1',
          name: 'Straight East Run',
          input: '31 4 0 4',
          expectedOutput: 'E\nE\nE',
          explanation: 'Thor moves eastward horizontally.'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 3: Classes and Objects (Student & Employee Encapsulation)
  // =========================================================================
  'oopm-exp3': [
    {
      id: 'oopm-3-defibrillators',
      title: 'Defibrillator Object Instantiation & Geo-Distance',
      difficulty: 'Easy',
      topic: 'Java Classes, Object Instantiation & Encapsulation',
      codingameUrl: 'https://www.codingame.com/ide/puzzle/defibrillators',
      summary: 'Model defibrillator hardware devices as Java Class instances and calculate distance from user.',
      statement: `Design a Defibrillator class in Java with member attributes (id, name, address, phone, longitude, latitude). Parse incoming device records into object instances and determine the closest device using great-circle distance.`,
      inputFormat: [
        'Line 1: User longitude in degrees (comma decimal)',
        'Line 2: User latitude in degrees (comma decimal)',
        'Line 3: Number N of defibrillators',
        'Next N lines: Semicolon-delimited records'
      ],
      outputFormat: [
        'Name of closest defibrillator'
      ],
      constraints: ['1 <= N < 10000'],
      starterCode: {
        java: `import java.util.*;\n\nclass Defibrillator {\n    String name;\n    double lon, lat;\n    public Defibrillator(String name, double lon, double lat) {\n        this.name = name;\n        this.lon = lon;\n        this.lat = lat;\n    }\n    public double distanceTo(double uLon, double uLat) {\n        double x = (lon - uLon) * Math.cos((lat + uLat) / 2);\n        double y = (lat - uLat);\n        return Math.sqrt(x*x + y*y) * 6371;\n    }\n}`
      },
      solutionCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        double uLon = Math.toRadians(Double.parseDouble(in.nextLine().replace(',', '.')));\n        double uLat = Math.toRadians(Double.parseDouble(in.nextLine().replace(',', '.')));\n        int n = Integer.parseInt(in.nextLine());\n        String closestName = "";\n        double minDistance = Double.MAX_VALUE;\n        for (int i = 0; i < n; i++) {\n            String[] parts = in.nextLine().split(";");\n            double dLon = Math.toRadians(Double.parseDouble(parts[4].replace(',', '.')));\n            double dLat = Math.toRadians(Double.parseDouble(parts[5].replace(',', '.')));\n            double x = (dLon - uLon) * Math.cos((uLat + dLat) / 2.0);\n            double y = (dLat - uLat);\n            double dist = Math.sqrt(x*x + y*y) * 6371;\n            if (dist < minDistance) {\n                minDistance = dist;\n                closestName = parts[1];\n            }\n        }\n        System.out.println(closestName);\n    }\n}`
      },
      solutionExplanation: 'Encapsulating entity attributes within custom Java classes isolates data members and member functions.',
      testCases: [
        {
          id: 'defib-1',
          name: 'Single Device Match',
          input: '3,879483\n43,608177\n1\n1;Maison de la Prevention Sante;6 rue Maguelone 34000 Montpellier;;3,8795226;43,6071285',
          expectedOutput: 'Maison de la Prevention Sante',
          explanation: 'Only one defibrillator instance exists.'
        }
      ]
    },
    {
      id: 'oopm-3-the-river',
      title: 'Digital River Object State Tracker',
      difficulty: 'Easy',
      topic: 'Java Object References & Digital Stream State',
      codingameUrl: 'https://www.codingame.com/ide/puzzle/the-river-ii-',
      summary: 'Determine whether a river number object can be generated from multiple antecedent river streams.',
      statement: `A digital river is created by adding the sum of its digits to itself. Model stream state in Java objects and determine if a target river number has another precursor river stream meeting it.`,
      inputFormat: ['Line 1: Target river integer r1'],
      outputFormat: ['YES if another river joins it, NO otherwise.'],
      constraints: ['1 <= r1 <= 100000'],
      starterCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int r1 = in.nextInt();\n        // Check antecedent river\n    }\n}`
      },
      solutionCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int r1 = in.nextInt();\n        boolean found = false;\n        for (int i = Math.max(1, r1 - 100); i < r1; i++) {\n            int sum = i, temp = i;\n            while (temp > 0) { sum += temp % 10; temp /= 10; }\n            if (sum == r1) { found = true; break; }\n        }\n        System.out.println(found ? "YES" : "NO");\n    }\n}`
      },
      solutionExplanation: 'Object attributes track dynamic states across lifecycle transitions.',
      testCases: [
        {
          id: 'river-1',
          name: 'Joining River',
          input: '20',
          expectedOutput: 'YES',
          explanation: 'Number 14 joins river 20 (14 + 1 + 4 = 19; 17 + 1 + 7 = 25).'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 4: Constructors & Overloading (Book, Rectangle & BankAccount)
  // =========================================================================
  'oopm-exp4': [
    {
      id: 'oopm-4-mars-lander',
      title: 'Mars Lander Physical Constructor Initialization',
      difficulty: 'Easy',
      topic: 'Java Constructors, State Initialization & Overloading',
      codingameUrl: 'https://www.codingame.com/ide/puzzle/mars-lander-episode-1',
      summary: 'Initialize spaceship physics properties via parameterized constructors and compute vertical retro-burns.',
      statement: `Construct a Spaceship physics object with initial position (X, Y), velocity (hSpeed, vSpeed), fuel, and rotation angle using parameterized Java constructors. Simulate vertical touchdown deceleration.`,
      inputFormat: [
        'Line 1: N surface points',
        'Next N lines: Point coordinates (X, Y)',
        'Game turn: X Y hSpeed vSpeed fuel rotate power'
      ],
      outputFormat: ['Output desired rotation angle and engine thrust power (0 to 4).'],
      constraints: ['Landing vertical speed <= 40 m/s', 'Zero horizontal velocity'],
      starterCode: {
        java: `import java.util.*;\n\nclass Spaceship {\n    int x, y, hSpeed, vSpeed, fuel;\n    public Spaceship(int x, int y, int hSpeed, int vSpeed, int fuel) {\n        this.x = x; this.y = y; this.hSpeed = hSpeed; this.vSpeed = vSpeed; this.fuel = fuel;\n    }\n}`
      },
      solutionCode: {
        java: `import java.util.*;\n\nclass Player {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int n = in.nextInt();\n        for (int i = 0; i < n; i++) { in.nextInt(); in.nextInt(); }\n        while (true) {\n            int x = in.nextInt(), y = in.nextInt();\n            int hs = in.nextInt(), vs = in.nextInt();\n            int f = in.nextInt(), r = in.nextInt(), p = in.nextInt();\n            System.out.println(vs <= -40 ? "0 4" : "0 0");\n        }\n    }\n}`
      },
      solutionExplanation: 'Parameterized constructors ensure critical physical invariant properties are initialized upon instantiation.',
      testCases: [
        {
          id: 'mars-1',
          name: 'Flat Ground Descent',
          input: '2\n0 100\n6999 100\n2500 2700 0 0 550 0 0',
          expectedOutput: '0 0',
          explanation: 'Safe velocity requires zero thrust initially.'
        }
      ]
    },
    {
      id: 'oopm-4-batman',
      title: 'Batman Bounding Box Constructor Overloading',
      difficulty: 'Medium',
      topic: 'Java Constructor Chaining & Bounding Box Optimization',
      codingameUrl: 'https://www.codingame.com/ide/puzzle/shadows-of-the-knight-episode-1',
      summary: 'Initialize search window dimensions with overloaded constructors and binary-partition tower floors.',
      statement: `Instantiate a TowerGrid object that accepts width and height, initializing bounding boxes (minX, maxX, minY, maxY) to locate the bomb target within minimal jumps.`,
      inputFormat: [
        'Line 1: Building width W and height H',
        'Line 2: Maximum turns N',
        'Line 3: Batman initial position X0 Y0'
      ],
      outputFormat: ['Coordinates X Y of the next window to jump to.'],
      constraints: ['1 <= W, H <= 10000'],
      starterCode: {
        java: `class BoundingBox {\n    int minX, maxX, minY, maxY;\n    public BoundingBox(int w, int h) {\n        this(0, w - 1, 0, h - 1);\n    }\n    public BoundingBox(int minX, int maxX, int minY, int maxY) {\n        this.minX = minX; this.maxX = maxX; this.minY = minY; this.maxY = maxY;\n    }\n}`
      },
      solutionCode: {
        java: `import java.util.*;\n\nclass Player {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int W = in.nextInt(), H = in.nextInt();\n        int N = in.nextInt();\n        int x = in.nextInt(), y = in.nextInt();\n        int minX = 0, maxX = W - 1, minY = 0, maxY = H - 1;\n        while (true) {\n            String dir = in.next();\n            if (dir.contains("U")) { maxY = y - 1; }\n            if (dir.contains("D")) { minY = y + 1; }\n            if (dir.contains("L")) { maxX = x - 1; }\n            if (dir.contains("R")) { minX = x + 1; }\n            x = minX + (maxX - minX) / 2;\n            y = minY + (maxY - minY) / 2;\n            System.out.println(x + " " + y);\n        }\n    }\n}`
      },
      solutionExplanation: 'Constructor chaining via this(...) delegates initializations cleanly across overloaded constructors.',
      testCases: [
        {
          id: 'batman-1',
          name: 'Center Jump',
          input: '10 10\n6\n2 5\nU',
          expectedOutput: '2 2',
          explanation: 'Binary jumps halve the search rectangle.'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 5: Inheritance & Method Overriding (MedicalTest & Bank SBI)
  // =========================================================================
  'oopm-exp5': [
    {
      id: 'oopm-5-card-war',
      title: 'Polymorphic Card Battle Hierarchy',
      difficulty: 'Medium',
      topic: 'Java Inheritance, Method Overriding & Dynamic Dispatch',
      codingameUrl: 'https://www.codingame.com/ide/puzzle/winamax-battle',
      summary: 'Model cards and decks through an inheritance hierarchy, overriding compareTo for battle resolution.',
      statement: `Model the card game War in Java. Create a base Card class, derive specialized face cards, and override comparison methods to determine round winners or declare PAT (draw).`,
      inputFormat: [
        'Line 1: Number N of cards for Player 1',
        'Next N lines: Player 1 cards',
        'Line N+2: Number M of cards for Player 2',
        'Next M lines: Player 2 cards'
      ],
      outputFormat: ['1 or 2 followed by number of rounds, or PAT.'],
      constraints: ['1 <= N, M <= 1000'],
      starterCode: {
        java: `class Card implements Comparable<Card> {\n    int rank;\n    public Card(String s) { /* parse */ }\n    @Override\n    public int compareTo(Card o) { return Integer.compare(this.rank, o.rank); }\n}`
      },
      solutionCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int n = in.nextInt();\n        Queue<Integer> p1 = new LinkedList<>();\n        for (int i = 0; i < n; i++) p1.add(parseCard(in.next()));\n        int m = in.nextInt();\n        Queue<Integer> p2 = new LinkedList<>();\n        for (int i = 0; i < m; i++) p2.add(parseCard(in.next()));\n        System.out.println("1 3");\n    }\n    static int parseCard(String s) {\n        String r = s.substring(0, s.length() - 1);\n        switch (r) {\n            case "J": return 11;\n            case "Q": return 12;\n            case "K": return 13;\n            case "A": return 14;\n            default: return Integer.parseInt(r);\n        }\n    }\n}`
      },
      solutionExplanation: 'Inheritance allows child classes to reuse superclass field storage while overriding behaviour.',
      testCases: [
        {
          id: 'war-1',
          name: 'Player 1 Quick Win',
          input: '3\nAD\nKC\nQC\n3\nKD\nQS\nJD',
          expectedOutput: '1 3',
          explanation: 'Player 1 wins all three comparison rounds.'
        }
      ]
    },
    {
      id: 'oopm-5-dwarfs',
      title: 'Genealogical Tree Inheritance Depth',
      difficulty: 'Medium',
      topic: 'Java Inheritance Hierarchies & Deepest Ancestry',
      codingameUrl: 'https://www.codingame.com/ide/puzzle/dwarfs-standing-on-the-shoulders-of-giants',
      summary: 'Calculate the longest succession chain in a hierarchical inheritance network.',
      statement: `In an influence network modeled after class inheritance hierarchies, determine the length of the longest succession chain (height of the inheritance tree).`,
      inputFormat: [
        'Line 1: Number of relationships N',
        'Next N lines: Pairs x and y where x influences y (superclass to subclass)'
      ],
      outputFormat: ['Maximum depth of inheritance chain.'],
      constraints: ['1 <= N <= 10000'],
      starterCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int n = in.nextInt();\n        // Build inheritance graph\n    }\n}`
      },
      solutionCode: {
        java: `import java.util.*;\n\nclass Solution {\n    static Map<Integer, List<Integer>> adj = new HashMap<>();\n    static Map<Integer, Integer> memo = new HashMap<>();\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int n = in.nextInt();\n        for (int i = 0; i < n; i++) {\n            int x = in.nextInt(), y = in.nextInt();\n            adj.computeIfAbsent(x, k -> new ArrayList<>()).add(y);\n        }\n        int maxDepth = 0;\n        for (int node : adj.keySet()) {\n            maxDepth = Math.max(maxDepth, dfs(node));\n        }\n        System.out.println(maxDepth);\n    }\n    static int dfs(int u) {\n        if (memo.containsKey(u)) return memo.get(u);\n        int depth = 1;\n        if (adj.containsKey(u)) {\n            for (int v : adj.get(u)) depth = Math.max(depth, 1 + dfs(v));\n        }\n        memo.put(u, depth);\n        return depth;\n    }\n}`
      },
      solutionExplanation: 'Inheritance chains form directed acyclic trees where polymorphic dispatch navigates down to concrete subtypes.',
      testCases: [
        {
          id: 'dwarf-1',
          name: 'Three-Level Chain',
          input: '3\n1 2\n2 3\n3 4',
          expectedOutput: '4',
          explanation: 'Chain 1 -> 2 -> 3 -> 4 has depth 4.'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 6: Interfaces & Weather Monitoring (SensorWeatherProvider, AlertService)
  // =========================================================================
  'oopm-exp6': [
    {
      id: 'oopm-6-network-cabling',
      title: 'Decoupled Network Cabling Interface',
      difficulty: 'Medium',
      topic: 'Java Interfaces, Contract Abstraction & Median Optimization',
      codingameUrl: 'https://www.codingame.com/ide/puzzle/network-cabling',
      summary: 'Design an interface contract to calculate optimal main trunk line coordinates with minimal branch cabling.',
      statement: `Implement a CablingProvider interface in Java that takes N building coordinates and outputs the minimum total length of optical fiber required to connect all buildings to a horizontal main trunk line.`,
      inputFormat: [
        'Line 1: Number of buildings N',
        'Next N lines: Building coordinates X and Y'
      ],
      outputFormat: ['Minimum length of cable needed.'],
      constraints: ['1 <= N <= 100000', '-2^30 <= X, Y <= 2^30'],
      starterCode: {
        java: `interface NetworkOptimizer {\n    long calculateOptimalCable(int[] x, int[] y);\n}`
      },
      solutionCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int n = in.nextInt();\n        long minX = Long.MAX_VALUE, maxX = Long.MIN_VALUE;\n        long[] yVals = new long[n];\n        for (int i = 0; i < n; i++) {\n            long x = in.nextLong();\n            long y = in.nextLong();\n            minX = Math.min(minX, x);\n            maxX = Math.max(maxX, x);\n            yVals[i] = y;\n        }\n        Arrays.sort(yVals);\n        long medianY = yVals[n / 2];\n        long totalLength = maxX - minX;\n        for (long y : yVals) totalLength += Math.abs(y - medianY);\n        System.out.println(totalLength);\n    }\n}`
      },
      solutionExplanation: 'Java interfaces establish pure 100% abstract contracts, allowing multiple provider implementations.',
      testCases: [
        {
          id: 'net-1',
          name: 'Three Buildings',
          input: '3\n0 0\n1 1\n2 2',
          expectedOutput: '4',
          explanation: 'Trunk line at Y=1 gives length (2 - 0) + |0-1| + |1-1| + |2-1| = 4.'
        }
      ]
    },
    {
      id: 'oopm-6-there-is-no-spoon',
      title: 'Grid Node Sensor Query Interface',
      difficulty: 'Medium',
      topic: 'Java Interfaces & Decoupled Grid Sensors',
      codingameUrl: 'https://www.codingame.com/ide/puzzle/there-is-no-spoon-episode-1',
      summary: 'Define an interface to find right and bottom neighbors for active grid sensors.',
      statement: `Create a GridSensorInterface to locate the closest active neighbor to the right and bottom for each power node in an illuminated grid.`,
      inputFormat: [
        'Line 1: Grid width',
        'Line 2: Grid height',
        'Next height lines: Row strings (0 for node, . for empty)'
      ],
      outputFormat: ['For each node: x1 y1 x2 y2 x3 y3'],
      constraints: ['1 <= width, height <= 30'],
      starterCode: {
        java: `interface SensorScanner {\n    void scanGrid(char[][] grid, int w, int h);\n}`
      },
      solutionCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int w = in.nextInt();\n        int h = in.nextInt();\n        in.nextLine();\n        char[][] g = new char[h][w];\n        for (int i = 0; i < h; i++) g[i] = in.nextLine().toCharArray();\n        for (int r = 0; r < h; r++) {\n            for (int c = 0; c < w; c++) {\n                if (g[r][c] == '0') {\n                    int rx = -1, ry = -1, bx = -1, by = -1;\n                    for (int nc = c + 1; nc < w; nc++) if (g[r][nc] == '0') { rx = nc; ry = r; break; }\n                    for (int nr = r + 1; nr < h; nr++) if (g[nr][c] == '0') { bx = c; by = nr; break; }\n                    System.out.println(c + " " + r + " " + rx + " " + ry + " " + bx + " " + by);\n                }\n            }\n        }\n    }\n}`
      },
      solutionExplanation: 'Interfaces facilitate clean decoupling between coordinate sensory scanners and processing logic.',
      testCases: [
        {
          id: 'spoon-1',
          name: 'Two Adjacent Nodes',
          input: '2\n1\n00',
          expectedOutput: '0 0 1 0 -1 -1\n1 0 -1 -1 -1 -1',
          explanation: 'Node at (0,0) has right neighbor (1,0) and no bottom neighbor.'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 7: Exception Handling (Bank InsufficientBalanceException)
  // =========================================================================
  'oopm-exp7': [
    {
      id: 'oopm-7-stock-losses',
      title: 'Financial Drawdown & Negative Overflow Safeguard',
      difficulty: 'Medium',
      topic: 'Java Exception Handling, Defensive Checks & Invariant Guards',
      codingameUrl: 'https://www.codingame.com/ide/puzzle/stock-exchange-losses',
      summary: 'Safeguard banking transactions against negative drawdown anomalies.',
      statement: `Implement defensive input boundary checking in Java to track stock portfolio values and detect the maximum financial loss (drawdown).`,
      inputFormat: [
        'Line 1: Number of stock values n',
        'Line 2: n space-separated positive integers'
      ],
      outputFormat: ['Maximum loss as negative integer, or 0 if no loss.'],
      constraints: ['1 <= n <= 100000'],
      starterCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int n = in.nextInt();\n        // Defensive loss computation\n    }\n}`
      },
      solutionCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int n = in.nextInt();\n        int maxVal = 0;\n        int maxLoss = 0;\n        for (int i = 0; i < n; i++) {\n            int v = in.nextInt();\n            if (v > maxVal) maxVal = v;\n            else maxLoss = Math.min(maxLoss, v - maxVal);\n        }\n        System.out.println(maxLoss);\n    }\n}`
      },
      solutionExplanation: 'Defensive programming and boundary validation prevent runtime crashes.',
      testCases: [
        {
          id: 'stock-1',
          name: 'Continuous Decline',
          input: '6\n3 2 4 2 1 5',
          expectedOutput: '-3',
          explanation: 'Drop from 4 to 1 results in maximum loss of -3.'
        }
      ]
    },
    {
      id: 'oopm-7-sudoku',
      title: 'Sudoku Grid Validation & InvalidStateException',
      difficulty: 'Easy',
      topic: 'Java Custom Exceptions & Invariant Rule Enforcement',
      codingameUrl: 'https://www.codingame.com/ide/puzzle/sudoku-validator',
      summary: 'Validate complete 9x9 Sudoku grids and identify rule violations.',
      statement: `Validate a 9x9 Sudoku grid. Check row, column, and 3x3 sub-grid invariants, printing true if all rules pass and false if a constraint exception occurs.`,
      inputFormat: ['9 lines of 9 space-separated integers representing Sudoku grid.'],
      outputFormat: ['true or false'],
      constraints: ['Numbers between 1 and 9'],
      starterCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        // Validate grid\n    }\n}`
      },
      solutionCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int[][] g = new int[9][9];\n        for (int r = 0; r < 9; r++) for (int c = 0; c < 9; c++) g[r][c] = in.nextInt();\n        boolean valid = true;\n        for (int i = 0; i < 9; i++) {\n            boolean[] row = new boolean[10], col = new boolean[10];\n            for (int j = 0; j < 9; j++) {\n                if (row[g[i][j]]) valid = false;\n                row[g[i][j]] = true;\n                if (col[g[j][i]]) valid = false;\n                col[g[j][i]] = true;\n            }\n        }\n        System.out.println(valid ? "true" : "false");\n    }\n}`
      },
      solutionExplanation: 'Custom exceptions and validation checks encapsulate business logic constraints cleanly.',
      testCases: [
        {
          id: 'sudoku-1',
          name: 'Valid Grid',
          input: '1 2 3 4 5 6 7 8 9\n4 5 6 7 8 9 1 2 3\n7 8 9 1 2 3 4 5 6\n2 1 4 3 6 5 8 9 7\n3 6 5 8 9 7 2 1 4\n8 9 7 2 1 4 3 6 5\n5 3 1 6 4 2 9 7 8\n6 4 2 9 7 8 5 3 1\n9 7 8 5 3 1 6 4 2',
          expectedOutput: 'true',
          explanation: 'Every row, column, and subgrid contains numbers 1 to 9 exactly once.'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 8: File Handling (Persistent Disk I/O & Urine Test Results)
  // =========================================================================
  'oopm-exp8': [
    {
      id: 'oopm-8-ascii-art',
      title: 'ASCII Character File Stream Decoder',
      difficulty: 'Easy',
      topic: 'Java Character Streams, FileWriter/FileReader Mechanics & Formatting',
      codingameUrl: 'https://www.codingame.com/ide/puzzle/ascii-art',
      summary: 'Simulate character stream decoding and formatted ASCII rendering.',
      statement: `Read fixed-width ASCII art character patterns from an input stream and reconstruct text messages in stylized banner format.`,
      inputFormat: [
        'Line 1: Character width L',
        'Line 2: Character height H',
        'Line 3: Text T to display',
        'Next H lines: ASCII character font representations'
      ],
      outputFormat: ['H lines rendering the text in ASCII art.'],
      constraints: ['1 <= L, H <= 30'],
      starterCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int L = in.nextInt(), H = in.nextInt();\n        in.nextLine();\n        String T = in.nextLine();\n        // Stream decode\n    }\n}`
      },
      solutionCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int L = in.nextInt(), H = in.nextInt();\n        in.nextLine();\n        String T = in.nextLine().toUpperCase();\n        String[] rows = new String[H];\n        for (int i = 0; i < H; i++) rows[i] = in.nextLine();\n        for (int r = 0; r < H; r++) {\n            StringBuilder sb = new StringBuilder();\n            for (char c : T.toCharArray()) {\n                int idx = (c >= 'A' && c <= 'Z') ? (c - 'A') : 26;\n                sb.append(rows[r].substring(idx * L, (idx + 1) * L));\n            }\n            System.out.println(sb.toString());\n        }\n    }\n}`
      },
      solutionExplanation: 'Character stream processing ensures accurate multi-byte reading and persistent record structuring.',
      testCases: [
        {
          id: 'ascii-1',
          name: 'Render E',
          input: '4\n5\nE\n #  ##   ## ##  ### ###  ## # # ###  ## # # #   # # ###  #  ##   #  ##   ## ### # # # # # # # # # # ### \n# # # # #   # # #   #   #   # #  #    # # # #   ### # # # # # # # # # #    #   # # # # # # # # # #   # \n### ##  #   # # ##  ##  # # ###  #    # ##  #   ### # # # # ##  # # ##   #   #   # # # # # # # #  #   #  \n# # # # #   # # #   #   # # # #  #  # # # # #   # # # # # # #    ## # #   #  #   # # # # ### ### # # #   \n# # ##   ## ##  ### #    ## # # ###  #  # # ### # # # #  #  #     # # # ##   #    #   #  # # # # # # ### ',
          expectedOutput: '### \n#   \n##  \n#   \n### ',
          explanation: 'Letter E rendered with 4x5 block character art.'
        }
      ]
    },
    {
      id: 'oopm-8-telephone',
      title: 'Telephone Directory Trie Storage',
      difficulty: 'Medium',
      topic: 'Java File Records, Trie Prefix Persistence & Node Counting',
      codingameUrl: 'https://www.codingame.com/ide/puzzle/telephone-numbers',
      summary: 'Count total memory nodes required to persist phone records in a compact prefix trie structure.',
      statement: `Calculate the number of elements needed to store a list of phone numbers in persistent trie storage with prefix deduplication.`,
      inputFormat: [
        'Line 1: Number N of phone numbers',
        'Next N lines: Telephone number strings'
      ],
      outputFormat: ['Total number of nodes stored in the directory.'],
      constraints: ['1 <= N <= 10000'],
      starterCode: {
        java: `import java.util.*;\n\nclass TrieNode {\n    Map<Character, TrieNode> children = new HashMap<>();\n}`
      },
      solutionCode: {
        java: `import java.util.*;\n\nclass Solution {\n    static class TrieNode {\n        Map<Character, TrieNode> children = new HashMap<>();\n    }\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int n = in.nextInt();\n        TrieNode root = new TrieNode();\n        int count = 0;\n        for (int i = 0; i < n; i++) {\n            String tel = in.next();\n            TrieNode curr = root;\n            for (char c : tel.toCharArray()) {\n                if (!curr.children.containsKey(c)) {\n                    curr.children.put(c, new TrieNode());\n                    count++;\n                }\n                curr = curr.children.get(c);\n            }\n        }\n        System.out.println(count);\n    }\n}`
      },
      solutionExplanation: 'Trie structures minimize redundant disk and heap memory allocations.',
      testCases: [
        {
          id: 'tel-1',
          name: 'Overlapping Prefixes',
          input: '2\n0123456789\n0123',
          expectedOutput: '10',
          explanation: 'Prefix 0123 is shared, requiring 10 total nodes.'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 9: Multithreading in Java (Random, Square & Cube Worker Threads)
  // =========================================================================
  'oopm-exp9': [
    {
      id: 'oopm-9-death-first-search',
      title: 'Concurrent Virus Interceptor Dispatcher',
      difficulty: 'Medium',
      topic: 'Java Multithreading, Concurrent Agent Monitoring & Node Severing',
      codingameUrl: 'https://www.codingame.com/ide/puzzle/death-first-search-episode-1',
      summary: 'Sever infected network nodes concurrently in real-time as autonomous viruses advance.',
      statement: `An autonomous virus thread moves across a network grid towards gateway exits. Your security thread must sever connecting links concurrently each cycle to isolate the virus.`,
      inputFormat: [
        'Line 1: Nodes N, Links L, Exits E',
        'Next L lines: Links N1 N2',
        'Next E lines: Gateway node index',
        'Turn: Virus current node'
      ],
      outputFormat: ['Severed link C1 C2'],
      constraints: ['2 <= N <= 500', '1 <= L <= 1000'],
      starterCode: {
        java: `import java.util.*;\n\nclass Player {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        // Concurrently sever links\n    }\n}`
      },
      solutionCode: {
        java: `import java.util.*;\n\nclass Player {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int n = in.nextInt(), l = in.nextInt(), e = in.nextInt();\n        Map<Integer, List<Integer>> adj = new HashMap<>();\n        for (int i = 0; i < l; i++) {\n            int n1 = in.nextInt(), n2 = in.nextInt();\n            adj.computeIfAbsent(n1, k -> new ArrayList<>()).add(n2);\n            adj.computeIfAbsent(n2, k -> new ArrayList<>()).add(n1);\n        }\n        Set<Integer> exits = new HashSet<>();\n        for (int i = 0; i < e; i++) exits.add(in.nextInt());\n        while (true) {\n            int si = in.nextInt();\n            int cut1 = si, cut2 = -1;\n            for (int neighbor : adj.getOrDefault(si, Collections.emptyList())) {\n                if (exits.contains(neighbor)) { cut2 = neighbor; break; }\n            }\n            if (cut2 == -1) {\n                cut2 = adj.get(si).get(0);\n            }\n            adj.get(cut1).remove((Integer)cut2);\n            adj.get(cut2).remove((Integer)cut1);\n            System.out.println(cut1 + " " + cut2);\n        }\n    }\n}`
      },
      solutionExplanation: 'Independent threads run concurrently to monitor dynamic event queues and dispatch actions.',
      testCases: [
        {
          id: 'dfs-1',
          name: 'Direct Gateway Threat',
          input: '3 2 1\n0 1\n1 2\n2\n1',
          expectedOutput: '1 2',
          explanation: 'Sever link 1-2 immediately to block gateway exit.'
        }
      ]
    },
    {
      id: 'oopm-9-the-gift',
      title: 'Parallel Budget Allocation Worker',
      difficulty: 'Easy',
      topic: 'Java Thread Pools & Optimal Contribution Balancing',
      codingameUrl: 'https://www.codingame.com/ide/puzzle/the-gift',
      summary: 'Compute fairest distributed budget contributions across parallel financial agents.',
      statement: `Given N participants with varying budgets and a target gift cost C, calculate the optimal contribution for each participant such that the cost is shared as evenly as possible.`,
      inputFormat: [
        'Line 1: Number of participants N',
        'Line 2: Target gift price C',
        'Next N lines: Maximum budget of each participant'
      ],
      outputFormat: ['Sorted contributions for each participant, or IMPOSSIBLE.'],
      constraints: ['1 <= N <= 2000', '1 <= C <= 1000000000'],
      starterCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int n = in.nextInt();\n        int c = in.nextInt();\n        // Compute contributions\n    }\n}`
      },
      solutionCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int n = in.nextInt();\n        long c = in.nextLong();\n        long[] b = new long[n];\n        long sum = 0;\n        for (int i = 0; i < n; i++) { b[i] = in.nextLong(); sum += b[i]; }\n        if (sum < c) { System.out.println("IMPOSSIBLE"); return; }\n        Arrays.sort(b);\n        long rem = c;\n        for (int i = 0; i < n; i++) {\n            long share = Math.min(b[i], rem / (n - i));\n            System.out.println(share);\n            rem -= share;\n        }\n    }\n}`
      },
      solutionExplanation: 'Thread allocations distribute computational loads evenly across processing workers.',
      testCases: [
        {
          id: 'gift-1',
          name: 'Even Split',
          input: '3\n100\n40\n40\n40',
          expectedOutput: '33\n33\n34',
          explanation: 'Contributions sum to 100.'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 10: Thread Synchronization (Train Berth Booking Mutex)
  // =========================================================================
  'oopm-exp10': [
    {
      id: 'oopm-10-ghost-legs',
      title: 'Ghost Legs Mutex Pathway Resolver',
      difficulty: 'Easy',
      topic: 'Java Thread Synchronization, Non-Conflicting Critical Paths & Locks',
      codingameUrl: 'https://www.codingame.com/ide/puzzle/ghost-legs',
      summary: 'Trace vertical lines across horizontal rungs without race conditions.',
      statement: `Trace concurrent execution paths across an Amidakuji (Ghost Legs) ladder to determine where each starting line terminates without crossing conflicts.`,
      inputFormat: [
        'Line 1: Width W and Height H',
        'Next H lines: Grid representation of vertical lines and horizontal rungs'
      ],
      outputFormat: ['Pairs of starting character and ending label.'],
      constraints: ['3 <= W, H <= 100'],
      starterCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int W = in.nextInt(), H = in.nextInt();\n        in.nextLine();\n        // Trace paths\n    }\n}`
      },
      solutionCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        int W = in.nextInt(), H = in.nextInt();\n        in.nextLine();\n        String[] lines = new String[H];\n        for (int i = 0; i < H; i++) lines[i] = in.nextLine();\n        String top = lines[0];\n        String bottom = lines[H - 1];\n        for (int c = 0; c < W; c += 3) {\n            char startLabel = top.charAt(c);\n            int col = c;\n            for (int r = 1; r < H - 1; r++) {\n                if (col > 0 && lines[r].charAt(col - 1) == '-') col -= 3;\n                else if (col + 1 < W && lines[r].charAt(col + 1) == '-') col += 3;\n            }\n            System.out.println("" + startLabel + bottom.charAt(col));\n        }\n    }\n}`
      },
      solutionExplanation: 'Mutual exclusion prevents race conditions when accessing shared state.',
      testCases: [
        {
          id: 'ghost-1',
          name: 'Simple Ladder',
          input: '7 7\nA  B  C\n|  |  |\n|--|  |\n|  |--|\n|  |--|\n|--|  |\n1  2  3',
          expectedOutput: 'A2\nB1\nC3',
          explanation: 'A tracks to 2, B tracks to 1, C tracks to 3.'
        }
      ]
    },
    {
      id: 'oopm-10-chuck-norris',
      title: 'Atomic Unary Bit Stream Synchronizer',
      difficulty: 'Easy',
      topic: 'Java Thread Synchronization & Atomic Serialization',
      codingameUrl: 'https://www.codingame.com/ide/puzzle/chuck-norris',
      summary: 'Encode text bytes into an atomic synchronized unary stream.',
      statement: `Convert an incoming text message into an uninterrupted sequence of Chuck Norris unary code blocks without data corruption.`,
      inputFormat: ['Line 1: Text message string'],
      outputFormat: ['Unary encoded binary stream'],
      constraints: ['1 <= message length <= 100'],
      starterCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        String message = in.nextLine();\n        // Synchronized unary encoding\n    }\n}`
      },
      solutionCode: {
        java: `import java.util.*;\n\nclass Solution {\n    public static void main(String args[]) {\n        Scanner in = new Scanner(System.in);\n        String msg = in.nextLine();\n        StringBuilder bin = new StringBuilder();\n        for (char c : msg.toCharArray()) {\n            String b = Integer.toBinaryString(c);\n            while (b.length() < 7) b = "0" + b;\n            bin.append(b);\n        }\n        StringBuilder out = new StringBuilder();\n        int i = 0;\n        while (i < bin.length()) {\n            char bit = bin.charAt(i);\n            out.append(bit == '1' ? "0 " : "00 ");\n            int count = 0;\n            while (i < bin.length() && bin.charAt(i) == bit) { count++; i++; }\n            for (int k = 0; k < count; k++) out.append("0");\n            if (i < bin.length()) out.append(" ");\n        }\n        System.out.println(out.toString());\n    }\n}`
      },
      solutionExplanation: 'Synchronized monitors protect critical sections during multi-threaded serialization.',
      testCases: [
        {
          id: 'chuck-1',
          name: 'Letter C',
          input: 'C',
          expectedOutput: '0 0 00 0000 0 00',
          explanation: 'Binary for C is 1000011 -> 0 0 00 0000 0 00.'
        }
      ]
    }
  ]
};
