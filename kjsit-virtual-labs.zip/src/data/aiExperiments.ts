import { LabExperiment } from '../types';

export const AI_EXPERIMENTS: LabExperiment[] = [
  {
    id: 'ai-exp1',
    num: 1,
    subjectId: 'ai',
    title: 'Uninformed Search: BFS & DFS State-Space Exploration',
    subtitle: 'Systematic Graph Traversal, Queue vs Stack Frontiers and Completeness',
    category: 'State-Space Search',
    iitReference: 'Autonomous Curriculum Standards / Artificial Intelligence Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/ai-lab/',
    aim: 'To implement and compare Breadth-First Search (BFS) and Depth-First Search (DFS) for solving pathfinding and maze navigation in arbitrary state spaces.',
    theory: {
      overview: [
        'In Artificial Intelligence, problem solving is frequently formulated as searching through a state space from an initial state to a goal state.',
        'Breadth-First Search (BFS) explores vertices level by level using a FIFO Queue. It is complete and optimal for unweighted graphs (guarantees the shortest path).',
        'Depth-First Search (DFS) explores as deep as possible along each branch before backtracking using a LIFO Stack. It has minimal memory requirements O(bm) where b is branching factor and m is maximum depth.'
      ],
      complexityTable: [
        { parameter: 'BFS Time Complexity', value: 'O(b^d) where b is branching factor, d is goal depth' },
        { parameter: 'BFS Space Complexity', value: 'O(b^d) - High exponential memory footprint' },
        { parameter: 'DFS Time Complexity', value: 'O(b^m) where m is maximum depth' },
        { parameter: 'DFS Space Complexity', value: 'O(b * m) - Highly memory efficient linear frontier' }
      ],
      keyPoints: [
        'BFS guarantees optimal path in step count; DFS can get trapped in infinite depth loops without cycle detection.',
        'Frontier data structures: Queue for BFS, Stack / Call Stack for DFS.'
      ],
      realWorldApplications: [
        'Web crawling indexing hyperlinks level by level.',
        'Solving 8-puzzle and maze pathfinding in robotic navigation.'
      ]
    },
    algorithm: [
      '1. Initialize frontier with initial state S0. Create visited set.',
      '2. While frontier is not empty: pop node curr.',
      '3. If curr satisfies GoalTest(curr), reconstruct path and return success.',
      '4. For each valid action yielding neighbor in Successors(curr):',
      '    a. If neighbor not in visited:',
      '    b. Add neighbor to visited and push to frontier with parent pointer.',
      '5. If frontier empty without reaching goal, return Failure.'
    ],
    procedure: [
      '1. Open the AI State-Space Search visualizer.',
      '2. Configure grid dimensions or select pre-built maze topology.',
      '3. Choose between BFS (Breadth-First) and DFS (Depth-First).',
      '4. Observe the expansion wavefront and frontier size at each step.',
      '5. Inspect the resulting shortest path.'
    ],
    code: {
      python: `from collections import deque
from typing import Dict, List, Optional

def bfs(graph: Dict[str, List[str]], start: str, goal: str) -> Optional[List[str]]:
    visited = {start}
    queue = deque([[start]])
    while queue:
        path = queue.popleft()
        node = path[-1]
        if node == goal:
            return path
        for neighbor in graph.get(node, []):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(path + [neighbor])
    return None

def dfs(graph: Dict[str, List[str]], start: str, goal: str) -> Optional[List[str]]:
    visited = set()
    stack = [[start]]
    while stack:
        path = stack.pop()
        node = path[-1]
        if node == goal:
            return path
        if node not in visited:
            visited.add(node)
            for neighbor in reversed(graph.get(node, [])):
                if neighbor not in visited:
                    stack.append(path + [neighbor])
    return None`,
      cpp: `#include <iostream>
#include <vector>
#include <queue>
#include <unordered_set>
// C++ BFS implementation for AI state space`,
      java: `import java.util.*;
// Java BFS & DFS search classes`,
      c: `// C Graph traversal`
    },
    sampleInput: 'Start: A, Goal: G, Graph: A->B,C; B->D,E; C->F; E->G',
    expectedOutput: 'BFS Path: A -> B -> E -> G (Path length: 3 steps, Nodes visited: 6)',
    references: ['Stuart Russell and Peter Norvig, Artificial Intelligence: A Modern Approach (4th Edition), Pearson'],
    conclusion: 'BFS successfully discovered the optimal shortest path, while DFS demonstrated linear space complexity during deep path exploration.',
    quiz: [
      {
        id: 1,
        question: 'Under which condition is Breadth-First Search (BFS) guaranteed to find the optimal shortest path?',
        options: [
          'When edge costs are strictly negative',
          'When all step costs are equal (uniform step cost)',
          'Only when the graph is a binary tree',
          'Only when heuristics are admissible'
        ],
        correctAnswer: 1,
        explanation: 'BFS is guaranteed to return the optimal solution when all step costs are identical, as it explores all paths of length k before any paths of length k+1.'
      }
    ]
  },
  {
    id: 'ai-exp2',
    num: 2,
    subjectId: 'ai',
    title: 'Informed / Heuristic Search: A* Algorithm',
    subtitle: 'Evaluation Function f(n) = g(n) + h(n), Admissibility & Consistency',
    category: 'Heuristic Search',
    iitReference: 'Autonomous Curriculum Standards / Artificial Intelligence Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/ai-lab/',
    aim: 'To implement the A* heuristic search algorithm on a 2D grid world, verifying admissibility of Manhattan and Euclidean distance heuristics.',
    theory: {
      overview: [
        'A* Search combines the path cost so far g(n) with an estimated cost to goal h(n): f(n) = g(n) + h(n).',
        'An admissible heuristic never overestimates the true cost to reach the goal (h(n) <= h*(n)).',
        'A consistent (monotonic) heuristic satisfies the triangle inequality: h(n) <= c(n, a, n\') + h(n\'). A* with consistent heuristics guarantees optimal path without reopening closed nodes.'
      ],
      complexityTable: [
        { parameter: 'Time Complexity', value: 'O(b^d) worst case, but heavily pruned by good heuristics' },
        { parameter: 'Space Complexity', value: 'O(b^d) - Keeps all generated nodes in Open/Closed lists' }
      ],
      keyPoints: [
        'Open List: Priority queue ordered by lowest f(n).',
        'Closed List: Explored nodes.',
        'Manhattan distance is admissible for 4-directional grid movement; Euclidean for any-angle.'
      ],
      realWorldApplications: [
        'GPS Navigation and vehicle routing systems (Google Maps, OpenStreetMap).',
        'Game character pathfinding in RTS and RPG game engines.'
      ]
    },
    algorithm: [
      '1. Place start node on openList with g=0, h=heuristic(start, goal), f=g+h.',
      '2. While openList is not empty: pop node with lowest f(n).',
      '3. If current == goal, reconstruct path via parent pointers and return.',
      '4. Add current to closedList.',
      '5. For each adjacent neighbor: calculate tentative_g = g(current) + stepCost.',
      '6. If tentative_g < g(neighbor): update neighbor parent, g, f and push to openList.'
    ],
    procedure: [
      '1. Open the A* Grid Simulator.',
      '2. Place obstacles, start point, and target goal.',
      '3. Select Manhattan vs Euclidean heuristic.',
      '4. Step through iterations and observe the priority queue order.',
      '5. Inspect total cost and generated path.'
    ],
    code: {
      python: `import heapq
from typing import Tuple, List, Dict

def a_star(start: Tuple[int, int], goal: Tuple[int, int], grid: List[List[int]]) -> List[Tuple[int, int]]:
    def h(pos):
        return abs(pos[0] - goal[0]) + abs(pos[1] - goal[1]) # Manhattan

    open_heap = [(h(start), 0, start, [start])]
    g_scores = {start: 0}
    visited = set()

    while open_heap:
        f, g, curr, path = heapq.heappop(open_heap)
        if curr == goal:
            return path
        if curr in visited:
            continue
        visited.add(curr)

        for dx, dy in [(-1,0), (1,0), (0,-1), (0,1)]:
            nx, ny = curr[0] + dx, curr[1] + dy
            if 0 <= nx < len(grid) and 0 <= ny < len(grid[0]) and grid[nx][ny] == 0:
                nxt = (nx, ny)
                new_g = g + 1
                if nxt not in g_scores or new_g < g_scores[nxt]:
                    g_scores[nxt] = new_g
                    heapq.heappush(open_heap, (new_g + h(nxt), new_g, nxt, path + [nxt]))
    return []`,
      cpp: `// C++ Priority Queue A* implementation`,
      java: `// Java PriorityQueue A*`,
      c: `// C A* pathfinder`
    },
    sampleInput: 'Grid 10x10, Start: (0,0), Goal: (8,8) with diagonal wall',
    expectedOutput: 'Optimal Path Found: 16 steps, Cost: 16.0, Evaluated: 28 nodes',
    references: ['Peter Hart, Nils Nilsson, and Bertram Raphael (1968), A Formal Basis for the Heuristic Determination of Minimum Cost Paths'],
    conclusion: 'A* with admissible Manhattan heuristic pruned 70% of state expansions compared to Dijkstra while maintaining complete optimality.',
    quiz: [
      {
        id: 1,
        question: 'What is the consequence if a heuristic function h(n) in A* search is NOT admissible?',
        options: [
          'A* may fail to find the optimal (lowest cost) path to the goal',
          'The program will crash with an out of memory exception',
          'The algorithm will run in exponential time O(2^n)',
          'Closed list operations become undefined'
        ],
        correctAnswer: 0,
        explanation: 'If h(n) overestimates the actual cost to the goal, A* may bypass the true optimal path in favor of a path that appears shorter according to the inaccurate heuristic.'
      }
    ]
  },
  {
    id: 'ai-exp3',
    num: 3,
    subjectId: 'ai',
    title: 'Adversarial Search: Minimax with Alpha-Beta Pruning',
    subtitle: 'Zero-Sum Two-Player Game Trees and Branch Cutoffs',
    category: 'Game Playing',
    iitReference: 'Autonomous Curriculum Standards / Artificial Intelligence Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/ai-lab/',
    aim: 'To model a two-player zero-sum game (Tic-Tac-Toe / Connect Four) using Minimax decision trees and optimize performance with Alpha-Beta pruning.',
    theory: {
      overview: [
        'Adversarial Search operates in competitive environments where two players have opposing utility goals: MAX aims to maximize utility, while MIN aims to minimize it.',
        'Minimax computes the minimax value of each node by recursive depth-first tree traversal.',
        'Alpha-Beta Pruning eliminates branches that cannot possibly influence the final decision, reducing the effective branching factor from b to sqrt(b) in the best case.'
      ],
      complexityTable: [
        { parameter: 'Standard Minimax', value: 'O(b^d) where b is branching factor, d is depth' },
        { parameter: 'Alpha-Beta Best Case', value: 'O(b^(d/2)) - Doubles the reachable search depth' }
      ],
      keyPoints: [
        'Alpha (α): Best score MAX can guarantee so far.',
        'Beta (β): Best score MIN can guarantee so far.',
        'Prune condition: When α >= β, remaining child branches are discarded.'
      ],
      realWorldApplications: [
        'Chess engines (Stockfish), Checkers, and Go game trees.'
      ]
    },
    algorithm: [
      '1. Function AlphaBeta(node, depth, alpha, beta, isMaximizing):',
      '2. If depth == 0 or Terminal(node): return Evaluate(node).',
      '3. If isMaximizing:',
      '    a. maxEval = -Infinity.',
      '    b. For each child of node: eval = AlphaBeta(child, depth-1, alpha, beta, False).',
      '    c. maxEval = max(maxEval, eval); alpha = max(alpha, eval).',
      '    d. If beta <= alpha: break (Beta cutoff).',
      '    e. Return maxEval.',
      '4. Else (Minimizing): minEval = +Infinity; similar logic with beta = min(beta, eval).'
    ],
    procedure: [
      '1. Open Game Tree Simulator.',
      '2. Play a move as MAX or MIN on the interactive board.',
      '3. View the generated game tree with Alpha/Beta values on nodes.',
      '4. Observe pruned branches highlighted in red.'
    ],
    code: {
      python: `import math

def minimax(board, depth, alpha, beta, is_max):
    score = evaluate(board)
    if score == 10 or score == -10 or depth == 0 or not is_moves_left(board):
        return score

    if is_max:
        best = -math.inf
        for move in get_valid_moves(board):
            make_move(board, move, 'X')
            val = minimax(board, depth - 1, alpha, beta, False)
            undo_move(board, move)
            best = max(best, val)
            alpha = max(alpha, best)
            if beta <= alpha:
                break # Beta cutoff
        return best
    else:
        best = math.inf
        for move in get_valid_moves(board):
            make_move(board, move, 'O')
            val = minimax(board, depth - 1, alpha, beta, True)
            undo_move(board, move)
            best = min(best, val)
            beta = min(beta, best)
            if beta <= alpha:
                break # Alpha cutoff
        return best`,
      cpp: `// C++ Alpha-Beta minimax engine`,
      java: `// Java Alpha-Beta engine`,
      c: `// C Minimax implementation`
    },
    sampleInput: 'Tic-Tac-Toe 3x3 Board State: X in center, O in corner',
    expectedOutput: 'Best Move for X: (0, 1), Evaluated Nodes: 247 (Reduced from 1,280 without pruning)',
    references: ['John von Neumann (1928), Zur Theorie der Gesellschaftsspiele (Theory of Parlor Games)'],
    conclusion: 'Alpha-Beta pruning cut down 65% of node evaluations without altering the optimal Minimax value.',
    quiz: [
      {
        id: 1,
        question: 'Under what condition does an Alpha cutoff occur during adversarial search?',
        options: [
          'When evaluating a minimizing node, beta becomes less than or equal to alpha (beta <= alpha)',
          'When depth reaches zero',
          'When alpha exceeds positive infinity',
          'When the opponent forfeits'
        ],
        correctAnswer: 0,
        explanation: 'When the minimizing player finds a move with value <= alpha, the maximizing parent will never choose this branch, triggering an immediate cutoff.'
      }
    ]
  },
  {
    id: 'ai-exp4',
    num: 4,
    subjectId: 'ai',
    title: 'Constraint Satisfaction Problems (CSP): 8-Queens & Map Coloring',
    subtitle: 'Backtracking Search, Forward Checking & Minimum Remaining Values (MRV)',
    category: 'Constraint Satisfaction',
    iitReference: 'Autonomous Curriculum Standards / Artificial Intelligence Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/ai-lab/',
    aim: 'To formulate and solve Constraint Satisfaction Problems (CSP) including the N-Queens problem and Australia Map Coloring using Backtracking and MRV heuristic.',
    theory: {
      overview: [
        'A CSP is defined by a set of variables X = {X1, ..., Xn}, domains D = {D1, ..., Dn}, and constraints C specifying allowable combinations of values.',
        'Backtracking Search is the standard depth-first method for CSPs, assigning values to one variable at a time and backtracking when a constraint is violated.',
        'Heuristics such as MRV (Minimum Remaining Values / Most Constrained Variable) and LCV (Least Constraining Value) dramatically accelerate search convergence.'
      ],
      complexityTable: [
        { parameter: 'Naive Generate & Test', value: 'O(d^n) - Astronomical combinatorial space' },
        { parameter: 'Backtracking + Forward Checking', value: 'O(b^d) with substantial constraint pruning' }
      ],
      keyPoints: [
        'Arc Consistency (AC-3) eliminates values from domains that have no valid support in neighboring variables.',
        'Forward checking propagates constraints immediately after every variable assignment.'
      ],
      realWorldApplications: [
        'University timetable scheduling and exam seating arrangements.',
        'Flight crew rostering and semiconductor circuit routing.'
      ]
    },
    algorithm: [
      '1. Function Backtrack(assignment, csp):',
      '2. If assignment is complete: return assignment.',
      '3. Select unassigned variable var using MRV heuristic.',
      '4. For each value in OrderDomainValues(var, assignment, csp):',
      '    a. If value is consistent with assignment given constraints:',
      '    b. Add {var = value} to assignment.',
      '    c. Inferences = ForwardCheck(csp, var, value).',
      '    d. If inferences != failure: result = Backtrack(assignment, csp); if result: return result.',
      '    e. Remove {var = value} and restore pruned domains.',
      '5. Return failure.'
    ],
    procedure: [
      '1. Select 8-Queens or Map Coloring in the CSP Simulator.',
      '2. Toggle heuristics: Naive Backtracking vs MRV + Forward Checking.',
      '3. Step through the variable assignment sequence.',
      '4. Observe domain reduction tables dynamically eliminating conflicting colors/positions.'
    ],
    code: {
      python: `def solve_n_queens(n=8):
    solutions = []
    board = [-1] * n # row index represents queen column

    def is_safe(row, col):
        for r in range(row):
            c = board[r]
            if c == col or abs(c - col) == abs(r - row):
                return False
        return True

    def backtrack(row):
        if row == n:
            solutions.append(list(board))
            return
        for col in range(n):
            if is_safe(row, col):
                board[row] = col
                backtrack(row + 1)
                board[row] = -1

    backtrack(0)
    return solutions`,
      cpp: `// C++ 8-Queens Backtracking`,
      java: `// Java Map Coloring CSP`,
      c: `// C Backtracking implementation`
    },
    sampleInput: '8-Queens Problem (N = 8)',
    expectedOutput: 'Total Distinct Solutions: 92. First solution: [0, 4, 7, 5, 2, 6, 1, 3] in 114 backtracks.',
    references: ['Eugene Freuder (1982), Synthesizing Constraint Expressions'],
    conclusion: 'MRV heuristic reduced backtracks by over 80% compared to brute force exhaustive search.',
    quiz: [
      {
        id: 1,
        question: 'What is the Minimum Remaining Values (MRV) heuristic in CSP search?',
        options: [
          'Choose the variable with the fewest legal values remaining in its domain',
          'Choose the value that rules out the fewest choices for neighboring variables',
          'Choose the variable that participates in the most constraints',
          'Assign values in descending numerical order'
        ],
        correctAnswer: 0,
        explanation: 'MRV selects the variable with the fewest allowable values left, failing fast if a variable has zero legal values and minimizing the search tree branching factor.'
      }
    ]
  },
  {
    id: 'ai-exp5',
    num: 5,
    subjectId: 'ai',
    title: 'Propositional & First-Order Logic Inference',
    subtitle: 'Resolution Refutation, Horn Clauses & Forward/Backward Chaining',
    category: 'Knowledge & Logic',
    iitReference: 'Autonomous Curriculum Standards / Artificial Intelligence Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/ai-lab/',
    aim: 'To represent knowledge using Propositional and First-Order Predicate Logic, convert to Conjunctive Normal Form (CNF), and prove theorems via Resolution Refutation.',
    theory: {
      overview: [
        'Logic provides a formal language for knowledge representation and reasoning. A knowledge base (KB) consists of sentences with precise semantics.',
        'Entailment (KB |= α) means that in every model where KB is true, α is also true.',
        'Resolution Refutation proves KB |= α by showing that KB ∧ ¬α is unsatisfiable. It repeatedly resolves complementary literals (P and ¬P) until the empty clause (contradiction) is derived.'
      ],
      complexityTable: [
        { parameter: 'Propositional Resolution', value: 'NP-complete in worst case' },
        { parameter: 'Horn Clause Forward Chaining', value: 'O(n) linear in size of knowledge base' }
      ],
      keyPoints: [
        'Conjunctive Normal Form (CNF): Conjunction of disjunctions of literals.',
        'Soundness: Derives only entailed sentences. Completeness: Derives all entailed sentences.'
      ],
      realWorldApplications: [
        'Automated hardware theorem proving and microprocessor verification.',
        'Medical diagnosis rule-based expert systems.'
      ]
    },
    algorithm: [
      '1. Negate the query theorem α (derive ¬α).',
      '2. Convert all KB axioms and ¬α into Conjunctive Normal Form (CNF) clauses.',
      '3. Repeatedly select two clauses containing complementary literals (L and ¬L).',
      '4. Compute resolvent by removing L and ¬L and combining remaining literals.',
      '5. If resolvent is empty clause (False), contradiction reached: return Proved (KB |= α).',
      '6. If no new clauses can be added, return Not Entailed.'
    ],
    procedure: [
      '1. Open Propositional Resolution Prover.',
      '2. Input logical premises (e.g., P -> Q, Q -> R, P).',
      '3. Enter query (R).',
      '4. Observe conversion to CNF and step-by-step resolution refutation tree.',
      '5. Verify generation of the null clause (box).'
    ],
    code: {
      python: `def pl_resolution(kb_clauses, query):
    clauses = set(kb_clauses)
    # Add negation of query
    clauses.add(f"-{query}" if not query.startswith("-") else query[1:])
    new = set()

    while True:
        clause_list = list(clauses)
        for i in range(len(clause_list)):
            for j in range(i + 1, len(clause_list)):
                resolvents = resolve(clause_list[i], clause_list[j])
                if "" in resolvents: # Empty clause derived
                    return True # Contradiction -> Query is TRUE
                new.update(resolvents)
        if new.issubset(clauses):
            return False # No new clauses -> Query is FALSE
        clauses.update(new)`,
      cpp: `// C++ Logic Inference Engine`,
      java: `// Java First-Order Logic Resolver`,
      c: `// C Propositional Logic`
    },
    sampleInput: 'Premises: A -> B, B -> C, A. Query: C',
    expectedOutput: 'Proved via Resolution Refutation: Contradiction derived in 4 resolution steps.',
    references: ['J. Alan Robinson (1965), A Machine-Oriented Logic Based on the Resolution Principle'],
    conclusion: 'Resolution refutation systematically derived the empty clause, formally demonstrating deductive entailment.',
    quiz: [
      {
        id: 1,
        question: 'What does the derivation of an empty clause in a resolution refutation proof indicate?',
        options: [
          'A contradiction has been established, proving that the original query is logically entailed by the KB',
          'The proof has failed and no conclusion can be drawn',
          'The knowledge base contains infinite cycles',
          'The query is independent of the axioms'
        ],
        correctAnswer: 0,
        explanation: 'In resolution refutation, proving KB ∧ ¬α entails false (empty clause) demonstrates that assuming ¬α leads to a contradiction, thus confirming that α must be true.'
      }
    ]
  },
  {
    id: 'ai-exp6',
    num: 6,
    subjectId: 'ai',
    title: 'Genetic Algorithms (GA): Evolutionary Optimization',
    subtitle: 'Chromosome Encoding, Fitness Selection, Crossover & Mutation',
    category: 'Evolutionary Computing',
    iitReference: 'Autonomous Curriculum Standards / Artificial Intelligence Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/ai-lab/',
    aim: 'To optimize non-linear multimodal objective functions and solve the Traveling Salesperson Problem (TSP) using Genetic Algorithms.',
    theory: {
      overview: [
        'Genetic Algorithms (GA) are randomized search and optimization heuristics inspired by Charles Darwin’s theory of natural evolution.',
        'A population of candidate solutions (chromosomes) undergoes iterative selection based on fitness, reproduction through crossover (recombination), and random mutation.',
        'Over successive generations, the population converges towards optimal or near-optimal solutions across complex, discontinuous landscapes.'
      ],
      complexityTable: [
        { parameter: 'Per-Generation Time', value: 'O(P * L) where P is population size, L is chromosome length' },
        { parameter: 'Space Complexity', value: 'O(P * L) - Maintains current and offspring populations' }
      ],
      keyPoints: [
        'Selection methods: Roulette Wheel (fitness proportionate), Tournament Selection.',
        'Exploration vs Exploitation: Crossover drives exploitation of good building blocks; mutation drives exploration of unvisited regions.'
      ],
      realWorldApplications: [
        'Aerodynamic wing profile design in aerospace engineering.',
        'Financial portfolio optimization and hyperparameter tuning.'
      ]
    },
    algorithm: [
      '1. Initialize random population of N individuals.',
      '2. Evaluate fitness score f(x) for each individual.',
      '3. While generation < max_gen and convergence threshold not reached:',
      '    a. Select parents using Tournament Selection.',
      '    b. Apply Crossover (Single-Point or Order-Crossover) with probability Pc.',
      '    c. Apply Mutation (Bit-Flip or Swap) with probability Pm.',
      '    d. Evaluate fitness of offspring and construct next generation.',
      '4. Return individual with highest fitness found.'
    ],
    procedure: [
      '1. Open GA Simulator.',
      '2. Set Population Size (50-200), Crossover Rate (0.8), Mutation Rate (0.02).',
      '3. Choose TSP or Mathematical Rastrigin Function.',
      '4. Click Run Evolution and watch the best-fitness curve converge in real-time.'
    ],
    code: {
      python: `import random

def genetic_algorithm(fitness_fn, gene_len=20, pop_size=100, generations=50):
    population = [[random.randint(0, 1) for _ in range(gene_len)] for _ in range(pop_size)]
    best_ind = None
    best_fitness = -1

    for gen in range(generations):
        fitnesses = [fitness_fn(ind) for ind in population]
        for ind, f in zip(population, fitnesses):
            if f > best_fitness:
                best_fitness, best_ind = f, ind

        # Selection & Reproduction
        new_pop = []
        for _ in range(pop_size // 2):
            # Tournament selection
            p1 = max(random.sample(list(zip(population, fitnesses)), 3), key=lambda x: x[1])[0]
            p2 = max(random.sample(list(zip(population, fitnesses)), 3), key=lambda x: x[1])[0]
            # Crossover
            pt = random.randint(1, gene_len - 1)
            c1, c2 = p1[:pt] + p2[pt:], p2[:pt] + p1[pt:]
            # Mutation
            c1 = [1 - bit if random.random() < 0.02 else bit for bit in c1]
            c2 = [1 - bit if random.random() < 0.02 else bit for bit in c2]
            new_pop.extend([c1, c2])
        population = new_pop
    return best_ind, best_fitness`,
      cpp: `// C++ Genetic Algorithm Engine`,
      java: `// Java Evolutionary Optimizer`,
      c: `// C GA implementation`
    },
    sampleInput: 'Target: Maximize One-Max function with 30-bit string',
    expectedOutput: 'Optimal Chromosome: 30 ones (Fitness: 30/30) discovered at Generation 18.',
    references: ['John Holland (1975), Adaptation in Natural and Artificial Systems, University of Michigan Press'],
    conclusion: 'The genetic algorithm successfully navigated non-convex state spaces to achieve global optima within 20 generations.',
    quiz: [
      {
        id: 1,
        question: 'What role does the mutation operator primarily play in a Genetic Algorithm?',
        options: [
          'It preserves diversity in the gene pool and prevents premature convergence to local optima',
          'It speeds up compilation',
          'It guarantees that fitness will strictly increase every generation',
          'It removes invalid chromosomes from memory'
        ],
        correctAnswer: 0,
        explanation: 'Mutation introduces novel genetic material into the population, preventing the algorithm from getting permanently trapped in suboptimal local minima.'
      }
    ]
  }
];
