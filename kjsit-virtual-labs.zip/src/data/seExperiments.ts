import { LabExperiment } from '../types';

export const SE_EXPERIMENTS: LabExperiment[] = [
  {
    id: 'se-exp1',
    num: 1,
    subjectId: 'se',
    title: 'Software Requirements Engineering & SRS Documentation',
    subtitle: 'IEEE 830 Standard, Functional & Non-Functional Specifications, Use Cases',
    category: 'Requirements Engineering',
    iitReference: 'Autonomous Curriculum Standards / Software Engineering Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/se-lab/',
    aim: 'To formulate an IEEE 830-compliant Software Requirements Specification (SRS) for a Cloud-Based Hospital Management System, detailing functional, non-functional, and interface requirements.',
    theory: {
      overview: [
        'Software Requirements Engineering is the disciplined process of establishing the services that the customer requires from a system and the constraints under which it operates.',
        'An SRS (Software Requirements Specification) document acts as the formal contract between stakeholders, clients, and developers.',
        'IEEE Std 830 structure: 1. Introduction (Purpose, Scope, Definitions), 2. Overall Description (Product Perspective, User Classes, Operating Environment), 3. Specific Requirements (Functional Requirements, Non-Functional Requirements: Reliability, Security, Performance).'
      ],
      complexityTable: [
        { parameter: 'Defect Amplification', value: 'Requirements defects cost 100x more to fix in production than during analysis' },
        { parameter: 'Verification Rigor', value: 'Traceability Matrix mapping every requirement to test cases' }
      ],
      keyPoints: [
        'Functional Requirements: What the system MUST do (e.g., Patient Registration, Bed Allocation).',
        'Non-Functional Requirements (NFRs): Qualities and constraints (e.g., Latency < 200ms, 99.99% Availability, HIPAA compliance).'
      ],
      realWorldApplications: [
        'Enterprise healthcare software certifications (FDA / CE mark medical software compliance).',
        'Fintech regulatory compliance specifications for transaction auditability.'
      ]
    },
    algorithm: [
      '1. Conduct stakeholder elicitation interviews and survey user personas.',
      '2. Document high-level problem statement and project scope boundaries.',
      '3. Formulate functional requirements categorized into user modules.',
      '4. Specify quantifiable Non-Functional Requirements (NFRs) with verifiable metrics.',
      '5. Construct Requirements Traceability Matrix (RTM) linking each requirement ID to verification test IDs.',
      '6. Perform peer inspection and sign-off review.'
    ],
    procedure: [
      '1. Open IEEE 830 SRS Interactive Workbench.',
      '2. Select system module (e.g. Patient Admissions).',
      '3. Formulate Functional Requirements and assign MoSCoW priorities (Must, Should, Could, Won\'t).',
      '4. Run the Requirements Consistency & Ambiguity Checker.',
      '5. Export formatted IEEE 830 PDF preview.'
    ],
    code: {
      json: `{
  "document": "IEEE 830 Software Requirements Specification",
  "project": "KJSIT Enterprise Virtual Lab Portal",
  "version": "1.0.0",
  "functional_requirements": [
    {
      "id": "FR-001",
      "module": "Authentication",
      "description": "System shall authenticate students via University Roll Number and LDAP credentials within 500ms.",
      "priority": "MUST"
    },
    {
      "id": "FR-002",
      "module": "Simulation Engine",
      "description": "System shall execute step-by-step interactive algorithmic simulations and record user execution telemetry.",
      "priority": "MUST"
    }
  ],
  "non_functional_requirements": [
    {
      "id": "NFR-001",
      "category": "Availability",
      "target": "99.95% uptime during semester examination periods."
    },
    {
      "id": "NFR-002",
      "category": "Security",
      "target": "Role-Based Access Control (RBAC) preventing unauthorized privilege escalation."
    }
  ]
}`,
      c: `// Requirements traceability header`
    },
    sampleInput: 'System Scope: Hospital Management Portal. Users: Doctor, Patient, Administrator.',
    expectedOutput: 'Complete IEEE 830 SRS draft generated with RTM mapping 12 FRs to 4 NFRs.',
    references: ['Ian Sommerville, Software Engineering (10th Edition), Pearson'],
    conclusion: 'Structured requirements engineering eliminated ambiguous specifications and established complete traceability between requirements and design.',
    quiz: [
      {
        id: 1,
        question: 'Which of the following is categorized as a NON-FUNCTIONAL requirement?',
        options: [
          'The system response time must not exceed 250 milliseconds under 5,000 concurrent requests',
          'The system shall allow users to reset their passwords via SMS OTP',
          'The user can export reports to CSV format',
          'The admin can deactivate inactive student accounts'
        ],
        correctAnswer: 0,
        explanation: 'Response time (< 250ms) specifies a performance quality constraint rather than a specific operational behavior, classifying it as a non-functional requirement.'
      }
    ]
  },
  {
    id: 'se-exp2',
    num: 2,
    subjectId: 'se',
    title: 'Agile Scrum Sprint Planning & Kanban Workflow',
    subtitle: 'User Stories, Story Points (Fibonacci), Velocity & Burndown Charts',
    category: 'Agile Project Management',
    iitReference: 'Autonomous Curriculum Standards / Software Engineering Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/se-lab/',
    aim: 'To simulate Agile Scrum sprint ceremonies: Backlog Grooming, Sprint Planning, Story Point Estimation using Planning Poker, and Sprint Burndown tracking.',
    theory: {
      overview: [
        'Agile Software Development advocates adaptive planning, evolutionary development, early delivery, and continual improvement.',
        'Scrum framework structures work in fixed-length iterations called Sprints (typically 2 weeks). Key roles: Product Owner, Scrum Master, Development Team.',
        'Story Points measure the relative effort and complexity of a User Story using modified Fibonacci sequences (1, 2, 3, 5, 8, 13, 21).',
        'Sprint Burndown Chart plots remaining story points day-by-day against the ideal linear velocity guideline.'
      ],
      complexityTable: [
        { parameter: 'Sprint Cadence', value: 'Predictable 2-week iterations with fixed scope' },
        { parameter: 'Velocity Tracking', value: 'Average completed story points per sprint across historical runs' }
      ],
      keyPoints: [
        'INVEST Criteria for User Stories: Independent, Negotiable, Valuable, Estimable, Small, Testable.',
        'Daily Standup: What did you do yesterday? What will you do today? Are there any blockers?'
      ],
      realWorldApplications: [
        'Modern software engineering organizations running continuous delivery (Jira, GitHub Projects).'
      ]
    },
    algorithm: [
      '1. Create Product Backlog containing Epics and prioritized User Stories.',
      '2. Conduct Planning Poker: Developers independently vote on story points using Fibonacci cards.',
      '3. Reconcile estimates and establish Definition of Done (DoD).',
      '4. Commit stories into Sprint Backlog matching team historical Velocity (e.g. 40 points).',
      '5. Transition stories across Kanban states: To Do -> In Progress -> Code Review -> QA -> Done.',
      '6. Update daily burndown chart and calculate final sprint completion percentage.'
    ],
    procedure: [
      '1. Open Agile Scrum Board Simulator.',
      '2. Drag User Stories from Product Backlog into Sprint 1.',
      '3. Assign story points and simulate a 10-day sprint cycle.',
      '4. Watch burndown chart plot real vs ideal story point burnoff.',
      '5. Conduct sprint retrospective review.'
    ],
    code: {
      python: `import matplotlib.pyplot as plt

def generate_burndown(total_points=40, sprint_days=10, actual_remaining=[40, 36, 33, 29, 24, 20, 15, 9, 4, 0]):
    days = list(range(sprint_days + 1))
    ideal = [total_points - (total_points / sprint_days) * d for d in days]
    print(f"Sprint Velocity: {total_points / sprint_days:.1f} pts/day")
    return ideal, actual_remaining`
    },
    sampleInput: 'Team Velocity: 35 pts, Sprint Backlog: 6 User Stories total 34 points',
    expectedOutput: 'Burndown curve tracking 10 days, completing all 34 committed points on Day 10.',
    references: ['Ken Schwaber and Jeff Sutherland, The Scrum Guide'],
    conclusion: 'Agile sprint simulation demonstrated disciplined backlog grooming, accurate relative estimation, and real-time burndown velocity tracking.',
    quiz: [
      {
        id: 1,
        question: 'What does the INVEST acronym for agile user stories stand for?',
        options: [
          'Independent, Negotiable, Valuable, Estimable, Small, Testable',
          'Integrated, Networked, Verified, Evaluated, Standardized, Tracked',
          'Incremental, Numerical, Vectorized, Extensible, Secure, Tested',
          'Iterative, Normalized, Validated, Encapsulated, Synchronous, Typed'
        ],
        correctAnswer: 0,
        explanation: 'INVEST defines qualities of well-formed user stories: Independent, Negotiable, Valuable, Estimable, Small, and Testable.'
      }
    ]
  },
  {
    id: 'se-exp3',
    num: 3,
    subjectId: 'se',
    title: 'Software Testing: Basis Path Testing & Cyclomatic Complexity',
    subtitle: 'Control Flow Graphs (CFG), Independent Paths & White-Box Test Case Coverage',
    category: 'Software Testing',
    iitReference: 'Autonomous Curriculum Standards / Software Engineering Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/se-lab/',
    aim: 'To construct the Control Flow Graph (CFG) of a program, calculate McCabe Cyclomatic Complexity V(G), and design a minimal set of test cases for 100% basis path coverage.',
    theory: {
      overview: [
        'White-Box Testing examines the internal structural logic and execution paths of software code.',
        'Basis Path Testing, introduced by Thomas McCabe, derives a logical complexity measure of a procedural design and uses this to define a basis set of execution paths.',
        'Cyclomatic Complexity V(G) defines the number of linearly independent paths through the program graph, guaranteeing that every statement and branch is executed at least once.',
        'Calculated as: V(G) = E - N + 2P, where E = edges, N = nodes, P = connected components (typically 1), or V(G) = Predicate Nodes + 1, or V(G) = Number of Closed Regions + 1.'
      ],
      complexityTable: [
        { parameter: 'Path Coverage', value: '100% statement and branch coverage with V(G) test cases' },
        { parameter: 'Maintainability Threshold', value: 'V(G) <= 10 considered modular and easily testable' }
      ],
      keyPoints: [
        'Control Flow Graph: Nodes represent sequential statements; Edges represent control transfer branches.',
        'Independent Path: Any path that introduces at least one new edge not previously traversed.'
      ],
      realWorldApplications: [
        'Avionics software safety validation (DO-178C Level A requires MC/DC coverage).',
        'Automated code quality gates in CI/CD pipelines (SonarQube quality rules).'
      ]
    },
    algorithm: [
      '1. Take source code with decision constructs (if-else, while, for).',
      '2. Label sequential basic blocks as nodes N1, N2, ..., Nk.',
      '3. Draw directed edges representing execution branches between nodes to form CFG.',
      '4. Count total edges E and nodes N.',
      '5. Compute Cyclomatic Complexity V(G) = E - N + 2.',
      '6. Identify V(G) linearly independent basis paths.',
      '7. Design input test vectors to exercise each basis path and record expected outputs.'
    ],
    procedure: [
      '1. Open the White-Box CFG Simulator.',
      '2. Input code snippet (e.g. Leap Year or Quadratic Solver).',
      '3. Click "Generate CFG" to render node-edge graph.',
      '4. Observe calculated Cyclomatic Complexity V(G).',
      '5. Step through each basis path and execute test suite to achieve 100% coverage.'
    ],
    code: {
      cpp: `// Program to check validity of Triangle
#include <iostream>

int checkTriangle(int a, int b, int c) {
    // Node 1: Entry
    if (a <= 0 || b <= 0 || c <= 0) { // Predicate 1
        return -1; // Node 2: Invalid lengths
    }
    // Node 3: Inequality check
    if (a + b > c && a + c > b && b + c > a) { // Predicate 2
        if (a == b && b == c) { // Predicate 3
            return 1; // Equilateral
        } else if (a == b || b == c || a == c) { // Predicate 4
            return 2; // Isosceles
        } else {
            return 3; // Scalene
        }
    }
    return 0; // Not a triangle
}`,
      python: `def check_triangle(a, b, c):
    if a <= 0 or b <= 0 or c <= 0:
        return -1
    if a + b > c and a + c > b and b + c > a:
        if a == b == c:
            return 1 # Equilateral
        elif a == b or b == c or a == c:
            return 2 # Isosceles
        else:
            return 3 # Scalene
    return 0`
    },
    sampleInput: 'Function checkTriangle(a, b, c) with 4 decision statements',
    expectedOutput: 'Edges: 14, Nodes: 10 -> V(G) = 14 - 10 + 2 = 6 independent basis paths.',
    references: ['Thomas J. McCabe (1976), A Complexity Measure, IEEE Transactions on Software Engineering'],
    conclusion: 'McCabe Cyclomatic Complexity mathematically identified 6 basis paths, achieving 100% branch and statement coverage.',
    quiz: [
      {
        id: 1,
        question: 'If a Control Flow Graph has 14 edges, 10 nodes, and 1 connected component, what is its Cyclomatic Complexity V(G)?',
        options: ['6', '4', '8', '14'],
        correctAnswer: 0,
        explanation: 'Using McCabe’s formula V(G) = E - N + 2P: V(G) = 14 - 10 + 2(1) = 6.'
      }
    ]
  }
];
