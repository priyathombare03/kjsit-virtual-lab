import { LabExperiment } from '../types';

export const ML_EXPERIMENTS: LabExperiment[] = [
  {
    id: 'linear-regression',
    num: 1,
    subjectId: 'aiml',
    title: 'Linear Regression with Gradient Descent',
    subtitle: 'Parameter Optimization, Cost Function Convergence & Ordinary Least Squares',
    category: 'Supervised Learning / Regression',
    iitReference: 'Autonomous Curriculum StandardsPattern Recognition Lab / Autonomous Curriculum StandardsMachine Learning Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in',
    aim: 'To formulate univariate and multivariate linear regression models, minimize the Mean Squared Error (MSE) cost function via Batch Gradient Descent, and study the effect of learning rate (α) on parameter convergence.',
    theory: {
      overview: [
        'Linear Regression models the relationship between a continuous scalar dependent variable Y and one or more explanatory variables (independent features) X via a linear predictor function: ŷ = w·x + b = ∑ wᵢxᵢ + b.',
        'The Mean Squared Error (MSE) cost function J(w, b) measures the discrepancy between predicted values ŷ⁽ⁱ⁾ and actual target labels y⁽ⁱ⁾ across m training examples: J(w, b) = (1 / 2m) ∑ᵢ₌₁ᵐ (ŷ⁽ⁱ⁾ - y⁽ⁱ⁾)²',
        'Gradient Descent iteratively adjusts the model weights w and bias b in the opposite direction of the gradient of J(w, b) scaled by the learning rate α: w := w - α (∂J/∂w), b := b - α (∂J/∂b).',
        'Normal Equation Analytical Solution provides an exact closed-form solution: w* = (Xᵀ X)⁻¹ Xᵀ y when Xᵀ X is non-singular.'
      ],
      complexityTable: [
        { parameter: 'Gradient Descent Time per Epoch', value: 'O(m · d) where m = samples, d = features' },
        { parameter: 'Normal Equation Time', value: 'O(d³) matrix inversion' },
        { parameter: 'Inference Time', value: 'O(d)' },
        { parameter: 'Space Complexity', value: 'O(m · d) for dataset matrix' }
      ],
      keyPoints: [
        'Learning rate α too high causes divergence or oscillation; α too small yields sluggish convergence.',
        'Feature scaling (Z-score standardization: (x - μ)/σ) creates spherical cost contours and accelerates gradient descent.',
        'R² (Coefficient of Determination) evaluates goodness-of-fit: R² = 1 - (SS_res / SS_tot).'
      ],
      realWorldApplications: [
        'Real estate price estimation and market appraisal valuation.',
        'Financial stock yield forecasting and macroeconomic trend analysis.',
        'Sensor calibration and industrial equipment lifecycle degradation modeling.'
      ]
    },
    algorithm: [
      'Step 1: Initialize weights vector w = [0, 0, ..., 0]ᵀ and bias scalar b = 0.',
      'Step 2: For each training epoch = 1 to max_epochs:',
      '  a. Compute predictions for all m samples: ŷ⁽ⁱ⁾ = wᵀ x⁽ⁱ⁾ + b',
      '  b. Compute prediction error: e⁽ⁱ⁾ = (ŷ⁽ⁱ⁾ - y⁽ⁱ⁾)',
      '  c. Compute MSE loss: J(w, b) = (1 / 2m) ∑ (e⁽ⁱ⁾)²',
      '  d. Compute gradients: ∂J/∂w = (1/m) ∑ e⁽ⁱ⁾ x⁽ⁱ⁾ and ∂J/∂b = (1/m) ∑ e⁽ⁱ⁾',
      '  e. Update weights and bias: w := w - α · (∂J/∂w), b := b - α · (∂J/∂b)',
      'Step 3: Terminate if |J_new - J_old| < tolerance ε or epoch limit reached.',
      'Step 4: Output optimal parameters w*, b* and calculate R² test score.'
    ],
    procedure: [
      '1. Load input dataset and split into 80% Training and 20% Testing subsets.',
      '2. Standardize features to mean = 0, std = 1 to prevent skewed gradient trajectories.',
      '3. Set hyperparameter values: Learning Rate α = 0.05, Epochs = 100.',
      '4. Execute Gradient Descent iterations and log the MSE cost after every step.',
      '5. Plot the dynamic regression line overlay on the scatter plot and verify cost reduction.',
      '6. Test parameter generalization on unseen test samples.'
    ],
    code: {
      python: `# Machine Learning Lab (KJSIT Virtual Lab Reference)
# Experiment 1: Linear Regression with Gradient Descent
import numpy as np
import matplotlib.pyplot as plt

class LinearRegressionGD:
    def __init__(self, learning_rate=0.01, epochs=1000):
        self.lr = learning_rate
        self.epochs = epochs
        self.weights = None
        self.bias = None
        self.loss_history = []

    def fit(self, X, y):
        n_samples, n_features = X.shape
        self.weights = np.zeros(n_features)
        self.bias = 0

        for epoch in range(self.epochs):
            y_pred = np.dot(X, self.weights) + self.bias
            loss = (1 / (2 * n_samples)) * np.sum((y_pred - y) ** 2)
            self.loss_history.append(loss)

            # Gradients
            dw = (1 / n_samples) * np.dot(X.T, (y_pred - y))
            db = (1 / n_samples) * np.sum(y_pred - y)

            # Parameter Updates
            self.weights -= self.lr * dw
            self.bias -= self.lr * db

    def predict(self, X):
        return np.dot(X, self.weights) + self.bias

# Synthetic Dataset
np.random.seed(42)
X = 2 * np.random.rand(100, 1)
y = 4 + 3 * X[:, 0] + np.random.randn(100) * 0.5

model = LinearRegressionGD(learning_rate=0.1, epochs=100)
model.fit(X, y)
print(f"Fitted Weight: {model.weights[0]:.4f} (True: 3.0)")
print(f"Fitted Bias: {model.bias:.4f} (True: 4.0)")`,
      cpp: `// Machine Learning Lab - Linear Regression with Gradient Descent
#include <iostream>
#include <vector>
#include <cmath>

struct LinearRegression {
    double weight = 0.0;
    double bias = 0.0;
    double lr;
    int epochs;

    LinearRegression(double learning_rate, int num_epochs) : lr(learning_rate), epochs(num_epochs) {}

    void fit(const std::vector<double>& X, const std::vector<double>& y) {
        int m = X.size();
        for (int ep = 0; ep < epochs; ++ep) {
            double dw = 0.0, db = 0.0, cost = 0.0;
            for (int i = 0; i < m; ++i) {
                double y_pred = weight * X[i] + bias;
                double err = y_pred - y[i];
                cost += err * err;
                dw += err * X[i];
                db += err;
            }
            weight -= lr * (dw / m);
            bias -= lr * (db / m);
        }
    }

    double predict(double x) const {
        return weight * x + bias;
    }
};`,
      c: `/* Machine Learning Lab - Univariate Linear Regression in C */
#include <stdio.h>

void linear_regression_gd(const double x[], const double y[], int n, double lr, int epochs, double *w, double *b) {
    *w = 0.0;
    *b = 0.0;
    for (int epoch = 0; epoch < epochs; epoch++) {
        double dw = 0.0, db = 0.0;
        for (int i = 0; i < n; i++) {
            double pred = (*w) * x[i] + (*b);
            double err = pred - y[i];
            dw += err * x[i];
            db += err;
        }
        *w -= lr * (dw / n);
        *b -= lr * (db / n);
    }
}`,
      java: `// Machine Learning Lab - Linear Regression
public class LinearRegression {
    private double weight = 0.0;
    private double bias = 0.0;

    public void fit(double[] X, double[] y, double lr, int epochs) {
        int m = X.length;
        for (int ep = 0; ep < epochs; ep++) {
            double dw = 0.0, db = 0.0;
            for (int i = 0; i < m; i++) {
                double yPred = weight * X[i] + bias;
                double err = yPred - y[i];
                dw += err * X[i];
                db += err;
            }
            weight -= lr * (dw / m);
            bias -= lr * (db / m);
        }
    }

    public double predict(double x) {
        return weight * x + bias;
    }
}`
    },
    sampleInput: 'Features X = [1.0, 2.0, 3.0, 4.0, 5.0], Labels Y = [2.2, 3.9, 6.1, 7.8, 10.2], LR = 0.01, Epochs = 500',
    expectedOutput: 'Optimal Weight (Slope) w ≈ 1.98, Bias (Intercept) b ≈ 0.14, MSE Loss ≈ 0.0124',
    references: [
      'Christopher Bishop, "Pattern Recognition and Machine Learning", Springer, 2006.',
      'Tom Mitchell, "Machine Learning", McGraw-Hill, 1997.',
      'Autonomous Curriculum StandardsPattern Recognition Lab Manual, vlabs.ac.in'
    ],
    conclusion: 'Gradient descent systematically minimizes the MSE objective function, demonstrating linear convergence to the global optimum due to the convex nature of the squared error loss bowl.',
    quiz: [
      {
        id: 1,
        question: 'Why is the Mean Squared Error (MSE) cost function guaranteed to have a single global minimum in linear regression?',
        options: [
          'Because the cost function is strictly convex (paraboloid in parameter space)',
          'Because linear models cannot handle noise',
          'Because the gradient is always negative',
          'Because the learning rate is fixed'
        ],
        correctAnswer: 0,
        explanation: 'MSE for linear regression is a quadratic function of parameters w and b with a positive semi-definite Hessian matrix, guaranteeing a strictly convex bowl with one global minimum.'
      },
      {
        id: 2,
        question: 'What happens if the learning rate α is chosen too high in gradient descent?',
        options: [
          'The parameters converge faster to the optimum',
          'The algorithm may overshoot the minimum and diverge (loss increases)',
          'The algorithm terminates in 1 epoch',
          'The bias parameter remains zero'
        ],
        correctAnswer: 1,
        explanation: 'An excessively large learning rate causes the step update to bounce across opposite walls of the valley, causing gradient updates to diverge to infinity.'
      },
      {
        id: 3,
        question: 'What is the closed-form equation to find the optimal weights in Ordinary Least Squares (OLS)?',
        options: [
          'w = (Xᵀ X)⁻¹ Xᵀ y',
          'w = Xᵀ y (X Xᵀ)⁻¹',
          'w = (X yᵀ)⁻¹ X',
          'w = X⁻¹ y'
        ],
        correctAnswer: 0,
        explanation: 'The Normal Equation w = (Xᵀ X)⁻¹ Xᵀ y is derived by setting the vector derivative ∂J/∂w = 0 and solving for w.'
      },
      {
        id: 4,
        question: 'What is the role of feature normalization (standardization) before applying gradient descent?',
        options: [
          'It changes non-linear data into linear data',
          'It makes cost function contours circular, enabling direct gradient paths towards the minimum',
          'It eliminates all testing errors',
          'It reduces the number of training samples'
        ],
        correctAnswer: 1,
        explanation: 'When features have different scales, the loss surface is an elongated ellipse. Scaling makes the contours spherical, preventing zig-zag oscillations.'
      }
    ]
  },
  {
    id: 'logistic-regression',
    num: 2,
    subjectId: 'aiml',
    title: 'Logistic Regression & Binary Classification',
    subtitle: 'Sigmoid Activation, Log-Loss Optimization & Decision Boundary',
    category: 'Supervised Learning / Classification',
    iitReference: 'Autonomous Curriculum StandardsMachine Learning Lab / Autonomous Curriculum Standards(vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in',
    aim: 'To implement a Logistic Regression classifier for binary classification, compute log-loss (binary cross-entropy), map probabilities using the Sigmoid function, and visualize the linear decision boundary.',
    theory: {
      overview: [
        'Logistic Regression is a probabilistic linear classifier that estimates the posterior probability P(y=1|x) using the Sigmoid (logistic) function: σ(z) = 1 / (1 + e⁻ᶻ), where z = wᵀ x + b.',
        'The output σ(z) ∈ (0, 1) represents the predicted probability. By default, a decision threshold of 0.5 is applied: ŷ = 1 if σ(z) ≥ 0.5, else ŷ = 0.',
        'Binary Cross-Entropy (Log-Loss) penalizes confident incorrect predictions: J(w, b) = -(1/m) ∑ [y⁽ⁱ⁾ log(ŷ⁽ⁱ⁾) + (1 - y⁽ⁱ⁾) log(1 - ŷ⁽ⁱ⁾)].',
        'The Decision Boundary is the hyper-surface where σ(z) = 0.5, corresponding to the linear hyperplane wᵀ x + b = 0.'
      ],
      complexityTable: [
        { parameter: 'Training Time per Epoch', value: 'O(m · d) via Gradient Descent' },
        { parameter: 'Inference Time', value: 'O(d) for single dot product & sigmoid' },
        { parameter: 'Space Complexity', value: 'O(d) for storing weight vector and bias' },
        { parameter: 'Loss Function Type', value: 'Convex Log-Loss (Cross-Entropy)' }
      ],
      keyPoints: [
        'Sigmoid function maps any real-valued number (-∞, +∞) into the bounded interval (0, 1).',
        'Derivative of Sigmoid is σ\'(z) = σ(z)(1 - σ(z)), which simplifies gradient computation.',
        'Evaluation metrics: Precision = TP/(TP+FP), Recall = TP/(TP+FN), F1-Score = 2·(P·R)/(P+R).'
      ],
      realWorldApplications: [
        'Email spam filtering (Spam vs Ham classification).',
        'Medical diagnosis (Disease positive vs negative prognosis).',
        'Credit card fraud transaction authorization.'
      ]
    },
    algorithm: [
      'Step 1: Initialize weights vector w = 0 and bias b = 0.',
      'Step 2: For each training epoch = 1 to max_epochs:',
      '  a. Compute linear combination: z = X·w + b',
      '  b. Apply sigmoid transformation: ŷ = 1 / (1 + exp(-z))',
      '  c. Compute log-loss: J = -(1/m) ∑ [y·log(ŷ) + (1-y)·log(1-ŷ)]',
      '  d. Compute gradients: dw = (1/m) Xᵀ(ŷ - y), db = (1/m) ∑(ŷ - y)',
      '  e. Update parameters: w := w - α·dw, b := b - α·db',
      'Step 3: Compute decision boundary line: x₂ = -(w₁ x₁ + b) / w₂',
      'Step 4: Generate Confusion Matrix (TP, FP, TN, FN) and compute Accuracy, Precision, Recall.'
    ],
    procedure: [
      '1. Create a 2D synthetic dataset with two separable Gaussian clusters (Class 0 and Class 1).',
      '2. Configure the learning rate α = 0.1 and number of epochs = 200.',
      '3. Run gradient descent and monitor the cross-entropy loss reduction.',
      '4. Draw the linear decision boundary line w₁ x₁ + w₂ x₂ + b = 0 over the 2D feature plane.',
      '5. Vary classification decision threshold from 0.1 to 0.9 and observe changes in the confusion matrix.'
    ],
    code: {
      python: `# Machine Learning Lab (KJSIT Virtual Lab Reference)
# Experiment 2: Logistic Regression Binary Classifier
import numpy as np

class LogisticRegression:
    def __init__(self, lr=0.01, epochs=1000):
        self.lr = lr
        self.epochs = epochs
        self.weights = None
        self.bias = None

    def _sigmoid(self, z):
        return 1.0 / (1.0 + np.exp(-np.clip(z, -250, 250)))

    def fit(self, X, y):
        n_samples, n_features = X.shape
        self.weights = np.zeros(n_features)
        self.bias = 0

        for _ in range(self.epochs):
            linear_model = np.dot(X, self.weights) + self.bias
            y_pred = self._sigmoid(linear_model)

            # Gradient calculation
            dw = (1 / n_samples) * np.dot(X.T, (y_pred - y))
            db = (1 / n_samples) * np.sum(y_pred - y)

            self.weights -= self.lr * dw
            self.bias -= self.lr * db

    def predict_proba(self, X):
        return self._sigmoid(np.dot(X, self.weights) + self.bias)

    def predict(self, X, threshold=0.5):
        return (self.predict_proba(X) >= threshold).astype(int)

# Quick Demo
X_train = np.array([[1, 2], [2, 3], [3, 3], [6, 5], [7, 7], [8, 6]])
y_train = np.array([0, 0, 0, 1, 1, 1])

clf = LogisticRegression(lr=0.1, epochs=500)
clf.fit(X_train, y_train)
print("Predicted probabilities:", clf.predict_proba(X_train))`,
      cpp: `// Machine Learning Lab - Logistic Regression
#include <iostream>
#include <vector>
#include <cmath>

double sigmoid(double z) {
    return 1.0 / (1.0 + std::exp(-z));
}

void train_logistic(const std::vector<std::vector<double>>& X, const std::vector<int>& y, 
                    std::vector<double>& w, double& b, double lr, int epochs) {
    int m = X.size();
    int d = X[0].size();
    w.assign(d, 0.0);
    b = 0.0;

    for (int ep = 0; ep < epochs; ++ep) {
        std::vector<double> dw(d, 0.0);
        double db = 0.0;
        for (int i = 0; i < m; ++i) {
            double z = b;
            for (int j = 0; j < d; ++j) z += w[j] * X[i][j];
            double y_hat = sigmoid(z);
            double err = y_hat - y[i];
            for (int j = 0; j < d; ++j) dw[j] += err * X[i][j];
            db += err;
        }
        for (int j = 0; j < d; ++j) w[j] -= lr * (dw[j] / m);
        b -= lr * (db / m);
    }
}`,
      c: `/* Machine Learning Lab - Logistic Regression */
#include <stdio.h>
#include <math.h>

double sigmoid(double z) {
    return 1.0 / (1.0 + exp(-z));
}`,
      java: `// Machine Learning Lab - Logistic Regression
public class LogisticRegression {
    private double[] w;
    private double b = 0.0;

    public double sigmoid(double z) {
        return 1.0 / (1.0 + Math.exp(-z));
    }
}`
    },
    sampleInput: 'Dataset: 2D Features [[x1, x2]], Labels {0, 1}, Threshold = 0.5',
    expectedOutput: 'Trained Weights w1, w2, Bias b, Confusion Matrix [TP=48, FP=2, FN=1, TN=49], Accuracy = 97%',
    references: [
      'Andrew Ng, "Machine Learning Yearning / CS229 Lecture Notes", Stanford University.',
      'Kevin P. Murphy, "Machine Learning: A Probabilistic Perspective", MIT Press.',
      'Autonomous Curriculum StandardsPattern Recognition Lab Manual (vlabs.ac.in)'
    ],
    conclusion: 'Logistic regression establishes a linear decision boundary in feature space while providing well-calibrated posterior probability outputs through the sigmoid mapping.',
    quiz: [
      {
        id: 1,
        question: 'Why do we use the Sigmoid function instead of a simple linear function for binary classification probabilities?',
        options: [
          'Sigmoid strictly restricts outputs to the range [0, 1] representing valid probabilities',
          'Sigmoid increases the computation time',
          'Sigmoid only works with negative numbers',
          'Sigmoid removes the need for gradient descent'
        ],
        correctAnswer: 0,
        explanation: 'Linear regression predictions can be < 0 or > 1, violating probability axioms. Sigmoid σ(z) = 1/(1+e^-z) maps (-∞, +∞) strictly into (0, 1).'
      },
      {
        id: 2,
        question: 'What is the shape of the decision boundary produced by standard Logistic Regression without polynomial features?',
        options: [
          'Linear (hyperplane)',
          'Circular',
          'Parabolic',
          'Piecewise constant step'
        ],
        correctAnswer: 0,
        explanation: 'The decision threshold σ(wᵀx + b) = 0.5 implies wᵀx + b = 0, which defines a linear hyperplane in feature space.'
      },
      {
        id: 3,
        question: 'Which loss function is used for Logistic Regression to guarantee convexity?',
        options: [
          'Binary Cross-Entropy (Log-Loss)',
          'Mean Squared Error (MSE)',
          'Hinge Loss',
          'Kullback-Leibler Divergence'
        ],
        correctAnswer: 0,
        explanation: 'MSE with sigmoid produces a non-convex loss surface with numerous local minima. Binary Cross-Entropy (Log-Loss) guarantees a convex surface.'
      },
      {
        id: 4,
        question: 'If precision is 1.0 and recall is 0.5, what is the F1-Score?',
        options: [
          '0.67 (2/3)',
          '0.75',
          '0.50',
          '1.00'
        ],
        correctAnswer: 0,
        explanation: 'F1-Score is the harmonic mean: 2 * (1.0 * 0.5) / (1.0 + 0.5) = 1.0 / 1.5 = 2/3 ≈ 0.67.'
      }
    ]
  },
  {
    id: 'knn-classifier',
    num: 3,
    subjectId: 'aiml',
    title: 'K-Nearest Neighbors (K-NN) Classifier',
    subtitle: 'Instance-Based Learning, Distance Metrics & Majority Voting',
    category: 'Supervised Learning / Non-Parametric',
    iitReference: 'Autonomous Curriculum StandardsPattern Recognition Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in',
    aim: 'To implement the K-Nearest Neighbors (K-NN) instance-based classification algorithm, evaluate Euclidean versus Manhattan distance metrics, and examine the effect of K on decision boundary smoothness.',
    theory: {
      overview: [
        'K-Nearest Neighbors (K-NN) is a non-parametric, lazy learning algorithm that stores all training instances in memory and postpones computation until query time.',
        'Given a query instance x_q, the algorithm calculates distance d(x_q, x_i) to every stored training sample x_i using a metric such as Euclidean distance: d_E(p, q) = √(∑ (p_j - q_j)²) or Manhattan distance: d_M(p, q) = ∑ |p_j - q_j|.',
        'It selects the K closest samples (the neighborhood N_K(x_q)) and assigns x_q to the class with the plurality (majority vote) among those K neighbors.',
        'Small K (e.g., K=1) creates complex, jagged decision boundaries sensitive to noise (overfitting). Large K produces smooth boundaries but may blur minor class clusters (underfitting).'
      ],
      complexityTable: [
        { parameter: 'Training Time', value: 'O(1) - No model parameters learned' },
        { parameter: 'Brute-Force Query Time', value: 'O(N · d) where N = training points, d = dimensions' },
        { parameter: 'KD-Tree Query Time', value: 'O(d · log N) in low dimensions' },
        { parameter: 'Space Complexity', value: 'O(N · d) to store all training vectors' }
      ],
      keyPoints: [
        'Distance metrics are highly sensitive to feature scaling; unnormalized features dominate distance calculations.',
        'Odd values of K are preferred in binary classification to prevent voting ties.',
        'Curse of dimensionality causes distance metrics to lose discriminative power in very high dimensions.'
      ],
      realWorldApplications: [
        'Handwritten optical character recognition (OCR) and digit classification.',
        'E-commerce user collaborative filtering and content recommendation.',
        'Facial recognition and biometric matching against reference databases.'
      ]
    },
    algorithm: [
      'Step 1: Store all training samples D = {(x₁, y₁), (x₂, y₂), ..., (xₙ, yₙ)} in memory.',
      'Step 2: Given a query test point x_q and user-specified hyperparameter K:',
      '  a. For each training sample (x_i, y_i) in D, compute distance d(x_q, x_i).',
      '  b. Sort all training samples in ascending order of calculated distance.',
      '  c. Select the first K training samples with the smallest distance values: N_K(x_q).',
      'Step 3: Count class frequencies in N_K(x_q): Count(c) = ∑_{(x_i, y_i) ∈ N_K} I(y_i == c).',
      'Step 4: Assign class label ŷ = argmax_c Count(c) (Majority Plurality Vote).',
      'Step 5: Return predicted class and neighborhood distance breakdown.'
    ],
    procedure: [
      '1. Plot an interactive 2D canvas populated with Red, Blue, and Green training instances.',
      '2. Click anywhere on the canvas to place a new query point X_test.',
      '3. Select K value from 1 to 15 using the slider.',
      '4. Switch distance metric between Euclidean (L2) and Manhattan (L1).',
      '5. Watch the nearest neighbors highlighted with concentric radius circles and connection lines.',
      '6. Check the voting tally and final classified category.'
    ],
    code: {
      python: `# Machine Learning Lab - K-Nearest Neighbors Classifier
import numpy as np
from collections import Counter

class KNNClassifier:
    def __init__(self, k=3, metric='euclidean'):
        self.k = k
        self.metric = metric
        self.X_train = None
        self.y_train = None

    def fit(self, X, y):
        self.X_train = np.array(X)
        self.y_train = np.array(y)

    def _distance(self, x1, x2):
        if self.metric == 'manhattan':
            return np.sum(np.abs(x1 - x2))
        return np.sqrt(np.sum((x1 - x2) ** 2))

    def predict(self, X):
        predictions = []
        for x in X:
            distances = [self._distance(x, x_tr) for x_tr in self.X_train]
            k_indices = np.argsort(distances)[:self.k]
            k_labels = [self.y_train[i] for i in k_indices]
            most_common = Counter(k_labels).most_common(1)[0][0]
            predictions.append(most_common)
        return np.array(predictions)

# Demo
X_train = [[1, 2], [2, 3], [3, 1], [6, 5], [7, 7], [8, 6]]
y_train = [0, 0, 0, 1, 1, 1]
knn = KNNClassifier(k=3)
knn.fit(X_train, y_train)
print("Prediction for [5, 5]:", knn.predict([[5, 5]]))`,
      cpp: `// Machine Learning Lab - K-Nearest Neighbors
#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <map>

struct Point {
    std::vector<double> features;
    int label;
};

int knn_predict(const std::vector<Point>& train_data, const std::vector<double>& query, int k) {
    std::vector<std::pair<double, int>> dists;
    for (const auto& pt : train_data) {
        double d = 0.0;
        for (size_t i = 0; i < query.size(); ++i) {
            d += (pt.features[i] - query[i]) * (pt.features[i] - query[i]);
        }
        dists.push_back({std::sqrt(d), pt.label});
    }
    std::sort(dists.begin(), dists.end());
    std::map<int, int> vote_count;
    for (int i = 0; i < k; ++i) vote_count[dists[i].second]++;
    int best_label = -1, max_votes = -1;
    for (auto& pair : vote_count) {
        if (pair.second > max_votes) {
            max_votes = pair.second;
            best_label = pair.first;
        }
    }
    return best_label;
}`,
      c: `/* Machine Learning Lab - K-NN Classifier */
#include <stdio.h>
#include <math.h>

double euclidean_dist(double x1, double y1, double x2, double y2) {
    return sqrt((x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2));
}`,
      java: `// Machine Learning Lab - K-NN
import java.util.*;

public class KNNClassifier {
    // Stores training vectors and computes majority vote among K nearest
}`
    },
    sampleInput: 'Training points: Class 0 {(1,2), (2,3), (3,1)}, Class 1 {(6,5), (7,7), (8,6)}, Query Point (2.5, 2.5), K=3',
    expectedOutput: '3 Nearest Neighbors: (2,3)[Class 0], (1,2)[Class 0], (3,1)[Class 0] -> Majority Vote: Class 0',
    references: [
      'Cover, T., & Hart, P., "Nearest neighbor pattern classification", IEEE Transactions on Information Theory, 1967.',
      'Autonomous Curriculum StandardsPattern Recognition Lab Manual (vlabs.ac.in)'
    ],
    conclusion: 'K-NN demonstrates effective instance-based classification without requiring explicit parametric training phases, with boundary complexity directly controlled by hyperparameter K.',
    quiz: [
      {
        id: 1,
        question: 'Why is K-NN categorized as a "Lazy Learner"?',
        options: [
          'It does not construct an explicit internal model during training; computation is deferred to query time',
          'It takes a very long time to run',
          'It uses very little CPU memory',
          'It can only learn when K=1'
        ],
        correctAnswer: 0,
        explanation: 'Lazy learning algorithms store training instances without building a general model. Inductive generalization occurs only when a query point must be classified.'
      },
      {
        id: 2,
        question: 'What is the primary drawback of setting K = 1 in K-NN?',
        options: [
          'High risk of overfitting to noise and outliers in training data',
          'Extremely smooth decision boundaries',
          'High computational cost during inference',
          'It cannot classify points into multiple categories'
        ],
        correctAnswer: 0,
        explanation: 'When K=1, a single noisy outlier forms an isolated decision island around itself, causing low bias but high variance (overfitting).'
      },
      {
        id: 3,
        question: 'What is the Euclidean distance between points P(1, 2) and Q(4, 6)?',
        options: [
          '5.0',
          '7.0',
          '25.0',
          '3.5'
        ],
        correctAnswer: 0,
        explanation: 'Euclidean distance = √((4 - 1)² + (6 - 2)²) = √(3² + 4²) = √(9 + 16) = √25 = 5.0.'
      },
      {
        id: 4,
        question: 'How does feature scaling affect K-NN distance computations?',
        options: [
          'Features with large numerical ranges dominate Euclidean distance calculations regardless of their actual relevance',
          'Feature scaling has no effect on K-NN',
          'It changes K from odd to even',
          'It reduces the number of classes'
        ],
        correctAnswer: 0,
        explanation: 'Because distance is computed across raw numerical differences, an unscaled feature with range 0-100,000 will dwarf a feature with range 0-1.'
      }
    ]
  },
  {
    id: 'kmeans-clustering',
    num: 4,
    subjectId: 'aiml',
    title: 'K-Means Clustering & WCSS Analysis',
    subtitle: 'Unsupervised Partitioning, Voronoi Cells & Elbow Method',
    category: 'Unsupervised Learning / Clustering',
    iitReference: 'Autonomous Curriculum StandardsPattern Recognition Lab / Autonomous Curriculum Standards(vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in',
    aim: 'To implement the K-Means unsupervised clustering algorithm (Lloyd’s algorithm), track centroid movements across iterations, minimize Within-Cluster Sum of Squares (WCSS), and identify the optimal K via the Elbow Method.',
    theory: {
      overview: [
        'K-Means is an iterative unsupervised partitioning algorithm that divides an unlabelled dataset D = {x₁, x₂, ..., xₘ} into K disjoint clusters C = {C₁, C₂, ..., C_K}.',
        'Objective Function: Minimize Within-Cluster Sum of Squares (WCSS) or Inertia: J(C, μ) = ∑ₖ₌₁ᴷ ∑_{xᵢ ∈ Cₖ} ||xᵢ - μₖ||², where μₖ is the centroid of cluster Cₖ.',
        'Lloyd’s Algorithm iterates two alternating steps: 1) Assignment Step: Assign each sample xᵢ to its nearest centroid μₖ; 2) Update Step: Recompute each centroid μₖ as the arithmetic mean of points assigned to Cₖ.',
        'The algorithm is guaranteed to converge because WCSS monotonically decreases with each step and the number of possible partitions is finite.'
      ],
      complexityTable: [
        { parameter: 'Time Complexity per Iteration', value: 'O(m · K · d) where m = samples, K = clusters, d = dimensions' },
        { parameter: 'Total Time', value: 'O(I · m · K · d) where I = number of iterations to converge' },
        { parameter: 'Space Complexity', value: 'O(m · d + K · d) for storing points and centroids' },
        { parameter: 'Convergence Guarantee', value: 'Local Minimum (Sensitive to initial seeds)' }
      ],
      keyPoints: [
        'K-Means++ initialization spreads initial centroids far apart, avoiding poor local minima.',
        'Elbow Method plots WCSS vs K to identify the point of diminishing returns (inflection point).',
        'Assumes spherical, equal-variance clusters; struggles with elongated or non-convex densities.'
      ],
      realWorldApplications: [
        'Customer market segmentation based on spending habits and demographic features.',
        'Image compression via color quantization (reducing 16M RGB colors to K representative centroids).',
        'Document and news article topic categorization.'
      ]
    },
    algorithm: [
      'Step 1: Choose number of clusters K.',
      'Step 2: Initialize K centroids μ₁, μ₂, ..., μ_K randomly from data points (or using K-Means++).',
      'Step 3: Repeat until centroids do not change (|μ_new - μ_old| < ε) or max iterations reached:',
      '  a. Assignment Step: For each point xᵢ, assign to cluster c⁽ⁱ⁾ = argmin_k ||xᵢ - μₖ||².',
      '  b. Update Step: For each cluster k = 1 to K:',
      '     If |Cₖ| > 0: μₖ = (1 / |Cₖ|) ∑_{xᵢ ∈ Cₖ} xᵢ.',
      'Step 4: Compute total WCSS: J = ∑ₖ ∑_{x ∈ Cₖ} ||x - μₖ||².',
      'Step 5: Output final cluster assignments and centroid coordinates.'
    ],
    procedure: [
      '1. Generate 2D point clouds with 3 distinct clusters.',
      '2. Select K value from 2 to 6 and initialize centroids.',
      '3. Step through the execution: Watch Voronoi color partitions update, then watch centroids glide to the cluster means.',
      '4. Observe the WCSS metric decrease step-by-step in real-time.',
      '5. Run the Elbow Method to plot WCSS across K=1 to K=8.'
    ],
    code: {
      python: `# Machine Learning Lab - K-Means Clustering
import numpy as np

class KMeans:
    def __init__(self, k=3, max_iters=100, tol=1e-4):
        self.k = k
        self.max_iters = max_iters
        self.tol = tol
        self.centroids = None

    def fit(self, X):
        # Random initial centroids
        np.random.seed(42)
        random_idx = np.random.choice(len(X), self.k, replace=False)
        self.centroids = X[random_idx]

        for _ in range(self.max_iters):
            # Assignment step
            distances = np.linalg.norm(X[:, np.newaxis] - self.centroids, axis=2)
            labels = np.argmin(distances, axis=1)

            # Update step
            new_centroids = np.array([X[labels == k].mean(axis=0) if len(X[labels == k]) > 0 
                                      else self.centroids[k] for k in range(self.k)])

            if np.all(np.abs(new_centroids - self.centroids) < self.tol):
                break
            self.centroids = new_centroids

        return labels

# Demo
X = np.array([[1, 2], [1.5, 1.8], [5, 8], [8, 8], [1, 0.6], [9, 11]])
kmeans = KMeans(k=2)
labels = kmeans.fit(X)
print("Final Centroids:\\n", kmeans.centroids)
print("Cluster Labels:", labels)`,
      cpp: `// Machine Learning Lab - K-Means Clustering
#include <iostream>
#include <vector>
#include <cmath>
#include <limits>

struct Centroid { double x, y; };

void kmeans(const std::vector<Centroid>& data, int k, int iters) {
    // Iterative centroid assignment and mean re-computation
}`,
      c: `/* Machine Learning Lab - K-Means */
#include <stdio.h>
#include <math.h>
`,
      java: `// Machine Learning Lab - K-Means
public class KMeans {
    // Java implementation of Lloyd's K-Means clustering algorithm
}`
    },
    sampleInput: 'Data points [[1,2], [2,1], [1,1], [8,9], [9,8], [8,8]], K = 2',
    expectedOutput: 'Cluster 1 Centroid ≈ (1.33, 1.33), Cluster 2 Centroid ≈ (8.33, 8.33), WCSS converged in 2 iterations',
    references: [
      'Lloyd, S., "Least squares quantization in PCM", IEEE Transactions on Information Theory, 1982.',
      'Arthur, D. & Vassilvitskii, S., "k-means++: The advantages of careful seeding", SODA 2007.',
      'Autonomous Curriculum StandardsPattern Recognition Lab Manual (vlabs.ac.in)'
    ],
    conclusion: 'K-Means partitions unlabelled multidimensional observations into Voronoi cells that minimize within-cluster variance, with the Elbow Method providing an objective heuristic for selecting K.',
    quiz: [
      {
        id: 1,
        question: 'What objective function does K-Means clustering minimize?',
        options: [
          'Within-Cluster Sum of Squares (WCSS / Inertia)',
          'Between-cluster variance',
          'Cross-entropy log-loss',
          'Margin width between support vectors'
        ],
        correctAnswer: 0,
        explanation: 'K-Means minimizes WCSS = ∑ ∑ ||x_i - μ_k||², representing the sum of squared Euclidean distances from each point to its cluster centroid.'
      },
      {
        id: 2,
        question: 'How does the K-Means++ initialization algorithm improve upon standard random seeding?',
        options: [
          'It chooses initial centroids with probability proportional to their squared distance from existing centroids, spreading them out',
          'It uses Decision Trees to find seeds',
          'It runs 1,000 extra gradient descent epochs',
          'It eliminates the need for computing cluster means'
        ],
        correctAnswer: 0,
        explanation: 'K-Means++ samples initial seeds with probability D(x)², dispersing initial centroids to avoid getting trapped in poor local minima.'
      },
      {
        id: 3,
        question: 'In the Elbow Method plot (WCSS vs K), how is the optimal number of clusters chosen?',
        options: [
          'At the "elbow" inflection point where the rate of decrease in WCSS sharply diminishes',
          'At the maximum value of K',
          'At K=1 where WCSS is largest',
          'Where WCSS becomes negative'
        ],
        correctAnswer: 0,
        explanation: 'The elbow indicates the point of diminishing returns where adding more clusters yields negligible reduction in within-cluster variance.'
      },
      {
        id: 4,
        question: 'What is a major limitation of standard K-Means clustering?',
        options: [
          'It assumes clusters are convex and spherical with roughly equal variance',
          'It cannot process numerical data',
          'It cannot run more than 10 iterations',
          'It requires labelled ground-truth data'
        ],
        correctAnswer: 0,
        explanation: 'K-Means uses Euclidean distance from a central point, making it unable to properly cluster arbitrary shapes like concentric circles or non-convex spirals.'
      }
    ]
  },
  {
    id: 'decision-tree',
    num: 5,
    subjectId: 'aiml',
    title: 'Decision Tree Classifier (ID3 / CART)',
    subtitle: 'Shannon Entropy, Information Gain & Gini Impurity Splitting',
    category: 'Supervised Learning / Tree Models',
    iitReference: 'Autonomous Curriculum StandardsMachine Learning Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in',
    aim: 'To construct a Decision Tree classifier using ID3 and CART splitting heuristics, calculate Shannon Entropy, Information Gain, and Gini Impurity, and visualize orthogonal feature space partitions.',
    theory: {
      overview: [
        'Decision Trees are non-parametric supervised models that recursively partition feature space into axis-aligned rectangular regions using hierarchical if-else decision rules.',
        'Shannon Entropy H(S) quantifies the impurity (uncertainty) of a set S with class proportions pᵢ: H(S) = - ∑ᵢ₌₁ᶜ pᵢ log₂(pᵢ). For binary classes, H(S)=1 when classes are split 50/50, and H(S)=0 for pure nodes.',
        'Information Gain IG(S, A) measures the entropy reduction achieved by splitting set S on attribute A: IG(S, A) = H(S) - ∑_{v ∈ Values(A)} (|Sᵥ| / |S|) H(Sᵥ).',
        'Gini Impurity (used in CART) measures the probability of incorrectly classifying a randomly chosen element: Gini(S) = 1 - ∑ᵢ₌₁ᶜ pᵢ².'
      ],
      complexityTable: [
        { parameter: 'Training Time Complexity', value: 'O(d · m log m) for m samples and d features' },
        { parameter: 'Inference Time Complexity', value: 'O(depth) ≤ O(log m) for balanced trees' },
        { parameter: 'Tree Depth Bound', value: 'Max depth controls model variance (pruning prevents overfitting)' },
        { parameter: 'Splitting Heuristic', value: 'Max Information Gain (ID3) / Min Gini (CART)' }
      ],
      keyPoints: [
        'Decision Trees provide high interpretability and feature importance rankings.',
        'Unconstrained trees memorize noise in training data (overfitting); mitigated via pre-pruning (max_depth, min_samples_split) or post-pruning.',
        'Handles both categorical and numerical continuous features without requiring feature scaling.'
      ],
      realWorldApplications: [
        'Loan approval credit risk scoring and default prediction.',
        'Clinical medical diagnosis decision support systems.',
        'Customer churn risk classification and targeted retention campaigns.'
      ]
    },
    algorithm: [
      'Step 1: Calculate total Entropy H(S) of the current training node.',
      'Step 2: For each available feature attribute A:',
      '  a. For continuous features: Sort values and test candidate split thresholds θ.',
      '  b. Split dataset into subsets S_left (x ≤ θ) and S_right (x > θ).',
      '  c. Compute weighted impurity: Impurity(S, A, θ) = (|S_L|/|S|) H(S_L) + (|S_R|/|S|) H(S_R).',
      '  d. Compute Information Gain: IG = H(S) - Impurity(S, A, θ).',
      'Step 3: Select feature A* and threshold θ* with the highest Information Gain.',
      'Step 4: Create a branch for A* ≤ θ* and recurse on subsets until stopping criteria met (max_depth, node pure, or samples < min_samples_split).',
      'Step 5: Assign leaf nodes the majority class label.'
    ],
    procedure: [
      '1. Load the canonical Play Tennis / Weather 2D synthetic dataset.',
      '2. Inspect the mathematical breakdown of Shannon Entropy and Information Gain for each feature.',
      '3. Step through the tree growth process node by node.',
      '4. Observe the corresponding 2D rectangular decision boundaries partitioned on the feature plane.',
      '5. Adjust max_depth slider to visualize tree pruning and generalization trade-offs.'
    ],
    code: {
      python: `# Machine Learning Lab - Decision Tree Classifier (ID3/CART)
import numpy as np

class Node:
    def __init__(self, feature=None, threshold=None, left=None, right=None, value=None):
        self.feature = feature
        self.threshold = threshold
        self.left = left
        self.right = right
        self.value = value

    def is_leaf(self):
        return self.value is not None

def entropy(y):
    hist = np.bincount(y)
    ps = hist / len(y)
    return -np.sum([p * np.log2(p) for p in ps if p > 0])

class DecisionTreeClassifier:
    def __init__(self, max_depth=5):
        self.max_depth = max_depth
        self.root = None

    def fit(self, X, y):
        self.root = self._grow_tree(X, y)

    def _grow_tree(self, X, y, depth=0):
        n_samples, n_features = X.shape
        n_labels = len(np.unique(y))

        if depth >= self.max_depth or n_labels == 1 or n_samples < 2:
            leaf_val = np.argmax(np.bincount(y))
            return Node(value=leaf_val)

        best_gain = -1
        best_feat, best_thresh = None, None

        for feat in range(n_features):
            thresholds = np.unique(X[:, feat])
            for thresh in thresholds:
                gain = self._info_gain(X[:, feat], y, thresh)
                if gain > best_gain:
                    best_gain = gain
                    best_feat = feat
                    best_thresh = thresh

        left_idx = X[:, best_feat] <= best_thresh
        right_idx = X[:, best_feat] > best_thresh
        left = self._grow_tree(X[left_idx], y[left_idx], depth + 1)
        right = self._grow_tree(X[right_idx], y[right_idx], depth + 1)
        return Node(best_feat, best_thresh, left, right)

    def _info_gain(self, X_col, y, thresh):
        parent_ent = entropy(y)
        l_idx, r_idx = X_col <= thresh, X_col > thresh
        if len(y[l_idx]) == 0 or len(y[r_idx]) == 0: return 0
        n = len(y)
        child_ent = (len(y[l_idx])/n)*entropy(y[l_idx]) + (len(y[r_idx])/n)*entropy(y[r_idx])
        return parent_ent - child_ent`,
      cpp: `// Machine Learning Lab - Decision Tree Node
struct TreeNode {
    int feature_idx;
    double threshold;
    int leaf_class;
    TreeNode* left;
    TreeNode* right;
};`,
      c: `/* Machine Learning Lab - Entropy Calculation */
#include <stdio.h>
#include <math.h>

double calc_entropy(int pos, int neg) {
    if (pos == 0 || neg == 0) return 0.0;
    double total = pos + neg;
    double p1 = pos / total, p2 = neg / total;
    return -(p1 * log2(p1) + p2 * log2(p2));
}`,
      java: `// Machine Learning Lab - Decision Tree
public class DecisionTree {
    // Java recursive tree builder with Information Gain splitting
}`
    },
    sampleInput: 'Features: Temperature & Humidity, Labels: Play Tennis {Yes, No}',
    expectedOutput: 'Root Split: Humidity <= 75 (Info Gain = 0.38), Sub-split: Temperature <= 80 -> Leaf Accuracy 100%',
    references: [
      'Quinlan, J. R., "Induction of decision trees", Machine Learning, 1986.',
      'Breiman, L., et al., "Classification and Regression Trees", Wadsworth, 1984.',
      'Autonomous Curriculum StandardsMachine Learning Lab Manual (vlabs.ac.in)'
    ],
    conclusion: 'Decision Trees construct intuitive hierarchical decision rules based on information-theoretic entropy reduction, effectively partitioning feature space into pure class regions.',
    quiz: [
      {
        id: 1,
        question: 'What is the Shannon Entropy of a binary dataset containing 50 positive and 50 negative samples?',
        options: [
          '1.0 bit (Maximum uncertainty)',
          '0.0 bits (Pure set)',
          '0.5 bits',
          '2.0 bits'
        ],
        correctAnswer: 0,
        explanation: 'H(S) = -(0.5 * log2(0.5) + 0.5 * log2(0.5)) = -(-0.5 - 0.5) = 1.0 bit, indicating maximum entropy.'
      },
      {
        id: 2,
        question: 'What is the main purpose of tree pruning in Decision Trees?',
        options: [
          'To prevent overfitting by limiting depth and removing noisy branches that do not generalize',
          'To make the tree calculate faster during training only',
          'To convert categorical data to numeric data',
          'To force the tree to use Gini instead of Entropy'
        ],
        correctAnswer: 0,
        explanation: 'Deep decision trees memorize random noise in training data. Pruning restricts model complexity and improves test accuracy.'
      },
      {
        id: 3,
        question: 'How does Gini Impurity differ from Shannon Entropy?',
        options: [
          'Gini impurity avoids logarithmic calculations, making it computationally faster',
          'Gini impurity only works on text data',
          'Gini impurity can only split on categorical features',
          'Entropy is always between 0 and 0.5'
        ],
        correctAnswer: 0,
        explanation: 'Gini Impurity Gini(S) = 1 - ∑ p_i² uses simple multiplications without computing log2, speeding up candidate split evaluations in CART.'
      },
      {
        id: 4,
        question: 'What type of decision boundaries are created by standard Decision Trees?',
        options: [
          'Axis-aligned orthogonal hyperplanes (horizontal and vertical split lines)',
          'Arbitrary curved polynomials',
          'Concentric circular boundaries',
          'Diagonal hyperplanes'
        ],
        correctAnswer: 0,
        explanation: 'Because each internal node evaluates a single feature x_i ≤ θ, the decision boundaries are orthogonal to the coordinate axes.'
      }
    ]
  },
  {
    id: 'naive-bayes',
    num: 6,
    subjectId: 'aiml',
    title: 'Naive Bayes Classifier',
    subtitle: 'Bayesian Inference, Conditional Independence & Maximum A Posteriori (MAP)',
    category: 'Supervised Learning / Generative Models',
    iitReference: 'Autonomous Curriculum StandardsPattern Recognition Lab / Autonomous Curriculum Standards(vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in',
    aim: 'To implement the Naive Bayes probabilistic classifier using Bayes’ Theorem, apply the conditional independence assumption, estimate Gaussian class-conditional likelihoods, and classify instances using MAP.',
    theory: {
      overview: [
        'Naive Bayes is a generative probabilistic classifier rooted in Bayes’ Theorem: P(y|x) = [P(y) · P(x|y)] / P(x).',
        'Naive Conditional Independence Assumption: All input features x₁, x₂, ..., x_d are mutually conditionally independent given the class label y: P(x|y) = ∏ᵢ₌₁ᵈ P(xᵢ|y).',
        'Maximum A Posteriori (MAP) Decision Rule assigns the class ŷ that maximizes the posterior probability: ŷ = argmax_{c ∈ C} [P(y=c) · ∏ᵢ₌₁ᵈ P(xᵢ|y=c)].',
        'For continuous features, Gaussian Naive Bayes models the likelihood as a normal distribution: P(xᵢ|y=c) = (1 / √(2πσ_c,i²)) · exp(- (xᵢ - μ_c,i)² / (2σ_c,i²)).'
      ],
      complexityTable: [
        { parameter: 'Training Time Complexity', value: 'O(m · d) single pass to compute class priors and feature means/variances' },
        { parameter: 'Inference Time Complexity', value: 'O(C · d) where C = number of classes, d = features' },
        { parameter: 'Space Complexity', value: 'O(C · d) for storing class parameters (means and variances)' },
        { parameter: 'Assumed Independence', value: 'Strong (Naive) feature independence given class' }
      ],
      keyPoints: [
        'Computationally efficient and highly resilient to irrelevant features.',
        'Laplace Smoothing (Additive Smoothing) prevents zero-probability multiplication for unseen categorical features: P(x_i|y) = (count + α) / (total + α·|V|).',
        'Log-posterior transformation prevents floating-point underflow: log P(y|x) ∝ log P(y) + ∑ log P(x_i|y).'
      ],
      realWorldApplications: [
        'Natural language spam detection and document sentiment classification.',
        'Medical diagnosis risk scoring given symptomatic biomarkers.',
        'Real-time multi-class text categorization and news tagging.'
      ]
    },
    algorithm: [
      'Step 1: Compute Prior Probabilities for each class c ∈ C: P(y = c) = N_c / N.',
      'Step 2: For continuous features, compute class-specific mean μ_{c,i} and variance σ²_{c,i} for each feature i:',
      '  μ_{c,i} = (1/N_c) ∑_{x ∈ C_c} x_i,  σ²_{c,i} = (1/N_c) ∑_{x ∈ C_c} (x_i - μ_{c,i})².',
      'Step 3: For a new test sample x = (x₁, x₂, ..., x_d):',
      '  a. For each class c, compute Gaussian likelihood P(x_i | y=c) = (1 / √(2πσ²)) exp(-(x_i - μ)² / (2σ²)).',
      '  b. Compute log-posterior: Score(c) = log P(y=c) + ∑ᵢ₌₁ᵈ log P(x_i | y=c).',
      'Step 4: Output predicted class ŷ = argmax_c Score(c) and normalized posterior probabilities.'
    ],
    procedure: [
      '1. Review training points partitioned across Class A and Class B in 2D space.',
      '2. Inspect the fitted Gaussian likelihood curves $\\mathcal{N}(\\mu, \\sigma^2)$ for each dimension.',
      '3. Move a test slider across the feature spectrum and inspect the live log-posterior probability bars.',
      '4. Observe MAP decision changes as the query shifts across class distributions.'
    ],
    code: {
      python: `# Machine Learning Lab - Gaussian Naive Bayes Classifier
import numpy as np

class GaussianNaiveBayes:
    def fit(self, X, y):
        n_samples, n_features = X.shape
        self.classes = np.unique(y)
        n_classes = len(self.classes)

        self.mean = np.zeros((n_classes, n_features))
        self.var = np.zeros((n_classes, n_features))
        self.priors = np.zeros(n_classes)

        for idx, c in enumerate(self.classes):
            X_c = X[y == c]
            self.mean[idx, :] = X_c.mean(axis=0)
            self.var[idx, :] = X_c.var(axis=0) + 1e-9
            self.priors[idx] = len(X_c) / n_samples

    def predict(self, X):
        return [self._predict_single(x) for x in X]

    def _predict_single(self, x):
        posteriors = []
        for idx, c in enumerate(self.classes):
            prior = np.log(self.priors[idx])
            likelihood = np.sum(np.log(self._pdf(idx, x)))
            posteriors.append(prior + likelihood)
        return self.classes[np.argmax(posteriors)]

    def _pdf(self, class_idx, x):
        mean = self.mean[class_idx]
        var = self.var[class_idx]
        numerator = np.exp(-((x - mean) ** 2) / (2 * var))
        denominator = np.sqrt(2 * np.pi * var)
        return numerator / denominator`,
      cpp: `// Machine Learning Lab - Gaussian Naive Bayes
#include <iostream>
#include <vector>
#include <cmath>

double gaussian_pdf(double x, double mean, double var) {
    double num = std::exp(-((x - mean)*(x - mean)) / (2 * var));
    double den = std::sqrt(2 * M_PI * var);
    return num / den;
}`,
      c: `/* Machine Learning Lab - Naive Bayes */
#include <stdio.h>
#include <math.h>
`,
      java: `// Machine Learning Lab - Gaussian Naive Bayes
public class NaiveBayes {
    // Java Gaussian likelihood computation and MAP decision rule
}`
    },
    sampleInput: 'Prior P(C0)=0.5, P(C1)=0.5; Class 0: μ=2.0, σ²=1.0; Class 1: μ=6.0, σ²=1.0; Query x=2.5',
    expectedOutput: 'P(x|C0) ≈ 0.352, P(x|C1) ≈ 0.0008 -> Predicted Class: 0 (Posterior: 99.7%)',
    references: [
      'Duda, R. O., Hart, P. E., & Stork, D. G., "Pattern Classification", John Wiley & Sons, 2001.',
      'Autonomous Curriculum StandardsPattern Recognition Lab Manual (vlabs.ac.in)'
    ],
    conclusion: 'Naive Bayes delivers robust and exceptionally fast classification by decomposing joint likelihoods into products of univariate conditional probabilities.',
    quiz: [
      {
        id: 1,
        question: 'What is the "Naive" assumption in the Naive Bayes algorithm?',
        options: [
          'All features are conditionally independent given the class label',
          'All classes have equal variance',
          'The data is always linearly separable',
          'Training takes zero CPU cycles'
        ],
        correctAnswer: 0,
        explanation: 'It naively assumes that the occurrence of one feature is statistically independent of another given the target class: P(x1, x2|y) = P(x1|y) * P(x2|y).'
      },
      {
        id: 2,
        question: 'Why do we use Laplace smoothing in Naive Bayes for text classification?',
        options: [
          'To prevent multiplying by zero probability for words not observed in a given class during training',
          'To convert words to numbers',
          'To remove stop words',
          'To calculate gradients'
        ],
        correctAnswer: 0,
        explanation: 'If an unseen word has probability 0, the entire product P(w1|c)*...*P(wn|c) becomes 0. Laplace smoothing adds 1 to all counts to eliminate zero products.'
      },
      {
        id: 3,
        question: 'Why do implementations calculate the sum of log probabilities instead of multiplying raw probabilities?',
        options: [
          'To prevent numerical floating-point underflow caused by multiplying many small numbers < 1',
          'Because log is required by Bayes Theorem',
          'To make the probabilities negative',
          'To double the training speed'
        ],
        correctAnswer: 0,
        explanation: 'Multiplying hundreds of small probabilities (e.g. 0.001) causes arithmetic underflow to 0.0. Taking logs turns products into sums: log(a*b) = log a + log b.'
      },
      {
        id: 4,
        question: 'What is the training time complexity of Naive Bayes?',
        options: [
          'O(N · d) - a single linear pass over the dataset',
          'O(N³ · d) matrix inversion',
          'O(2ᴺ) exponential',
          'O(N² log N)'
        ],
        correctAnswer: 0,
        explanation: 'Naive Bayes requires only one pass through the N samples to accumulate counts, means, and variances for all d features.'
      }
    ]
  },
  {
    id: 'perceptron-neural-net',
    num: 7,
    subjectId: 'aiml',
    title: 'Single & Multi-Layer Perceptron (Neural Network)',
    subtitle: 'Artificial Neuron, Activation Functions & Linear Separability (XOR Problem)',
    category: 'Deep Learning / Neural Networks',
    iitReference: 'Autonomous Curriculum StandardsMachine Learning Lab / Autonomous Curriculum Standards(vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in',
    aim: 'To implement Rosenblatt’s Single-Layer Perceptron learning algorithm, evaluate linear separability for fundamental logic gates (AND, OR, NAND, XOR), and understand how multi-layer architectures resolve the XOR limitation.',
    theory: {
      overview: [
        'The Perceptron is the foundational mathematical model of an artificial biological neuron proposed by Frank Rosenblatt (1958).',
        'Net input aggregation: z = ∑ᵢ₌₁ᵈ wᵢ xᵢ + b = wᵀ x + b. An activation function g(z) applies a threshold: ŷ = 1 if z ≥ 0 else 0 (Step function).',
        'Perceptron Learning Rule: For each misclassified training sample (x⁽ⁱ⁾, y⁽ⁱ⁾), weights and bias are updated via: w := w + η (y⁽ⁱ⁾ - ŷ⁽ⁱ⁾) x⁽ⁱ⁾ and b := b + η (y⁽ⁱ⁾ - ŷ⁽ⁱ⁾), where η ∈ (0, 1] is the learning rate.',
        'Minsky & Papert (1969) proved that a single-layer perceptron can only learn linearly separable functions (like AND, OR, NAND) and fails on non-linear functions like XOR without a hidden layer.'
      ],
      complexityTable: [
        { parameter: 'Perceptron Training Time per Epoch', value: 'O(m · d) where m = samples, d = inputs' },
        { parameter: 'Perceptron Convergence', value: 'Finite steps if data is linearly separable (Novikoff Theorem)' },
        { parameter: 'Activation Functions', value: 'Step, Sigmoid, ReLU, Tanh' },
        { parameter: 'XOR Resolution', value: 'Requires Multi-Layer Perceptron (MLP) with 1 hidden layer' }
      ],
      keyPoints: [
        'Novikoff Perceptron Convergence Theorem guarantees convergence in at most (R/γ)² steps for linearly separable datasets with margin γ.',
        'Modern Multi-Layer Perceptrons (MLPs) use smooth non-linear activations (ReLU, Sigmoid) with Backpropagation gradient descent.',
        'Universal Approximation Theorem states an MLP with one hidden layer can approximate any continuous function.'
      ],
      realWorldApplications: [
        'Logic gate emulation and hardware neuromorphic computing.',
        'Basic binary threshold decision controllers.',
        'Foundational building block for deep convolutional and transformer neural networks.'
      ]
    },
    algorithm: [
      'Step 1: Initialize weights w₁, w₂ = 0 (or small random values) and bias b = 0.',
      'Step 2: Choose learning rate η (e.g., η = 0.1) and select target logic function (AND, OR, NAND, XOR).',
      'Step 3: For each training epoch = 1 to max_epochs:',
      '  a. Set error_count = 0.',
      '  b. For each sample (x⁽ⁱ⁾, y⁽ⁱ⁾) in the truth table:',
      '     i. Compute net sum: z = w₁ x₁ + w₂ x₂ + b.',
      '     ii. Compute prediction: ŷ = 1 if z ≥ 0 else 0.',
      '     iii. Compute error: e = y⁽ⁱ⁾ - ŷ.',
      '     iv. If e ≠ 0:',
      '         w₁ := w₁ + η · e · x₁',
      '         w₂ := w₂ + η · e · x₂',
      '         b := b + η · e',
      '         error_count += 1',
      '  c. If error_count == 0, terminate early (linear convergence reached).',
      'Step 4: Output final decision boundary w₁ x₁ + w₂ x₂ + b = 0 and verify truth table.'
    ],
    procedure: [
      '1. Select a logic gate function: AND, OR, NAND, or XOR.',
      '2. Step through training epochs one step at a time or run auto-train.',
      '3. Watch the weight arrows and decision boundary line rotate across the 4 binary coordinate points.',
      '4. Observe how AND, OR, and NAND converge in 3-5 epochs, while XOR oscillates indefinitely.',
      '5. Switch to 2-Layer Perceptron mode to view how XOR is solved with two intersecting hyperplanes.'
    ],
    code: {
      python: `# Machine Learning Lab - Perceptron Logic Gate Simulator
import numpy as np

class Perceptron:
    def __init__(self, lr=0.1, epochs=100):
        self.lr = lr
        self.epochs = epochs
        self.weights = None
        self.bias = None

    def fit(self, X, y):
        n_samples, n_features = X.shape
        self.weights = np.zeros(n_features)
        self.bias = 0.0

        for epoch in range(self.epochs):
            errors = 0
            for idx, x_i in enumerate(X):
                linear_output = np.dot(x_i, self.weights) + self.bias
                y_pred = 1 if linear_output >= 0 else 0
                error = y[idx] - y_pred
                if error != 0:
                    self.weights += self.lr * error * x_i
                    self.bias += self.lr * error
                    errors += 1
            if errors == 0:
                print(f"Converged at epoch {epoch + 1}")
                break

    def predict(self, X):
        linear_output = np.dot(X, self.weights) + self.bias
        return np.where(linear_output >= 0, 1, 0)

# AND Gate Demo
X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
y_and = np.array([0, 0, 0, 1])

p = Perceptron(lr=0.1, epochs=20)
p.fit(X, y_and)
print("AND Gate Predictions:", p.predict(X))`,
      cpp: `// Machine Learning Lab - Single Perceptron
#include <iostream>
#include <vector>

struct Perceptron {
    double w1 = 0.0, w2 = 0.0, bias = 0.0;
    double lr = 0.1;

    int predict(double x1, double x2) const {
        return (w1 * x1 + w2 * x2 + bias >= 0) ? 1 : 0;
    }
};`,
      c: `/* Machine Learning Lab - Perceptron */
#include <stdio.h>
`,
      java: `// Machine Learning Lab - Perceptron
public class Perceptron {
    // Java artificial neuron with step activation and delta update rule
}`
    },
    sampleInput: 'Logic Gate: AND Gate, Inputs: {(0,0):0, (0,1):0, (1,0):0, (1,1):1}, LR = 0.1',
    expectedOutput: 'Converged in 4 epochs. Weights: w1=0.2, w2=0.1, Bias=-0.2. Accuracy: 100%',
    references: [
      'Rosenblatt, F., "The Perceptron: A probabilistic model for information storage and organization", Psychological Review, 1958.',
      'Minsky, M. & Papert, S., "Perceptrons: An Introduction to Computational Geometry", MIT Press, 1969.',
      'Autonomous Curriculum StandardsMachine Learning Lab Manual (vlabs.ac.in)'
    ],
    conclusion: 'Single-layer perceptrons learn linear separation boundaries for simple Boolean logic, while multi-layer architectures with non-linear activations are required to solve non-linear problems like XOR.',
    quiz: [
      {
        id: 1,
        question: 'Why is a Single-Layer Perceptron fundamentally unable to solve the XOR logic problem?',
        options: [
          'Because XOR is not linearly separable (no single straight line can separate (0,1),(1,0) from (0,0),(1,1))',
          'Because XOR has 4 inputs',
          'Because the learning rate is too small',
          'Because the step function does not work on zeros'
        ],
        correctAnswer: 0,
        explanation: 'XOR outputs 1 for (0,1) and (1,0) and outputs 0 for (0,0) and (1,1). These two classes cannot be partitioned by any single straight line.'
      },
      {
        id: 2,
        question: 'According to the Novikoff Perceptron Convergence Theorem, under what condition is the perceptron guaranteed to converge in finite steps?',
        options: [
          'If the training dataset is strictly linearly separable by some margin γ > 0',
          'Only if the dataset has fewer than 10 samples',
          'Only if the learning rate is 1.0',
          'If all weights are initialized to negative values'
        ],
        correctAnswer: 0,
        explanation: 'Novikoff proved that if data can be separated by a hyperplane with margin γ, the perceptron converges after at most (R/γ)² weight updates.'
      },
      {
        id: 3,
        question: 'What is the mathematical update rule for weights when a perceptron misclassifies a point?',
        options: [
          'w := w + η * (y_true - y_pred) * x',
          'w := w * η / x',
          'w := w + (y_true)² / x',
          'w := 0'
        ],
        correctAnswer: 0,
        explanation: 'The perceptron learning rule shifts weights in the direction of the input vector x scaled by the prediction error (y - ŷ) and learning rate η.'
      },
      {
        id: 4,
        question: 'How do Multi-Layer Perceptrons (MLPs) overcome the XOR limitation?',
        options: [
          'By introducing hidden layers with non-linear activation functions to transform the input space',
          'By running for 100,000 epochs without changing architecture',
          'By removing the bias term',
          'By using negative numbers only'
        ],
        correctAnswer: 0,
        explanation: 'Hidden layer neurons perform non-linear feature mappings, warping the space so that XOR points become linearly separable in the hidden representation.'
      }
    ]
  },
  {
    id: 'svm-classifier',
    num: 8,
    subjectId: 'aiml',
    title: 'Support Vector Machine (SVM) & Kernel Trick',
    subtitle: 'Maximum Margin Hyperplane, Support Vectors & RBF Kernel Transformations',
    category: 'Supervised Learning / Maximum Margin',
    iitReference: 'Autonomous Curriculum StandardsPattern Recognition Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in',
    aim: 'To formulate the Support Vector Machine (SVM) optimization problem, identify support vectors, maximize the geometric margin 2/||w||, and demonstrate non-linear classification using Radial Basis Function (RBF) Kernels.',
    theory: {
      overview: [
        'Support Vector Machines (SVM) find the unique optimal separating hyperplane that maximizes the geometric margin (distance) between two classes: Margin = 2 / ||w||.',
        'Primal Optimization Problem: Minimize (1/2) ||w||² subject to y⁽ⁱ⁾(wᵀ x⁽ⁱ⁾ + b) ≥ 1 - ξᵢ, where ξᵢ ≥ 0 are slack variables penalized by regularization parameter C.',
        'Support Vectors are the critical data points that lie directly on or inside the margin boundaries wᵀ x + b = ±1. The decision boundary is solely determined by these support vectors.',
        'Kernel Trick: Maps non-linearly separable data into a higher-dimensional Hilbert feature space where linear separation is possible without explicitly calculating coordinates: K(x, z) = ⟨Φ(x), Φ(z)⟩. Common kernels include Polynomial and Radial Basis Function (RBF): K(x, z) = exp(-γ ||x - z||²).'
      ],
      complexityTable: [
        { parameter: 'Training Time Complexity', value: 'O(m² · d) to O(m³) for quadratic programming optimization' },
        { parameter: 'Inference Time Complexity', value: 'O(N_sv · d) where N_sv = number of support vectors' },
        { parameter: 'Regularization Parameter C', value: 'High C = Hard margin (low bias, high variance); Low C = Soft margin' },
        { parameter: 'RBF Gamma (γ)', value: 'Controls the radius of influence of each support vector' }
      ],
      keyPoints: [
        'Convex Quadratic Programming formulation guarantees a unique global optimal solution without local minima.',
        'Robust to outliers when configured with an appropriate soft margin parameter C.',
        'Kernel trick enables non-linear boundary learning with infinite-dimensional feature projections.'
      ],
      realWorldApplications: [
        'Bioinformatics protein fold classification and gene expression cancer profiling.',
        'Facial recognition and handwriting digit classification.',
        'Text and hypertext categorization with high-dimensional sparse representations.'
      ]
    },
    algorithm: [
      'Step 1: Choose kernel type (Linear, Polynomial, or Radial Basis Function RBF) and hyperparameter C.',
      'Step 2: Formulate the Dual Lagrangian optimization problem:',
      '  Maximize ∑ᵢ αᵢ - (1/2) ∑ᵢ ∑ⱼ αᵢ αⱼ yᵢ yⱼ K(xᵢ, xⱼ)  subject to 0 ≤ αᵢ ≤ C and ∑ᵢ αᵢ yᵢ = 0.',
      'Step 3: Solve using Sequential Minimal Optimization (SMO) algorithm to obtain optimal Lagrange multipliers α*ᵢ.',
      'Step 4: Identify Support Vectors (samples with α*ᵢ > 0).',
      'Step 5: Compute optimal bias b* from support vectors on the margin.',
      'Step 6: Classify new test query x: f(x) = sign(∑_{i ∈ SV} α*ᵢ yᵢ K(xᵢ, x) + b*).'
    ],
    procedure: [
      '1. Choose between Linearly Separable vs Concentric Circular (Non-Linear) datasets.',
      '2. Adjust Regularization parameter C (0.1 to 100) and RBF Gamma parameter γ.',
      '3. Observe the Optimal Separating Hyperplane and the two parallel margin boundary lines.',
      '4. Notice the glowing highlighted Support Vectors lying exactly on the margin.',
      '5. Switch from Linear Kernel to RBF Kernel to observe non-linear circular decision contours.'
    ],
    code: {
      python: `# Machine Learning Lab - Support Vector Machine (Linear & RBF Kernel)
import numpy as np
from sklearn.svm import SVC
import matplotlib.pyplot as plt

# Generate non-linear concentric dataset
np.random.seed(42)
X = np.random.randn(100, 2)
y = (X[:, 0]**2 + X[:, 1]**2 > 1.2).astype(int)

# Fit SVM with Radial Basis Function (RBF) Kernel
svm_rbf = SVC(kernel='rbf', C=1.0, gamma=0.5)
svm_rbf.fit(X, y)

print(f"Number of Support Vectors: {len(svm_rbf.support_)}")
print(f"Support Vector Indices:\\n{svm_rbf.support_}")
print(f"Intercept: {svm_rbf.intercept_}")`,
      cpp: `// Machine Learning Lab - Linear SVM
#include <iostream>
#include <vector>

struct SVM {
    std::vector<double> w;
    double b = 0.0;
    double C = 1.0;
    // Sequential Minimal Optimization (SMO) solver
};`,
      c: `/* Machine Learning Lab - RBF Kernel */
#include <stdio.h>
#include <math.h>

double rbf_kernel(const double* x1, const double* x2, int dim, double gamma) {
    double dist_sq = 0.0;
    for (int i = 0; i < dim; ++i) {
        dist_sq += (x1[i] - x2[i]) * (x1[i] - x2[i]);
    }
    return exp(-gamma * dist_sq);
}`,
      java: `// Machine Learning Lab - Support Vector Machine
public class SupportVectorMachine {
    // Java implementation of dual Lagrangian quadratic programming
}`
    },
    sampleInput: 'Dataset: 2D Points, Kernel: RBF (gamma=0.5), Regularization C = 1.0',
    expectedOutput: 'Optimal Margin = 1.42, Number of Support Vectors = 14, Test Accuracy = 98.5%',
    references: [
      'Cortes, C., & Vapnik, V., "Support-vector networks", Machine Learning, 1995.',
      'Schölkopf, B., & Smola, A. J., "Learning with Kernels", MIT Press, 2002.',
      'Autonomous Curriculum StandardsPattern Recognition Lab Manual (vlabs.ac.in)'
    ],
    conclusion: 'SVM achieves maximum generalization margins by relying strictly on critical support vectors, while the kernel trick seamlessly elevates non-linear data into linearly separable spaces.',
    quiz: [
      {
        id: 1,
        question: 'What geometric quantity does a Support Vector Machine maximize?',
        options: [
          'The margin (perpendicular distance) between the separating hyperplane and closest data points (2 / ||w||)',
          'The total number of parameters',
          'The sum of squared residuals',
          'The training time'
        ],
        correctAnswer: 0,
        explanation: 'SVM seeks the maximum margin hyperplane with width 2/||w|| to maximize generalization resilience against unseen test data.'
      },
      {
        id: 2,
        question: 'What are "Support Vectors" in an SVM?',
        options: [
          'The critical training points that lie directly on or violate the margin boundaries (α_i > 0)',
          'All points in the training set',
          'The coordinates of the origin',
          'The testing samples only'
        ],
        correctAnswer: 0,
        explanation: 'Support vectors are the subset of training samples with non-zero Lagrange multipliers that determine the position and orientation of the separating hyperplane.'
      },
      {
        id: 3,
        question: 'What is the "Kernel Trick" in Machine Learning?',
        options: [
          'Computing inner products in high-dimensional feature space without explicitly calculating coordinates in that space',
          'A method to delete noisy rows',
          'A technique to speed up K-Means',
          'A way to convert Python code to C'
        ],
        correctAnswer: 0,
        explanation: 'The kernel trick uses kernel functions K(x, z) = ⟨Φ(x), Φ(z)⟩ to evaluate dot products in higher dimensions efficiently without explicit mapping Φ(x).'
      },
      {
        id: 4,
        question: 'What is the effect of setting a very large value for the regularization parameter C in SVM?',
        options: [
          'Hard margin behavior: strictly penalizes margin violations, risking overfitting',
          'Soft margin behavior: allows many points inside the margin',
          'Hyperplane becomes a vertical line always',
          'Eliminates all support vectors'
        ],
        correctAnswer: 0,
        explanation: 'A large C heavily penalizes slack variables ξ_i, forcing the optimization to find a narrow hard margin with zero tolerance for misclassifications.'
      }
    ]
  },
  {
    id: 'pca-reduction',
    num: 9,
    subjectId: 'aiml',
    title: 'Principal Component Analysis (PCA)',
    subtitle: 'Dimensionality Reduction, Covariance Matrix & Eigen Decomposition',
    category: 'Unsupervised Learning / Feature Extraction',
    iitReference: 'Autonomous Curriculum StandardsPattern Recognition Lab / Autonomous Curriculum Standards(vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in',
    aim: 'To implement Principal Component Analysis (PCA) for unsupervised dimensionality reduction, perform mean-centering, compute the sample covariance matrix Σ, solve for eigenvalues and eigenvectors, and project data onto principal axes.',
    theory: {
      overview: [
        'Principal Component Analysis (PCA) is an orthogonal linear transformation technique that maps data from a d-dimensional feature space to a lower k-dimensional subspace (k < d) while preserving maximal variance.',
        'Data Centering: The feature matrix X is centered by subtracting the column mean vector μ: X_centered = X - μ.',
        'Sample Covariance Matrix Σ measures pairwise feature correlations: Σ = (1 / (m - 1)) X_centeredᵀ X_centered.',
        'Eigen Decomposition: Σ vᵢ = λᵢ vᵢ. The eigenvectors vᵢ represent the directions of the principal axes, and the corresponding eigenvalues λᵢ quantify the variance along each axis.',
        'Explained Variance Ratio for component k: EVR_k = λ_k / (∑ⱼ λⱼ). The first Principal Component (PC1) captures the highest possible variance.'
      ],
      complexityTable: [
        { parameter: 'Covariance Matrix Calculation', value: 'O(d² · m) where m = samples, d = features' },
        { parameter: 'Eigenvalue Decomposition', value: 'O(d³) on d × d covariance matrix' },
        { parameter: 'Projection Transformation', value: 'O(m · d · k) to project into k dimensions' },
        { parameter: 'Orthogonality Property', value: 'Principal components are mutually orthogonal (uncorrelated)' }
      ],
      keyPoints: [
        'PCA eliminates multicollinearity by converting correlated features into linearly uncorrelated principal components.',
        'Scree plot displays eigenvalues in descending order to help select the number of retained components k (e.g., retaining 95% total variance).',
        'Data reconstruction approximation from k components: X_reconstructed = (X_projected · V_kᵀ) + μ.'
      ],
      realWorldApplications: [
        'High-dimensional gene microarray data compression and genomics exploration.',
        'Eigenfaces algorithm for facial recognition and compression.',
        'Data visualization of complex multi-attribute industrial datasets in 2D/3D.'
      ]
    },
    algorithm: [
      'Step 1: Given data matrix X of shape (m, d), compute feature means: μ = (1/m) ∑ x⁽ⁱ⁾.',
      'Step 2: Mean-center the data: X̃ = X - μ.',
      'Step 3: Compute the (d × d) Covariance Matrix: Σ = (1 / (m - 1)) X̃ᵀ X̃.',
      'Step 4: Compute eigenvalues {λ₁, λ₂, ..., λ_d} and eigenvectors {v₁, v₂, ..., v_d} of Σ.',
      'Step 5: Sort eigenvalues in descending order: λ₁ ≥ λ₂ ≥ ... ≥ λ_d, and rearrange eigenvectors accordingly.',
      'Step 6: Construct projection matrix W = [v₁, v₂, ..., v_k] consisting of top k eigenvectors.',
      'Step 7: Project data into k-dimensional subspace: Z = X̃ · W.',
      'Step 8: Compute explained variance ratio and reconstruction error.'
    ],
    procedure: [
      '1. Generate a correlated 2D point cloud with strong diagonal variance.',
      '2. Inspect the computed Covariance Matrix Σ, Eigenvalues (λ₁, λ₂), and Eigenvectors (v₁, v₂).',
      '3. Observe the 1st Principal Component (PC1 - green vector) aligning along the direction of maximal spread.',
      '4. Observe the 2nd Principal Component (PC2 - red vector) perpendicular (orthogonal) to PC1.',
      '5. Project 2D points onto the 1D PC1 axis and examine the reconstructed 1D representation.'
    ],
    code: {
      python: `# Machine Learning Lab - Principal Component Analysis (PCA)
import numpy as np

class PCA:
    def __init__(self, n_components=2):
        self.n_components = n_components
        self.components = None
        self.mean = None
        self.explained_variance_ratio = None

    def fit(self, X):
        # Step 1: Mean centering
        self.mean = np.mean(X, axis=0)
        X_centered = X - self.mean

        # Step 2: Covariance matrix
        cov_matrix = np.cov(X_centered, rowvar=False)

        # Step 3: Eigen decomposition
        eigenvalues, eigenvectors = np.linalg.eigh(cov_matrix)

        # Step 4: Sort in descending order
        idx = np.argsort(eigenvalues)[::-1]
        eigenvalues = eigenvalues[idx]
        eigenvectors = eigenvectors[:, idx]

        # Step 5: Store top k components
        self.components = eigenvectors[:, :self.n_components]
        self.explained_variance_ratio = eigenvalues[:self.n_components] / np.sum(eigenvalues)

    def transform(self, X):
        X_centered = X - self.mean
        return np.dot(X_centered, self.components)

# Demo
X = np.array([[2.5, 2.4], [0.5, 0.7], [2.2, 2.9], [1.9, 2.2], [3.1, 3.0], [2.3, 2.7], [2.0, 1.6], [1.0, 1.1], [1.5, 1.6], [1.1, 0.9]])
pca = PCA(n_components=1)
pca.fit(X)
Z = pca.transform(X)
print("PC1 Vector:\\n", pca.components[:, 0])
print(f"Explained Variance Ratio: {pca.explained_variance_ratio[0]*100:.2f}%")`,
      cpp: `// Machine Learning Lab - PCA Covariance
#include <iostream>
#include <vector>
#include <cmath>

struct PCA {
    int n_components;
    // Mean-centering, covariance matrix, and power iteration for top eigenvectors
};`,
      c: `/* Machine Learning Lab - Covariance Calculation */
#include <stdio.h>

void compute_covariance(const double x[], const double y[], int n, double *cov) {
    double mx = 0, my = 0;
    for (int i = 0; i < n; ++i) { mx += x[i]; my += y[i]; }
    mx /= n; my /= n;
    double sum = 0;
    for (int i = 0; i < n; ++i) {
        sum += (x[i] - mx) * (y[i] - my);
    }
    *cov = sum / (n - 1);
}`,
      java: `// Machine Learning Lab - Principal Component Analysis
public class PCA {
    // Java implementation of Eigen decomposition on covariance matrix
}`
    },
    sampleInput: '2D Dataset: 10 Correlated Points, Target Components k = 1',
    expectedOutput: 'Eigenvalues λ1 = 1.28, λ2 = 0.04. PC1 captures 96.9% of total variance. Dimensionality reduced from 2D -> 1D.',
    references: [
      'Pearson, K., "On lines and planes of closest fit to systems of points in space", Philosophical Magazine, 1901.',
      'Jolliffe, I. T., "Principal Component Analysis", Springer-Verlag, 2002.',
      'Autonomous Curriculum StandardsPattern Recognition Lab Manual (vlabs.ac.in)'
    ],
    conclusion: 'Principal Component Analysis effectively projects high-dimensional data onto orthogonal axes of maximum variance, eliminating collinearity and enabling optimal dimensionality reduction.',
    quiz: [
      {
        id: 1,
        question: 'What criterion does the first Principal Component (PC1) satisfy in PCA?',
        options: [
          'It is the linear direction that captures the maximum variance in the centered data',
          'It is always the horizontal x-axis',
          'It minimizes the distance between all data points',
          'It connects the first and last data points'
        ],
        correctAnswer: 0,
        explanation: 'PC1 is the eigenvector corresponding to the largest eigenvalue of the covariance matrix, pointing in the direction of greatest data spread (maximum variance).'
      },
      {
        id: 2,
        question: 'What is the mathematical relationship between the different Principal Components (e.g., PC1 and PC2)?',
        options: [
          'They are mutually orthogonal (perpendicular) and completely uncorrelated (covariance = 0)',
          'They are parallel to each other',
          'PC2 is always 2x larger than PC1',
          'They must sum to 100'
        ],
        correctAnswer: 0,
        explanation: 'Because the covariance matrix is symmetric, its eigenvectors are mutually orthogonal, ensuring that the projected components are linearly uncorrelated.'
      },
      {
        id: 3,
        question: 'Why must data be mean-centered before calculating the covariance matrix and eigenvalues in PCA?',
        options: [
          'To ensure the principal axes pass through the centroid (center of mass) of the data cloud',
          'To remove negative numbers',
          'To make the number of rows equal to the number of columns',
          'To convert labels to integers'
        ],
        correctAnswer: 0,
        explanation: 'Centering (X - μ) places the coordinate origin at the mean of the dataset so that variance is computed with respect to the true central tendency.'
      },
      {
        id: 4,
        question: 'What does a Scree Plot visualize in PCA?',
        options: [
          'The fraction of total variance explained by each principal component in descending order',
          'The training loss over time',
          'The decision boundary of logistic regression',
          'The cluster centers of K-Means'
        ],
        correctAnswer: 0,
        explanation: 'A scree plot graphs eigenvalues (or explained variance ratio) against component numbers to help determine the optimal number of dimensions to retain.'
      }
    ]
  }
];
