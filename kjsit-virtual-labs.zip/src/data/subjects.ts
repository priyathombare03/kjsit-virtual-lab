import { LabSubject } from '../types';

export const LAB_SUBJECTS: LabSubject[] = [
  // Semester 3
  {
    id: 'dsa',
    name: 'Data Structure and Algorithms Laboratory',
    code: 'AIL302',
    department: 'Department of Artificial Intelligence and Data Science',
    semester: 'Semester III (Second Year)',
    description: 'Stacks, Linear Queues, Infix-to-Postfix conversion, Polynomial Arithmetic with dynamic linked lists, Binary Trees, Binary Search Trees, Graph BFS/DFS, and real-world Sorting Applications.',
    iconName: 'Layers',
    isFunctional: true,
    experimentCount: 8,
    tags: ['KJSIT Autonomous', 'AIL302', 'Stacks', 'Linear Queues', 'Infix-to-Postfix', 'Polynomials', 'BST', 'Graph Traversals', 'Sorting Applications'],
    bannerColor: 'from-red-900 via-neutral-950 to-black',
    iitReference: 'KJSIT Autonomous Syllabus / AIL302 Lab Manual'
  },
  {
    id: 'oopm',
    name: 'Object Oriented Programming (OOPM) Lab',
    code: 'CSC303',
    department: 'Department of Artificial Intelligence and Data Science',
    semester: 'Semester III (Second Year)',
    description: 'Official K. J. Somaiya Institute of Technology (KJSIT) Autonomous Lab Manual curriculum. 10 comprehensive experiments covering User Input (Scanner & BufferedReader), Menu-Driven ATM Simulation, Classes & Objects, Constructor Overloading, Hierarchical Inheritance & Method Overriding, Interfaces (Weather Monitoring System), Exception Handling (Custom InsufficientBalanceException), File Handling (Urine Test Strip Results), Multithreading (Square/Cube Threads), and Thread Synchronization (Train Berth Booking).',
    iconName: 'Code2',
    isFunctional: true,
    experimentCount: 10,
    tags: ['KJSIT Autonomous', 'User Input', 'Menu-Driven ATM', 'Classes & Objects', 'Constructors', 'Inheritance', 'Interfaces', 'Exceptions', 'File Handling', 'Multithreading', 'Synchronization'],
    bannerColor: 'from-amber-900 via-neutral-950 to-black',
    iitReference: 'K. J. Somaiya Institute of Technology / OOPM Lab Manual (Department of AI & DS)'
  },
  {
    id: 'daa',
    name: 'Design and Analysis of Algorithms (DAA)',
    code: 'AIL303',
    department: 'Department of Artificial Intelligence and Data Science',
    semester: 'Semester III (Second Year)',
    description: 'Official KJSIT Autonomous Lab Manual curriculum (Dr. Vaishali Wadhe, Prof. Prashant Bhandare). 9 experiments covering Selection Sort, Insertion Sort, Merge Sort, Quick Sort, Kruskal MST, TSP Dynamic Programming, N-Queens Backtracking, Sum of Subsets, and KMP String Matching applied to precision agriculture and climate telemetry.',
    iconName: 'Cpu',
    isFunctional: true,
    experimentCount: 9,
    tags: ['Selection Sort', 'Insertion Sort', 'Merge Sort', 'Quick Sort', 'Kruskal MST', 'TSP DP', 'N-Queens', 'Sum of Subsets', 'KMP Search'],
    bannerColor: 'from-red-800 via-neutral-950 to-black',
    iitReference: 'KJSIT Autonomous Syllabus / AIL303 Lab Manual (Dr. Vaishali Wadhe, Prof. Prashant Bhandare)'
  },

  // Semester 4
  {
    id: 'aoa',
    name: 'Analysis of Algorithm Laboratory',
    code: 'CSC402',
    department: 'Department of Artificial Intelligence and Data Science',
    semester: 'Semester IV (Second Year)',
    description: 'Empirical runtime analysis of Divide & Conquer (Merge/Quick Sort), Greedy strategies (Fractional Knapsack), Dynamic Programming (0/1 Knapsack, LCS), and Backtracking state-space pruning.',
    iconName: 'Cpu',
    isFunctional: true,
    experimentCount: 3,
    tags: ['Analysis of Algorithms', 'Divide & Conquer', 'Greedy Method', 'Dynamic Programming', 'CLRS Standards'],
    bannerColor: 'from-blue-900 via-neutral-950 to-black',
    iitReference: 'Autonomous Curriculum Standards / Analysis of Algorithms Virtual Lab (vlabs.ac.in)'
  },
  {
    id: 'dbms',
    name: 'Database Management Systems (DBMS)',
    code: 'CSC403',
    department: 'Department of Artificial Intelligence and Data Science',
    semester: 'Semester IV (Second Year)',
    description: 'Interactive SQL query executor, ER-to-Relational mapping, Relational Algebra tree evaluator, Normalization (1NF to BCNF) solver, Transaction Serializability & B+ Tree indexing referenced from KJSIT Virtual Labs (vlabs.ac.in).',
    iconName: 'Database',
    isFunctional: true,
    experimentCount: 10,
    tags: ['KJSIT Virtual Lab', 'SQL', 'Relational Algebra', 'Normalization', 'ER Modeling', 'ACID Transactions', 'B+ Tree Indexing', 'PL/SQL'],
    bannerColor: 'from-zinc-900 via-red-950 to-black',
    iitReference: 'Autonomous Curriculum Standards / Database Systems Virtual Lab (vlabs.ac.in)'
  },
  {
    id: 'os',
    name: 'Operating Systems Laboratory',
    code: 'CSC404',
    department: 'Department of Artificial Intelligence and Data Science',
    semester: 'Semester IV (Second Year)',
    description: 'Process hierarchies (fork/exec), CPU scheduling (FCFS, SJF, SRTF, Round Robin, Priority), IPC pipes & shared memory, semaphore synchronization (Dining Philosophers), Banker’s deadlock avoidance, dynamic memory allocation (First/Best/Worst Fit), page replacement (FIFO, LRU, Optimal, Clock), disk arm scheduling (SCAN, SSTF), and POSIX multithreading (pthreads) referenced from KJSIT Virtual Labs (vlabs.ac.in).',
    iconName: 'Terminal',
    isFunctional: true,
    experimentCount: 10,
    tags: ['KJSIT Virtual Lab', 'Process Trees', 'CPU Scheduling', 'Semaphores', 'IPC Pipes', 'Banker’s Algorithm', 'Virtual Memory', 'Disk Arm', 'Pthreads'],
    bannerColor: 'from-red-900 via-zinc-900 to-black',
    iitReference: 'Autonomous Curriculum Standards / Operating Systems Virtual Lab (vlabs.ac.in)'
  },

  // Semester 5
  {
    id: 'ai',
    name: 'Artificial Intelligence Laboratory',
    code: 'CSC501',
    department: 'Department of Artificial Intelligence and Data Science',
    semester: 'Semester V (Third Year)',
    description: 'State-space exploration (BFS/DFS), Heuristic pathfinding (A* Search with Manhattan/Euclidean distance), Minimax with Alpha-Beta Pruning, Constraint Satisfaction Problems (8-Queens, Map Coloring), Propositional Logic Resolution, and Genetic Algorithms.',
    iconName: 'BrainCircuit',
    isFunctional: true,
    experimentCount: 6,
    tags: ['Artificial Intelligence', 'State-Space Search', 'A* Search', 'Alpha-Beta Pruning', 'CSP', 'Logic Inference', 'Genetic Algorithms'],
    bannerColor: 'from-indigo-900 via-zinc-900 to-black',
    iitReference: 'Autonomous Curriculum Standards / Artificial Intelligence Virtual Lab (vlabs.ac.in)'
  },
  {
    id: 'dwm',
    name: 'Data Warehousing and Mining Laboratory',
    code: 'CSC503',
    department: 'Department of Artificial Intelligence and Data Science',
    semester: 'Semester V (Third Year)',
    description: 'Multidimensional Star and Snowflake schema design, OLAP multidimensional operations (Roll-Up, Drill-Down, Slice, Dice, Pivot), Apriori association rule mining, and K-Means clustering with Elbow method.',
    iconName: 'Database',
    isFunctional: true,
    experimentCount: 4,
    tags: ['Data Warehousing', 'Data Mining', 'Star Schema', 'OLAP Cubes', 'Apriori', 'K-Means Clustering'],
    bannerColor: 'from-cyan-900 via-zinc-900 to-black',
    iitReference: 'Autonomous Curriculum Standards / Data Mining Virtual Lab (vlabs.ac.in)'
  },
  {
    id: 'se',
    name: 'Software Engineering Laboratory',
    code: 'CSC505',
    department: 'Department of Artificial Intelligence and Data Science',
    semester: 'Semester V (Third Year)',
    description: 'IEEE Std 830 Software Requirements Specification (SRS), Requirements Traceability Matrices, Agile Scrum Sprint Planning with Planning Poker, Kanban workflows, and Basis Path Testing with McCabe Cyclomatic Complexity.',
    iconName: 'FileText',
    isFunctional: true,
    experimentCount: 3,
    tags: ['Software Engineering', 'IEEE 830 SRS', 'Agile Scrum', 'Story Points', 'Basis Path Testing', 'Cyclomatic Complexity'],
    bannerColor: 'from-emerald-900 via-zinc-900 to-black',
    iitReference: 'Autonomous Curriculum Standards / Software Engineering Virtual Lab (vlabs.ac.in)'
  },

  // Semester 6
  {
    id: 'ann',
    name: 'Artificial Neural Networks Laboratory',
    code: 'CSC602',
    department: 'Department of Artificial Intelligence and Data Science',
    semester: 'Semester VI (Third Year)',
    description: 'McCulloch-Pitts neuron threshold models, Hebbian synaptic weight adaptation, Multi-Layer Perceptron (MLP) with Backpropagation gradient descent solving XOR, and Vanishing Gradient analysis across activation functions (Sigmoid, Tanh, ReLU, Softmax).',
    iconName: 'BrainCircuit',
    isFunctional: true,
    experimentCount: 3,
    tags: ['Neural Networks', 'McCulloch-Pitts', 'Backpropagation', 'MLP', 'ReLU', 'Vanishing Gradient'],
    bannerColor: 'from-violet-900 via-zinc-900 to-black',
    iitReference: 'Autonomous Curriculum Standards / Neural Networks Virtual Lab (vlabs.ac.in)'
  },
  {
    id: 'dav',
    name: 'Data Analytics and Visualization Lab',
    code: 'CSC604',
    department: 'Department of Artificial Intelligence and Data Science',
    semester: 'Semester VI (Third Year)',
    description: 'Exploratory Data Analysis (EDA) and summary statistics, Tukey IQR outlier fences, Pearson and Spearman correlation heatmaps, Collinearity detection, and Principal Component Analysis (PCA) dimensionality reduction with Scree plots.',
    iconName: 'BarChart2',
    isFunctional: true,
    experimentCount: 3,
    tags: ['Data Analytics', 'Visualization', 'EDA', 'Tukey IQR', 'Correlation Heatmap', 'PCA'],
    bannerColor: 'from-teal-900 via-zinc-900 to-black',
    iitReference: 'Autonomous Curriculum Standards / Data Analytics Virtual Lab (vlabs.ac.in)'
  },
  {
    id: 'aiml',
    name: 'Machine Learning & Pattern Recognition Lab',
    code: 'CSC601',
    department: 'Department of Artificial Intelligence and Data Science',
    semester: 'Semester VI (Third Year)',
    description: 'Linear Regression, Logistic Regression, K-NN Classifier, K-Means Clustering, Decision Trees (ID3/CART), Naive Bayes, Support Vector Machines (SVM), Perceptrons & PCA referenced from KJSIT Virtual Labs (vlabs.ac.in).',
    iconName: 'BrainCircuit',
    isFunctional: true,
    experimentCount: 9,
    tags: ['KJSIT Virtual Lab', 'Supervised Learning', 'Unsupervised', 'Neural Networks', 'SVM', 'Clustering', 'Classification', 'PCA'],
    bannerColor: 'from-red-950 via-zinc-900 to-black',
    iitReference: 'Autonomous Curriculum Standards / Pattern Recognition Lab (vlabs.ac.in)'
  },

  // Semester 7
  {
    id: 'nlp',
    name: 'Natural Language Processing Laboratory',
    code: 'CSC701',
    department: 'Department of Artificial Intelligence and Data Science',
    semester: 'Semester VII (Final Year)',
    description: 'Official KJSIT Autonomous Lab Manual curriculum with 8 core practicals: Text Preprocessing (Tokenization, Stopwords, Stemming & Lemmatization in English & Regional Languages), N-Gram Language Models (Unigram, Bigram, Trigram), spaCy POS Tagging & Named Entity Recognition (NER), Naïve Bayes Text Classification with TF-IDF, Dictionary-Based Sentiment Analysis (VADER), Word2Vec Continuous Distributed Embeddings (CBOW & Skip-Gram), Transformer-based BERT with Hugging Face, and LSTM Networks for Sequence Modeling & Next-Word Prediction.',
    iconName: 'Sparkles',
    isFunctional: true,
    experimentCount: 8,
    tags: [
      'Natural Language Processing',
      'Text Preprocessing',
      'Stemming & Lemmatization',
      'N-Gram Models',
      'spaCy POS & NER',
      'Naive Bayes TF-IDF',
      'VADER Sentiment Analysis',
      'Word2Vec Embeddings',
      'BERT Transformers',
      'LSTM Sequence Models'
    ],
    bannerColor: 'from-[#741118] via-[#2E080C] to-[#1d0508]',
    iitReference: 'Autonomous Curriculum Standards / Natural Language Processing Lab Manual (Dept. of AI&DS)'
  },
  {
    id: 'dl',
    name: 'Deep Reinforcement Learning Lab',
    code: 'AIL 702',
    department: 'Department of Artificial Intelligence and Data Science',
    semester: 'Semester VII (Final Year)',
    description: 'Official K. J. Somaiya Institute of Technology (KJSIT) Autonomous Lab Manual curriculum (Prepared by Prof. Devanand K. Bathe, A.Y. 2026-27). 9 comprehensive experiments covering Teachable Machine No-Code AI, XOR Backpropagation MLP, Deep Learning Frameworks (TensorFlow, Keras, MXNet, Theano, CNTK), CNN Digit Classification with Conv2D/MaxPooling, RNNs with LSTM & GRU, Multi-Armed Bandit Epsilon-Greedy, MDP Discount Factors & Returns, Dynamic Programming (Policy & Value Iteration), and Monte Carlo Episode-Based Sampling.',
    iconName: 'BrainCircuit',
    isFunctional: true,
    experimentCount: 9,
    tags: [
      'KJSIT Autonomous',
      'AIL 702',
      'Teachable Machine',
      'XOR Backprop',
      'Keras & TensorFlow',
      'CNN Image Classification',
      'LSTM & GRU RNN',
      'Multi-Armed Bandit',
      'MDP Returns',
      'Dynamic Programming',
      'Monte Carlo Methods'
    ],
    bannerColor: 'from-purple-900 via-zinc-900 to-black',
    iitReference: 'KJSIT Autonomous Syllabus / AIL 702 Lab Manual (Prof. Devanand K. Bathe, Dept. of AI&DS)'
  },

  // Semester 8
  {
    id: 'rpa',
    name: 'Robotic Process Automation Laboratory',
    code: 'CSC801',
    department: 'Department of Artificial Intelligence and Data Science',
    semester: 'Semester VIII (Final Year)',
    description: 'RPA workflow engineering (Sequences, Flowcharts, State Machines), dynamic UI automation with wildcard selectors and Anchor Base, in-memory DataTable Excel transformations, and automated reporting pipelines.',
    iconName: 'Terminal',
    isFunctional: true,
    experimentCount: 3,
    tags: ['Robotic Process Automation', 'Workflows', 'State Machine', 'Dynamic Selectors', 'Wildcards', 'Excel Automation'],
    bannerColor: 'from-rose-900 via-zinc-900 to-black',
    iitReference: 'Autonomous Curriculum Standards / Robotic Process Automation Virtual Lab (vlabs.ac.in)'
  },
  {
    id: 'rl',
    name: 'Reinforcement Learning Laboratory',
    code: 'CSC802',
    department: 'Department of Artificial Intelligence and Data Science',
    semester: 'Semester VIII (Final Year)',
    description: 'Markov Decision Processes (MDP) and Bellman Optimality via Value Iteration, Model-free Temporal Difference control (Q-Learning vs SARSA on Cliff Walking), and Deep Q-Networks (DQN) with Experience Replay for continuous control.',
    iconName: 'BrainCircuit',
    isFunctional: true,
    experimentCount: 3,
    tags: ['Reinforcement Learning', 'Markov Decision Process', 'Value Iteration', 'Q-Learning', 'SARSA', 'DQN', 'CartPole'],
    bannerColor: 'from-red-950 via-zinc-900 to-black',
    iitReference: 'Autonomous Curriculum Standards / Reinforcement Learning Virtual Lab (vlabs.ac.in)'
  }
];
