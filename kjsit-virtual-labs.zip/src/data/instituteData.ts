import kjsitBuildingImg from '../assets/kjsit-building.jpg';

export const INSTITUTE_INFO = {
  name: "K. J. Somaiya Institute of Technology",
  shortName: "KJSIT",
  trust: "Somaiya Vidyavihar University Trust",
  mottoSanskrit: "ज्ञानादेव तु कैवल्यम्",
  mottoEnglish: "Liberation through Knowledge",
  campus: "Somaiya Ayurvihar Complex",
  location: "Eastern Express Highway, Near Everard Nagar, Sion (East), Mumbai - 400 022, Maharashtra, India",
  affiliations: [
    "Autonomous Institute Affiliated to University of Mumbai",
    "Approved by AICTE, New Delhi",
    "Recognized by DTE, Govt. of Maharashtra",
    "Accredited with 'A' Grade by NAAC (3.21 CGPA)",
    "NBA Accredited UG Programs (CE, IT, EXTC, AIDS)",
    "Ranked among Top Engineering Institutions in Mumbai"
  ],
  establishedYear: 2001,
  contact: {
    address: "Somaiya Ayurvihar Complex, Eastern Express Highway, Near Everard Nagar, Sion (East), Mumbai - 400 022, Maharashtra, India",
    phone: "+91 22 2406 1400 / 2406 1403",
    email: "principal.tech@somaiya.edu",
    vlabEmail: "vlab.kjsit@somaiya.edu",
    admissions: "admissions.kjsit@somaiya.edu",
    website: "https://kjsit.somaiya.edu.in"
  },
  vision: "To be a globally recognized institute of excellence in engineering education and research by empowering students with knowledge, skills, ethical values, and sustainable innovations for the betterment of society.",
  mission: [
    "To provide state-of-the-art infrastructure and student-centric academic ambience that fosters experiential and outcome-based learning.",
    "To encourage industry-academia partnerships, interdisciplinary research, entrepreneurial mindset, and innovative problem-solving abilities.",
    "To inculcate ethical values, environmental responsibility, and social accountability through active engagement in community development.",
    "To continuously enhance faculty competence and promote digital pedagogy, including open-access virtual laboratory learning platforms."
  ],
  principal: {
    name: "Dr. Suresh K. Ukarande",
    title: "Principal & Professor",
    qualification: "Ph.D. (Civil Engineering), M.E., B.E., FIE, MISTE",
    message: "In this era of rapid technological transformation, experiential digital learning plays a pivotal role in bridging conceptual theory and practical mastery. KJSIT Virtual Labs initiative is dedicated to providing our students with high-fidelity, self-paced, round-the-clock interactive simulation environments. Through these intuitive algorithm simulators and virtual workstations, students can test edge cases, analyze time complexities, and develop rigorous algorithmic problem-solving instincts.",
    quote: "True engineering begins when theoretical algorithms come alive through curiosity, experimentation, and critical analysis."
  },
  departments: [
    "Department of Computer Engineering",
    "Department of Information Technology",
    "Department of Artificial Intelligence & Data Science",
    "Department of Electronics & Telecommunication Engineering",
    "Department of Science and Humanities"
  ],
  stats: [
    { label: "Active Virtual Labs", value: "8+", sub: "DAA, DSA, CN & Systems" },
    { label: "Interactive Simulations", value: "25+", sub: "Step-by-step Visualizers" },
    { label: "Lab Access", value: "24x7", sub: "Anytime, Anywhere Portal" },
    { label: "NAAC Accreditation", value: "Grade 'A'", sub: "CGPA 3.21 Excellence" },
  ]
};

export const HERO_SLIDES = [
  {
    id: 1,
    title: "Welcome to KJSIT Virtual Labs Portal",
    subtitle: "Autonomous Digital Laboratory Environment for Department of Artificial Intelligence and Data Science",
    badge: "KJSIT Digital Campus Initiative",
    tagline: "Bridging classroom theoretical concepts with step-by-step interactive algorithmic simulations and self-assessment modules.",
    image: "https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?auto=format&fit=crop&w=1600&q=80",
    ctaText: "Explore Virtual Labs",
    ctaAction: "labs"
  },
  {
    id: 2,
    title: "Interactive Algorithm Visualizer & Workstation",
    subtitle: "Design and Analysis of Algorithms (DAA) Laboratory with Live Code Simulators",
    badge: "Hands-On Simulation",
    tagline: "Analyze Divide-and-Conquer, Greedy heuristics, Dynamic Programming, and Backtracking graphs with real-time state tracking.",
    image: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1600&q=80",
    ctaText: "Explore Virtual Labs",
    ctaAction: "labs"
  },
  {
    id: 3,
    title: "Aligned with KJSIT Virtual Labs & AICTE Mandates",
    subtitle: "Experiential Outcome-Based Education (OBE) for Modern Engineering",
    badge: "Accredited Excellence",
    tagline: "Equipped with Aims, In-depth Theory, Complexity Tables, Multi-language Code implementations, and instant Quizzes.",
    image: "https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=1600&q=80",
    ctaText: "Explore Virtual Labs",
    ctaAction: "labs"
  },
  {
    id: 4,
    title: "K. J. Somaiya Institute of Technology, Sion",
    subtitle: "Empowering Next-Generation Engineers with State-of-the-Art Digital Pedagogy",
    badge: "Somaiya Ayurvihar, Mumbai",
    tagline: "Continuous learning without laboratory hardware constraints. Accessible across desktops, tablets, and smartphones.",
    image: kjsitBuildingImg,
    ctaText: "Explore Virtual Labs",
    ctaAction: "labs"
  }
];
