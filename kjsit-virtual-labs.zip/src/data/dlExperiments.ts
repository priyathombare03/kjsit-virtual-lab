import { LabExperiment } from '../types';

export const DL_EXPERIMENTS: LabExperiment[] = [
  // ==========================================
  // Experiment 1
  // ==========================================
  {
    id: 'dl-exp1',
    num: 1,
    subjectId: 'dl',
    title: 'Build Two-Class Machine Learning Models using Teachable Machine',
    subtitle: 'No-Code AI, Web-Based Vision Classifier, TensorFlow.js Export & Real-Time Inference',
    category: 'No-Code AI & Vision',
    iitReference: 'KJSIT Autonomous Syllabus / AIL 702 Lab Manual (Prof. Devanand K. Bathe, Dept. of AI&DS)',
    iitLabUrl: 'https://teachablemachine.withgoogle.com/',
    aim: 'Build two class Machine Learning models using a Teachable Machine.',
    objective: 'To implement basic neural network models for simulating vision classification tasks using a no-code web-based AI environment.',
    labObjectives: [
      'Understand the principles of No-Code AI and transfer learning.',
      'Train a binary image classifier using browser-captured or uploaded image datasets.',
      'Analyze training parameters (Epochs, Batch Size, Learning Rate) and export trained models to TensorFlow.js / Keras.'
    ],
    software: 'Teachable Machine (Google), Web Browser with WebCam / Image Upload, TensorFlow.js',
    theory: {
      overview: [
        'Teachable Machine is a web-based tool developed by Google that makes creating machine learning models fast, easy, and accessible without requiring manual code writing.',
        'It falls under the paradigm of No-Code AI, enabling users to train computer vision, audio, or pose classification models in seconds through interactive data capture.',
        'Transfer Learning Backbone: Behind the scenes, Teachable Machine uses a pre-trained MobileNet neural network model running in the browser using TensorFlow.js and WebGL hardware acceleration.',
        'During training, the base feature extractor weights remain frozen while a custom 2-class dense classification head is fine-tuned on user-provided image samples.',
        'Export Capabilities: Models can be exported directly to TensorFlow.js (for web apps, Glitch, P5.js, Node.js), TensorFlow Lite (Android, Raspberry Pi), and microcontrollers (Coral, Arduino).'
      ],
      complexityTable: [
        { parameter: 'Training Computational Complexity', value: 'O(N · D) where N = sample count, D = transfer feature dimensions (1024-d MobileNet bottleneck)' },
        { parameter: 'Inference Latency', value: '< 20 ms via browser WebGL hardware acceleration' },
        { parameter: 'Input Resolution', value: '224 × 224 RGB pixels (standard MobileNet input shape)' }
      ],
      keyPoints: [
        'No-Code AI: Democratizes machine learning by eliminating syntax barriers while teaching core concepts of class balance, overfitting, and validation.',
        'Data Balance: Both Class 1 and Class 2 should have balanced sample sizes (at least 30-50 diverse samples per class) to avoid biased predictions.',
        'Hyperparameters: Epochs (default 50), Batch Size (default 16), Learning Rate (default 0.001).'
      ],
      realWorldApplications: [
        'Defect detection on automated manufacturing assembly lines.',
        'Face mask compliance and PPE detection systems.',
        'Edge IoT vision sorting devices on Arduino Nano 33 BLE and Raspberry Pi.'
      ]
    },
    algorithm: [
      '1. Initialize Teachable Machine Image Project with Standard Image Model (224x224).',
      '2. Define Class 1 (e.g. "Mask" or "Class A") and capture image samples via webcam or file upload.',
      '3. Define Class 2 (e.g. "No Mask" or "Class B") and capture diverse counter-example samples.',
      '4. Configure training hyperparameters: Epochs = 50, Batch Size = 16, Learning Rate = 0.001.',
      '5. Execute browser-side transfer learning: extract MobileNet feature embeddings and fit softmax classification head.',
      '6. Test live model with webcam preview; evaluate prediction probability bars.',
      '7. Export model as TensorFlow.js JSON/bin or Python Keras code for downstream application integration.'
    ],
    procedure: [
      '1. Open web browser and navigate to teachablemachine.withgoogle.com.',
      '2. Click on "Get Started" to launch the project workbench.',
      '3. Select "Image Project" and choose "Standard Image Model".',
      '4. Label Class 1 and Class 2 with meaningful category names.',
      '5. Capture or upload at least 30 sample images per class with varied lighting and angles.',
      '6. Click "Train Model" and observe the real-time loss graph.',
      '7. Test the trained model in the Preview panel by presenting novel objects.',
      '8. Click "Export Model", select the "Keras" or "TensorFlow.js" tab, and download model files.'
    ],
    code: {
      python: `import tensorflow as tf
from tensorflow import keras
import numpy as np
from PIL import Image, ImageOps

# Disable scientific notation for clarity
np.set_printoptions(suppress=True)

# Load the model exported from Teachable Machine
model = keras.models.load_model("keras_model.h5", compile=False)

# Load the class labels
class_names = open("labels.txt", "r").readlines()

# Prepare input image: 224x224 RGB normalized to [-1, 1]
image = Image.open("test_sample.jpg").convert("RGB")
image = ImageOps.fit(image, (224, 224), Image.Resampling.LANCZOS)
image_array = np.asarray(image)
normalized_image_array = (image_array.astype(np.float32) / 127.5) - 1

# Reshape for model input (batch_size=1, height=224, width=224, channels=3)
data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)
data[0] = normalized_image_array

# Predict class probabilities
prediction = model.predict(data)
index = np.argmax(prediction)
class_name = class_names[index].strip()
confidence_score = float(prediction[0][index])

print(f"Predicted Class: {class_name}")
print(f"Confidence Score: {confidence_score * 100:.2f}%")`,
      javascript: `// TensorFlow.js Inference using Teachable Machine model
const URL = "./my_model/";
let model, webcam, labelContainer, maxPredictions;

async function init() {
    const modelURL = URL + "model.json";
    const metadataURL = URL + "metadata.json";

    // Load the model and metadata
    model = await tmImage.load(modelURL, metadataURL);
    maxPredictions = model.getTotalClasses();

    // Setup webcam
    webcam = new tmImage.Webcam(224, 224, true);
    await webcam.setup();
    await webcam.play();
    window.requestAnimationFrame(loop);
}

async function loop() {
    webcam.update();
    await predict();
    window.requestAnimationFrame(loop);
}

async function predict() {
    // predict can take in an image, video or canvas html element
    const prediction = await model.predict(webcam.canvas);
    for (let i = 0; i < maxPredictions; i++) {
        console.log(prediction[i].className + ": " + prediction[i].probability.toFixed(2));
    }
}`
    },
    sampleInput: '35 sample images of Class 1 (Mask) and 35 sample images of Class 2 (No Mask); Epochs: 50, Batch Size: 16, LR: 0.001',
    expectedOutput: 'Trained model achieving >95% accuracy; real-time inference confidence: Class 1 = 98.4%, Class 2 = 1.6%.',
    references: [
      'Google Creative Lab (2019), Teachable Machine: teachablemachine.withgoogle.com',
      'Howard et al. (2017), MobileNets: Efficient Convolutional Neural Networks for Mobile Vision Applications, arXiv:1704.04861'
    ],
    postLabQuestions: [
      { question: 'What is the role of transfer learning in Teachable Machine?', answer: 'It uses pre-trained weights from MobileNet trained on ImageNet, allowing accurate training with very few user samples.' },
      { question: 'Why must training samples be balanced across both classes?', answer: 'Unbalanced samples cause the model to develop class bias toward the majority class.' },
      { question: 'What formats can Teachable Machine models be exported to?', answer: 'TensorFlow.js (web), TensorFlow (Python/Keras), TensorFlow Lite (mobile/embedded), and Coral/Arduino.' }
    ],
    conclusion: 'Machine learning model is built using a Teachable Machine.',
    quiz: [
      {
        id: 1,
        question: 'Which pre-trained neural network backbone does Teachable Machine leverage for vision classification?',
        options: ['MobileNet', 'ResNet-152', 'VGG-19', 'AlexNet'],
        correctAnswer: 0,
        explanation: 'Teachable Machine uses MobileNet due to its lightweight architecture optimized for real-time in-browser WebGL inference.'
      },
      {
        id: 2,
        question: 'In No-Code AI transfer learning, which layers are primarily trained on the new dataset?',
        options: ['Only the top classification/output layers', 'All convolutional filters from scratch', 'Only the first convolution layer', 'No layers are updated'],
        correctAnswer: 0,
        explanation: 'Transfer learning freezes lower feature extraction layers and only trains the top classification head for the specific classes.'
      }
    ]
  },

  // ==========================================
  // Experiment 2
  // ==========================================
  {
    id: 'dl-exp2',
    num: 2,
    subjectId: 'dl',
    title: 'Implementation of XOR Gate using Backpropagation in Neural Networks',
    subtitle: 'Multi-Layer Perceptron (MLP), Forward Propagation, Error Backpropagation & Gradient Descent',
    category: 'Neural Networks & Backpropagation',
    iitReference: 'KJSIT Autonomous Syllabus / AIL 702 Lab Manual (Prof. Devanand K. Bathe, Dept. of AI&DS)',
    iitLabUrl: 'https://vlab.co.in/dl-lab/',
    aim: 'Implementation of XOR Gate using Backpropagation in Neural Networks',
    objective: 'To implement basic neural network models for simulating logic gates and design feedforward neural networks using backpropagation.',
    labObjectives: [
      'Understand why single-layer perceptrons fail on non-linearly separable problems like XOR.',
      'Implement forward propagation and error backpropagation with non-linear activation functions.',
      'Apply gradient descent weight update rules to achieve zero classification error on XOR.'
    ],
    software: 'Browser (AI DL Virtual Lab), Python / NumPy',
    theory: {
      overview: [
        'The XOR (Exclusive-OR) problem is the classic non-linearly separable classification problem that single-layer perceptrons cannot solve (Minsky & Papert, 1969).',
        'Solving XOR requires a Multi-Layer Perceptron (MLP) containing at least one hidden layer with non-linear activation functions (e.g., Sigmoid, Tanh, or ReLU).',
        'Error Backpropagation is a two-phase supervised training cycle consisting of Propagation and Weight Update:',
        'Phase 1: Forward Propagation - Input vector x is passed through the network: z^[1] = W^[1] x + b^[1], a^[1] = σ(z^[1]), z^[2] = W^[2] a^[1] + b^[2], y_hat = σ(z^[2]). Output error is calculated via MSE loss: E = 0.5 · (y - y_hat)^2.',
        'Phase 1: Backward Propagation - Error deltas are computed at the output: δ^[2] = (y_hat - y) · σ\'(z^[2]), then backpropagated to hidden layer: δ^[1] = (W^[2]^T δ^[2]) ⊙ σ\'(z^[1]).',
        'Phase 2: Weight Update - Gradients are subtracted using learning rate η: W := W - η · (δ · a^T).'
      ],
      complexityTable: [
        { parameter: 'Time Complexity per Epoch', value: 'O(|V| + |E|) = O(N_in · N_hidden + N_hidden · N_out)' },
        { parameter: 'Architecture', value: '2 Input Neurons → 2 Hidden Neurons → 1 Output Neuron' },
        { parameter: 'Loss Function', value: 'Mean Squared Error (MSE): L = (1/2) · Σ (y - y_hat)^2' }
      ],
      keyPoints: [
        'Linear Inseparability: Points (0,0)→0, (0,1)→1, (1,0)→1, (1,1)→0 cannot be separated by a single straight decision boundary in 2D space.',
        'Differentiable Activations: Backpropagation requires differentiable non-linearities. For Sigmoid σ(z) = 1/(1 + e^-z), the derivative is σ\'(z) = σ(z)(1 - σ(z)).',
        'Learning Rate (η): Higher η speeds up learning but risks oscillation; lower η ensures stability but requires more training epochs.'
      ],
      realWorldApplications: [
        'Foundational building block for all deep neural networks.',
        'Parity checking and error-detection circuits.',
        'Non-linear pattern separation in biometric classification.'
      ]
    },
    algorithm: [
      '1. Initialize network architecture: 2 inputs, 2 hidden neurons, 1 output neuron.',
      '2. Initialize weights W1 (2x2), W2 (1x2), and biases b1 (2x1), b2 (1x1) with small random values.',
      '3. For each training epoch (until error < ε or max epochs reached):',
      '    a. Forward Pass: For each sample (x1, x2) with target y:',
      '       Compute hidden activations: a1 = σ(W1 · x + b1).',
      '       Compute output activation: y_hat = σ(W2 · a1 + b2).',
      '    b. Compute Loss: E = 0.5 * (y - y_hat)^2.',
      '    c. Backward Pass:',
      '       Output delta: δ_out = (y_hat - y) * y_hat * (1 - y_hat).',
      '       Hidden delta: δ_hidden = (W2^T · δ_out) * a1 * (1 - a1).',
      '    d. Weight Update:',
      '       W2 := W2 - η * (δ_out · a1^T),  b2 := b2 - η * δ_out.',
      '       W1 := W1 - η * (δ_hidden · x^T),  b1 := b1 - η * δ_hidden.',
      '4. Evaluate converged network on all four XOR combinations.'
    ],
    procedure: [
      '1. Open the XOR Backpropagation Simulator workbench.',
      '2. Configure hyperparameters: Learning Rate (e.g. 0.5), Target Error Threshold (0.01), Max Epochs (10000).',
      '3. Click "Initialize Weights" to generate random synaptic connections.',
      '4. Step through single training iterations to observe forward activations, delta errors, and gradient updates.',
      '5. Run full training and monitor the epoch loss curve descending toward zero.',
      '6. Verify the final truth table predictions: (0,0)->0, (0,1)->1, (1,0)->1, (1,1)->0.'
    ],
    code: {
      python: `import numpy as np

# Sigmoid activation and its derivative
def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))

def sigmoid_derivative(x):
    s = sigmoid(x)
    return s * (1.0 - s)

# XOR Dataset
X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
y = np.array([[0], [1], [1], [0]])

# Set random seed for reproducibility
np.random.seed(42)

# Architecture: 2 inputs, 2 hidden neurons, 1 output neuron
input_dim, hidden_dim, output_dim = 2, 2, 1
W1 = np.random.uniform(-1, 1, (input_dim, hidden_dim))
b1 = np.zeros((1, hidden_dim))
W2 = np.random.uniform(-1, 1, (hidden_dim, output_dim))
b2 = np.zeros((1, output_dim))

learning_rate = 0.5
epochs = 10000

# Training Loop
for epoch in range(epochs):
    # Phase 1: Forward Propagation
    z1 = np.dot(X, W1) + b1
    a1 = sigmoid(z1)
    z2 = np.dot(a1, W2) + b2
    y_pred = sigmoid(z2)

    # Compute loss (MSE)
    loss = np.mean(0.5 * (y - y_pred) ** 2)

    # Phase 2: Error Backpropagation
    delta2 = (y_pred - y) * (y_pred * (1.0 - y_pred))
    delta1 = np.dot(delta2, W2.T) * (a1 * (1.0 - a1))

    # Weight Updates (Gradient Descent)
    W2 -= learning_rate * np.dot(a1.T, delta2)
    b2 -= learning_rate * np.sum(delta2, axis=0, keepdims=True)
    W1 -= learning_rate * np.dot(X.T, delta1)
    b1 -= learning_rate * np.sum(delta1, axis=0, keepdims=True)

    if epoch % 2000 == 0:
        print(f"Epoch {epoch:5d} | MSE Loss: {loss:.6f}")

print("\\nTrained XOR Model Predictions:")
for i in range(len(X)):
    pred = sigmoid(np.dot(sigmoid(np.dot(X[i], W1) + b1), W2) + b2)
    print(f"Input: {X[i]} -> Output: {pred[0][0]:.4f} (Round: {round(pred[0][0])})")`
    },
    sampleInput: 'XOR Truth Table: [0,0]->0, [0,1]->1, [1,0]->1, [1,1]->0; Learning Rate = 0.5',
    expectedOutput: 'Converged predictions: [0,0]->0.02, [0,1]->0.97, [1,0]->0.97, [1,1]->0.03; Loss < 0.001.',
    references: [
      'Rumelhart, Hinton, & Williams (1986), Learning representations by back-propagating errors, Nature 323, 533–536',
      'Minsky, M., & Papert, S. (1969), Perceptrons: An introduction to computational geometry, MIT Press'
    ],
    postLabQuestions: [
      { question: 'Why cannot a single perceptron solve the XOR function?', answer: 'A single perceptron creates a linear hyperplane. In XOR, points (0,1) and (1,0) cannot be separated from (0,0) and (1,1) by any single line.' },
      { question: 'What is the role of non-linear activation functions in hidden layers?', answer: 'Without non-linear activations, stacking multiple linear layers collapses mathematically into a single linear transformation.' },
      { question: 'How does the learning rate affect gradient descent?', answer: 'Too high causes oscillations and overshooting; too low leads to exceedingly slow convergence or getting trapped in local minima.' }
    ],
    conclusion: 'XOR Gate is implemented using Backpropagation in Neural Networks using a virtual lab.',
    quiz: [
      {
        id: 1,
        question: 'Why was the XOR problem historically significant in neural network history?',
        options: [
          'It proved single-layer perceptrons cannot separate non-linear data, prompting multi-layer research',
          'It proved neural networks cannot solve any logic problems',
          'It showed that backpropagation is mathematically impossible',
          'It required quantum computers to solve'
        ],
        correctAnswer: 0,
        explanation: 'Minsky and Papert demonstrated in 1969 that single-layer perceptrons cannot solve XOR, necessitating multi-layer architectures with backpropagation.'
      },
      {
        id: 2,
        question: 'What is the mathematical derivative of the sigmoid function σ(z)?',
        options: ['σ(z) · (1 - σ(z))', '1 - σ(z)', 'σ(z)^2', 'e^-z'],
        correctAnswer: 0,
        explanation: 'The derivative of sigmoid is d/dz[σ(z)] = σ(z)(1 - σ(z)), making gradient computation extremely efficient.'
      }
    ]
  },

  // ==========================================
  // Experiment 3
  // ==========================================
  {
    id: 'dl-exp3',
    num: 3,
    subjectId: 'dl',
    title: 'Exploring Modern Deep Learning Libraries (TensorFlow, Keras, Theano, MXNet, CNTK)',
    subtitle: 'Framework Architecture, Autograd, Computation Graphs, Keras Sequential & Functional APIs',
    category: 'Deep Learning Frameworks',
    iitReference: 'KJSIT Autonomous Syllabus / AIL 702 Lab Manual (Prof. Devanand K. Bathe, Dept. of AI&DS)',
    iitLabUrl: 'https://colab.research.google.com/',
    aim: 'To Explore all deep learning libraries e.g. Theano, Tensor Flow, Lasagne, Keras MXNet etc.',
    objective: 'To survey and implement neural network models across major open-source deep learning frameworks.',
    labObjectives: [
      'Compare deep learning ecosystems: TensorFlow, PyTorch, Keras, Apache MXNet, Theano, and Microsoft CNTK.',
      'Understand symbolic computation graphs vs dynamic eager execution.',
      'Construct neural networks using Keras Sequential and Functional APIs.'
    ],
    software: 'Google Colab, Python 3.x, TensorFlow 2.x, Keras, Apache MXNet',
    theory: {
      overview: [
        'Modern deep learning libraries provide tensor computation with GPU acceleration and automatic differentiation engines.',
        'TensorFlow: Developed by Google Brain, open-sourced on Nov 9, 2015 under Apache 2.0. Supports multi-CPU/GPU/TPU execution, distributed training, mobile deployment (TF Lite), and web runtime (TF.js).',
        'Theano: Pioneered by the MILA group at the University of Montreal. It was one of the earliest libraries to compile symbolic mathematical graphs to efficient GPU CUDA code.',
        'CNTK (Microsoft Cognitive Toolkit): Enterprise deep learning system from Microsoft with high-efficiency speech and text processing, C++/Python training, and C#/Java inference.',
        'Apache MXNet: Ultra-scalable deep learning framework featuring Autograd, NDArray, KVStore (multi-GPU parameter synchronization), and the Gluon imperative API.',
        'Keras: Created by Francois Chollet (Google). High-level, modular neural network API that originally ran atop TensorFlow, Theano, or CNTK, and is now deeply integrated into TensorFlow.'
      ],
      complexityTable: [
        { parameter: 'TensorFlow Execution', value: 'Eager Execution by default (dynamic graph) + @tf.function (static graph)' },
        { parameter: 'Keras APIs', value: 'Sequential API (linear stack) & Functional API (arbitrary multi-input/output DAGs)' },
        { parameter: 'GPU Acceleration', value: 'NVIDIA CUDA / cuDNN backend with automatic mixed precision (FP16/FP32)' }
      ],
      keyPoints: [
        'Sequential API: Ideal for simple feedforward stacks where each layer has exactly one input tensor and one output tensor.',
        'Functional API: Essential for complex architectures like residual connections (ResNet), multi-branch networks, and feature pyramid models.',
        'MXNet Packages: Autograd (automatic differentiation), NDArray (n-dimensional tensors), KVStore (distributed sync), Gluon (clean high-level API).'
      ],
      realWorldApplications: [
        'Production deep learning pipelines across cloud and mobile platforms.',
        'High-performance distributed training on multi-node GPU/TPU clusters.',
        'Cross-platform deployment from servers to edge microcontrollers.'
      ]
    },
    algorithm: [
      '1. Import deep learning framework modules (tensorflow.keras.models, layers).',
      '2. Compare architectural capabilities of TensorFlow, MXNet, PyTorch, and Keras.',
      '3. Define a Sequential Neural Network model for 784-dimensional flattened inputs.',
      '4. Add Dense layers with ReLU and Softmax activations.',
      '5. Compile model specifying optimizer (Adam/SGD), loss function (Categorical Crossentropy), and evaluation metrics.',
      '6. Inspect model summary, parameter counts, and tensor shape propagation.',
      '7. Execute forward pass with dummy batch to verify graph compilation.'
    ],
    procedure: [
      '1. Open Google Colab environment with Python 3 runtime.',
      '2. Verify GPU availability using tf.config.list_physical_devices(\'GPU\').',
      '3. Construct a Keras Sequential model with Dense(32, input_shape=(784,)), ReLU, Dense(10), Softmax.',
      '4. Construct the equivalent model using Keras Functional API.',
      '5. Print model.summary() and calculate trainable parameter counts manually to verify understanding.',
      '6. Compile and test execution on synthetic tensor data.'
    ],
    code: {
      python: `import tensorflow as tf
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import Dense, Activation, Input

print(f"TensorFlow Version: {tf.__version__}")
print(f"GPUs Available: {tf.config.list_physical_devices('GPU')}")

# ==========================================
# 1. Keras Sequential Model
# ==========================================
sequential_model = Sequential([
    Dense(32, input_shape=(784,), name="dense_hidden"),
    Activation('relu', name="relu_act"),
    Dense(10, name="dense_output"),
    Activation('softmax', name="softmax_act")
], name="Sequential_Classifier")

sequential_model.compile(
    optimizer='adam',
    loss='categorical_crossentropy',
    metrics=['accuracy']
)

print("\\n--- Sequential Model Architecture ---")
sequential_model.summary()

# ==========================================
# 2. Keras Functional API Model
# ==========================================
inputs = Input(shape=(784,), name="input_tensor")
x = Dense(64, activation='relu', name="hidden_layer_1")(inputs)
x = Dense(32, activation='relu', name="hidden_layer_2")(x)
outputs = Dense(10, activation='softmax', name="output_probabilities")(x)

functional_model = Model(inputs=inputs, outputs=outputs, name="Functional_Classifier")
functional_model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

print("\\n--- Functional API Model Architecture ---")
functional_model.summary()`
    },
    sampleInput: 'Input shape: (batch_size, 784) representing 28x28 flattened image vectors',
    expectedOutput: 'Model summary displaying 25,450 parameters for hidden layer and 330 parameters for output layer; Total: 25,780 params.',
    references: [
      'Chollet, Francois (2017), Deep Learning with Python, Manning Publications',
      'Abadi et al. (2016), TensorFlow: A System for Large-Scale Machine Learning, OSDI 16'
    ],
    postLabQuestions: [
      { question: 'What is the key difference between Keras Sequential and Functional API?', answer: 'Sequential API only allows linear single-input single-output stacks. Functional API allows arbitrary directed acyclic graphs (DAGs) with multiple inputs, outputs, and skip connections.' },
      { question: 'What is Autograd in frameworks like MXNet and PyTorch?', answer: 'Autograd is an automatic differentiation engine that records tensor operations dynamically to compute gradients via reverse-mode automatic differentiation.' },
      { question: 'Why did the deep learning community transition toward eager execution?', answer: 'Eager execution evaluates operations immediately, enabling standard Python debugging (pdb), dynamic control flow (loops, ifs), and faster prototyping.' }
    ],
    conclusion: 'Modern deep learning frameworks are explored.',
    quiz: [
      {
        id: 1,
        question: 'Who developed Keras and when was it first released?',
        options: ['Francois Chollet (2015)', 'Yann LeCun (2010)', 'Geoffrey Hinton (2006)', 'Andrew Ng (2012)'],
        correctAnswer: 0,
        explanation: 'Keras was created by Google AI researcher Francois Chollet in 2015 to make deep learning experimentation fast and accessible.'
      },
      {
        id: 2,
        question: 'How many parameters does a Dense layer with 784 inputs and 32 neurons have (including biases)?',
        options: ['25,120', '25,088', '24,304', '7,840'],
        correctAnswer: 0,
        explanation: 'Formula: (Weights) + (Biases) = (784 * 32) + 32 = 25,088 + 32 = 25,120 parameters.'
      }
    ]
  },

  // ==========================================
  // Experiment 4
  // ==========================================
  {
    id: 'dl-exp4',
    num: 4,
    subjectId: 'dl',
    title: 'Design & Implementation of CNN for Multiclass Object Classification on Image Data',
    subtitle: 'Digit Classification (0-9) using Keras API with Conv2D, Maxpooling, Dropout & Dense Layers',
    category: 'Computer Vision & CNN',
    iitReference: 'KJSIT Autonomous Syllabus / AIL 702 Lab Manual (Prof. Devanand K. Bathe, Dept. of AI&DS)',
    iitLabUrl: 'https://vlab.co.in/dl-lab/',
    aim: 'To design and implement a CNN for Multiclass Object classification on image data. a) Classification of digits from 0 to 9 using keras API and training using layers of Conv2D, Maxpooling, Dropout etc.',
    objective: 'To design, train, and evaluate deep convolutional neural networks for multiclass spatial pattern recognition.',
    labObjectives: [
      'Understand 2D convolution operations, kernels/filters, feature maps, and receptive fields.',
      'Implement downsampling via MaxPooling2D to reduce spatial dimensions and prevent overfitting.',
      'Integrate Dropout regularization and train an end-to-end MNIST digit classifier achieving >98% test accuracy.'
    ],
    software: 'Keras library, Google Colab, TensorFlow',
    theory: {
      overview: [
        'Convolutional Neural Networks (CNNs / ConvNets) explicitly exploit the 2D spatial grid topology of images (height, width, color channels).',
        'Key Inductive Biases: Local Receptive Fields (neurons connect only to local neighborhoods) and Weight Sharing (the same filter slides across the entire image, detecting features invariant to position).',
        'Convolutional Layer (Conv2D): Slides learnable filters (e.g. 3x3) over the input volume, computing element-wise dot products to produce 2D feature maps detecting edges, corners, and textures.',
        'Stride & Padding: Stride (S) is the step size. Padding (P) controls boundary conditions. Output size formula: O = ((W - K + 2P) / S) + 1.',
        'Max Pooling Layer: Non-linear downsampling that slides a window (typically 2x2 with stride 2) and takes the maximum activation, halving height and width while preserving dominant features without adding learnable parameters.',
        'Dropout: Regularization technique (Srivastava et al., 2014) that randomly sets a fraction (e.g. 25% or 50%) of neuron activations to zero during training, preventing co-adaptation of features.',
        'Flatten & Dense (FC) Layers: Flattens the 3D volume into a 1D feature vector and passes it through fully connected layers terminating with a 10-way Softmax output layer.'
      ],
      complexityTable: [
        { parameter: 'Conv2D Output Size', value: 'O = floor((W - K + 2P) / S) + 1' },
        { parameter: 'Conv2D Parameters', value: 'K_h · K_w · C_in · C_out + C_out (biases)' },
        { parameter: 'MaxPooling Parameters', value: '0 (Deterministic maximum operator, no learnable weights)' }
      ],
      keyPoints: [
        'Hierarchical Feature Representation: Early layers capture low-level lines and edges; middle layers combine them into parts; deep layers classify semantic objects.',
        'Softmax Activation: Normalizes 10 raw logits into probability distribution: P(y=c|x) = e^(z_c) / Σ_j e^(z_j).',
        'Categorical Crossentropy: Loss function measuring cross-entropy divergence between one-hot ground truth and predicted softmax probabilities.'
      ],
      realWorldApplications: [
        'Automated postal zip code digit recognition (USPS / LeNet-5).',
        'Autonomous driving camera perception (pedestrian, traffic sign, lane detection).',
        'Medical radiography analysis (X-ray fracture and lung opacity detection).'
      ]
    },
    algorithm: [
      '1. Load MNIST dataset of 70,000 28x28 grayscale handwritten digits (60,000 train, 10,000 test).',
      '2. Normalize pixel intensities from [0, 255] to [0.0, 1.0] and reshape to (28, 28, 1).',
      '3. One-hot encode target labels (0 to 9) into 10-dimensional binary vectors.',
      '4. Build CNN Architecture:',
      '    a. Conv2D(32 filters, 3x3 kernel, activation=\'relu\', input_shape=(28, 28, 1)) -> Output: (26, 26, 32).',
      '    b. MaxPooling2D(pool_size=(2, 2)) -> Output: (13, 13, 32).',
      '    c. Conv2D(64 filters, 3x3 kernel, activation=\'relu\') -> Output: (11, 11, 64).',
      '    d. MaxPooling2D(pool_size=(2, 2)) -> Output: (5, 5, 64).',
      '    e. Dropout(0.25) to regularize convolution features.',
      '    f. Flatten() -> Output: 1600-dimensional vector.',
      '    g. Dense(128, activation=\'relu\') and Dropout(0.5).',
      '    h. Dense(10, activation=\'softmax\') for 10-digit multiclass prediction.',
      '5. Compile with Adam optimizer and categorical_crossentropy loss.',
      '6. Train for 10 epochs with batch size 128; evaluate on unseen test set.'
    ],
    procedure: [
      '1. Open Google Colab and import tensorflow.keras modules.',
      '2. Download and preprocess MNIST dataset.',
      '3. Instantiate the Sequential CNN model with Conv2D, MaxPooling2D, Dropout, and Dense layers.',
      '4. Print model.summary() and verify output shapes at each stage.',
      '5. Train model with model.fit(x_train, y_train, epochs=10, validation_split=0.1).',
      '6. Plot training vs validation accuracy and loss curves.',
      '7. Compute confusion matrix and evaluate test set accuracy (>98%).'
    ],
    code: {
      python: `import tensorflow as tf
from tensorflow.keras import layers, models
from tensorflow.keras.datasets import mnist
from tensorflow.keras.utils import to_categorical
import numpy as np

# 1. Load and Preprocess MNIST Dataset
(X_train, y_train), (X_test, y_test) = mnist.load_data()

# Normalize to [0, 1] and add channel dimension (28, 28, 1)
X_train = X_train.reshape((-1, 28, 28, 1)).astype('float32') / 255.0
X_test = X_test.reshape((-1, 28, 28, 1)).astype('float32') / 255.0

# One-hot encode targets
y_train_cat = to_categorical(y_train, 10)
y_test_cat = to_categorical(y_test, 10)

# 2. Build CNN Architecture
model = models.Sequential([
    # Layer 1: Feature Extraction
    layers.Conv2D(32, (3, 3), activation='relu', input_shape=(28, 28, 1), name="conv1"),
    layers.MaxPooling2D((2, 2), name="pool1"),
    
    # Layer 2: Deeper Representation
    layers.Conv2D(64, (3, 3), activation='relu', name="conv2"),
    layers.MaxPooling2D((2, 2), name="pool2"),
    layers.Dropout(0.25, name="dropout_conv"),
    
    # Layer 3: Classification Head
    layers.Flatten(name="flatten"),
    layers.Dense(128, activation='relu', name="dense_features"),
    layers.Dropout(0.5, name="dropout_dense"),
    layers.Dense(10, activation='softmax', name="digit_probabilities")
])

# 3. Compile Model
model.compile(
    optimizer='adam',
    loss='categorical_crossentropy',
    metrics=['accuracy']
)

model.summary()

# 4. Train Model
history = model.fit(
    X_train, y_train_cat,
    epochs=5,
    batch_size=128,
    validation_split=0.1,
    verbose=1
)

# 5. Evaluate on Test Data
test_loss, test_acc = model.evaluate(X_test, y_test_cat, verbose=0)
print(f"\\nFinal Test Accuracy: {test_acc * 100:.2f}%")
print(f"Final Test Loss: {test_loss:.4f}")`
    },
    sampleInput: 'Input Image: 28x28 grayscale handwritten digit; Batch size: 128; Epochs: 5',
    expectedOutput: 'Test Accuracy: ~98.8%; Correct classification of digits 0 through 9 with high confidence (>0.99).',
    references: [
      'LeCun, Y. et al. (1998), Gradient-based learning applied to document recognition, Proceedings of the IEEE, 86(11), 2278-2324',
      'Srivastava, N. et al. (2014), Dropout: A simple way to prevent neural networks from overfitting, JMLR, 15(1), 1929-1958'
    ],
    postLabQuestions: [
      { question: 'Why are convolutional layers preferable over fully connected layers for image data?', answer: 'Conv layers exploit spatial locality and weight sharing, drastically reducing parameter count and providing translation equivariance.' },
      { question: 'What is the purpose of Max Pooling in CNNs?', answer: 'It reduces spatial dimensions (H, W), reducing computational cost and controlling overfitting while creating translation invariance.' },
      { question: 'How does Dropout mitigate overfitting during training?', answer: 'It randomly zeroes out activations during forward pass, preventing neurons from relying on co-adaptations with other specific neurons.' }
    ],
    conclusion: 'Convolution Neural Network is implemented for Multiclass Object classification on image data.',
    quiz: [
      {
        id: 1,
        question: 'An input image of shape 28x28 is processed with a 3x3 Conv2D filter, stride=1, padding=0. What is the spatial output size?',
        options: ['26x26', '28x28', '27x27', '24x24'],
        correctAnswer: 0,
        explanation: 'Formula: ((W - K + 2P)/S) + 1 = ((28 - 3 + 0)/1) + 1 = 25 + 1 = 26. Hence output is 26x26.'
      },
      {
        id: 2,
        question: 'How many learnable parameters does a 2x2 Max Pooling layer have?',
        options: ['0', '4', '8', '16'],
        correctAnswer: 0,
        explanation: 'Max Pooling is a deterministic mathematical operator that takes the maximum value in each window. It contains zero learnable parameters.'
      }
    ]
  },

  // ==========================================
  // Experiment 5
  // ==========================================
  {
    id: 'dl-exp5',
    num: 5,
    subjectId: 'dl',
    title: 'Design & Implementation of RNNs using LSTM & GRU for Multiclass Text Classification',
    subtitle: 'Vanishing Gradient Mitigation, Forget/Input/Output Gating, Gated Recurrent Units & Bi-LSTM',
    category: 'Sequence Modeling & NLP',
    iitReference: 'KJSIT Autonomous Syllabus / AIL 702 Lab Manual (Prof. Devanand K. Bathe, Dept. of AI&DS)',
    iitLabUrl: 'https://vlab.co.in/dl-lab/',
    aim: 'a) To design and implement RNN(Recurrent Neural Network) by using LSTM layer for Multiclass Classification on text data. b) To design and implement a RNN(Recurrent Neural Network) by using GRU layer for Multiclass Classification on text data.',
    objective: 'To design recurrent neural networks using gated units (LSTM & GRU) to classify sequential text data and solve the vanishing gradient problem.',
    labObjectives: [
      'Understand the vanishing/exploding gradient problem in standard recurrent neural networks.',
      'Analyze the gating mechanisms of Long Short-Term Memory (Forget, Input, Output gates, Cell State).',
      'Compare LSTM vs Gated Recurrent Unit (GRU) architectures and train multiclass text classifiers.'
    ],
    software: 'Keras library, Google Colab, TensorFlow',
    theory: {
      overview: [
        'Problems with standard RNN: Backpropagation Through Time (BPTT) requires multiplying recurrent weight matrices across time steps. When eigenvalues are < 1, gradients vanish exponentially, preventing the network from retaining long sequences.',
        'LSTM (Long Short-Term Memory, Hochreiter & Schmidhuber 1997) solves this with an uninterrupted additive Cell State C_t regulated by three non-linear gates:',
        '1. Forget Gate f_t = σ(W_f · [h_{t-1}, x_t] + b_f): decides what information from previous cell state to discard (0 = discard, 1 = retain).',
        '2. Input Gate i_t = σ(W_i · [h_{t-1}, x_t] + b_i) and Candidate ~C_t = tanh(W_c · [h_{t-1}, x_t] + b_c): decides what new information to write into the cell state.',
        'Cell State Update: C_t = f_t ⊙ C_{t-1} + i_t ⊙ ~C_t (additive linear gradient highway).',
        '3. Output Gate o_t = σ(W_o · [h_{t-1}, x_t] + b_o) and Hidden State: h_t = o_t ⊙ tanh(C_t).',
        'GRU (Gated Recurrent Unit, Cho et al. 2014): Streamlined architecture with only 2 gates (Reset Gate r_t and Update Gate z_t). It merges cell state and hidden state, has 25% fewer parameters, and trains faster than LSTM.',
        'Bidirectional RNN (Bi-LSTM): Processes text tokens in both forward (t=1..T) and backward (t=T..1) directions, capturing past and future linguistic context simultaneously.'
      ],
      complexityTable: [
        { parameter: 'LSTM Parameters per Cell', value: '4 · (d_hidden · (d_hidden + d_input) + d_hidden)' },
        { parameter: 'GRU Parameters per Cell', value: '3 · (d_hidden · (d_hidden + d_input) + d_hidden) (25% fewer parameters)' },
        { parameter: 'Gradient Flow', value: 'Additive linear cell state highway prevents exponential vanishing gradients' }
      ],
      keyPoints: [
        'LSTM Gates: Forget Gate (sigmoid), Input Gate (sigmoid * tanh), Output Gate (sigmoid * tanh).',
        'GRU Gates: Update Gate (combines forget and input) and Reset Gate (controls influence of previous hidden state).',
        'No Cell State in GRU: GRU uses its hidden state directly to transport information across time steps.'
      ],
      realWorldApplications: [
        'Sentiment analysis and customer feedback multiclass categorization.',
        'Machine translation and cross-lingual text generation.',
        'Named Entity Recognition (NER) and speech-to-text transcription.'
      ]
    },
    algorithm: [
      '1. Prepare text dataset (e.g. AG News or sentiment corpus) with N multiclass categories.',
      '2. Tokenize text into word indices; pad sequences to a fixed maximum sequence length L.',
      '3. Build Embedding Layer converting word indices into dense vector representations (e.g. 128-d).',
      '4. Architecture Part A (LSTM):',
      '    Add Bidirectional(LSTM(64, dropout=0.2, recurrent_dropout=0.2)).',
      '    Add Dense(32, activation=\'relu\') followed by Dense(N_classes, activation=\'softmax\').',
      '5. Architecture Part B (GRU):',
      '    Add Bidirectional(GRU(64, dropout=0.2, recurrent_dropout=0.2)).',
      '    Add Dense(32, activation=\'relu\') followed by Dense(N_classes, activation=\'softmax\').',
      '6. Compile models with categorical_crossentropy and Adam optimizer.',
      '7. Train both models and compare convergence speed, validation accuracy, and inference latency.'
    ],
    procedure: [
      '1. Load news/sentiment text corpus in Google Colab.',
      '2. Preprocess text using Tokenizer with max_words=10000 and pad_sequences(maxlen=100).',
      '3. Train the LSTM model for 5 epochs and record training time and accuracy.',
      '4. Train the GRU model with identical hyperparameters and compare parameter counts and training speed.',
      '5. Evaluate both models on test sentences to observe classification confidence.'
    ],
    code: {
      python: `import tensorflow as tf
from tensorflow.keras import layers, models
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
import numpy as np

# Synthetic Multiclass Text Dataset (4 topics: Tech, Sports, Business, Sci)
texts = [
    "deep learning neural networks gpu training algorithms",
    "football soccer champion league tournament match goal",
    "stock market wall street shares revenue quarterly profit",
    "quantum physics astrophysics telescope space telescope universe",
    "convolutional neural network image classification keras python",
    "basketball nba tournament playoffs slam dunk finals",
    "central bank interest rates inflation fiscal treasury bonds",
    "black hole gravitational waves neutron star cosmological expansion"
]
labels = [0, 1, 2, 3, 0, 1, 2, 3] # 4 classes

# Tokenization and Padding
max_words = 1000
max_len = 20
tokenizer = Tokenizer(num_words=max_words, oov_token="<OOV>")
tokenizer.fit_on_texts(texts)
sequences = tokenizer.texts_to_sequences(texts)
X = pad_sequences(sequences, maxlen=max_len, padding='post')
y = tf.keras.utils.to_categorical(labels, num_classes=4)

# ==========================================
# 1. LSTM Text Classification Model
# ==========================================
lstm_model = models.Sequential([
    layers.Embedding(max_words, 32, input_length=max_len, name="embedding"),
    layers.Bidirectional(layers.LSTM(32, return_sequences=False), name="bi_lstm"),
    layers.Dropout(0.3),
    layers.Dense(16, activation='relu'),
    layers.Dense(4, activation='softmax', name="multiclass_output")
], name="LSTM_Text_Classifier")

lstm_model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
print("--- LSTM Model Summary ---")
lstm_model.summary()

# ==========================================
# 2. GRU Text Classification Model
# ==========================================
gru_model = models.Sequential([
    layers.Embedding(max_words, 32, input_length=max_len, name="embedding"),
    layers.Bidirectional(layers.GRU(32, return_sequences=False), name="bi_gru"),
    layers.Dropout(0.3),
    layers.Dense(16, activation='relu'),
    layers.Dense(4, activation='softmax', name="multiclass_output")
], name="GRU_Text_Classifier")

gru_model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
print("\\n--- GRU Model Summary ---")
gru_model.summary()

# Train both models
lstm_model.fit(X, y, epochs=10, verbose=0)
gru_model.fit(X, y, epochs=10, verbose=0)
print("\\nBoth models successfully compiled and trained!")`
    },
    sampleInput: 'Text prompt: "convolutional neural network deep learning vision" -> Tokenized sequence',
    expectedOutput: 'Predicted category: Tech (Class 0) with confidence > 97%; GRU trains ~20% faster than LSTM.',
    references: [
      'Hochreiter, S., & Schmidhuber, J. (1997), Long short-term memory, Neural Computation, 9(8), 1735-1780',
      'Cho, K. et al. (2014), Learning phrase representations using RNN encoder-decoder for statistical machine translation, EMNLP 2014'
    ],
    postLabQuestions: [
      { question: 'Why does GRU train faster than LSTM?', answer: 'GRU has only 2 gates (Reset and Update) and no separate cell state, resulting in 25% fewer matrix multiplications per time step.' },
      { question: 'How does the LSTM cell state prevent vanishing gradients?', answer: 'The cell state acts as an additive linear highway C_t = f_t * C_{t-1} + i_t * ~C_t, allowing gradients to backpropagate with minimal multiplicative decay.' },
      { question: 'What advantage does Bidirectional LSTM provide over unidirectional LSTM?', answer: 'Bi-LSTM captures both preceding and subsequent context in a sentence, which is crucial for disambiguating word meaning.' }
    ],
    conclusion: 'Long short term memory (LSTM) and Gated recurrent unit is implemented',
    quiz: [
      {
        id: 1,
        question: 'Which gate in an LSTM cell decides what information should be discarded from the cell state?',
        options: ['Forget Gate', 'Input Gate', 'Output Gate', 'Reset Gate'],
        correctAnswer: 0,
        explanation: 'The Forget Gate f_t = σ(W_f · [h_{t-1}, x_t] + b_f) produces values between 0 (discard) and 1 (retain).'
      },
      {
        id: 2,
        question: 'How many gates does a Gated Recurrent Unit (GRU) contain?',
        options: ['2 (Reset Gate and Update Gate)', '3 (Forget, Input, Output)', '1 (Recurrent Gate)', '4 (Forget, Input, Output, Cell)'],
        correctAnswer: 0,
        explanation: 'A GRU contains exactly 2 gates: the Reset Gate and the Update Gate, merging the cell state and hidden state.'
      }
    ]
  },

  // ==========================================
  // Experiment 6
  // ==========================================
  {
    id: 'dl-exp6',
    num: 6,
    subjectId: 'dl',
    title: 'Multi-Armed Bandit Problem using Epsilon-Greedy Agent',
    subtitle: 'Exploration vs Exploitation Trade-off, Incremental Sample-Average Updates & Action-Value Estimation',
    category: 'Reinforcement Learning - Bandits',
    iitReference: 'KJSIT Autonomous Syllabus / AIL 702 Lab Manual (Prof. Devanand K. Bathe, Dept. of AI&DS)',
    iitLabUrl: 'https://vlab.co.in/dl-lab/',
    aim: 'To implement and analyze the performance of an Epsilon-Greedy agent for solving the Multi-Armed Bandit (MAB) problem and to study the exploration–exploitation trade-off.',
    objective: 'To demonstrate tabular reinforcement learning methods and evaluate exploration vs exploitation on stochastic bandit tasks.',
    labObjectives: [
      'Formulate the classical Multi-Armed Bandit decision-making problem under uncertainty.',
      'Implement the Epsilon-Greedy action selection strategy with incremental mean value updates.',
      'Analyze cumulative reward, regret, and optimal action selection rate across ε = 0, ε = 0.01, and ε = 0.1.'
    ],
    software: 'Browser, Python / NumPy, Matplotlib',
    theory: {
      overview: [
        'The Multi-Armed Bandit (MAB) problem is a foundational reinforcement learning problem modeling decision-making under uncertainty without state transitions.',
        'The name originates from a gambler facing a row of slot machines ("one-armed bandits"), each providing rewards from unknown stochastic distributions.',
        'Bandits vs Full RL: No state transitions (S is trivial), no delayed rewards, immediate scalar reward feedback upon selecting action a.',
        'The Exploration-Exploitation Dilemma:',
        '- Exploration: Choosing non-greedy actions to acquire information about unknown reward distributions.',
        '- Exploitation: Selecting the currently highest-estimated arm to maximize immediate expected payout.',
        'Epsilon-Greedy Policy: At each step t, with probability (1 - ε), exploit best action: a_t = argmax_a Q(a); with probability ε, explore a random arm uniformly from all K actions.',
        'Incremental Sample-Average Update Rule: Q_{n+1}(a) = Q_n(a) + (1 / N(a)) · [R_n - Q_n(a)], where N(a) is the pull count and R_n is the sampled reward.'
      ],
      complexityTable: [
        { parameter: 'Time Complexity per Step', value: 'O(K) to evaluate argmax across K arms' },
        { parameter: 'Space Complexity', value: 'O(K) to store estimated values Q(a) and action counts N(a)' },
        { parameter: 'Reward Distribution', value: 'K-Gaussian Distributions: R_t ~ N(q_*(a), σ^2)' }
      ],
      keyPoints: [
        'ε = 0 (Pure Greedy): Converges quickly to whichever arm produces an early reward, but frequently gets stuck on a suboptimal arm indefinitely.',
        'ε = 0.1: Balances exploration and exploitation, finding the true optimal arm quickly and sustaining high cumulative rewards.',
        'ε = 0.01: Explores too conservatively; requires thousands of steps to reliably find the optimal arm.'
      ],
      realWorldApplications: [
        'A/B and multivariate website testing (headline, layout, button optimization).',
        'Clinical drug trials allocating treatments to patients adaptively.',
        'Real-time ad placement and recommender system exploration.'
      ]
    },
    algorithm: [
      '1. Initialize Q(a) = 0 for all actions a in {1, 2, ..., K}.',
      '2. Initialize N(a) = 0 for all actions a in {1, 2, ..., K}.',
      '3. For time step t = 1 to T:',
      '    a. Generate uniform random number r in [0, 1].',
      '    b. If r < ε: choose random action a uniformly from {1..K}.',
      '       Else: choose action a = argmax_a Q(a).',
      '    c. Execute action a and receive stochastic reward R ~ N(μ_a, 1).',
      '    d. Increment pull count: N(a) = N(a) + 1.',
      '    e. Update action value estimate: Q(a) = Q(a) + (1 / N(a)) * (R - Q(a)).',
      '4. Track cumulative reward and % optimal action selected over time.'
    ],
    procedure: [
      '1. Open the Multi-Armed Bandit Simulator.',
      '2. Set number of bandit arms K = 10 and time steps T = 1000.',
      '3. Test Case 1: Set ε = 0 (Pure Greedy). Observe how often the agent locks onto a suboptimal arm.',
      '4. Test Case 2: Set ε = 0.01 (Slow Exploration). Observe slow convergence.',
      '5. Test Case 3: Set ε = 0.1 (Balanced Exploration). Observe rapid discovery of the optimal arm and steady high rewards.',
      '6. Analyze comparison plots of Average Reward and % Optimal Action Selected.'
    ],
    code: {
      python: `import numpy as np

class EpsilonGreedyBandit:
    def __init__(self, k_arms=10, epsilon=0.1, steps=1000):
        self.k = k_arms
        self.epsilon = epsilon
        self.steps = steps
        
        # True expected reward for each arm ~ N(0, 1)
        self.q_true = np.random.normal(0, 1, self.k)
        self.optimal_arm = np.argmax(self.q_true)
        
        # Estimated values and action counts
        self.q_est = np.zeros(self.k)
        self.action_counts = np.zeros(self.k)
        
        # Tracking metrics
        self.rewards = np.zeros(self.steps)
        self.optimal_actions = np.zeros(self.steps)

    def run(self):
        for t in range(self.steps):
            # Epsilon-Greedy action selection
            if np.random.random() < self.epsilon:
                action = np.random.randint(self.k)
            else:
                action = np.argmax(self.q_est)
                
            # Sample reward ~ N(q_true(a), 1)
            reward = np.random.normal(self.q_true[action], 1.0)
            
            # Incremental Mean Update Rule
            self.action_counts[action] += 1
            n = self.action_counts[action]
            self.q_est[action] += (1.0 / n) * (reward - self.q_est[action])
            
            # Record metrics
            self.rewards[t] = reward
            self.optimal_actions[t] = 1 if action == self.optimal_arm else 0

        return self.rewards, self.optimal_actions

# Compare epsilon values
np.random.seed(42)
for eps in [0.0, 0.01, 0.1]:
    bandit = EpsilonGreedyBandit(k_arms=10, epsilon=eps, steps=1000)
    rewards, opt_actions = bandit.run()
    print(f"Epsilon = {eps:4.2f} | Avg Reward: {np.mean(rewards):.4f} | Optimal Arm Pulls: {np.sum(opt_actions)}/1000 ({np.mean(opt_actions)*100:.1f}%)")`
    },
    sampleInput: 'K = 10 arms, T = 1000 steps, Gaussian rewards with true means in [-2, 2]; Epsilon tested: [0, 0.01, 0.1]',
    expectedOutput: 'ε = 0.1 achieves highest cumulative reward (~1450) and >85% optimal action pulls, outperforming ε = 0 (~1050) and ε = 0.01 (~1180).',
    references: [
      'Sutton, R. S., & Barto, A. G. (2018), Reinforcement Learning: An Introduction, Chapter 2: Multi-armed Bandits, MIT Press',
      'Lattimore, T., & Szepesvári, C. (2020), Bandit Algorithms, Cambridge University Press'
    ],
    postLabQuestions: [
      { question: 'What is the exploration–exploitation trade-off?', answer: 'Exploration gathers knowledge about uncertain arm distributions; exploitation leverages the best-known arm to maximize immediate rewards.' },
      { question: 'Why does ε = 0 sometimes fail?', answer: 'Pure greedy agents act solely on initial samples. If a suboptimal arm yields a positive reward first, the agent never samples the true best arm.' },
      { question: 'How does ε affect convergence?', answer: 'Higher ε explores faster but never stops taking random exploratory actions. Lower ε takes longer to find the best arm.' },
      { question: 'What is regret in bandit problems?', answer: 'Regret is the cumulative loss incurred by not selecting the optimal arm at every time step: R_T = T · q_*(a*) - Σ q_*(a_t).' },
      { question: 'What is the difference between the bandit problem and full RL?', answer: 'Bandits have no state transitions and no delayed rewards (single-state MDP). Full RL involves sequential states and delayed credit assignment.' }
    ],
    conclusion: 'The experiment demonstrates that the Epsilon-Greedy algorithm effectively balances exploration and exploitation in the Multi-Armed Bandit problem. Moderate exploration (ε ≈ 0.1) generally yields higher cumulative rewards compared to purely greedy strategies.',
    quiz: [
      {
        id: 1,
        question: 'In an epsilon-greedy policy with ε = 0.1, what is the probability of selecting the greedy action argmax Q(a) (assuming no ties)?',
        options: ['0.90 + (0.10 / K)', '0.90', '0.10', '1.00'],
        correctAnswer: 0,
        explanation: 'The greedy action is selected with probability (1 - ε) when exploiting, plus (ε / K) when the random exploratory choice happens to pick the greedy action.'
      },
      {
        id: 2,
        question: 'What is the incremental update rule for estimating the value of action a after receiving reward R_n?',
        options: [
          'Q_{n+1}(a) = Q_n(a) + (1/N(a)) · [R_n - Q_n(a)]',
          'Q_{n+1}(a) = Q_n(a) + R_n',
          'Q_{n+1}(a) = R_n / N(a)',
          'Q_{n+1}(a) = Q_n(a) · (1 - N(a))'
        ],
        correctAnswer: 0,
        explanation: 'The incremental sample-average formula computes the new mean using: NewEstimate = OldEstimate + StepSize * [Target - OldEstimate].'
      }
    ]
  },

  // ==========================================
  // Experiment 7
  // ==========================================
  {
    id: 'dl-exp7',
    num: 7,
    subjectId: 'dl',
    title: 'Markov Decision Processes – Returns and Discount Factors',
    subtitle: 'MDP 5-Tuple Formulation, Discount Factor (γ), Finite vs Infinite Horizon & Return Computation',
    category: 'Reinforcement Learning - MDP',
    iitReference: 'KJSIT Autonomous Syllabus / AIL 702 Lab Manual (Prof. Devanand K. Bathe, Dept. of AI&DS)',
    iitLabUrl: 'https://vlab.co.in/dl-lab/',
    aim: 'To study and compute returns in a Markov Decision Process (MDP) and to analyze the effect of the discount factor (γ) on long-term decision making.',
    objective: 'To formulate MDP state-reward dynamics and analyze how discount factor γ shapes agent decision horizon.',
    labObjectives: [
      'Define an MDP formally as a 5-tuple M = (S, A, P, R, γ).',
      'Compute discounted returns G_t for episodic trajectories using backward recursion.',
      'Analyze the impact of discount factors γ = 1.0, 0.9, 0.5, and 0.0 on delayed reward valuation.'
    ],
    software: 'Keras library, Github, Python, Browser',
    theory: {
      overview: [
        'A Markov Decision Process (MDP) provides a mathematical framework for modeling sequential decision problems where outcomes depend on both randomness and agent actions.',
        'Formal 5-Tuple Definition: M = (S, A, P, R, γ), where:',
        '- S: Set of environmental states.',
        '- A: Set of agent actions.',
        '- P(s\'|s, a): Transition probability of reaching state s\' from state s under action a.',
        '- R(s, a): Expected immediate scalar reward received after taking action a in state s.',
        '- γ ∈ [0, 1]: Discount factor weighting the present value of future rewards.',
        'Discounted Return G_t: The total accumulated reward from time step t forward:',
        'G_t = R_{t+1} + γ R_{t+2} + γ^2 R_{t+3} + ... = Σ_{k=0}^{T-t-1} γ^k R_{t+k+1}.',
        'Backward Return Computation: G = R[t] + γ · G, processed in reverse from the terminal step back to step 0.',
        'Infinite Horizon Convergence: For continuing tasks with bounded reward R, the infinite return converges to: G = R / (1 - γ).'
      ],
      complexityTable: [
        { parameter: 'Return Backward Recursion', value: 'G_t = R_{t+1} + γ · G_{t+1} in O(T) linear time' },
        { parameter: 'Infinite Horizon Return', value: 'G = R / (1 - γ) when 0 ≤ γ < 1 and rewards are bounded' }
      ],
      keyPoints: [
        'γ = 0 (Completely Myopic): Only the immediate reward R_{t+1} matters; all future rewards are ignored.',
        'γ = 1 (Undiscounted): All future rewards are weighted equally; suitable for finite episodic tasks.',
        '0 < γ < 1 (Exponential Decay): Future rewards are discounted geometrically; emphasizes strategic long-term planning while ensuring mathematical convergence.',
        'Manual Benchmark: Episode rewards R = [-1, -1, -1, 10]:',
        '- Case 1: γ = 1.0 → G_0 = -1 - 1 - 1 + 10 = 7.0',
        '- Case 2: γ = 0.9 → G_0 = -1 + 0.9(-1) + 0.9^2(-1) + 0.9^3(10) = 4.58',
        '- Case 3: γ = 0.5 → G_0 = -1 + 0.5(-1) + 0.25(-1) + 0.125(10) = -0.5',
        '- Case 4: γ = 0.0 → G_0 = -1.0'
      ],
      realWorldApplications: [
        'Financial portfolio management balancing immediate dividends against long-term capital gains.',
        'Autonomous vehicle route planning balancing fuel cost against total journey time.',
        'Game playing AI (Chess, Go) planning moves many turns in advance.'
      ]
    },
    algorithm: [
      '1. Input reward sequence R = [R_1, R_2, ..., R_T] and discount factor γ.',
      '2. Initialize cumulative return G = 0.',
      '3. For t = T down to 1 (iterate backward through time steps):',
      '    Compute updated return: G = R[t] + γ * G.',
      '    Record return G_t at time step t.',
      '4. Output initial return G_0.'
    ],
    procedure: [
      '1. Open the MDP Returns Simulator.',
      '2. Input the episodic reward sequence: [-1, -1, -1, 10] (3 steps with penalty -1, goal reward +10).',
      '3. Set γ = 1.0 and compute undiscounted return G_0 = 7.0.',
      '4. Change γ to 0.9 and observe discounted return G_0 = 4.58.',
      '5. Change γ to 0.5 and observe return flipping to negative G_0 = -0.5.',
      '6. Set γ = 0.0 and observe myopic return G_0 = -1.0.',
      '7. Plot Return G_0 as a function of γ from 0 to 1 to visualize the transition from short-term to long-term planning.'
    ],
    code: {
      python: `def compute_discounted_return(rewards, gamma):
    """
    Computes discounted return using backward accumulation:
    G_t = R_{t+1} + gamma * G_{t+1}
    """
    G = 0.0
    returns = []
    # Process backward from final time step
    for r in reversed(rewards):
        G = r + gamma * G
        returns.append(G)
    returns.reverse()
    return returns

# Benchmark episode from manual: R = [-1, -1, -1, 10]
rewards = [-1, -1, -1, 10]
gammas = [1.0, 0.9, 0.5, 0.0]

print("--- MDP Return Computation for Rewards: [-1, -1, -1, 10] ---")
for g in gammas:
    ret = compute_discounted_return(rewards, g)
    g0 = ret[0]
    print(f"Discount Factor γ = {g:3.1f} | Initial Return G_0 = {g0:6.2f} | Returns: {[round(x, 2) for x in ret]}")`
    },
    sampleInput: 'Episode rewards: [-1, -1, -1, 10]; Discount factors tested: [1.0, 0.9, 0.5, 0.0]',
    expectedOutput: 'γ=1.0 -> G_0 = 7.0; γ=0.9 -> G_0 = 4.58; γ=0.5 -> G_0 = -0.50; γ=0.0 -> G_0 = -1.00.',
    references: [
      'Sutton, R. S., & Barto, A. G. (2018), Reinforcement Learning: An Introduction, Chapter 3: Finite Markov Decision Processes, MIT Press',
      'Bellman, R. (1957), Dynamic Programming, Princeton University Press'
    ],
    postLabQuestions: [
      { question: 'Why is discounting necessary in infinite-horizon problems?', answer: 'Without discounting (γ = 1), the sum of infinite positive rewards diverges to infinity, making policy comparison impossible. With γ < 1, the geometric series is bounded by R_max / (1 - γ).' },
      { question: 'What happens if γ > 1?', answer: 'If γ > 1, future rewards grow exponentially larger than present rewards, causing return estimates to diverge.' },
      { question: 'What is the difference between reward and return?', answer: 'Reward is the immediate scalar feedback R_{t+1} received at a single transition. Return G_t is the cumulative discounted sum of all future rewards from time t onward.' },
      { question: 'How does γ affect convergence?', answer: 'Lower γ shrinks the contraction factor in value iteration, speeding up numerical convergence, but shortens the agent\'s planning horizon.' },
      { question: 'Why is γ usually chosen close to 1 in practice (e.g. 0.99)?', answer: 'Choosing γ ≈ 0.99 allows the agent to act strategically for hundreds of future steps while maintaining bounded mathematical convergence.' }
    ],
    conclusion: 'This experiment demonstrates the role of return and discount factor in Markov Decision Processes. The discount factor γ plays a crucial role in shaping agent behavior: High γ → Long-term planning, Low γ → Short-term decision making. Proper tuning of γ is essential for optimal policy learning.',
    quiz: [
      {
        id: 1,
        question: 'Given an episode with rewards [-1, -1, -1, 10] and discount factor γ = 0.9, what is the initial return G_0?',
        options: ['4.58', '7.00', '-0.50', '-1.00'],
        correctAnswer: 0,
        explanation: 'G_0 = -1 + 0.9(-1) + 0.9^2(-1) + 0.9^3(10) = -1 - 0.9 - 0.81 + 7.29 = 4.58.'
      },
      {
        id: 2,
        question: 'For an infinite-horizon task with constant reward R = 5 and discount factor γ = 0.8, what is the total return G?',
        options: ['25', '50', '5', '40'],
        correctAnswer: 0,
        explanation: 'Using the infinite sum formula G = R / (1 - γ) = 5 / (1 - 0.8) = 5 / 0.2 = 25.'
      }
    ]
  },

  // ==========================================
  // Experiment 8
  // ==========================================
  {
    id: 'dl-exp8',
    num: 8,
    subjectId: 'dl',
    title: 'Dynamic Programming in Markov Decision Processes',
    subtitle: 'Bellman Optimality Equations, Policy Evaluation, Policy Improvement & Value Iteration',
    category: 'Reinforcement Learning - Dynamic Programming',
    iitReference: 'KJSIT Autonomous Syllabus / AIL 702 Lab Manual (Prof. Devanand K. Bathe, Dept. of AI&DS)',
    iitLabUrl: 'https://vlab.co.in/dl-lab/',
    aim: 'To implement Dynamic Programming (DP) methods for solving a Markov Decision Process (MDP), including Policy Evaluation, Policy Improvement, and Value Iteration, and to analyze convergence to the optimal policy.',
    objective: 'To implement Dynamic Programming algorithms (Policy Iteration and Value Iteration) using Bellman equations to solve finite MDPs.',
    labObjectives: [
      'Understand Bellman Expectation and Optimality equations for state-value functions.',
      'Implement Policy Evaluation and Policy Improvement routines.',
      'Implement Value Iteration on a 3-state MDP and verify convergence to optimal values V*(S1)=14, V*(S2)=10.'
    ],
    software: 'Keras library, Google Colab, Python, Browser',
    theory: {
      overview: [
        'Dynamic Programming (DP) in RL refers to a collection of algorithms that compute optimal policies given a perfect mathematical model of the environment (known transition probabilities P and rewards R).',
        'Key Idea: The Bellman Equation, which decomposes the value of a state into the immediate reward plus the discounted value of successor states.',
        'Bellman Expectation Equation: V^π(s) = Σ_a π(a|s) Σ_{s\'} P(s\'|s, a) [R(s, a, s\') + γ V^π(s\')].',
        'Bellman Optimality Equation: V*(s) = max_a Σ_{s\'} P(s\'|s, a) [R(s, a, s\') + γ V*(s\')].',
        'Policy Iteration: Alternates between Policy Evaluation (iterating until V^π converges) and Policy Improvement (π\'(s) = argmax_a Q(s, a)). Guarantees monotonic convergence.',
        'Value Iteration: Combines evaluation and improvement into a single Bellman optimality backup per iteration: V_{k+1}(s) = max_a Σ_{s\'} P(s\'|s, a) [R + γ V_k(s\')].',
        'Contraction Property: The Bellman operator is a γ-contraction mapping in the infinity norm (||T(u) - T(v)||_∞ ≤ γ ||u - v||_∞), guaranteeing convergence to a unique fixed point V* regardless of initialization.'
      ],
      complexityTable: [
        { parameter: 'Value Iteration Complexity per Iteration', value: 'O(|S|^2 · |A|) for transition checks' },
        { parameter: 'Convergence Guarantee', value: 'Contraction mapping theorem guarantees exponential convergence: ||V_k - V*|| ≤ γ^k ||V_0 - V*||' },
        { parameter: 'MDP Knowledge Requirement', value: 'Full Model Knowledge: requires explicit transition matrix P(s\'|s,a) and reward function R(s,a)' }
      ],
      keyPoints: [
        '3-State MDP Benchmark from Manual:',
        '- States: S1, S2, S3 (Terminal).',
        '- Transitions: S1 → S2 (Reward = 5), S2 → S3 (Reward = 10), S3 → Terminal (Reward = 0).',
        '- Discount Factor γ = 0.9.',
        '- Iteration 0: V(S1) = 0, V(S2) = 0, V(S3) = 0.',
        '- Iteration 1: V(S2) = 10 + 0.9(0) = 10; V(S1) = 5 + 0.9(0) = 5.',
        '- Iteration 2: V(S2) = 10 + 0.9(0) = 10; V(S1) = 5 + 0.9(10) = 14.',
        '- Converged Values: V(S1) = 14, V(S2) = 10, V(S3) = 0.'
      ],
      realWorldApplications: [
        'Robotics path planning in mapped 2D grid environments.',
        'Supply chain inventory control and warehouse replenishment.',
        'Game strategy optimization in finite-state board games.'
      ]
    },
    algorithm: [
      'Value Iteration Algorithm:',
      '1. Initialize V(s) = 0 for all states s in S, and V(terminal) = 0.',
      '2. Repeat until max_s |V(s) - V_old(s)| < θ (convergence threshold):',
      '    a. For each non-terminal state s:',
      '       V_new(s) = max_a Σ_{s\'} P(s\'|s, a) [R(s, a, s\') + γ · V(s\')].',
      '    b. Update V(s) = V_new(s).',
      '3. Output optimal value function V* and derive optimal policy π*(s) = argmax_a Σ_{s\'} P(s\'|s, a) [R + γ V*(s\')].'
    ],
    procedure: [
      '1. Open the Dynamic Programming MDP Simulator.',
      '2. Select the 3-state environment (S1, S2, S3) with γ = 0.9.',
      '3. Click "Step Iteration" once: observe V(S2)=10, V(S1)=5 (Iteration 1).',
      '4. Click "Step Iteration" a second time: observe V(S1) update to 5 + 0.9(10) = 14, V(S2)=10 (Iteration 2).',
      '5. Verify convergence as further iterations produce zero delta.',
      '6. Compare Policy Iteration vs Value Iteration computation times and step counts.'
    ],
    code: {
      python: `import numpy as np

def value_iteration_3state(gamma=0.9, theta=1e-6):
    # States: 0: S1, 1: S2, 2: S3 (Terminal)
    # Transitions: S1 -> S2 (R=5), S2 -> S3 (R=10), S3 -> Terminal (R=0)
    V = np.zeros(3)
    iteration = 0
    
    print("Initial State Values: V(S1)=0, V(S2)=0, V(S3)=0\\n")
    
    while True:
        iteration += 1
        delta = 0.0
        V_new = np.copy(V)
        
        # S1 transitions to S2 with reward 5
        V_new[0] = 5.0 + gamma * V[1]
        
        # S2 transitions to S3 (Terminal) with reward 10
        V_new[1] = 10.0 + gamma * V[2]
        
        # S3 is terminal
        V_new[2] = 0.0
        
        delta = np.max(np.abs(V_new - V))
        V = V_new
        
        print(f"Iteration {iteration:2d}: V(S1) = {V[0]:5.2f}, V(S2) = {V[1]:5.2f}, V(S3) = {V[2]:5.2f} | Max Delta: {delta:.4f}")
        
        if delta < theta:
            break
            
    print(f"\\nConverged in {iteration} iterations!")
    print(f"Optimal Value Function: V*(S1)={V[0]}, V*(S2)={V[1]}, V*(S3)={V[2]}")
    return V

value_iteration_3state(gamma=0.9)`
    },
    sampleInput: '3-State MDP: S1 -> S2 (R=5), S2 -> S3 (R=10), S3 Terminal (R=0); Discount factor γ = 0.9',
    expectedOutput: 'Iteration 1: V=[5, 10, 0]; Iteration 2: V=[14, 10, 0]; Converged Optimal Values: V*(S1)=14, V*(S2)=10, V*(S3)=0.',
    references: [
      'Bellman, R. (1957), Dynamic Programming, Princeton University Press',
      'Sutton, R. S., & Barto, A. G. (2018), Reinforcement Learning: An Introduction, Chapter 4: Dynamic Programming, MIT Press'
    ],
    postLabQuestions: [
      { question: 'Why does value iteration converge?', answer: 'Value iteration is guaranteed to converge because the Bellman optimality operator is a contraction mapping with factor γ < 1 in the Banach space of value functions.' },
      { question: 'What is the difference between policy iteration and value iteration?', answer: 'Policy iteration separates evaluation (solving V until convergence) and improvement in alternating loops. Value iteration combines evaluation and improvement into a single backup per step.' },
      { question: 'Why is full model knowledge required for Dynamic Programming?', answer: 'DP formulas require explicit transition probabilities P(s\'|s,a) and expected rewards R(s,a) to compute expectation sums across all possible successor states.' },
      { question: 'What is the contraction property in DP?', answer: 'Applying the Bellman backup operator T shrinks the distance between any two value vectors: ||T(u) - T(v)|| ≤ γ ||u - v||.' },
      { question: 'Can DP be applied to large state spaces (e.g. Go, Atari)?', answer: 'No, standard DP suffers from the "curse of dimensionality" as state spaces grow exponentially, requiring deep reinforcement learning approximations instead.' }
    ],
    conclusion: 'This experiment demonstrates that Dynamic Programming methods can compute optimal policies in finite MDPs when the environment model is known. Policy iteration and value iteration both converge to optimal solutions using the Bellman equation. Dynamic Programming forms the theoretical foundation for many modern reinforcement learning algorithms.',
    quiz: [
      {
        id: 1,
        question: 'In the 3-state MDP benchmark with γ = 0.9, what is the value of V(S1) after Iteration 2?',
        options: ['14', '10', '5', '0'],
        correctAnswer: 0,
        explanation: 'In Iteration 1, V(S2) = 10. In Iteration 2, V(S1) = 5 + 0.9 · V(S2) = 5 + 0.9(10) = 5 + 9 = 14.'
      },
      {
        id: 2,
        question: 'Which property guarantees that Value Iteration converges to a unique optimal value function?',
        options: [
          'Contraction Mapping Theorem',
          'Law of Large Numbers',
          'Central Limit Theorem',
          'Markov Property'
        ],
        correctAnswer: 0,
        explanation: 'The Bellman optimality operator is a γ-contraction mapping, which by the Banach fixed-point theorem ensures convergence to a unique fixed point.'
      }
    ]
  },

  // ==========================================
  // Experiment 9
  // ==========================================
  {
    id: 'dl-exp9',
    num: 9,
    subjectId: 'dl',
    title: 'Monte Carlo Methods for Value Estimation in MDPs',
    subtitle: 'Model-Free Learning, First-Visit vs Every-Visit MC, Episode-Based Sampling & Value Convergence',
    category: 'Reinforcement Learning - Monte Carlo',
    iitReference: 'KJSIT Autonomous Syllabus / AIL 702 Lab Manual (Prof. Devanand K. Bathe, Dept. of AI&DS)',
    iitLabUrl: 'https://vlab.co.in/dl-lab/',
    aim: 'To implement the Monte Carlo (MC) method for estimating value functions in a Markov Decision Process (MDP) and to analyze learning through episode-based sampling.',
    objective: 'To implement model-free Monte Carlo prediction algorithms and compare First-Visit vs Every-Visit methods.',
    labObjectives: [
      'Understand model-free learning from raw sampled episodes without transition dynamics.',
      'Implement First-Visit and Every-Visit Monte Carlo value estimation.',
      'Compare convergence, sample variance, and computational requirements among Dynamic Programming, Monte Carlo, and Temporal Difference learning.'
    ],
    software: 'Keras library and Google Colab, Python, Browser',
    theory: {
      overview: [
        'The Monte Carlo (MC) method is a model-free reinforcement learning technique that estimates value functions directly from complete episodes of experience.',
        'Unlike Dynamic Programming (which requires transition probabilities P(s\'|s,a) and bootstraps from successor estimates):',
        '- MC does NOT require knowledge of transition probabilities or reward models.',
        '- MC learns directly from actual sampled returns G_t.',
        '- MC updates values only after an episode terminates (strictly episodic tasks).',
        'Value Estimation as Sample Average: V(s) = (Σ G(s)) / N(s).',
        'Incremental Running Average Form: V(s) := V(s) + (1 / N(s)) · [G - V(s)].',
        'First-Visit MC: Averages returns following only the first time state s is visited within an episode (unbiased estimate of V_π(s)).',
        'Every-Visit MC: Averages returns following every time state s is visited in an episode (slightly biased initially, but asymptotically consistent with lower MSE).'
      ],
      complexityTable: [
        { parameter: 'Model Requirement', value: 'Model-Free (zero knowledge of transition probabilities or reward function)' },
        { parameter: 'Bootstrapping', value: 'None (updates based on true terminal returns, unlike DP and TD)' },
        { parameter: 'Bias and Variance', value: 'Zero Bias (unbiased estimate of expected return), High Variance' }
      ],
      keyPoints: [
        'Comparison of Methods from Manual:',
        '- Dynamic Programming: Requires Model = Yes, Updates during episode = Yes, Variance = Low.',
        '- Monte Carlo: Requires Model = No, Updates during episode = No (after episode), Variance = High.',
        '- Temporal Difference: Requires Model = No, Updates during episode = Yes, Variance = Medium.',
        'Manual 3-State Episode Example:',
        '- Episode: S1 → S2 → Terminal with rewards [5, 10], γ = 0.9.',
        '- Observed return for S2: G(S2) = 10.',
        '- Observed return for S1: G(S1) = 5 + 0.9(10) = 14.',
        '- As episodes accumulate, average values converge: V(S1) ≈ 14, V(S2) ≈ 10.'
      ],
      realWorldApplications: [
        'Blackjack card counting and strategy simulation.',
        'Episodic robotics locomotion where trial-and-error simulation is inexpensive.',
        'Financial risk modeling and Monte Carlo option pricing.'
      ]
    },
    algorithm: [
      'First-Visit Monte Carlo Algorithm:',
      '1. Initialize V(s) arbitrarily (e.g. 0) for all s in S.',
      '2. Initialize Returns(s) = empty list for all s in S.',
      '3. For each episode:',
      '    a. Generate an episode following policy π: S_0, A_0, R_1, S_1, A_1, R_2, ..., S_T.',
      '    b. Compute return G = 0.',
      '    c. Loop for each step t = T-1 down to 0:',
      '       G = R_{t+1} + γ * G.',
      '       If S_t does not appear in S_0, S_1, ..., S_{t-1} (First-Visit check):',
      '           Append G to Returns(S_t).',
      '           V(S_t) = average(Returns(S_t)).',
      '4. Return estimated value function V.'
    ],
    procedure: [
      '1. Open the Monte Carlo Simulator workbench.',
      '2. Select the 3-state episodic environment with discount factor γ = 0.9.',
      '3. Choose between "First-Visit MC" and "Every-Visit MC".',
      '4. Generate episodes: Observe sampled trajectory S1 -> S2 -> Terminal with rewards [5, 10].',
      '5. Watch running average value V(S1) converge toward 14.0 and V(S2) converge toward 10.0.',
      '6. Review the comparison matrix contrasting Dynamic Programming, Monte Carlo, and Temporal Difference methods.'
    ],
    code: {
      python: `import numpy as np

class MonteCarlo3State:
    def __init__(self, gamma=0.9):
        self.gamma = gamma
        self.V = {'S1': 0.0, 'S2': 0.0}
        self.returns = {'S1': [], 'S2': []}

    def generate_episode(self):
        # Deterministic 3-state trajectory with small Gaussian noise on rewards
        # S1 -> S2 (reward ~ 5.0), S2 -> Terminal (reward ~ 10.0)
        r1 = np.random.normal(5.0, 0.5)
        r2 = np.random.normal(10.0, 0.5)
        episode = [('S1', r1), ('S2', r2)]
        return episode

    def run_first_visit_mc(self, num_episodes=50):
        for ep in range(1, num_episodes + 1):
            episode = self.generate_episode()
            G = 0.0
            visited = set()
            
            # Backward return calculation
            for state, reward in reversed(episode):
                G = reward + self.gamma * G
                if state not in visited:
                    visited.add(state)
                    self.returns[state].append(G)
                    self.V[state] = np.mean(self.returns[state])
                    
            if ep in [1, 5, 10, 25, 50]:
                print(f"Episode {ep:2d} | V(S1) = {self.V['S1']:5.2f} (Target: 14.0) | V(S2) = {self.V['S2']:5.2f} (Target: 10.0)")

np.random.seed(42)
mc = MonteCarlo3State(gamma=0.9)
print("--- First-Visit Monte Carlo Value Estimation ---")
mc.run_first_visit_mc(num_episodes=50)`
    },
    sampleInput: '3-State episodic environment; Episodes: 50; Discount factor γ = 0.9; Trajectory: S1 -> S2 -> Terminal',
    expectedOutput: 'After 50 episodes, running averages converge close to theoretical values: V(S1) ≈ 14.0, V(S2) ≈ 10.0.',
    references: [
      'Sutton, R. S., & Barto, A. G. (2018), Reinforcement Learning: An Introduction, Chapter 5: Monte Carlo Methods, MIT Press',
      'Singh, S. P., & Sutton, R. S. (1996), Reinforcement learning with replacing eligibility traces, Machine Learning, 22, 123-158'
    ],
    postLabQuestions: [
      { question: 'What is the difference between first-visit and every-visit MC?', answer: 'First-visit MC updates value using returns only after the first occurrence of a state in an episode. Every-visit MC updates value using returns after all visits to that state.' },
      { question: 'Why does Monte Carlo have higher variance than TD learning?', answer: 'Monte Carlo estimates rely on full returns that sum many stochastic transitions and rewards over an entire episode, compounding random variance.' },
      { question: 'Can Monte Carlo methods be used for continuing tasks?', answer: 'No, standard MC requires complete episodes that terminate in order to calculate the total return G_t.' },
      { question: 'How is Monte Carlo fundamentally different from Temporal Difference (TD) learning?', answer: 'MC waits until the end of the episode and updates using actual returns (no bootstrapping). TD updates at each step by bootstrapping using successor value estimates.' },
      { question: 'When is Monte Carlo preferred over Dynamic Programming?', answer: 'When the transition dynamics and reward distributions are unknown or too complex to model analytically, but episodes can be simulated cheaply.' }
    ],
    conclusion: 'The Monte Carlo method estimates value functions using complete episodes and sample returns. It does not require transition probabilities and converges to the true value function with sufficient experience. However, it has higher variance compared to temporal-difference methods. Monte Carlo methods form the foundation for advanced RL algorithms such as Monte Carlo Control and Policy Gradient methods.',
    quiz: [
      {
        id: 1,
        question: 'Which of the following statements about Monte Carlo reinforcement learning is correct?',
        options: [
          'It is model-free and does not bootstrap from successor value estimates',
          'It requires complete transition probability matrices P(s\'|s,a)',
          'It can only be applied to non-terminating continuing tasks',
          'It updates state values after every individual time step'
        ],
        correctAnswer: 0,
        explanation: 'Monte Carlo methods learn directly from complete sampled episodes without requiring an environment model, and do not bootstrap.'
      },
      {
        id: 2,
        question: 'In First-Visit Monte Carlo prediction, when is the return G recorded for a given state?',
        options: [
          'Only upon the first time the state is visited within an episode',
          'Upon every single occurrence of the state in an episode',
          'Only when the agent reaches the terminal state',
          'Prior to taking any action'
        ],
        correctAnswer: 0,
        explanation: 'First-Visit MC only appends return G to Returns(s) if the state has not been visited earlier in that same episode, ensuring unbiasedness.'
      }
    ]
  }
];
