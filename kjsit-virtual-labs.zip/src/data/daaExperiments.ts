import { LabExperiment } from '../types';
import { DAA_CODINGAME_PUZZLES } from './daaCodingamePuzzles';

export const DAA_EXPERIMENTS: LabExperiment[] = [
  // =========================================================================
  // EXPERIMENT 1: Selection Sort for Temperature Observations
  // =========================================================================
  {
    id: 'selection-sort',
    num: 1,
    subjectId: 'daa',
    title: 'Sorting Historical Temperature Observations Using Selection Sort',
    subtitle: 'Iterative Sorting for Weather Station Meteorological Data',
    category: 'Sorting',
    iitReference: 'KJSIT Autonomous Syllabus / AIL303 Lab Manual (Dr. Vaishali Wadhe, Prof. Prashant Bhandare)',
    iitLabUrl: 'https://vlab.amrita.edu/?sub=3&brch=189&sim=543&cnt=1',
    aim: 'To implement the Selection Sort algorithm in C for sorting historical temperature observations collected from multiple weather stations in ascending order.',
    theory: {
      overview: [
        'Weather stations continuously record atmospheric temperature to monitor climatic conditions, identify seasonal changes, predict heatwaves, and support agricultural planning. Since the collected observations may not always be stored in chronological or numerical order, sorting becomes an essential pre-processing step before performing statistical analysis.',
        'Selection Sort is one of the simplest comparison-based sorting algorithms. It works by repeatedly selecting the smallest element from the unsorted portion of the array and placing it at its correct position in the sorted portion. After every iteration, one more element reaches its final position.',
        'Unlike Bubble Sort, Selection Sort performs fewer swap operations because only one swap is performed during each pass. Although its time complexity remains O(n²), Selection Sort is useful for small datasets and educational purposes because of its simplicity and ease of implementation.',
        'In agricultural weather monitoring systems, Selection Sort can be used to organize historical temperature observations collected from different weather stations. Once sorted, researchers can easily identify minimum and maximum temperatures, detect abnormal climatic conditions, calculate temperature ranges, and prepare seasonal reports for crop planning.'
      ],
      complexityTable: [
        { parameter: 'Best Case Time', value: 'O(n²)' },
        { parameter: 'Average Case Time', value: 'O(n²)' },
        { parameter: 'Worst Case Time', value: 'O(n²)' },
        { parameter: 'Space Complexity', value: 'O(1) (In-place)' },
        { parameter: 'Swaps Count', value: 'At most (n - 1) swaps' },
        { parameter: 'Course Outcomes', value: 'LO1, LO3, LO5 (Apply, Analyze)' }
      ],
      keyPoints: [
        'Simple comparison-based sorting algorithm with constant auxiliary memory O(1).',
        'Performs minimum number of swaps compared to other quadratic algorithms.',
        'Preserves low computational memory footprint on edge weather station microcontrollers.',
        'Time complexity remains O(n²) even if input data is already sorted.'
      ],
      realWorldApplications: [
        'Historical temperature observations sorting for heatwave analysis and crop suitability studies.',
        'Arranging weather station temperature readings before statistical reporting.',
        'Low-memory embedded sensor gateways and agricultural telemetry logs.'
      ]
    },
    algorithm: [
      '1. Start.',
      '2. Read the number of temperature observations, n.',
      '3. Read all temperature values into an array.',
      '4. Assume the first unsorted element as the minimum.',
      '5. Compare it with every remaining element in the unsorted portion.',
      '6. If a smaller element is found, update the minimum index.',
      '7. Swap the smallest element with the first unsorted element.',
      '8. Repeat Steps 4–7 for the remaining unsorted portion.',
      '9. Display the sorted temperature observations.',
      '10. Stop.'
    ],
    procedure: [
      '1. Initialize the temperature array with sensor values collected from field weather stations.',
      '2. Run outer loop for i from 0 to n-2 to fix the i-th smallest element.',
      '3. In inner loop, iterate j from i+1 to n-1 to locate minimum value index.',
      '4. Perform swap between temp[i] and temp[min] only if min != i.',
      '5. Output sorted float temperature array with two decimal precision.'
    ],
    code: {
      c: `#include<stdio.h>

int main()
{
 int i, j, n, min;
 float temp[100], swap;

 printf("Enter the number of temperature observations: ");
 scanf("%d",&n);

 printf("Enter the temperature observations:\\n");
 for(i=0;i<n;i++)
 {
   scanf("%f",&temp[i]);
 }

 for(i=0;i<n-1;i++)
 {
   min=i;
   for(j=i+1;j<n;j++)
   {
     if(temp[j]<temp[min])
       min=j;
   }
   if(min!=i)
   {
     swap=temp[i];
     temp[i]=temp[min];
     temp[min]=swap;
   }
 }

 printf("\\nSorted Temperature Observations:\\n");
 for(i=0;i<n;i++)
   printf("%.2f ",temp[i]);

 return 0;
}`,
      cpp: `#include <iostream>
#include <vector>
#include <iomanip>
using namespace std;

int main() {
    int n;
    cout << "Enter the number of temperature observations: ";
    if (!(cin >> n)) return 0;

    vector<float> temp(n);
    cout << "Enter the temperature observations:\\n";
    for(int i = 0; i < n; i++) cin >> temp[i];

    for(int i = 0; i < n - 1; i++) {
        int minIdx = i;
        for(int j = i + 1; j < n; j++) {
            if(temp[j] < temp[minIdx]) minIdx = j;
        }
        if(minIdx != i) swap(temp[i], temp[minIdx]);
    }

    cout << "\\nSorted Temperature Observations:\\n";
    for(float val : temp) cout << fixed << setprecision(2) << val << " ";
    cout << endl;
    return 0;
}`,
      python: `def selection_sort_temperatures(temps):
    n = len(temps)
    for i in range(n - 1):
        min_idx = i
        for j in range(i + 1, n):
            if temps[j] < temps[min_idx]:
                min_idx = j
        if min_idx != i:
            temps[i], temps[min_idx] = temps[min_idx], temps[i]
    return temps

# Example execution
observations = [34.5, 28.2, 41.0, 19.8, 25.4]
sorted_obs = selection_sort_temperatures(observations)
print("Sorted Temperature Observations:")
print(" ".join(f"{x:.2f}" for x in sorted_obs))`,
      java: `import java.util.Scanner;

public class SelectionSortWeather {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of temperature observations: ");
        int n = sc.nextInt();
        float[] temp = new float[n];

        System.out.println("Enter the temperature observations:");
        for(int i = 0; i < n; i++) temp[i] = sc.nextFloat();

        for(int i = 0; i < n - 1; i++) {
            int minIdx = i;
            for(int j = i + 1; j < n; j++) {
                if(temp[j] < temp[minIdx]) minIdx = j;
            }
            if(minIdx != i) {
                float swap = temp[i];
                temp[i] = temp[minIdx];
                temp[minIdx] = swap;
            }
        }

        System.out.println("\\nSorted Temperature Observations:");
        for(float v : temp) System.out.printf("%.2f ", v);
        System.out.println();
    }
}`
    },
    sampleInput: `5\n34.5 28.2 41.0 19.8 25.4`,
    expectedOutput: `Sorted Temperature Observations:\n19.80 25.40 28.20 34.50 41.00`,
    references: [
      'KJSIT Lab Manual: Design and Analysis of Algorithms (AIL303), Academic Year 2026-27 (Dr. Vaishali Wadhe, Prof. Prashant Bhandare)',
      'Cormen, T. H., Leiserson, C. E., Rivest, R. L., & Stein, C. Introduction to Algorithms (CLRS), MIT Press',
      'Horowitz, E., Sahni, S., & Rajasekaran, S. Fundamentals of Computer Algorithms, Silicon Press'
    ],
    conclusion: 'The historical temperature observations collected from multiple weather stations were successfully sorted in ascending order using the Selection Sort algorithm. Selection Sort is suitable for organizing small collections of temperature observations where swap minimization is beneficial.',
    quiz: [
      {
        id: 1,
        question: 'Why is Selection Sort suitable for microcontroller nodes in remote weather stations?',
        options: [
          'It has O(n log n) worst-case running time',
          'It performs at most (n - 1) swaps and requires constant O(1) extra RAM',
          'It is an adaptive algorithm that runs in O(n) for sorted inputs',
          'It requires no comparison operations'
        ],
        correctAnswer: 1,
        explanation: 'Selection Sort performs at most (n - 1) swap operations, reducing expensive flash memory writes on low-power IoT microcontrollers with strict O(1) memory limits.'
      },
      {
        id: 2,
        question: 'What is the time complexity of Selection Sort when the temperature observations are already sorted in ascending order?',
        options: [
          'O(n)',
          'O(n log n)',
          'O(n²)',
          'O(1)'
        ],
        correctAnswer: 2,
        explanation: 'Selection Sort always executes n(n-1)/2 comparisons regardless of whether the array is unsorted, sorted, or reversed, maintaining O(n²) in all cases.'
      }
    ]
  },

  // =========================================================================
  // EXPERIMENT 2: Insertion Sort for IoT Soil Moisture Readings
  // =========================================================================
  {
    id: 'insertion-sort',
    num: 2,
    subjectId: 'daa',
    title: 'Sorting Soil Moisture Readings Collected from IoT Sensors Using Insertion Sort',
    subtitle: 'Adaptive In-Place Sorting for Streaming Agricultural Telemetry',
    category: 'Sorting',
    iitReference: 'KJSIT Autonomous Syllabus / AIL303 Lab Manual (Dr. Vaishali Wadhe, Prof. Prashant Bhandare)',
    iitLabUrl: 'https://vlab.amrita.edu/?sub=3&brch=189&sim=543&cnt=1',
    aim: 'To implement the Insertion Sort algorithm in C for sorting soil moisture readings collected from IoT sensors in ascending order.',
    theory: {
      overview: [
        'Modern precision agriculture relies on Internet of Things (IoT) sensors to continuously monitor soil moisture levels across agricultural fields. These sensors collect moisture data at regular intervals, enabling farmers to optimize irrigation schedules, conserve water, and improve crop productivity. Since sensor readings are collected over time from multiple locations, arranging the data in sorted order helps identify dry regions, wet regions, and abnormal sensor values.',
        'Insertion Sort is a simple comparison-based sorting algorithm that builds the sorted list one element at a time. Similar to arranging playing cards in hand, each newly encountered element is inserted into its correct position within the already sorted portion of the array.',
        'The algorithm starts by assuming that the first element is already sorted. It then picks the next element, compares it with previously sorted elements, shifts larger elements one position to the right, and inserts the selected element into its correct position. This process continues until all elements are sorted.',
        'Unlike Selection Sort, Insertion Sort performs very efficiently when the input data is already partially sorted. Since IoT sensor readings collected at short time intervals generally change gradually, Insertion Sort is particularly suitable for such datasets.'
      ],
      complexityTable: [
        { parameter: 'Best Case Time', value: 'O(n) (Nearly sorted readings)' },
        { parameter: 'Average Case Time', value: 'O(n²)' },
        { parameter: 'Worst Case Time', value: 'O(n²)' },
        { parameter: 'Space Complexity', value: 'O(1) (In-place)' },
        { parameter: 'Stability', value: 'Stable (Preserves sensor timestamp order)' },
        { parameter: 'Course Outcomes', value: 'LO1, LO3, LO5 (Apply, Analyze)' }
      ],
      keyPoints: [
        'Adaptive O(n) performance when sensor readings arrive nearly sorted over time.',
        'Stable algorithm: preserves original chronological sequence for duplicate moisture readings.',
        'Requires shifting elements rightward, which can be computationally intensive on large datasets.',
        'Operates in-place with zero external memory buffers.'
      ],
      realWorldApplications: [
        'Smart irrigation systems sorting hundreds of soil moisture sensors to identify parched farm zones.',
        'Online telemetry ingestion in precision agriculture edge nodes.',
        'Classifying farmland zones according to volumetric water content before automated valve activation.'
      ]
    },
    algorithm: [
      '1. Start.',
      '2. Read the number of soil moisture readings (n).',
      '3. Read all moisture values into an array.',
      '4. Assume the first element is already sorted.',
      '5. Select the next element as the key.',
      '6. Compare the key with all previously sorted elements.',
      '7. Shift all elements greater than the key one position towards the right.',
      '8. Insert the key into its correct position.',
      '9. Repeat Steps 5–8 until all elements are sorted.',
      '10. Display the sorted soil moisture readings.',
      '11. Stop.'
    ],
    procedure: [
      '1. Ingest continuous sensor moisture readings into a floating-point array.',
      '2. Iterate through index i from 1 to n-1, storing moisture[i] as the target key.',
      '3. Initialize pointer j = i - 1.',
      '4. While j >= 0 and moisture[j] > key, shift moisture[j] into moisture[j + 1] and decrement j.',
      '5. Place key at moisture[j + 1]. Print final ascending array.'
    ],
    code: {
      c: `#include<stdio.h>

int main()
{
 int n, i, j;
 float moisture[100], key;

 printf("Enter the number of soil moisture readings: ");
 scanf("%d", &n);

 printf("Enter the soil moisture readings:\\n");
 for(i = 0; i < n; i++)
 {
   scanf("%f", &moisture[i]);
 }

 for(i = 1; i < n; i++)
 {
   key = moisture[i];
   j = i - 1;
   while(j >= 0 && moisture[j] > key)
   {
     moisture[j + 1] = moisture[j];
     j--;
   }
   moisture[j + 1] = key;
 }

 printf("\\nSorted Soil Moisture Readings:\\n");
 for(i = 0; i < n; i++)
 {
   printf("%.2f ", moisture[i]);
 }

 return 0;
}`,
      cpp: `#include <iostream>
#include <vector>
#include <iomanip>
using namespace std;

int main() {
    int n;
    cout << "Enter number of soil moisture readings: ";
    if (!(cin >> n)) return 0;

    vector<float> moisture(n);
    cout << "Enter the soil moisture readings:\\n";
    for(int i = 0; i < n; i++) cin >> moisture[i];

    for(int i = 1; i < n; i++) {
        float key = moisture[i];
        int j = i - 1;
        while(j >= 0 && moisture[j] > key) {
            moisture[j + 1] = moisture[j];
            j--;
        }
        moisture[j + 1] = key;
    }

    cout << "\\nSorted Soil Moisture Readings:\\n";
    for(float v : moisture) cout << fixed << setprecision(2) << v << " ";
    cout << endl;
    return 0;
}`,
      python: `def insertion_sort_moisture(readings):
    n = len(readings)
    for i in range(1, n):
        key = readings[i]
        j = i - 1
        while j >= 0 and readings[j] > key:
            readings[j + 1] = readings[j]
            j -= 1
        readings[j + 1] = key
    return readings

# Example telemetry from field IoT nodes
sensors = [45.2, 38.5, 48.0, 22.1, 35.6, 40.2]
sorted_sensors = insertion_sort_moisture(sensors)
print("Sorted Soil Moisture Readings:")
print(" ".join(f"{x:.2f}" for x in sorted_sensors))`,
      java: `import java.util.Scanner;

public class InsertionSortSoil {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of soil moisture readings: ");
        int n = sc.nextInt();
        float[] moisture = new float[n];

        System.out.println("Enter the soil moisture readings:");
        for(int i = 0; i < n; i++) moisture[i] = sc.nextFloat();

        for(int i = 1; i < n; i++) {
            float key = moisture[i];
            int j = i - 1;
            while(j >= 0 && moisture[j] > key) {
                moisture[j + 1] = moisture[j];
                j--;
            }
            moisture[j + 1] = key;
        }

        System.out.println("\\nSorted Soil Moisture Readings:");
        for(float v : moisture) System.out.printf("%.2f ", v);
        System.out.println();
    }
}`
    },
    sampleInput: `6\n45.2 38.5 48.0 22.1 35.6 40.2`,
    expectedOutput: `Sorted Soil Moisture Readings:\n22.10 35.60 38.50 40.20 45.20 48.00`,
    references: [
      'KJSIT Lab Manual: Design and Analysis of Algorithms (AIL303), Academic Year 2026-27 (Dr. Vaishali Wadhe, Prof. Prashant Bhandare)',
      'Knuth, D. E. The Art of Computer Programming, Volume 3: Sorting and Searching',
      'Sedgewick, R., & Wayne, K. Algorithms (4th ed.), Addison-Wesley'
    ],
    conclusion: 'The soil moisture readings collected from IoT sensors were successfully sorted in ascending order using the Insertion Sort algorithm. Insertion Sort is an efficient algorithm for sorting small or nearly sorted datasets, making it a practical choice for embedded and real-time agricultural monitoring systems.',
    quiz: [
      {
        id: 1,
        question: 'Why is Insertion Sort especially advantageous for periodic IoT soil moisture streams?',
        options: [
          'It always operates in O(1) space and achieves O(n) linear time when sensor data changes gradually',
          'It eliminates comparisons entirely',
          'It divides the problem into logarithmic subproblems',
          'It is immune to worst-case complexity'
        ],
        correctAnswer: 0,
        explanation: 'Because soil moisture levels generally vary slowly between consecutive measurement epochs, newly polled sensor streams are nearly sorted, allowing Insertion Sort to run in near-linear O(n) time.'
      }
    ]
  },

  // =========================================================================
  // EXPERIMENT 3: Merge Sort for Merging Multi-Village Datasets
  // =========================================================================
  {
    id: 'merge-sort',
    num: 3,
    subjectId: 'daa',
    title: 'Merging Weather Forecast and Soil Moisture Datasets Collected from Multiple Villages Using Merge Sort',
    subtitle: 'Divide-and-Conquer Integration for Unified Smart Farming Databases',
    category: 'Divide and Conquer',
    iitReference: 'KJSIT Autonomous Syllabus / AIL303 Lab Manual (Dr. Vaishali Wadhe, Prof. Prashant Bhandare)',
    iitLabUrl: 'https://vlab.amrita.edu/?sub=3&brch=189&sim=543&cnt=1',
    aim: 'To implement the Merge Sort algorithm in C for sorting and merging weather forecast and soil moisture datasets collected from multiple villages into a unified agricultural database.',
    theory: {
      overview: [
        'Modern smart agriculture relies on data collected from multiple sources such as automatic weather stations, IoT-based soil moisture sensors, humidity sensors, rainfall gauges, and crop monitoring systems. These datasets are collected from different villages and need to be integrated into a centralized agricultural database for effective decision-making.',
        'Since the data received from different locations is usually unsorted, an efficient sorting algorithm is required before performing data integration, statistical analysis, machine learning, or predictive analytics.',
        'Merge Sort is a Divide and Conquer algorithm that recursively divides a dataset into smaller sub-arrays until each sub-array contains only one element. These sub-arrays are then merged in sorted order to produce a completely sorted dataset.',
        'The Merge Sort algorithm consists of three major phases: 1. Divide (recursively split in two halves), 2. Conquer (sort halves recursively), and 3. Combine/Merge (merge two sorted subarrays in linear time).',
        'Because agricultural databases often contain thousands or millions of observations, Merge Sort is widely used because of its guaranteed O(n log n) running time and stability.'
      ],
      complexityTable: [
        { parameter: 'Best Case Time', value: 'O(n log n)' },
        { parameter: 'Average Case Time', value: 'O(n log n)' },
        { parameter: 'Worst Case Time', value: 'O(n log n)' },
        { parameter: 'Space Complexity', value: 'O(n) (Auxiliary buffer)' },
        { parameter: 'Stability', value: 'Stable (Preserves village timestamps)' },
        { parameter: 'Course Outcomes', value: 'LO2, LO3, LO5 (Apply, Analyze)' }
      ],
      keyPoints: [
        'Guaranteed O(n log n) performance regardless of initial dataset permutation.',
        'Stable sorting retains order of identical sensor observations from different villages.',
        'Requires O(n) auxiliary temporary storage during the two-way merge phase.',
        'Well-suited for external sorting and parallel agricultural data pipelines.'
      ],
      realWorldApplications: [
        'Merging simultaneous sensor feeds from 5+ agricultural villages into a centralized dashboard.',
        'Predicting district irrigation requirements and analyzing regional climatic variations.',
        'Preparing training datasets for AI-based crop recommendation systems.'
      ]
    },
    algorithm: [
      '1. Start.',
      '2. Read the number of observations.',
      '3. Store weather and soil moisture data in an array.',
      '4. Divide the dataset into two equal halves.',
      '5. Recursively apply Merge Sort to the left half.',
      '6. Recursively apply Merge Sort to the right half.',
      '7. Merge both sorted halves into one sorted array.',
      '8. Display the merged sorted dataset.',
      '9. Stop.'
    ],
    procedure: [
      '1. Populate array with combined telemetry values from multiple rural centers.',
      '2. In mergeSort(arr, low, high): compute mid = (low + high) / 2.',
      '3. Recursively sort subarray [low...mid] and [mid+1...high].',
      '4. In merge(arr, low, mid, high): allocate temp buffer, compare elements from both halves, and copy merged result back to arr.',
      '5. Output unified sorted agricultural dataset.'
    ],
    code: {
      c: `#include<stdio.h>

void merge(int arr[], int low, int mid, int high)
{
 int i, j, k;
 int temp[100];
 i = low;
 j = mid + 1;
 k = low;
 while(i <= mid && j <= high)
 {
   if(arr[i] <= arr[j])
     temp[k++] = arr[i++];
   else
     temp[k++] = arr[j++];
 }
 while(i <= mid)
   temp[k++] = arr[i++];
 while(j <= high)
   temp[k++] = arr[j++];
 for(i = low; i <= high; i++)
   arr[i] = temp[i];
}

void mergeSort(int arr[], int low, int high)
{
 int mid;
 if(low < high)
 {
   mid = (low + high) / 2;
   mergeSort(arr, low, mid);
   mergeSort(arr, mid + 1, high);
   merge(arr, low, mid, high);
 }
}

int main()
{
 int arr[100], n, i;
 printf("Enter number of agricultural observations: ");
 scanf("%d",&n);
 printf("Enter weather forecast / soil moisture values:\\n");
 for(i = 0; i < n; i++)
   scanf("%d",&arr[i]);

 mergeSort(arr,0,n-1);

 printf("\\nMerged and Sorted Agricultural Dataset:\\n");
 for(i = 0; i < n; i++)
   printf("%d ",arr[i]);
 return 0;
}`,
      cpp: `#include <iostream>
#include <vector>
using namespace std;

void merge(vector<int>& arr, int low, int mid, int high) {
    vector<int> temp(high - low + 1);
    int i = low, j = mid + 1, k = 0;
    while(i <= mid && j <= high) {
        if(arr[i] <= arr[j]) temp[k++] = arr[i++];
        else temp[k++] = arr[j++];
    }
    while(i <= mid) temp[k++] = arr[i++];
    while(j <= high) temp[k++] = arr[j++];
    for(int p = 0; p < k; p++) arr[low + p] = temp[p];
}

void mergeSort(vector<int>& arr, int low, int high) {
    if(low < high) {
        int mid = low + (high - low) / 2;
        mergeSort(arr, low, mid);
        mergeSort(arr, mid + 1, high);
        merge(arr, low, mid, high);
    }
}

int main() {
    int n;
    cout << "Enter number of agricultural observations: ";
    if (!(cin >> n)) return 0;
    vector<int> arr(n);
    cout << "Enter weather forecast / soil moisture values:\\n";
    for(int i = 0; i < n; i++) cin >> arr[i];

    mergeSort(arr, 0, n - 1);

    cout << "\\nMerged and Sorted Agricultural Dataset:\\n";
    for(int v : arr) cout << v << " ";
    cout << endl;
    return 0;
}`,
      python: `def merge_sort(arr):
    if len(arr) <= 1:
        return arr
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    
    merged = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            merged.append(left[i])
            i += 1
        else:
            merged.append(right[j])
            j += 1
    merged.extend(left[i:])
    merged.extend(right[j:])
    return merged

# Example combining 2 village datasets
observations = [32, 18, 45, 27, 12, 39]
sorted_obs = merge_sort(observations)
print("Merged and Sorted Agricultural Dataset:")
print(" ".join(map(str, sorted_obs)))`,
      java: `import java.util.Scanner;

public class MergeSortAgri {
    static void merge(int[] arr, int low, int mid, int high) {
        int[] temp = new int[high - low + 1];
        int i = low, j = mid + 1, k = 0;
        while(i <= mid && j <= high) {
            if(arr[i] <= arr[j]) temp[k++] = arr[i++];
            else temp[k++] = arr[j++];
        }
        while(i <= mid) temp[k++] = arr[i++];
        while(j <= high) temp[k++] = arr[j++];
        for(int p = 0; p < k; p++) arr[low + p] = temp[p];
    }

    static void mergeSort(int[] arr, int low, int high) {
        if(low < high) {
            int mid = (low + high) / 2;
            mergeSort(arr, low, mid);
            mergeSort(arr, mid + 1, high);
            merge(arr, low, mid, high);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of agricultural observations: ");
        int n = sc.nextInt();
        int[] arr = new int[n];
        System.out.println("Enter weather forecast / soil moisture values:");
        for(int i = 0; i < n; i++) arr[i] = sc.nextInt();

        mergeSort(arr, 0, n - 1);

        System.out.println("\\nMerged and Sorted Agricultural Dataset:");
        for(int v : arr) System.out.print(v + " ");
        System.out.println();
    }
}`
    },
    sampleInput: `6\n32 18 45 27 12 39`,
    expectedOutput: `Merged and Sorted Agricultural Dataset:\n12 18 27 32 39 45`,
    references: [
      'KJSIT Lab Manual: Design and Analysis of Algorithms (AIL303), Academic Year 2026-27 (Dr. Vaishali Wadhe, Prof. Prashant Bhandare)',
      'Cormen, T. H., Leiserson, C. E., Rivest, R. L., & Stein, C. Introduction to Algorithms (CLRS), MIT Press',
      'Aho, A. V., Hopcroft, J. E., & Ullman, J. D. The Design and Analysis of Computer Algorithms'
    ],
    conclusion: 'Merge Sort is an efficient Divide and Conquer algorithm that provides consistent O(n log n) performance regardless of the input order. Its stability and predictable running time make it suitable for handling large agricultural datasets generated by IoT devices and weather monitoring systems.',
    quiz: [
      {
        id: 1,
        question: 'What is the recurrence relation governing Merge Sort running time?',
        options: [
          'T(n) = 2T(n/2) + O(n)',
          'T(n) = T(n - 1) + O(n)',
          'T(n) = 2T(n/2) + O(1)',
          'T(n) = T(n/2) + O(n)'
        ],
        correctAnswer: 0,
        explanation: 'By the Master Theorem, T(n) = 2T(n/2) + O(n) resolves to Θ(n log n).'
      }
    ]
  },

  // =========================================================================
  // EXPERIMENT 4: Quick Sort for Ranking Districts for Heatwave Priority
  // =========================================================================
  {
    id: 'quick-sort',
    num: 4,
    subjectId: 'daa',
    title: 'Ranking Districts According to Maximum Temperature and Generating Heatwave Priority Lists Using Quick Sort',
    subtitle: 'Divide-and-Conquer Partitioning for Climate Risk Prioritization',
    category: 'Divide and Conquer',
    iitReference: 'KJSIT Autonomous Syllabus / AIL303 Lab Manual (Dr. Vaishali Wadhe, Prof. Prashant Bhandare)',
    iitLabUrl: 'https://vlab.amrita.edu/?sub=3&brch=189&sim=543&cnt=1',
    aim: 'To implement the Quick Sort algorithm in C for ranking districts according to their maximum recorded temperatures and generating a heatwave priority list for agricultural planning.',
    theory: {
      overview: [
        'Heatwaves have become one of the most significant climatic challenges affecting agriculture worldwide. Extremely high temperatures reduce crop productivity, increase irrigation requirements, accelerate soil moisture loss, and adversely affect livestock health. Government agencies and agricultural departments continuously monitor district-wise temperature data to identify regions that require immediate intervention.',
        'Before preparing heatwave advisories and allocating resources, districts must be ranked according to their maximum recorded temperatures. Efficient sorting algorithms are therefore essential in climate monitoring systems.',
        'Quick Sort is one of the fastest comparison-based sorting algorithms and follows the Divide and Conquer strategy. Instead of repeatedly selecting the minimum element like Selection Sort or merging sub-arrays like Merge Sort, Quick Sort selects a pivot element, partitions the dataset around the pivot, and recursively sorts the resulting sub-arrays.',
        'The algorithm consists of three main steps: 1. Pivot Selection (e.g. last element), 2. Partitioning (placing elements smaller than pivot on left, greater on right), and 3. Recursive Sorting of partitions.',
        'Districts with the highest temperatures are listed first so agricultural officers can issue advisories, schedule emergency irrigation, and distribute heat-resistant seeds.'
      ],
      complexityTable: [
        { parameter: 'Best Case Time', value: 'O(n log n)' },
        { parameter: 'Average Case Time', value: 'O(n log n)' },
        { parameter: 'Worst Case Time', value: 'O(n²)' },
        { parameter: 'Auxiliary Space', value: 'O(log n) (Call stack)' },
        { parameter: 'In-Place Property', value: 'Yes (Sorts without extra array)' },
        { parameter: 'Course Outcomes', value: 'LO2, LO3, LO5 (Apply, Analyze)' }
      ],
      keyPoints: [
        'Very fast general-purpose sorting algorithm with O(n log n) expected time.',
        'In-place sorting eliminates the need for temporary array buffers.',
        'Ranks district temperatures in descending order to output heatwave priority lists.',
        'Performance sensitive to pivot selection strategy.'
      ],
      realWorldApplications: [
        'Meteorological department district temperature ranking for heatwave advisories.',
        'Emergency water resource deployment and drought relief prioritization.',
        'Recommending heat-tolerant crop varieties to vulnerable farm zones.'
      ]
    },
    algorithm: [
      '1. Start.',
      '2. Read the number of districts.',
      '3. Read district names and maximum temperatures.',
      '4. Select the last element as the pivot.',
      '5. Partition the array such that elements smaller than pivot are placed before it and larger after it.',
      '6. Recursively apply Quick Sort to the left partition.',
      '7. Recursively apply Quick Sort to the right partition.',
      '8. Display the sorted district temperature list.',
      '9. Generate the heatwave priority ranking.',
      '10. Stop.'
    ],
    procedure: [
      '1. Ingest maximum temperature records across n districts into array a[].',
      '2. Call quickSort(a, 0, n-1).',
      '3. In partition(a, low, high): set pivot = a[high]. Rearrange elements such that a[i] <= pivot on left.',
      '4. Recursively sort partitions before and after the pivot index.',
      '5. Print array in descending order (from high to low) to display top heatwave alert districts.'
    ],
    code: {
      c: `#include<stdio.h>

void quickSort(int a[], int low, int high);
int partition(int a[], int low, int high);

int main()
{
 int a[100], n, i;
 printf("Enter number of districts: ");
 scanf("%d",&n);
 printf("Enter maximum temperatures:\\n");
 for(i=0;i<n;i++)
   scanf("%d",&a[i]);

 quickSort(a,0,n-1);

 printf("\\nDistrict Temperature Ranking (Highest to Lowest):\\n");
 for(i=n-1;i>=0;i--)
   printf("%d ",a[i]);
 return 0;
}

void quickSort(int a[], int low, int high)
{
 int p;
 if(low<high)
 {
   p=partition(a,low,high);
   quickSort(a,low,p-1);
   quickSort(a,p+1,high);
 }
}

int partition(int a[], int low, int high)
{
 int pivot=a[high];
 int i=low-1;
 int j,temp;
 for(j=low;j<high;j++)
 {
   if(a[j]<=pivot)
   {
     i++;
     temp=a[i];
     a[i]=a[j];
     a[j]=temp;
   }
 }
 temp=a[i+1];
 a[i+1]=a[high];
 a[high]=temp;
 return i+1;
}`,
      cpp: `#include <iostream>
#include <vector>
using namespace std;

int partition(vector<int>& a, int low, int high) {
    int pivot = a[high];
    int i = low - 1;
    for(int j = low; j < high; j++) {
        if(a[j] <= pivot) {
            i++;
            swap(a[i], a[j]);
        }
    }
    swap(a[i + 1], a[high]);
    return i + 1;
}

void quickSort(vector<int>& a, int low, int high) {
    if(low < high) {
        int p = partition(a, low, high);
        quickSort(a, low, p - 1);
        quickSort(a, p + 1, high);
    }
}

int main() {
    int n;
    cout << "Enter number of districts: ";
    if (!(cin >> n)) return 0;
    vector<int> a(n);
    cout << "Enter maximum temperatures:\\n";
    for(int i = 0; i < n; i++) cin >> a[i];

    quickSort(a, 0, n - 1);

    cout << "\\nDistrict Temperature Ranking (Heatwave Priority):\\n";
    for(int i = n - 1; i >= 0; i--) cout << a[i] << " ";
    cout << endl;
    return 0;
}`,
      python: `def quick_sort(a, low, high):
    if low < high:
        p = partition(a, low, high)
        quick_sort(a, low, p - 1)
        quick_sort(a, p + 1, high)

def partition(a, low, high):
    pivot = a[high]
    i = low - 1
    for j in range(low, high):
        if a[j] <= pivot:
            i += 1
            a[i], a[j] = a[j], a[i]
    a[i + 1], a[high] = a[high], a[i + 1]
    return i + 1

# District temperature inputs
temps = [38, 45, 41, 47, 39]
quick_sort(temps, 0, len(temps) - 1)
print("District Temperature Ranking (Heatwave Priority):")
print(" ".join(map(str, reversed(temps))))`,
      java: `import java.util.Scanner;

public class QuickSortHeatwave {
    static int partition(int[] a, int low, int high) {
        int pivot = a[high];
        int i = low - 1;
        for(int j = low; j < high; j++) {
            if(a[j] <= pivot) {
                i++;
                int temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
        int temp = a[i + 1];
        a[i + 1] = a[high];
        a[high] = temp;
        return i + 1;
    }

    static void quickSort(int[] a, int low, int high) {
        if(low < high) {
            int p = partition(a, low, high);
            quickSort(a, low, p - 1);
            quickSort(a, p + 1, high);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of districts: ");
        int n = sc.nextInt();
        int[] a = new int[n];
        System.out.println("Enter maximum temperatures:");
        for(int i = 0; i < n; i++) a[i] = sc.nextInt();

        quickSort(a, 0, n - 1);

        System.out.println("\\nDistrict Temperature Ranking (Heatwave Priority):");
        for(int i = n - 1; i >= 0; i--) System.out.print(a[i] + " ");
        System.out.println();
    }
}`
    },
    sampleInput: `5\n38 45 41 47 39`,
    expectedOutput: `District Temperature Ranking (Highest to Lowest):\n47 45 41 39 38`,
    references: [
      'KJSIT Lab Manual: Design and Analysis of Algorithms (AIL303), Academic Year 2026-27 (Dr. Vaishali Wadhe, Prof. Prashant Bhandare)',
      'Hoare, C. A. R. (1962). Quicksort. The Computer Journal, 5(1), 10-16',
      'Cormen, T. H. et al. Introduction to Algorithms (3rd ed.)'
    ],
    conclusion: 'Quick Sort is one of the fastest sorting algorithms for large datasets and is widely used in real-world applications. Although its worst-case time complexity is O(n²), its average performance of O(n log n) makes it highly efficient for ranking district temperatures in agricultural decision-support systems.',
    quiz: [
      {
        id: 1,
        question: 'Under what input condition does Quick Sort exhibit its worst-case O(n²) performance when using the last element as pivot?',
        options: [
          'When the array elements are randomized',
          'When the array is already sorted in ascending or descending order',
          'When all elements are negative',
          'When n is a power of 2'
        ],
        correctAnswer: 1,
        explanation: 'If the array is already sorted, picking the last element as pivot creates unbalanced partitions of size 0 and n-1 at each step, yielding O(n²) quadratic runtime.'
      }
    ]
  },

  // =========================================================================
  // EXPERIMENT 5: Kruskal's Algorithm for Minimum Cost Wireless Sensor Network
  // =========================================================================
  {
    id: 'kruskals',
    num: 5,
    subjectId: 'daa',
    title: 'Designing a Minimum-Cost Wireless Sensor Network Connecting Agricultural Fields Using Kruskal\'s Algorithm',
    subtitle: 'Greedy Minimum Spanning Tree for Agricultural IoT Infrastructure',
    category: 'Greedy Method',
    iitReference: 'KJSIT Autonomous Syllabus / AIL303 Lab Manual (Dr. Vaishali Wadhe, Prof. Prashant Bhandare)',
    iitLabUrl: 'https://vlab.amrita.edu/?sub=3&brch=189&sim=543&cnt=1',
    aim: 'To implement Kruskal\'s Algorithm in C for designing a minimum-cost wireless sensor network connecting agricultural fields.',
    theory: {
      overview: [
        'Smart agriculture extensively uses Wireless Sensor Networks (WSNs) to monitor environmental parameters such as soil moisture, temperature, humidity, soil pH, rainfall, and crop health. These sensors are deployed across agricultural fields and communicate wirelessly with a central monitoring station.',
        'Since installing communication links between every pair of sensor nodes is expensive and unnecessary, an optimal communication network must be designed that connects all sensors with the minimum installation cost.',
        'This problem is represented using a weighted undirected graph, where: Each vertex represents an agricultural field or sensor node; each edge represents a wireless communication link; the weight of an edge represents the installation cost, communication distance, or transmission energy.',
        'This problem is solved using the Minimum Spanning Tree (MST): connects every vertex, contains no cycles, uses exactly (V - 1) edges, and has the minimum total edge weight.',
        'Kruskal\'s Algorithm follows the Greedy Strategy: sorts all edges in increasing order of weight, picks the smallest edge, checks whether it creates a cycle using the Disjoint Set (Union-Find) structure, and adds it if safe until (V - 1) edges are selected.'
      ],
      complexityTable: [
        { parameter: 'Edge Sorting Time', value: 'O(E log E)' },
        { parameter: 'Union-Find Operations', value: 'O(E · α(V))' },
        { parameter: 'Overall Time Complexity', value: 'O(E log E)' },
        { parameter: 'Space Complexity', value: 'O(V + E)' },
        { parameter: 'Strategy', value: 'Greedy with Disjoint Set' },
        { parameter: 'Course Outcomes', value: 'LO2, LO4, LO5 (Apply, Analyze)' }
      ],
      keyPoints: [
        'Produces an optimal minimum spanning tree connecting all farmland sensors.',
        'Greedy local choice guarantees global minimum communication cost.',
        'Cycle detection accomplished efficiently using parent array in Union-Find.',
        'Highly suitable for sparse agricultural field graphs.'
      ],
      realWorldApplications: [
        'Precision agriculture wireless sensor networks connecting field probes to gateway stations.',
        'Cost-optimal automated drip irrigation pipeline network routing.',
        'Rural broadband telemetry backbones linking village weather towers.'
      ]
    },
    algorithm: [
      '1. Start.',
      '2. Read the number of vertices and edges.',
      '3. Store all communication links with their costs.',
      '4. Sort all edges in ascending order of cost.',
      '5. Initialize every vertex as an independent set (parent[i] = i).',
      '6. Select the edge with minimum weight.',
      '7. Check whether adding the edge forms a cycle using find().',
      '8. If no cycle exists: Include edge in MST; Merge the corresponding sets using unionSet().',
      '9. Repeat Steps 6–8 until (V - 1) edges are selected.',
      '10. Display the Minimum Spanning Tree and total installation cost.',
      '11. Stop.'
    ],
    procedure: [
      '1. Define struct Edge { int u, v, weight; } to represent wireless links between farms.',
      '2. Ingest graph vertices V, total links E, and edge weights (source, destination, cost).',
      '3. Sort edge array in non-decreasing order of cost.',
      '4. Iterate through sorted edges, calling find() on both endpoints to verify they belong to disjoint components.',
      '5. Union endpoints, add link to MST array, and accumulate totalCost until count == V - 1.',
      '6. Output chosen communication links and minimal overall network budget.'
    ],
    code: {
      c: `#include<stdio.h>
#include<stdlib.h>
#define MAX 20

struct Edge
{
 int u, v, weight;
};

struct Edge edge[MAX], mst[MAX];
int parent[MAX];

int find(int i)
{
 while(parent[i] != i)
   i = parent[i];
 return i;
}

void unionSet(int a, int b)
{
 parent[a] = b;
}

int main()
{
 int vertices, edges;
 int i, j, count = 0;
 int totalCost = 0;

 printf("Enter number of vertices: ");
 scanf("%d",&vertices);
 printf("Enter number of edges: ");
 scanf("%d",&edges);

 printf("\\nEnter Source Destination Cost\\n");
 for(i=0;i<edges;i++)
 {
   scanf("%d%d%d",&edge[i].u,&edge[i].v,&edge[i].weight);
 }

 for(i=0;i<vertices;i++)
   parent[i]=i;

 for(i=0;i<edges-1;i++)
 {
   for(j=0;j<edges-i-1;j++)
   {
     if(edge[j].weight > edge[j+1].weight)
     {
       struct Edge temp=edge[j];
       edge[j]=edge[j+1];
       edge[j+1]=temp;
     }
   }
 }

 for(i=0;i<edges && count<vertices-1;i++)
 {
   int a=find(edge[i].u);
   int b=find(edge[i].v);
   if(a!=b)
   {
     mst[count]=edge[i];
     totalCost+=edge[i].weight;
     unionSet(a,b);
     count++;
   }
 }

 printf("\\nMinimum Cost Wireless Sensor Network\\n\\n");
 printf("Edge\\tCost\\n");
 for(i=0;i<count;i++)
   printf("%d - %d\\t%d\\n", mst[i].u,mst[i].v,mst[i].weight);
 printf("\\nTotal Installation Cost = %d\\n",totalCost);

 return 0;
}`,
      cpp: `#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Edge {
    int u, v, weight;
    bool operator<(const Edge& other) const {
        return weight < other.weight;
    }
};

struct DisjointSet {
    vector<int> parent;
    DisjointSet(int n) : parent(n) {
        for(int i = 0; i < n; i++) parent[i] = i;
    }
    int find(int i) {
        if(parent[i] == i) return i;
        return parent[i] = find(parent[i]);
    }
    bool unite(int i, int j) {
        int rootI = find(i), rootJ = find(j);
        if(rootI != rootJ) {
            parent[rootI] = rootJ;
            return true;
        }
        return false;
    }
};

int main() {
    int vertices, edges;
    cout << "Enter number of vertices and edges: ";
    if (!(cin >> vertices >> edges)) return 0;

    vector<Edge> edgeList(edges);
    cout << "Enter Source Destination Cost:\\n";
    for(int i = 0; i < edges; i++) cin >> edgeList[i].u >> edgeList[i].v >> edgeList[i].weight;

    sort(edgeList.begin(), edgeList.end());

    DisjointSet ds(vertices);
    int totalCost = 0;
    vector<Edge> mst;

    for(const auto& e : edgeList) {
        if(ds.unite(e.u, e.v)) {
            mst.push_back(e);
            totalCost += e.weight;
            if(mst.size() == vertices - 1) break;
        }
    }

    cout << "\\nMinimum Cost Wireless Sensor Network\\n";
    cout << "Edge\\tCost\\n";
    for(const auto& e : mst) cout << e.u << " - " << e.v << "\\t" << e.weight << "\\n";
    cout << "\\nTotal Installation Cost = " << totalCost << endl;
    return 0;
}`,
      python: `class DisjointSet:
    def __init__(self, n):
        self.parent = list(range(n))
    def find(self, i):
        while self.parent[i] != i:
            i = self.parent[i]
        return i
    def union(self, a, b):
        self.parent[a] = b

def kruskal_sensor_network(vertices, edges):
    # Sort edges by weight
    edges.sort(key=lambda x: x[2])
    ds = DisjointSet(vertices)
    mst = []
    total_cost = 0

    for u, v, weight in edges:
        root_u = ds.find(u)
        root_v = ds.find(v)
        if root_u != root_v:
            mst.append((u, v, weight))
            total_cost += weight
            ds.union(root_u, root_v)
            if len(mst) == vertices - 1:
                break
    return mst, total_cost

# Farmland sensor connectivity sample
V = 4
E = [(0, 1, 10), (0, 2, 6), (0, 3, 5), (1, 3, 15), (2, 3, 4)]
mst, cost = kruskal_sensor_network(V, E)
print("Minimum Cost Wireless Sensor Network:")
for u, v, w in mst:
    print(f"{u} - {v}\\t{w}")
print(f"Total Installation Cost = {cost}")`,
      java: `import java.util.*;

class Edge implements Comparable<Edge> {
    int u, v, weight;
    public Edge(int u, int v, int weight) {
        this.u = u; this.v = v; this.weight = weight;
    }
    public int compareTo(Edge o) {
        return Integer.compare(this.weight, o.weight);
    }
}

public class KruskalSensorNet {
    static int find(int[] parent, int i) {
        while(parent[i] != i) i = parent[i];
        return i;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of vertices: ");
        int vertices = sc.nextInt();
        System.out.print("Enter number of edges: ");
        int edges = sc.nextInt();

        List<Edge> edgeList = new ArrayList<>();
        System.out.println("Enter Source Destination Cost:");
        for(int i = 0; i < edges; i++) {
            edgeList.add(new Edge(sc.nextInt(), sc.nextInt(), sc.nextInt()));
        }

        Collections.sort(edgeList);
        int[] parent = new int[vertices];
        for(int i = 0; i < vertices; i++) parent[i] = i;

        int totalCost = 0;
        List<Edge> mst = new ArrayList<>();

        for(Edge e : edgeList) {
            int a = find(parent, e.u);
            int b = find(parent, e.v);
            if(a != b) {
                mst.add(e);
                totalCost += e.weight;
                parent[a] = b;
                if(mst.size() == vertices - 1) break;
            }
        }

        System.out.println("\\nMinimum Cost Wireless Sensor Network\\nEdge\\tCost");
        for(Edge e : mst) System.out.println(e.u + " - " + e.v + "\\t" + e.weight);
        System.out.println("\\nTotal Installation Cost = " + totalCost);
    }
}`
    },
    sampleInput: `4\n5\n0 1 10\n0 2 6\n0 3 5\n1 3 15\n2 3 4`,
    expectedOutput: `Minimum Cost Wireless Sensor Network\n\nEdge\tCost\n2 - 3\t4\n0 - 3\t5\n0 - 1\t10\n\nTotal Installation Cost = 19`,
    references: [
      'KJSIT Lab Manual: Design and Analysis of Algorithms (AIL303), Academic Year 2026-27 (Dr. Vaishali Wadhe, Prof. Prashant Bhandare)',
      'Kruskal, J. B. (1956). On the shortest spanning subtree of a graph. Proc. Amer. Math. Soc.',
      'Tarjan, R. E. (1975). Efficiency of a good but not linear set union algorithm. JACM'
    ],
    conclusion: 'A minimum-cost wireless sensor network connecting all agricultural fields was successfully designed using Kruskal\'s Algorithm, ensuring complete connectivity with the least possible installation cost.',
    quiz: [
      {
        id: 1,
        question: 'Why does Kruskal\'s algorithm utilize the Disjoint Set (Union-Find) data structure?',
        options: [
          'To detect cycles in near-constant time when testing candidate edges',
          'To sort the edges in ascending order',
          'To store node coordinates in geographic space',
          'To compute all-pairs shortest paths'
        ],
        correctAnswer: 0,
        explanation: 'Union-Find provides near-constant O(α(V)) cycle detection, guaranteeing that adding an edge does not connect vertices already in the same connected component.'
      }
    ]
  },

  // =========================================================================
  // EXPERIMENT 6: TSP Dynamic Programming with Bitmasking for Farm Visits
  // =========================================================================
  {
    id: 'tsp',
    num: 6,
    subjectId: 'daa',
    title: 'Planning the Shortest Route for Agricultural Officers Visiting Multiple Farms Using Traveling Salesperson Problem (Dynamic Programming)',
    subtitle: 'Dynamic Programming with Bitmasking for Field Inspection Tours',
    category: 'Dynamic Programming',
    iitReference: 'KJSIT Autonomous Syllabus / AIL303 Lab Manual (Dr. Vaishali Wadhe, Prof. Prashant Bhandare)',
    iitLabUrl: 'https://vlab.amrita.edu/?sub=3&brch=189&sim=543&cnt=1',
    aim: 'To implement the Traveling Salesperson Problem (TSP) using Dynamic Programming in C to determine the shortest route for agricultural officers visiting multiple farms and returning to the starting location.',
    theory: {
      overview: [
        'In modern agriculture, agricultural officers, extension workers, and field inspectors frequently visit multiple farms to monitor crop health, assess irrigation systems, inspect pest infestations, collect soil samples, and provide technical guidance to farmers. Planning an efficient travel route is essential to reduce travel time, fuel consumption, operational costs, and overall inspection duration.',
        'This problem can be modeled using the Traveling Salesperson Problem (TSP). Given a set of farms and the distances between every pair of locations, the objective is to determine the shortest possible route that visits every location exactly once, returns to the starting location, and minimizes the total travel distance or cost.',
        'The TSP belongs to the class of NP-Hard problems, meaning that no polynomial-time algorithm is known for solving all instances optimally.',
        'For a small number of locations, the problem can be solved optimally using Dynamic Programming with Bit Masking. Instead of solving the same subproblem repeatedly, the solution of each subproblem is stored in dp[mask][pos] (where mask encodes visited farms in binary, and pos is the current farm) and reused whenever required.',
        'Compared with brute-force search (O(n!)), Dynamic Programming significantly reduces redundant computations to O(n² · 2ⁿ).'
      ],
      complexityTable: [
        { parameter: 'Number of States', value: '2ⁿ × n' },
        { parameter: 'Time Complexity', value: 'O(n² × 2ⁿ)' },
        { parameter: 'Space Complexity', value: 'O(n × 2ⁿ)' },
        { parameter: 'Optimization Approach', value: 'Held-Karp DP with Bitmasking' },
        { parameter: 'Class', value: 'NP-Hard (Exact Exponential DP)' },
        { parameter: 'Course Outcomes', value: 'LO2, LO4, LO5 (Apply, Analyze)' }
      ],
      keyPoints: [
        'Produces mathematically optimal route visiting every farm exactly once and returning.',
        'Bitmasking uses binary bits (1 << city) to compactly represent the visited subset.',
        'Memoization table dp[1 << MAX][MAX] prevents redundant tour computations.',
        'Guarantees minimal fuel expenditure and inspection transit times.'
      ],
      realWorldApplications: [
        'Optimizing agricultural extension officer travel itineraries across rural districts.',
        'Soil sample collection logistics from multiple regional farm test plots.',
        'Pest and disease outbreak response routing by state agricultural departments.'
      ]
    },
    algorithm: [
      '1. Start.',
      '2. Read the number of farms, n.',
      '3. Read the distance matrix.',
      '4. Mark the starting farm as visited (mask = 1, current farm = 0).',
      '5. Generate all possible routes using Dynamic Programming with bit masking.',
      '6. Calculate the total distance for each possible route recursively.',
      '7. Store the minimum distance obtained in dp[mask][pos].',
      '8. When mask == (1 << n) - 1, return dist[pos][0] to complete the round trip to the base farm.',
      '9. Display the optimal route and minimum travel distance.',
      '10. Stop.'
    ],
    procedure: [
      '1. Read adjacency matrix dist[n][n] representing pairwise farm travel distances.',
      '2. Initialize memoization table dp[1 << n][n] with -1.',
      '3. Define recursive function tsp(mask, pos): if mask == (1 << n) - 1 return dist[pos][0].',
      '4. Check if dp[mask][pos] != -1. If so, return cached minimum.',
      '5. Iterate over unvisited farms where (mask & (1 << city)) == 0, recursing on tsp(mask | (1 << city), city) + dist[pos][city].',
      '6. Return and print the minimal round-trip travel distance.'
    ],
    code: {
      c: `#include <stdio.h>
#define MAX 10
#define INF 99999

int n;
int dist[MAX][MAX];
int dp[1<<MAX][MAX];

int min(int a,int b)
{
 return (a<b)?a:b;
}

int tsp(int mask,int pos)
{
 if(mask==(1<<n)-1)
   return dist[pos][0];

 if(dp[mask][pos]!=-1)
   return dp[mask][pos];

 int ans=INF;
 for(int city=0;city<n;city++)
 {
   if((mask&(1<<city))==0)
   {
     ans=min(ans, dist[pos][city]+tsp(mask|(1<<city),city));
   }
 }
 return dp[mask][pos]=ans;
}

int main()
{
 int i,j;
 printf("Enter number of farms: ");
 scanf("%d",&n);

 printf("Enter distance matrix:\\n");
 for(i=0;i<n;i++)
 {
   for(j=0;j<n;j++)
   {
     scanf("%d",&dist[i][j]);
   }
 }

 for(i=0;i<(1<<n);i++)
   for(j=0;j<n;j++)
     dp[i][j]=-1;

 printf("\\nMinimum Travel Distance = %d\\n", tsp(1,0));
 return 0;
}`,
      cpp: `#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

const int INF = 1e9;
int n;
vector<vector<int>> dist;
vector<vector<int>> dp;

int tsp(int mask, int pos) {
    if(mask == (1 << n) - 1) return dist[pos][0];
    if(dp[mask][pos] != -1) return dp[mask][pos];

    int ans = INF;
    for(int city = 0; city < n; city++) {
        if(!(mask & (1 << city))) {
            ans = min(ans, dist[pos][city] + tsp(mask | (1 << city), city));
        }
    }
    return dp[mask][pos] = ans;
}

int main() {
    cout << "Enter number of farms: ";
    if (!(cin >> n)) return 0;

    dist.assign(n, vector<int>(n));
    cout << "Enter distance matrix:\\n";
    for(int i = 0; i < n; i++)
        for(int j = 0; j < n; j++)
            cin >> dist[i][j];

    dp.assign(1 << n, vector<int>(n, -1));
    cout << "\\nMinimum Travel Distance = " << tsp(1, 0) << endl;
    return 0;
}`,
      python: `def tsp_held_karp(n, dist):
    memo = {}

    def tsp(mask, pos):
        if mask == (1 << n) - 1:
            return dist[pos][0]
        state = (mask, pos)
        if state in memo:
            return memo[state]

        ans = float('inf')
        for city in range(n):
            if not (mask & (1 << city)):
                cost = dist[pos][city] + tsp(mask | (1 << city), city)
                ans = min(ans, cost)
        memo[state] = ans
        return ans

    return tsp(1, 0)

# Sample 4-farm distance matrix
farms = 4
distances = [
    [0, 10, 15, 20],
    [10, 0, 35, 25],
    [15, 35, 0, 30],
    [20, 25, 30, 0]
]
min_distance = tsp_held_karp(farms, distances)
print(f"Minimum Travel Distance = {min_distance}")`,
      java: `import java.util.Scanner;
import java.util.Arrays;

public class TSPFarmItinerary {
    static final int INF = 99999;
    static int n;
    static int[][] dist;
    static int[][] dp;

    static int tsp(int mask, int pos) {
        if(mask == (1 << n) - 1) return dist[pos][0];
        if(dp[mask][pos] != -1) return dp[mask][pos];

        int ans = INF;
        for(int city = 0; city < n; city++) {
            if((mask & (1 << city)) == 0) {
                ans = Math.min(ans, dist[pos][city] + tsp(mask | (1 << city), city));
            }
        }
        return dp[mask][pos] = ans;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of farms: ");
        n = sc.nextInt();
        dist = new int[n][n];

        System.out.println("Enter distance matrix:");
        for(int i = 0; i < n; i++)
            for(int j = 0; j < n; j++)
                dist[i][j] = sc.nextInt();

        dp = new int[1 << n][n];
        for(int[] row : dp) Arrays.fill(row, -1);

        System.out.println("\\nMinimum Travel Distance = " + tsp(1, 0));
    }
}`
    },
    sampleInput: `4\n0 10 15 20\n10 0 35 25\n15 35 0 30\n20 25 30 0`,
    expectedOutput: `Minimum Travel Distance = 80`,
    references: [
      'KJSIT Lab Manual: Design and Analysis of Algorithms (AIL303), Academic Year 2026-27 (Dr. Vaishali Wadhe, Prof. Prashant Bhandare)',
      'Held, M., & Karp, R. M. (1962). A dynamic programming approach to sequencing problems. J. SIAM',
      'Bellman, R. (1962). Dynamic programming treatment of the travelling salesman problem. JACM'
    ],
    conclusion: 'The shortest route for visiting multiple farms and returning to the starting farm was successfully determined using the Dynamic Programming approach to the Traveling Salesperson Problem. Dynamic Programming provides an optimal solution by eliminating redundant computations through memoization.',
    quiz: [
      {
        id: 1,
        question: 'What is the role of bitmasking in the Held-Karp TSP algorithm?',
        options: [
          'To compress the set of visited farms into an integer where the k-th bit denotes whether farm k was visited',
          'To sort distances into a priority queue',
          'To approximate the solution in polynomial time',
          'To detect cycles in undirected graphs'
        ],
        correctAnswer: 0,
        explanation: 'Bitmasking uses bits 0 to n-1 of an integer to represent subsets of visited vertices, enabling fast array indexing dp[mask][pos] in O(1).'
      }
    ]
  },

  // =========================================================================
  // EXPERIMENT 7: N-Queen Backtracking for Irrigation Controller Placement
  // =========================================================================
  {
    id: 'n-queen',
    num: 7,
    subjectId: 'daa',
    title: 'Determining Optimal Placement of Irrigation Controllers Across Agricultural Fields Using the N-Queen Problem',
    subtitle: 'Backtracking State-Space Search for Non-Interfering Wireless Zones',
    category: 'Backtracking',
    iitReference: 'KJSIT Autonomous Syllabus / AIL303 Lab Manual (Dr. Vaishali Wadhe, Prof. Prashant Bhandare)',
    iitLabUrl: 'https://vlab.amrita.edu/?sub=3&brch=189&sim=543&cnt=1',
    aim: 'To implement the N-Queen Problem using Backtracking in C to determine the optimal placement of irrigation controllers across agricultural fields such that no two controllers interfere with each other.',
    theory: {
      overview: [
        'Modern precision agriculture relies on automated irrigation systems to optimize water usage and improve crop productivity. Large agricultural fields are often divided into multiple irrigation zones, each controlled by an irrigation controller or smart sprinkler. These controllers communicate using wireless technologies such as ZigBee, LoRaWAN, Wi-Fi, or Bluetooth.',
        'If two controllers are placed too close to one another or along the same communication path, signal interference may occur. This interference can result in communication failures, inaccurate sensor readings, delayed irrigation schedules, and inefficient water distribution.',
        'The problem of placing irrigation controllers without interference can be modeled using the N-Queen Problem, a classic problem in Artificial Intelligence and Backtracking.',
        'Originally, the N-Queen Problem requires placing N queens on an N × N chessboard such that: No two queens share the same row, column, or diagonal. In smart agriculture: Each queen represents an irrigation controller; each square represents a possible installation zone; two controllers must not interfere along axial or diagonal radiation vectors.',
        'Backtracking systematically places a controller row by row, checks whether the placement is safe, and backtracks immediately if no valid column exists.'
      ],
      complexityTable: [
        { parameter: 'Time Complexity (Worst)', value: 'O(N!)' },
        { parameter: 'Space Complexity', value: 'O(N) (Recursion call stack)' },
        { parameter: 'Search Method', value: 'Depth-First State-Space Pruning' },
        { parameter: 'Constraint Checks', value: 'Row, Column & Diagonal Conflicts' },
        { parameter: 'Course Outcomes', value: 'LO2, LO4, LO5 (Apply, Analyze)' }
      ],
      keyPoints: [
        'Finds all valid, interference-free placement configurations for field controllers.',
        'Prunes unpromising configurations early without searching entire factorial space.',
        'Diagonal checking utilizes property: |board[i] - column| == |i - row|.',
        'Ensures complete agricultural field irrigation coverage without radio collisions.'
      ],
      realWorldApplications: [
        'Interference-free spatial deployment of smart irrigation controllers and automated valves.',
        'Arranging agricultural drone transceiver antennas across precision farming plots.',
        'Placement of surveillance cameras and micro-weather telemetry towers.'
      ]
    },
    algorithm: [
      '1. Start.',
      '2. Read the number of irrigation controllers (N).',
      '3. Place the first controller in the first row.',
      '4. Check whether the selected position is safe (no column or diagonal conflicts).',
      '5. If safe, place the next controller in the next row.',
      '6. If no safe position exists, backtrack to the previous row.',
      '7. Try another position in the previous row.',
      '8. Continue until all controllers are placed.',
      '9. Display all valid arrangements.',
      '10. Stop.'
    ],
    procedure: [
      '1. Declare global 1-indexed array board[20] where board[row] = column.',
      '2. Implement place(row, column): check for all previous rows i < row that board[i] != column and abs(board[i] - column) != abs(i - row).',
      '3. Implement recursive queen(row, n): try placing controller in column 1 to n. If safe and row == n, call printSolution(n); else recurse on queen(row + 1, n).',
      '4. Print formatted grid showing Q for installed controller and . for open farmland.'
    ],
    code: {
      c: `#include <stdio.h>
#include <stdlib.h>

int board[20];
int count = 0;

int place(int row, int column)
{
 int i;
 for(i = 1; i < row; i++)
 {
   if(board[i] == column)
     return 0;
   if(abs(board[i] - column) == abs(i - row))
     return 0;
 }
 return 1;
}

void printSolution(int n)
{
 int i, j;
 printf("\\nSolution %d\\n\\n", ++count);
 for(i = 1; i <= n; i++)
 {
   for(j = 1; j <= n; j++)
   {
     if(board[i] == j)
       printf(" Q ");
     else
       printf(" . ");
   }
   printf("\\n");
 }
}

void queen(int row, int n)
{
 int column;
 for(column = 1; column <= n; column++)
 {
   if(place(row, column))
   {
     board[row] = column;
     if(row == n)
       printSolution(n);
     else
       queen(row + 1, n);
   }
 }
}

int main()
{
 int n;
 printf("Enter number of irrigation controllers: ");
 scanf("%d", &n);
 queen(1, n);
 if(count == 0)
   printf("\\nNo feasible arrangement exists.\\n");
 return 0;
}`,
      cpp: `#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

int board[20];
int solutionCount = 0;

bool isSafe(int row, int col) {
    for(int i = 1; i < row; i++) {
        if(board[i] == col || abs(board[i] - col) == abs(i - row))
            return false;
    }
    return true;
}

void printSolution(int n) {
    cout << "\\nSolution " << ++solutionCount << "\\n\\n";
    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= n; j++) {
            if(board[i] == j) cout << " Q ";
            else cout << " . ";
        }
        cout << "\\n";
    }
}

void solve(int row, int n) {
    for(int col = 1; col <= n; col++) {
        if(isSafe(row, col)) {
            board[row] = col;
            if(row == n) printSolution(n);
            else solve(row + 1, n);
        }
    }
}

int main() {
    int n;
    cout << "Enter number of irrigation controllers: ";
    if (!(cin >> n)) return 0;
    solve(1, n);
    if(solutionCount == 0) cout << "\\nNo feasible arrangement exists.\\n";
    return 0;
}`,
      python: `def solve_irrigation_controllers(n):
    board = [-1] * n
    solutions = []

    def is_safe(row, col):
        for i in range(row):
            if board[i] == col or abs(board[i] - col) == abs(i - row):
                return False
        return True

    def backtrack(row):
        if row == n:
            solutions.append(list(board))
            return
        for col in range(n):
            if is_safe(row, col):
                board[row] = col
                backtrack(row + 1)
                board[row] = -1

    backtrack(0)
    return solutions

# Example 4-zone field placement
sols = solve_irrigation_controllers(4)
print(f"Found {len(sols)} interference-free placement configurations:")
for idx, sol in enumerate(sols, 1):
    print(f"\\nSolution {idx}:")
    for row in range(4):
        line = [" Q " if sol[row] == col else " . " for col in range(4)]
        print("".join(line))`,
      java: `import java.util.Scanner;

public class IrrigationControllerNQueens {
    static int[] board = new int[25];
    static int count = 0;

    static boolean place(int row, int col) {
        for(int i = 1; i < row; i++) {
            if(board[i] == col || Math.abs(board[i] - col) == Math.abs(i - row))
                return false;
        }
        return true;
    }

    static void printSolution(int n) {
        System.out.println("\\nSolution " + (++count) + "\\n");
        for(int i = 1; i <= n; i++) {
            for(int j = 1; j <= n; j++) {
                if(board[i] == j) System.out.print(" Q ");
                else System.out.print(" . ");
            }
            System.out.println();
        }
    }

    static void queen(int row, int n) {
        for(int col = 1; col <= n; col++) {
            if(place(row, col)) {
                board[row] = col;
                if(row == n) printSolution(n);
                else queen(row + 1, n);
            }
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of irrigation controllers: ");
        int n = sc.nextInt();
        queen(1, n);
        if(count == 0) System.out.println("\\nNo feasible arrangement exists.");
    }
}`
    },
    sampleInput: `4`,
    expectedOutput: `Solution 1\n\n .  Q  .  . \n .  .  .  Q \n Q  .  .  . \n .  .  Q  . \n\nSolution 2\n\n .  .  Q  . \n Q  .  .  . \n .  .  .  Q \n .  Q  .  . `,
    references: [
      'KJSIT Lab Manual: Design and Analysis of Algorithms (AIL303), Academic Year 2026-27 (Dr. Vaishali Wadhe, Prof. Prashant Bhandare)',
      'Russell, S., & Norvig, P. Artificial Intelligence: A Modern Approach, Pearson',
      'Brassard, G., & Bratley, P. Fundamentals of Algorithmics, Prentice Hall'
    ],
    conclusion: 'The irrigation controllers were successfully placed across the agricultural field without communication interference using the Backtracking approach to the N-Queen Problem. Backtracking efficiently identifies all valid arrangements by systematically exploring only feasible placements and abandoning invalid configurations.',
    quiz: [
      {
        id: 1,
        question: 'In the mathematical conflict test abs(board[i] - column) == abs(i - row), what condition is being checked?',
        options: [
          'Whether two controllers share the same column',
          'Whether two controllers lie on the same 45-degree diagonal line of sight',
          'Whether two controllers are in adjacent rows',
          'Whether the total controller count exceeds N'
        ],
        correctAnswer: 1,
        explanation: 'The slope of diagonals on a grid is ±1. When |Δrow| == |Δcol|, the two controllers lie on the same diagonal, leading to signal interference.'
      }
    ]
  },

  // =========================================================================
  // EXPERIMENT 8: Sum of Subsets Backtracking for Weather Station Budgeting
  // =========================================================================
  {
    id: 'sum-of-subsets',
    num: 8,
    subjectId: 'daa',
    title: 'Selecting Weather Stations Satisfying Monitoring Objectives Under Budget Constraints Using the Sum of Subsets Algorithm',
    subtitle: 'Backtracking Pruning for Optimal Climate Equipment Budget Allocation',
    category: 'Backtracking',
    iitReference: 'KJSIT Autonomous Syllabus / AIL303 Lab Manual (Dr. Vaishali Wadhe, Prof. Prashant Bhandare)',
    iitLabUrl: 'https://vlab.amrita.edu/?sub=3&brch=189&sim=543&cnt=1',
    aim: 'To implement the Sum of Subsets algorithm using Backtracking in C to identify combinations of weather stations that satisfy monitoring objectives while remaining within the available budget.',
    theory: {
      overview: [
        'In precision agriculture, weather monitoring stations play a vital role in collecting environmental parameters such as temperature, humidity, rainfall, wind speed, solar radiation, and atmospheric pressure. Due to financial constraints, agricultural organizations often cannot install weather stations at every possible location. Therefore, selecting an optimal combination of weather stations within a fixed budget becomes an important optimization problem.',
        'This problem can be modeled using the Sum of Subsets Problem, a classical Backtracking problem. The Sum of Subsets Problem aims to determine all possible subsets of a given set of positive numbers whose sum is exactly equal to a specified target value.',
        'In this experiment: Each weather station has an installation cost; the target sum represents the available budget; the objective is to identify all possible combinations of weather stations whose total installation cost equals the allocated budget.',
        'Backtracking systematically explores all possible combinations by making decisions one at a time: Include station (x[k] = 1), or Exclude station (x[k] = 0).',
        'Whenever the accumulated cost exceeds the available budget (s > target), that branch is abandoned immediately (pruning). This significantly reduces unnecessary computations compared to brute-force enumeration.'
      ],
      complexityTable: [
        { parameter: 'Time Complexity (Worst)', value: 'O(2ⁿ)' },
        { parameter: 'Space Complexity', value: 'O(n) (Depth of decision tree)' },
        { parameter: 'Pruning Condition', value: 's > target (Abandons unviable paths)' },
        { parameter: 'Binary Tree Branching', value: 'x[k] ∈ {0, 1} (Exclude/Include)' },
        { parameter: 'Course Outcomes', value: 'LO2, LO4, LO5 (Apply, Analyze)' }
      ],
      keyPoints: [
        'Finds all feasible combinations matching the government or farm collective budget.',
        'Eliminates unpromising paths early through systematic bounding tests.',
        'Simple recursive structure easy to implement in embedded controllers.',
        'Practical combinatorial tool for rural infrastructure capital expenditure.'
      ],
      realWorldApplications: [
        'Government agricultural agencies allocating grant funds for rural weather station networks.',
        'Optimizing procurement of IoT sensor equipment under strict cooperative funding ceilings.',
        'Solar irrigation pump and drip line hardware package matching.'
      ]
    },
    algorithm: [
      '1. Start.',
      '2. Read the number of weather stations (n).',
      '3. Read the installation cost of each station.',
      '4. Read the available budget (target sum).',
      '5. Initialize an empty subset.',
      '6. Select a weather station k.',
      '7. Include it in the subset (x[k] = 1) if the accumulated cost does not exceed the target.',
      '8. Recursively continue with the remaining stations.',
      '9. If the accumulated cost equals the target, display the subset.',
      '10. Backtrack (set x[k] = 0) and explore other combinations.',
      '11. Stop after all possible subsets are examined.'
    ],
    procedure: [
      '1. Ingest n station costs into array w[] and budget ceiling into target.',
      '2. In sumOfSubsets(s, k): s is accumulated cost, k is current station index.',
      '3. If s == target: print all stations where x[i] == 1.',
      '4. If k == n or s > target: return immediately (pruning).',
      '5. Branch 1: set x[k] = 1, recurse on sumOfSubsets(s + w[k], k + 1).',
      '6. Branch 2: set x[k] = 0, recurse on sumOfSubsets(s, k + 1).'
    ],
    code: {
      c: `#include <stdio.h>

int w[20], x[20], n, target;

void sumOfSubsets(int s, int k)
{
 int i;
 if(s == target)
 {
   printf("\\nSelected Weather Stations:\\n");
   for(i = 0; i < k; i++)
   {
     if(x[i] == 1)
       printf("Station %d (Cost = %d)\\n", i + 1, w[i]);
   }
   return;
 }

 if(k == n || s > target)
   return;

 x[k] = 1;
 sumOfSubsets(s + w[k], k + 1);

 x[k] = 0;
 sumOfSubsets(s, k + 1);
}

int main()
{
 int i;
 printf("Enter number of weather stations: ");
 scanf("%d", &n);

 printf("Enter installation costs:\\n");
 for(i = 0; i < n; i++)
   scanf("%d", &w[i]);

 printf("Enter available budget: ");
 scanf("%d", &target);

 printf("\\nPossible Weather Station Combinations:\\n");
 sumOfSubsets(0, 0);

 return 0;
}`,
      cpp: `#include <iostream>
#include <vector>
using namespace std;

int n, target;
vector<int> w, x;

void sumOfSubsets(int s, int k) {
    if(s == target) {
        cout << "\\nSelected Weather Stations:\\n";
        for(int i = 0; i < k; i++) {
            if(x[i] == 1) cout << "Station " << (i + 1) << " (Cost = " << w[i] << ")\\n";
        }
        return;
    }
    if(k == n || s > target) return;

    x[k] = 1;
    sumOfSubsets(s + w[k], k + 1);

    x[k] = 0;
    sumOfSubsets(s, k + 1);
}

int main() {
    cout << "Enter number of weather stations: ";
    if (!(cin >> n)) return 0;
    w.resize(n);
    x.assign(n, 0);
    cout << "Enter installation costs:\\n";
    for(int i = 0; i < n; i++) cin >> w[i];
    cout << "Enter available budget: ";
    cin >> target;

    cout << "\\nPossible Weather Station Combinations:\\n";
    sumOfSubsets(0, 0);
    return 0;
}`,
      python: `def weather_stations_budget(costs, budget):
    n = len(costs)
    x = [0] * n
    solutions = []

    def backtrack(s, k):
        if s == budget:
            portfolio = [i + 1 for i in range(k) if x[i] == 1]
            solutions.append(portfolio)
            return
        if k == n or s > budget:
            return

        # Include station k
        x[k] = 1
        backtrack(s + costs[k], k + 1)

        # Exclude station k
        x[k] = 0
        backtrack(s, k + 1)

    backtrack(0, 0)
    return solutions

# 5 Station costs, budget 45
costs = [15, 10, 20, 25, 35]
budget = 45
combinations = weather_stations_budget(costs, budget)
print("Possible Weather Station Combinations:")
for c in combinations:
    print(f"Selected: Stations {c} -> Total Cost = {budget}")`,
      java: `import java.util.Scanner;

public class WeatherStationSubsets {
    static int[] w = new int[25];
    static int[] x = new int[25];
    static int n, target;

    static void sumOfSubsets(int s, int k) {
        if(s == target) {
            System.out.println("\\nSelected Weather Stations:");
            for(int i = 0; i < k; i++) {
                if(x[i] == 1) System.out.println("Station " + (i + 1) + " (Cost = " + w[i] + ")");
            }
            return;
        }
        if(k == n || s > target) return;

        x[k] = 1;
        sumOfSubsets(s + w[k], k + 1);

        x[k] = 0;
        sumOfSubsets(s, k + 1);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of weather stations: ");
        n = sc.nextInt();
        System.out.println("Enter installation costs:");
        for(int i = 0; i < n; i++) w[i] = sc.nextInt();
        System.out.print("Enter available budget: ");
        target = sc.nextInt();

        System.out.println("\\nPossible Weather Station Combinations:");
        sumOfSubsets(0, 0);
    }
}`
    },
    sampleInput: `5\n15 10 20 25 35\n45`,
    expectedOutput: `Possible Weather Station Combinations:\n\nSelected Weather Stations:\nStation 1 (Cost = 15)\nStation 2 (Cost = 10)\nStation 3 (Cost = 20)\n\nSelected Weather Stations:\nStation 2 (Cost = 10)\nStation 5 (Cost = 35)\n\nSelected Weather Stations:\nStation 3 (Cost = 20)\nStation 4 (Cost = 25)`,
    references: [
      'KJSIT Lab Manual: Design and Analysis of Algorithms (AIL303), Academic Year 2026-27 (Dr. Vaishali Wadhe, Prof. Prashant Bhandare)',
      'Horowitz, E., & Sahni, S. Computer Algorithms, Silicon Press',
      'Garey, M. R., & Johnson, D. S. Computers and Intractability: A Guide to the Theory of NP-Completeness'
    ],
    conclusion: 'The combinations of weather stations satisfying the specified budget constraint were successfully identified using the Sum of Subsets algorithm. By systematically exploring feasible combinations and pruning branches that exceed the target budget, it efficiently identifies all valid subsets.',
    quiz: [
      {
        id: 1,
        question: 'In the Sum of Subsets algorithm, what bounding condition triggers immediate pruning of a subtree?',
        options: [
          'When current accumulated cost exceeds the available budget (s > target)',
          'When the number of examined stations is odd',
          'When the average cost of stations is zero',
          'When x[k] == 0'
        ],
        correctAnswer: 0,
        explanation: 'Because all station installation costs are positive, once the accumulated sum exceeds target, adding any further positive cost will never yield target, allowing immediate pruning.'
      }
    ]
  },

  // =========================================================================
  // EXPERIMENT 9: Knuth-Morris-Pratt (KMP) Algorithm for Irrigation Engine
  // =========================================================================
  {
    id: 'kmp',
    num: 9,
    subjectId: 'daa',
    title: 'Developing a Fast Search Engine for Irrigation Recommendations Using the Knuth–Morris–Pratt (KMP) Algorithm',
    subtitle: 'Linear Time Pattern Matching with LPS Array for Agricultural Systems',
    category: 'String Matching',
    iitReference: 'KJSIT Autonomous Syllabus / AIL303 Lab Manual (Dr. Vaishali Wadhe, Prof. Prashant Bhandare)',
    iitLabUrl: 'https://vlab.amrita.edu/?sub=3&brch=189&sim=543&cnt=1',
    aim: 'To implement the Knuth–Morris–Pratt (KMP) String Matching Algorithm in C to efficiently search irrigation recommendations stored in an agricultural information system.',
    theory: {
      overview: [
        'Modern agricultural information systems store a large volume of textual data related to irrigation scheduling, crop management, fertilizer recommendations, weather advisories, pest control measures, and soil health reports. Farmers, agricultural officers, and researchers frequently search these databases to retrieve specific recommendations quickly.',
        'A simple string matching technique compares the pattern with the text character by character. Whenever a mismatch occurs, the search restarts from the next character in the text. This leads to repeated comparisons and poor performance, especially for large agricultural databases.',
        'The Knuth–Morris–Pratt (KMP) Algorithm is an efficient pattern matching algorithm that avoids unnecessary comparisons by using information obtained from previous matches.',
        'KMP preprocesses the search pattern and constructs a special array known as the Longest Proper Prefix which is also a Suffix (LPS) Array. The LPS array indicates how much the pattern can be shifted without rechecking characters that have already been matched.',
        'The algorithm consists of two major phases: Phase 1 – LPS Construction (O(m)), and Phase 2 – Pattern Searching (O(n)). Overall time complexity is strictly linear O(n + m), with zero backtracking on the agricultural text.'
      ],
      complexityTable: [
        { parameter: 'LPS Construction', value: 'O(m) (Pattern preprocessing)' },
        { parameter: 'Pattern Searching', value: 'O(n) (Linear text scanning)' },
        { parameter: 'Overall Time Complexity', value: 'O(n + m)' },
        { parameter: 'Space Complexity', value: 'O(m) (LPS array)' },
        { parameter: 'Text Backtracking', value: 'Zero (Text pointer i never moves backwards)' },
        { parameter: 'Course Outcomes', value: 'LO2, LO4, LO5 (Apply, Analyze)' }
      ],
      keyPoints: [
        'Linear time string matching avoids repeated comparisons upon mismatch.',
        'LPS array computes longest proper prefix that is also a valid suffix.',
        'Text pointer i only moves forward; pattern pointer j shifts using LPS[j - 1].',
        'Crucial for large corpus search engines indexing thousands of farm manuals.'
      ],
      realWorldApplications: [
        'Search engine indexing for irrigation recommendations: Drip Irrigation, Sprinkler Irrigation, Alternate Furrow Irrigation, Rainwater Harvesting.',
        'Smart farming decision support systems parsing pest advisories and soil health reports.',
        'Genomic pattern matching across crop disease DNA/RNA pathogen sequences.'
      ]
    },
    algorithm: [
      '1. Start.',
      '2. Read the agricultural text.',
      '3. Read the irrigation recommendation (pattern).',
      '4. Construct the LPS (Longest Proper Prefix Suffix) array.',
      '5. Compare characters of the text and pattern.',
      '6. If characters match, move to the next characters.',
      '7. If the complete pattern is matched, display its starting position.',
      '8. If a mismatch occurs: Use the LPS array to determine the next comparison; Avoid comparing previously matched characters again.',
      '9. Continue until the entire text has been searched.',
      '10. Stop.'
    ],
    procedure: [
      '1. In computeLPS(pattern, M, lps): compute lengths of longest proper prefix matching suffix for all prefixes 0 to M-1.',
      '2. In KMPSearch(pattern, text): maintain text index i and pattern index j.',
      '3. If pattern[j] == text[i], increment both i and j.',
      '4. If j == M, report match at index i - j and update j = lps[j - 1].',
      '5. On mismatch (pattern[j] != text[i]), if j != 0 update j = lps[j - 1]; else increment i.',
      '6. Read inputs with fgets() and strip trailing newlines.'
    ],
    code: {
      c: `#include <stdio.h>
#include <string.h>

void computeLPS(char pattern[], int M, int lps[])
{
 int len = 0;
 lps[0] = 0;
 int i = 1;
 while(i < M)
 {
   if(pattern[i] == pattern[len])
   {
     len++;
     lps[i] = len;
     i++;
   }
   else
   {
     if(len != 0)
     {
       len = lps[len - 1];
     }
     else
     {
       lps[i] = 0;
       i++;
     }
   }
 }
}

void KMPSearch(char pattern[], char text[])
{
 int M = strlen(pattern);
 int N = strlen(text);
 int lps[M];

 computeLPS(pattern, M, lps);

 int i = 0, j = 0;
 while(i < N)
 {
   if(pattern[j] == text[i])
   {
     i++;
     j++;
   }
   if(j == M)
   {
     printf("Pattern found at position %d\\n", i - j);
     j = lps[j - 1];
   }
   else if(i < N && pattern[j] != text[i])
   {
     if(j != 0)
       j = lps[j - 1];
     else
       i++;
   }
 }
}

int main()
{
 char text[500], pattern[100];
 printf("Enter Agricultural Information:\\n");
 fgets(text, sizeof(text), stdin);

 printf("Enter Irrigation Recommendation to Search:\\n");
 fgets(pattern, sizeof(pattern), stdin);

 pattern[strcspn(pattern, "\\n")] = '\\0';
 text[strcspn(text, "\\n")] = '\\0';

 KMPSearch(pattern, text);
 return 0;
}`,
      cpp: `#include <iostream>
#include <vector>
#include <string>
using namespace std;

vector<int> computeLPS(const string& pat) {
    int m = pat.length();
    vector<int> lps(m, 0);
    int len = 0, i = 1;
    while(i < m) {
        if(pat[i] == pat[len]) {
            len++;
            lps[i] = len;
            i++;
        } else {
            if(len != 0) len = lps[len - 1];
            else { lps[i] = 0; i++; }
        }
    }
    return lps;
}

void KMPSearch(const string& pat, const string& txt) {
    int m = pat.length(), n = txt.length();
    vector<int> lps = computeLPS(pat);
    int i = 0, j = 0;
    while(i < n) {
        if(pat[j] == txt[i]) { i++; j++; }
        if(j == m) {
            cout << "Pattern found at position " << (i - j) << "\\n";
            j = lps[j - 1];
        } else if(i < n && pat[j] != txt[i]) {
            if(j != 0) j = lps[j - 1];
            else i++;
        }
    }
}

int main() {
    string text, pattern;
    cout << "Enter Agricultural Information:\\n";
    getline(cin, text);
    cout << "Enter Irrigation Recommendation to Search:\\n";
    getline(cin, pattern);

    KMPSearch(pattern, text);
    return 0;
}`,
      python: `def compute_lps(pattern):
    m = len(pattern)
    lps = [0] * m
    length = 0
    i = 1
    while i < m:
        if pattern[i] == pattern[length]:
            length += 1
            lps[i] = length
            i += 1
        else:
            if length != 0:
                length = lps[length - 1]
            else:
                lps[i] = 0
                i += 1
    return lps

def kmp_search(pattern, text):
    m = len(pattern)
    n = len(text)
    lps = compute_lps(pattern)
    matches = []
    i = j = 0
    while i < n:
        if pattern[j] == text[i]:
            i += 1
            j += 1
        if j == m:
            matches.append(i - j)
            j = lps[j - 1]
        elif i < n and pattern[j] != text[i]:
            if j != 0:
                j = lps[j - 1]
            else:
                i += 1
    return matches

# Agricultural knowledge base query
corpus = "Drip Irrigation maximizes water efficiency in cotton fields. Precision Drip Irrigation reduces evaporation."
term = "Drip Irrigation"
found_positions = kmp_search(term, corpus)
for pos in found_positions:
    print(f"Pattern found at position {pos}")`,
      java: `import java.util.Scanner;

public class KMPIrrigationSearch {
    static int[] computeLPS(String pat) {
        int m = pat.length();
        int[] lps = new int[m];
        int len = 0, i = 1;
        while(i < m) {
            if(pat.charAt(i) == pat.charAt(len)) {
                len++;
                lps[i] = len;
                i++;
            } else {
                if(len != 0) len = lps[len - 1];
                else { lps[i] = 0; i++; }
            }
        }
        return lps;
    }

    static void KMPSearch(String pat, String txt) {
        int m = pat.length();
        int n = txt.length();
        int[] lps = computeLPS(pat);
        int i = 0, j = 0;
        while(i < n) {
            if(pat.charAt(j) == txt.charAt(i)) { i++; j++; }
            if(j == m) {
                System.out.println("Pattern found at position " + (i - j));
                j = lps[j - 1];
            } else if(i < n && pat.charAt(j) != txt.charAt(i)) {
                if(j != 0) j = lps[j - 1];
                else i++;
            }
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Agricultural Information:");
        String text = sc.nextLine();
        System.out.println("Enter Irrigation Recommendation to Search:");
        String pattern = sc.nextLine();

        KMPSearch(pattern, text);
    }
}`
    },
    sampleInput: `Drip Irrigation maximizes water efficiency in cotton fields. Precision Drip Irrigation reduces evaporation.\nDrip Irrigation`,
    expectedOutput: `Pattern found at position 0\nPattern found at position 65`,
    references: [
      'KJSIT Lab Manual: Design and Analysis of Algorithms (AIL303), Academic Year 2026-27 (Dr. Vaishali Wadhe, Prof. Prashant Bhandare)',
      'Knuth, D. E., Morris, J. H., & Pratt, V. R. (1977). Fast pattern matching in strings. SIAM J. Comput.',
      'Gusfield, D. Algorithms on Strings, Trees, and Sequences, Cambridge University Press'
    ],
    conclusion: 'The Knuth–Morris–Pratt (KMP) algorithm is an efficient string matching technique that performs pattern searching in linear time by eliminating redundant comparisons using the LPS array. It is highly suitable for searching large agricultural databases containing irrigation recommendations, weather advisories, crop management practices, and soil health reports.',
    quiz: [
      {
        id: 1,
        question: 'What information does the Longest Proper Prefix which is also a Suffix (LPS) array capture?',
        options: [
          'The length of the longest matching prefix and suffix, allowing the pattern to be shifted without re-evaluating previously matched characters',
          'The ASCII sum of the characters',
          'The number of vowels in the text',
          'The frequency of word occurrences'
        ],
        correctAnswer: 0,
        explanation: 'LPS[i] stores the length of the longest proper prefix of pattern[0...i] that is also a suffix of pattern[0...i]. Upon mismatch, the pattern shifts to index LPS[j-1] without ever moving the text pointer i backwards.'
      }
    ]
  }
];

// Attach CodinGame Puzzles to all DAA experiments
DAA_EXPERIMENTS.forEach((exp) => {
  exp.codingamePuzzles = DAA_CODINGAME_PUZZLES[exp.id] || [];
});
