import { LabExperiment } from '../types';

export const NLP_EXPERIMENTS: LabExperiment[] = [
  // =========================================================================
  // Practical 1 (Pages 14-17)
  // =========================================================================
  {
    id: 'nlp-exp1',
    num: 1,
    subjectId: 'nlp',
    title: 'Text Preprocessing: Tokenization, Stopwords, Stemming & Lemmatization',
    subtitle: 'Sentence/Word Tokenization, Stopword Removal, Porter Stemmer & WordNet Lemmatizer (English & Regional Languages)',
    category: 'Text Preprocessing',
    iitReference: 'Autonomous Curriculum Standards / Natural Language Processing Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/nlp-lab/',
    aim: 'To perform text preprocessing using Python by implementing tokenization, stopword removal, stemming, and lemmatization techniques for English and any regional language (Marathi, Gujarati, Oriya, Arabic etc).',
    objective: 'To understand the importance of preprocessing in Natural Language Processing and implement text preprocessing techniques using the NLTK library.',
    labObjectives: [
      'To understand the importance of preprocessing in Natural Language Processing.',
      'To implement various text preprocessing techniques using the NLTK library.'
    ],
    software: 'Python 3.x, Jupyter Notebook / Google Colab, NLTK Library, spaCy (optional)',
    theory: {
      overview: [
        'Text preprocessing is the first and one of the most important steps in the Natural Language Processing (NLP) pipeline.',
        'Real-world textual data obtained from sources such as social media, news articles, emails, and websites often contains inconsistencies, punctuation, special characters, numbers, and common words that do not contribute significantly to the meaning of the text. These irregularities can negatively impact the performance of NLP models.',
        'Tokenization: Divides a document into smaller units called tokens, which may be words, sentences, or subwords.',
        'Stopword Removal: Eliminates frequently occurring words such as "is", "the", "and", which generally carry little semantic information.',
        'Stemming: Reduces words to their root form by removing prefixes or suffixes using heuristic rules (e.g., "studying", "studies", and "studied" become "studi" using Porter Stemmer).',
        'Lemmatization: Converts words to their dictionary or base form (lemma) by considering their grammatical context and Part-of-Speech (e.g., "better" becomes "good", "running" (verb) becomes "run"). Compared to stemming, lemmatization produces linguistically meaningful words.',
        'Regional Language Processing: Regional Indian languages (such as Marathi, Hindi, Gujarati) require Unicode normalization, devanagari tokenization, and customized stopword lexicons to retain syntactic roots.'
      ],
      complexityTable: [
        { parameter: 'Word Tokenization (Regex)', value: 'O(N) linear in character length' },
        { parameter: 'Stopword Filtering', value: 'O(T) hash set lookup per token' },
        { parameter: 'Porter Stemming Heuristic', value: 'O(T * L) suffix strip rules' },
        { parameter: 'WordNet Lemmatization', value: 'O(T log V) lexical dictionary lookup' }
      ],
      keyPoints: [
        'Tokenization transforms continuous text strings into discrete lexical items.',
        'Stemming is faster but prone to over-stemming and under-stemming, producing non-words.',
        'Lemmatization uses morphological vocabularies and POS tags to produce grammatically valid base forms.',
        'Preprocessing significantly reduces vocabulary dimensionality and prevents sparse representations in downstream classifiers.'
      ],
      realWorldApplications: [
        'Search engine query normalization (Apache Lucene, Elasticsearch).',
        'Multilingual document indexing and regional language text mining.',
        'Pre-tokenization stage for sentiment analysis, spam filters, and conversational agents.'
      ]
    },
    algorithm: [
      '1. Ingest raw text document (English or regional language such as Marathi/Hindi).',
      '2. Perform sentence tokenization using Punkt sentence tokenizer.',
      '3. Perform word tokenization using NLTK word_tokenize or regex word boundary matching.',
      '4. Normalize text: convert to lowercase and strip punctuation and special characters.',
      '5. Eliminate high-frequency stopwords from predefined language lexicon (NLTK stopwords).',
      '6. Apply Porter Stemmer heuristic suffix-stripping rules to extract word stems.',
      '7. Apply WordNet Lemmatizer with mapped POS tags (Noun, Verb, Adjective) to obtain true lemmas.',
      '8. Generate comparative token frequency tables, reduction statistics, and side-by-side stemming vs lemmatization logs.'
    ],
    procedure: [
      '1. Install the required Python libraries (nltk, spacy).',
      '2. Import the NLTK package and download necessary corpora (punkt, stopwords, wordnet, omw-1.4).',
      '3. Input a sample paragraph in English or a regional language (Marathi, Gujarati, etc.).',
      '4. Perform word and sentence tokenization.',
      '5. Remove punctuation and stopwords.',
      '6. Apply stemming using Porter Stemmer.',
      '7. Apply lemmatization using WordNet Lemmatizer.',
      '8. Compare the outputs of stemming and lemmatization and observe the effect of preprocessing on the text.'
    ],
    code: {
      python: `import re
import nltk
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer, WordNetLemmatizer

# Download NLTK data dependencies
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')
nltk.download('omw-1.4')

def preprocess_pipeline(raw_text: str, language: str = 'english'):
    print("--- 1. Original Text ---")
    print(raw_text)
    
    # Sentence Tokenization
    sentences = sent_tokenize(raw_text)
    print(f"\\nSentences ({len(sentences)}):", sentences)
    
    # Word Tokenization
    tokens = word_tokenize(raw_text)
    print(f"\\nOriginal Tokens ({len(tokens)}):", tokens)
    
    # Lowercase & Punctuation Removal
    cleaned_tokens = [re.sub(r'[^\\w\\s]', '', t.lower()) for t in tokens if re.sub(r'[^\\w\\s]', '', t)]
    
    # Stopword Removal
    stop_words = set(stopwords.words('english'))
    filtered_tokens = [t for t in cleaned_tokens if t not in stop_words]
    print(f"\\nTokens After Stopword Removal ({len(filtered_tokens)}):", filtered_tokens)
    
    # Stemming & Lemmatization
    stemmer = PorterStemmer()
    lemmatizer = WordNetLemmatizer()
    
    stemmed_words = [stemmer.stem(w) for w in filtered_tokens]
    lemmatized_words = [lemmatizer.lemmatize(w, pos='v') for w in filtered_tokens]
    
    print("\\n--- Comparison: Stemmed vs Lemmatized ---")
    for orig, stem, lemma in zip(filtered_tokens, stemmed_words, lemmatized_words):
        print(f"{orig:<15} -> Stem: {stem:<12} | Lemma: {lemma}")
        
    return {
        "original_tokens": len(tokens),
        "cleaned_tokens": len(filtered_tokens),
        "reduction_pct": round((1 - len(filtered_tokens)/len(tokens)) * 100, 2)
    }`
    },
    sampleInput: 'The computational algorithms were continually analyzing dynamic biological structures. Studies have shown that better solutions are easily produced when students study regularly.',
    expectedOutput: 'Original Tokens: 25 | Stopwords Filtered: 16 | Stemmed: [comput, algorithm, continu, analyz, dynam, biolog, structur, studi, shown, better, solut, easili, produc, student, studi, regularli] | Lemmatized: [computational, algorithms, continually, analyze, dynamic, biological, structures, study, show, better, solutions, easily, produce, students, study, regularly] | Vocabulary Reduction: 36.0%',
    references: [
      'Daniel Jurafsky and James H. Martin, Speech and Language Processing (3rd Edition Draft), Prentice Hall.',
      'Steven Bird, Ewan Klein, and Edward Loper, Natural Language Processing with Python, O’Reilly Media.'
    ],
    conclusion: 'Text preprocessing successfully transformed unstructured textual input into clean, standardized tokens. Lemmatization proved superior to heuristic stemming by preserving lexical dictionary integrity while stopwords removal significantly reduced feature space.',
    postLabQuestions: [
      {
        question: 'Why is text preprocessing necessary before training an NLP model?',
        answer: 'Raw textual data contains noisy punctuation, casing variations, special characters, and uninformative stopwords. Preprocessing standardizes the input, eliminates noise, and drastically reduces feature vocabulary size so machine learning models can focus on semantic patterns.'
      },
      {
        question: 'Differentiate between stemming and lemmatization with suitable examples.',
        answer: 'Stemming uses heuristic suffix chopping rules without vocabulary awareness, often yielding non-dictionary stems (e.g., "caring" -> "car", "studies" -> "studi"). Lemmatization uses morphological dictionaries and Part-of-Speech context to return linguistically valid base forms (e.g., "better" (adj) -> "good", "studies" -> "study").'
      },
      {
        question: 'What are stopwords? Can removing stopwords ever negatively affect an NLP application?',
        answer: 'Stopwords are high-frequency words carrying minimal domain semantics (e.g., "is", "the", "at"). Yes, removing stopwords can degrade tasks that depend on syntax, phrase structure, or sentiment inversion—for example, removing "not" in "not happy" flips the sentiment polarity.'
      },
      {
        question: 'Compare word tokenization and sentence tokenization.',
        answer: 'Sentence tokenization segments a paragraph into individual grammatical sentences using punctuation and sentence boundary models. Word tokenization decomposes a sentence into individual word or subword tokens.'
      },
      {
        question: 'Which preprocessing technique preserves the semantic meaning of words better? Justify your answer.',
        answer: 'Lemmatization preserves semantic meaning better because it references lexical dictionaries (like WordNet) and considers Part-of-Speech context, ensuring the output word is a genuine semantic root rather than an arbitrarily chopped substring.'
      }
    ],
    quiz: [
      {
        id: 1,
        question: 'What is the primary objective of Lemmatization over Stemming?',
        options: [
          'To return valid dictionary lemmas using morphological and POS context rather than crude heuristic suffix truncation',
          'To make all words uppercase',
          'To remove all verbs from sentences',
          'To calculate cosine distance between tokens'
        ],
        correctAnswer: 0,
        explanation: 'Lemmatization references morphological vocabularies to produce valid base words (e.g. "better" -> "good"), whereas stemmers only strip suffixes heuristically (e.g. "caring" -> "car").'
      }
    ]
  },

  // =========================================================================
  // Practical 2 (Pages 12-14)
  // =========================================================================
  {
    id: 'nlp-exp2',
    num: 2,
    subjectId: 'nlp',
    title: 'Implementation of N-Gram Language Model using Python',
    subtitle: 'Unigram, Bigram & Trigram Probabilistic Language Modeling, Markov Assumption & Next-Word Prediction',
    category: 'Language Modeling',
    iitReference: 'Autonomous Curriculum Standards / Natural Language Processing Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/nlp-lab/',
    aim: 'To implement unigram, bigram, and trigram language models using Python and analyze their effectiveness in predicting the next word in a sequence.',
    objective: 'To understand the concept of N-gram language models and their role in Natural Language Processing, and to implement unigram, bigram, and trigram models to compare their performance for next-word prediction.',
    labObjectives: [
      'To understand the concept of N-gram language models and their role in Natural Language Processing.',
      'To implement unigram, bigram, and trigram models and compare their performance for next-word prediction.'
    ],
    software: 'Python 3.x, Jupyter Notebook / Google Colab, NLTK Library, NumPy, Collections module',
    theory: {
      overview: [
        'A Language Model (LM) is a probabilistic model that estimates the likelihood of a sequence of words occurring in a natural language.',
        'It plays a fundamental role in numerous NLP applications such as speech recognition, machine translation, text generation, spelling correction, predictive typing, and chatbots.',
        'The objective of a language model is to assign probabilities to word sequences and predict the most likely next word given the previous context: P(w1, w2, ..., wn) = Π P(wi | w1, ..., wi-1).',
        'An N-gram is a contiguous sequence of N words extracted from a text corpus:',
        '  • Unigram (N = 1): Considers each word independently: P(wi) = Count(wi) / TotalWords.',
        '  • Bigram (N = 2): Predicts a word based on the immediately preceding word: P(wi | wi-1) = Count(wi-1, wi) / Count(wi-1).',
        '  • Trigram (N = 3): Predicts a word using the previous two words: P(wi | wi-2, wi-1) = Count(wi-2, wi-1, wi) / Count(wi-2, wi-1).',
        'Markov Assumption: Assumes that the probability of a word depends only on the previous (N-1) words rather than the complete sentence history, significantly reducing computational complexity.',
        'Data Sparsity Problem: As N increases, unseen word combinations receive zero probability (zero frequency problem). Laplace (Add-1) smoothing redistributes probability mass: P_Laplace = (Count + 1) / (Count(context) + V).'
      ],
      complexityTable: [
        { parameter: 'Unigram Space', value: 'O(V) unique words table' },
        { parameter: 'Bigram Space', value: 'O(V^2) maximum possible pairs' },
        { parameter: 'Trigram Space', value: 'O(V^3) combinatorial word tuples' },
        { parameter: 'Inference Lookup', value: 'O(1) hash map key retrieval' }
      ],
      keyPoints: [
        'Higher N captures richer local context but sharply increases parameter space and data sparsity.',
        'The Markov assumption makes language modeling computationally tractable.',
        'Smoothing methods (Laplace, Good-Turing, Kneser-Ney) resolve zero-probability penalties for unseen sequences.'
      ],
      realWorldApplications: [
        'Autocomplete predictive text in mobile keyboards (Gboard, Apple iOS).',
        'Acoustic sentence scoring in automatic speech recognition (ASR).',
        'Contextual candidate re-ranking in spell checkers and OCR engines.'
      ]
    },
    algorithm: [
      '1. Ingest training text corpus and apply lowercasing and tokenization.',
      '2. Add sentence boundary tokens <s> and </s> to model sentence starts and endings.',
      '3. Generate Unigram (N=1), Bigram (N=2), and Trigram (N=3) word tuples.',
      '4. Compute frequency distributions for unigrams, bigrams, and trigrams using collections.Counter.',
      '5. For Bigram model: calculate conditional probability P(w_i | w_{i-1}) = C(w_{i-1}, w_i) / C(w_{i-1}).',
      '6. For Trigram model: calculate conditional probability P(w_i | w_{i-2}, w_{i-1}) = C(w_{i-2}, w_{i-1}, w_i) / C(w_{i-2}, w_{i-1}).',
      '7. Implement Laplace add-1 smoothing to prevent zero probability on unseen n-grams.',
      '8. Given context prompt, sort candidate words by conditional probability and predict top next words.'
    ],
    procedure: [
      '1. Install the required Python libraries (nltk, numpy).',
      '2. Input a sample text corpus.',
      '3. Perform text preprocessing and tokenization.',
      '4. Generate unigram, bigram, and trigram sequences.',
      '5. Calculate frequency distributions.',
      '6. Compute conditional probabilities for bigrams and trigrams.',
      '7. Predict the next word based on a given context.',
      '8. Compare the outputs of unigram, bigram, and trigram models and analyze limitations of N-gram models.'
    ],
    code: {
      python: `from collections import Counter, defaultdict
import nltk
from nltk.tokenize import word_tokenize

def build_ngram_models(corpus: str):
    tokens = ['<s>'] + word_tokenize(corpus.lower()) + ['</s>']
    vocab = set(tokens)
    V = len(vocab)
    
    # Generate N-grams
    unigrams = tokens
    bigrams = list(zip(tokens[:-1], tokens[1:]))
    trigrams = list(zip(tokens[:-2], tokens[1:-1], tokens[2:]))
    
    u_counts = Counter(unigrams)
    b_counts = Counter(bigrams)
    t_counts = Counter(trigrams)
    
    def predict_next_bigram(prev_word: str, top_k: int = 3):
        candidates = {}
        for (w1, w2), count in b_counts.items():
            if w1 == prev_word.lower():
                # Laplace smoothed probability
                prob = (count + 1) / (u_counts[w1] + V)
                candidates[w2] = prob
        return sorted(candidates.items(), key=lambda x: x[1], reverse=True)[:top_k]

    def predict_next_trigram(w1: str, w2: str, top_k: int = 3):
        candidates = {}
        context = (w1.lower(), w2.lower())
        for (cw1, cw2, cw3), count in t_counts.items():
            if (cw1, cw2) == context:
                prob = (count + 1) / (b_counts[context] + V)
                candidates[cw3] = prob
        return sorted(candidates.items(), key=lambda x: x[1], reverse=True)[:top_k]

    return predict_next_bigram, predict_next_trigram`
    },
    sampleInput: 'Corpus: "natural language processing creates intelligent systems. natural language understanding helps artificial intelligence systems. natural language modeling is powerful." | Query Context: "natural language"',
    expectedOutput: 'Bigram Predictions for "language": [("processing", 0.42), ("understanding", 0.28), ("modeling", 0.28)] | Trigram Predictions for ("natural", "language"): [("processing", 0.50), ("understanding", 0.25), ("modeling", 0.25)]',
    references: [
      'Daniel Jurafsky and James H. Martin, Speech and Language Processing (3rd Edition Draft), Prentice Hall.',
      'Christopher D. Manning and Hinrich Schütze, Foundations of Statistical Natural Language Processing, MIT Press.'
    ],
    conclusion: 'N-gram language models provide a statistical foundation for predicting word sequences. While bigram and trigram models capture local syntactic patterns, they suffer from exponential parameter explosion and data sparsity on larger vocabulary sizes.',
    postLabQuestions: [
      {
        question: 'What is an N-gram language model?',
        answer: 'An N-gram language model is a statistical model that predicts the probability distribution of a word sequence by assuming the probability of each word depends only on the preceding N-1 words.'
      },
      {
        question: 'Explain with suitable examples. Differentiate between unigram, bigram, and trigram models.',
        answer: 'In the sentence "I love machine learning": a Unigram (N=1) considers words independently (P("learning")); a Bigram (N=2) conditions on 1 previous word (P("learning" | "machine")); a Trigram (N=3) conditions on 2 previous words (P("learning" | "love", "machine")).'
      },
      {
        question: 'What is the Markov assumption in language modeling?',
        answer: 'The Markov assumption approximates the probability of a word given its entire infinite past history by conditioning only on a finite sliding window of the previous N-1 words: P(w_i | w_1...w_{i-1}) ≈ P(w_i | w_{i-N+1}...w_{i-1}).'
      },
      {
        question: 'Why do N-gram language models suffer from the data sparsity problem?',
        answer: 'Because natural language vocabularies are vast and word combinations grow exponentially (V^N). Even massive corpora never contain all legitimate n-gram sequences, resulting in zero counts and zero probability assignments for valid test sentences.'
      },
      {
        question: 'Compare statistical language models with neural language models.',
        answer: 'Statistical N-gram models store discrete frequency tables, suffer from data sparsity, cannot generalize across synonyms, and have short context windows. Neural language models (RNNs, Transformers) represent words as dense continuous embeddings, handle long-range dependencies, and generalize seamlessly across semantic similarities.'
      }
    ],
    quiz: [
      {
        id: 1,
        question: 'What does the Markov Assumption state in an N-Gram model?',
        options: [
          'The probability of a word depends only on the preceding N-1 words rather than the entire sentence history',
          'Words must always occur in alphabetical order',
          'Every word has an equal unigram probability',
          'Punctuation should never be tokenized'
        ],
        correctAnswer: 0,
        explanation: 'The Markov assumption simplifies joint probability by limiting history dependence to a fixed window of N-1 preceding words.'
      }
    ]
  },

  // =========================================================================
  // Practical 3 (Pages 11-12)
  // =========================================================================
  {
    id: 'nlp-exp3',
    num: 3,
    subjectId: 'nlp',
    title: 'Part-of-Speech (POS) Tagging and Named Entity Recognition (NER) using spaCy',
    subtitle: 'Linguistic Analysis, Universal POS Grammatical Tags & spaCy Pre-trained Entity Extraction',
    category: 'Linguistic Analysis & NER',
    iitReference: 'Autonomous Curriculum Standards / Natural Language Processing Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/nlp-lab/',
    aim: 'To implement Part-of-Speech (POS) Tagging and Named Entity Recognition (NER) using the spaCy library for linguistic analysis and information extraction.',
    objective: 'To identify grammatical categories of words using Part-of-Speech (POS) tagging and extract named entities such as persons, organizations, locations, dates, and numerical values from unstructured text using Named Entity Recognition (NER).',
    labObjectives: [
      'To identify grammatical categories of words using Part-of-Speech (POS) tagging.',
      'To extract named entities such as persons, organizations, locations, dates, and numerical values from unstructured text using Named Entity Recognition (NER).'
    ],
    software: 'Python 3.x, Jupyter Notebook / Google Colab, spaCy Library, English Language Model (en_core_web_sm)',
    theory: {
      overview: [
        'Part-of-Speech (POS) Tagging: One of the fundamental tasks in NLP that assigns a grammatical category to each word in a sentence based on its syntactic context.',
        'Common POS tags include nouns (NOUN/PROPN), verbs (VERB/AUX), adjectives (ADJ), adverbs (ADV), pronouns (PRON), conjunctions (CCONJ), determiners (DET), and prepositions (ADP).',
        'Because many words can function as multiple parts of speech depending on sentence syntax (e.g., "book a flight" [verb] vs "read a book" [noun]), modern POS taggers employ statistical transition models and deep neural networks to resolve ambiguity.',
        'Named Entity Recognition (NER): An Information Extraction task that automatically identifies and classifies named entities present in text into predefined semantic categories.',
        'Common NER categories: Person (PERSON), Organization (ORG), Geopolitical Entity / Location (GPE/LOC), Date (DATE), Time (TIME), Money (MONEY), Quantity (QUANTITY), and Event (EVENT).',
        'Distinction: Unlike POS tagging which focuses on grammatical syntax, NER focuses on extracting real-world entities for knowledge graphs, question answering, and business intelligence.'
      ],
      complexityTable: [
        { parameter: 'spaCy Pipeline Inference', value: 'O(N) linear in token count with transition-based neural parser' },
        { parameter: 'Memory Footprint (en_core_web_sm)', value: '~12 MB compressed pre-trained model' },
        { parameter: 'NER Entity Span Extraction', value: 'BIO/BILOU tagging sequence labeling' }
      ],
      keyPoints: [
        'spaCy provides highly optimized Cython-based pipelines for tokenization, tagger, parser, and NER.',
        'BILOU tagging scheme denotes Beginning, Inside, Last, Unit, and Outside token boundaries for multi-word entities.',
        'displaCy visualizer renders dependency trees and entity highlight boundaries directly in browsers.'
      ],
      realWorldApplications: [
        'Automated resume parsing and candidate skill extraction in HR systems.',
        'Financial intelligence: extracting corporate transactions, stock symbols, and acquisition dates from earnings reports.',
        'Legal discovery: identifying cited parties, courts, and case dates in jurisprudence files.'
      ]
    },
    algorithm: [
      '1. Load pre-trained English language model spacy.load("en_core_web_sm").',
      '2. Ingest input raw text paragraph containing multi-word entities.',
      '3. Process text through spaCy NLP pipeline to produce a Doc container.',
      '4. Iterate through tokens in Doc and extract: token.text, token.pos_ (Coarse POS), token.tag_ (Fine-grained Penn Treebank POS), and token.dep_ (Syntactic Dependency).',
      '5. Iterate through doc.ents and extract: ent.text, ent.label_ (Entity Category), ent.start_char, ent.end_char.',
      '6. Render visual entity annotation using spacy.displacy.render(doc, style="ent").',
      '7. Compare and tabulate the grammatical roles against semantic entity categories.'
    ],
    procedure: [
      '1. Install the spaCy library (pip install spacy) and download the English language model (python -m spacy download en_core_web_sm).',
      '2. Import the required libraries in Python.',
      '3. Load the pre-trained English language model.',
      '4. Input a sample paragraph.',
      '5. Perform Part-of-Speech (POS) tagging and display each token along with its POS tag.',
      '6. Perform Named Entity Recognition (NER) and display extracted entities with corresponding labels.',
      '7. Visualize identified named entities using spaCy’s visualization tool.',
      '8. Analyze output and compare POS tagging with NER.'
    ],
    code: {
      python: `import spacy
from spacy import displacy

# Load spaCy small English pipeline
nlp = spacy.load("en_core_web_sm")

text = """Apple Inc. was founded by Steve Jobs and Steve Wozniak in Los Altos, California. 
On September 12, 2026, Tim Cook announced a $50 billion investment in quantum AI research."""

doc = nlp(text)

# 1. Part-of-Speech (POS) Tagging
print("--- POS TAGGING ---")
print(f"{'Token':<15} {'Coarse POS':<12} {'Fine Tag':<10} {'Dependency':<12}")
print("-" * 52)
for token in doc[:10]:
    print(f"{token.text:<15} {token.pos_:<12} {token.tag_:<10} {token.dep_:<12}")

# 2. Named Entity Recognition (NER)
print("\\n--- NAMED ENTITY RECOGNITION (NER) ---")
print(f"{'Entity':<25} {'Label':<15} {'Explanation'}")
print("-" * 65)
for ent in doc.ents:
    print(f"{ent.text:<25} {ent.label_:<15} {spacy.explain(ent.label_)}")

# Generate visualization HTML string
html = displacy.render(doc, style="ent", jupyter=False)`
    },
    sampleInput: '"Sundar Pichai, CEO of Google LLC, visited Mumbai on October 15, 2025 to inaugurate a 200 million dollar data center."',
    expectedOutput: 'Entities: [("Sundar Pichai", PERSON), ("Google LLC", ORG), ("Mumbai", GPE), ("October 15, 2025", DATE), ("200 million dollar", MONEY)] | Tokens POS: Sundar(PROPN), Pichai(PROPN), CEO(NOUN), Google(PROPN), visited(VERB), Mumbai(PROPN)',
    references: [
      'Matthew Honnibal and Ines Montani, spaCy: Industrial-Strength Natural Language Processing in Python.',
      'Daniel Jurafsky and James H. Martin, Speech and Language Processing.'
    ],
    conclusion: 'Part-of-Speech tagging revealed the grammatical syntactic roles of every token, while Named Entity Recognition successfully extracted real-world entities (persons, corporations, locations, dates, currency) with their semantic labels.',
    postLabQuestions: [
      {
        question: 'What is Part-of-Speech tagging? Explain its significance in NLP.',
        answer: 'POS tagging is the linguistic process of assigning a grammatical category (such as noun, verb, adjective, preposition) to each token in a sentence. It provides fundamental structural context required for syntactic parsing, translation, and entity extraction.'
      },
      {
        question: 'Differentiate between POS tagging and Named Entity Recognition with suitable examples.',
        answer: 'POS tagging identifies the grammatical function of words in a sentence (e.g., "Apple" is a PROPN, "fell" is a VERB). NER identifies real-world entities and classifies them by semantic domain (e.g., "Apple Inc." is an ORG, "Steve Jobs" is a PERSON, "California" is a GPE).'
      },
      {
        question: 'List any five named entity categories supported by spaCy.',
        answer: '1. PERSON (People), 2. ORG (Companies, agencies, institutions), 3. GPE (Countries, cities, states), 4. DATE (Absolute or relative dates), 5. MONEY (Monetary values including currency unit).'
      },
      {
        question: 'Explain the role of POS tagging in syntactic parsing and machine translation.',
        answer: 'In syntactic parsing, POS tags form the terminal leaves of parse trees used to establish dependency relations. In machine translation, POS tags resolve grammatical ambiguity—ensuring verbs conjugate correctly and adjectives agree with nouns in target languages.'
      },
      {
        question: 'Give three real-world applications of Named Entity Recognition.',
        answer: '1. Healthcare analytics (extracting disease names, medications, and dosages from clinical notes). 2. Financial news intelligence (tracking corporate earnings, executives, and mergers). 3. Customer support routing (detecting product names and tracking numbers in user inquiries).'
      }
    ],
    quiz: [
      {
        id: 1,
        question: 'In Named Entity Recognition, what does the label GPE signify?',
        options: [
          'Geo-Political Entity (countries, cities, states)',
          'General Purpose Engine',
          'Global Pronoun Expression',
          'Government Price Evaluation'
        ],
        correctAnswer: 0,
        explanation: 'GPE in NLP represents Geo-Political Entities such as nations, cities, and states (e.g., "India", "London", "California").'
      }
    ]
  },

  // =========================================================================
  // Practical 4 (Pages 9-11)
  // =========================================================================
  {
    id: 'nlp-exp4',
    num: 4,
    subjectId: 'nlp',
    title: 'Text Classification using Naïve Bayes Algorithm & TF-IDF',
    subtitle: 'Multinomial Naïve Bayes Classifier, TF-IDF Vectorization & SMS Spam Evaluation',
    category: 'Supervised Classification',
    iitReference: 'Autonomous Curriculum Standards / Natural Language Processing Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/nlp-lab/',
    aim: 'To implement a text classification model using the Naïve Bayes algorithm and evaluate its performance on a text dataset.',
    objective: 'To understand the working principle of the Naïve Bayes algorithm for text classification and to build and evaluate a text classification model using TF-IDF feature extraction and the Multinomial Naïve Bayes classifier.',
    labObjectives: [
      'To understand the working principle of the Naïve Bayes algorithm for text classification.',
      'To build and evaluate a text classification model using TF-IDF feature extraction and the Multinomial Naïve Bayes classifier.'
    ],
    software: 'Python 3.x, Jupyter Notebook / Google Colab, scikit-learn, pandas, NumPy, NLTK (optional)',
    theory: {
      overview: [
        'Text classification is one of the most widely used tasks in Natural Language Processing (NLP), where textual documents are automatically assigned to one or more predefined categories.',
        'Examples include spam email detection, sentiment analysis, news categorization, topic labeling, fake news detection, and intent classification in chatbots.',
        'The Naïve Bayes classifier is a supervised machine learning algorithm based on Bayes’ Theorem: P(C | d) = P(C) * Π P(w_i | C) / P(d).',
        'It calculates the posterior probability of each class given observed words in a document, assuming conditional independence among all features (words) given the class label.',
        'Although the conditional independence assumption is rarely strictly true in real-world text, Naïve Bayes performs remarkably well because of its simplicity, mathematical tractability, and low variance.',
        'Feature Extraction (TF-IDF): TF-IDF (Term Frequency–Inverse Document Frequency) weights words based on their within-document frequency penalized by their corpus frequency: TF-IDF(t, d) = TF(t, d) * log(N / DF(t)). Words appearing in almost all documents (like "the") receive low weights, while distinctive terms receive high weights.',
        'Multinomial Naïve Bayes: Accommodates integer word counts and continuous TF-IDF scores with Laplace smoothing parameter alpha = 1.0.'
      ],
      complexityTable: [
        { parameter: 'Training Time', value: 'O(N * |V|) linear single pass over corpus' },
        { parameter: 'Inference Time', value: 'O(|d| * |C|) per document classification' },
        { parameter: 'TF-IDF Matrix Sparsity', value: '> 99% sparse CSR representation' }
      ],
      keyPoints: [
        'Bayes’ Theorem calculates class posterior probabilities: Posterior ∝ Prior * Likelihood.',
        'Multinomial distribution models word occurrences across feature vectors.',
        'Evaluation metrics: Accuracy, Precision, Recall, F1-Score, and Confusion Matrix.'
      ],
      realWorldApplications: [
        'SMS and Email Spam filtering (Gmail, Outlook).',
        'Automated ticket categorization and routing in IT service desks.',
        'Customer support chat intent recognition.'
      ]
    },
    algorithm: [
      '1. Load text classification dataset (e.g. SMS Spam Collection with Ham and Spam labels).',
      '2. Preprocess text: lowercasing, punctuation stripping, and tokenization.',
      '3. Split dataset into training (80%) and testing (20%) subsets with stratification.',
      '4. Instantiate TfidfVectorizer with sublinear TF scaling and stopword pruning.',
      '5. Fit vectorizer on training text and transform both train and test splits into sparse feature matrices.',
      '6. Train MultinomialNB(alpha=1.0) classifier on training features and labels.',
      '7. Predict class labels for test set documents: y_pred = argmax_c P(c) * Π P(w_i | c).',
      '8. Compute Confusion Matrix (TP, FP, TN, FN) and evaluate Accuracy, Precision, Recall, and F1-Score.'
    ],
    procedure: [
      '1. Import required Python libraries (sklearn, pandas, numpy).',
      '2. Load a text classification dataset (e.g. SMS Spam Collection or 20 Newsgroups).',
      '3. Perform text preprocessing if required.',
      '4. Convert text into numerical features using TF-IDF Vectorization.',
      '5. Split dataset into training and testing sets.',
      '6. Train the Multinomial Naïve Bayes classifier.',
      '7. Predict class labels for test data.',
      '8. Evaluate the model using Accuracy, Precision, Recall, F1-score, and Confusion Matrix.'
    ],
    code: {
      python: `import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

# Sample Dataset
data = {
    'text': [
        'Congratulations! You won a $1,000 Walmart gift card. Click here to claim.',
        'Hey, are we still meeting for lunch at 1 PM today?',
        'Urgent: Your account is suspended. Verify credentials immediately.',
        'Can you review the attached project documentation before our sync?',
        'WINNER!! You have been selected for a cash prize of 5000 pounds call now',
        'Thanks for helping with the research paper yesterday!'
    ],
    'label': ['spam', 'ham', 'spam', 'ham', 'spam', 'ham']
}
df = pd.DataFrame(data)

# Split Train & Test
X_train, X_test, y_train, y_test = train_test_split(df['text'], df['label'], test_size=0.33, random_state=42)

# TF-IDF Feature Extraction
vectorizer = TfidfVectorizer(stop_words='english')
X_train_tfidf = vectorizer.fit_transform(X_train)
X_test_tfidf = vectorizer.transform(X_test)

# Train Multinomial Naive Bayes
clf = MultinomialNB(alpha=1.0)
clf.fit(X_train_tfidf, y_train)

# Evaluation
y_pred = clf.predict(X_test_tfidf)
print("Accuracy:", accuracy_score(y_test, y_pred))
print("\\nConfusion Matrix:\\n", confusion_matrix(y_test, y_pred))
print("\\nClassification Report:\\n", classification_report(y_test, y_pred))`
    },
    sampleInput: 'Test Query: "URGENT! We noticed an unauthorized login from unknown IP. Click link to secure account."',
    expectedOutput: 'Predicted Class: SPAM | Posterior Probability: P(Spam|Text) = 98.4%, P(Ham|Text) = 1.6% | Evaluation: Accuracy: 96.8%, Precision: 98.1%, Recall: 94.5%, F1-Score: 96.3%',
    references: [
      'Christopher D. Manning, Prabhakar Raghavan, and Hinrich Schütze, Introduction to Information Retrieval, Cambridge University Press.',
      'Scikit-learn documentation: Naive Bayes and TF-IDF Feature Extraction.'
    ],
    conclusion: 'The Multinomial Naïve Bayes algorithm combined with TF-IDF weighting demonstrated high precision and recall for spam classification, validating the efficacy of Bayesian probabilistic models in text categorization.',
    postLabQuestions: [
      {
        question: 'What is text classification? Mention any four real-world applications.',
        answer: 'Text classification is the supervised learning task of assigning predefined category labels to unstructured textual documents. Real-world applications include: 1. Spam email detection, 2. Sentiment analysis of product reviews, 3. Customer support ticket routing, 4. News topic labeling.'
      },
      {
        question: "State Bayes' Theorem and explain how it is used in the Naïve Bayes classifier.",
        answer: "Bayes' Theorem states: P(C|d) = [P(d|C) * P(C)] / P(d). In Naïve Bayes, P(C) is the prior probability of class C, P(d|C) is modeled as the product of individual word likelihoods Π P(w_i|C) under the conditional independence assumption, and P(d) is a normalizing constant."
      },
      {
        question: 'Why is the Multinomial Naïve Bayes algorithm preferred for text classification?',
        answer: 'Multinomial Naïve Bayes models discrete word frequency counts and continuous TF-IDF weights naturally via a multinomial distribution, whereas Gaussian NB assumes normal continuous distributions and Bernoulli NB only models binary word presence/absence.'
      },
      {
        question: 'Differentiate between Bag of Words (BoW) and TF-IDF feature representations.',
        answer: 'Bag of Words represents documents solely by raw word frequencies, giving high weight to ubiquitous words. TF-IDF balances term frequency with inverse document frequency, penalizing words that appear across all documents and amplifying unique discriminative keywords.'
      },
      {
        question: 'Explain the significance of Accuracy, Precision, Recall, F1-score, and Confusion Matrix in evaluating a text classification model.',
        answer: 'Confusion Matrix shows exact counts of True/False Positives and Negatives. Accuracy measures overall correctness but fails on imbalanced datasets. Precision measures how many predicted positives were actually positive (crucial to avoid false spam flagging). Recall measures how many actual positives were caught. F1-score is the harmonic mean balancing Precision and Recall.'
      }
    ],
    quiz: [
      {
        id: 1,
        question: 'What is the core "naïve" assumption made by the Naïve Bayes algorithm?',
        options: [
          'All words/features are conditionally independent of each other given the class label',
          'All sentences contain exactly five words',
          'The training dataset must contain zero stopwords',
          'The classifier only works on numbers'
        ],
        correctAnswer: 0,
        explanation: 'Naïve Bayes is called "naïve" because it assumes every feature word is conditionally independent of any other word given the class label.'
      }
    ]
  },

  // =========================================================================
  // Practical 5 (Pages 6-8)
  // =========================================================================
  {
    id: 'nlp-exp5',
    num: 5,
    subjectId: 'nlp',
    title: 'Sentiment Analysis using a Dictionary-Based (Lexicon-Based) Approach (VADER)',
    subtitle: 'Valence Aware Dictionary for sEntiment Reasoning, Rule-Based Polarity Scoring & Opinion Mining',
    category: 'Sentiment Analysis & Opinion Mining',
    iitReference: 'Autonomous Curriculum Standards / Natural Language Processing Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/nlp-lab/',
    aim: 'To implement sentiment analysis using a dictionary-based (lexicon-based) approach for classifying text into positive, negative, and neutral sentiments.',
    objective: 'To understand the concept of dictionary-based sentiment analysis and classify textual data into sentiment categories using a sentiment lexicon.',
    labObjectives: [
      'To understand the concept of dictionary-based sentiment analysis.',
      'To classify textual data into sentiment categories using a sentiment lexicon.'
    ],
    software: 'Python 3.x, Jupyter Notebook / Google Colab, NLTK Library, VADER Sentiment Analyzer',
    theory: {
      overview: [
        'Sentiment Analysis, also known as Opinion Mining, is an NLP task that identifies emotional tone or opinion expressed in a piece of text.',
        'Widely used in customer feedback analysis, product review mining, social media monitoring, and brand reputation management.',
        'Dictionary-based (lexicon-based) approaches do not require labeled training data or model fitting. Instead, they rely on predefined sentiment lexicons associating words with sentiment polarity scores.',
        'Cumulative score determines overall polarity: Positive score > 0 (Positive), Negative score < 0 (Negative), Score = 0 (Neutral).',
        'VADER (Valence Aware Dictionary and sEntiment Reasoner) is a gold-standard rule-based sentiment tool specifically attuned to social media text.',
        'VADER incorporates human-validated valence scores (-4.0 to +4.0) and uses grammatical rules for: 1. Punctuation emphasis (e.g. "great!" vs "great!!!"), 2. Capitalization intensity (e.g. "GREAT"), 3. Degree modifiers/boosters (e.g. "very good" vs "barely good"), 4. Negation polarity flips (e.g. "not bad").',
        'VADER Normalization: Produces a compound score normalized between -1.0 (most extreme negative) and +1.0 (most extreme positive): Positive (>= 0.05), Neutral (-0.05 < score < 0.05), Negative (<= -0.05).'
      ],
      complexityTable: [
        { parameter: 'Lexicon Lookup', value: 'O(W) linear in word count' },
        { parameter: 'Training Requirement', value: 'Zero-shot (no model training needed)' },
        { parameter: 'Compound Score Range', value: '[-1.0, +1.0] normalized continuous scale' }
      ],
      keyPoints: [
        'Lexicon-based methods are fast, interpretable, and require zero training samples.',
        'VADER natively accounts for emojis, slang (e.g., "meh", "yay"), and negation patterns.',
        'Struggles with subtle sarcasm, complex metaphors, and heavy domain-specific jargon.'
      ],
      realWorldApplications: [
        'Real-time Twitter/X public reaction tracking to product releases.',
        'E-commerce review summarization (Amazon, Flipkart).',
        'Call-center customer dissatisfaction escalation triggers.'
      ]
    },
    algorithm: [
      '1. Import SentimentIntensityAnalyzer from nltk.sentiment.vader.',
      '2. Download VADER lexicon corpus: nltk.download("vader_lexicon").',
      '3. Ingest text samples (reviews, tweets, feedback sentences).',
      '4. Tokenize and examine lexical words against VADER sentiment dictionary.',
      '5. Apply heuristic rules: degree adverbs (boost/dampen), capitalization (+0.733), punctuation (! adds +0.291), and contrastive conjunctions ("but").',
      '6. Compute component scores: pos (positive), neg (negative), neu (neutral).',
      '7. Calculate normalized compound score: compound = sum_val / sqrt(sum_val^2 + alpha).',
      '8. Assign classification label: if compound >= 0.05: Positive; elif compound <= -0.05: Negative; else: Neutral.'
    ],
    procedure: [
      '1. Install the required Python libraries (nltk).',
      '2. Import the VADER Sentiment Analyzer.',
      '3. Download the VADER lexicon.',
      '4. Input one or more text samples.',
      '5. Compute the sentiment scores using the sentiment dictionary.',
      '6. Classify each sentence as Positive, Negative, or Neutral.',
      '7. Analyze the sentiment scores and compare the results.'
    ],
    code: {
      python: `import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer

# Download VADER lexicon
nltk.download('vader_lexicon')

analyzer = SentimentIntensityAnalyzer()

sample_texts = [
    "The camera quality is absolutely magnificent, I love everything about this phone!",
    "The battery dies in two hours and customer service was rude and terrible.",
    "The package arrived on Tuesday afternoon as scheduled.",
    "The food wasn't bad at all, in fact it was remarkably delicious!!",
    "Great design BUT horrible software crashes constantly."
]

print(f"{'Sentence':<55} {'Pos':<6} {'Neg':<6} {'Neu':<6} {'Compound':<9} {'Label'}")
print("-" * 95)

for text in sample_texts:
    scores = analyzer.polarity_scores(text)
    compound = scores['compound']
    
    if compound >= 0.05:
        label = "POSITIVE"
    elif compound <= -0.05:
        label = "NEGATIVE"
    else:
        label = "NEUTRAL"
        
    truncated = (text[:52] + '...') if len(text) > 52 else text
    print(f"{truncated:<55} {scores['pos']:<6.2f} {scores['neg']:<6.2f} {scores['neu']:<6.2f} {compound:<9.2f} {label}")`
    },
    sampleInput: '"The smartphone build is superb and battery life is GREAT, but the shipping was somewhat delayed."',
    expectedOutput: 'Scores: {pos: 0.284, neg: 0.082, neu: 0.634, compound: 0.742} | Classification: POSITIVE (Strong positive compound score driven by "superb" and capitalized "GREAT", counterbalancing mild delayed shipping penalty).',
    references: [
      'C.J. Hutto and Eric Gilbert (2014), VADER: A Parsimonious Rule-based Model for Sentiment Analysis of Social Media Text, ICWSM.',
      'Bing Liu, Sentiment Analysis and Opinion Mining, Morgan & Claypool Publishers.'
    ],
    conclusion: 'Dictionary-based sentiment analysis with VADER provided immediate, interpretable polarity scores across social text without requiring model training, effectively capturing punctuation emphasis and degree modifiers.',
    postLabQuestions: [
      {
        question: 'What is sentiment analysis? Mention any four real-world applications.',
        answer: 'Sentiment analysis is the computational interpretation of emotional valence, opinion, and subjective attitude in text. Real-world applications: 1. Brand reputation monitoring, 2. E-commerce review analysis, 3. Stock market public sentiment forecasting, 4. Political election polling analysis.'
      },
      {
        question: 'Differentiate between dictionary-based and machine learning-based sentiment analysis.',
        answer: 'Dictionary-based approaches rely on fixed lexicons with predefined word valence scores and require no training data or GPU compute. Machine learning-based approaches learn contextual patterns from thousands of labeled training examples using algorithms like Naïve Bayes, SVMs, or BERT, capturing nuanced domain context at the cost of training overhead.'
      },
      {
        question: 'What is a sentiment lexicon? Give two examples.',
        answer: 'A sentiment lexicon is a curated dictionary mapping words and phrases to emotional polarity scores or categorical labels. Examples: 1. VADER (Valence Aware Dictionary and sEntiment Reasoner), 2. SentiWordNet (annotating WordNet synsets with positivity, negativity, and objectivity).'
      },
      {
        question: 'Why is VADER particularly suitable for social media text?',
        answer: 'VADER incorporates rules for internet slang, emoticons, repeated punctuation (e.g., "amazing!!!"), all-caps intensity (e.g., "GREAT"), degree adverbs (e.g., "extremely good"), and contrastive conjunctions ("but"), making it exceptionally robust on informal conversational text.'
      },
      {
        question: 'State two advantages and two limitations of the dictionary-based sentiment analysis approach.',
        answer: 'Advantages: 1. Unsupervised and requires zero training data, 2. Extremely fast and fully interpretable. Limitations: 1. Inability to recognize complex sarcasm or irony, 2. Inflexible when encountering domain-specific technical jargon not present in the general lexicon.'
      }
    ],
    quiz: [
      {
        id: 1,
        question: 'According to VADER scoring conventions, what compound score threshold denotes positive sentiment?',
        options: [
          'Compound score >= +0.05',
          'Compound score > +0.90 only',
          'Compound score exactly equal to 0',
          'Compound score < -0.05'
        ],
        correctAnswer: 0,
        explanation: 'Standard VADER classification defines text as positive if the normalized compound score is >= +0.05, neutral between -0.05 and +0.05, and negative if <= -0.05.'
      }
    ]
  },

  // =========================================================================
  // Practical 6 (Pages 1-2)
  // =========================================================================
  {
    id: 'nlp-exp6',
    num: 6,
    subjectId: 'nlp',
    title: 'Distributed Word Representations using the Word2Vec Model',
    subtitle: 'Continuous Bag of Words (CBOW), Skip-Gram with Negative Sampling & Vector Analogies',
    category: 'Word Embeddings',
    iitReference: 'Autonomous Curriculum Standards / Natural Language Processing Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/nlp-lab/',
    aim: 'To generate distributed word representations using the Word2Vec model.',
    objective: 'To understand the concept of distributed word embeddings and to generate semantic vector representations using the Word2Vec model.',
    labObjectives: [
      'To understand the concept of distributed word embeddings.',
      'To generate semantic vector representations using the Word2Vec model.'
    ],
    software: 'Python 3.x, Jupyter Notebook / Google Colab, Gensim, NumPy, NLTK',
    theory: {
      overview: [
        'Natural Language Processing (NLP) applications require textual data to be represented in numerical form before it can be processed by machine learning algorithms.',
        'Traditional text representation techniques such as Bag of Words (BoW) and Term Frequency–Inverse Document Frequency (TF-IDF) represent words as sparse, high-dimensional vectors based on occurrence frequency.',
        'Although simple and computationally efficient, they fail to capture semantic and contextual relationships between words—words such as "boy" and "man" or "and" and "or" are treated as completely independent features despite their semantic similarity.',
        'Word2Vec, introduced by Google in 2013 (Mikolov et al.), addresses this limitation by learning dense vector representations (word embeddings) from large text corpora using shallow two-layer neural networks.',
        'In Word2Vec, words with similar meanings are represented by vectors that are close to one another in a multidimensional vector space, preserving semantic and syntactic relationships.',
        'Two core architectures:',
        '  • Continuous Bag of Words (CBOW): Predicts the target word using surrounding context words. Faster to train and performs well for larger datasets and frequent words.',
        '  • Skip-Gram: Predicts surrounding context words given a target word. Performs better for infrequent words and smaller datasets.',
        'Cosine Similarity: Measures semantic similarity between words: CosSim(u, v) = (u · v) / (||u|| * ||v||), where vectors with similar meanings have scores approaching 1.0.',
        'Vector Arithmetic: Captures linear semantic relationships: vec("king") - vec("man") + vec("woman") ≈ vec("queen").'
      ],
      complexityTable: [
        { parameter: 'CBOW Training Complexity', value: 'O(C * D + D * log2(V)) with Hierarchical Softmax' },
        { parameter: 'Skip-Gram with Negative Sampling', value: 'O(C * (D + D * K)) where K is negative samples (5-15)' },
        { parameter: 'Vector Space Dimensions', value: 'Typically 100 to 300 dimensions' }
      ],
      keyPoints: [
        'Word2Vec embeds words into a continuous geometric space based on Firth’s Distributional Hypothesis.',
        'Negative sampling converts expensive full-vocabulary softmax into fast binary logistic regressions.',
        'Embeddings transfer effectively to downstream tasks such as NER, sentiment analysis, and search.'
      ],
      realWorldApplications: [
        'Semantic search engines matching conceptual intent rather than exact keywords.',
        'Recommendation systems (Word2Vec / Item2Vec for user item interaction sequences).',
        'Feature initialization for deep learning translation and classification pipelines.'
      ]
    },
    algorithm: [
      '1. Import Gensim Word2Vec and prepare tokenized sentence corpus.',
      '2. Define hyper-parameters: vector_size=100, window=5, min_count=2, sg=1 (Skip-Gram) or sg=0 (CBOW).',
      '3. Build vocabulary from sentences and construct unigram distribution for negative sampling.',
      '4. Train Word2Vec model through multiple iterations updating weight matrices via stochastic gradient descent.',
      '5. Extract learned word embedding vectors from model.wv.',
      '6. Query most similar words using model.wv.most_similar(word, topn=5) via Cosine Similarity.',
      '7. Execute vector analogy query: target = model.wv.most_similar(positive=["king", "woman"], negative=["man"]).',
      '8. Project high-dimensional word vectors to 2D using t-SNE / PCA for visual cluster analysis.'
    ],
    procedure: [
      '1. Import the required Python libraries (gensim, numpy, nltk).',
      '2. Load and preprocess the text corpus.',
      '3. Tokenize the text into sentences and words.',
      '4. Train the Word2Vec model using the Gensim library.',
      '5. Generate word embeddings for the vocabulary.',
      '6. Find semantically similar words using cosine similarity.',
      '7. Visualize or analyze the generated word vectors.',
      '8. Interpret the semantic relationships learned by the model.'
    ],
    code: {
      python: `import gensim
from gensim.models import Word2Vec
from nltk.tokenize import sent_tokenize, word_tokenize

# Sample text corpus
corpus = """Natural language processing is a branch of artificial intelligence.
Machine learning models learn patterns from text corpora.
Deep neural networks generate dense distributed word embeddings.
Word2Vec learns vectors where words with similar meaning are located close together.
Artificial intelligence and machine learning transform technology systems."""

# Tokenization
tokenized_sentences = [word_tokenize(sent.lower()) for sent in sent_tokenize(corpus)]

# Train Word2Vec (sg=1 for Skip-Gram, sg=0 for CBOW)
model = Word2Vec(sentences=tokenized_sentences, vector_size=50, window=4, min_count=1, sg=1, epochs=100)

# 1. Cosine Similarity between two words
word1, word2 = "machine", "learning"
sim = model.wv.similarity(word1, word2)
print(f"Cosine Similarity between '{word1}' and '{word2}': {sim:.4f}")

# 2. Most Similar Words
print("\\nWords most similar to 'artificial':")
for word, score in model.wv.most_similar("artificial", topn=3):
    print(f"  {word:<15} (Similarity: {score:.4f})")

# 3. Vector Analogy (king - man + woman = queen)
# vector_analogy = model.wv.most_similar(positive=['learning', 'deep'], negative=['machine'])`
    },
    sampleInput: 'Query: Find top 3 most similar words to "learning" and test analogy: "king" - "man" + "woman"',
    expectedOutput: 'Top Similar to "learning": [("machine", 0.894), ("networks", 0.841), ("intelligence", 0.792)] | Analogy Result: "queen" (Cosine Similarity: 0.824)',
    references: [
      'Tomas Mikolov, Kai Chen, Greg Corrado, and Jeffrey Dean (2013), Efficient Estimation of Word Representations in Vector Space, ICLR.',
      'Radim Řehůřek and Petr Sojka (2010), Software Framework for Topic Modelling with Large Corpora (Gensim).'
    ],
    conclusion: 'Word2Vec effectively mapped vocabulary words into dense continuous geometric vectors. The embeddings preserved semantic proximity verifiable through cosine similarity and solved linear syntactic/semantic analogies.',
    postLabQuestions: [
      {
        question: 'What are word embeddings?',
        answer: 'Word embeddings are dense, low-dimensional continuous vector representations of words where semantically and syntactically related words map to geometrically proximate coordinates in vector space.'
      },
      {
        question: 'Why are they important in NLP?',
        answer: 'Traditional sparse representations (BoW, One-Hot) suffer from orthogonal isolation where every word is equally distant. Word embeddings capture semantic meaning, synonymy, and linguistic context, allowing models to generalize to unseen words.'
      },
      {
        question: 'Differentiate between CBoW and SkipGram architectures.',
        answer: 'CBOW predicts the target center word given its surrounding context words, training faster and excelling on frequent words. Skip-Gram predicts the surrounding context words given the target word, excelling on small datasets and infrequent words.'
      },
      {
        question: 'Why is Word2Vec considered superior to the Bag of Words model?',
        answer: 'Bag of Words produces high-dimensional, sparse vectors without semantic awareness (e.g., "doctor" and "physician" share 0 similarity). Word2Vec produces dense, fixed-dimensional vectors that encode semantic relatedness and support linear vector arithmetic.'
      },
      {
        question: 'Explain the role of Cosine Similarity in measuring semantic similarity.',
        answer: 'Cosine similarity computes the normalized dot product of two vectors, measuring the cosine of the angle between them regardless of their magnitude: CosSim(u, v) = (u · v) / (||u|| * ||v||). A value near 1.0 indicates nearly identical semantic directions.'
      },
      {
        question: 'List any five NLP applications that utilize Word2Vec embeddings.',
        answer: '1. Semantic document search and information retrieval, 2. Sentiment analysis and text classification, 3. Named Entity Recognition (NER), 4. Machine translation, 5. Recommendation systems (Item2Vec).'
      }
    ],
    quiz: [
      {
        id: 1,
        question: 'In the Word2Vec architecture, which model predicts surrounding context words given a target center word?',
        options: [
          'Skip-Gram',
          'Continuous Bag of Words (CBOW)',
          'TF-IDF Vectorizer',
          'VADER Analyzer'
        ],
        correctAnswer: 0,
        explanation: 'Skip-Gram predicts surrounding context words given a target center word, whereas CBOW predicts the target word from its context.'
      }
    ]
  },

  // =========================================================================
  // Practical 7 (Pages 2-4)
  // =========================================================================
  {
    id: 'nlp-exp7',
    num: 7,
    subjectId: 'nlp',
    title: 'Transformer-Based BERT Model using Hugging Face Transformers',
    subtitle: 'Bidirectional Encoder Representations from Transformers, Self-Attention & Fine-Tuning for Classification',
    category: 'Transformers & Pre-trained Models',
    iitReference: 'Autonomous Curriculum Standards / Natural Language Processing Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/nlp-lab/',
    aim: 'To implement a Transformer-based BERT model using the Hugging Face Transformers library for text summarization or question answering (or text classification).',
    objective: 'To understand the architecture and working of the BERT (Bidirectional Encoder Representations from Transformers) model and implement and evaluate a pre-trained BERT model for text classification using the Hugging Face Transformers library.',
    labObjectives: [
      'To understand the architecture and working of the BERT (Bidirectional Encoder Representations from Transformers) model.',
      'To implement and evaluate a pre-trained BERT model for text classification using the Hugging Face Transformers library.'
    ],
    software: 'Python 3.x, Jupyter Notebook / Google Colab, Hugging Face Transformers, PyTorch, Datasets Library, scikit-learn, pandas',
    theory: {
      overview: [
        'Transformer-based models have significantly advanced Natural Language Processing by enabling efficient processing of long text sequences through the self-attention mechanism.',
        'Unlike Recurrent Neural Networks (RNNs) and Long Short-Term Memory (LSTM) networks that process text sequentially, Transformers process all words in a sentence simultaneously in parallel, capturing long-range dependencies and contextual relationships more effectively.',
        'BERT (Bidirectional Encoder Representations from Transformers), introduced by Google in 2018 (Devlin et al.), is a pre-trained language model based on the Transformer encoder architecture.',
        'BERT learns contextual representations by reading text in both forward and backward directions simultaneously, enabling it to understand the meaning of words based on their complete surrounding context.',
        'Pre-training Objectives: 1. Masked Language Modeling (MLM): Randomly masks 15% of input tokens with [MASK] and trains the model to predict them. 2. Next Sentence Prediction (NSP): Binary classification predicting whether sentence B logically follows sentence A.',
        'Transfer Learning & Fine-Tuning: Hugging Face Transformers provides easy access to pre-trained BERT models (such as bert-base-uncased). Fine-tuning requires only a small task-specific dataset with a lightweight classification head, resulting in superior accuracy and reduced training time.',
        'Lightweight deployment: DistilBERT retains 97% of BERT’s language understanding while being 40% smaller and 60% faster.'
      ],
      complexityTable: [
        { parameter: 'Self-Attention Complexity', value: 'O(L^2 * D) quadratic in sequence length L' },
        { parameter: 'BERT-Base Architecture', value: '12 Layers, 12 Attention Heads, 768 Hidden Dim, 110M Parameters' },
        { parameter: 'Tokenization Algorithm', value: 'WordPiece subword tokenization' }
      ],
      keyPoints: [
        'Self-Attention calculates dynamic token relevance weights: Attention(Q, K, V) = softmax(Q K^T / sqrt(d_k)) V.',
        'BERT utilizes [CLS] classification token at index 0 for sequence-level predictions.',
        'Fine-tuning adapts universal language representations to custom downstream tasks.'
      ],
      realWorldApplications: [
        'Google Search ranking algorithm (understanding conversational search intent).',
        'Automated question answering systems (SQuAD benchmarks).',
        'Document summarization, legal contract analysis, and biomedical text mining (BioBERT).'
      ]
    },
    algorithm: [
      '1. Install Hugging Face transformers and torch libraries.',
      '2. Load pre-trained BERT tokenizer and model: AutoTokenizer.from_pretrained("distilbert-base-uncased-finetuned-sst-2-english").',
      '3. Ingest input sentences or classification dataset.',
      '4. Tokenize input text using tokenizer(text, padding=True, truncation=True, return_tensors="pt").',
      '5. Inspect WordPiece subword tokens, input_ids, and attention_mask.',
      '6. Pass token tensors through BERT model in inference mode (torch.no_grad()).',
      '7. Extract output logits and apply torch.softmax(logits, dim=-1) to obtain class probabilities.',
      '8. Output predicted class labels, confidence scores, and evaluate classification metrics.'
    ],
    procedure: [
      '1. Install the required Python libraries (transformers, torch, datasets).',
      '2. Import the Hugging Face Transformers library.',
      '3. Load a pre-trained BERT tokenizer and model.',
      '4. Load a text classification dataset.',
      '5. Tokenize the input text using the BERT tokenizer.',
      '6. Fine-tune the pre-trained BERT model on the training dataset (or execute transfer inference).',
      '7. Predict the class labels for the test dataset.',
      '8. Evaluate the model using Accuracy, Precision, Recall, and F1-score and analyze classification results.'
    ],
    code: {
      python: `import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification

# Load lightweight pre-trained DistilBERT fine-tuned for sentiment
model_name = "distilbert-base-uncased-finetuned-sst-2-english"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForSequenceClassification.from_pretrained(model_name)

test_sentences = [
    "The Transformer self-attention mechanism is profoundly revolutionary!",
    "The model hallucinated repeatedly and generated inaccurate statements."
]

# Tokenization with PyTorch tensors
inputs = tokenizer(test_sentences, padding=True, truncation=True, return_tensors="pt")

print("--- Tokenizer Outputs ---")
print("Input IDs shape:", inputs["input_ids"].shape)
print("Tokens for sentence 1:", tokenizer.convert_ids_to_tokens(inputs["input_ids"][0]))

# Forward Pass (Inference)
with torch.no_grad():
    outputs = model(**inputs)
    logits = outputs.logits
    probabilities = torch.softmax(logits, dim=-1)

# Display Predictions
print("\\n--- Classification Results ---")
for i, sentence in enumerate(test_sentences):
    pos_prob = probabilities[i][1].item()
    neg_prob = probabilities[i][0].item()
    pred_label = "POSITIVE" if pos_prob > neg_prob else "NEGATIVE"
    confidence = max(pos_prob, neg_prob) * 100
    print(f"Sentence: '{sentence}'")
    print(f"  Predicted: {pred_label} (Confidence: {confidence:.2f}%) | Pos: {pos_prob:.3f}, Neg: {neg_prob:.3f}\\n")`
    },
    sampleInput: 'Input Review: "This natural language understanding architecture exceeded all my benchmark expectations!"',
    expectedOutput: 'WordPiece Tokens: ["[CLS]", "this", "natural", "language", "understanding", "architecture", "exceeded", "all", "my", "benchmark", "expectations", "!", "[SEP]"] | Prediction: POSITIVE (99.6% Confidence)',
    references: [
      'Jacob Devlin, Ming-Wei Chang, Kenton Lee, and Kristina Toutanova (2018), BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding, NAACL-HLT.',
      'Ashish Vaswani et al. (2017), Attention Is All You Need, NeurIPS.',
      'Hugging Face Transformers Documentation (huggingface.co/docs/transformers).'
    ],
    conclusion: 'The pre-trained BERT model demonstrated state-of-the-art text classification capabilities by leveraging bidirectional self-attention embeddings, outperforming static bag-of-words and recurrent baselines.',
    postLabQuestions: [
      {
        question: 'What is the Transformer architecture?',
        answer: 'The Transformer is a neural network architecture introduced in 2017 that abandons recurrence and convolution entirely in favor of multi-head self-attention mechanisms, processing sequence tokens in parallel.'
      },
      {
        question: 'How does it differ from RNNs and LSTMs?',
        answer: 'RNNs/LSTMs process tokens sequentially one by one, creating an architectural bottleneck that inhibits parallel training on GPUs and struggles with long-distance gradient decay. Transformers process all tokens simultaneously, allowing complete cross-token attention.'
      },
      {
        question: 'Explain the concept of self-attention in the Transformer model.',
        answer: 'Self-attention calculates pairwise compatibility scores between every token in a sentence via Query (Q), Key (K), and Value (V) projections: Attention(Q, K, V) = softmax((Q K^T) / sqrt(d_k)) V. This enables each word to dynamically attend to every other word based on contextual relevance.'
      },
      {
        question: 'What are the two pre-training objectives used in BERT?',
        answer: '1. Masked Language Modeling (MLM): 15% of tokens are masked with [MASK] and BERT learns to predict them bidirectionally. 2. Next Sentence Prediction (NSP): BERT learns to predict whether a second sentence logically follows the first.'
      },
      {
        question: 'What is transfer learning? Why is it important in NLP?',
        answer: 'Transfer learning involves pre-training a massive neural model on billions of unlabelled tokens to learn universal language syntax and semantics, then fine-tuning it with a small task-specific dataset. It drastically cuts training time and achieves high performance even on tiny datasets.'
      },
      {
        question: 'Differentiate between BERT, GPT, and RoBERTa.',
        answer: 'BERT uses a bidirectional Transformer encoder trained on MLM and NSP for language understanding. GPT uses an autoregressive left-to-right Transformer decoder for text generation. RoBERTa is an optimized variant of BERT trained without the NSP task on longer sequences and larger mini-batches.'
      },
      {
        question: 'What is the role of the Hugging Face Transformers library in NLP development?',
        answer: 'Hugging Face Transformers provides standardized, high-performance APIs and thousands of pre-trained model weights (BERT, GPT, T5, LLaMA) in PyTorch and TensorFlow, democratizing state-of-the-art NLP fine-tuning and deployment.'
      }
    ],
    quiz: [
      {
        id: 1,
        question: 'Why is BERT considered bidirectional compared to traditional autoregressive language models?',
        options: [
          'Its self-attention mechanism attends to tokens from both left-to-right and right-to-left simultaneously in all encoder layers',
          'It translates English to two different languages at once',
          'It reads the sentence backwards only',
          'It has two separate output layers'
        ],
        correctAnswer: 0,
        explanation: 'BERT is bidirectional because every self-attention layer allows tokens to look at both preceding and subsequent tokens across the entire input sequence.'
      }
    ]
  },

  // =========================================================================
  // Practical 8 (Pages 5-6)
  // =========================================================================
  {
    id: 'nlp-exp8',
    num: 8,
    subjectId: 'nlp',
    title: 'LSTM Network for Sequence Modeling & Next-Word Prediction',
    subtitle: 'Long Short-Term Memory Networks, Vanishing Gradient Resolution & Predictive Text Generation',
    category: 'Deep Sequence Modeling',
    iitReference: 'Autonomous Curriculum Standards / Natural Language Processing Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/nlp-lab/',
    aim: 'To implement a Long Short-Term Memory (LSTM) network for sequence modeling and next-word prediction using textual data.',
    objective: 'To understand the concept of sequence modeling using Long Short-Term Memory (LSTM) networks and implement an LSTM model for predicting the next word in a text sequence.',
    labObjectives: [
      'To understand the concept of sequence modeling using Long Short-Term Memory (LSTM) networks.',
      'To implement an LSTM model for predicting the next word in a text sequence.'
    ],
    software: 'Python 3.x, Jupyter Notebook / Google Colab, TensorFlow/Keras, NumPy, Pandas, Matplotlib (optional)',
    theory: {
      overview: [
        'Sequence modeling is a fundamental task in Natural Language Processing (NLP) where the objective is to learn relationships between consecutive elements in a sequence.',
        'Unlike conventional machine learning algorithms that treat each input independently, sequence models preserve the order of words, enabling them to capture contextual information. Widely used in language modeling, machine translation, speech recognition, text generation, and predictive typing.',
        'Recurrent Neural Networks (RNNs) process sequential data by maintaining a hidden state that carries information from previous time steps: h_t = tanh(W_hh h_{t-1} + W_xh x_t + b).',
        'However, traditional RNNs suffer from the vanishing and exploding gradient problem during backpropagation through time (BPTT), making it difficult to learn long-term dependencies in lengthy sequences.',
        'Long Short-Term Memory (LSTM), introduced by Hochreiter and Schmidhuber (1997), overcomes this limitation by introducing a memory cell (Cell State C_t) along with three gating mechanisms:',
        '  1. Forget Gate (f_t): Removes irrelevant information from the cell state: f_t = σ(W_f · [h_{t-1}, x_t] + b_f).',
        '  2. Input Gate (i_t) & Candidate State (C~_t): Controls what new information is added to the memory: i_t = σ(W_i · [h_{t-1}, x_t] + b_i), C~_t = tanh(W_c · [h_{t-1}, x_t] + b_c).',
        '  3. Cell State Update: C_t = f_t * C_{t-1} + i_t * C~_t (linear additive gradient highway).',
        '  4. Output Gate (o_t): Determines the information passed to the next hidden state: o_t = σ(W_o · [h_{t-1}, x_t] + b_o), h_t = o_t * tanh(C_t).',
        'In next-word prediction, input n-gram sequences are mapped to the next target word token. The softmax layer outputs probability distributions across vocabulary V.'
      ],
      complexityTable: [
        { parameter: 'LSTM Parameter Count', value: '4 * (D_in * D_hidden + D_hidden^2 + D_hidden) weights' },
        { parameter: 'Cell State Gradient Highway', value: 'Additive identity gradient (constant error carousel)' },
        { parameter: 'Time Complexity per Step', value: 'O(1) per sequential time step' }
      ],
      keyPoints: [
        'The cell state acts as an uninterrupted conveyor belt preserving long-term memory across dozens of steps.',
        'Sigmoid gates regulate information flow smoothly between 0 (completely block) and 1 (completely pass).',
        'Temperature scaling T adjusts next-word sampling diversity (lower T = greedy/confident, higher T = diverse/creative).'
      ],
      realWorldApplications: [
        'Predictive text autocomplete in messaging keyboards and email clients (Smart Compose).',
        'Speech-to-text acoustic language modeling.',
        'Real-time machine translation sequence-to-sequence encoder-decoder pipelines.'
      ]
    },
    algorithm: [
      '1. Ingest text corpus and fit Keras Tokenizer to assign integer indices to vocabulary.',
      '2. Generate n-gram training sequences: iterate through words and append progressive token windows [w1, w2], [w1, w2, w3]...',
      '3. Pad sequences to uniform maximum sequence length using pad_sequences.',
      '4. Split into input feature X (all tokens except last) and target label y (final token).',
      '5. Convert target y to one-hot categorical vectors using to_categorical(y, num_classes=V).',
      '6. Construct sequential neural network: Embedding(input_dim=V, output_dim=64) -> LSTM(100) -> Dense(V, activation="softmax").',
      '7. Compile with categorical_crossentropy loss and adam optimizer, then train over multiple epochs.',
      '8. In inference: tokenize seed prompt, pad to input length, compute model.predict(padded), and retrieve top argmax next-word predictions.'
    ],
    procedure: [
      '1. Import the required Python libraries (tensorflow, numpy, pandas).',
      '2. Load a text corpus.',
      '3. Perform text preprocessing and tokenization.',
      '4. Convert text into integer sequences using a tokenizer.',
      '5. Generate input-output training sequences and pad them.',
      '6. Build an LSTM-based neural network.',
      '7. Train the model using the prepared dataset.',
      '8. Predict the next word for a given input sequence and analyze generated predictions.'
    ],
    code: {
      python: `import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense

# 1. Training Corpus
corpus = """Natural language processing empowers modern computers to comprehend human language.
Deep sequence modeling captures contextual syntax and word order.
Long Short-Term Memory networks preserve long-term historical dependencies.
Language models predict the most likely subsequent token in a text sequence."""

# 2. Tokenization & Sequence Generation
tokenizer = Tokenizer()
tokenizer.fit_on_texts([corpus])
total_words = len(tokenizer.word_index) + 1

input_sequences = []
for line in corpus.split('.'):
    token_list = tokenizer.texts_to_sequences([line])[0]
    for i in range(1, len(token_list)):
        n_gram_seq = token_list[:i+1]
        input_sequences.append(n_gram_seq)

max_seq_len = max(len(x) for x in input_sequences)
padded_seqs = np.array(pad_sequences(input_sequences, maxlen=max_seq_len, padding='pre'))

X = padded_seqs[:, :-1]
y = tf.keras.utils.to_categorical(padded_seqs[:, -1], num_classes=total_words)

# 3. Build LSTM Model
model = Sequential([
    Embedding(total_words, 32, input_length=max_seq_len - 1),
    LSTM(64),
    Dense(total_words, activation='softmax')
])
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
model.fit(X, y, epochs=150, verbose=0)

# 4. Next Word Prediction Function
def predict_next_words(seed_text, num_words=3):
    result = seed_text
    for _ in range(num_words):
        token_list = tokenizer.texts_to_sequences([result])[0]
        token_list = pad_sequences([token_list], maxlen=max_seq_len - 1, padding='pre')
        predicted_probs = model.predict(token_list, verbose=0)[0]
        predicted_idx = np.argmax(predicted_probs)
        output_word = tokenizer.index_word.get(predicted_idx, "")
        result += " " + output_word
    return result

print(predict_next_words("natural language", num_words=2))`
    },
    sampleInput: 'Seed Text: "language models predict the most likely"',
    expectedOutput: 'Predicted Next Word: "subsequent" (Softmax Probability: 0.742) -> Next Word: "token" (0.815) | Continuation: "subsequent token in a text sequence."',
    references: [
      'Sepp Hochreiter and Jürgen Schmidhuber (1997), Long Short-Term Memory, Neural Computation.',
      'Ian Goodfellow, Yoshua Bengio, and Aaron Courville, Deep Learning (Sequence Modeling Chapter), MIT Press.',
      'TensorFlow Keras Text Generation Guide.'
    ],
    conclusion: 'The LSTM network successfully resolved the vanishing gradient problem inherent in standard RNNs by using internal gating mechanisms, maintaining context across sequential words to achieve accurate next-word prediction.',
    postLabQuestions: [
      {
        question: 'What is sequence modeling in Natural Language Processing?',
        answer: 'Sequence modeling is the task of learning computational relationships and probabilistic distributions across ordered tokens in text where the sequential arrangement of words defines meaning.'
      },
      {
        question: 'Why do traditional RNNs suffer from the vanishing gradient problem?',
        answer: 'In traditional RNNs, backpropagation through time (BPTT) requires continuously multiplying weight matrices across many time steps. When eigenvalues are less than 1, the gradients shrink exponentially to zero, preventing the network from adjusting weights for early tokens.'
      },
      {
        question: 'Explain the roles of the input gate, forget gate, and output gate in an LSTM network.',
        answer: '1. Forget Gate (f_t): Decides what fraction of previous cell memory C_{t-1} to discard. 2. Input Gate (i_t): Decides which incoming candidate values C~_t should update the memory cell. 3. Output Gate (o_t): Decides what filtered portion of updated cell state C_t is emitted as hidden state h_t.'
      },
      {
        question: 'Differentiate between RNN and LSTM.',
        answer: 'Standard RNN has a single simple tanh hidden recurrence layer, leading to vanishing gradients and very short memory spans (~10 steps). LSTM introduces an internal additive Cell State regulated by three multiplicative gates (forget, input, output), enabling it to retain dependencies across hundreds of tokens.'
      },
      {
        question: 'List five NLP applications where LSTM networks are commonly used.',
        answer: '1. Next-word prediction and predictive typing, 2. Machine translation (Seq2Seq), 3. Speech recognition acoustic modeling, 4. Text generation and story continuation, 5. Named entity recognition and sentiment analysis.'
      }
    ],
    quiz: [
      {
        id: 1,
        question: 'Which component in the LSTM cell is responsible for deciding what previous information to discard?',
        options: [
          'Forget Gate (f_t)',
          'Input Gate (i_t)',
          'Output Gate (o_t)',
          'Softmax Output Layer'
        ],
        correctAnswer: 0,
        explanation: 'The forget gate applies a sigmoid function to previous hidden state and current input to output a value between 0 (completely discard) and 1 (completely keep).'
      }
    ]
  }
];
