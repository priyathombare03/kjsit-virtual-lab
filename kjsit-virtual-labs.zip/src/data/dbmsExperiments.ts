import { LabExperiment } from '../types';

export const DBMS_EXPERIMENTS: LabExperiment[] = [
  // =========================================================================
  // Practical 1: ER Model Design
  // =========================================================================
  {
    id: 'er-model-design',
    num: 1,
    subjectId: 'dbms',
    title: 'ER Model Design',
    subtitle: 'Conceptual Data Modeling, Entities, Attributes, Relationships & Cardinality',
    category: 'Conceptual Modeling & ER Diagrams',
    iitReference: 'KJSIT Autonomous Lab Manual (Ms. Sejal Shah, Dept. of AI & Data Science) / MU Autonomous Standards',
    iitLabUrl: 'https://vlab.co.in/broad-division-computer-science-and-engineering',
    aim: 'To understand and design an Entity–Relationship model for a given application.',
    objective: 'To identify entities, attributes, relationships and constraints and represent them using an ER diagram.',
    software: 'draw.io / ERDPlus',
    theory: {
      overview: [
        'The Entity–Relationship (ER) model is a conceptual data model used to represent real‑world objects and their relationships before implementing a database. For example, in a Student Management System, Student and Course are entities connected by an Enrolls relationship.',
        'Entities are represented as rectangles, attributes as ovals and relationships as diamonds. Cardinality specifies how many instances participate, such as one student enrolling in many courses.',
        'ER modeling reduces redundancy, improves clarity and ensures that the logical database design matches real‑world requirements.',
        'Entity classifications: (1) Strong Entity: possess an intrinsic primary key attribute that uniquely distinguishes records independently; (2) Weak Entity: cannot be uniquely identified by its own attributes alone and depends on an identifying owner entity via an identifying relationship (represented by double rectangles and double diamonds).'
      ],
      complexityTable: [
        { parameter: 'Conceptual Mapping Complexity', value: 'O(|E| + |R|) where E is Entities, R is Relationships' },
        { parameter: 'Redundancy Reduction Ratio', value: '65% – 85% elimination of anomalous dependencies' },
        { parameter: 'Initial Normal Form Target', value: 'Directly yields normalized 1NF/2NF relations' },
        { parameter: 'Cardinality Ratios Supported', value: '1:1 (One-to-One), 1:N (One-to-Many), M:N (Many-to-Many)' }
      ],
      keyPoints: [
        'Entities are represented by Rectangles; Weak entities by Double Rectangles.',
        'Attributes are represented by Ovals (Key attributes underlined, Multivalued by Double Ovals, Derived by Dashed Ovals).',
        'Relationships are represented by Diamonds (Identifying relationships by Double Diamonds).',
        'Cardinality constraints designate participation ratios: 1:1, 1:N, or M:N.',
        '1:N relationships embed the primary key of the "1" side as a foreign key into the "N" side table.',
        'M:N relationships require an independent associative/junction table containing foreign keys to both tables.'
      ],
      realWorldApplications: [
        'Precision Smart Agriculture: Farmers, Sensor Nodes, Plots, Telemetry Loggers, Irrigation Stations',
        'University Academic Portals: Students, Faculty, Departments, Courses, Exam Enrollments',
        'Hospital Healthcare Informatics: Patients, Doctors, Wards, Diagnostic Labs, Prescriptions',
        'E-Commerce Portals: Customers, Products, Warehouses, Orders, Shipments'
      ]
    },
    algorithm: [
      'Step 1: Identify all real-world entity sets in the domain specifications (e.g., Student, Department, Course).',
      'Step 2: Classify entities into Strong and Weak entities based on independent key existence.',
      'Step 3: Enumerate attributes for each entity set and mark key attributes (underlined), composite, and multivalued attributes.',
      'Step 4: Identify semantic relationships connecting entities and specify cardinality ratios (1:1, 1:N, M:N).',
      'Step 5: Determine participation constraints (Total participation indicated by double lines, Partial by single lines).',
      'Step 6: Draw the complete ER Diagram using draw.io or ERDPlus according to standard Chen notation.',
      'Step 7: Translate the ER model into relational database tables using standard mapping rules.'
    ],
    procedure: [
      'Launch draw.io, ERDPlus, or open the Virtual Lab ER Modeler simulator tab.',
      'Add rectangular nodes for entities: Department, Student, Course, and Instructor.',
      'Add oval nodes for attributes and connect them to their parent entities.',
      'Add diamond nodes for relationships (e.g., "Belongs_To" between Student and Department; "Enrolls" between Student and Course).',
      'Specify cardinalities (1:N between Department and Student, M:N between Student and Course).',
      'Verify schema constraints and export the diagram for documentation.'
    ],
    code: {
      sql: `-- Relational Schema mapped from University / Smart Agriculture ER Diagram
CREATE TABLE Department (
    dept_id INT PRIMARY KEY,
    dept_name VARCHAR(100) NOT NULL UNIQUE,
    building VARCHAR(50)
);

CREATE TABLE Student (
    student_id INT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    dept_id INT,
    gpa DECIMAL(3, 2) CHECK (gpa BETWEEN 0.0 AND 10.0),
    FOREIGN KEY (dept_id) REFERENCES Department(dept_id)
        ON DELETE SET NULL
);

CREATE TABLE Course (
    course_id VARCHAR(10) PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    credits INT CHECK (credits BETWEEN 1 AND 6),
    dept_id INT,
    FOREIGN KEY (dept_id) REFERENCES Department(dept_id)
        ON DELETE CASCADE
);

-- M:N Junction Table representing Enrolls relationship
CREATE TABLE Enrollment (
    student_id INT,
    course_id VARCHAR(10),
    enroll_date DATE DEFAULT (CURRENT_DATE),
    grade VARCHAR(2),
    PRIMARY KEY (student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES Student(student_id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES Course(course_id) ON DELETE CASCADE
);`,
      python: `# Python SQLite ER Schema Mapping Verification
import sqlite3

conn = sqlite3.connect(':memory:')
cursor = conn.cursor()
cursor.execute("PRAGMA foreign_keys = ON;")

# Execute DDL generated from ER Diagram
cursor.executescript("""
CREATE TABLE Department (
    dept_id INTEGER PRIMARY KEY,
    dept_name TEXT NOT NULL UNIQUE
);
CREATE TABLE Student (
    student_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    dept_id INTEGER,
    FOREIGN KEY (dept_id) REFERENCES Department(dept_id)
);
""")

cursor.execute("INSERT INTO Department VALUES (1, 'Artificial Intelligence & Data Science');")
cursor.execute("INSERT INTO Student VALUES (101, 'Aarav Mehta', 1);")
conn.commit()

cursor.execute("SELECT s.name, d.dept_name FROM Student s JOIN Department d ON s.dept_id = d.dept_id")
print("Mapped Record:", cursor.fetchone())
conn.close()`
    },
    sampleInput: 'Entities: Student (id, name), Course (id, title); Relationship: Enrolls (M:N)',
    expectedOutput: 'Relational tables: Student(id, name), Course(id, title), Enrollment(student_id, course_id)',
    references: [
      'K. J. Somaiya Institute of Technology - DBMS Lab Manual (Ms. Sejal Shah, Dept. of AI & Data Science)',
      'Silberschatz, Korth, Sudarshan, "Database System Concepts", 7th Edition, McGraw-Hill',
      'Peter Chen, "The Entity-Relationship Model—Toward a Unified View of Data", ACM TODS'
    ],
    conclusion: 'The conceptual ER diagram was successfully designed using draw.io/ERDPlus and translated into normalized relational tables respecting primary and foreign key constraints.',
    postLabQuestions: [
      {
        question: 'Define entity, attribute and relationship.',
        answer: 'An Entity is a distinguishable real-world object (e.g., Student, Course). An Attribute is a descriptive property or characteristic of an entity (e.g., student_id, name). A Relationship is an association or semantic connection among two or more entities (e.g., Student "Enrolls" in Course).'
      },
      {
        question: 'Explain strong vs weak entity.',
        answer: 'A Strong Entity has a primary key that uniquely identifies each entity instance independently. A Weak Entity does not have a primary key of its own; it depends on the existence of an identifying (strong) owner entity and is identified via a partial discriminator combined with the owner primary key, represented in ER diagrams with double rectangles.'
      },
      {
        question: 'Why ER modeling is important?',
        answer: 'ER modeling provides an intuitive, high-level graphical abstraction of real-world business requirements. It eliminates schema ambiguity, identifies data dependencies, prevents data redundancy early in the design cycle, and ensures the resulting relational tables match real-world requirements before physical database implementation.'
      }
    ],
    quiz: [
      {
        id: 1,
        question: 'In an ER diagram, how is a weak entity represented?',
        options: ['Single Rectangle', 'Double Rectangle', 'Dashed Oval', 'Diamond'],
        correctAnswer: 1,
        explanation: 'Weak entities are represented by double rectangles in standard Chen notation, and their identifying relationships use double diamonds.'
      },
      {
        id: 2,
        question: 'How is an M:N (Many-to-Many) relationship mapped into relational database tables?',
        options: [
          'By placing foreign key on the first entity table only',
          'By placing foreign key on the second entity table only',
          'By creating a separate junction table containing primary keys of both entities as foreign keys',
          'By merging both entities into a single column'
        ],
        correctAnswer: 2,
        explanation: 'An M:N relationship cannot be embedded in either participating table without multi-valued anomalies; it requires a new junction/associative table.'
      },
      {
        id: 3,
        question: 'What does a dashed oval represent in an ER diagram?',
        options: ['Key attribute', 'Multivalued attribute', 'Derived attribute', 'Composite attribute'],
        correctAnswer: 2,
        explanation: 'Derived attributes (such as Age derived from Date_of_Birth) are represented by dashed ovals.'
      }
    ]
  },

  // =========================================================================
  // Practical 2: Table Constraints
  // =========================================================================
  {
    id: 'table-constraints',
    num: 2,
    subjectId: 'dbms',
    title: 'Table Constraints',
    subtitle: 'Data Validity, Uniqueness, Referential Integrity (PRIMARY KEY, FOREIGN KEY, UNIQUE, NOT NULL, CHECK, DEFAULT)',
    category: 'Data Integrity & Constraints',
    iitReference: 'KJSIT Autonomous Lab Manual (Ms. Sejal Shah, Dept. of AI & Data Science) / MU Autonomous Standards',
    iitLabUrl: 'https://vlab.co.in/broad-division-computer-science-and-engineering',
    aim: 'To understand and apply integrity constraints in relational tables.',
    objective: 'To enforce data validity, uniqueness and referential integrity using SQL constraints.',
    software: 'MySQL',
    theory: {
      overview: [
        'After designing the conceptual model using an ER diagram, the next step is to convert it into relational tables. During this process, constraints are applied to enforce rules on the data stored in the database.',
        'Constraints help maintain data accuracy, validity, and consistency by restricting what kind of values can be inserted into table columns.',
        'Common constraints include PRIMARY KEY, FOREIGN KEY, UNIQUE, NOT NULL, CHECK, and DEFAULT. The PRIMARY KEY uniquely identifies each record in a table, while the FOREIGN KEY establishes a relationship between two tables.',
        'CHECK constraints enforce logical conditions on data values, such as age > 18, and NOT NULL ensures that a column cannot remain empty.',
        'By applying constraints, databases prevent incorrect, duplicate, or inconsistent data from entering the system. This improves reliability, supports referential integrity, and reduces the need for additional validation at the application level.'
      ],
      complexityTable: [
        { parameter: 'Primary Key Lookup', value: 'O(1) with Hash Index / O(\\log N) with B+ Tree' },
        { parameter: 'Foreign Key Verification', value: 'O(\\log M) indexed parent table lookup' },
        { parameter: 'CHECK Constraint Overhead', value: 'O(1) inline CPU boolean evaluation' },
        { parameter: 'Storage Overhead', value: 'Index metadata storage (minimal)' }
      ],
      keyPoints: [
        'PRIMARY KEY: Uniquely identifies each row; automatically enforces UNIQUE and NOT NULL.',
        'FOREIGN KEY: Enforces referential integrity by referencing the primary key of another table.',
        'UNIQUE: Ensures all values in a column are distinct across records.',
        'NOT NULL: Prohibits missing or NULL values in a column.',
        'CHECK: Enforces condition-based domain integrity (e.g., age > 18, salary > 0).',
        'DEFAULT: Automatically assigns a predefined fallback value when no value is provided during insertion.'
      ],
      realWorldApplications: [
        'Banking Systems: Balance CHECK (balance >= 0) preventing illegal overdrafts',
        'Academic Registrations: Student age CHECK (age >= 18) and unique PRN/roll numbers',
        'Healthcare EHR: Patient ID PRIMARY KEY and Doctor ID FOREIGN KEY referential checks',
        'E-Commerce Inventories: Product stock CHECK (stock >= 0) and order status ENUM values'
      ]
    },
    algorithm: [
      'Step 1: Connect to the MySQL database engine using MySQL Command Line Client or Workbench.',
      'Step 2: Create parent tables with PRIMARY KEY and UNIQUE constraints.',
      'Step 3: Create child tables with FOREIGN KEY constraints specifying ON DELETE and ON UPDATE actions.',
      'Step 4: Attach CHECK constraints to numeric columns to restrict data ranges.',
      'Step 5: Test valid INSERT operations that satisfy all integrity constraints.',
      'Step 6: Test invalid INSERT operations (duplicate PK, NULL in NOT NULL column, violation of CHECK condition) and observe the MySQL error codes returned.'
    ],
    procedure: [
      'Open MySQL client or the SQL Playground Simulator in the lab interface.',
      'Execute DDL scripts defining the Departments and Employees tables with all 6 constraints.',
      'Insert valid student records and confirm successful row insertion.',
      'Attempt to insert a student with age < 18 or negative salary to verify CHECK constraint violation.',
      'Attempt to insert a student with an invalid dept_id to verify FOREIGN KEY constraint violation.'
    ],
    code: {
      sql: `-- Practical 2: Demonstrating SQL Table Integrity Constraints in MySQL
DROP TABLE IF EXISTS Student_Records;
DROP TABLE IF EXISTS Department_Info;

-- 1. Parent Table with PRIMARY KEY, UNIQUE, NOT NULL
CREATE TABLE Department_Info (
    dept_id INT PRIMARY KEY,
    dept_name VARCHAR(50) NOT NULL UNIQUE,
    intake_capacity INT DEFAULT 60 CHECK (intake_capacity > 0)
);

-- 2. Child Table with FOREIGN KEY, CHECK, NOT NULL, and DEFAULT
CREATE TABLE Student_Records (
    prn_no BIGINT PRIMARY KEY,
    student_name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    age INT CHECK (age >= 18),
    semester INT DEFAULT 1 CHECK (semester BETWEEN 1 AND 8),
    gpa DECIMAL(3, 2) DEFAULT 0.0 CHECK (gpa BETWEEN 0.0 AND 10.0),
    dept_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_student_dept FOREIGN KEY (dept_id)
        REFERENCES Department_Info(dept_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
);

-- Insert Valid Records into Parent and Child
INSERT INTO Department_Info (dept_id, dept_name, intake_capacity)
VALUES (10, 'AI & Data Science', 120), (20, 'Computer Engineering', 180);

INSERT INTO Student_Records (prn_no, student_name, email, age, semester, gpa, dept_id)
VALUES (16010123001, 'Aarav Mehta', 'aarav.m@somaiya.edu', 19, 4, 9.25, 10);

-- Query to verify active constraints
SELECT * FROM Student_Records;`,
      python: `# Python script testing constraint validation
import sqlite3

conn = sqlite3.connect(':memory:')
conn.execute("PRAGMA foreign_keys = ON;")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE Users (
    user_id INTEGER PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    age INTEGER CHECK(age >= 18)
);
""")

# Test 1: Valid Insert
cursor.execute("INSERT INTO Users VALUES (1, 'user1@somaiya.edu', 20);")
print("Valid insert succeeded.")

# Test 2: Catch CHECK constraint violation
try:
    cursor.execute("INSERT INTO Users VALUES (2, 'user2@somaiya.edu', 15);")
except sqlite3.IntegrityError as e:
    print("Caught expected constraint violation:", e)
conn.close()`
    },
    sampleInput: 'INSERT INTO Student_Records VALUES (16010123002, "Rohan", "rohan@somaiya.edu", 16, 4, 8.5, 10);',
    expectedOutput: 'ERROR 3819 (HY000): Check constraint "Student_Records_chk_1" is violated.',
    references: [
      'KJSIT Autonomous Lab Manual (Ms. Sejal Shah, Dept. of AI & Data Science)',
      'MySQL 8.0 Reference Manual - Constraints & Foreign Keys',
      'Elmasri & Navathe, "Fundamentals of Database Systems", 7th Edition, Pearson'
    ],
    conclusion: 'Integrity constraints (PRIMARY KEY, FOREIGN KEY, UNIQUE, NOT NULL, CHECK, DEFAULT) were successfully applied and verified in MySQL, preventing invalid entries and preserving referential integrity.',
    postLabQuestions: [
      {
        question: 'List different types of constraints supported in SQL.',
        answer: 'SQL supports: (1) PRIMARY KEY (unique identifier, NOT NULL), (2) FOREIGN KEY (referential integrity linking to another table), (3) UNIQUE (prevents duplicate values across rows), (4) NOT NULL (ensures column cannot store NULL), (5) CHECK (enforces a boolean validation expression e.g. age > 18), and (6) DEFAULT (specifies a default value when none is supplied).'
      },
      {
        question: 'Explain how PRIMARY KEY and UNIQUE constraints differ.',
        answer: 'A table can have only ONE PRIMARY KEY, and it strictly forbids NULL values. In contrast, a table can have multiple UNIQUE constraints, and in standard SQL, UNIQUE columns can accept NULL values unless combined with NOT NULL.'
      },
      {
        question: 'What problems may occur if constraints are not used in a database?',
        answer: 'Without constraints: (1) Orphan records occur when foreign keys are deleted, breaking referential integrity; (2) Duplicate records corrupt identity; (3) Invalid data entries (negative salaries, ages < 0) pollute analytics; and (4) The application layer must bear heavy, fragile validation logic.'
      }
    ],
    quiz: [
      {
        id: 1,
        question: 'How many PRIMARY KEY constraints can a single relational table have?',
        options: ['Unlimited', 'Exactly One', 'Up to Two', 'As many as unique columns'],
        correctAnswer: 1,
        explanation: 'A table can have only ONE primary key (which may be simple or composite of multiple columns).'
      },
      {
        id: 2,
        question: 'Which constraint ensures that column values satisfy a specific boolean condition like age >= 18?',
        options: ['NOT NULL', 'DEFAULT', 'CHECK', 'FOREIGN KEY'],
        correctAnswer: 2,
        explanation: 'The CHECK constraint validates each row against a logical predicate before permitting insertion or modification.'
      },
      {
        id: 3,
        question: 'What happens when ON DELETE CASCADE is specified on a FOREIGN KEY?',
        options: [
          'Deletion of parent record is prohibited',
          'Deleting the parent record automatically deletes all referencing child records',
          'Child records have their foreign key set to NULL',
          'Database throws a runtime error'
        ],
        correctAnswer: 1,
        explanation: 'ON DELETE CASCADE propagates parent tuple deletion down to all child tuples referencing that parent key.'
      }
    ]
  },

  // =========================================================================
  // Practical 3: DML Operations
  // =========================================================================
  {
    id: 'dml-operations',
    num: 3,
    subjectId: 'dbms',
    title: 'DML Operations',
    subtitle: 'Data Manipulation Language: INSERT, UPDATE, DELETE, and SELECT in Relational Tables',
    category: 'Data Manipulation (DML)',
    iitReference: 'KJSIT Autonomous Lab Manual (Ms. Sejal Shah, Dept. of AI & Data Science) / MU Autonomous Standards',
    iitLabUrl: 'https://vlab.co.in/broad-division-computer-science-and-engineering',
    aim: 'To understand and perform data manipulation operations on relational tables.',
    objective: 'To insert, update, delete and retrieve records using DML commands.',
    software: 'MySQL',
    theory: {
      overview: [
        'Data Manipulation Language (DML) commands are used to manage the actual data stored in database tables. The most common DML commands are INSERT, UPDATE, DELETE, and SELECT.',
        'These commands allow users to add new records, modify existing records, remove unwanted data, and retrieve stored information.',
        'INSERT adds new rows to a table, UPDATE modifies existing values, and DELETE removes rows based on a condition.',
        'Since these operations directly affect stored data, they must be used carefully, especially in multi‑user environments or production systems.',
        'DML operations are often combined with transaction control to ensure that changes are saved only when correct and complete. This helps maintain database consistency and prevents accidental data loss.'
      ],
      complexityTable: [
        { parameter: 'INSERT Cost', value: 'O(1) append + O(\\log N) per active index' },
        { parameter: 'UPDATE Cost', value: 'O(\\log N) locate target + O(1) in-place rewrite' },
        { parameter: 'DELETE Cost', value: 'O(\\log N) locate + O(1) tombstone/page reclaim' },
        { parameter: 'SELECT Point Lookup', value: 'O(1) hash / O(\\log N) B+ tree seek' }
      ],
      keyPoints: [
        'INSERT: Adds single or multiple new rows into an existing table.',
        'UPDATE: Modifies existing column values in one or more records meeting a WHERE condition.',
        'DELETE: Removes existing rows satisfying a WHERE clause; omitting WHERE deletes all rows.',
        'SELECT: Retrieves specified attributes and records from tables.',
        'Always use WHERE in UPDATE and DELETE statements to avoid inadvertently modifying the entire table.',
        'Transactions (COMMIT / ROLLBACK) provide safety when executing critical DML operations.'
      ],
      realWorldApplications: [
        'Banking Portals: Crediting/debiting account balances via atomic UPDATE operations',
        'Student Admissions: Registering new student batches using bulk INSERT commands',
        'Precision Farming: Updating real-time soil moisture and sensor status telemetry',
        'Inventory Management: Decrementing product stock levels when customer orders are placed'
      ]
    },
    algorithm: [
      'Step 1: Construct the target relational table with appropriate data types and constraints.',
      'Step 2: Perform single-row INSERT statements specifying column lists and values.',
      'Step 3: Perform multi-row bulk INSERT statements to efficiently load batch data.',
      'Step 4: Execute targeted UPDATE statements modifying attribute values with precise WHERE predicates.',
      'Step 5: Perform conditional DELETE operations to remove obsolete or inactive records.',
      'Step 6: Execute SELECT queries after each operation to inspect the mutated table state.'
    ],
    procedure: [
      'Launch the SQL Playground simulator or connect to MySQL.',
      'Create a sample "Course_Registrations" table.',
      'Insert 5 candidate records using INSERT INTO ... VALUES (...).',
      'Update a student GPA or status using UPDATE ... SET ... WHERE ...',
      'Delete a dropped enrollment using DELETE FROM ... WHERE ...',
      'Verify the table contents before and after each DML statement.'
    ],
    code: {
      sql: `-- Practical 3: DML Operations in MySQL
CREATE TABLE Course_Registrations (
    reg_id INT PRIMARY KEY,
    student_name VARCHAR(80) NOT NULL,
    course_code VARCHAR(10) NOT NULL,
    attendance_pct DECIMAL(5, 2) DEFAULT 100.0,
    exam_status VARCHAR(20) DEFAULT 'ELIGIBLE'
);

-- 1. INSERT Operations (Single & Bulk)
INSERT INTO Course_Registrations (reg_id, student_name, course_code, attendance_pct)
VALUES (1, 'Aarav Mehta', 'AIL403', 88.50);

INSERT INTO Course_Registrations (reg_id, student_name, course_code, attendance_pct)
VALUES 
    (2, 'Ananya Iyer', 'AIL403', 94.00),
    (3, 'Rohan Sharma', 'AIL403', 68.00),
    (4, 'Tanvi Joshi', 'AIL403', 72.50);

-- 2. UPDATE Operation with WHERE condition
UPDATE Course_Registrations
SET exam_status = 'DEBARRED'
WHERE attendance_pct < 75.00;

-- 3. DELETE Operation with WHERE condition
DELETE FROM Course_Registrations
WHERE reg_id = 4;

-- 4. SELECT Operation to verify final state
SELECT * FROM Course_Registrations;`,
      python: `# Python script executing DML commands via SQLite
import sqlite3

conn = sqlite3.connect(':memory:')
cur = conn.cursor()

cur.execute("CREATE TABLE Inventory (item_id INT PRIMARY KEY, name TEXT, qty INT);")

# INSERT
cur.execute("INSERT INTO Inventory VALUES (1, 'Sensor Node', 50);")
cur.execute("INSERT INTO Inventory VALUES (2, 'Solenoid Valve', 20);")

# UPDATE
cur.execute("UPDATE Inventory SET qty = qty - 5 WHERE item_id = 1;")

# DELETE
cur.execute("DELETE FROM Inventory WHERE item_id = 2;")

cur.execute("SELECT * FROM Inventory;")
print("Remaining Inventory:", cur.fetchall())
conn.close()`
    },
    sampleInput: 'UPDATE Course_Registrations SET attendance_pct = 95.0 WHERE reg_id = 1;',
    expectedOutput: 'Query OK, 1 row affected. Rows matched: 1  Changed: 1  Warnings: 0',
    references: [
      'KJSIT Autonomous Lab Manual (Ms. Sejal Shah, Dept. of AI & Data Science)',
      'MySQL 8.0 Reference Manual - Data Manipulation Statements',
      'Date, C. J., "An Introduction to Database Systems", 8th Edition'
    ],
    conclusion: 'DML operations (INSERT, UPDATE, DELETE, and SELECT) were successfully executed on relational tables, demonstrating precise row mutations and safety practices with WHERE clauses.',
    postLabQuestions: [
      {
        question: 'Name the three main DML commands.',
        answer: 'The three primary DML commands that modify stored data are INSERT, UPDATE, and DELETE (with SELECT often categorized as Data Query Language / DQL or retrieval DML).'
      },
      {
        question: 'Explain INSERT vs UPDATE.',
        answer: 'INSERT adds brand-new records/tuples into a table. UPDATE modifies existing attribute values within rows that are already present in the table, typically qualified with a WHERE condition to target specific records.'
      },
      {
        question: 'Why is DELETE considered a risky operation in production databases?',
        answer: 'DELETE physically removes records. If executed without an explicit WHERE clause, it wipes out every single record in the table. Furthermore, cascading deletes (ON DELETE CASCADE) can inadvertently wipe related child records across linked tables, leading to irreversible data loss if not encapsulated within safe transactions (ROLLBACK) or backups.'
      }
    ],
    quiz: [
      {
        id: 1,
        question: 'What happens if you execute "DELETE FROM Student;" without a WHERE clause?',
        options: [
          'It throws a syntax error',
          'It deletes only the first row',
          'It deletes all rows in the Student table',
          'It drops the Student table schema'
        ],
        correctAnswer: 2,
        explanation: 'Executing DELETE without a WHERE condition removes all rows from the target table while keeping the table structure intact.'
      },
      {
        id: 2,
        question: 'Which clause in an UPDATE statement specifies the new column values?',
        options: ['WHERE', 'SET', 'MODIFY', 'CHANGE'],
        correctAnswer: 1,
        explanation: 'The SET clause specifies the column and the new value to be assigned: UPDATE table_name SET col = val WHERE condition.'
      },
      {
        id: 3,
        question: 'How do you insert multiple rows in a single SQL statement in MySQL?',
        options: [
          'Separate multiple INSERT statements with commas',
          'Use INSERT INTO table VALUES (row1), (row2), (row3)',
          'Use MULTI INSERT INTO table VALUES (...)',
          'Multiple rows cannot be inserted in a single statement'
        ],
        correctAnswer: 1,
        explanation: 'MySQL supports bulk inserts by providing comma-separated tuples in the VALUES clause: VALUES (1, "A"), (2, "B").'
      }
    ]
  },

  // =========================================================================
  // Practical 4: SELECT Queries
  // =========================================================================
  {
    id: 'select-queries',
    num: 4,
    subjectId: 'dbms',
    title: 'SELECT Queries',
    subtitle: 'Data Retrieval, Filtering, Sorting & Deduplication with WHERE, ORDER BY, DISTINCT, and LIMIT',
    category: 'Query Processing & Filtering',
    iitReference: 'KJSIT Autonomous Lab Manual (Ms. Sejal Shah, Dept. of AI & Data Science) / MU Autonomous Standards',
    iitLabUrl: 'https://vlab.co.in/broad-division-computer-science-and-engineering',
    aim: 'To retrieve and filter data from tables using SELECT queries.',
    objective: 'To use clauses such as WHERE, ORDER BY and DISTINCT for data retrieval.',
    software: 'MySQL',
    theory: {
      overview: [
        'The SELECT statement is used to retrieve data from one or more tables in a database. It can be combined with clauses such as WHERE for filtering, ORDER BY for sorting, DISTINCT for removing duplicates, and LIMIT for restricting the number of rows returned.',
        'Filtering data allows users to retrieve only the information that meets specific criteria, improving performance and readability.',
        'Sorting helps organize the output, while DISTINCT ensures uniqueness in the result set.',
        'Well‑structured SELECT queries enable efficient data analysis and reporting, making them a core component of database interaction and decision‑making processes.'
      ],
      complexityTable: [
        { parameter: 'Full Table Scan Retrieval', value: 'O(N) sequential page reads' },
        { parameter: 'Index Range Scan (WHERE)', value: 'O(\\log N + K) where K is matching rows' },
        { parameter: 'Sorting Complexity (ORDER BY)', value: 'O(N \\log N) external filesort / O(1) indexed order' },
        { parameter: 'Deduplication (DISTINCT)', value: 'O(N) hash aggregation / O(N \\log N) sort' }
      ],
      keyPoints: [
        'SELECT specifies columns/expressions to display in the result relation.',
        'WHERE filters rows based on conditional predicates before projection.',
        'DISTINCT removes duplicate output tuples across selected columns.',
        'ORDER BY sorts results ascending (ASC, default) or descending (DESC).',
        'LIMIT restricts the maximum number of rows returned, useful for pagination.',
        'Comparison operators: =, !=, <, >, <=, >=, BETWEEN ... AND ..., IN (...), LIKE (% and _).'
      ],
      realWorldApplications: [
        'E-Commerce Portals: Filtering products by price range, rating, and category with pagination',
        'Smart Agriculture: Filtering sensor nodes reporting soil moisture below 30% ordered by severity',
        'Banking: Retrieving the top 10 most recent transactions for a customer statement',
        'Academic Portals: Listing distinct departments and generating semester merit rank lists'
      ]
    },
    algorithm: [
      'Step 1: Write a basic projection query: SELECT column1, column2 FROM table_name.',
      'Step 2: Add conditional filtering using WHERE with comparison and logical operators (AND, OR, NOT).',
      'Step 3: Use pattern matching with LIKE and wildcards (% for zero-or-more characters, _ for single character).',
      'Step 4: Use DISTINCT to eliminate duplicate values across categorical columns.',
      'Step 5: Apply ORDER BY on one or more columns in ASC or DESC sequence.',
      'Step 6: Restrict result set size using LIMIT and OFFSET for efficient pagination.'
    ],
    procedure: [
      'Open the SQL Playground simulator or connect to MySQL.',
      'Inspect the sample Student and Department tables.',
      'Execute a query filtering students with GPA >= 8.5 in Department 10.',
      'Sort students by GPA descending: ORDER BY gpa DESC.',
      'Execute a query using SELECT DISTINCT dept_id to view active departments.',
      'Combine clauses into a single comprehensive reporting query.'
    ],
    code: {
      sql: `-- Practical 4: Advanced SELECT Queries in MySQL
-- 1. Simple Projection & Filtering with WHERE
SELECT student_id, name, gpa 
FROM Student 
WHERE gpa >= 8.50 AND dept_id = 10;

-- 2. Range Filtering using BETWEEN ... AND ...
SELECT student_id, name, year, gpa 
FROM Student 
WHERE gpa BETWEEN 8.0 AND 9.5;

-- 3. Pattern Matching using LIKE
SELECT student_id, name, email 
FROM Student 
WHERE name LIKE 'A%' OR email LIKE '%@somaiya.edu';

-- 4. Deduplication using DISTINCT
SELECT DISTINCT dept_id, year 
FROM Student 
ORDER BY dept_id ASC, year ASC;

-- 5. Sorting using ORDER BY and Row Limiting with LIMIT
SELECT student_id, name, gpa 
FROM Student 
ORDER BY gpa DESC, name ASC 
LIMIT 5;`,
      python: `# Python SQLite SELECT query filtering and sorting
import sqlite3

conn = sqlite3.connect(':memory:')
cur = conn.cursor()

cur.execute("CREATE TABLE Telemetry (id INT, zone TEXT, temp REAL);")
cur.executemany("INSERT INTO Telemetry VALUES (?, ?, ?);", [
    (1, 'Zone_A', 36.5),
    (2, 'Zone_B', 42.1),
    (3, 'Zone_A', 38.0),
    (4, 'Zone_C', 44.8),
    (5, 'Zone_B', 39.5)
])

# Query: Filter zones with temp > 40.0 ordered by temperature descending
cur.execute("SELECT zone, temp FROM Telemetry WHERE temp > 40.0 ORDER BY temp DESC;")
print("Heatwave Alerts:", cur.fetchall())
conn.close()`
    },
    sampleInput: 'SELECT name, gpa FROM Student WHERE gpa > 8.5 ORDER BY gpa DESC LIMIT 3;',
    expectedOutput: '3 rows returned: Aditya Sharma (9.4), Sneha Rao (9.1), Karan Mehra (9.0)',
    references: [
      'KJSIT Autonomous Lab Manual (Ms. Sejal Shah, Dept. of AI & Data Science)',
      'MySQL 8.0 Reference Manual - SELECT Statement',
      'Silberschatz, Korth, Sudarshan, "Database System Concepts", 7th Edition'
    ],
    conclusion: 'SELECT queries with WHERE filtering, ORDER BY sorting, DISTINCT deduplication, and LIMIT constraints were successfully evaluated and analyzed for database query optimization.',
    postLabQuestions: [
      {
        question: 'List SELECT clauses.',
        answer: 'The principal SELECT clauses in standard SQL conceptual order of execution are: FROM, WHERE, GROUP BY, HAVING, SELECT, DISTINCT, ORDER BY, and LIMIT/OFFSET.'
      },
      {
        question: 'Explain WHERE clause.',
        answer: 'The WHERE clause specifies search conditions used to filter rows before any groupings or projections are computed. Only rows that evaluate to TRUE for the boolean condition (using operators like =, <>, >, <, BETWEEN, LIKE, IN) are retained in the pipeline.'
      },
      {
        question: 'How filtering affects performance?',
        answer: 'Early filtering with a selective WHERE clause drastically reduces the volume of rows processed in memory, decreases I/O disk reads, leverages B-Tree indexes for fast point or range lookups (avoiding costly full table scans), and accelerates overall query response times.'
      }
    ],
    quiz: [
      {
        id: 1,
        question: 'In which order are SQL clauses logically executed by the query engine?',
        options: [
          'SELECT -> FROM -> WHERE -> ORDER BY',
          'FROM -> WHERE -> GROUP BY -> HAVING -> SELECT -> ORDER BY',
          'WHERE -> FROM -> SELECT -> LIMIT',
          'ORDER BY -> SELECT -> FROM -> WHERE'
        ],
        correctAnswer: 1,
        explanation: 'FROM determines source tables, WHERE filters rows, GROUP BY groups, HAVING filters groups, SELECT projects columns, and ORDER BY sorts the final output.'
      },
      {
        id: 2,
        question: 'What is the wildcard character in SQL LIKE to match any sequence of zero or more characters?',
        options: ['_', '%', '*', '?'],
        correctAnswer: 1,
        explanation: 'The percent sign (%) matches zero or more characters, while the underscore (_) matches exactly one character.'
      },
      {
        id: 3,
        question: 'What does the DISTINCT keyword do in a SELECT query?',
        options: [
          'Sorts rows alphabetically',
          'Eliminates duplicate rows from the query output',
          'Enforces unique index constraint on the table',
          'Filters out NULL values only'
        ],
        correctAnswer: 1,
        explanation: 'SELECT DISTINCT evaluates the projected columns and discards identical duplicate rows from the output result set.'
      }
    ]
  },

  // =========================================================================
  // Practical 5: Aggregate Functions
  // =========================================================================
  {
    id: 'aggregate-functions',
    num: 5,
    subjectId: 'dbms',
    title: 'Aggregate Functions',
    subtitle: 'Data Summarization with COUNT, SUM, AVG, MIN, MAX, GROUP BY, and HAVING Clauses',
    category: 'Aggregation & Grouping',
    iitReference: 'KJSIT Autonomous Lab Manual (Ms. Sejal Shah, Dept. of AI & Data Science) / MU Autonomous Standards',
    iitLabUrl: 'https://vlab.co.in/broad-division-computer-science-and-engineering',
    aim: 'To summarize data using SQL aggregate functions.',
    objective: 'To use COUNT, SUM, AVG, MIN, MAX with GROUP BY and HAVING.',
    software: 'MySQL',
    theory: {
      overview: [
        'Aggregate functions perform calculations on multiple rows of data and return a single summarized value. Common aggregate functions include COUNT, SUM, AVG, MIN, and MAX. These functions are widely used in reporting, analytics, and statistical analysis.',
        'The GROUP BY clause is used to divide rows into groups based on a common attribute so that aggregate functions can be applied to each group separately.',
        'The HAVING clause filters groups after aggregation, whereas WHERE filters rows before grouping.',
        'This combination enables meaningful data summarization, such as total sales per region or average marks per subject, supporting informed decision‑making.',
        'GROUP BY groups records, such as calculating average marks per subject. HAVING filters grouped results, such as showing only subjects with more than 10 students.'
      ],
      complexityTable: [
        { parameter: 'Aggregation Scan', value: 'O(N) sequential stream aggregation' },
        { parameter: 'GROUP BY Hash Bucketing', value: 'O(N) with in-memory hash table' },
        { parameter: 'GROUP BY Sort Aggregation', value: 'O(N \\log N) when sorting required' },
        { parameter: 'HAVING Filter Cost', value: 'O(G) where G is number of distinct groups (G << N)' }
      ],
      keyPoints: [
        'COUNT(*): Counts total rows including NULLs; COUNT(col) counts non-NULL entries.',
        'SUM(col): Computes the arithmetic sum of numeric values.',
        'AVG(col): Computes the arithmetic mean, ignoring NULL entries.',
        'MIN(col) and MAX(col): Determine minimum and maximum values respectively.',
        'GROUP BY: Groups rows sharing identical values across grouped columns.',
        'HAVING: Filters aggregated groups based on aggregate conditions (e.g., HAVING COUNT(*) > 5).'
      ],
      realWorldApplications: [
        'Academic Portals: Computing department-wise average GPA and total student enrollments',
        'Smart Agriculture Telemetry: Computing daily average, maximum, and minimum soil temperatures per zone',
        'Banking Systems: Summing monthly transaction volumes per account type',
        'Retail Dashboards: Summarizing total sales revenue grouped by product category'
      ]
    },
    algorithm: [
      'Step 1: Compute scalar aggregates across the entire table (e.g., SELECT AVG(gpa), COUNT(*) FROM Student).',
      'Step 2: Add GROUP BY clause to categorize rows by department, year, or region.',
      'Step 3: Include the grouped column in the SELECT list alongside aggregate functions.',
      'Step 4: Use WHERE to filter raw rows before grouping is performed.',
      'Step 5: Add HAVING clause to filter summary groups based on aggregate calculation criteria.',
      'Step 6: Order the aggregated output using ORDER BY with aggregate aliases or column names.'
    ],
    procedure: [
      'Open the SQL Playground simulator or connect to MySQL.',
      'Run queries calculating COUNT, AVG, MIN, and MAX across all students.',
      'Group students by department ID: GROUP BY dept_id.',
      'Filter departments having average GPA >= 8.5 using the HAVING clause.',
      'Analyze the distinction between WHERE (pre-group) and HAVING (post-group).'
    ],
    code: {
      sql: `-- Practical 5: Aggregate Functions with GROUP BY & HAVING in MySQL
-- 1. Table-wide Scalar Aggregates
SELECT 
    COUNT(*) AS total_students,
    AVG(gpa) AS overall_avg_gpa,
    MIN(gpa) AS lowest_gpa,
    MAX(gpa) AS highest_gpa
FROM Student;

-- 2. Department-wise Aggregation with GROUP BY
SELECT 
    dept_id,
    COUNT(*) AS student_count,
    ROUND(AVG(gpa), 2) AS avg_gpa,
    MIN(gpa) AS min_gpa,
    MAX(gpa) AS max_gpa
FROM Student
GROUP BY dept_id;

-- 3. Filtering Groups using HAVING (e.g. departments with avg GPA >= 8.5)
SELECT 
    dept_id,
    COUNT(*) AS student_count,
    ROUND(AVG(gpa), 2) AS avg_gpa
FROM Student
GROUP BY dept_id
HAVING AVG(gpa) >= 8.50
ORDER BY avg_gpa DESC;

-- 4. Combining WHERE, GROUP BY, and HAVING
SELECT 
    dept_id,
    COUNT(*) AS senior_count,
    ROUND(AVG(gpa), 2) AS senior_avg_gpa
FROM Student
WHERE year >= 3             -- Row filter before grouping
GROUP BY dept_id            -- Grouping
HAVING COUNT(*) >= 2        -- Group filter after aggregation
ORDER BY senior_avg_gpa DESC;`,
      python: `# Python SQLite aggregation and grouping
import sqlite3

conn = sqlite3.connect(':memory:')
cur = conn.cursor()

cur.execute("CREATE TABLE Crops (zone TEXT, crop TEXT, yield_kg REAL);")
cur.executemany("INSERT INTO Crops VALUES (?, ?, ?);", [
    ('North', 'Wheat', 1200),
    ('North', 'Rice', 1800),
    ('South', 'Cotton', 950),
    ('North', 'Wheat', 1400),
    ('South', 'Sugarcane', 3200),
    ('South', 'Cotton', 1100)
])

# Aggregate: Average and Total yield per zone having total yield > 2000kg
cur.execute("""
SELECT zone, COUNT(*) AS count, SUM(yield_kg) AS total_yield, AVG(yield_kg) AS avg_yield
FROM Crops
GROUP BY zone
HAVING SUM(yield_kg) > 2000;
""")
for row in cur.fetchall():
    print(f"Zone {row[0]}: Count={row[1]}, Total={row[2]}kg, Avg={row[3]:.1f}kg")
conn.close()`
    },
    sampleInput: 'SELECT dept_id, COUNT(*), AVG(gpa) FROM Student GROUP BY dept_id HAVING COUNT(*) > 1;',
    expectedOutput: 'Dept 10: Count=3, Avg=8.40; Dept 20: Count=2, Avg=8.15',
    references: [
      'KJSIT Autonomous Lab Manual (Ms. Sejal Shah, Dept. of AI & Data Science)',
      'MySQL 8.0 Reference Manual - Aggregate Functions & GROUP BY',
      'Ramakrishnan & Gehrke, "Database Management Systems", 3rd Edition'
    ],
    conclusion: 'SQL aggregate functions (COUNT, SUM, AVG, MIN, MAX) combined with GROUP BY and HAVING clauses were successfully executed to analyze multi-row summaries and group thresholds.',
    postLabQuestions: [
      {
        question: 'List aggregate functions.',
        answer: 'The five core SQL aggregate functions are: (1) COUNT() - counts number of rows/values; (2) SUM() - calculates total sum of numeric column; (3) AVG() - computes arithmetic mean; (4) MIN() - identifies minimum value; and (5) MAX() - identifies maximum value.'
      },
      {
        question: 'Explain WHERE vs HAVING.',
        answer: 'WHERE filters individual rows BEFORE aggregation and cannot contain aggregate functions (e.g. WHERE salary > 50000). HAVING filters grouped summary rows AFTER aggregation and evaluates aggregate expressions (e.g. HAVING COUNT(student_id) > 10 or HAVING AVG(gpa) >= 8.5).'
      },
      {
        question: 'Why GROUP BY is needed?',
        answer: 'GROUP BY is essential when you need summary statistics broken down across categories (e.g., average salary per department, total sales per district). Without GROUP BY, aggregate functions collapse all table rows into a single single-value scalar result.'
      }
    ],
    quiz: [
      {
        id: 1,
        question: 'What is the primary difference between WHERE and HAVING in SQL?',
        options: [
          'WHERE operates on columns; HAVING operates on tables',
          'WHERE filters rows before grouping; HAVING filters groups after aggregation',
          'WHERE is used for numbers; HAVING is used for text',
          'There is no difference; they are interchangeable'
        ],
        correctAnswer: 1,
        explanation: 'WHERE filters raw rows prior to aggregation, while HAVING filters the summary groups produced after GROUP BY aggregation.'
      },
      {
        id: 2,
        question: 'What is the return value of COUNT(column_name) when a column contains NULL values?',
        options: [
          'It includes NULL values in the count',
          'It ignores NULL values and counts only non-NULL entries',
          'It throws a runtime error',
          'It returns 0'
        ],
        correctAnswer: 1,
        explanation: 'COUNT(column_name) counts only non-NULL rows for that column. Only COUNT(*) counts all rows regardless of NULLs.'
      },
      {
        id: 3,
        question: 'Can you use aggregate functions directly in a WHERE clause (e.g., WHERE AVG(marks) > 75)?',
        options: [
          'Yes, in all standard SQL engines',
          'No, aggregate functions are not permitted in WHERE; use HAVING instead',
          'Yes, but only if preceded by GROUP BY',
          'Only with MySQL'
        ],
        correctAnswer: 1,
        explanation: 'Aggregate functions cannot be used in a WHERE clause because WHERE evaluates before group aggregations are calculated; HAVING must be used.'
      }
    ]
  },

  // =========================================================================
  // Practical 6: Joins and Subqueries
  // =========================================================================
  {
    id: 'joins-and-subqueries',
    num: 6,
    subjectId: 'dbms',
    title: 'Joins and Subqueries',
    subtitle: 'Multi-Table Data Retrieval: INNER, LEFT, RIGHT, FULL Joins and Nested Subqueries',
    category: 'Joins & Nested Subqueries',
    iitReference: 'KJSIT Autonomous Lab Manual (Ms. Sejal Shah, Dept. of AI & Data Science) / MU Autonomous Standards',
    iitLabUrl: 'https://vlab.co.in/broad-division-computer-science-and-engineering',
    aim: 'To retrieve related data from multiple tables.',
    objective: 'To apply joins and subqueries for complex data retrieval.',
    software: 'MySQL',
    theory: {
      overview: [
        'In relational databases, data is distributed across multiple tables to reduce redundancy and improve consistency. Joins are used to combine related data from multiple tables based on common attributes such as foreign keys.',
        'Types of joins include INNER JOIN, LEFT JOIN, RIGHT JOIN, and FULL JOIN, each determining how unmatched rows are handled.',
        'Subqueries are nested queries placed inside another SQL statement and are useful when results of one query are needed for another.',
        'Choosing between joins and subqueries depends on the problem context, data size, and performance considerations.',
        'Joins combine tables using common attributes, such as linking Student and Course tables. INNER JOIN returns matching rows, while LEFT JOIN returns all left table rows. Subqueries are nested queries used for comparisons, such as finding students scoring above average.'
      ],
      complexityTable: [
        { parameter: 'Nested Loop Join', value: 'O(|R| \\times |S|) worst case without index' },
        { parameter: 'Indexed Nested Loop Join', value: 'O(|R| \\log |S|) with B+ Tree on join key' },
        { parameter: 'Hash Join Complexity', value: 'O(|R| + |S|) in-memory hash table matching' },
        { parameter: 'Correlated Subquery', value: 'O(|Outer| \\times Cost(Inner))' }
      ],
      keyPoints: [
        'INNER JOIN: Returns records that have matching values in both participating tables.',
        'LEFT JOIN: Returns all rows from the left table, plus matched rows from the right table (NULL if no match).',
        'RIGHT JOIN: Returns all rows from the right table, plus matched rows from the left table.',
        'FULL OUTER JOIN: Returns all rows when there is a match in either left or right table (simulated in MySQL via UNION).',
        'Subquery: A query nested within a WHERE, FROM, or SELECT clause.',
        'Correlated Subquery: References columns from the outer query and executes once for each outer row.'
      ],
      realWorldApplications: [
        'Academic Portals: Joining Student, Department, and Course tables for grade transcripts',
        'Smart Agriculture: Joining Sensor_Nodes, Gateway_Stations, and Soil_Telemetry tables',
        'E-Commerce Portals: Correlated subquery identifying customers whose purchases exceed the average order value',
        'Human Resources: Self-joins mapping employee-to-manager hierarchies'
      ]
    },
    algorithm: [
      'Step 1: Identify foreign key relationships connecting participating tables.',
      'Step 2: Construct INNER JOIN query with ON predicate matching primary/foreign keys.',
      'Step 3: Construct LEFT OUTER JOIN query to include entities that have no related records in the child table.',
      'Step 4: Formulate non-correlated subquery returning a scalar value for conditional filtering.',
      'Step 5: Formulate subqueries using IN, NOT IN, and EXISTS / NOT EXISTS operators.',
      'Step 6: Execute EXPLAIN query plan to compare execution cost between Joins and Subqueries.'
    ],
    procedure: [
      'Open the Relational Joins Simulator tab in the laboratory view.',
      'Select Department and Student tables.',
      'Execute INNER JOIN to observe students with assigned departments.',
      'Execute LEFT JOIN to see all departments, including those with zero enrolled students.',
      'Write a subquery finding all students scoring higher than the department average GPA.',
      'Compare performance between join-based and subquery-based expressions.'
    ],
    code: {
      sql: `-- Practical 6: Joins and Subqueries in MySQL
-- 1. INNER JOIN (Students and their Departments)
SELECT 
    s.student_id,
    s.name AS student_name,
    s.gpa,
    d.dept_name,
    d.building
FROM Student s
INNER JOIN Department d ON s.dept_id = d.dept_id;

-- 2. LEFT OUTER JOIN (All Departments, including those with 0 students)
SELECT 
    d.dept_id,
    d.dept_name,
    COUNT(s.student_id) AS enrolled_students
FROM Department d
LEFT JOIN Student s ON d.dept_id = s.dept_id
GROUP BY d.dept_id, d.dept_name;

-- 3. Non-Correlated Subquery: Students with GPA above University Average
SELECT student_id, name, gpa 
FROM Student 
WHERE gpa > (SELECT AVG(gpa) FROM Student);

-- 4. Correlated Subquery: Students with GPA above their own Department Average
SELECT s.student_id, s.name, s.dept_id, s.gpa
FROM Student s
WHERE s.gpa > (
    SELECT AVG(s2.gpa)
    FROM Student s2
    WHERE s2.dept_id = s.dept_id
);

-- 5. Subquery with EXISTS
SELECT d.dept_name
FROM Department d
WHERE EXISTS (
    SELECT 1 FROM Student s 
    WHERE s.dept_id = d.dept_id AND s.gpa >= 9.0
);`,
      python: `# Python SQLite Joins and Subqueries
import sqlite3

conn = sqlite3.connect(':memory:')
cur = conn.cursor()

cur.executescript("""
CREATE TABLE Depts (id INT PRIMARY KEY, name TEXT);
CREATE TABLE Emps (id INT PRIMARY KEY, name TEXT, dept_id INT, sal REAL);

INSERT INTO Depts VALUES (1, 'R&D'), (2, 'Marketing'), (3, 'HR');
INSERT INTO Emps VALUES (101, 'Aarav', 1, 90000), (102, 'Priya', 1, 95000), (103, 'Rohan', 2, 70000);
""")

# Join
cur.execute("""
SELECT e.name, d.name, e.sal 
FROM Emps e 
JOIN Depts d ON e.dept_id = d.id;
""")
print("Joined Records:", cur.fetchall())

# Subquery
cur.execute("SELECT name, sal FROM Emps WHERE sal > (SELECT AVG(sal) FROM Emps);")
print("Above-average earners:", cur.fetchall())
conn.close()`
    },
    sampleInput: 'SELECT s.name, d.dept_name FROM Student s JOIN Department d ON s.dept_id = d.dept_id;',
    expectedOutput: 'Joined tuples with matching dept_ids; unmatched rows omitted in INNER JOIN',
    references: [
      'KJSIT Autonomous Lab Manual (Ms. Sejal Shah, Dept. of AI & Data Science)',
      'MySQL 8.0 Reference Manual - JOIN Clauses & Subqueries',
      'Garcia-Molina, Ullman, Widom, "Database Systems: The Complete Book", 2nd Edition'
    ],
    conclusion: 'Multi-table data retrieval using INNER JOIN, LEFT OUTER JOIN, non-correlated subqueries, and correlated subqueries was successfully implemented and evaluated.',
    postLabQuestions: [
      {
        question: 'List join types.',
        answer: 'The main join types in relational databases are: (1) INNER JOIN (returns rows with matching values in both tables), (2) LEFT OUTER JOIN (returns all left rows + matching right rows), (3) RIGHT OUTER JOIN (returns all right rows + matching left rows), (4) FULL OUTER JOIN (returns all rows from both tables, with NULLs where un-matched), (5) CROSS JOIN (Cartesian product), and (6) SELF JOIN (table joined to itself).'
      },
      {
        question: 'Explain INNER vs LEFT join.',
        answer: 'INNER JOIN discards unmatched rows from both tables and only returns records where the join predicate evaluates to TRUE. LEFT JOIN retains ALL records from the left table; if there is no corresponding match in the right table, columns from the right table are padded with NULL values.'
      },
      {
        question: 'When prefer subquery?',
        answer: 'Subqueries are preferred when testing for set membership (IN, NOT IN), existential checks (EXISTS, NOT EXISTS), comparing against a scalar computed threshold (e.g., salary > (SELECT AVG(salary) FROM emp)), or when logically separating complex sub-computations for readability.'
      }
    ],
    quiz: [
      {
        id: 1,
        question: 'What is returned by a LEFT JOIN for rows in the left table that have NO match in the right table?',
        options: [
          'They are omitted from the result',
          'They are included with NULL values for right table columns',
          'They cause a constraint violation error',
          'They are duplicated'
        ],
        correctAnswer: 1,
        explanation: 'LEFT JOIN keeps all left table rows; when no matching record exists in the right table, all right table attributes are populated with NULL.'
      },
      {
        id: 2,
        question: 'What is a correlated subquery in SQL?',
        options: [
          'A subquery that executes only once before the main query',
          'A subquery that references a column from the outer query and executes once for each outer row',
          'A subquery that cannot contain a WHERE clause',
          'A query joined to itself'
        ],
        correctAnswer: 1,
        explanation: 'A correlated subquery depends on values from the outer query tuple and must be re-evaluated for each candidate row processed by the outer query.'
      },
      {
        id: 3,
        question: 'How can a FULL OUTER JOIN be simulated in MySQL (which lacks native FULL JOIN syntax)?',
        options: [
          'Using CROSS JOIN',
          'Combining a LEFT JOIN and a RIGHT JOIN using UNION',
          'Using an INNER JOIN with WHERE NULL',
          'Using a subquery with IN'
        ],
        correctAnswer: 1,
        explanation: 'In MySQL, FULL OUTER JOIN is implemented by taking the UNION of a LEFT JOIN and a RIGHT JOIN.'
      }
    ]
  },

  // =========================================================================
  // Practical 7: Views and Indexes
  // =========================================================================
  {
    id: 'views-and-indexes',
    num: 7,
    subjectId: 'dbms',
    title: 'Views and Indexes',
    subtitle: 'Virtual Tables, Query Simplification, Data Security & B-Tree Index Search Optimization',
    category: 'Views & Index Optimization',
    iitReference: 'KJSIT Autonomous Lab Manual (Ms. Sejal Shah, Dept. of AI & Data Science) / MU Autonomous Standards',
    iitLabUrl: 'https://vlab.co.in/broad-division-computer-science-and-engineering',
    aim: 'To simplify queries and improve data retrieval performance.',
    objective: 'To create and manage views and indexes.',
    software: 'MySQL',
    theory: {
      overview: [
        'A view is a virtual table created using a SELECT query that does not store data itself but displays data from one or more tables. Views simplify complex queries, improve readability, and provide controlled access to sensitive data.',
        'Indexes are data structures used to improve the speed of data retrieval operations. They work similarly to book indexes by allowing faster access to rows without scanning the entire table.',
        'While indexes improve performance for read operations, they slightly increase storage and slow down write operations, so they must be used judiciously.'
      ],
      complexityTable: [
        { parameter: 'Full Table Scan without Index', value: 'O(N) disk I/O reads' },
        { parameter: 'B+ Tree Index Search', value: 'O(\\log_B N) node page accesses' },
        { parameter: 'Index Insertion Overhead', value: 'O(\\log_B N) node split & rebalance' },
        { parameter: 'View Execution Overhead', value: 'O(1) macro query rewrite expansion' }
      ],
      keyPoints: [
        'View: Virtual table defined by a stored SELECT query; does not consume physical disk space for data.',
        'Security & Abstraction: Views hide sensitive columns (e.g. passwords, salary) from unauthorized users.',
        'Index: Physical data structure (B+ Tree) that stores sorted keys with record pointers.',
        'Clustered Index: Determines physical ordering of table rows on disk (Primary Key in MySQL InnoDB).',
        'Non-Clustered / Secondary Index: Separate structure pointing to clustered index primary key values.',
        'Trade-off: Indexes accelerate SELECT reads but add maintenance cost on INSERT, UPDATE, and DELETE.'
      ],
      realWorldApplications: [
        'Banking Systems: Customer balance view hiding internal account hashes and KYC documents',
        'Academic Portals: Student view exposing only public merit list columns, masking phone and fees',
        'IoT Telemetry: B+ Tree secondary index on (sensor_id, timestamp) for rapid range telemetry queries',
        'E-Commerce Portals: Secondary indexes on product category and price for instant sub-second search'
      ]
    },
    algorithm: [
      'Step 1: Identify complex or sensitive queries suitable for abstraction into a VIEW.',
      'Step 2: Create view using: CREATE VIEW view_name AS SELECT ... FROM ... WHERE ...',
      'Step 3: Query the view just like a base relational table: SELECT * FROM view_name;',
      'Step 4: Identify search-heavy query filters and create a B-Tree index using: CREATE INDEX idx_name ON table(col);',
      'Step 5: Run EXPLAIN SELECT ... to analyze query execution plan (type=ALL vs type=ref/range).',
      'Step 6: Measure performance gains and evaluate disk storage vs write overhead trade-offs.'
    ],
    procedure: [
      'Open the B+ Tree Simulator / SQL Playground in the virtual laboratory interface.',
      'Create a view "Department_Honors" filtering students with GPA >= 9.0.',
      'Query the view and verify that underlying base table changes reflect immediately in the view.',
      'Create a secondary index on the "email" and "gpa" columns.',
      'Use the EXPLAIN statement to verify that MySQL switches from Full Table Scan to Index Range Scan.'
    ],
    code: {
      sql: `-- Practical 7: Views and Indexes in MySQL
-- 1. Create a Secure Virtual View
CREATE OR REPLACE VIEW High_Achievers_View AS
SELECT 
    s.student_id,
    s.name,
    s.gpa,
    d.dept_name
FROM Student s
JOIN Department d ON s.dept_id = d.dept_id
WHERE s.gpa >= 9.00
WITH CHECK OPTION;

-- Query the View like a standard table
SELECT * FROM High_Achievers_View;

-- 2. Create B-Tree Secondary Index for Query Acceleration
CREATE INDEX idx_student_gpa ON Student(gpa);
CREATE INDEX idx_student_dept_year ON Student(dept_id, year);

-- 3. Verify Query Execution Plan with EXPLAIN
EXPLAIN SELECT student_id, name FROM Student WHERE gpa >= 9.0;
-- The EXPLAIN output will demonstrate: key = idx_student_gpa, type = range (Index seek!)

-- 4. Dropping an Index or View
-- DROP INDEX idx_student_gpa ON Student;
-- DROP VIEW High_Achievers_View;`,
      python: `# Python SQLite View and Index Demonstration
import sqlite3

conn = sqlite3.connect(':memory:')
cur = conn.cursor()

cur.execute("CREATE TABLE SensorData (id INT, sensor_type TEXT, reading REAL);")
cur.executemany("INSERT INTO SensorData VALUES (?, ?, ?);", [
    (1, 'Moisture', 32.5), (2, 'Temperature', 39.1), (3, 'Moisture', 18.0)
])

# Create View
cur.execute("CREATE VIEW LowMoistureAlerts AS SELECT * FROM SensorData WHERE sensor_type='Moisture' AND reading < 25.0;")
cur.execute("SELECT * FROM LowMoistureAlerts;")
print("View Alert Output:", cur.fetchall())

# Create Index
cur.execute("CREATE INDEX idx_sensor_reading ON SensorData(sensor_type, reading);")
print("B-Tree Index created successfully.")
conn.close()`
    },
    sampleInput: 'EXPLAIN SELECT * FROM Student WHERE gpa >= 9.0;',
    expectedOutput: 'type: range, key: idx_student_gpa, rows: 2 (Index Seek instead of Full Scan)',
    references: [
      'KJSIT Autonomous Lab Manual (Ms. Sejal Shah, Dept. of AI & Data Science)',
      'MySQL 8.0 Reference Manual - Optimization & Indexes',
      'Silberschatz, Korth, Sudarshan, "Database System Concepts", 7th Edition'
    ],
    conclusion: 'Virtual tables (Views) were created to encapsulate complex multi-table queries and enforce security boundaries. B-Tree indexes were constructed and verified via EXPLAIN query execution plans.',
    postLabQuestions: [
      {
        question: 'Define view and index.',
        answer: 'A View is a stored virtual relation defined by an underlying SQL SELECT query that dynamically presents filtered/joined data without duplicating physical storage. An Index is an auxiliary balanced physical data structure (typically a B+ Tree or Hash table) that maintains sorted column references to enable sub-linear O(log N) lookup and retrieval times.'
      },
      {
        question: 'How indexes improve performance?',
        answer: 'Indexes eliminate the need for an expensive O(N) Full Table Scan by allowing the database engine to traverse a balanced tree to locate the exact page/row pointer directly in O(log N) disk reads, accelerating WHERE lookups, ORDER BY sorts, and JOIN operations.'
      },
      {
        question: 'Trade-offs of indexes?',
        answer: 'While indexes dramatically accelerate SELECT read queries, they consume additional physical disk storage and introduce computational overhead on write operations (INSERT, UPDATE, DELETE), because the database must rebalance and update the B+ Tree index structures on every mutation.'
      }
    ],
    quiz: [
      {
        id: 1,
        question: 'Does a standard relational SQL View consume physical disk space for storing table data rows?',
        options: [
          'Yes, equal to the base table',
          'No, it only stores the SQL query definition in the data dictionary',
          'Yes, but compressed to 50%',
          'Only in MySQL'
        ],
        correctAnswer: 1,
        explanation: 'A standard View is virtual and stores only the query definition; it is executed dynamically upon invocation.'
      },
      {
        id: 2,
        question: 'What is the primary tree data structure utilized for secondary indexing in relational databases like MySQL InnoDB?',
        options: ['Binary Search Tree', 'B+ Tree', 'AVL Tree', 'Red-Black Tree'],
        correctAnswer: 1,
        explanation: 'Relational databases use B+ Trees because high branching fan-out minimizes disk I/O reads, and sequential leaf node pointers allow rapid range scans.'
      },
      {
        id: 3,
        question: 'What is a major trade-off of adding too many indexes to a table?',
        options: [
          'SELECT queries become slower',
          'INSERT, UPDATE, and DELETE operations become slower due to index maintenance',
          'Primary keys stop functioning',
          'Database cannot execute transactions'
        ],
        correctAnswer: 1,
        explanation: 'Every write operation (INSERT/UPDATE/DELETE) must update all corresponding secondary B+ tree indexes, adding write latency.'
      }
    ]
  },

  // =========================================================================
  // Practical 8: Transactions and DCL
  // =========================================================================
  {
    id: 'transactions-and-dcl',
    num: 8,
    subjectId: 'dbms',
    title: 'Transactions and DCL',
    subtitle: 'Data Control Language (GRANT, REVOKE) & Transaction Processing (COMMIT, ROLLBACK, ACID)',
    category: 'Access Control & Transactions',
    iitReference: 'KJSIT Autonomous Lab Manual (Ms. Sejal Shah, Dept. of AI & Data Science) / MU Autonomous Standards',
    iitLabUrl: 'https://vlab.co.in/broad-division-computer-science-and-engineering',
    aim: 'To ensure data consistency and control user access.',
    objective: 'To use data control commands.',
    software: 'MySQL',
    theory: {
      overview: [
        'Data Control Language (DCL) commands such as GRANT and REVOKE manage user permissions and access rights.',
        'These mechanisms protect the database from unauthorized access and maintain data consistency in multi‑user environments.',
        'Transaction Control Language (TCL) commands (COMMIT, ROLLBACK, SAVEPOINT) maintain ACID properties: Atomicity (all or nothing), Consistency (preserves database integrity constraints), Isolation (concurrent transactions execute without cross-interference), and Durability (committed changes persist permanently across crashes).'
      ],
      complexityTable: [
        { parameter: 'Privilege Verification Cost', value: 'O(1) cached memory security context' },
        { parameter: 'Transaction Commit Latency', value: 'O(1) synchronous Write-Ahead Log (WAL) fsync' },
        { parameter: 'Rollback Recovery Cost', value: 'O(U) where U is uncommitted undo log records' },
        { parameter: 'Lock Acquisition Overhead', value: 'O(1) 2-Phase Locking (2PL) hash table lookup' }
      ],
      keyPoints: [
        'GRANT: Bestows specific privileges (SELECT, INSERT, UPDATE, DELETE, ALL) to a user or role.',
        'REVOKE: Withdraws previously granted privileges from a user or role.',
        'COMMIT: Permanently records all modifications made in the current transaction.',
        'ROLLBACK: Aborts the current transaction and restores data to the previous committed state.',
        'SAVEPOINT: Establishes an intermediate rollback checkpoint within a complex transaction.',
        'ACID Properties: Atomicity, Consistency, Isolation, and Durability guarantee transaction reliability.'
      ],
      realWorldApplications: [
        'Banking Transfers: Atomically debiting Account A and crediting Account B with automatic ROLLBACK on failure',
        'Enterprise Security: Enforcing principle of least privilege: Analysts get SELECT only; HR gets UPDATE',
        'Healthcare Portals: Restricting patient medical history access to authorized attending physicians',
        'E-Commerce Checkout: Reserving inventory, processing gateway payment, and generating invoice in one transaction'
      ]
    },
    algorithm: [
      'Step 1: Create distinct MySQL database users with secure passwords.',
      'Step 2: Apply DCL command GRANT to award selective privileges (e.g. GRANT SELECT ON db.* TO "analyst").',
      'Step 3: Test user authorization and verify privilege enforcement.',
      'Step 4: Apply REVOKE command to withdraw privileges and confirm access denial.',
      'Step 5: Initiate a multi-step transaction using START TRANSACTION.',
      'Step 6: Execute DML statements and verify atomic COMMIT upon success, or ROLLBACK upon error.'
    ],
    procedure: [
      'Open the Transaction & Concurrency Simulator in the laboratory interface.',
      'Create two user accounts: "finance_clerk" and "auditor".',
      'Grant SELECT and INSERT privileges to finance_clerk; grant SELECT only to auditor.',
      'Execute START TRANSACTION; transfer funds between two accounts.',
      'Issue ROLLBACK to observe complete restoration of account balances.',
      'Re-execute the transfer and issue COMMIT to permanently persist the state.'
    ],
    code: {
      sql: `-- Practical 8: DCL (GRANT/REVOKE) and Transactions (COMMIT/ROLLBACK) in MySQL
-- Part A: Data Control Language (DCL)
-- 1. Create a restricted user
CREATE USER IF NOT EXISTS 'lab_analyst'@'localhost' IDENTIFIED BY 'Pass@12345';

-- 2. Grant selective privileges
GRANT SELECT, INSERT ON college_db.Student TO 'lab_analyst'@'localhost';
FLUSH PRIVILEGES;

-- 3. Revoke privilege
REVOKE INSERT ON college_db.Student FROM 'lab_analyst'@'localhost';
FLUSH PRIVILEGES;

-- 4. Check active privileges
SHOW GRANTS FOR 'lab_analyst'@'localhost';

-- Part B: Transaction Control Language (TCL) & ACID
CREATE TABLE Accounts (
    acc_no INT PRIMARY KEY,
    owner_name VARCHAR(50),
    balance DECIMAL(10, 2) CHECK (balance >= 0)
);

INSERT INTO Accounts VALUES (101, 'Aarav Mehta', 5000.00), (102, 'Priya Nair', 3000.00);

-- Atomic Fund Transfer Transaction: Transfer 1000 from Aarav to Priya
START TRANSACTION;

-- Step 1: Debit Account 101
UPDATE Accounts SET balance = balance - 1000.00 WHERE acc_no = 101;

-- Intermediate Savepoint
SAVEPOINT step_one_done;

-- Step 2: Credit Account 102
UPDATE Accounts SET balance = balance + 1000.00 WHERE acc_no = 102;

-- If both steps succeed, permanently persist:
COMMIT;

-- Verify final balances
SELECT * FROM Accounts;`,
      python: `# Python demonstrating transactional COMMIT and ROLLBACK
import sqlite3

conn = sqlite3.connect(':memory:')
cur = conn.cursor()

cur.execute("CREATE TABLE Bank (acc INT PRIMARY KEY, bal REAL);")
cur.execute("INSERT INTO Bank VALUES (1, 500.0), (2, 200.0);")
conn.commit()

# Transaction with automatic Rollback on error
try:
    cur.execute("UPDATE Bank SET bal = bal - 100 WHERE acc = 1;")
    # Simulate an error (e.g. division by zero or negative balance)
    raise ValueError("Network timeout during transfer")
    cur.execute("UPDATE Bank SET bal = bal + 100 WHERE acc = 2;")
    conn.commit()
except Exception as e:
    print(f"Transaction aborted: {e}. Executing ROLLBACK...")
    conn.rollback()

cur.execute("SELECT * FROM Bank;")
print("Post-rollback Balances (Untouched):", cur.fetchall())
conn.close()`
    },
    sampleInput: 'START TRANSACTION; UPDATE Accounts SET balance = balance - 500 WHERE acc_no = 101; ROLLBACK;',
    expectedOutput: 'Account 101 balance remains unchanged (5000.00) due to ROLLBACK.',
    references: [
      'KJSIT Autonomous Lab Manual (Ms. Sejal Shah, Dept. of AI & Data Science)',
      'MySQL 8.0 Reference Manual - Account Management & Transaction Statements',
      'Bernstein & Newcomer, "Principles of Transaction Processing", 2nd Edition'
    ],
    conclusion: 'Access control mechanisms using DCL (GRANT and REVOKE) and transaction management (COMMIT and ROLLBACK) were successfully executed, ensuring data consistency and strict security governance.',
    postLabQuestions: [
      {
        question: 'List ACID properties.',
        answer: 'ACID stands for: (1) Atomicity: all operations in a transaction succeed completely or all are rolled back; (2) Consistency: transaction takes database from one valid state to another, upholding all constraints; (3) Isolation: concurrent transactions execute independently without observing intermediate uncommitted states; (4) Durability: once committed, updates persist permanently even through power failure or system crash.'
      },
      {
        question: 'Explain COMMIT and ROLLBACK.',
        answer: 'COMMIT finalizes and permanently records all data modifications made during the current transaction to physical storage, releasing lock resources. ROLLBACK undoes and aborts all uncommitted modifications back to the beginning of the transaction or to a designated SAVEPOINT.'
      },
      {
        question: 'Why is access control critical?',
        answer: 'Access control (DCL) prevents unauthorized data access, restricts sensitive data modification (preventing malicious or accidental data corruption), isolates user roles (admin, analyst, customer) to the principle of least privilege, and maintains compliance with enterprise security and privacy standards.'
      }
    ],
    quiz: [
      {
        id: 1,
        question: 'Which ACID property guarantees that all operations in a transaction succeed together, or none take effect?',
        options: ['Consistency', 'Atomicity', 'Isolation', 'Durability'],
        correctAnswer: 1,
        explanation: 'Atomicity ensures that a multi-step transaction is treated as an indivisible unit: all operations succeed or all are rolled back.'
      },
      {
        id: 2,
        question: 'Which DCL command is used to withdraw previously allocated access permissions from a database user?',
        options: ['DENY', 'DROP', 'REVOKE', 'REMOVE'],
        correctAnswer: 2,
        explanation: 'The REVOKE command withdraws privileges previously granted via the GRANT statement.'
      },
      {
        id: 3,
        question: 'What is the function of a SAVEPOINT in SQL transaction management?',
        options: [
          'It permanently commits the transaction up to that point',
          'It defines an intermediate checkpoint within a transaction to which you can selectively ROLLBACK',
          'It creates a backup of the entire database',
          'It terminates the client connection'
        ],
        correctAnswer: 1,
        explanation: 'A SAVEPOINT sets an intermediate marker within a transaction, allowing a ROLLBACK TO SAVEPOINT without aborting earlier valid steps.'
      }
    ]
  },

  // =========================================================================
  // Practical 9: Front-end Connectivity
  // =========================================================================
  {
    id: 'frontend-connectivity',
    num: 9,
    subjectId: 'dbms',
    title: 'Front-end Connectivity',
    subtitle: 'Database Integration with Client Applications: Python Connector, Cursors & CRUD Interfaces',
    category: 'Application & API Connectivity',
    iitReference: 'KJSIT Autonomous Lab Manual (Ms. Sejal Shah, Dept. of AI & Data Science) / MU Autonomous Standards',
    iitLabUrl: 'https://vlab.co.in/broad-division-computer-science-and-engineering',
    aim: 'To connect a database with a front-end application.',
    objective: 'To perform database operations through a user interface.',
    software: 'Python + MySQL',
    theory: {
      overview: [
        'Database connectivity allows applications to interact with databases using programming interfaces called connectors or drivers. These connectors enable the execution of SQL queries from programming languages such as Python, Java, or PHP.',
        'Through connectivity, users can insert, update, delete, and retrieve data using graphical interfaces instead of command‑line queries. This improves usability and accessibility for non‑technical users.',
        'Proper connection management ensures security, performance, and reliability of database‑driven applications.'
      ],
      complexityTable: [
        { parameter: 'TCP Handshake Connection Cost', value: '~15ms – 50ms per socket creation' },
        { parameter: 'Connection Pool Reuse Latency', value: '< 1ms from pre-warmed pool' },
        { parameter: 'Query Parameter Binding Overhead', value: 'O(M) string escaping (negligible)' },
        { parameter: 'Cursor Fetch Iteration', value: 'O(K) stream buffered records' }
      ],
      keyPoints: [
        'Connectors / Drivers: Libraries (e.g. mysql-connector-python, PyMySQL) implementing PEP 249 Python Database API.',
        'Connection Object: Manages TCP/IP network socket communication to the MySQL server.',
        'Cursor Object: Executes SQL queries, holds result sets, and traverses returned tuples.',
        'Parameterized Queries: Using %s placeholders prevents deadly SQL Injection attacks.',
        'Connection Pooling: Reusing a fixed pool of connections prevents server resource exhaustion.',
        'Transaction Commit: DML statements (INSERT, UPDATE, DELETE) require conn.commit() to persist.'
      ],
      realWorldApplications: [
        'Precision Smart Agriculture: Streamlit / React web dashboard displaying real-time sensor telemetry',
        'Student Management Systems: Desktop GUI (Tkinter) or Web Portal (Flask/Django) for student enrollment',
        'Hospital Administration: Doctor interface for issuing prescriptions and retrieving patient EHR records',
        'E-Commerce Applications: Shopping cart checkout connected via REST API to backend database'
      ]
    },
    algorithm: [
      'Step 1: Install driver package using pip install mysql-connector-python.',
      'Step 2: Establish connection object: conn = mysql.connector.connect(host, user, password, database).',
      'Step 3: Instantiate cursor object from connection: cursor = conn.cursor(dictionary=True).',
      'Step 4: Prepare parameterized SQL statement: query = "INSERT INTO table (col) VALUES (%s)".',
      'Step 5: Execute query passing sanitized tuple values: cursor.execute(query, (val,)).',
      'Step 6: Commit transaction: conn.commit() for mutations; cursor.fetchall() for retrieval.',
      'Step 7: Close cursor and connection cleanly in a finally block or using context managers.'
    ],
    procedure: [
      'Launch the Frontend Connectivity Simulator in the virtual laboratory interface.',
      'Review the connection configuration parameters (host, port, user, database).',
      'Use the interactive graphical form to insert a new student record.',
      'Observe the Python connector script executing parameterized INSERT statements.',
      'Inspect the live table update and connection pool telemetry.',
      'Test search filtering and record deletion through the front-end interface.'
    ],
    code: {
      python: `# Practical 9: Front-end Database Connectivity in Python + MySQL
import mysql.connector
from mysql.connector import Error

def create_connection():
    """Establish secure pooled database connection."""
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='student_management_db',
            user='kjsit_app_user',
            password='SecurePassword!2025',
            pool_name='kjsit_pool',
            pool_size=5
        )
        if connection.is_connected():
            print("Successfully connected to MySQL database.")
            return connection
    except Error as e:
        print(f"Error connecting to MySQL: {e}")
        return None

def insert_student(prn, name, email, dept, gpa):
    """Insert a new student using secure parameterized query."""
    conn = create_connection()
    if not conn: return
    cursor = conn.cursor()
    try:
        sql = "INSERT INTO students (prn, name, email, dept, gpa) VALUES (%s, %s, %s, %s, %s)"
        values = (prn, name, email, dept, gpa)
        cursor.execute(sql, values)
        conn.commit()
        print(f"Student {name} inserted successfully. Rows affected: {cursor.rowcount}")
    except Error as e:
        conn.rollback()
        print(f"Failed to insert student: {e}")
    finally:
        cursor.close()
        conn.close()

def fetch_students_by_dept(dept_name):
    """Retrieve students by department with dictionary cursor."""
    conn = create_connection()
    if not conn: return []
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("SELECT prn, name, email, gpa FROM students WHERE dept = %s", (dept_name,))
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    insert_student(101, 'Aarav Mehta', 'aarav.m@somaiya.edu', 'AI & Data Science', 9.2)
    students = fetch_students_by_dept('AI & Data Science')
    for s in students:
        print(s)`
    },
    sampleInput: 'insert_student(102, "Diya Sengupta", "diya.s@somaiya.edu", "AI & Data Science", 9.4)',
    expectedOutput: 'Successfully connected. Rows affected: 1. Student Diya Sengupta inserted.',
    references: [
      'KJSIT Autonomous Lab Manual (Ms. Sejal Shah, Dept. of AI & Data Science)',
      'MySQL Connector/Python Developer Guide (Official Oracle Documentation)',
      'PEP 249 -- Python Database API Specification v2.0'
    ],
    conclusion: 'Full-stack client-database connectivity was successfully established using Python and MySQL Connector, executing secure parameterized CRUD operations through an interactive front-end interface.',
    postLabQuestions: [
      {
        question: 'Define DB connectivity.',
        answer: 'Database connectivity is the software mechanism (via standard drivers/connectors such as MySQL Connector/Python, JDBC, ODBC) that enables an external software application to establish a networked socket connection with a database server, authenticate, send SQL queries, and receive tabular result sets.'
      },
      {
        question: 'Explain front-end interaction.',
        answer: 'Front-end interaction allows users to trigger database operations via visual controls (buttons, forms, data tables, dialogs) without writing raw SQL. The client-side application captures input, sends requests to backend services or drivers, which execute parameterized SQL queries against the database and format the response for display.'
      },
      {
        question: 'Issues with poor connection management?',
        answer: 'Poor connection management causes: (1) Connection leaks where unclosed sockets exhaust the database connection limit ("Too many connections" error); (2) Severe latency from repeatedly opening/closing sockets without a pool; (3) Memory starvation and thread lockups; and (4) Uncommitted zombie transactions locking database rows.'
      }
    ],
    quiz: [
      {
        id: 1,
        question: 'Why should user inputs always be passed as parameter tuples to cursor.execute() instead of formatted string concatenation?',
        options: [
          'To speed up query parsing by 10x',
          'To prevent SQL Injection vulnerabilities',
          'Because Python syntax requires it',
          'To compress the database payload'
        ],
        correctAnswer: 1,
        explanation: 'Parameterized queries escape special characters and separate code from data, completely neutralizing SQL Injection attacks.'
      },
      {
        id: 2,
        question: 'What method must be called on a Python DB connection after executing an INSERT or UPDATE statement to permanently save changes?',
        options: ['conn.save()', 'conn.commit()', 'conn.persist()', 'cursor.close()'],
        correctAnswer: 1,
        explanation: 'In compliance with PEP 249, DML mutations are wrapped inside a transaction and require connection.commit() to persist.'
      },
      {
        id: 3,
        question: 'What is the advantage of using a Connection Pool (pool_size > 1) in a front-end web application?',
        options: [
          'It removes the need for database passwords',
          'It reuses pre-established open connections, eliminating the high TCP handshake latency of opening new connections',
          'It converts SQL into NoSQL automatically',
          'It allows unlimited concurrent users'
        ],
        correctAnswer: 1,
        explanation: 'Connection pooling maintains a cache of open, ready-to-use connections, drastically reducing latency and server CPU socket overhead.'
      }
    ]
  },

  // =========================================================================
  // Practical 10: Capstone Project
  // =========================================================================
  {
    id: 'capstone-project',
    num: 10,
    subjectId: 'dbms',
    title: 'Capstone Project',
    subtitle: 'End-to-End Database Application Development: ER Modeling, Schema, SQL, Access Control & UI',
    category: 'Comprehensive Capstone System',
    iitReference: 'KJSIT Autonomous Lab Manual (Ms. Sejal Shah, Dept. of AI & Data Science) / MU Autonomous Standards',
    iitLabUrl: 'https://vlab.co.in/broad-division-computer-science-and-engineering',
    aim: 'To design and implement a complete database-driven application.',
    objective: 'To integrate modeling, SQL, access control and front-end development.',
    software: 'Any DB + Frontend',
    theory: {
      overview: [
        'The capstone project applies all database concepts to solve a real‑world problem.',
        'Students design schema, implement SQL queries and connect with a front‑end.',
        'This enhances system thinking, problem solving and technical integration skills.',
        'The full lifecycle includes: (1) Conceptual ER modeling, (2) Relational schema mapping and 3NF normalization, (3) Table constraints and DDL definition, (4) DML query and index optimization, (5) Role-based access control with DCL, and (6) Interactive user interface integration.'
      ],
      complexityTable: [
        { parameter: 'Development Lifecycle Stages', value: '6 distinct engineering phases' },
        { parameter: 'Target Normalization Standard', value: 'Boyce-Codd Normal Form (BCNF) / 3NF' },
        { parameter: 'System Architecture', value: '3-Tier (Client UI, Application API, Database)' },
        { parameter: 'Access Security', value: 'Role-Based Access Control (RBAC) via DCL' }
      ],
      keyPoints: [
        'Requirement Analysis: Identifying system entities, user personas, and transactional flows.',
        'Conceptual Design: Crafting ER diagrams with entities, attributes, and relationship cardinalities.',
        'Logical Design: Mapping ER diagrams to relational schemas normalized to 3NF/BCNF.',
        'Physical Implementation: Writing DDL schemas with primary, foreign, check, and unique constraints.',
        'Security & Governance: Configuring database roles (Admin, Manager, Customer) via GRANT/REVOKE.',
        'Full-Stack Integration: Connecting frontend components with backend API endpoints executing SQL queries.'
      ],
      realWorldApplications: [
        'Smart AgriTech Hardware Portal: Sensor inventory management, automated irrigation alerts, and order checkout',
        'Campus Placement Management System: Student profiles, company interview drives, and offer verification',
        'Healthcare Diagnostic Lab System: Patient test bookings, lab analyzer telemetry, and digital EHR reports',
        'Public Transportation Fleet Management: Route schedules, bus telematics, and ticket bookings'
      ]
    },
    algorithm: [
      'Stage 1: System Definition & Conceptual ER Model: Define entities, attributes, and relationships.',
      'Stage 2: Schema Design & Normalization: Convert ER into 3NF relational tables with integrity constraints.',
      'Stage 3: Data Population & Queries: Insert seed data, create Views, and test multi-table joins.',
      'Stage 4: Role-Based Access Control: Define database roles and enforce least privilege via GRANT/REVOKE.',
      'Stage 5: Front-End UI Development: Build responsive web interfaces with form inputs, search filters, and catalog views.',
      'Stage 6: End-to-End Testing: Verify transaction atomicity during checkout/order placement across all tiers.'
    ],
    procedure: [
      'Launch the Capstone Project Simulator in the virtual laboratory interface.',
      'Step through Stage 1 (Architecture & Conceptual Design) to review the multi-tier system topology.',
      'Review Stage 2 (SQL Schema & DDL) for tables: users, products, orders, and order_items.',
      'Examine Stage 3 (DCL Security) to inspect role-based grants for Admin, Staff, and Student.',
      'Interact with Stage 4 (Live Web App): browse hardware catalog, add items to cart, and execute checkout transactions.',
      'Verify that inventory decrements correctly and transaction commits are logged in the database.'
    ],
    code: {
      sql: `-- Practical 10: Capstone Project Complete Relational Schema
CREATE DATABASE IF NOT EXISTS agritech_portal_db;
USE agritech_portal_db;

-- 1. Users Table with Authentication & Roles
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'staff', 'student') DEFAULT 'student',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Products Table with Domain Constraints
CREATE TABLE products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    category VARCHAR(80) NOT NULL,
    price DECIMAL(10, 2) NOT NULL CHECK (price >= 0),
    stock INT NOT NULL CHECK (stock >= 0)
);

-- 3. Orders Header Table
CREATE TABLE orders (
    order_id VARCHAR(30) PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL CHECK (total_amount >= 0),
    status ENUM('PENDING', 'CONFIRMED', 'SHIPPED') DEFAULT 'CONFIRMED',
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE RESTRICT
);

-- 4. Order Line Items Table (M:N Relationship Junction)
CREATE TABLE order_items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id VARCHAR(30) NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    unit_price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE RESTRICT
);

-- 5. Seed Data
INSERT INTO products (name, category, price, stock) VALUES
('Smart IoT Soil Moisture Sensor Node', 'Precision Agriculture', 1200.00, 25),
('Automated Drip Solenoid Valve 12V', 'Smart Irrigation', 850.00, 30),
('LoRaWAN Gateway Receiver 868MHz', 'Telemetry', 4500.00, 8);`,
      python: `# Python Flask REST API Backend for Capstone Project
from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)

def get_db():
    conn = sqlite3.connect('capstone.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/api/products', methods=['GET'])
def get_products():
    db = get_db()
    products = db.execute("SELECT * FROM products WHERE stock > 0").fetchall()
    return jsonify([dict(p) for p in products])

@app.route('/api/orders/checkout', methods=['POST'])
def checkout():
    data = request.json
    db = get_db()
    try:
        db.execute("BEGIN TRANSACTION;")
        # Insert order and decrement inventory atomically
        db.execute("INSERT INTO orders (order_id, user_id, total_amount) VALUES (?, ?, ?)",
                   (data['order_id'], data['user_id'], data['total']))
        for item in data['items']:
            db.execute("UPDATE products SET stock = stock - ? WHERE product_id = ?",
                       (item['qty'], item['product_id']))
        db.commit()
        return jsonify({"status": "SUCCESS", "order_id": data['order_id']})
    except Exception as e:
        db.rollback()
        return jsonify({"status": "ERROR", "message": str(e)}), 400

if __name__ == '__main__':
    print("Capstone API Service Ready.")`
    },
    sampleInput: 'Execute checkout transaction with 2x IoT Soil Sensor Nodes for ₹2,400',
    expectedOutput: 'Transaction Committed: Order ORD-2025-4812 created; inventory updated from 25 to 23.',
    references: [
      'KJSIT Autonomous Lab Manual (Ms. Sejal Shah, Dept. of AI & Data Science)',
      'Pressman, R. S., "Software Engineering: A Practitioner\'s Approach", McGraw-Hill',
      'Silberschatz, Korth, Sudarshan, "Database System Concepts", 7th Edition'
    ],
    conclusion: 'A complete end-to-end database application was successfully designed and integrated, demonstrating conceptual modeling, 3NF schema architecture, DCL security governance, and interactive front-end application transactions.',
    postLabQuestions: [
      {
        question: 'List stages of DB development.',
        answer: 'The stages of database system development are: (1) Requirement Analysis, (2) Conceptual Design (ER Modeling), (3) Logical Design (Relational Schema Mapping & Normalization to 3NF/BCNF), (4) Physical Design (Data types, Indexing, Storage Allocation), (5) Implementation & Security (DDL, DML, DCL Access Control), and (6) Application Integration & Testing (Front-end connectivity & user interface verification).'
      },
      {
        question: 'Explain normalization.',
        answer: 'Normalization is the systematic process of decomposing relational tables to minimize data redundancy and eliminate insert, update, and delete anomalies. It progresses through normal forms: 1NF (atomic attributes, no repeating groups), 2NF (eliminates partial key dependencies), 3NF (eliminates transitive dependencies), and BCNF (every determinant is a superkey).'
      },
      {
        question: 'Effect of poor schema design?',
        answer: 'Poor schema design causes severe data redundancy, inconsistent updates, loss of referential integrity, excessive storage consumption, complex multi-table joins that degrade query performance, and security vulnerabilities that expose sensitive business entities.'
      }
    ],
    quiz: [
      {
        id: 1,
        question: 'Which stage of database development translates business requirements into an Entity-Relationship (ER) model?',
        options: ['Physical Design', 'Conceptual Design', 'Query Optimization', 'DCL Configuration'],
        correctAnswer: 1,
        explanation: 'Conceptual Design models high-level entities, attributes, and relationships independently of any specific DBMS implementation.'
      },
      {
        id: 2,
        question: 'What normal form eliminates transitive functional dependencies (where a non-prime attribute depends on another non-prime attribute)?',
        options: ['1NF', '2NF', '3NF', 'BCNF'],
        correctAnswer: 2,
        explanation: 'Third Normal Form (3NF) requires 2NF and mandates that no non-prime attribute is transitively dependent on any candidate key.'
      },
      {
        id: 3,
        question: 'In a 3-tier enterprise database architecture, what is the role of the middle tier (Application API)?',
        options: [
          'Directly stores raw data files on physical spinning hard disks',
          'Renders UI CSS styling in the user browser',
          'Processes business logic, validates inputs, manages connection pools, and securely queries the database',
          'Acts as an electrical circuit breaker'
        ],
        correctAnswer: 2,
        explanation: 'The application tier coordinates business rules, executes parameter-bound queries against the database, and serves sanitized JSON to the client presentation tier.'
      }
    ]
  }
];
