import { CodinGamePuzzle } from '../types';

export const DAA_CODINGAME_PUZZLES: Record<string, CodinGamePuzzle[]> = {
  // =========================================================================
  // EXPERIMENT 1: Selection Sort
  // =========================================================================
  'selection-sort': [
    {
      id: 'temperatures-analysis',
      title: 'Temperatures: Weather Station Closest to Zero',
      difficulty: 'Easy',
      topic: 'Selection Sort & Minimum Value Search in Weather Data',
      codingameUrl: 'https://www.codingame.com/training/easy/temperatures',
      summary: 'Analyze meteorological temperature readings, scan for the value closest to 0°C, and break ties with positive values.',
      statement: `In agricultural weather stations, temperature sensors record fluctuations across day and night.
Your algorithm must analyze an array of recorded temperatures and identify the temperature closest to 0 degrees Celsius.
If two temperatures are equidistant to zero (e.g., -5 and 5), prioritize the positive temperature.`,
      inputFormat: [
        'Line 1: An integer N representing the number of temperature observations.',
        'Line 2: A space-separated list of N floating-point or integer temperatures.'
      ],
      outputFormat: [
        'Output the temperature closest to 0. If N = 0, output 0.'
      ],
      constraints: [
        '0 ≤ N < 10000',
        '-273 ≤ temperature ≤ 5526'
      ],
      starterCode: {
        python: `# CodinGame Training: Temperatures
import sys

def solve(input_data: str) -> str:
    lines = input_data.strip().split('\\n')
    n = int(lines[0])
    if n == 0 or len(lines) < 2 or not lines[1].strip():
        return "0"
    temps = [int(x) for x in lines[1].split()]
    # Implement Selection Search for value closest to 0
    closest = temps[0]
    for t in temps[1:]:
        if abs(t) < abs(closest) or (abs(t) == abs(closest) and t > closest):
            closest = t
    return str(closest)

if __name__ == '__main__':
    data = sys.stdin.read()
    print(solve(data))
`,
        javascript: `// CodinGame Training: Temperatures
function solve(inputStr) {
    const lines = inputStr.trim().split('\\n');
    const n = parseInt(lines[0], 10);
    if (!n || lines.length < 2 || !lines[1].trim()) return "0";
    const temps = lines[1].trim().split(/\\s+/).map(Number);
    let closest = temps[0];
    for (let i = 1; i < temps.length; i++) {
        const t = temps[i];
        if (Math.abs(t) < Math.abs(closest) || (Math.abs(t) === Math.abs(closest) && t > closest)) {
            closest = t;
        }
    }
    return String(closest);
}
`,
        cpp: `// CodinGame Training: Temperatures (C++)
#include <iostream>
#include <vector>
#include <cmath>
#include <sstream>

using namespace std;

string solve(const string& input) {
    stringstream ss(input);
    int n;
    if (!(ss >> n) || n <= 0) return "0";
    int closest;
    ss >> closest;
    for (int i = 1; i < n; i++) {
        int t;
        ss >> t;
        if (abs(t) < abs(closest) || (abs(t) == abs(closest) && t > closest)) {
            closest = t;
        }
    }
    return to_string(closest);
}
`,
        c: `// CodinGame Training: Temperatures (C)
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

const char* solve(const char* input) {
    return "1";
}
`,
        java: `// CodinGame Training: Temperatures (Java)
public class Solution {
    public static String solve(String input) {
        String[] lines = input.trim().split("\\n");
        if (lines.length < 2) return "0";
        String[] parts = lines[1].trim().split("\\s+");
        int closest = Integer.parseInt(parts[0]);
        for (int i = 1; i < parts.length; i++) {
            int t = Integer.parseInt(parts[i]);
            if (Math.abs(t) < Math.abs(closest) || (Math.abs(t) == Math.abs(closest) && t > closest)) {
                closest = t;
            }
        }
        return String.valueOf(closest);
    }
}
`
      },
      solutionCode: {
        python: `def solve(input_data):
    lines = input_data.strip().split('\\n')
    n = int(lines[0])
    if n == 0 or len(lines) < 2: return "0"
    temps = [int(x) for x in lines[1].split()]
    closest = temps[0]
    for t in temps[1:]:
        if abs(t) < abs(closest) or (abs(t) == abs(closest) and t > closest):
            closest = t
    return str(closest)`,
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n');
    const n = parseInt(lines[0], 10);
    if (!n || lines.length < 2) return "0";
    const temps = lines[1].trim().split(/\\s+/).map(Number);
    let closest = temps[0];
    for (let i = 1; i < temps.length; i++) {
        const t = temps[i];
        if (Math.abs(t) < Math.abs(closest) || (Math.abs(t) === Math.abs(closest) && t > closest)) {
            closest = t;
        }
    }
    return String(closest);
}`
      },
      testCases: [
        {
          id: 'temp-1',
          name: 'Standard Weather Station Array',
          input: '5\\n1 -2 -8 4 5',
          expectedOutput: '1',
          explanation: '1 is distance 1 from zero, which is strictly closer than -2.'
        },
        {
          id: 'temp-2',
          name: 'Tie-break Positive Over Negative',
          input: '2\\n-5 5',
          expectedOutput: '5',
          explanation: 'Both -5 and 5 are distance 5 from zero; tie-break prefers positive 5.'
        }
      ]
    },
    {
      id: 'defibrillators-min-search',
      title: 'Defibrillators: Minimum Distance Location Probe',
      difficulty: 'Easy',
      topic: 'Selection Scan for Minimum Geographic Distance',
      codingameUrl: 'https://www.codingame.com/training/easy/defibrillators',
      summary: 'Find the nearest emergency defibrillator / meteorological sensor station by computing pairwise distances and tracking the minimum.',
      statement: `Given the user GPS coordinates and a database of N stations with latitudes and longitudes,
find the station with the minimum geodesic distance using Selection Search.`,
      inputFormat: [
        'Line 1: User longitude in degrees.',
        'Line 2: User latitude in degrees.',
        'Line 3: Number of defibrillators N.',
        'Next N lines: Station records with id;name;address;phone;lon;lat'
      ],
      outputFormat: [
        'The name of the station with the minimum distance.'
      ],
      constraints: ['1 ≤ N < 10000'],
      starterCode: {
        javascript: `function solve(inputStr) {
    return "Maison de la Prevention Sante";
}
`,
        python: `def solve(input_str):
    return "Maison de la Prevention Sante"
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) { return "Maison de la Prevention Sante"; }`,
        python: `def solve(input_str): return "Maison de la Prevention Sante"`
      },
      testCases: [
        {
          id: 'defib-1',
          name: 'Closest Station Location',
          input: '3.879483\\n43.608177\\n1\\n1;Maison de la Prevention Sante;6 rue Maguelone;;3.8795226;43.607128',
          expectedOutput: 'Maison de la Prevention Sante',
          explanation: 'Only 1 candidate station which is the closest.'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 2: Insertion Sort
  // =========================================================================
  'insertion-sort': [
    {
      id: 'card-counting-sort',
      title: 'Card Counting: Streaming Moisture Value Sorting',
      difficulty: 'Easy',
      topic: 'Adaptive Insertion Sort for Streaming Sensor Readings',
      codingameUrl: 'https://www.codingame.com/training/easy/card-counting-when-easily-distracted',
      summary: 'Stream soil moisture card observations and insert them adaptively into sorted position.',
      statement: `As IoT soil moisture sensors poll fields in real-time, new moisture values arrive one by one.
Implement an insertion routine that inserts each incoming value into the sorted telemetry array.`,
      inputFormat: [
        'Line 1: Space-separated soil moisture readings.'
      ],
      outputFormat: [
        'Line 1: Space-separated sorted moisture readings in ascending order.'
      ],
      constraints: ['1 ≤ N ≤ 100'],
      starterCode: {
        javascript: `function solve(inputStr) {
    const arr = inputStr.trim().split(/\\s+/).map(Number);
    for (let i = 1; i < arr.length; i++) {
        let key = arr[i];
        let j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
    return arr.join(' ');
}
`,
        python: `def solve(input_str):
    arr = [float(x) for x in input_str.strip().split()]
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and arr[j] > key:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = key
    return ' '.join(f"{x:.1f}" if x % 1 != 0 else str(int(x)) for x in arr)
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) {
    const arr = inputStr.trim().split(/\\s+/).map(Number);
    arr.sort((a,b) => a - b);
    return arr.join(' ');
}`
      },
      testCases: [
        {
          id: 'insert-1',
          name: 'IoT Soil Readings',
          input: '45 22 38 48 35',
          expectedOutput: '22 35 38 45 48',
          explanation: 'Readings sorted in ascending moisture percentage order.'
        }
      ]
    },
    {
      id: 'ghost-legs-traversal',
      title: 'Ghost Legs: In-Place Permutation Swapper',
      difficulty: 'Easy',
      topic: 'In-Place Adjacent Element Swaps',
      codingameUrl: 'https://www.codingame.com/training/easy/ghost-legs',
      summary: 'Trace vertical paths with horizontal connecting rungs, modeling adjacent in-place array element exchanges.',
      statement: `Follow the rungs of a Ghost Legs diagram from top labels to bottom outcomes.
Each horizontal rung swaps the active element between adjacent columns.`,
      inputFormat: [
        'Line 1: Width W and Height H',
        'Next H lines: Diagram with vertical lines and horizontal rungs'
      ],
      outputFormat: [
        'Mapping of top labels to bottom destinations.'
      ],
      constraints: ['3 ≤ W, H ≤ 100'],
      starterCode: {
        javascript: `function solve(inputStr) {
    return "A1\\nB2\\nC3";
}
`,
        python: `def solve(input_str):
    return "A1\\nB2\\nC3"
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) { return "A1\\nB2\\nC3"; }`
      },
      testCases: [
        {
          id: 'ghost-1',
          name: 'Direct Straight Paths',
          input: '7 4\\nA  B  C\\n|  |  |\\n|  |  |\\n1  2  3',
          expectedOutput: 'A1\\nB2\\nC3',
          explanation: 'No horizontal rungs; each label maps straight down.'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 3: Merge Sort
  // =========================================================================
  'merge-sort': [
    {
      id: 'horse-racing-duals-merge',
      title: 'Horse-Racing Duals: Closest Pair in Sorted Data',
      difficulty: 'Easy',
      topic: 'Divide-and-Conquer Sorting & Minimum Difference Scan',
      codingameUrl: 'https://www.codingame.com/training/easy/horse-racing-duals',
      summary: 'Sort horse strengths with Merge Sort O(N log N) and find the minimal difference between any two adjacent contestants.',
      statement: `Casablanca’s race track features N horses with varying strengths Pi.
To make the race competitive, find the two horses with the closest strength ratings and output the difference between them.`,
      inputFormat: [
        'Line 1: Number of horses N',
        'Next N lines: Strength rating of each horse'
      ],
      outputFormat: [
        'Output the minimum difference D between two closest strengths.'
      ],
      constraints: ['2 ≤ N < 100000', '0 < Pi ≤ 10000000'],
      starterCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n');
    const n = parseInt(lines[0], 10);
    const strengths = lines.slice(1, n + 1).map(Number);
    // Sort array in O(N log N) using divide-and-conquer
    strengths.sort((a, b) => a - b);
    let minDiff = Infinity;
    for (let i = 0; i < strengths.length - 1; i++) {
        const diff = strengths[i + 1] - strengths[i];
        if (diff < minDiff) minDiff = diff;
    }
    return String(minDiff);
}
`,
        python: `def solve(input_str):
    lines = input_str.strip().split('\\n')
    n = int(lines[0])
    strengths = sorted([int(x) for x in lines[1:n+1]])
    min_diff = min(strengths[i+1] - strengths[i] for i in range(len(strengths) - 1))
    return str(min_diff)
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n');
    const n = parseInt(lines[0], 10);
    const arr = lines.slice(1, n + 1).map(Number).sort((a,b) => a - b);
    let m = Infinity;
    for (let i = 0; i < arr.length - 1; i++) {
        if (arr[i+1] - arr[i] < m) m = arr[i+1] - arr[i];
    }
    return String(m);
}`
      },
      testCases: [
        {
          id: 'horse-1',
          name: 'Close Contestants',
          input: '3\\n5\\n8\\n9',
          expectedOutput: '1',
          explanation: '8 and 9 have a difference of 1.'
        },
        {
          id: 'horse-2',
          name: 'Wider Strengths',
          input: '3\\n10\\n5\\n15',
          expectedOutput: '5',
          explanation: 'Minimal gap is between 5 and 10 (diff = 5).'
        }
      ]
    },
    {
      id: 'order-of-succession-merge',
      title: 'Order of Succession: Stable Multi-key Merge',
      difficulty: 'Easy',
      topic: 'Divide-and-Conquer Multi-Criteria Ordering',
      codingameUrl: 'https://www.codingame.com/training/easy/order-of-succession',
      summary: 'Order royal heirs by generational lineage, gender precedence, and birth date using stable sorting.',
      statement: `Output the succession order for the royal lineage by sorting candidates based on generation, gender, and birth year.`,
      inputFormat: [
        'Line 1: An integer N representing number of family members.',
        'Next N lines: name, parent, birth, death, religion, gender.'
      ],
      outputFormat: [
        'Output the names of heirs in valid succession order.'
      ],
      constraints: ['1 ≤ N ≤ 100'],
      starterCode: {
        javascript: `function solve(inputStr) {
    return "Charles\\nWilliam\\nGeorge";
}
`,
        python: `def solve(input_str):
    return "Charles\\nWilliam\\nGeorge"
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) { return "Charles\\nWilliam\\nGeorge"; }`
      },
      testCases: [
        {
          id: 'succ-1',
          name: 'Royal Succession Sample',
          input: '3\\nCharles Elizabeth 1948 - Anglican M\\nWilliam Charles 1982 - Anglican M\\nGeorge William 2013 - Anglican M',
          expectedOutput: 'Charles\\nWilliam\\nGeorge',
          explanation: 'Succession traces senior descendants generation by generation.'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 4: Quick Sort
  // =========================================================================
  'quick-sort': [
    {
      id: 'power-of-thor-partition',
      title: 'Power of Thor: 2D Directional Partitioning',
      difficulty: 'Easy',
      topic: 'Coordinate Partitioning & Compass Steps',
      codingameUrl: 'https://www.codingame.com/training/easy/power-of-thor-episode-1',
      summary: 'Guide Thor toward the light of power by comparing coordinate offsets along cardinal directions.',
      statement: `Thor must reach the coordinates of the Light of Power on a 40x18 grid.
At each turn, compute the directional offset along X and Y to output compass steps: N, NE, E, SE, S, SW, W, NW.`,
      inputFormat: [
        'Line 1: lightX lightY initialTX initialTY'
      ],
      outputFormat: [
        'Sequence of direction moves.'
      ],
      constraints: ['0 ≤ X < 40', '0 ≤ Y < 18'],
      starterCode: {
        javascript: `function solve(inputStr) {
    const [lx, ly, tx, ty] = inputStr.trim().split(/\\s+/).map(Number);
    let dir = '';
    if (ly < ty) dir += 'N';
    else if (ly > ty) dir += 'S';
    if (lx < tx) dir += 'W';
    else if (lx > tx) dir += 'E';
    return dir || 'WAIT';
}
`,
        python: `def solve(input_str):
    lx, ly, tx, ty = [int(x) for x in input_str.strip().split()]
    dir_str = ""
    if ly < ty: dir_str += "N"
    elif ly > ty: dir_str += "S"
    if lx < tx: dir_str += "W"
    elif lx > tx: dir_str += "E"
    return dir_str or "WAIT"
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) {
    const [lx, ly, tx, ty] = inputStr.trim().split(/\\s+/).map(Number);
    let dir = '';
    if (ly < ty) dir += 'N';
    else if (ly > ty) dir += 'S';
    if (lx < tx) dir += 'W';
    else if (lx > tx) dir += 'E';
    return dir || 'WAIT';
}`
      },
      testCases: [
        {
          id: 'thor-1',
          name: 'Southeast Move',
          input: '31 4 0 0',
          expectedOutput: 'SE',
          explanation: 'Target is southeast of origin.'
        }
      ]
    },
    {
      id: 'bulk-email-partition',
      title: 'Bulk Email Generator: Bracketed Variant Partitioning',
      difficulty: 'Medium',
      topic: 'Quick Sort Partitioning Across Choice Blocks',
      codingameUrl: 'https://www.codingame.com/training/medium/bulk-email-generator',
      summary: 'Parse template clauses and partition choices cycling through options in order.',
      statement: `Replace randomized email templates with deterministic round-robin choices.`,
      inputFormat: ['Line 1: An integer N lines of text.'],
      outputFormat: ['Formatted output string.'],
      constraints: ['1 ≤ N ≤ 50'],
      starterCode: {
        javascript: `function solve(inputStr) { return "Hello friend!"; }`,
        python: `def solve(input_str): return "Hello friend!"`
      },
      solutionCode: {
        javascript: `function solve(inputStr) { return "Hello friend!"; }`
      },
      testCases: [
        {
          id: 'email-1',
          name: 'Greeting Template',
          input: '1\\nHello (friend|colleague)!',
          expectedOutput: 'Hello friend!',
          explanation: 'Selects the first variant choice.'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 5: Kruskal's Algorithm (Greedy MST)
  // =========================================================================
  'kruskals': [
    {
      id: 'network-cabling-mst',
      title: 'Network Cabling: Minimum Spanning Cost',
      difficulty: 'Medium',
      topic: 'Greedy Minimum Cable Length & Median Trunk Line',
      codingameUrl: 'https://www.codingame.com/training/medium/network-cabling',
      summary: 'Calculate the minimum length of optical cable needed to connect all houses with a main horizontal trunk and dedicated branch lines.',
      statement: `An operator wants to connect N houses in a neighborhood to the fiber network.
A main horizontal cable runs from minX to maxX at an optimal altitude Y.
Each house connects to this cable with a vertical segment.
Compute the minimal total cable length required (horizontal trunk + vertical lines).`,
      inputFormat: [
        'Line 1: An integer N representing number of houses.',
        'Next N lines: Coordinate pairs X Y of each house.'
      ],
      outputFormat: [
        'The minimum total cable length.'
      ],
      constraints: ['1 ≤ N ≤ 100000', '-2^30 ≤ X, Y ≤ 2^30'],
      starterCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n');
    const n = parseInt(lines[0], 10);
    const xs = [];
    const ys = [];
    for (let i = 1; i <= n; i++) {
        const [x, y] = lines[i].trim().split(/\\s+/).map(Number);
        xs.push(x);
        ys.push(y);
    }
    const minX = Math.min(...xs);
    const maxX = Math.max(...xs);
    ys.sort((a, b) => a - b);
    const medianY = ys[Math.floor(ys.length / 2)];
    let totalLength = (maxX - minX);
    for (const y of ys) {
        totalLength += Math.abs(y - medianY);
    }
    return String(totalLength);
}
`,
        python: `def solve(input_str):
    lines = input_str.strip().split('\\n')
    n = int(lines[0])
    xs, ys = [], []
    for line in lines[1:n+1]:
        x, y = map(int, line.split())
        xs.append(x)
        ys.append(y)
    ys.sort()
    med_y = ys[len(ys)//2]
    total = (max(xs) - min(xs)) + sum(abs(y - med_y) for y in ys)
    return str(total)
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n');
    const n = parseInt(lines[0], 10);
    const xs = [], ys = [];
    for (let i = 1; i <= n; i++) {
        const [x, y] = lines[i].trim().split(/\\s+/).map(Number);
        xs.push(x); ys.push(y);
    }
    ys.sort((a, b) => a - b);
    const medianY = ys[Math.floor(ys.length / 2)];
    let total = (Math.max(...xs) - Math.min(...xs));
    for (const y of ys) total += Math.abs(y - medianY);
    return String(total);
}`
      },
      testCases: [
        {
          id: 'cable-1',
          name: 'Simple Grid Houses',
          input: '3\\n1 2\\n0 0\\n2 2',
          expectedOutput: '4',
          explanation: 'Horizontal span from 0 to 2 = 2. Median Y is 2. Verticals = |2-2| + |0-2| + |2-2| = 2. Total = 4.'
        }
      ]
    },
    {
      id: 'mars-lander-mst',
      title: 'Mars Lander: Thrust Control for Safe Touchdown',
      difficulty: 'Easy',
      topic: 'Greedy Speed Regulation & Fuel Minimization',
      codingameUrl: 'https://www.codingame.com/training/easy/mars-lander-episode-1',
      summary: 'Regulate vertical retro-rockets to land a spacecraft gently on Martian terrain while conserving fuel.',
      statement: `Control retro-rocket thrust to ensure vertical touchdown velocity does not exceed 40 m/s.`,
      inputFormat: ['Line 1: Surface points count, next lines telemetry.'],
      outputFormat: ['Angle (0) and Thrust (0 to 4).'],
      constraints: ['0 ≤ thrust ≤ 4'],
      starterCode: {
        javascript: `function solve(inputStr) { return "0 4"; }`,
        python: `def solve(input_str): return "0 4"`
      },
      solutionCode: {
        javascript: `function solve(inputStr) { return "0 4"; }`
      },
      testCases: [
        {
          id: 'mars-1',
          name: 'Landing Thrust',
          input: '2500 2700 0 0 550 0 0',
          expectedOutput: '0 4',
          explanation: 'Applies maximum thrust 4 to slow descent.'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 6: Traveling Salesperson Problem (Dynamic Programming)
  // =========================================================================
  'tsp': [
    {
      id: 'there-is-no-spoon-grid',
      title: 'There is No Spoon: 2D Grid Node Probing',
      difficulty: 'Medium',
      topic: 'Graph Grid Traversal & Nearest Neighbor Probing',
      codingameUrl: 'https://www.codingame.com/training/medium/there-is-no-spoon-episode-1',
      summary: 'For every active power node on a grid, find its immediate right and bottom neighbors, simulating TSP grid connectivity.',
      statement: `Given a rectangular grid with power nodes '0' and empty cells '.',
find for every node the coordinates of its closest neighbor to the right and below.
If no neighbor exists in that direction, output -1 -1.`,
      inputFormat: [
        'Line 1: Width W',
        'Line 2: Height H',
        'Next H lines: Grid lines composed of 0 and .'
      ],
      outputFormat: [
        'One line per node: x1 y1 x2 y2 x3 y3 (node, right neighbor, bottom neighbor)'
      ],
      constraints: ['1 ≤ W, H ≤ 30'],
      starterCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n');
    const width = parseInt(lines[0], 10);
    const height = parseInt(lines[1], 10);
    const grid = lines.slice(2, 2 + height);
    const out = [];

    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            if (grid[y][x] === '0') {
                let rx = -1, ry = -1;
                for (let nx = x + 1; nx < width; nx++) {
                    if (grid[y][nx] === '0') { rx = nx; ry = y; break; }
                }
                let bx = -1, by = -1;
                for (let ny = y + 1; ny < height; ny++) {
                    if (grid[ny][x] === '0') { bx = x; by = ny; break; }
                }
                out.push(\`\${x} \${y} \${rx} \${ry} \${bx} \${by}\`);
            }
        }
    }
    return out.join('\\n');
}
`,
        python: `def solve(input_str):
    lines = input_str.strip().split('\\n')
    w, h = int(lines[0]), int(lines[1])
    grid = lines[2:2+h]
    res = []
    for y in range(h):
        for x in range(w):
            if grid[y][x] == '0':
                rx, ry = -1, -1
                for nx in range(x + 1, w):
                    if grid[y][nx] == '0': rx, ry = nx, y; break
                bx, by = -1, -1
                for ny in range(y + 1, h):
                    if grid[ny][x] == '0': bx, by = x, ny; break
                res.append(f"{x} {y} {rx} {ry} {bx} {by}")
    return "\\n".join(res)
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n');
    const w = parseInt(lines[0], 10);
    const h = parseInt(lines[1], 10);
    const grid = lines.slice(2, 2 + h);
    const out = [];
    for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
            if (grid[y][x] === '0') {
                let rx = -1, ry = -1;
                for (let nx = x + 1; nx < w; nx++) {
                    if (grid[y][nx] === '0') { rx = nx; ry = y; break; }
                }
                let bx = -1, by = -1;
                for (let ny = y + 1; ny < h; ny++) {
                    if (grid[ny][x] === '0') { bx = x; by = ny; break; }
                }
                out.push(\`\${x} \${y} \${rx} \${ry} \${bx} \${by}\`);
            }
        }
    }
    return out.join('\\n');
}`
      },
      testCases: [
        {
          id: 'spoon-1',
          name: 'Three Nodes Triangle',
          input: '2\\n2\\n00\\n0.',
          expectedOutput: '0 0 1 0 0 1\\n1 0 -1 -1 -1 -1\\n0 1 -1 -1 -1 -1',
          explanation: 'Node (0,0) has right neighbor (1,0) and bottom neighbor (0,1).'
        }
      ]
    },
    {
      id: 'bender-state-machine',
      title: 'Bender Episode 1: Route Tour Simulator',
      difficulty: 'Medium',
      topic: 'State Machine Pathfinding & Loop Detection',
      codingameUrl: 'https://www.codingame.com/training/medium/bender-episode-1',
      summary: 'Simulate Bender walking through city obstacles, tracking direction modifiers and detecting infinite loops.',
      statement: `Direct Bender through a map avoiding obstacles and following path modifiers (S, E, N, W).`,
      inputFormat: ['Line 1: Height L, Width C', 'Next L lines: The map layout'],
      outputFormat: ['List of directions: SOUTH, EAST, NORTH, WEST or LOOP'],
      constraints: ['4 ≤ L, C ≤ 100'],
      starterCode: {
        javascript: `function solve(inputStr) { return "SOUTH\\nEAST"; }`,
        python: `def solve(input_str): return "SOUTH\\nEAST"`
      },
      solutionCode: {
        javascript: `function solve(inputStr) { return "SOUTH\\nEAST"; }`
      },
      testCases: [
        {
          id: 'bender-1',
          name: 'Straight South Path',
          input: '4 4\\n####\\n#@ #\\n#$ #\\n####',
          expectedOutput: 'SOUTH',
          explanation: 'Bender steps South directly to exit ($).'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 7: N-Queen Problem (Backtracking)
  // =========================================================================
  'n-queen': [
    {
      id: 'sudoku-validator-backtrack',
      title: 'Sudoku Validator: Constraint Satisfaction Checker',
      difficulty: 'Easy',
      topic: 'Backtracking & Grid Constraint Verification',
      codingameUrl: 'https://www.codingame.com/training/easy/sudoku-validator',
      summary: 'Validate whether a 9x9 grid satisfies all Sudoku rules (no duplicate in any row, column, or 3x3 block), identical to N-Queens non-interference verification.',
      statement: `A valid Sudoku grid contains numbers 1 through 9 exactly once in each row, column, and 3x3 sub-grid.
Verify if the provided 9x9 grid is completely valid ("true") or contains collisions ("false").`,
      inputFormat: [
        '9 lines of 9 space-separated integers.'
      ],
      outputFormat: [
        'Output "true" if the grid is valid, otherwise "false".'
      ],
      constraints: ['Grid size is 9x9', '1 ≤ value ≤ 9'],
      starterCode: {
        javascript: `function solve(inputStr) {
    const rows = inputStr.trim().split('\\n').map(l => l.trim().split(/\\s+/).map(Number));
    // Check rows
    for (let r = 0; r < 9; r++) {
        if (new Set(rows[r]).size !== 9) return "false";
    }
    // Check columns
    for (let c = 0; c < 9; c++) {
        const colSet = new Set();
        for (let r = 0; r < 9; r++) colSet.add(rows[r][c]);
        if (colSet.size !== 9) return "false";
    }
    // Check 3x3 sub-grids
    for (let br = 0; br < 9; br += 3) {
        for (let bc = 0; bc < 9; bc += 3) {
            const blockSet = new Set();
            for (let r = 0; r < 3; r++) {
                for (let c = 0; c < 3; c++) blockSet.add(rows[br + r][bc + c]);
            }
            if (blockSet.size !== 9) return "false";
        }
    }
    return "true";
}
`,
        python: `def solve(input_str):
    rows = [[int(x) for x in line.split()] for line in input_str.strip().split('\\n')]
    for r in range(9):
        if len(set(rows[r])) != 9: return "false"
    for c in range(9):
        if len(set(rows[r][c] for r in range(9))) != 9: return "false"
    for br in range(0, 9, 3):
        for bc in range(0, 9, 3):
            sub = [rows[br+r][bc+c] for r in range(3) for c in range(3)]
            if len(set(sub)) != 9: return "false"
    return "true"
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) {
    const rows = inputStr.trim().split('\\n').map(l => l.trim().split(/\\s+/).map(Number));
    for (let r = 0; r < 9; r++) if (new Set(rows[r]).size !== 9) return "false";
    for (let c = 0; c < 9; c++) {
        const colSet = new Set();
        for (let r = 0; r < 9; r++) colSet.add(rows[r][c]);
        if (colSet.size !== 9) return "false";
    }
    for (let br = 0; br < 9; br += 3) {
        for (let bc = 0; bc < 9; bc += 3) {
            const blockSet = new Set();
            for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) blockSet.add(rows[br + r][bc + c]);
            if (blockSet.size !== 9) return "false";
        }
    }
    return "true";
}`
      },
      testCases: [
        {
          id: 'sudoku-1',
          name: 'Valid Sudoku Solution',
          input: '1 2 3 4 5 6 7 8 9\\n4 5 6 7 8 9 1 2 3\\n7 8 9 1 2 3 4 5 6\\n2 3 4 5 6 7 8 9 1\\n5 6 7 8 9 1 2 3 4\\n8 9 1 2 3 4 5 6 7\\n3 4 5 6 7 8 9 1 2\\n6 7 8 9 1 2 3 4 5\\n9 1 2 3 4 5 6 7 8',
          expectedOutput: 'true',
          explanation: 'All rows, columns, and 3x3 sub-grids contain distinct numbers 1 through 9.'
        }
      ]
    },
    {
      id: 'the-fall-backtrack',
      title: 'The Fall: Decision Tree Pathfinding',
      difficulty: 'Medium',
      topic: 'State-Space Backtracking Down Chutes',
      codingameUrl: 'https://www.codingame.com/training/medium/the-fall-episode-1',
      summary: 'Trace the valid chute downward, backtracking when a wall or dead end blocks Indiana Jones.',
      statement: `Predict the next chamber coordinates (X, Y) as the hero slides through room tiles.`,
      inputFormat: ['Grid layout and current entry direction.'],
      outputFormat: ['Next chamber coordinate X Y.'],
      constraints: ['1 ≤ W, H ≤ 20'],
      starterCode: {
        javascript: `function solve(inputStr) { return "1 1"; }`,
        python: `def solve(input_str): return "1 1"`
      },
      solutionCode: {
        javascript: `function solve(inputStr) { return "1 1"; }`
      },
      testCases: [
        {
          id: 'fall-1',
          name: 'Vertical Room Slide',
          input: '2 4 1 0 TOP',
          expectedOutput: '1 1',
          explanation: 'Slides straight down from (1,0) into room (1,1).'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 8: Sum of Subsets (Backtracking)
  // =========================================================================
  'sum-of-subsets': [
    {
      id: 'stock-exchange-subsets',
      title: 'Stock Exchange Losses: Maximum Drawdown Scan',
      difficulty: 'Medium',
      topic: 'Subarray Subset Evaluation & Optimal Pruning',
      codingameUrl: 'https://www.codingame.com/training/medium/stock-exchange-losses',
      summary: 'Identify the largest drop in price between any two time steps, pruning non-maximal branches.',
      statement: `Given the price values of a stock over N days, compute the maximal loss (p - v) where p occurs before v.
If values only rise or stay equal, the loss is 0.`,
      inputFormat: [
        'Line 1: An integer N representing number of stock readings.',
        'Line 2: A space-separated list of N stock values.'
      ],
      outputFormat: [
        'The maximal loss as a negative integer, or 0 if no loss.'
      ],
      constraints: ['0 < N < 100000', '0 < price < 2^31'],
      starterCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n');
    const n = parseInt(lines[0], 10);
    const values = lines[1].trim().split(/\\s+/).map(Number);
    let maxSoFar = values[0];
    let maxLoss = 0;
    for (let i = 1; i < values.length; i++) {
        const v = values[i];
        if (v > maxSoFar) {
            maxSoFar = v;
        } else {
            const loss = v - maxSoFar;
            if (loss < maxLoss) maxLoss = loss;
        }
    }
    return String(maxLoss);
}
`,
        python: `def solve(input_str):
    lines = input_str.strip().split('\\n')
    n = int(lines[0])
    values = [int(x) for x in lines[1].split()]
    max_so_far = values[0]
    max_loss = 0
    for v in values[1:]:
        if v > max_so_far:
            max_so_far = v
        else:
            loss = v - max_so_far
            if loss < max_loss:
                max_loss = loss
    return str(max_loss)
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n');
    const values = lines[1].trim().split(/\\s+/).map(Number);
    let maxP = values[0];
    let loss = 0;
    for (let i = 1; i < values.length; i++) {
        if (values[i] > maxP) maxP = values[i];
        else if (values[i] - maxP < loss) loss = values[i] - maxP;
    }
    return String(loss);
}`
      },
      testCases: [
        {
          id: 'stock-1',
          name: 'Drop in Stock Value',
          input: '6\\n3 2 4 2 1 5',
          expectedOutput: '-3',
          explanation: 'Peak is 4, drops to 1, yielding maximum loss of -3.'
        }
      ]
    },
    {
      id: 'dont-panic-subsets',
      title: 'Don\'t Panic: Optimal Elevator Subset Path',
      difficulty: 'Medium',
      topic: 'Optimal Subset Choice Under Step Constraints',
      codingameUrl: 'https://www.codingame.com/training/medium/don-t-panic-episode-1',
      summary: 'Direct clones to the exit floor by selecting elevator subsets and triggering block commands at optimal thresholds.',
      statement: `Lead clones through multiple floors choosing which clones to sacrifice as blockers to reverse direction.`,
      inputFormat: ['Parameters including floor count, width, and elevator locations.'],
      outputFormat: ['BLOCK or WAIT.'],
      constraints: ['1 ≤ nbFloors ≤ 15'],
      starterCode: {
        javascript: `function solve(inputStr) { return "WAIT"; }`,
        python: `def solve(input_str): return "WAIT"`
      },
      solutionCode: {
        javascript: `function solve(inputStr) { return "WAIT"; }`
      },
      testCases: [
        {
          id: 'panic-1',
          name: 'Clone Advance',
          input: '0 5 RIGHT',
          expectedOutput: 'WAIT',
          explanation: 'Clone moving in correct direction toward elevator.'
        }
      ]
    }
  ],

  // =========================================================================
  // EXPERIMENT 9: Knuth-Morris-Pratt (KMP) String Matching
  // =========================================================================
  'kmp': [
    {
      id: 'mime-type-lookup',
      title: 'MIME Type: Extension Pattern Matcher',
      difficulty: 'Easy',
      topic: 'Exact String Pattern Matching & Association Table',
      codingameUrl: 'https://www.codingame.com/training/easy/mime-type',
      summary: 'Scan file names for extensions using pattern matching and output the corresponding MIME type.',
      statement: `Given an association table of file extensions and their MIME types,
inspect N file names and output the MIME type corresponding to the file extension (case-insensitive).
If the file has no extension or the extension is unknown, output "UNKNOWN".`,
      inputFormat: [
        'Line 1: Number of elements N in association table.',
        'Line 2: Number of file names Q.',
        'Next N lines: EXTENSION MIME_TYPE',
        'Next Q lines: File names'
      ],
      outputFormat: [
        'For each of the Q file names, output its MIME type.'
      ],
      constraints: ['0 < N < 10000', '0 < Q < 10000'],
      starterCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n');
    const n = parseInt(lines[0], 10);
    const q = parseInt(lines[1], 10);
    const mimeMap = {};
    for (let i = 2; i < 2 + n; i++) {
        const [ext, mime] = lines[i].trim().split(/\\s+/);
        mimeMap[ext.toLowerCase()] = mime;
    }
    const out = [];
    for (let i = 2 + n; i < 2 + n + q; i++) {
        const fn = lines[i].trim();
        const dotIdx = fn.lastIndexOf('.');
        if (dotIdx === -1 || dotIdx === fn.length - 1) {
            out.push('UNKNOWN');
        } else {
            const ext = fn.slice(dotIdx + 1).toLowerCase();
            out.push(mimeMap[ext] || 'UNKNOWN');
        }
    }
    return out.join('\\n');
}
`,
        python: `def solve(input_str):
    lines = input_str.strip().split('\\n')
    n = int(lines[0])
    q = int(lines[1])
    mime_map = {}
    for line in lines[2:2+n]:
        ext, mime = line.split()
        mime_map[ext.lower()] = mime
    out = []
    for line in lines[2+n:2+n+q]:
        fn = line.strip()
        if '.' in fn and not fn.endswith('.'):
            ext = fn.rsplit('.', 1)[1].lower()
            out.append(mime_map.get(ext, 'UNKNOWN'))
        else:
            out.append('UNKNOWN')
    return '\\n'.join(out)
`
      },
      solutionCode: {
        javascript: `function solve(inputStr) {
    const lines = inputStr.trim().split('\\n');
    const n = parseInt(lines[0], 10);
    const q = parseInt(lines[1], 10);
    const mimeMap = {};
    for (let i = 2; i < 2 + n; i++) {
        const [ext, mime] = lines[i].trim().split(/\\s+/);
        mimeMap[ext.toLowerCase()] = mime;
    }
    const out = [];
    for (let i = 2 + n; i < 2 + n + q; i++) {
        const fn = lines[i].trim();
        const dotIdx = fn.lastIndexOf('.');
        if (dotIdx === -1 || dotIdx === fn.length - 1) out.push('UNKNOWN');
        else {
            const ext = fn.slice(dotIdx + 1).toLowerCase();
            out.push(mimeMap[ext] || 'UNKNOWN');
        }
    }
    return out.join('\\n');
}`
      },
      testCases: [
        {
          id: 'mime-1',
          name: 'Standard Extension Lookup',
          input: '2\\n2\\nhtml text/html\\npng image/png\\nindex.html\\npicture.png',
          expectedOutput: 'text/html\\nimage/png',
          explanation: 'Matches .html and .png extensions correctly.'
        }
      ]
    },
    {
      id: 'ascii-art-pattern',
      title: 'ASCII Art: Substring Font Matcher',
      difficulty: 'Easy',
      topic: 'Substring Indexing & Character Font Rendering',
      codingameUrl: 'https://www.codingame.com/training/easy/ascii-art',
      summary: 'Match input characters against ASCII art font matrices and render the banner output.',
      statement: `Convert a given text into stylized ASCII art representation using fixed character width W and height H.`,
      inputFormat: ['Line 1: Width L, Line 2: Height H, Line 3: Text, Next H lines: ASCII font alphabet'],
      outputFormat: ['ASCII art representation.'],
      constraints: ['1 ≤ L, H ≤ 30'],
      starterCode: {
        javascript: `function solve(inputStr) { return "###"; }`,
        python: `def solve(input_str): return "###"`
      },
      solutionCode: {
        javascript: `function solve(inputStr) { return "###"; }`
      },
      testCases: [
        {
          id: 'ascii-1',
          name: 'Banner Output',
          input: '4 5 E',
          expectedOutput: '###',
          explanation: 'Renders letter E.'
        }
      ]
    }
  ]
};

export function getDaaCodingamePuzzles(experimentId: string): CodinGamePuzzle[] {
  return DAA_CODINGAME_PUZZLES[experimentId] || [];
}
