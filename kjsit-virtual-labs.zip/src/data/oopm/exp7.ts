import { LabExperiment } from '../../types';

export const oopmExp7: LabExperiment = {
  id: 'oopm-exp7',
  num: 7,
  subjectId: 'oopm',
  title: 'Exception Handling in Java (Bank Withdrawal Simulation)',
  subtitle: 'try-catch-finally Blocks, Checked vs. Unchecked Exceptions, throw/throws Keywords & Custom InsufficientBalanceException',
  category: 'Exception Handling & Robustness',
  iitReference: 'K. J. Somaiya Institute of Technology / OOPM Lab Manual Experiment No. 7',
  software: 'VS Code',
  aim: 'To study and implement Exception Handling in Java using try, catch, finally, throw, and throws keywords to handle runtime errors and develop robust Java applications (Simulate a simple bank withdrawal system throwing a user-defined InsufficientBalanceException).',
  objective: 'To safeguard application runtime integrity against unforeseen exceptions, distinguishing compiler-checked from unchecked exceptions, and designing domain-specific custom exception classes.',
  labObjectives: [
    'Understand the concept of exceptions and exception handling in Java.',
    'Identify different types of exceptions such as checked and unchecked exceptions.',
    'Implement exception handling using try, catch, and finally blocks.',
    'Use throw and throws to explicitly handle and propagate exceptions.',
    'Handle multiple exceptions appropriately in a Java program.',
    'Develop robust programs that can handle runtime errors without abnormal termination.'
  ],
  theory: {
    overview: [
      'An exception is an abnormal condition or unexpected event that occurs during the execution of a program and interrupts its normal instruction flow (e.g., dividing by zero, accessing an invalid array index, invalid numerical input, or missing files). Java provides a structured exception handling mechanism to detect, catch, and handle such runtime anomalies.',
      'Types of Exceptions in Java: 1) Checked Exceptions: Checked by the compiler during compilation. The programmer MUST handle them using try-catch blocks or declare them in the method signature using the "throws" keyword (e.g. IOException, FileNotFoundException, SQLException). 2) Unchecked Exceptions: Occur at runtime and are subclasses of RuntimeException; the compiler does not enforce handling (e.g. ArithmeticException, ArrayIndexOutOfBoundsException, NullPointerException, NumberFormatException).',
      'The 5 Core Exception Handling Keywords: 1. try: Encloses code that may potentially generate an exception. 2. catch: Catches and handles specific exception objects thrown in try. 3. finally: Executes cleanup routines unconditionally, whether an exception occurred or not. 4. throw: Explicitly generates and raises an exception object. 5. throws: Declares in a method signature that the method may propagate one or more checked exceptions to its caller.',
      'User-Defined (Custom) Exceptions: In financial, medical, and enterprise systems, developers create custom exception classes extending java.lang.Exception to encapsulate business logic failures, such as throwing InsufficientBalanceException when withdrawal amount exceeds available balance.'
    ],
    complexityTable: [
      { parameter: 'Normal Execution (no exception)', value: 'Zero runtime overhead (zero-cost exception model)' },
      { parameter: 'Exception Throw & Stack Unwind', value: 'O(D) where D is stack call-frame depth to catch block' },
      { parameter: 'Custom Exception Instantiation', value: 'O(1) - Instantiation of Exception payload with message' },
      { parameter: 'Finally Block Execution', value: 'Guaranteed O(1) invocation before method exit' }
    ],
    keyPoints: [
      'Checked exceptions must be either caught or declared via throws; unchecked exceptions are optional.',
      'Custom exceptions extend Exception (checked) or RuntimeException (unchecked).',
      'The finally block is always executed, even if a return statement or exception occurs in try or catch.',
      'Exception handling prevents abnormal termination, preserving user data and terminal stability.',
      'Use getMessage() or printStackTrace() to retrieve diagnostic error logs.'
    ],
    realWorldApplications: [
      'Banking transaction safeguards preventing negative account balances and fraudulent overdrafts.',
      'Secure web APIs intercepting invalid authentication tokens and generating HTTP 401/403 responses.',
      'Database transaction rollbacks during SQL constraint violations to preserve ACID compliance.'
    ]
  },
  algorithm: [
    'Steps for Bank Withdrawal Simulation:',
    '1. Start the program.',
    '2. Define a user-defined checked exception class named InsufficientBalanceException extending java.lang.Exception.',
    '3. Create class BankWithdrawal with static method withdraw(double balance, double amount) throws InsufficientBalanceException.',
    '4. Inside withdraw(): compare withdrawal amount with account balance.',
    '5. If amount > balance: throw new InsufficientBalanceException("Insufficient balance! Withdrawal amount exceeds account balance.").',
    '6. Otherwise: calculate remaining balance = balance - amount, and display "Withdrawal successful!" and updated remaining balance.',
    '7. In main(): accept account balance and withdrawal amount from user via Scanner.',
    '8. Place the call withdraw(balance, amount) inside a try block.',
    '9. Handle InsufficientBalanceException using a catch block and display e.getMessage().',
    '10. Close Scanner resource and stop the program.'
  ],
  procedure: [
    '1. Open VS Code and create BankWithdrawal.java.',
    '2. Declare class InsufficientBalanceException extends Exception with super(message) constructor.',
    '3. Implement withdraw() method with throws InsufficientBalanceException check.',
    '4. In main(), read balance and amount from standard input.',
    '5. Enclose withdraw() in a try-catch block catching InsufficientBalanceException.',
    '6. Test Case 1: Enter balance 10000, amount 3000 -> Verify successful withdrawal of 7000.',
    '7. Test Case 2: Enter balance 5000, amount 7000 -> Verify graceful capture of InsufficientBalanceException.'
  ],
  code: {
    java: `// ==========================================
// K. J. Somaiya Institute of Technology
// Experiment No. 7: Exception Handling in Java
// Bank Withdrawal with Custom Exception
// ==========================================

import java.util.Scanner;

// User-defined exception
class InsufficientBalanceException extends Exception {
    public InsufficientBalanceException(String message) {
        super(message);
    }
}

public class BankWithdrawal {
    // Method to perform withdrawal
    static void withdraw(double balance, double amount)
            throws InsufficientBalanceException {
        if (amount > balance) {
            throw new InsufficientBalanceException(
                "Insufficient balance! Withdrawal amount exceeds account balance."
            );
        }
        double remainingBalance = balance - amount;
        System.out.println("Withdrawal successful!");
        System.out.println("Remaining balance: " + remainingBalance);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter account balance: ");
        double balance = sc.nextDouble();

        System.out.print("Enter withdrawal amount: ");
        double amount = sc.nextDouble();

        try {
            withdraw(balance, amount);
        } catch (InsufficientBalanceException e) {
            System.out.println(e.getMessage());
        } finally {
            System.out.println("Transaction processing completed.");
        }

        sc.close();
    }
}`,
    cpp: `#include <iostream>
#include <stdexcept>
#include <string>

// Custom Exception in C++
class InsufficientBalanceException : public std::runtime_error {
public:
    InsufficientBalanceException(const std::string& msg)
        : std::runtime_error(msg) {}
};

void withdraw(double balance, double amount) {
    if (amount > balance) {
        throw InsufficientBalanceException("Insufficient balance! Withdrawal amount exceeds account balance.");
    }
    double remaining = balance - amount;
    std::cout << "Withdrawal successful!\\nRemaining balance: " << remaining << "\\n";
}

int main() {
    double balance = 10000, amount = 3000;
    try {
        withdraw(balance, amount);
    } catch (const InsufficientBalanceException& e) {
        std::cout << e.what() << "\\n";
    }
    return 0;
}`
  },
  sampleInput: `Test Case 1 (Success):
10000
3000

Test Case 2 (Exception):
5000
7000`,
  expectedOutput: `Sample Output 1 — Successful withdrawal:
Enter account balance: 10000
Enter withdrawal amount: 3000
Withdrawal successful!
Remaining balance: 7000.0
Transaction processing completed.

Sample Output 2 — Exception occurs:
Enter account balance: 5000
Enter withdrawal amount: 7000
Insufficient balance! Withdrawal amount exceeds account balance.
Transaction processing completed.`,
  conclusion: 'Thus, the Java program successfully demonstrates exception handling using try, catch, finally, throw, and throws keywords. By creating a custom user-defined InsufficientBalanceException, the program prevents invalid financial deductions and ensures application robustness and graceful error recovery without abnormal crash.',
  postLabQuestions: [
    {
      question: 'What is the primary difference between checked and unchecked exceptions in Java?',
      answer: 'Checked exceptions are verified at compile-time by the Java compiler and must be handled using try-catch or declared with throws (e.g. IOException). Unchecked exceptions extend RuntimeException and occur at runtime; the compiler does not mandate their handling (e.g. ArithmeticException, NullPointerException).'
    },
    {
      question: 'What is the role of the finally block in exception handling?',
      answer: 'The finally block executes unconditionally after try and catch blocks, regardless of whether an exception was raised, caught, or even if a return statement was encountered, making it essential for resource deallocation (closing files, DB connections, sockets).'
    },
    {
      question: 'How do the "throw" and "throws" keywords differ?',
      answer: '"throw" is an executable statement used to explicitly instantiate and raise an exception object (e.g. throw new Exception()). "throws" is a clause in a method signature that declares the types of checked exceptions the method might propagate up the call stack.'
    },
    {
      question: 'How do you create a custom user-defined checked exception in Java?',
      answer: 'Create a class that extends java.lang.Exception and implement a constructor that passes the custom descriptive error message to the superclass constructor using super(message).'
    },
    {
      question: 'Can a single try block be associated with multiple catch blocks?',
      answer: 'Yes, multiple catch blocks can handle different exception types sequentially, ordered from the most specific child exception to the most general parent exception (e.g., catching InsufficientBalanceException first, followed by Exception).'
    }
  ],
  references: [
    'KJSIT Autonomous Syllabus / OOPM Lab Manual (Department of AI & DS)',
    'Herbert Schildt, "Java: The Complete Reference", McGraw-Hill',
    'Oracle Java SE Documentation - Exceptions Lesson'
  ],
  quiz: [
    {
      id: 1,
      question: 'Which superclass is at the root of the Java exception hierarchy?',
      options: ['java.lang.Exception', 'java.lang.Throwable', 'java.lang.Error', 'java.lang.RuntimeException'],
      correctAnswer: 1,
      explanation: 'java.lang.Throwable is the root class of all exceptions and errors in the Java language.'
    },
    {
      id: 2,
      question: 'Which of the following is a checked exception in Java?',
      options: ['NullPointerException', 'ArrayIndexOutOfBoundsException', 'IOException', 'ArithmeticException'],
      correctAnswer: 2,
      explanation: 'IOException is a checked exception that must be declared with throws or enclosed in try-catch.'
    },
    {
      id: 3,
      question: 'Under what condition does a finally block NOT execute?',
      options: [
        'When an uncaught exception occurs',
        'When System.exit(0) is called inside try or catch',
        'When a return statement is encountered in catch',
        'When the try block finishes successfully'
      ],
      correctAnswer: 1,
      explanation: 'System.exit(0) terminates the JVM process immediately, preventing finally execution.'
    },
    {
      id: 4,
      question: 'To create a user-defined checked exception, which class must your custom class extend?',
      options: ['java.lang.Throwable', 'java.lang.Exception', 'java.lang.RuntimeException', 'java.lang.Object'],
      correctAnswer: 1,
      explanation: 'Extending java.lang.Exception directly creates a checked exception in Java.'
    }
  ]
};
