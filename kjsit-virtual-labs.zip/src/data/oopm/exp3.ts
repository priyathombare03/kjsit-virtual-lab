import { LabExperiment } from '../../types';

export const oopmExp3: LabExperiment = {
  id: 'oopm-exp3',
  num: 3,
  subjectId: 'oopm',
  title: 'Classes and Objects in Java',
  subtitle: 'Class Blueprint, Object Instantiation, Field Encapsulation & Method Invocation (Student & Employee)',
  category: 'Classes & Objects',
  iitReference: 'K. J. Somaiya Institute of Technology / OOPM Lab Manual Experiment No. 3',
  software: 'VS Code',
  aim: 'To study and implement the concept of Classes and Objects in Java by creating a Student class and accessing its data through an object.',
  objective: 'To grasp the foundational principles of Object-Oriented Programming (OOP) in Java by creating user-defined templates, allocating heap instances using the "new" keyword, and manipulating member states via methods.',
  labObjectives: [
    'Understand the basic concepts of classes and objects in Java.',
    'Create a user-defined Student class with appropriate data members and methods.',
    'Create and initialize objects of a class in Java.',
    'Access and manipulate class data members and methods using objects.',
    'Apply the concepts of classes and objects to solve a simple real-world problem.',
    'Develop a Java program demonstrating object creation and interaction with class members.'
  ],
  theory: {
    overview: [
      'A class is a blueprint or template used to create objects. It defines the state (represented by data members or variables) and the behavior (represented by member functions or methods) that objects instantiated from the class will possess.',
      'An object is a distinct instance of a class. It occupies physical memory on the Java virtual machine (JVM) heap and provides access to the variables and methods defined within the class structure.',
      'Key Advantages of Classes and Objects: 1) Promotes code reusability through modular components. 2) Supports encapsulation by bundling data and operations together. 3) Makes programs modular, readable, and easy to maintain. 4) Naturally represents real-world entities (e.g., Students, Employees, Bank Accounts).',
      'In Java, memory for an object is dynamically allocated at runtime using the "new" operator, which returns a reference to the created heap instance. Member variables and methods are then accessed using the dot (.) operator.'
    ],
    complexityTable: [
      { parameter: 'Object Heap Allocation', value: 'O(1) - JVM generational heap allocation' },
      { parameter: 'Direct Field Access (dot operator)', value: 'O(1) - Direct offset displacement' },
      { parameter: 'Method Invocation (displayDetails)', value: 'O(1) - Virtual method dispatch via vtable' },
      { parameter: 'Instance Footprint', value: 'JVM Object Header (12-16B) + Primitive Fields' }
    ],
    keyPoints: [
      'A class declaration does not allocate memory; memory is only allocated when an object is created with "new".',
      'Multiple independent instances can be created from a single class blueprint, each holding its own state.',
      'The dot operator (.) is used to access object variables and invoke object methods.',
      'Separating state initialization and display methods promotes high cohesion and clean architecture.',
      'Reference variables reside on the call stack, pointing to object payloads located on the JVM heap.'
    ],
    realWorldApplications: [
      'Academic student management systems tracking roll numbers, department branches, and semester marks.',
      'Enterprise payroll systems modeling Employee ID, department designation, and monthly compensation.',
      'IoT environmental sensor telemetry tracking TemperatureRecord objects with humidity metrics.'
    ]
  },
  algorithm: [
    'Algorithm (Programme 3.1: Student Class):',
    '1. Define a class named Student.',
    '2. Declare data members: rollNo (int), name (String), branch (String), and marks (double).',
    '3. Create a method displayDetails() to print formatted student details.',
    '4. Create a main class StudentDemo with public static void main(String args[]).',
    '5. Create an object of the Student class using: Student s1 = new Student();',
    '6. Assign values to the object\'s data members: s1.rollNo = 101, s1.name = "Rahul", s1.branch = "AI & DS", s1.marks = 85.5.',
    '7. Call the displayDetails() method (s1.displayDetails()).',
    '8. Display the output and stop the program.'
  ],
  procedure: [
    '1. Open VS Code and create StudentDemo.java.',
    '2. Declare class Student with data members: rollNo, name, branch, and marks.',
    '3. Implement displayDetails() method with console print formatting.',
    '4. In StudentDemo main, instantiate Student using the "new" operator.',
    '5. Assign values to each field and invoke s1.displayDetails().',
    '6. Compile (javac StudentDemo.java) and run (java StudentDemo) to verify expected output.'
  ],
  code: {
    java: `// ==========================================
// K. J. Somaiya Institute of Technology
// Experiment No. 3: Classes and Objects
// Programme 3.1: Student Class
// ==========================================

// Program to demonstrate Classes and Objects
class Student {
    // Data members
    int rollNo;
    String name;
    String branch;
    double marks;

    // Method to display student details
    void displayDetails() {
        System.out.println("----- Student Details -----");
        System.out.println("Roll No : " + rollNo);
        System.out.println("Name    : " + name);
        System.out.println("Branch  : " + branch);
        System.out.println("Marks   : " + marks);
    }
}

public class StudentDemo {
    public static void main(String[] args) {
        // Creating an object of Student class
        Student s1 = new Student();

        // Assigning values to data members
        s1.rollNo = 101;
        s1.name = "Rahul";
        s1.branch = "AI & DS";
        s1.marks = 85.5;

        // Accessing data through object
        s1.displayDetails();
    }
}

/*
// Practice Program: Employee Class
class Employee {
    int empId;
    String empName;
    double salary;

    // Method to initialize employee details
    void setEmployee(int id, String name, double sal) {
        empId = id;
        empName = name;
        salary = sal;
    }

    // Method to display employee details
    void displayEmployee() {
        System.out.println("Employee ID   : " + empId);
        System.out.println("Employee Name : " + empName);
        System.out.println("Salary        : " + salary);
    }

    public static void main(String[] args) {
        Employee emp = new Employee();
        emp.setEmployee(101, "Rahul Sharma", 55000.00);
        emp.displayEmployee();
    }
}
*/`,
    cpp: `#include <iostream>
#include <string>

class Student {
public:
    int rollNo;
    std::string name;
    std::string branch;
    double marks;

    void displayDetails() {
        std::cout << "----- Student Details -----\\n";
        std::cout << "Roll No : " << rollNo << "\\n";
        std::cout << "Name    : " << name << "\\n";
        std::cout << "Branch  : " << branch << "\\n";
        std::cout << "Marks   : " << marks << "\\n";
    }
};

int main() {
    Student s1;
    s1.rollNo = 101;
    s1.name = "Rahul";
    s1.branch = "AI & DS";
    s1.marks = 85.5;
    s1.displayDetails();
    return 0;
}`
  },
  sampleInput: `(Static initialization in main: Roll=101, Name="Rahul", Branch="AI & DS", Marks=85.5)`,
  expectedOutput: `----- Student Details -----
Roll No : 101
Name    : Rahul
Branch  : AI & DS
Marks   : 85.5`,
  conclusion: 'The program was executed successfully. It demonstrated the creation of classes and objects, object instantiation, data member access, and method invocation, thereby illustrating the basic concepts of Object-Oriented Programming (OOP) in Java.',
  postLabQuestions: [
    {
      question: 'What is the fundamental difference between a class and an object?',
      answer: 'A class is a logical blueprint or template defining the structure and behavior of a concept without occupying physical heap memory. An object is a concrete, physical instance of that class created in memory with its own independent state.'
    },
    {
      question: 'What is the role of the "new" keyword in Java object creation?',
      answer: 'The "new" keyword dynamically allocates memory on the JVM heap for a new object instance, invokes the appropriate constructor to initialize its members, and returns a reference to that allocated heap space.'
    },
    {
      question: 'What operator is used to access members of a class in Java?',
      answer: 'The dot (.) operator is used to access instance variables and call member methods on an object reference.'
    },
    {
      question: 'How does object encapsulation improve software maintenance?',
      answer: 'Encapsulation restricts direct external access to internal data members and bundles operations into coherent methods, minimizing bugs from unexpected state mutations and allowing internal refactoring without breaking external code.'
    },
    {
      question: 'Practice Exercise: How would you design a TemperatureRecord class?',
      answer: 'Define a class TemperatureRecord with fields "double temperature" and "double humidity", a method setRecord(double t, double h) or constructor, and a method displayRecord() to print weather readings formatted on console.'
    }
  ],
  references: [
    'KJSIT Autonomous Syllabus / OOPM Lab Manual (Department of AI & DS)',
    'James Gosling, Bill Joy, Guy Steele, "The Java Language Specification", Addison-Wesley',
    'Cay S. Horstmann, "Core Java Volume I--Fundamentals", 12th Edition, Prentice Hall'
  ],
  quiz: [
    {
      id: 1,
      question: 'Where are objects physically stored in the Java memory architecture?',
      options: ['Call Stack', 'Heap Memory', 'Method Area / Metaspace', 'CPU Registers'],
      correctAnswer: 1,
      explanation: 'All Java objects are allocated dynamically on the Heap, while reference variables reside on the Stack.'
    },
    {
      id: 2,
      question: 'What default value does an uninitialized numeric instance variable (e.g. double marks) receive in Java?',
      options: ['0.0', 'garbage memory value', 'null', 'NaN'],
      correctAnswer: 0,
      explanation: 'In Java, instance variables are automatically assigned default values upon object instantiation (0 for int, 0.0 for double, false for boolean, null for references).'
    },
    {
      id: 3,
      question: 'Which of the following best describes an object?',
      options: ['A data type definition', 'An instance of a class occupying memory', 'A compiled bytecode file', 'A package namespace'],
      correctAnswer: 1,
      explanation: 'An object is a specific, instantiated occurrence of a class blueprint in runtime memory.'
    },
    {
      id: 4,
      question: 'Can a single Java class be used to create multiple objects?',
      options: ['No, each class allows exactly one object', 'Yes, arbitrarily many independent objects can be instantiated', 'Only if the class is marked static', 'Only up to 10 objects'],
      correctAnswer: 1,
      explanation: 'A class serves as a reusable factory; you can create as many instances as available memory permits.'
    }
  ]
};
