import { LabExperiment } from '../../types';

export const oopmExp1: LabExperiment = {
  id: 'oopm-exp1',
  num: 1,
  subjectId: 'oopm',
  title: 'Demonstration of User Input Techniques in Java',
  subtitle: 'Comparative Implementation of Scanner and BufferedReader Classes with Data Conversion',
  category: 'Java Fundamentals & I/O',
  iitReference: 'K. J. Somaiya Institute of Technology / OOPM Lab Manual Experiment No. 1',
  software: 'VS Code',
  aim: 'Write a program to demonstrate different ways of accepting user input in Java by entering Person details (Name, age, city, pin) using Scanner as well as BufferedReader class.',
  objective: 'To master character and byte stream abstractions in Java I/O, comparing formatted token parsing (Scanner) with synchronous line-buffered reading (BufferedReader & InputStreamReader).',
  labObjectives: [
    'Understand different techniques for accepting user input in Java.',
    'Use the Scanner class to read different types of data such as integers, floating-point numbers, characters, and strings.',
    'Apply BufferedReader and InputStreamReader for accepting input from the keyboard.',
    'Implement command-line arguments to accept input during program execution.',
    'Compare different user-input techniques based on their syntax, data types, and ease of use.',
    'Develop a Java program that accepts and processes user-provided data using appropriate input methods.'
  ],
  theory: {
    overview: [
      'Java brings various Streams with its I/O package (java.io) that helps the user to perform all input-output operations. These streams support all types of objects, data types, characters, and files to fully execute I/O operations.',
      '1. BufferedReader: It is a simple class used to read a sequence of characters from a character-input stream. It provides functions such as read() to read a single character or array of characters, and readLine() to read a complete line of text. InputStreamReader() functions as a bridge that converts the input stream of raw bytes from System.in into a stream of characters so that it can be buffered and read by BufferedReader. BufferedReader throws checked IOException which must be caught or declared.',
      '2. Scanner: An advanced scanner added in Java 5 (java.util package). The Scanner class reads and parses formatted input into primitive types and strings using regular expressions. It provides convenient methods such as nextLine(), nextInt(), nextDouble(), and nextBoolean(), eliminating the need to write throws clauses for checked exceptions.',
      'Comparison: BufferedReader has a significantly larger buffer memory (8KB by default) compared to Scanner (1KB) and is thread-safe (synchronized), making it much faster for reading large inputs. Conversely, Scanner provides built-in type parsing at the expense of parsing overhead.'
    ],
    complexityTable: [
      { parameter: 'BufferedReader Read Overhead', value: 'O(1) amortized per token / synchronous 8KB memory buffer' },
      { parameter: 'Scanner Parse Overhead', value: 'O(L) regex token match per token (1KB buffer)' },
      { parameter: 'Type Parsing (Integer.parseInt)', value: 'O(D) where D is number of decimal digits' },
      { parameter: 'Thread Safety', value: 'BufferedReader is synchronized (Thread-safe); Scanner is not' }
    ],
    keyPoints: [
      'BufferedReader is imported from java.io.BufferedReader and requires InputStreamReader.',
      'Scanner is imported from java.util.Scanner.',
      'BufferedReader.readLine() always returns String; explicit parsing using Integer.parseInt() or Double.parseDouble() is required.',
      'Scanner must handle leftover newline delimiters when switching between nextInt() and nextLine().',
      'Both classes should be explicitly closed using .close() to release OS underlying file and stream descriptors.'
    ],
    realWorldApplications: [
      'High-throughput competitive programming input ingestion (Fast I/O routines).',
      'Interactive CLI terminal tools accepting customer biodata, billing details, and postal PIN codes.',
      'Parsing structured log feeds and file pipelines line by line in production servers.'
    ]
  },
  algorithm: [
    'Method 1: Using Scanner Class:',
    '1. Start the program.',
    '2. Import the Scanner class (java.util.Scanner).',
    '3. Create a Scanner object (Scanner sc = new Scanner(System.in)) to read input from the keyboard.',
    '4. Declare variables for name (String), age (int), city (String), and pin (int).',
    '5. Accept the Name using sc.nextLine().',
    '6. Accept the Age using sc.nextInt() and consume newline via sc.nextLine().',
    '7. Accept the City using sc.nextLine().',
    '8. Accept the PIN using sc.nextInt().',
    '9. Display all the entered person details.',
    '10. Close the Scanner object (sc.close()).',
    '11. Stop.',
    '',
    'Method 2: Using BufferedReader Class:',
    '1. Start the program.',
    '2. Import BufferedReader, InputStreamReader, and IOException from java.io.*.',
    '3. Create a BufferedReader object connected to System.in: new BufferedReader(new InputStreamReader(System.in)).',
    '4. Declare variables for name, age, city, and pin.',
    '5. Accept the Name using br.readLine().',
    '6. Accept the Age using br.readLine() and convert it to an integer using Integer.parseInt().',
    '7. Accept the City using br.readLine().',
    '8. Accept the PIN using br.readLine() and convert it to an integer using Integer.parseInt().',
    '9. Display all the entered person details.',
    '10. Close the BufferedReader object (br.close()).',
    '11. Stop.'
  ],
  procedure: [
    '1. Open VS Code or integrated Java compiler terminal.',
    '2. Create PersonDetailsScanner.java implementing Method 1.',
    '3. Compile using javac PersonDetailsScanner.java and run with java PersonDetailsScanner.',
    '4. Supply test input: Name, Age, City, PIN.',
    '5. Create PersonDetailsBufferedReader.java implementing Method 2 with IOException signature.',
    '6. Verify type casting with Integer.parseInt() and verify terminal output matches format.'
  ],
  code: {
    java: `// ==========================================
// K. J. Somaiya Institute of Technology
// Experiment No. 1: User Input Handling
// ==========================================

// Method 1: Using Scanner Class
import java.util.Scanner;

public class PersonDetailsScanner {
    public static void main(String[] args) {
        // Create Scanner object
        Scanner sc = new Scanner(System.in);

        // Declare variables
        String name, city;
        int age, pin;

        // Accept person details
        System.out.print("Enter Name: ");
        name = sc.nextLine();

        System.out.print("Enter Age: ");
        age = sc.nextInt();
        sc.nextLine(); // Consume newline

        System.out.print("Enter City: ");
        city = sc.nextLine();

        System.out.print("Enter PIN: ");
        pin = sc.nextInt();

        // Display person details
        System.out.println("\\n--- Person Details ---");
        System.out.println("Name : " + name);
        System.out.println("Age  : " + age);
        System.out.println("City : " + city);
        System.out.println("PIN  : " + pin);

        // Close Scanner
        sc.close();
    }
}

/*
// Method 2: Using BufferedReader Class
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class PersonDetailsBufferedReader {
    public static void main(String[] args) throws IOException {
        // Create BufferedReader object
        BufferedReader br = new BufferedReader(
            new InputStreamReader(System.in)
        );

        // Declare variables
        String name, city;
        int age, pin;

        // Accept person details
        System.out.print("Enter Name: ");
        name = br.readLine();

        System.out.print("Enter Age: ");
        age = Integer.parseInt(br.readLine());

        System.out.print("Enter City: ");
        city = br.readLine();

        System.out.print("Enter PIN: ");
        pin = Integer.parseInt(br.readLine());

        // Display person details
        System.out.println("\\n--- Person Details ---");
        System.out.println("Name : " + name);
        System.out.println("Age  : " + age);
        System.out.println("City : " + city);
        System.out.println("PIN  : " + pin);

        // Close BufferedReader
        br.close();
    }
}
*/`,
    cpp: `#include <iostream>
#include <string>

int main() {
    std::string name, city;
    int age, pin;

    std::cout << "Enter Name: ";
    std::getline(std::cin, name);

    std::cout << "Enter Age: ";
    std::cin >> age;
    std::cin.ignore();

    std::cout << "Enter City: ";
    std::getline(std::cin, city);

    std::cout << "Enter PIN: ";
    std::cin >> pin;

    std::cout << "\\n--- Person Details ---\\n";
    std::cout << "Name : " << name << "\\n";
    std::cout << "Age  : " << age << "\\n";
    std::cout << "City : " << city << "\\n";
    std::cout << "PIN  : " << pin << "\\n";
    return 0;
}`
  },
  sampleInput: `Rahul Sharma
25
Mumbai
400001`,
  expectedOutput: `Enter Name: Rahul Sharma
Enter Age: 25
Enter City: Mumbai
Enter PIN: 400001

--- Person Details ---
Name : Rahul Sharma
Age  : 25
City : Mumbai
PIN  : 400001`,
  conclusion: 'Thus, the Java program was successfully implemented to accept and display Person details (Name, Age, City, and PIN) using both the Scanner and BufferedReader classes. The experiment demonstrated different methods of accepting user input and converting string input into appropriate data types in Java.',
  postLabQuestions: [
    {
      question: 'What are the different ways of accepting user input in Java?',
      answer: 'The primary techniques include: 1) Scanner class (from java.util), 2) BufferedReader combined with InputStreamReader (from java.io), 3) Command-line arguments (String[] args), and 4) System.console() for secure console inputs.'
    },
    {
      question: 'What is the difference between Scanner and BufferedReader?',
      answer: 'Scanner provides built-in parsing for primitive types via regular expressions and has a 1KB buffer; it is not thread-safe. BufferedReader reads raw character sequences into an 8KB buffer, is thread-safe (synchronized), and is significantly faster, but requires explicit manual parsing (e.g., Integer.parseInt) and checked exception handling (IOException).'
    },
    {
      question: 'Which method is used by Scanner to read an integer and a string?',
      answer: 'Scanner uses nextInt() to read an integer token and nextLine() (or next()) to read a String.'
    },
    {
      question: 'Why is Integer.parseInt() used with BufferedReader?',
      answer: 'BufferedReader.readLine() strictly returns data as a String. To store and compute numerical values as primitive ints, Integer.parseInt() must be used to parse the string into an integer.'
    },
    {
      question: 'What are command-line arguments in Java, and how are they used to accept input?',
      answer: 'Command-line arguments are parameters passed directly to the program when executing from the terminal (e.g., java App val1 val2). They are captured as an array of Strings in main(String[] args) and accessed via zero-based indexing (args[0], args[1]).'
    }
  ],
  references: [
    'KJSIT Autonomous Syllabus / OOPM Lab Manual (Department of AI & DS)',
    'Herbert Schildt, "Java: The Complete Reference", 12th Edition, McGraw-Hill',
    'Oracle Java SE Documentation - java.util.Scanner & java.io.BufferedReader'
  ],
  quiz: [
    {
      id: 1,
      question: 'Which package contains the Scanner class in Java?',
      options: ['java.io', 'java.util', 'java.lang', 'java.text'],
      correctAnswer: 1,
      explanation: 'The Scanner class is located inside the java.util package.'
    },
    {
      id: 2,
      question: 'What exception is thrown by BufferedReader.readLine() if an I/O error occurs?',
      options: ['InputMismatchException', 'IOException', 'NullPointerException', 'ArithmeticException'],
      correctAnswer: 1,
      explanation: 'BufferedReader.readLine() declares throws java.io.IOException, which is a checked exception.'
    },
    {
      id: 3,
      question: 'What is the primary role of InputStreamReader when used with BufferedReader?',
      options: [
        'To format double values to strings',
        'To convert a byte stream (System.in) into a character stream',
        'To flush the output buffer to terminal',
        'To encrypt the input data'
      ],
      correctAnswer: 1,
      explanation: 'InputStreamReader is a bridge from byte streams to character streams: it reads bytes and decodes them into characters.'
    },
    {
      id: 4,
      question: 'Why does a developer call sc.nextLine() immediately after sc.nextInt()?',
      options: [
        'To clear the system heap',
        'To consume the leftover newline character (\\n) in the input buffer',
        'To convert the integer to float',
        'To reset the scanner delimiter to whitespace'
      ],
      correctAnswer: 1,
      explanation: 'nextInt() reads only the integer token and leaves the newline generated by hitting Enter in the buffer; sc.nextLine() consumes it so subsequent reads succeed.'
    }
  ]
};
