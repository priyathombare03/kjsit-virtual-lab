import { LabExperiment } from '../../types';

export const oopmExp5: LabExperiment = {
  id: 'oopm-exp5',
  num: 5,
  subjectId: 'oopm',
  title: 'Inheritance and Method Overriding in Java',
  subtitle: 'Class Hierarchies, Superclass Reusability, MedicalTest Subclasses (5A) & Rate of Interest Overriding (5B)',
  category: 'Inheritance & Dynamic Dispatch',
  iitReference: 'K. J. Somaiya Institute of Technology / OOPM Lab Manual Experiment No. 5, 5A & 5B',
  software: 'VS Code',
  aim: 'Write a program to implement the concept of inheritance and method overriding in Java (Programme 1: Person & Employee; Experiment 5A: Healthcare MedicalTest superclass with UrineTest, BloodTest, GlucoseTest; Experiment 5B: Bank method overriding with SBI).',
  objective: 'To master the "IS-A" hierarchical relationship using the extends keyword, super constructor chaining, and runtime dynamic method overriding with the super keyword.',
  labObjectives: [
    'Understand the concept of inheritance and its importance in Java.',
    'Create a superclass and subclass using the extends keyword.',
    'Implement single and multilevel inheritance in Java programs.',
    'Reuse data members and methods of a superclass in a subclass.',
    'Access superclass members using inherited properties and methods.',
    'Apply inheritance to model relationships between classes and develop reusable Java programs.'
  ],
  theory: {
    overview: [
      'Inheritance is one of the foundational features of Object-Oriented Programming that allows us to create a new class from an existing class. The existing class is known as the superclass (parent or base class), and the newly created class is the subclass (child or derived class). Java uses the "extends" keyword to implement inheritance.',
      'Key Benefits of Inheritance: 1) Code Reusability: Subclasses inherit data fields and methods of the parent, eliminating duplication. 2) Extensibility: Child classes can add specialized attributes and behaviors without altering base logic. 3) Polymorphism: Enables dynamic method overriding and generic handling of sub-types via superclass references.',
      'Experiment 5A: Healthcare Diagnostics Modeling: A superclass MedicalTest captures common metadata (testId, patientName, testDate, displayTestDetails()). Subclasses UrineTest, BloodTest, and GlucoseTest extend MedicalTest, invoking super(testId, patientName, testDate) and appending specialized diagnostic fields (e.g. glucoseLevel in mg/dL, bloodGroup, urine result).',
      'Experiment 5B: Method Overriding and the "super" Keyword: If the exact same method signature is present in both superclass and subclass, the subclass method overrides the superclass implementation. When the subclass needs to reuse parent logic while adding extra computation, it calls super.methodName() (e.g., SBI calls super.getRateOfInterest() and adds 1.5%).'
    ],
    complexityTable: [
      { parameter: 'Subclass Construction Overhead', value: 'O(1) - Downward constructor call chain from Object -> Super -> Sub' },
      { parameter: 'Inherited Member Access', value: 'O(1) - Offset-based field indexing in instance structure' },
      { parameter: 'Dynamic Method Dispatch', value: 'O(1) - Invokevirtual bytecode through vtable pointer' },
      { parameter: 'Super Invocation Overhead', value: 'O(1) - Invokespecial direct compile-time binding' }
    ],
    keyPoints: [
      'Java supports single, multilevel, and hierarchical inheritance for classes, but forbids multiple inheritance of classes (to prevent diamond problem ambiguity).',
      'The "super" keyword has two primary uses: 1) super(...) to invoke the parent constructor, 2) super.method() or super.variable to access shadowed parent members.',
      'A subclass constructor automatically calls super() with no arguments if not specified.',
      'The @Override annotation provides compile-time verification that a method signature correctly overrides a superclass method.',
      'Private members of the superclass are not directly accessible in subclasses; they must be accessed via public or protected getters/setters.'
    ],
    realWorldApplications: [
      'Hospital Electronic Medical Record (EMR) diagnostic hierarchies (MedicalTest -> Blood, Urine, Glucose, Imaging).',
      'Banking financial platforms calculating base interest across branches (Bank -> SBI, HDFC, ICICI).',
      'Enterprise payroll systems modeling base Person attributes inherited by Employee and Contractor.'
    ]
  },
  algorithm: [
    'Algorithm (Experiment 5A: MedicalTest Hierarchy):',
    '1. Start the program.',
    '2. Create a superclass named MedicalTest.',
    '3. Declare common data members: testId (int), patientName (String), and testDate (String).',
    '4. Create constructor MedicalTest(testId, patientName, testDate) and define displayTestDetails().',
    '5. Create a subclass UrineTest that extends MedicalTest with member result (String).',
    '6. Inside UrineTest constructor, call super(testId, patientName, testDate) and initialize result.',
    '7. Create a subclass BloodTest that extends MedicalTest with member bloodGroup (String).',
    '8. Inside BloodTest constructor, call super(...) and initialize bloodGroup.',
    '9. Create a subclass GlucoseTest that extends MedicalTest with member glucoseLevel (double).',
    '10. Inside GlucoseTest constructor, call super(...) and initialize glucoseLevel.',
    '11. In main(), create objects: u = new UrineTest(101, "Rahul", "22-08-2026", "Normal"), b = new BloodTest(102, "Priya", "22-08-2026", "B+"), and g = new GlucoseTest(103, "Amit", "22-08-2026", 110.5).',
    '12. Call u.displayUrineTest(), b.displayBloodTest(), and g.displayGlucoseTest().',
    '13. Display formatted output.',
    '14. Stop the program.'
  ],
  procedure: [
    '1. Open VS Code and create MedicalTestDemo.java.',
    '2. Implement base class MedicalTest with fields testId, patientName, testDate, and displayTestDetails().',
    '3. Implement child classes UrineTest, BloodTest, and GlucoseTest using the "extends" keyword.',
    '4. In each child constructor, call super(testId, patientName, testDate) as the first statement.',
    '5. Create main driver, instantiate instances of each test, and print diagnostic reports.',
    '6. Verify that common metadata prints correctly alongside specialized clinical metrics.'
  ],
  code: {
    java: `// ==========================================
// K. J. Somaiya Institute of Technology
// Experiment No. 5: Inheritance in Java
// Experiment 5A: Healthcare MedicalTest Hierarchy
// ==========================================

class MedicalTest {
    int testId;
    String patientName;
    String testDate;

    // Constructor
    MedicalTest(int testId, String patientName, String testDate) {
        this.testId = testId;
        this.patientName = patientName;
        this.testDate = testDate;
    }

    // Method to display common test details
    void displayTestDetails() {
        System.out.println("Test ID     : " + testId);
        System.out.println("Patient Name: " + patientName);
        System.out.println("Test Date   : " + testDate);
    }
}

// Subclass 1: UrineTest
class UrineTest extends MedicalTest {
    String result;

    UrineTest(int testId, String patientName, String testDate, String result) {
        super(testId, patientName, testDate);
        this.result = result;
    }

    void displayUrineTest() {
        displayTestDetails();
        System.out.println("Urine Result: " + result);
    }
}

// Subclass 2: BloodTest
class BloodTest extends MedicalTest {
    String bloodGroup;

    BloodTest(int testId, String patientName, String testDate, String bloodGroup) {
        super(testId, patientName, testDate);
        this.bloodGroup = bloodGroup;
    }

    void displayBloodTest() {
        displayTestDetails();
        System.out.println("Blood Group : " + bloodGroup);
    }
}

// Subclass 3: GlucoseTest
class GlucoseTest extends MedicalTest {
    double glucoseLevel;

    GlucoseTest(int testId, String patientName, String testDate, double glucoseLevel) {
        super(testId, patientName, testDate);
        this.glucoseLevel = glucoseLevel;
    }

    void displayGlucoseTest() {
        displayTestDetails();
        System.out.println("Glucose Level: " + glucoseLevel + " mg/dL");
    }
}

// Main class for 5A
public class MedicalTestDemo {
    public static void main(String[] args) {
        UrineTest u = new UrineTest(101, "Rahul", "22-08-2026", "Normal");
        BloodTest b = new BloodTest(102, "Priya", "22-08-2026", "B+");
        GlucoseTest g = new GlucoseTest(103, "Amit", "22-08-2026", 110.5);

        System.out.println("===== URINE TEST =====");
        u.displayUrineTest();

        System.out.println("\\n===== BLOOD TEST =====");
        b.displayBloodTest();

        System.out.println("\\n===== GLUCOSE TEST =====");
        g.displayGlucoseTest();
    }
}

/*
// ==========================================
// Experiment 5B: Method Overriding in Java
// ==========================================
class Bank {
    double getRateOfInterest() {
        return 5.0;
    }
}

class SBI extends Bank {
    @Override
    double getRateOfInterest() {
        // Child class adds extra benefit but also calls parent method
        double parentRate = super.getRateOfInterest(); // parent method
        return parentRate + 1.5; // extra interest (5.0 + 1.5 = 6.5%)
    }
}

public class BankOverridingDemo {
    public static void main(String[] args) {
        SBI sbi = new SBI();
        System.out.println("SBI Rate of Interest: " + sbi.getRateOfInterest());
    }
}
*/`,
    cpp: `#include <iostream>
#include <string>

class MedicalTest {
protected:
    int testId;
    std::string patientName;
    std::string testDate;

public:
    MedicalTest(int id, std::string name, std::string date)
        : testId(id), patientName(name), testDate(date) {}

    void displayTestDetails() const {
        std::cout << "Test ID     : " << testId << "\\n";
        std::cout << "Patient Name: " << patientName << "\\n";
        std::cout << "Test Date   : " << testDate << "\\n";
    }
};

class UrineTest : public MedicalTest {
    std::string result;
public:
    UrineTest(int id, std::string name, std::string date, std::string res)
        : MedicalTest(id, name, date), result(res) {}

    void displayUrineTest() const {
        displayTestDetails();
        std::cout << "Urine Result: " << result << "\\n";
    }
};

int main() {
    UrineTest u(101, "Rahul", "22-08-2026", "Normal");
    std::cout << "===== URINE TEST =====\\n";
    u.displayUrineTest();
    return 0;
}`
  },
  sampleInput: `(Static initialization in MedicalTestDemo)`,
  expectedOutput: `===== URINE TEST =====
Test ID     : 101
Patient Name: Rahul
Test Date   : 22-08-2026
Urine Result: Normal

===== BLOOD TEST =====
Test ID     : 102
Patient Name: Priya
Test Date   : 22-08-2026
Blood Group : B+

===== GLUCOSE TEST =====
Test ID     : 103
Patient Name: Amit
Test Date   : 22-08-2026
Glucose Level: 110.5 mg/dL`,
  conclusion: 'Thus, the Java program successfully demonstrates inheritance and code reuse by creating a superclass MedicalTest and subclasses UrineTest, BloodTest, and GlucoseTest. The subclasses inherit common data members and methods from the superclass while adding their own specific properties and functionality. Furthermore, Experiment 5B proved method overriding using the super keyword to invoke parent methods while augmenting specialized behavior.',
  postLabQuestions: [
    {
      question: 'What is the purpose of the extends keyword in Java?',
      answer: 'The "extends" keyword establishes an inheritance hierarchy, declaring that a new subclass derives its members and behaviors from an existing superclass.'
    },
    {
      question: 'How does super(...) work in a subclass constructor?',
      answer: 'super(arguments) explicitly calls the matching constructor of the immediate superclass. It must be the very first statement inside the subclass constructor body.'
    },
    {
      question: 'What is method overriding in Java?',
      answer: 'Method overriding occurs when a subclass defines an instance method that has the exact same name, return type, and parameter list as a method in its superclass, replacing the parent implementation during runtime dynamic dispatch.'
    },
    {
      question: 'Why does Java not support multiple inheritance with classes?',
      answer: 'To prevent ambiguity known as the "Diamond Problem" where a child class inheriting from two parents with identical method names cannot determine which parent method implementation to execute.'
    },
    {
      question: 'In Experiment 5B, why is super.getRateOfInterest() invoked by the SBI subclass?',
      answer: 'It invokes the baseline 5.0% interest calculation provided by the Bank superclass, allowing SBI to cleanly add its supplemental 1.5% premium without hardcoding or duplicating the parent base rate.'
    }
  ],
  references: [
    'KJSIT Autonomous Syllabus / OOPM Lab Manual (Department of AI & DS)',
    'Herbert Schildt, "Java: The Complete Reference", McGraw-Hill',
    'Oracle Java SE Documentation - Inheritance and Polymorphism'
  ],
  quiz: [
    {
      id: 1,
      question: 'Which keyword in Java is used to inherit a class?',
      options: ['implements', 'extends', 'inherits', 'super'],
      correctAnswer: 1,
      explanation: 'In Java, the "extends" keyword is used to derive a subclass from a superclass.'
    },
    {
      id: 2,
      question: 'What happens if a subclass constructor does not explicitly call super(...) or this(...)?',
      options: [
        'A compile-time syntax error occurs',
        'The compiler automatically inserts an implicit call to super() with zero arguments',
        'The superclass constructor is skipped entirely',
        'The program crashes at runtime'
      ],
      correctAnswer: 1,
      explanation: 'The Java compiler automatically inserts super() to invoke the no-argument constructor of the superclass.'
    },
    {
      id: 3,
      question: 'Can a subclass access private fields of its superclass directly?',
      options: [
        'Yes, because it inherits the class',
        'No, private members are strictly accessible only within the declaring superclass',
        'Only if both classes are in the same package',
        'Only using the this pointer'
      ],
      correctAnswer: 1,
      explanation: 'Private members are private to the declaring class; subclasses must access them through public or protected methods.'
    },
    {
      id: 4,
      question: 'What is dynamic method dispatch in Java?',
      options: [
        'Calling static methods at compile-time',
        'The mechanism by which a call to an overridden method is resolved at runtime based on the actual object type',
        'Automatic serialization of methods to disk',
        'Allocating memory for methods in the stack'
      ],
      correctAnswer: 1,
      explanation: 'Dynamic method dispatch is the runtime mechanism by which an overridden method is invoked based on the type of object being referred to.'
    }
  ]
};
