import { LabExperiment } from '../../types';

export const oopmExp9: LabExperiment = {
  id: 'oopm-exp9',
  num: 9,
  subjectId: 'oopm',
  title: 'Multithreading in Java (Random Number, Square & Cube Threads)',
  subtitle: 'Concurrent Execution, Thread Lifecycle, start() and run() Mechanics, and Asynchronous Worker Threads',
  category: 'Multithreading & Concurrency',
  iitReference: 'K. J. Somaiya Institute of Technology / OOPM Lab Manual Experiment No. 9',
  software: 'VS Code',
  aim: 'Write a java program that implements a multi-thread application that has three threads. First thread generates a random integer every 1 second and if the value is even, the second thread computes the square of the number and prints. If the value is odd, the third thread will print the value of the cube of the number.',
  objective: 'To implement concurrent multitasking in Java by extending the Thread class, scheduling periodic events via Thread.sleep(), and dispatching dynamic worker threads based on numerical parity.',
  labObjectives: [
    'Understand the fundamentals of multithreading and concurrent execution in Java.',
    'Create and manage multiple threads using Java\'s Thread class and/or Runnable interface.',
    'Implement thread-based applications where multiple threads perform different tasks concurrently.',
    'Apply conditional statements and thread synchronization concepts to coordinate the execution of multiple threads.',
    'Generate and process data concurrently, such as generating random numbers and performing square or cube calculations.',
    'Analyze the behavior and execution sequence of multiple threads in a Java application.'
  ],
  theory: {
    overview: [
      'Multithreading is a Java feature that allows concurrent execution of two or more parts of a program for maximum utilization of the CPU. Each part of such a program is called a thread. Threads are lightweight processes within a process that share the same address space and memory.',
      'Mechanisms of Thread Creation in Java: 1. Extending the java.lang.Thread class: We create a class extending Thread and override its public void run() method. The thread begins life when start() is called, which allocates native OS thread resources and schedules run(). 2. Implementing the java.lang.Runnable interface: The class implements the run() method and is passed as a target to a Thread instance (new Thread(new MyRunnable())).',
      'Three-Thread Architecture in Experiment 9: 1) Thread 1 (RandomNumberThread): Generates a random integer between 0 and 99 every 1000 milliseconds using Thread.sleep(1000). 2) Thread 2 (SquareThread): Instantiated and started when the random number is even, computing and printing number * number. 3) Thread 3 (CubeThread): Instantiated and started when the random number is odd, computing and printing number * number * number.'
    ],
    complexityTable: [
      { parameter: 'Thread Context Switch', value: 'O(1) - OS kernel scheduler preemptive timeslicing' },
      { parameter: 'Thread Creation Overhead', value: 'O(1) - Stack allocation (~1MB JVM default per thread)' },
      { parameter: 'Periodic Event Interval', value: '1000ms delay via Thread.sleep()' },
      { parameter: 'Worker Dispatch Latency', value: 'Sub-millisecond worker thread startup' }
    ],
    keyPoints: [
      'Calling run() directly runs synchronously on the current thread; start() must be called to create a genuine new thread.',
      'Thread.sleep(millis) pauses execution of the current thread and throws checked InterruptedException.',
      'Threads share process memory, which enables fast inter-thread communication without IPC overhead.',
      'JVM terminates only when all non-daemon user threads have completed their run() methods.',
      'Multithreading prevents CPU idle time during I/O delays or periodic timer waits.'
    ],
    realWorldApplications: [
      'Real-time IoT telemetry brokers polling sensor metrics every second and dispatching data processing workers.',
      'Game development engines separating physics updates, rendering, and background audio onto distinct threads.',
      'Financial algorithmic tickers consuming real-time market quotes and asynchronously calculating moving averages.'
    ]
  },
  algorithm: [
    'Algorithm (Three-Thread Concurrent Computing):',
    '1. Start the program.',
    '2. Create class SquareThread extending Thread with int number field; in run(), print "Square of " + number + " = " + (number * number).',
    '3. Create class CubeThread extending Thread with int number field; in run(), print "Cube of " + number + " = " + (number * number * number).',
    '4. Create class RandomNumberThread extending Thread.',
    '5. In RandomNumberThread.run():',
    '   - Create Random random = new Random().',
    '   - Loop 10 iterations (for int i = 0; i < 10; i++):',
    '     a. Generate randomInteger = random.nextInt(100).',
    '     b. Print "Random Integer generated : " + randomInteger.',
    '     c. If (randomInteger % 2 == 0): create SquareThread sThread = new SquareThread(randomInteger); sThread.start().',
    '     d. Else: create CubeThread cThread = new CubeThread(randomInteger); cThread.start().',
    '     e. Pause for 1 second using Thread.sleep(1000) inside try-catch(InterruptedException).',
    '6. In MultiThreadingTest.main(), create RandomNumberThread rnThread = new RandomNumberThread(); rnThread.start().',
    '7. Stop the program when all iterations finish.'
  ],
  procedure: [
    '1. Open VS Code and create MultiThreadingTest.java.',
    '2. Define class RandomNumberThread extending Thread with 1-second interval loop.',
    '3. Define classes SquareThread and CubeThread extending Thread.',
    '4. Inside the parity check of RandomNumberThread, call start() on the appropriate worker thread.',
    '5. In main, invoke rnThread.start().',
    '6. Compile and execute; observe the 1-second cadence and asynchronous calculation outputs.'
  ],
  code: {
    java: `// ==========================================
// K. J. Somaiya Institute of Technology
// Experiment No. 9: Multithreading in Java
// Three-Thread Random Generator, Square & Cube
// ==========================================

import java.util.Random;

class RandomNumberThread extends Thread {
    public void run() {
        Random random = new Random();
        for (int i = 0; i < 10; i++) {
            int randomInteger = random.nextInt(100);
            System.out.println("Random Integer generated : " + randomInteger);

            if ((randomInteger % 2) == 0) {
                SquareThread sThread = new SquareThread(randomInteger);
                sThread.start();
            } else {
                CubeThread cThread = new CubeThread(randomInteger);
                cThread.start();
            }

            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                System.out.println(ex);
            }
        }
    }
}

class SquareThread extends Thread {
    int number;

    SquareThread(int randomNumber) {
        this.number = randomNumber;
    }

    public void run() {
        System.out.println("Square of " + number + " = " + (number * number));
    }
}

class CubeThread extends Thread {
    int number;

    CubeThread(int randomNumber) {
        this.number = randomNumber;
    }

    public void run() {
        System.out.println("Cube of " + number + " = " + (number * number * number));
    }
}

public class MultiThreadingTest {
    public static void main(String args[]) {
        RandomNumberThread rnThread = new RandomNumberThread();
        rnThread.start();
    }
}`,
    cpp: `#include <iostream>
#include <thread>
#include <chrono>
#include <random>

void computeSquare(int n) {
    std::cout << "Square of " << n << " = " << (n * n) << "\\n";
}

void computeCube(int n) {
    std::cout << "Cube of " << n << " = " << (n * n * n) << "\\n";
}

int main() {
    std::mt19937 rng(1337);
    std::uniform_int_distribution<int> dist(0, 99);

    for (int i = 0; i < 5; i++) {
        int val = dist(rng);
        std::cout << "Random Integer generated : " << val << "\\n";
        if (val % 2 == 0) {
            std::thread t(computeSquare, val);
            t.detach();
        } else {
            std::thread t(computeCube, val);
            t.detach();
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    }
    return 0;
}`
  },
  sampleInput: `(Executed autonomously: 10 pseudo-random numbers generated at 1000ms intervals)`,
  expectedOutput: `Random Integer generated : 42
Square of 42 = 1764
Random Integer generated : 17
Cube of 17 = 4913
Random Integer generated : 88
Square of 88 = 7744
Random Integer generated : 23
Cube of 23 = 12167
Random Integer generated : 50
Square of 50 = 2500`,
  conclusion: 'Thus, the Java program successfully demonstrates multithreading and concurrent execution by coordinating three distinct threads. The primary generator thread autonomously emits random integers every 1 second, while asynchronous worker threads (SquareThread and CubeThread) dynamically spawn to process calculations without stalling subsequent generations.',
  postLabQuestions: [
    {
      question: 'What is the fundamental difference between a process and a thread?',
      answer: 'A process is an executing program instance with its own dedicated virtual address space and isolated resources managed by the OS. A thread is a lightweight unit of execution within a process that shares memory and heap with peer threads, enabling fast context switching and shared-memory communication.'
    },
    {
      question: 'Why do we invoke start() instead of calling run() directly on a Thread object?',
      answer: 'Invoking start() allocates a new call stack in JVM memory, requests OS native thread creation, and triggers the scheduler to invoke run() asynchronously. Calling run() directly merely executes the method synchronously on the existing caller thread.'
    },
    {
      question: 'What exception does Thread.sleep() throw and why?',
      answer: 'Thread.sleep() throws InterruptedException, a checked exception that occurs if another thread interrupts the sleeping thread via the interrupt() method.'
    },
    {
      question: 'What are the two ways to create a thread in Java, and which is generally preferred?',
      answer: '1) Extending Thread class, and 2) Implementing Runnable interface. Implementing Runnable is generally preferred because Java only supports single class inheritance, allowing the class to extend another business superclass while keeping task logic separated from thread execution mechanics.'
    },
    {
      question: 'What is the state of a thread during Thread.sleep(1000)?',
      answer: 'The thread transitions into the TIMED_WAITING state, relinquishing CPU cycles until the specified duration elapses or an interrupt signal is received.'
    }
  ],
  references: [
    'KJSIT Autonomous Syllabus / OOPM Lab Manual (Department of AI & DS)',
    'Brian Goetz et al., "Java Concurrency in Practice", Addison-Wesley',
    'Oracle Java SE Documentation - Concurrency and Threads'
  ],
  quiz: [
    {
      id: 1,
      question: 'Which method must be overridden when creating a thread by extending the Thread class?',
      options: ['start()', 'run()', 'sleep()', 'init()'],
      correctAnswer: 1,
      explanation: 'The public void run() method contains the executable code of the thread and must be overridden.'
    },
    {
      id: 2,
      question: 'What is the purpose of the start() method in Java multithreading?',
      options: [
        'It pauses the current thread for 1 second',
        'It causes the JVM to create a new thread and execute its run() method concurrently',
        'It kills the currently executing thread',
        'It synchronizes all variables in the class'
      ],
      correctAnswer: 1,
      explanation: 'start() initializes a new thread of execution with its own call stack and invokes run().'
    },
    {
      id: 3,
      question: 'What state does a thread enter when Thread.sleep(1000) is called?',
      options: ['RUNNABLE', 'BLOCKED', 'TIMED_WAITING', 'TERMINATED'],
      correctAnswer: 2,
      explanation: 'Thread.sleep() puts the thread into the TIMED_WAITING state for the specified duration.'
    },
    {
      id: 4,
      question: 'What happens if a thread calls run() directly instead of start()?',
      options: [
        'A compile error occurs',
        'The run() method executes sequentially on the caller thread without creating a new thread',
        'The JVM crashes immediately',
        'A SecurityException is thrown'
      ],
      correctAnswer: 1,
      explanation: 'Calling run() directly is a standard synchronous method invocation on the current thread; no new thread is spawned.'
    }
  ]
};
