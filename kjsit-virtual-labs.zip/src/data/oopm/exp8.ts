import { LabExperiment } from '../../types';

export const oopmExp8: LabExperiment = {
  id: 'oopm-exp8',
  num: 8,
  subjectId: 'oopm',
  title: 'File Handling in Java (Urine Test Strip Results System)',
  subtitle: 'Persistent Disk I/O using FileWriter, FileReader, BufferedReader and IOException Handling in Healthcare Applications',
  category: 'File Handling & Java I/O',
  iitReference: 'K. J. Somaiya Institute of Technology / OOPM Lab Manual Experiment No. 8',
  software: 'VS Code',
  aim: 'To study and implement file handling in Java by creating, writing, reading, and managing data in files using Java I/O classes (Develop a program storing, reading, and displaying urine test strip results using FileWriter and BufferedReader).',
  objective: 'To master character stream operations in Java I/O, writing structured patient diagnostic records to persistent disk files and sequentially parsing file records using line-buffered streams.',
  labObjectives: [
    'Understand the concept of file handling and its importance in Java applications.',
    'Create and manage files using Java file-handling classes.',
    'Write and append data to text files using appropriate I/O classes.',
    'Read and display data from files using Java input streams.',
    'Handle file-related exceptions using appropriate exception-handling mechanisms.',
    'Develop Java programs for storing and retrieving data using files.'
  ],
  theory: {
    overview: [
      'File handling refers to the process of creating, reading, writing, updating, and managing data stored in persistent non-volatile disk storage. Java provides the java.io package to perform comprehensive file operations.',
      'Core Classes in java.io for File Operations: 1. File Class: Represents files and directory pathnames on the filesystem (e.g., File file = new File("student.txt")). 2. FileWriter: Used for writing character streams directly to a file (FileWriter fw = new FileWriter("filename")). 3. FileReader: Reads streams of characters from a file character by character (FileReader fr = new FileReader("filename")). 4. BufferedWriter: Wraps a Writer to provide efficient buffered character output with newLine() capability. 5. BufferedReader: Wraps a Reader to efficiently read text line by line using readLine(), reducing expensive physical disk read syscalls.',
      'Clinical Diagnostic Scenario: In the Urine Test Strip System, patient diagnostic metrics including Patient ID, Patient Name, Glucose concentration, Protein presence, and pH value are captured from clinical instruments and persisted into "UrineTestResults.txt" using FileWriter. The stored report is subsequently retrieved and verified on the console using BufferedReader line by line.'
    ],
    complexityTable: [
      { parameter: 'FileWriter Flush & Write', value: 'O(N) where N is character count of diagnostic report' },
      { parameter: 'BufferedReader.readLine()', value: 'O(L) per line of length L with 8KB buffered chunk pre-fetching' },
      { parameter: 'Resource Deallocation (.close())', value: 'O(1) - OS file descriptor release' },
      { parameter: 'Disk Space Complexity', value: 'Exact payload byte size on filesystem' }
    ],
    keyPoints: [
      'FileWriter overwrites the file by default; pass true as second parameter (new FileWriter(file, true)) to append.',
      'Always flush or close FileWriter using fw.close() to ensure cached memory buffers write to physical disk.',
      'BufferedReader.readLine() returns null when the End-Of-File (EOF) is reached.',
      'File operations throw checked java.io.IOException which must be handled using try-catch blocks.',
      'Proper resource cleanup prevents operating system file locking and memory leaks.'
    ],
    realWorldApplications: [
      'Automated clinical laboratory diagnostic report generation (Urine strip analysis, Hematology).',
      'Banking transactional audit trail log storage with timestamped entries.',
      'Web server access log parsing and security incident investigation.'
    ]
  },
  algorithm: [
    'Algorithm (Urine Test Strip File Handling):',
    '1. Start the program.',
    '2. Define the target filename: String fileName = "UrineTestResults.txt".',
    '3. Accept urine test strip information from keyboard using Scanner:',
    '   - Patient ID (e.g. "P101")',
    '   - Patient Name (e.g. "Rahul")',
    '   - Glucose Result (e.g. "Negative")',
    '   - Protein Result (e.g. "Negative")',
    '   - pH Value (e.g. "6.0")',
    '4. Open a FileWriter object: FileWriter fw = new FileWriter(fileName).',
    '5. Write formatted header and patient records to the file using fw.write(...).',
    '6. Close the FileWriter stream using fw.close() to commit data.',
    '7. Display "Test results saved successfully." to console.',
    '8. Open the file for reading using BufferedReader br = new BufferedReader(new FileReader(fileName)).',
    '9. Read stored test results line by line using while ((line = br.readLine()) != null) and print to console.',
    '10. Close BufferedReader stream (br.close()) and handle any IOException in catch block.',
    '11. Stop the program.'
  ],
  procedure: [
    '1. Open VS Code and create UrineStripFileHandling.java.',
    '2. Import java.io.* and java.util.Scanner.',
    '3. Inside a try block, prompt the user for Patient ID, Name, Glucose, Protein, and pH.',
    '4. Instantiate FileWriter("UrineTestResults.txt") and stream out the structured report.',
    '5. Close FileWriter, then instantiate BufferedReader wrapped around FileReader.',
    '6. Iterate using readLine() loop printing content under "===== STORED TEST RESULTS ======".',
    '7. Close reader and catch IOException.',
    '8. Compile and run; inspect the created text file in the working directory.'
  ],
  code: {
    java: `// ==========================================
// K. J. Somaiya Institute of Technology
// Experiment No. 8: File Handling in Java
// Urine Test Strip File Handling System
// ==========================================

import java.io.*;
import java.util.Scanner;

public class UrineStripFileHandling {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String fileName = "UrineTestResults.txt";

        try {
            // Accept urine test information
            System.out.println("===== URINE TEST STRIP SYSTEM =====");
            System.out.print("Enter Patient ID: ");
            String patientId = sc.nextLine();

            System.out.print("Enter Patient Name: ");
            String patientName = sc.nextLine();

            System.out.print("Enter Glucose Result: ");
            String glucose = sc.nextLine();

            System.out.print("Enter Protein Result: ");
            String protein = sc.nextLine();

            System.out.print("Enter pH Value: ");
            String ph = sc.nextLine();

            // Write data to file
            FileWriter fw = new FileWriter(fileName);
            fw.write("===== URINE TEST STRIP RESULT =====\\n");
            fw.write("Patient ID   : " + patientId + "\\n");
            fw.write("Patient Name : " + patientName + "\\n");
            fw.write("Glucose      : " + glucose + "\\n");
            fw.write("Protein      : " + protein + "\\n");
            fw.write("pH Value     : " + ph + "\\n");
            fw.close();

            System.out.println("\\nTest results saved successfully.");

            // Read data from file
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String line;
            System.out.println("\\n===== STORED TEST RESULTS =====");
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
            br.close();

        } catch (IOException e) {
            System.out.println("File Error: " + e.getMessage());
        } finally {
            sc.close();
        }
    }
}`,
    cpp: `#include <iostream>
#include <fstream>
#include <string>

int main() {
    std::string fileName = "UrineTestResults.txt";
    std::string patientId, patientName, glucose, protein, ph;

    std::cout << "===== URINE TEST STRIP SYSTEM =====\\n";
    std::cout << "Enter Patient ID: ";
    std::getline(std::cin, patientId);
    std::cout << "Enter Patient Name: ";
    std::getline(std::cin, patientName);
    std::cout << "Enter Glucose Result: ";
    std::getline(std::cin, glucose);
    std::cout << "Enter Protein Result: ";
    std::getline(std::cin, protein);
    std::cout << "Enter pH Value: ";
    std::getline(std::cin, ph);

    // Write to file
    std::ofstream outFile(fileName);
    outFile << "===== URINE TEST STRIP RESULT =====\\n";
    outFile << "Patient ID   : " << patientId << "\\n";
    outFile << "Patient Name : " << patientName << "\\n";
    outFile << "Glucose      : " << glucose << "\\n";
    outFile << "Protein      : " << protein << "\\n";
    outFile << "pH Value     : " << ph << "\\n";
    outFile.close();

    std::cout << "\\nTest results saved successfully.\\n";

    // Read from file
    std::ifstream inFile(fileName);
    std::string line;
    std::cout << "\\n===== STORED TEST RESULTS =====\\n";
    while (std::getline(inFile, line)) {
        std::cout << line << "\\n";
    }
    inFile.close();

    return 0;
}`
  },
  sampleInput: `P101
Rahul
Negative
Negative
6.0`,
  expectedOutput: `===== URINE TEST STRIP SYSTEM =====
Enter Patient ID: P101
Enter Patient Name: Rahul
Enter Glucose Result: Negative
Enter Protein Result: Negative
Enter pH Value: 6.0

Test results saved successfully.

===== STORED TEST RESULTS =====
===== URINE TEST STRIP RESULT =====
Patient ID   : P101
Patient Name : Rahul
Glucose      : Negative
Protein      : Negative
pH Value     : 6.0`,
  conclusion: 'Thus, the Java program successfully demonstrates file handling in a urine test strip application. The program accepts urine test results, stores them in a text file using FileWriter, and retrieves and displays the stored information using BufferedReader. The experiment also demonstrates the use of exception handling to manage file-related errors.',
  postLabQuestions: [
    {
      question: 'What is the purpose of FileWriter in the given program?',
      answer: 'FileWriter is used to write character data directly to the target file ("UrineTestResults.txt") on the filesystem, saving the patient diagnostic parameters permanently.'
    },
    {
      question: 'Why is BufferedReader used to read the urine test results?',
      answer: 'BufferedReader reads character streams with an internal memory buffer, enabling the efficient readLine() method to retrieve and process the stored clinical records line-by-line rather than byte-by-byte.'
    },
    {
      question: 'Which exception is handled during file operations in Java?',
      answer: 'java.io.IOException (and its subclass FileNotFoundException) must be handled because file access involves hardware storage and operating system permissions that can fail at runtime.'
    },
    {
      question: 'What is the purpose of the close() method?',
      answer: 'The close() method flushes any remaining buffered data to disk and releases the underlying operating system file descriptor handle, preventing memory leaks and locked files.'
    },
    {
      question: 'How can you modify the program to append new patient results without deleting existing data?',
      answer: 'Instantiate FileWriter with its boolean append flag set to true: new FileWriter(fileName, true). This causes new write operations to append at the end of the file instead of overwriting existing records.'
    }
  ],
  references: [
    'KJSIT Autonomous Syllabus / OOPM Lab Manual (Department of AI & DS)',
    'Herbert Schildt, "Java: The Complete Reference", McGraw-Hill',
    'Oracle Java SE Documentation - Java I/O Tutorial (Character Streams)'
  ],
  quiz: [
    {
      id: 1,
      question: 'What does BufferedReader.readLine() return when it reaches the End-Of-File (EOF)?',
      options: ['"" (empty string)', 'null', '-1', 'EOFException'],
      correctAnswer: 1,
      explanation: 'BufferedReader.readLine() returns null when the end of the character stream has been reached.'
    },
    {
      id: 2,
      question: 'How do you open a file in append mode using FileWriter?',
      options: [
        'new FileWriter(filename, "append")',
        'new FileWriter(filename, true)',
        'FileWriter.openAppend(filename)',
        'new FileWriter(filename, 1)'
      ],
      correctAnswer: 1,
      explanation: 'Passing true as the second boolean argument to the FileWriter constructor activates append mode.'
    },
    {
      id: 3,
      question: 'Which package contains the File, FileWriter, and BufferedReader classes?',
      options: ['java.util', 'java.io', 'java.nio', 'java.lang'],
      correctAnswer: 1,
      explanation: 'File, FileWriter, and BufferedReader are all members of the java.io package.'
    },
    {
      id: 4,
      question: 'What is the primary advantage of BufferedReader over FileReader?',
      options: [
        'BufferedReader encrypts the file data',
        'BufferedReader provides buffered reading via readLine(), significantly reducing disk I/O operations',
        'BufferedReader can read binary image files',
        'BufferedReader does not throw exceptions'
      ],
      correctAnswer: 1,
      explanation: 'BufferedReader maintains an 8KB internal buffer and provides readLine(), preventing expensive single-character physical disk reads.'
    }
  ]
};
