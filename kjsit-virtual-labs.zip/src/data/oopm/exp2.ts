import { LabExperiment } from '../../types';

export const oopmExp2: LabExperiment = {
  id: 'oopm-exp2',
  num: 2,
  subjectId: 'oopm',
  title: 'Menu-Driven Control Structures (ATM Simulation)',
  subtitle: 'Iterative State Control using do-while Loops, switch-case Branching & Conditional Guards',
  category: 'Control Structures & Decision Making',
  iitReference: 'K. J. Somaiya Institute of Technology / OOPM Lab Manual Experiment No. 2',
  software: 'VS Code',
  aim: 'Implement a menu driven Java program which will read a number and should implement the methods using controlled structure (ATM simulation using switch and loops).',
  objective: 'To design a resilient console application utilizing decision-making (switch-case, if-else) and post-test looping (do-while) to manage banking transaction states and input boundaries.',
  labObjectives: [
    'Understand the concept of controlled structures in Java, including if-else, switch-case, and looping statements.',
    'Implement a menu-driven Java program using the switch-case control structure.',
    'Apply conditional and iterative statements to perform different operations based on user selection.',
    'Accept and process numerical input from the user using appropriate Java input methods.',
    'Develop a menu-driven program that repeatedly performs selected operations until the user chooses to exit.',
    'Analyze the flow of control in a Java program and select suitable control structures for solving a given problem.'
  ],
  theory: {
    overview: [
      'Menu-Driven Program: A menu-driven program is an application that presents users with a menu of options or choices, allowing them to select the desired action from a list. The user interacts with the program by selecting a numerical or character option, and the system executes the corresponding functionality.',
      'Menu-driven architectures are foundational in management systems, games, and banking utilities to simplify user interaction and ensure predictable execution flows.',
      'Designing a Menu-Driven Program in Java involves four critical phases: 1) Display a Menu: Presenting the numbered operations clearly on console. 2) Accept User Input: Reading the option via Scanner. 3) Process User Choice: Branching through switch-case or if-else ladders with defensive guards. 4) Repeat or Exit: Retaining loop iteration via do-while until an explicit exit code is selected.',
      'Switch-case provides constant-time jump table / table-lookup branching for discrete menu choices, while do-while guarantees that the menu is rendered at least once before evaluating continuation criteria.'
    ],
    complexityTable: [
      { parameter: 'Menu Dispatch (switch-case)', value: 'O(1) - Compiler tableswitch / lookupswitch bytecode' },
      { parameter: 'Loop Space Overhead', value: 'O(1) - In-place scalar balance and choice registers' },
      { parameter: 'Guard Checking (Validation)', value: 'O(1) - Constant-time inequality checks' },
      { parameter: 'Iteration Bound', value: 'Arbitrary N transactions until exit choice (4) selected' }
    ],
    keyPoints: [
      'do-while loop is ideal for menus because the menu must always execute at least once.',
      'switch-case simplifies multi-branch logic compared to nested if-else ladders.',
      'break statements are mandatory to prevent accidental fall-through between cases.',
      'defensive condition checks prevent illegal actions such as negative deposits or overdraft withdrawals.',
      'The default branch gracefully catches unexpected or out-of-range user selections.'
    ],
    realWorldApplications: [
      'Automated Teller Machine (ATM) terminal software and kiosk kiosks.',
      'Point-of-Sale (POS) cash registers and inventory checkout stations.',
      'Command-line interactive configuration wizards (e.g., git config, system setup).'
    ]
  },
  algorithm: [
    'Step 1: Start the program.',
    'Step 2: Import the Scanner class and create a Scanner object to accept user input.',
    'Step 3: Initialize the account balance with an initial value (e.g., ₹10,000.0).',
    'Step 4: Repeat the following steps in a do-while loop until the user chooses to exit (choice == 4):',
    '  1. Display the ATM menu: [1. Check Balance, 2. Deposit Money, 3. Withdraw Money, 4. Exit].',
    '  2. Accept the user\'s choice via sc.nextInt().',
    '  3. Use a switch statement to perform the selected operation:',
    '     - Case 1: Display the current account balance.',
    '     - Case 2: Accept deposit amount. If amount > 0, add to balance and print success; else display "Invalid deposit amount!".',
    '     - Case 3: Accept withdrawal amount. If amount <= 0, display "Invalid withdrawal amount!". Else if amount > balance, display "Insufficient Balance!". Otherwise subtract amount and display updated balance.',
    '     - Case 4: Display "Thank you for using the ATM!" and terminate.',
    '     - Default: Display "Invalid Choice! Please try again.".',
    'Step 5: Close the Scanner object.',
    'Step 6: Stop the program.'
  ],
  procedure: [
    '1. Open VS Code and create ATMSimulation.java.',
    '2. Implement the balance state variable (double balance = 10000.0).',
    '3. Write the do-while loop enclosing the console menu display.',
    '4. Implement switch(choice) with cases 1, 2, 3, 4 and default.',
    '5. Add validation guards for zero/negative amounts and overdraft conditions.',
    '6. Compile and execute; verify valid transactions and boundary error messages.'
  ],
  code: {
    java: `// ==========================================
// K. J. Somaiya Institute of Technology
// Experiment No. 2: ATM Simulation Menu
// ==========================================

import java.util.Scanner;

public class ATMSimulation {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double balance = 10000.0; // Initial balance
        int choice;
        double amount;

        do {
            System.out.println("\\n===== ATM MENU =====");
            System.out.println("1. Check Balance");
            System.out.println("2. Deposit Money");
            System.out.println("3. Withdraw Money");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Current Balance: ₹" + balance);
                    break;

                case 2:
                    System.out.print("Enter amount to deposit: ₹");
                    amount = sc.nextDouble();
                    if (amount > 0) {
                        balance += amount;
                        System.out.println("Amount Deposited Successfully.");
                        System.out.println("Updated Balance: ₹" + balance);
                    } else {
                        System.out.println("Invalid deposit amount!");
                    }
                    break;

                case 3:
                    System.out.print("Enter amount to withdraw: ₹");
                    amount = sc.nextDouble();
                    if (amount <= 0) {
                        System.out.println("Invalid withdrawal amount!");
                    } else if (amount > balance) {
                        System.out.println("Insufficient Balance!");
                    } else {
                        balance -= amount;
                        System.out.println("Withdrawal Successful.");
                        System.out.println("Remaining Balance: ₹" + balance);
                    }
                    break;

                case 4:
                    System.out.println("Thank you for using the ATM!");
                    break;

                default:
                    System.out.println("Invalid Choice! Please try again.");
            }
        } while (choice != 4);

        sc.close();
    }
}`,
    cpp: `#include <iostream>

int main() {
    double balance = 10000.0;
    int choice;
    double amount;

    do {
        std::cout << "\\n===== ATM MENU =====\\n";
        std::cout << "1. Check Balance\\n";
        std::cout << "2. Deposit Money\\n";
        std::cout << "3. Withdraw Money\\n";
        std::cout << "4. Exit\\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Current Balance: ₹" << balance << "\\n";
                break;
            case 2:
                std::cout << "Enter amount to deposit: ₹";
                std::cin >> amount;
                if (amount > 0) {
                    balance += amount;
                    std::cout << "Amount Deposited Successfully.\\nUpdated Balance: ₹" << balance << "\\n";
                } else {
                    std::cout << "Invalid deposit amount!\\n";
                }
                break;
            case 3:
                std::cout << "Enter amount to withdraw: ₹";
                std::cin >> amount;
                if (amount <= 0) {
                    std::cout << "Invalid withdrawal amount!\\n";
                } else if (amount > balance) {
                    std::cout << "Insufficient Balance!\\n";
                } else {
                    balance -= amount;
                    std::cout << "Withdrawal Successful.\\nRemaining Balance: ₹" << balance << "\\n";
                }
                break;
            case 4:
                std::cout << "Thank you for using the ATM!\\n";
                break;
            default:
                std::cout << "Invalid Choice! Please try again.\\n";
        }
    } while (choice != 4);

    return 0;
}`
  },
  sampleInput: `1
2
5000
3
3000
1
4`,
  expectedOutput: `===== ATM MENU =====
1. Check Balance
2. Deposit Money
3. Withdraw Money
4. Exit
Enter your choice: 1
Current Balance: ₹10000.0

===== ATM MENU =====
1. Check Balance
2. Deposit Money
3. Withdraw Money
4. Exit
Enter your choice: 2
Enter amount to deposit: ₹5000
Amount Deposited Successfully.
Updated Balance: ₹15000.0

===== ATM MENU =====
1. Check Balance
2. Deposit Money
3. Withdraw Money
4. Exit
Enter your choice: 3
Enter amount to withdraw: ₹3000
Withdrawal Successful.
Remaining Balance: ₹12000.0

===== ATM MENU =====
1. Check Balance
2. Deposit Money
3. Withdraw Money
4. Exit
Enter your choice: 1
Current Balance: ₹12000.0

===== ATM MENU =====
1. Check Balance
2. Deposit Money
3. Withdraw Money
4. Exit
Enter your choice: 4
Thank you for using the ATM!`,
  conclusion: 'The ATM Simulation program demonstrates the use of switch statements and loops to create a menu-driven application in Java. It allows users to perform basic banking operations such as checking the account balance, depositing money, and withdrawing money. The program also incorporates conditional statements to validate user inputs and handle scenarios such as insufficient balance and invalid choices. This experiment helps in understanding menu-driven programming, decision-making, looping constructs, and user interaction in Java.',
  postLabQuestions: [
    {
      question: 'What is a menu-driven program in Java?',
      answer: 'A menu-driven program is a software application that presents users with a curated list of choices and executes specific routines based on the user selection, facilitating modular and interactive user workflows.'
    },
    {
      question: 'Which control structure is commonly used to implement a menu in Java?',
      answer: 'The switch-case statement is commonly used to evaluate the discrete integer or character choice and jump directly to the matched branch.'
    },
    {
      question: 'What is the purpose of the switch-case statement in the given program?',
      answer: 'It directs program flow to the specific banking action (check balance, deposit, withdraw, or exit) corresponding to the integer entered by the user, executing the targeted block without testing each condition sequentially.'
    },
    {
      question: 'Why is a do-while loop suitable for implementing a menu-driven program?',
      answer: 'A do-while loop is exit-controlled (post-test), guaranteeing that the menu options are printed and at least one user choice is accepted before checking the termination condition (choice != 4).'
    },
    {
      question: 'What is the difference between break and continue statements in Java?',
      answer: 'The break statement immediately terminates the enclosing switch or loop construct, transferring execution to the statement following the block. The continue statement skips the remaining statements of the current iteration and jumps immediately to the next iteration check of the loop.'
    }
  ],
  references: [
    'KJSIT Autonomous Syllabus / OOPM Lab Manual (Department of AI & DS)',
    'E. Balagurusamy, "Programming with Java: A Primer", McGraw-Hill Education',
    'Oracle Java SE Documentation - Control Flow Statements (switch, while, do-while)'
  ],
  quiz: [
    {
      id: 1,
      question: 'What happens if a programmer omits the "break" statement inside a switch-case?',
      options: [
        'A compile-time syntax error occurs',
        'Execution continues (falls through) into subsequent cases until a break or end of switch is reached',
        'The program immediately terminates with an exception',
        'The default case is automatically executed first'
      ],
      correctAnswer: 1,
      explanation: 'Omitting break causes fall-through: Java continues executing the next cases sequentially regardless of whether their labels match.'
    },
    {
      id: 2,
      question: 'What type of loop is a do-while loop classified as?',
      options: ['Entry-controlled loop', 'Exit-controlled (post-test) loop', 'Infinite non-terminating loop', 'Compile-time loop'],
      correctAnswer: 1,
      explanation: 'A do-while loop evaluates its condition after executing the body, making it an exit-controlled loop.'
    },
    {
      id: 3,
      question: 'Which data types are valid expression types in a Java switch statement?',
      options: [
        'Only float and double',
        'byte, short, char, int, String, and enums',
        'boolean and float only',
        'Thread and Runnable only'
      ],
      correctAnswer: 1,
      explanation: 'Java switch supports integral types (byte, short, char, int), their wrappers, enums, and String (from Java 7).'
    },
    {
      id: 4,
      question: 'What is the role of the "default" block in a switch-case statement?',
      options: [
        'It is executed when none of the specified case values match the selector',
        'It resets the variables to zero',
        'It terminates the program immediately',
        'It is executed before every case'
      ],
      correctAnswer: 0,
      explanation: 'The default block acts as the fallback catch-all executed when no case label matches the input value.'
    }
  ]
};
