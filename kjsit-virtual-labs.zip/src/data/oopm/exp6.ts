import { LabExperiment } from '../../types';

export const oopmExp6: LabExperiment = {
  id: 'oopm-exp6',
  num: 6,
  subjectId: 'oopm',
  title: 'Java Interfaces & Weather Monitoring System',
  subtitle: 'Abstract Contracts, Loose Coupling, Polymorphic Interface References & Multi-Service Dispatch',
  category: 'Interfaces & Abstraction',
  iitReference: 'K. J. Somaiya Institute of Technology / OOPM Lab Manual Experiment No. 6',
  software: 'VS Code',
  aim: 'Design a Weather Monitoring System using Java interfaces. Create WeatherDataProvider, ForecastService, and AlertService interfaces, and implement them using SensorWeatherProvider, APIWeatherProvider, BasicForecastService, AIForecastService, SMSAlertService, and EmailAlertService.',
  objective: 'To realize 100% pure abstraction in Java using the "interface" and "implements" keywords, decoupling client services from concrete hardware/cloud implementations.',
  labObjectives: [
    'To understand the concept of interfaces in Java.',
    'To define an interface with abstract methods.',
    'To implement an interface in a class.',
    'To understand how interfaces achieve abstraction and support multiple inheritance.'
  ],
  theory: {
    overview: [
      'An interface in Java is a blueprint of a class. It contains abstract method signatures that any implementing class must provide concrete definitions for. A class uses the "implements" keyword to establish this architectural contract.',
      'Important Characteristics of Interfaces: 1) Declared using the "interface" keyword. 2) Methods are implicitly public and abstract by default (unless declared default or static in modern Java). 3) Variables declared in an interface are implicitly public, static, and final (constants). 4) A class can implement multiple interfaces (e.g. class C implements A, B), effectively achieving multiple inheritance of type in Java.',
      'Abstraction & Loose Coupling: Interfaces allow developers to write client code against abstract interface references rather than tight concrete class types. In the Weather Monitoring System, the main program holds references of type WeatherDataProvider, ForecastService, and AlertService, allowing seamless swapping between physical IoT sensors, cloud REST APIs, statistical models, AI predictors, SMS gateways, and SMTP mail alerts without changing the consuming code.'
    ],
    complexityTable: [
      { parameter: 'Interface Method Dispatch', value: 'O(1) - invokeinterface bytecode with inline cache' },
      { parameter: 'Multi-Interface Table Lookup', value: 'O(1) - Itable index lookup per implementing class' },
      { parameter: 'Memory Overhead', value: 'Zero instance state inside interface definitions' },
      { parameter: 'Extensibility Cost', value: 'O(1) - Plug-in new provider without refactoring core logic' }
    ],
    keyPoints: [
      'An interface cannot be instantiated directly with "new"; it must be instantiated via a concrete implementing class.',
      'A class implementing an interface must override every abstract method with public visibility.',
      'Polymorphic interface references (e.g., WeatherDataProvider p = new SensorWeatherProvider()) ensure modular design.',
      'Java allows a class to extend one superclass while implementing multiple interfaces simultaneously.',
      'Interfaces promote testability and dependency injection in enterprise software.'
    ],
    realWorldApplications: [
      'Meteorological meteorological stations switching between physical telemetry sensors and satellite cloud APIs.',
      'Payment gateway integrations (PaymentProcessor -> StripeProvider, PayPalProvider, RazorpayProvider).',
      'Multi-channel notification hubs routing critical alerts to SMS, Email, and Push Notification channels.'
    ]
  },
  algorithm: [
    '1. Start the program.',
    '2. Define interface WeatherDataProvider with abstract method void getWeatherData().',
    '3. Define interface ForecastService with abstract method void generateForecast().',
    '4. Define interface AlertService with abstract method void sendAlert().',
    '5. Create class SensorWeatherProvider implementing WeatherDataProvider; print sensor temperature (32°C) and humidity (70%).',
    '6. Create class APIWeatherProvider implementing WeatherDataProvider; print API temperature (31°C) and humidity (68%).',
    '7. Create class BasicForecastService implementing ForecastService; print basic forecast ("Partly cloudy weather expected.").',
    '8. Create class AIForecastService implementing ForecastService; print AI forecast ("Heavy rainfall is likely in the evening.").',
    '9. Create class SMSAlertService implementing AlertService; print SMS alert ("Weather alert sent through SMS.").',
    '10. Create class EmailAlertService implementing AlertService; print Email alert ("Weather alert sent through Email.").',
    '11. In WeatherMonitoringSystem main(), instantiate objects using interface references:',
    '    - WeatherDataProvider provider1 = new SensorWeatherProvider()',
    '    - WeatherDataProvider provider2 = new APIWeatherProvider()',
    '    - ForecastService forecast1 = new BasicForecastService()',
    '    - ForecastService forecast2 = new AIForecastService()',
    '    - AlertService alert1 = new SMSAlertService()',
    '    - AlertService alert2 = new EmailAlertService()',
    '12. Invoke methods using these interface references and display weather outputs.',
    '13. Stop the program.'
  ],
  procedure: [
    '1. Open VS Code and create WeatherMonitoringSystem.java.',
    '2. Define the three interfaces: WeatherDataProvider, ForecastService, AlertService.',
    '3. Implement two concrete classes for each interface demonstrating diverse providers.',
    '4. In main(), create polymorphic references of the interface type.',
    '5. Invoke getWeatherData(), generateForecast(), and sendAlert() sequentially.',
    '6. Compile and run; observe pure abstraction and decoupled service output.'
  ],
  code: {
    java: `// ==========================================
// K. J. Somaiya Institute of Technology
// Experiment No. 6: Java Interfaces
// Weather Monitoring System
// ==========================================

// Interface 1: WeatherDataProvider
interface WeatherDataProvider {
    void getWeatherData();
}

// Interface 2: ForecastService
interface ForecastService {
    void generateForecast();
}

// Interface 3: AlertService
interface AlertService {
    void sendAlert();
}

// Implementation 1 of WeatherDataProvider: Hardware Sensors
class SensorWeatherProvider implements WeatherDataProvider {
    @Override
    public void getWeatherData() {
        System.out.println("Getting weather data from sensors...");
        System.out.println("Temperature: 32°C");
        System.out.println("Humidity: 70%");
    }
}

// Implementation 2 of WeatherDataProvider: Cloud REST API
class APIWeatherProvider implements WeatherDataProvider {
    @Override
    public void getWeatherData() {
        System.out.println("Getting weather data from Weather API...");
        System.out.println("Temperature: 31°C");
        System.out.println("Humidity: 68%");
    }
}

// Implementation 1 of ForecastService: Basic Statistical Rule
class BasicForecastService implements ForecastService {
    @Override
    public void generateForecast() {
        System.out.println("Basic Forecast: Partly cloudy weather expected.");
    }
}

// Implementation 2 of ForecastService: AI Deep Learning Model
class AIForecastService implements ForecastService {
    @Override
    public void generateForecast() {
        System.out.println("AI Forecast: Heavy rainfall is likely in the evening.");
    }
}

// Implementation 1 of AlertService: SMS Gateway
class SMSAlertService implements AlertService {
    @Override
    public void sendAlert() {
        System.out.println("SMS Alert: Weather alert sent through SMS.");
    }
}

// Implementation 2 of AlertService: Email Protocol
class EmailAlertService implements AlertService {
    @Override
    public void sendAlert() {
        System.out.println("Email Alert: Weather alert sent through Email.");
    }
}

// Main class demonstrating Interface References
public class WeatherMonitoringSystem {
    public static void main(String[] args) {
        // Interface references
        WeatherDataProvider provider1 = new SensorWeatherProvider();
        WeatherDataProvider provider2 = new APIWeatherProvider();
        ForecastService forecast1 = new BasicForecastService();
        ForecastService forecast2 = new AIForecastService();
        AlertService alert1 = new SMSAlertService();
        AlertService alert2 = new EmailAlertService();

        System.out.println("===== WEATHER MONITORING SYSTEM =====");
        System.out.println("\\n--- Weather Data ---");
        provider1.getWeatherData();
        System.out.println();
        provider2.getWeatherData();

        System.out.println("\\n--- Weather Forecast ---");
        forecast1.generateForecast();
        System.out.println();
        forecast2.generateForecast();

        System.out.println("\\n--- Weather Alerts ---");
        alert1.sendAlert();
        System.out.println();
        alert2.sendAlert();
    }
}`,
    cpp: `#include <iostream>

// Pure Abstract Base Class (C++ Interface Equivalent)
class WeatherDataProvider {
public:
    virtual ~WeatherDataProvider() {}
    virtual void getWeatherData() = 0;
};

class SensorWeatherProvider : public WeatherDataProvider {
public:
    void getWeatherData() override {
        std::cout << "Getting weather data from sensors...\\n";
        std::cout << "Temperature: 32°C\\nHumidity: 70%\\n";
    }
};

int main() {
    WeatherDataProvider* provider = new SensorWeatherProvider();
    provider->getWeatherData();
    delete provider;
    return 0;
}`
  },
  sampleInput: `(Static invocation of polymorphic interface methods)`,
  expectedOutput: `===== WEATHER MONITORING SYSTEM =====

--- Weather Data ---
Getting weather data from sensors...
Temperature: 32°C
Humidity: 70%

Getting weather data from Weather API...
Temperature: 31°C
Humidity: 68%

--- Weather Forecast ---
Basic Forecast: Partly cloudy weather expected.

AI Forecast: Heavy rainfall is likely in the evening.

--- Weather Alerts ---
SMS Alert: Weather alert sent through SMS.

Email Alert: Weather alert sent through Email.`,
  conclusion: 'Thus, the Weather Monitoring System was successfully implemented using Java interfaces. The program demonstrated abstraction and polymorphism by defining common operations through interfaces and providing different implementations using multiple classes. Interface references allowed different weather providers, forecasting services, and alert services to be used flexibly and demonstrated code reusability and modularity.',
  postLabQuestions: [
    {
      question: 'What is an interface in Java and how does it differ from an abstract class?',
      answer: 'An interface is a pure contract containing method signatures without state (all variables are public static final), enabling multiple inheritance. An abstract class can have instance fields, constructors, and partial method implementations with state.'
    },
    {
      question: 'Why are interface methods public and abstract by default?',
      answer: 'Because the primary purpose of an interface is to expose a public contract to external consumers that concrete implementing classes must fulfill.'
    },
    {
      question: 'Can an interface implement another interface?',
      answer: 'No, an interface cannot implement another interface; it must use the "extends" keyword to inherit or combine multiple interfaces.'
    },
    {
      question: 'What is the significance of using interface references in WeatherMonitoringSystem?',
      answer: 'It decouples the consuming application from specific concrete classes. The main method only depends on the interface contract, allowing dynamic switching between sensor data, API data, AI forecasts, and notification channels without breaking existing code.'
    },
    {
      question: 'Can a single Java class implement multiple interfaces?',
      answer: 'Yes, a Java class can implement multiple interfaces separated by commas (e.g. class HybridService implements WeatherDataProvider, ForecastService), providing Java\'s mechanism for multiple interface inheritance.'
    }
  ],
  references: [
    'KJSIT Autonomous Syllabus / OOPM Lab Manual (Department of AI & DS)',
    'Joshua Bloch, "Effective Java", 3rd Edition, Addison-Wesley',
    'Oracle Java SE Documentation - Interfaces and Inheritance'
  ],
  quiz: [
    {
      id: 1,
      question: 'Which keyword is used by a class to implement an interface in Java?',
      options: ['extends', 'implements', 'inherits', 'interface'],
      correctAnswer: 1,
      explanation: 'The "implements" keyword is used by classes to implement interface contracts in Java.'
    },
    {
      id: 2,
      question: 'What are the implicit modifiers for all variables declared inside a Java interface?',
      options: ['private final', 'public static final', 'protected volatile', 'transient static'],
      correctAnswer: 1,
      explanation: 'All fields declared inside a Java interface are implicitly public, static, and final (constants).'
    },
    {
      id: 3,
      question: 'Can you instantiate an interface directly using the "new" keyword?',
      options: ['Yes, always', 'No, interfaces cannot be directly instantiated', 'Only if the interface has zero methods', 'Only inside the main method'],
      correctAnswer: 1,
      explanation: 'Interfaces cannot be instantiated directly because they lack method implementations and instance state.'
    },
    {
      id: 4,
      question: 'How many interfaces can a single Java class implement?',
      options: ['Exactly one', 'Up to two', 'Multiple (arbitrarily many separated by commas)', 'None'],
      correctAnswer: 2,
      explanation: 'Java supports multiple inheritance through interfaces; a class can implement any number of interfaces.'
    }
  ]
};
