import { LabExperiment } from '../../types';

export const oopmExp4: LabExperiment = {
  id: 'oopm-exp4',
  num: 4,
  subjectId: 'oopm',
  title: 'Constructors in Java (Default, Parameterized & Overloading)',
  subtitle: 'Object Lifecycle Initialization, Parameterized Constructors, and Constructor Overloading (Book, Rectangle & BankAccount)',
  category: 'Constructors & Object Lifecycle',
  iitReference: 'K. J. Somaiya Institute of Technology / OOPM Lab Manual Experiment No. 4',
  software: 'VS Code',
  aim: 'Implement program for constructor in Java demonstrating default constructors, parameterized constructors, and constructor overloading (Experiment 4A: Book class, 4B: Rectangle area, 4C: BankAccount).',
  objective: 'To examine the lifecycle and invocation mechanics of constructors in Java, ensuring deterministic member initialization and exploiting constructor overloading for versatile object instantiation.',
  labObjectives: [
    'Understand the concept and purpose of constructors in Java.',
    'Identify the characteristics and rules of constructors in a Java class.',
    'Implement default and parameterized constructors in Java programs.',
    'Initialize object data members using constructors.',
    'Differentiate between constructors and methods based on their purpose and usage.',
    'Apply constructor overloading to initialize objects with different sets of values.'
  ],
  theory: {
    overview: [
      'A constructor is a special member of a class that is automatically invoked when an object of the class is created. It is primarily used to initialize the object\'s data members and allocate necessary operational resources.',
      'Characteristics of Constructors: 1) The constructor name must be identical to the class name. 2) It does not have any return type (not even void). 3) It is called automatically during object creation using "new". 4) Constructors can be overloaded with distinct parameter lists. 5) Constructors cannot be inherited directly by child classes. 6) Constructors can possess access modifiers (public, protected, package-private, private).',
      'Types of Constructors: 1. Default Constructor: A zero-argument constructor that initializes fields to predefined constants or default zeros/nulls. 2. Parameterized Constructor: Accepts arguments to dynamically initialize instance members with user-provided parameters. 3. Copy Constructor: A constructor that accepts an object of the same class to clone its member values.',
      'Constructor Overloading: Java permits defining multiple constructors within the same class, differentiated by parameter count, types, or ordering (polymorphism at instantiation). This allows objects to be constructed with varying initial configurations (e.g., Rectangle() default, Rectangle(side) square, Rectangle(length, width) rectangle).'
    ],
    complexityTable: [
      { parameter: 'Default Constructor Invocation', value: 'O(1) - Constant-time scalar initialization' },
      { parameter: 'Parameterized Constructor Dispatch', value: 'O(1) - Direct compile-time static signature resolution' },
      { parameter: 'Constructor Chaining (this())', value: 'O(1) - Inline call frame on call stack' },
      { parameter: 'Return Type Overhead', value: 'None - Constructors do not return typed values' }
    ],
    keyPoints: [
      'If no constructor is explicitly provided by the developer, the Java compiler auto-generates a public no-arg default constructor.',
      'Once any constructor (parameterized) is declared, the compiler no longer creates the default constructor automatically.',
      'The "this" keyword disambiguates instance variables from constructor parameters sharing the same identifier.',
      'Constructor overloading allows versatile initialization scenarios across applications.',
      'Constructors cannot be declared static, final, or abstract.'
    ],
    realWorldApplications: [
      'Digital library catalogs creating Book objects with complete bibliographic records.',
      'Geometry modeling engines constructing Point, Rectangle, and Polygon entities with default or custom dimensions.',
      'Fintech banking cores initializing BankAccount instances with KYC customer names and opening balances.'
    ]
  },
  algorithm: [
    'Algorithm (Experiment 4A: Book Initialization):',
    '1. Start the program.',
    '2. Define a class named Book.',
    '3. Declare data members: bookId (int), title (String), author (String), and price (double).',
    '4. Define a parameterized constructor Book(int bookId, String title, String author, double price).',
    '5. Inside the constructor, initialize the instance members using "this" (this.bookId = bookId, etc.).',
    '6. Define a method displayDetails() to print the book information formatted.',
    '7. In the main() method of BookDemo, create a Book object b1 passing arguments (101, "Java Programming", "James Gosling", 550.00).',
    '8. Call the displayDetails() method on object b1.',
    '9. Display the output.',
    '10. Stop the program.'
  ],
  procedure: [
    '1. Open VS Code and create BookDemo.java.',
    '2. Declare the Book class with private/package data members.',
    '3. Implement the parameterized constructor assigning arguments to this.* members.',
    '4. Implement displayDetails() showing ID, title, author, and price.',
    '5. Create BookDemo with main() invoking new Book(...) and b1.displayDetails().',
    '6. Compile and execute; verify constructor initialization output matches specification.'
  ],
  code: {
    java: `// ==========================================
// K. J. Somaiya Institute of Technology
// Experiment No. 4: Constructors in Java
// Experiment 4A: Book with Parameterized Constructor
// ==========================================

class Book {
    // Data members
    int bookId;
    String title;
    String author;
    double price;

    // Parameterized constructor
    Book(int bookId, String title, String author, double price) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.price = price;
    }

    // Method to display book details
    void displayDetails() {
        System.out.println("----- Book Details -----");
        System.out.println("Book ID : " + bookId);
        System.out.println("Title   : " + title);
        System.out.println("Author  : " + author);
        System.out.println("Price   : Rs. " + price);
    }
}

public class BookDemo {
    public static void main(String[] args) {
        // Creating object using parameterized constructor
        Book b1 = new Book(101, "Java Programming", "James Gosling", 550.00);

        // Displaying book details
        b1.displayDetails();
    }
}

/*
// Experiment 4B: Constructor Overloading (Rectangle Area)
class Rectangle {
    double length, width;

    // 1. Constructor with no arguments (default 0)
    Rectangle() {
        length = 0;
        width = 0;
    }

    // 2. Constructor with one argument (square)
    Rectangle(double side) {
        length = side;
        width = side;
    }

    // 3. Constructor with two arguments (rectangle)
    Rectangle(double l, double w) {
        length = l;
        width = w;
    }

    double getArea() {
        return length * width;
    }
}

// Experiment 4C: BankAccount Class
class BankAccount {
    String accountNumber;
    String accountHolder;
    double balance;

    BankAccount(String accNo, String holder, double bal) {
        this.accountNumber = accNo;
        this.accountHolder = holder;
        this.balance = bal;
    }

    void display() {
        System.out.println("Account : " + accountNumber + " | Holder: " + accountHolder + " | Balance: ₹" + balance);
    }
}
*/`,
    cpp: `#include <iostream>
#include <string>

class Book {
public:
    int bookId;
    std::string title;
    std::string author;
    double price;

    Book(int id, std::string t, std::string a, double p)
        : bookId(id), title(t), author(a), price(p) {}

    void displayDetails() {
        std::cout << "----- Book Details -----\\n";
        std::cout << "Book ID : " << bookId << "\\n";
        std::cout << "Title   : " << title << "\\n";
        std::cout << "Author  : " << author << "\\n";
        std::cout << "Price   : Rs. " << price << "\\n";
    }
};

int main() {
    Book b1(101, "Java Programming", "James Gosling", 550.00);
    b1.displayDetails();
    return 0;
}`
  },
  sampleInput: `(Static initialization in main: Book b1 = new Book(101, "Java Programming", "James Gosling", 550.00);)`,
  expectedOutput: `----- Book Details -----
Book ID : 101
Title   : Java Programming
Author  : James Gosling
Price   : Rs. 550.0`,
  conclusion: 'Java program demonstrating the use of default constructor, parameterized constructor, and constructor overloading was implemented and executed successfully.',
  postLabQuestions: [
    {
      question: 'What are the core characteristics that distinguish a constructor from a method in Java?',
      answer: 'A constructor must have the exact same name as the class, has no return type (not even void), and is invoked automatically only once during object instantiation with "new". A method can have any legal identifier, must declare a return type, and can be invoked repeatedly on demand.'
    },
    {
      question: 'What happens if a class defines a parameterized constructor but does not declare a default constructor?',
      answer: 'The Java compiler only supplies a default no-argument constructor if no constructors are declared in the class. Once a parameterized constructor is defined, the automatic default constructor is disabled; attempting to call new ClassName() will cause a compile-time error unless a zero-arg constructor is explicitly written.'
    },
    {
      question: 'How is constructor overloading achieved in Java?',
      answer: 'By defining multiple constructors within the same class that have distinct parameter lists (different number of parameters, different data types, or different sequence of parameter types).'
    },
    {
      question: 'What is the purpose of the "this" keyword in a parameterized constructor?',
      answer: 'The "this" reference is used to eliminate ambiguity between instance variables and formal parameters when both share the same name (e.g., this.bookId = bookId).'
    },
    {
      question: 'How does constructor chaining work using this()?',
      answer: 'A constructor can call another overloaded constructor in the same class using this(arguments), which must be the very first statement in the constructor body.'
    }
  ],
  references: [
    'KJSIT Autonomous Syllabus / OOPM Lab Manual (Department of AI & DS)',
    'Herbert Schildt, "Java: The Complete Reference", McGraw-Hill',
    'Oracle Java SE Documentation - Providing Constructors for Your Classes'
  ],
  quiz: [
    {
      id: 1,
      question: 'What is the return type of a Java constructor?',
      options: ['void', 'int', 'Object', 'Constructors have no return type'],
      correctAnswer: 3,
      explanation: 'Constructors in Java do not specify any return type, not even void.'
    },
    {
      id: 2,
      question: 'When is a constructor executed?',
      options: [
        'When the class bytecode is loaded by ClassLoader',
        'When an object is created using the new keyword',
        'When the garbage collector collects the object',
        'When the main method finishes'
      ],
      correctAnswer: 1,
      explanation: 'A constructor is invoked automatically at runtime when memory is allocated for a new object using new.'
    },
    {
      id: 3,
      question: 'Can a constructor be declared as private?',
      options: [
        'No, constructors must always be public',
        'Yes, private constructors are used to prevent direct external instantiation (e.g. in Singleton pattern)',
        'Only in abstract classes',
        'Only in interfaces'
      ],
      correctAnswer: 1,
      explanation: 'Constructors can be private; this is widely used in Singleton design patterns and utility classes.'
    },
    {
      id: 4,
      question: 'Which statement must be the first line when invoking an overloaded constructor from another constructor in the same class?',
      options: ['super();', 'this(...);', 'return this;', 'new Class();'],
      correctAnswer: 1,
      explanation: 'An explicit constructor invocation using this(...) must be the very first statement in the calling constructor body.'
    }
  ]
};
