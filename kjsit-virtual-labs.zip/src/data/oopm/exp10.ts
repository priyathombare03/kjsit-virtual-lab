import { LabExperiment } from '../../types';

export const oopmExp10: LabExperiment = {
  id: 'oopm-exp10',
  num: 10,
  subjectId: 'oopm',
  title: 'Thread Synchronization (Train Berth Booking System)',
  subtitle: 'Synchronized Blocks, Mutual Exclusion Monitors, Race Condition Elimination & Thread join() Coordination',
  category: 'Thread Synchronization & Concurrency',
  iitReference: 'K. J. Somaiya Institute of Technology / OOPM Lab Manual Experiment 9B',
  software: 'VS Code',
  aim: 'Multiple users booking train berths. totalBerths = 2. Use a synchronized block so only one user can book at a time. If no berths left, display "No seats available".',
  objective: 'To examine critical section hazards (race conditions) in multi-threaded concurrent environments, enforcing mutual exclusion through synchronized monitor locks and synchronizing thread completion with join().',
  labObjectives: [
    'Understand the concepts of thread synchronization, monitors, and critical sections.',
    'Identify race conditions and data corruption risks in shared concurrent resources.',
    'Implement synchronized blocks in Java using the intrinsic object lock (synchronized(this)).',
    'Demonstrate thread coordination and sequential rendezvous using the join() method.',
    'Prevent double-allocation and negative resource counters in multi-user booking simulations.'
  ],
  theory: {
    overview: [
      'In multi-threaded applications, when multiple concurrent threads attempt to read and modify a shared mutable resource simultaneously (such as a database counter or seat inventory), a "Race Condition" occurs. Without coordination, unpredictable scheduling can cause data corruption—such as two passengers booking the final remaining berth simultaneously, causing inventory to become negative.',
      'Thread Synchronization in Java: Java provides synchronization built on intrinsic locks (monitors). Every Java object has an associated monitor lock. When a thread enters a synchronized block (e.g. synchronized(this)), it acquires the lock on that object. All other threads attempting to enter any synchronized block on the same object are placed in the BLOCKED state until the lock holder exits the block.',
      'The join() Method: The join() method of the Thread class allows one thread to wait for the completion of another. In TrainBookingDemo, the main thread invokes user1.join(), user2.join(), user3.join(), and user4.join() to pause its own execution until all passenger threads finish processing their booking transactions, ensuring a clean and ordered final summary.'
    ],
    complexityTable: [
      { parameter: 'Lock Acquisition (Uncontended)', value: 'O(1) - JVM biased locking / thin lock CAS operation' },
      { parameter: 'Lock Contention (Contended)', value: 'O(1) - Thread suspension into OS monitor wait queue' },
      { parameter: 'Critical Section Duration', value: 'Minimal scalar check (totalBerths > 0) & decrement' },
      { parameter: 'join() Barrier Overhead', value: 'Waits for thread termination in O(T) duration' }
    ],
    keyPoints: [
      'A synchronized block requires a lock reference object (e.g., synchronized(this)).',
      'Only one thread can hold the intrinsic lock at any given instance.',
      'Without synchronization, multiple threads could evaluate totalBerths > 0 simultaneously, resulting in negative berths.',
      'The join() method throws InterruptedException, which must be caught or declared.',
      'Synchronization ensures visibility and atomicity according to the Java Memory Model (JMM).'
    ],
    realWorldApplications: [
      'Railway and airline reservation systems preventing seat over-booking (IRCTC, Amadeus).',
      'Banking payment ledgers processing simultaneous ATM and online debit card withdrawals.',
      'Inventory management systems handling flash-sale e-commerce checkouts.'
    ]
  },
  algorithm: [
    'Algorithm (Experiment 9B: Synchronized Train Berth Booking):',
    '1. Start the program.',
    '2. Create a TrainBooking class with an instance variable totalBerths = 2.',
    '3. Define a bookBerth(String userName) method to handle berth reservation.',
    '4. Create a synchronized block inside bookBerth() using the booking object as the lock (synchronized (this)).',
    '5. Inside the synchronized block, print that the user is trying to book, then check whether totalBerths > 0.',
    '6. If a berth is available:',
    '   - Display user found a berth.',
    '   - Decrease totalBerths by 1 (totalBerths--).',
    '   - Display booking confirmation and remaining berths.',
    '7. If no berth is available, display "No seats available for " + userName.',
    '8. Create a User class extending Thread holding references to TrainBooking and userName; in run(), invoke booking.bookBerth(userName).',
    '9. In TrainBookingDemo main(), create a shared TrainBooking booking = new TrainBooking().',
    '10. Create multiple User threads: user1, user2, user3, user4 sharing the same booking instance.',
    '11. Start all the threads using start().',
    '12. Wait for all threads to complete using user.join() inside try-catch(InterruptedException).',
    '13. Display "All booking requests processed." and stop the program.'
  ],
  procedure: [
    '1. Open VS Code and create TrainBookingDemo.java.',
    '2. Implement class TrainBooking with variable int totalBerths = 2.',
    '3. Write bookBerth() with a synchronized(this) block enclosing the check-and-decrement logic.',
    '4. Implement User thread class accepting TrainBooking and userName.',
    '5. In main(), create 4 user threads pointing to the single booking monitor object.',
    '6. Start all threads, call join() on each, and observe deterministic thread mutual exclusion in console output.'
  ],
  code: {
    java: `// ==========================================
// K. J. Somaiya Institute of Technology
// Experiment No. 9B: Thread Synchronization
// Train Berth Booking System
// ==========================================

class TrainBooking {
    int totalBerths = 2;

    void bookBerth(String userName) {
        // Synchronized block using intrinsic monitor lock
        synchronized (this) {
            System.out.println(userName + " is trying to book a berth...");

            if (totalBerths > 0) {
                System.out.println(userName + " found a berth.");
                totalBerths--;
                System.out.println("Booking successful for " + userName);
                System.out.println("Remaining berths: " + totalBerths);
            } else {
                System.out.println("No seats available for " + userName);
            }
            System.out.println();
        }
    }
}

class User extends Thread {
    TrainBooking booking;
    String userName;

    User(TrainBooking booking, String userName) {
        this.booking = booking;
        this.userName = userName;
    }

    public void run() {
        booking.bookBerth(userName);
    }
}

public class TrainBookingDemo {
    public static void main(String[] args) {
        TrainBooking booking = new TrainBooking();

        // Creating multiple user threads
        User user1 = new User(booking, "User 1");
        User user2 = new User(booking, "User 2");
        User user3 = new User(booking, "User 3");
        User user4 = new User(booking, "User 4");

        // Starting threads concurrently
        user1.start();
        user2.start();
        user3.start();
        user4.start();

        try {
            user1.join();
            user2.join();
            user3.join();
            user4.join();
        } catch (InterruptedException e) {
            System.out.println("Thread interrupted.");
        }

        System.out.println("All booking requests processed.");
    }
}`,
    cpp: `#include <iostream>
#include <thread>
#include <mutex>
#include <vector>
#include <string>

class TrainBooking {
private:
    int totalBerths = 2;
    std::mutex mtx;

public:
    void bookBerth(const std::string& userName) {
        std::lock_guard<std::mutex> lock(mtx);
        std::cout << userName << " is trying to book a berth...\\n";
        if (totalBerths > 0) {
            std::cout << userName << " found a berth.\\n";
            totalBerths--;
            std::cout << "Booking successful for " << userName << "\\n";
            std::cout << "Remaining berths: " << totalBerths << "\\n\\n";
        } else {
            std::cout << "No seats available for " << userName << "\\n\\n";
        }
    }
};

int main() {
    TrainBooking booking;
    std::vector<std::string> users = {"User 1", "User 2", "User 3", "User 4"};
    std::vector<std::thread> threads;

    for (const auto& u : users) {
        threads.emplace_back(&TrainBooking::bookBerth, &booking, u);
    }

    for (auto& t : threads) {
        t.join();
    }
    std::cout << "All booking requests processed.\\n";
    return 0;
}`
  },
  sampleInput: `(Concurrent execution of 4 User threads against totalBerths = 2)`,
  expectedOutput: `User 1 is trying to book a berth...
User 1 found a berth.
Booking successful for User 1
Remaining berths: 1

User 3 is trying to book a berth...
User 3 found a berth.
Booking successful for User 3
Remaining berths: 0

User 2 is trying to book a berth...
No seats available for User 2

User 4 is trying to book a berth...
No seats available for User 4

All booking requests processed.`,
  conclusion: 'Thus, the Java program successfully demonstrates multithreading and synchronization in a train berth booking system. Multiple user threads attempt to book limited berths, while the synchronized block ensures that only one user can access the booking section at a time. This prevents race conditions and ensures that the number of available berths never becomes negative.',
  postLabQuestions: [
    {
      question: 'What is a race condition, and what would happen in this program without synchronization?',
      answer: 'A race condition occurs when two or more threads attempt to modify shared state concurrently and the final result depends on non-deterministic scheduling. Without the synchronized block, two users might check totalBerths > 0 at the exact same moment when only 1 berth is left, both reserving a berth and driving totalBerths into an illegal negative state (-1).'
    },
    {
      question: 'What does the synchronized(this) statement do?',
      answer: 'It acquires the intrinsic monitor lock of the current TrainBooking instance (this). Any other thread attempting to execute a synchronized block on this same instance is blocked until the lock is released.'
    },
    {
      question: 'What is the purpose of the join() method in TrainBookingDemo?',
      answer: 'The join() method makes the main thread pause and wait until user1, user2, user3, and user4 finish their run() execution, ensuring "All booking requests processed." is printed strictly after all bookings conclude.'
    },
    {
      question: 'What is the difference between a synchronized method and a synchronized block?',
      answer: 'A synchronized method locks the entire method scope using the object\'s monitor for the entire duration of the method. A synchronized block allows fine-grained locking over only the specific critical lines of code, minimizing lock contention and maximizing concurrent throughput.'
    },
    {
      question: 'What is deadlock in multithreading?',
      answer: 'Deadlock is a situation where two or more threads are blocked forever, each waiting for a lock held by the other thread in a circular dependency.'
    }
  ],
  references: [
    'KJSIT Autonomous Syllabus / OOPM Lab Manual (Department of AI & DS)',
    'Brian Goetz, "Java Concurrency in Practice", Addison-Wesley Professional',
    'Oracle Java SE Documentation - Synchronization and Intrinsic Locks'
  ],
  quiz: [
    {
      id: 1,
      question: 'What is the primary purpose of thread synchronization in Java?',
      options: [
        'To make threads run faster',
        'To prevent race conditions when multiple threads access shared resources',
        'To stop background threads from sleeping',
        'To automatically serialize objects to disk'
      ],
      correctAnswer: 1,
      explanation: 'Synchronization ensures mutual exclusion and visibility, preventing race conditions on shared state.'
    },
    {
      id: 2,
      question: 'What lock is acquired when entering synchronized (this)?',
      options: [
        'The intrinsic lock (monitor) of the current object',
        'A global operating system file lock',
        'A lock on the Thread class bytecode',
        'A hardware CPU bus lock'
      ],
      correctAnswer: 0,
      explanation: 'synchronized(this) locks the intrinsic monitor associated with the specific object instance referenced by this.'
    },
    {
      id: 3,
      question: 'What does calling thread.join() do?',
      options: [
        'It terminates the target thread immediately',
        'It causes the calling thread to wait until the target thread finishes execution',
        'It creates a new clone of the thread',
        'It pauses the target thread indefinitely'
      ],
      correctAnswer: 1,
      explanation: 'thread.join() causes the calling thread to block until the thread on which join() was called terminates.'
    },
    {
      id: 4,
      question: 'What state is a thread in while waiting for a synchronized lock held by another thread?',
      options: ['NEW', 'RUNNABLE', 'BLOCKED', 'WAITING'],
      correctAnswer: 2,
      explanation: 'When a thread is blocked waiting for a monitor lock to enter a synchronized method or block, its state is BLOCKED.'
    }
  ]
};
