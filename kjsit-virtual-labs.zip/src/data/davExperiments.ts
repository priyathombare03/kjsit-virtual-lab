import { LabExperiment } from '../types';

export const DAV_EXPERIMENTS: LabExperiment[] = [
  {
    id: 'dav-exp1',
    num: 1,
    subjectId: 'dav',
    title: 'Exploratory Data Analysis (EDA) & Summary Statistics',
    subtitle: 'Measures of Central Tendency, Dispersion, Skewness, Kurtosis & Outlier Detection',
    category: 'Exploratory Data Analysis',
    iitReference: 'Autonomous Curriculum Standards / Data Analytics Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/dav-lab/',
    aim: 'To perform comprehensive Exploratory Data Analysis (EDA) on multi-attribute datasets, computing statistical moments, identifying missing values, and isolating outliers via Interquartile Range (IQR).',
    theory: {
      overview: [
        'Exploratory Data Analysis (EDA), formalized by John Tukey, analyzes dataset characteristics through summary statistics and visual representations before modeling.',
        'Measures of Central Tendency: Mean (sensitive to outliers), Median (robust 50th percentile), Mode.',
        'Measures of Dispersion: Variance, Standard Deviation, Interquartile Range (IQR = Q3 - Q1).',
        'Tukey’s Outlier Rule: Outliers are observations falling outside [Q1 - 1.5*IQR, Q3 + 1.5*IQR]. Extreme outliers exceed 3*IQR.',
        'Skewness measures asymmetry; Kurtosis measures tail heaviness relative to normal Gaussian distribution.'
      ],
      complexityTable: [
        { parameter: 'Summary Statistics (Mean, Var)', value: 'O(n) single pass streaming algorithms' },
        { parameter: 'Median & Quartiles (IQR)', value: 'O(n log n) sorting or O(n) QuickSelect' },
        { parameter: 'Outlier Filtering', value: 'O(n) linear boundary verification' }
      ],
      keyPoints: [
        'Missing Value Imputation: Mean/Median for numerical skewed distributions, Mode for categorical.',
        'Z-Score thresholding: |z| > 3 identifies observations beyond 3 standard deviations.'
      ],
      realWorldApplications: [
        'Financial credit card fraud detection identifying anomalous transaction amounts.',
        'Healthcare patient vitals monitoring filtering sensor calibration noise.'
      ]
    },
    algorithm: [
      '1. Ingest raw CSV dataset and inspect column data types (numerical, categorical, datetime).',
      '2. Compute Five-Number Summary: Minimum, Q1 (25th percentile), Median (50th), Q3 (75th), Maximum.',
      '3. Calculate IQR = Q3 - Q1, Lower Bound = Q1 - 1.5*IQR, Upper Bound = Q3 + 1.5*IQR.',
      '4. Identify and flag outlier indices.',
      '5. Calculate Skewness and Pearson coefficient of kurtosis.',
      '6. Generate Boxplot and Kernel Density Estimate (KDE) distribution curves.'
    ],
    procedure: [
      '1. Open the Interactive EDA Workbench.',
      '2. Select University Student Performance Dataset or Housing Prices Dataset.',
      '3. Review summary statistical table (Mean, Std, Median, IQR, Skewness).',
      '4. Observe dynamic Boxplot highlighting detected outliers in red.',
      '5. Toggle outlier clipping vs median imputation filter.'
    ],
    code: {
      python: `import pandas as pd
import numpy as np

def perform_eda(df: pd.DataFrame, col: str):
    data = df[col].dropna()
    mean = data.mean()
    median = data.median()
    std = data.std()
    
    q1 = data.quantile(0.25)
    q3 = data.quantile(0.75)
    iqr = q3 - q1
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    outliers = data[(data < lower) | (data > upper)]
    
    skew = data.skew()
    kurt = data.kurt()
    
    return {
        "mean": mean, "median": median, "std": std,
        "iqr": iqr, "outlier_count": len(outliers),
        "skewness": skew, "kurtosis": kurt
    }`,
      c: `// Statistical moments calculation`
    },
    sampleInput: 'Dataset with 500 records: CGPA column with values ranging from 4.2 to 9.9',
    expectedOutput: 'Mean: 7.82, Median: 7.90, IQR: 1.45, Outliers Detected: 6 observations.',
    references: ['John W. Tukey (1977), Exploratory Data Analysis, Addison-Wesley'],
    conclusion: 'Exploratory data analysis accurately quantified distribution skewness and successfully isolated anomalous outliers using Tukey’s IQR fences.',
    quiz: [
      {
        id: 1,
        question: 'According to Tukey’s IQR fence rule, how is an upper outlier threshold computed?',
        options: [
          'Q3 + 1.5 * IQR',
          'Mean + 2 * Standard Deviation',
          'Median + IQR',
          'Q3 * 1.5'
        ],
        correctAnswer: 0,
        explanation: 'In boxplot statistics, points exceeding Q3 + 1.5*IQR are categorized as upper outliers.'
      }
    ]
  },
  {
    id: 'dav-exp2',
    num: 2,
    subjectId: 'dav',
    title: 'Multi-Variate Correlation Matrix & Interactive Heatmaps',
    subtitle: 'Pearson & Spearman Rank Correlation, Collinearity & Feature Importance',
    category: 'Multi-Variate Analysis',
    iitReference: 'Autonomous Curriculum Standards / Data Analytics Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/dav-lab/',
    aim: 'To compute Pearson linear correlation and Spearman non-parametric rank correlation coefficients and visualize multi-attribute relationships using an interactive diverging color heatmap.',
    theory: {
      overview: [
        'Correlation measures the strength and direction of the linear or monotonic relationship between two quantitative variables.',
        'Pearson Correlation r_xy = Cov(x, y) / (σ_x * σ_y): Ranges from -1.0 (perfect negative) to +1.0 (perfect positive). Sensitive to linear relationships.',
        'Spearman Rank Correlation ρ: Computes Pearson correlation on ranked values, evaluating monotonic relationships regardless of non-linearity.',
        'Multicollinearity: High correlation between independent predictor variables (|r| > 0.85) distorts regression coefficient estimates.'
      ],
      complexityTable: [
        { parameter: 'Pairwise Pearson Matrix', value: 'O(m^2 * n) where m is features, n is rows' },
        { parameter: 'Spearman Ranking Pass', value: 'O(m * n log n) for ranking column elements' }
      ],
      keyPoints: [
        'Diverging color map (Coolwarm: Blue for -1, White for 0, Red for +1).',
        'Correlation does NOT imply causation.'
      ],
      realWorldApplications: [
        'Algorithmic trading pairs trading and portfolio diversification.',
        'Bioinformatics gene expression co-regulation networks.'
      ]
    },
    algorithm: [
      '1. Standardize numerical feature columns (Z-score normalization).',
      '2. Compute pairwise covariance matrix Cov = (X^T * X) / (N - 1).',
      '3. Normalize covariance by product of standard deviations to yield Pearson matrix R.',
      '4. Filter upper triangle of symmetric matrix to eliminate redundant pairs.',
      '5. Render interactive 2D Heatmap with tooltips displaying correlation r and p-values.'
    ],
    procedure: [
      '1. Open Correlation Heatmap Visualizer.',
      '2. Select Feature Dataset (e.g. Attendance, Lab Marks, Midterm Score, Final CGPA).',
      '3. Toggle between Pearson (Linear) and Spearman (Rank) metrics.',
      '4. Hover over heatmap cells to inspect bivariate scatter plots.',
      '5. Apply threshold slider to highlight highly collinear pairs.'
    ],
    code: {
      python: `import numpy as np
import pandas as pd

def compute_correlation_matrix(df: pd.DataFrame):
    pearson = df.corr(method='pearson')
    spearman = df.corr(method='spearman')
    return pearson, spearman`
    },
    sampleInput: 'Dataset features: [Attendance, StudyHours, InternalAssessment, FinalGrade]',
    expectedOutput: 'Strong positive correlation discovered between StudyHours and FinalGrade (r = +0.84, p < 0.001).',
    references: ['Karl Pearson (1895), Notes on regression and inheritance in the case of two parents'],
    conclusion: 'Heatmap visualization revealed strong multi-attribute dependencies and highlighted candidate collinear features for dimensionality reduction.',
    quiz: [
      {
        id: 1,
        question: 'When should Spearman rank correlation be preferred over Pearson linear correlation?',
        options: [
          'When data contains monotonic non-linear relationships or ordinal variables with significant outliers',
          'Only when the dataset has less than 10 rows',
          'Only for text strings',
          'When variables are completely uncorrelated'
        ],
        correctAnswer: 0,
        explanation: 'Spearman rank correlation evaluates monotonic relationships based on ranks rather than raw values, making it robust against non-linearities and extreme outliers.'
      }
    ]
  },
  {
    id: 'dav-exp3',
    num: 3,
    subjectId: 'dav',
    title: 'Dimensionality Reduction: Principal Component Analysis (PCA)',
    subtitle: 'Covariance Eigen-Decomposition, Scree Plots, Explained Variance & Biplots',
    category: 'Dimensionality Reduction',
    iitReference: 'Autonomous Curriculum Standards / Data Analytics Virtual Lab (vlabs.ac.in)',
    iitLabUrl: 'https://vlab.co.in/dav-lab/',
    aim: 'To reduce high-dimensional multivariate data to 2D/3D latent principal components using eigen-decomposition and construct Scree plots of explained variance ratio.',
    theory: {
      overview: [
        'Principal Component Analysis (PCA) is an unsupervised linear transformation technique that maps high-dimensional data into orthogonal axes of maximum variance.',
        'Principal Component 1 (PC1) captures the direction of greatest variance in the data; PC2 is orthogonal to PC1 and captures the second highest variance.',
        'Mathematical formulation: Eigen-decomposition of the sample covariance matrix Σ: Σ * v_i = λ_i * v_i, where λ_i is the eigenvalue (variance explained) and v_i is the eigenvector (principal direction).',
        'Scree Plot: Visualizes eigenvalues in descending order to identify the elbow cutoff for retaining k components.'
      ],
      complexityTable: [
        { parameter: 'Covariance Matrix', value: 'O(n * d^2) where n is samples, d is dimensions' },
        { parameter: 'Eigen-Decomposition', value: 'O(d^3) cubic in feature count' }
      ],
      keyPoints: [
        'Features MUST be centered (mean = 0) and scaled (variance = 1) before computing PCA.',
        'Cumulative explained variance ratio (e.g. 95%) dictates the number of retained dimensions.'
      ],
      realWorldApplications: [
        'Genomics micro-array visualization collapsing 20,000 gene features into 2D clusters.',
        'Facial recognition (Eigenfaces) compressing image pixel dimensions.'
      ]
    },
    algorithm: [
      '1. Standardize data matrix X (n x d): X_std = (X - μ) / σ.',
      '2. Compute sample covariance matrix: Cov = (1 / (n - 1)) * X_std^T * X_std.',
      '3. Compute eigenvalues λ and eigenvectors V using singular value decomposition (SVD).',
      '4. Sort eigenvalues in descending order and sort eigenvectors accordingly.',
      '5. Select top k eigenvectors to form projection matrix W (d x k).',
      '6. Transform data into low-dimensional space: Z = X_std * W.',
      '7. Plot 2D scatter of PC1 vs PC2 and render Scree Plot of cumulative variance.'
    ],
    procedure: [
      '1. Open PCA Dimensionality Simulator.',
      '2. Load Iris or Wine 13-feature dataset.',
      '3. Inspect Scree Plot showing variance explained per component.',
      '4. Project data onto 2D PC1 vs PC2 biplot with feature loading vectors.',
      '5. Observe distinct cluster separation without supervised class labels.'
    ],
    code: {
      python: `import numpy as np

def pca(X: np.ndarray, n_components: int = 2):
    # 1. Standardize
    X_std = (X - np.mean(X, axis=0)) / np.std(X, axis=0)
    # 2. Covariance matrix
    cov_mat = np.cov(X_std, rowvar=False)
    # 3. Eigen-decomposition
    eigen_vals, eigen_vecs = np.linalg.eigh(cov_mat)
    # 4. Sort descending
    idx = np.argsort(eigen_vals)[::-1]
    sorted_vals = eigen_vals[idx]
    sorted_vecs = eigen_vecs[:, idx]
    # 5. Projection
    W = sorted_vecs[:, :n_components]
    X_pca = np.dot(X_std, W)
    explained_variance_ratio = sorted_vals / np.sum(sorted_vals)
    return X_pca, explained_variance_ratio[:n_components]`
    },
    sampleInput: '13-Dimensional Wine chemical analysis dataset',
    expectedOutput: 'Top 2 Principal Components capture 55.4% of total variance, cleanly separating wine cultivars in 2D.',
    references: ['Harold Hotelling (1933), Analysis of a complex of statistical variables into principal components'],
    conclusion: 'PCA successfully compressed 13 continuous dimensions into 2 orthogonal components while preserving over half the system variance.',
    quiz: [
      {
        id: 1,
        question: 'Why is feature scaling essential before executing Principal Component Analysis (PCA)?',
        options: [
          'Because features with large numerical magnitudes will artificially dominate the direction of maximum variance',
          'Because PCA cannot compute negative numbers',
          'Because eigenvalues must always sum to 100',
          'To convert continuous values into categorical strings'
        ],
        correctAnswer: 0,
        explanation: 'PCA maximizes variance. If one feature is measured in kilograms and another in milligrams, the latter would exhibit massive numerical variance and dominate the principal components unless standardized.'
      }
    ]
  }
];
