import { OSExperiment } from '../types';

export const OS_EXPERIMENTS: OSExperiment[] = [
  {
    id: 'process-system-calls',
    num: 1,
    subjectId: 'os',
    title: 'UNIX / Linux System Calls & Process Management',
    subtitle: 'Process Hierarchy, fork(), exec(), wait(), exit(), and Zombie/Orphan Lifecycle',
    category: 'System Calls & Process API',
    iitReference: 'Autonomous Curriculum Standards/ Autonomous Curriculum StandardsVirtual Lab: Process Management & System Calls',
    iitLabUrl: 'https://vlabs.ac.in',
    aim: 'To understand process creation, execution, synchronization, and termination in UNIX/Linux systems using fundamental system calls: fork(), exec(), wait(), and exit(), and to analyze Zombie and Orphan process states.',
    theory: {
      overview: [
        'A process is an instance of a computer program in execution. In UNIX/Linux operating systems, every process is uniquely identified by a Process ID (PID) and maintains a Parent Process ID (PPID).',
        'The fork() system call creates an exact duplicate child process. Upon successful invocation, fork() returns 0 to the child process, returns the child PID to the parent process, and returns -1 upon failure.',
        'The exec() family (execl, execv, execvp) replaces the current process memory image, code segment, and stack with a new executable binary.',
        'The wait() and waitpid() system calls suspend the parent process execution until one of its child processes terminates, harvesting its termination status from the kernel Process Table.',
        'A Zombie process is a terminated process whose parent has not yet invoked wait(), leaving its entry in the process table. An Orphan process is an active process whose parent has terminated, causing it to be adopted by systemd/init (PID 1).'
      ],
      complexityTable: [
        { parameter: 'fork() System Call Overhead', value: 'O(1) with Copy-On-Write (COW) page sharing' },
        { parameter: 'exec() Memory Replacement', value: 'O(M) where M is the size of the binary text & data' },
        { parameter: 'Process Table Entry Size', value: 'Fixed Task Struct (task_struct in Linux kernel)' },
        { parameter: 'wait() Synchronization Time', value: 'O(1) to O(child execution duration)' }
      ],
      keyPoints: [
        'Process Control Block (PCB) stores PID, registers, Program Counter (PC), memory limits, and open file descriptors.',
        'Copy-On-Write (COW) optimization avoids copying physical pages until either parent or child writes to memory.',
        'Zombie processes consume Process Table slots; excessive zombies can exhaust system PID limits.',
        'The init process (PID 1) periodically reaps orphaned zombie processes to maintain system stability.'
      ],
      realWorldApplications: [
        'Shell implementations (bash, zsh) using fork-exec-wait patterns for running user commands.',
        'Web servers (Apache prefork MPM) spawning child worker processes for concurrent HTTP request handling.',
        'Daemon and service management in Linux systemd and container runtimes like Docker and containerd.'
      ]
    },
    algorithm: [
      '1. Parent process executes and invokes pid = fork().',
      '2. Kernel checks for available PIDs and clones the PCB, file descriptors, and virtual memory mappings.',
      '3. If pid < 0: Fork failed due to memory or PID exhaustion; handle error.',
      '4. If pid == 0: In child context. Print Child PID (getpid()) and Parent PID (getppid()). Optionally invoke execvp() to execute a target program.',
      '5. If pid > 0: In parent context. Parent invokes wait(&status) to block until child exits and reap its termination status code.',
      '6. Child terminates via exit(0), sending SIGCHLD signal to parent, concluding execution.'
    ],
    procedure: [
      'Step 1: Inspect the interactive Process Tree visualizer.',
      'Step 2: Click "Execute fork()" to trigger process splitting and observe PID assignments.',
      'Step 3: Toggle the "Orphan Process" or "Zombie Process" scenario to watch parent termination vs delayed wait() harvesting.',
      'Step 4: Review the kernel Process Control Block (PCB) attributes for both parent and child.'
    ],
    code: {
      c: `#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    pid_t pid;
    int status;

    printf("Parent Process (PID: %d) starting...\\n", getpid());

    pid = fork();

    if (pid < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    } else if (pid == 0) {
        // Child Process
        printf("[CHILD] PID: %d, PPID: %d\\n", getpid(), getppid());
        printf("[CHILD] Executing task and exiting with code 42...\\n");
        sleep(1);
        exit(42);
    } else {
        // Parent Process
        printf("[PARENT] Spawned child with PID: %d. Waiting for completion...\\n", pid);
        pid_t terminated_child = wait(&status);

        if (WIFEXITED(status)) {
            printf("[PARENT] Child PID %d exited normally with status: %d\\n",
                   terminated_child, WEXITSTATUS(status));
        }
    }
    return 0;
}`,
      cpp: `#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    std::cout << "[PARENT] Process ID: " << getpid() << std::endl;
    pid_t pid = fork();

    if (pid == 0) {
        std::cout << "[CHILD] PID: " << getpid() << " | Parent PID: " << getppid() << std::endl;
        _exit(0);
    } else if (pid > 0) {
        int status;
        waitpid(pid, &status, 0);
        std::cout << "[PARENT] Reaped child PID: " << pid << std::endl;
    }
    return 0;
}`,
      python: `import os
import time

print(f"[PARENT] PID: {os.getpid()}")
pid = os.fork()

if pid == 0:
    print(f"[CHILD] PID: {os.getpid()}, Parent: {os.getppid()}")
    os._exit(0)
else:
    print(f"[PARENT] Created child with PID: {pid}")
    child_pid, status = os.waitpid(pid, 0)
    print(f"[PARENT] Child {child_pid} reaped with exit code {status >> 8}")`,
      java: `import java.io.IOException;

public class ProcessDemo {
    public static void main(String[] args) throws IOException, InterruptedException {
        System.out.println("Main Java PID: " + ProcessHandle.current().pid());
        ProcessBuilder pb = new ProcessBuilder("echo", "Hello from spawned child process");
        Process p = pb.start();
        int exitCode = p.waitFor();
        System.out.println("Child finished with exit code: " + exitCode);
    }
}`
    },
    sampleInput: `Spawn child process with fork(), parent waits for child termination.`,
    expectedOutput: `Parent Process (PID: 1024) starting...
[PARENT] Spawned child with PID: 1025. Waiting for completion...
[CHILD] PID: 1025, PPID: 1024
[CHILD] Executing task and exiting with code 42...
[PARENT] Child PID 1025 exited normally with status: 42`,
    references: [
      'Silberschatz, Galvin, Gagne - Operating System Concepts (10th Ed), Chapter 3: Processes',
      'W. Richard Stevens - Advanced Programming in the UNIX Environment (APUE)',
      'Autonomous Curriculum StandardsVirtual Labs - Process Creation & Control (vlabs.ac.in)'
    ],
    conclusion: 'Demonstrated process life cycle using fork(), exec(), wait(), and exit() system calls, validating parent-child process synchronization and resource cleanup in the UNIX process table.',
    quiz: [
      {
        id: 1,
        question: 'What return value does fork() produce in the newly created child process upon success?',
        options: ['Child Process PID', '0', '-1', '1'],
        correctAnswer: 1,
        explanation: 'fork() returns 0 to the child process, allowing code logic to branch into the child execution path.'
      },
      {
        id: 2,
        question: 'What is a Zombie process in UNIX systems?',
        options: [
          'A process that has hung in an infinite loop',
          'A terminated process whose parent has not yet collected its exit status via wait()',
          'A process whose parent terminated before the child',
          'A process executing with root administrative privileges'
        ],
        correctAnswer: 1,
        explanation: 'A zombie process has finished execution but remains in the process table until its parent reads its exit status with wait().'
      },
      {
        id: 3,
        question: 'Which process adopts an orphan process when its parent process terminates prematurely?',
        options: ['Kernel idle process (PID 0)', 'Init / systemd process (PID 1)', 'Parent of the parent process', 'No process; it terminates immediately'],
        correctAnswer: 1,
        explanation: 'Orphan processes are automatically adopted by the system init/systemd daemon (PID 1), which periodically executes wait() to reap them.'
      },
      {
        id: 4,
        question: 'What mechanism allows fork() to avoid copying all physical memory pages immediately?',
        options: ['Direct Memory Access (DMA)', 'Copy-On-Write (COW)', 'Demand Paging', 'Virtual Address Translation'],
        correctAnswer: 1,
        explanation: 'Copy-On-Write (COW) shares read-only pages between parent and child until one of them performs a write, minimizing overhead.'
      }
    ]
  },
  {
    id: 'cpu-scheduling-sjf-fcfs',
    num: 2,
    subjectId: 'os',
    title: 'CPU Scheduling: FCFS & Shortest Job First (SJF / SRTF)',
    subtitle: 'Non-Preemptive FCFS, Non-Preemptive SJF, and Preemptive Shortest Remaining Time First',
    category: 'CPU Scheduling',
    iitReference: 'Autonomous Curriculum Standards/ Autonomous Curriculum StandardsVirtual Lab: CPU Scheduling Algorithms',
    iitLabUrl: 'https://vlabs.ac.in',
    aim: 'To simulate and analyze Non-Preemptive First Come First Serve (FCFS), Non-Preemptive Shortest Job First (SJF), and Preemptive Shortest Remaining Time First (SRTF) CPU scheduling algorithms, calculating Waiting Time, Turnaround Time, and Average Metrics.',
    theory: {
      overview: [
        'CPU Scheduling is the process of deciding which process in the ready queue is allocated the CPU when the processor becomes idle.',
        'FCFS (First-Come, First-Served) is a non-preemptive algorithm that assigns the CPU to the process that requests it first in order of arrival. It suffers from the "Convoy Effect" where short processes get delayed behind a CPU-intensive long process.',
        'SJF (Shortest Job First) assigns the CPU to the process with the smallest burst time. SJF is mathematically provably optimal in minimizing average waiting time for a set of stationary processes.',
        'SRTF (Shortest Remaining Time First) is the preemptive version of SJF. If a new process arrives with a remaining CPU burst time shorter than the currently running process, the CPU is preempted.'
      ],
      complexityTable: [
        { parameter: 'FCFS Scheduling Time Complexity', value: 'O(N) with standard FIFO Queue' },
        { parameter: 'SJF Selection Complexity', value: 'O(N log N) using Min-Priority Queue / Min-Heap' },
        { parameter: 'SRTF Preemptive Check Complexity', value: 'O(log N) per arrival and tick' },
        { parameter: 'Turnaround Time (TAT) Formula', value: 'TAT = Completion Time (CT) - Arrival Time (AT)' },
        { parameter: 'Waiting Time (WT) Formula', value: 'WT = Turnaround Time (TAT) - Burst Time (BT)' }
      ],
      keyPoints: [
        'Convoy effect in FCFS causes high average waiting times when a long job precedes short jobs.',
        'SJF is optimal for average waiting time, but predicting future CPU burst time requires exponential smoothing.',
        'SRTF provides lower average waiting times than non-preemptive SJF but introduces context switching overhead.'
      ],
      realWorldApplications: [
        'Batch processing systems and print queue management (FCFS / SJF).',
        'Real-time transaction schedulers prioritizing lightweight micro-tasks (SRTF).',
        'Kernel task dispatchers and thread pool priority queues.'
      ]
    },
    algorithm: [
      '1. Input process list with Process ID (PID), Arrival Time (AT), and Burst Time (BT).',
      '2. For FCFS: Sort ready queue by AT. For each process: Start Time = max(Current Time, AT), Completion Time = Start Time + BT. Calculate TAT = CT - AT, WT = TAT - BT.',
      '3. For Non-Preemptive SJF: At current time T, filter all arrived uncompleted processes. Pick process with minimum BT. Run to completion, update T = T + BT.',
      '4. For Preemptive SRTF: At each clock tick, select arrived process with minimum Remaining Burst Time. Decrement remaining time by 1. If remaining time == 0, mark completed and compute CT, TAT, WT.',
      '5. Output Gantt Chart, per-process WT & TAT, and compute Average WT and Average TAT.'
    ],
    procedure: [
      'Step 1: Set process parameters (Arrival Times & Burst Times) or select standard KJSIT test cases.',
      'Step 2: Toggle between FCFS, Non-Preemptive SJF, and Preemptive SRTF.',
      'Step 3: Play step-by-step or run full simulation to observe the animated Gantt Chart.',
      'Step 4: Compare Average Waiting Time and Turnaround Time metrics across algorithms.'
    ],
    code: {
      c: `#include <stdio.h>
#include <stdbool.h>

struct Process {
    int pid, at, bt, ct, tat, wt, rt;
};

void calculateFCFS(struct Process p[], int n) {
    int current_time = 0;
    float total_wt = 0, total_tat = 0;

    for (int i = 0; i < n; i++) {
        if (current_time < p[i].at) current_time = p[i].at;
        p[i].ct = current_time + p[i].bt;
        p[i].tat = p[i].ct - p[i].at;
        p[i].wt = p[i].tat - p[i].bt;
        current_time = p[i].ct;
        total_wt += p[i].wt;
        total_tat += p[i].tat;
    }

    printf("\\n--- FCFS Scheduling Results ---\\n");
    printf("PID\\tAT\\tBT\\tCT\\tTAT\\tWT\\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\\t%d\\t%d\\t%d\\t%d\\t%d\\n",
               p[i].pid, p[i].at, p[i].bt, p[i].ct, p[i].tat, p[i].wt);
    }
    printf("Average Waiting Time: %.2f\\n", total_wt / n);
    printf("Average Turnaround Time: %.2f\\n", total_tat / n);
}

int main() {
    struct Process p[] = {
        {1, 0, 8, 0, 0, 0, 8},
        {2, 1, 4, 0, 0, 0, 4},
        {3, 2, 9, 0, 0, 0, 9},
        {4, 3, 5, 0, 0, 0, 5}
    };
    calculateFCFS(p, 4);
    return 0;
}`,
      cpp: `#include <iostream>
#include <vector>
#include <algorithm>

struct Process {
    int id, at, bt, ct, tat, wt;
};

void runSJF(std::vector<Process>& procs) {
    int n = procs.size();
    std::sort(procs.begin(), procs.end(), [](const Process& a, const Process& b){ return a.at < b.at; });
    int completed = 0, time = 0;
    std::vector<bool> isDone(n, false);

    while (completed < n) {
        int idx = -1, min_bt = 1e9;
        for (int i = 0; i < n; i++) {
            if (procs[i].at <= time && !isDone[i] && procs[i].bt < min_bt) {
                min_bt = procs[i].bt;
                idx = i;
            }
        }
        if (idx != -1) {
            time += procs[idx].bt;
            procs[idx].ct = time;
            procs[idx].tat = procs[idx].ct - procs[idx].at;
            procs[idx].wt = procs[idx].tat - procs[idx].bt;
            isDone[idx] = true;
            completed++;
        } else {
            time++;
        }
    }
}`,
      python: `def simulate_srtf(processes):
    # processes: list of (pid, at, bt)
    n = len(processes)
    rem_bt = [p[2] for p in processes]
    completed = 0
    t = 0
    ct = [0] * n

    while completed < n:
        min_rem = float('inf')
        idx = -1
        for i in range(n):
            if processes[i][1] <= t and rem_bt[i] > 0 and rem_bt[i] < min_rem:
                min_rem = rem_bt[i]
                idx = i
        if idx != -1:
            rem_bt[idx] -= 1
            if rem_bt[idx] == 0:
                completed += 1
                ct[idx] = t + 1
            t += 1
        else:
            t += 1
    return ct`,
      java: `import java.util.*;

class CPUScheduler {
    public static void main(String[] args) {
        System.out.println("CPU Scheduler: FCFS and SJF simulator");
    }
}`
    },
    sampleInput: `Processes: P1(AT=0, BT=8), P2(AT=1, BT=4), P3(AT=2, BT=9), P4(AT=3, BT=5)`,
    expectedOutput: `--- FCFS Scheduling Results ---
PID	AT	BT	CT	TAT	WT
P1	0	8	8	8	0
P2	1	4	12	11	7
P3	2	9	21	19	10
P4	3	5	26	23	18
Average Waiting Time: 8.75
Average Turnaround Time: 15.25`,
    references: [
      'Silberschatz, Galvin, Gagne - Operating System Concepts (10th Ed), Chapter 5: CPU Scheduling',
      'Autonomous Curriculum StandardsVirtual Lab - CPU Scheduling (vlabs.ac.in)'
    ],
    conclusion: 'Analyzed FCFS, SJF, and SRTF scheduling mechanics, proving SJF and SRTF yield significantly lower average waiting times compared to standard FCFS.',
    quiz: [
      {
        id: 1,
        question: 'Which phenomenon describes short processes getting stuck waiting behind a CPU-heavy process in FCFS?',
        options: ['Starvation', 'Convoy Effect', 'Priority Inversion', 'Thrashing'],
        correctAnswer: 1,
        explanation: 'The Convoy Effect occurs in FCFS when smaller processes wait for a long CPU-bound process to finish execution.'
      },
      {
        id: 2,
        question: 'Which scheduling algorithm is provably optimal for minimizing average waiting time for a set of stationary processes?',
        options: ['First Come First Serve (FCFS)', 'Round Robin (RR)', 'Shortest Job First (SJF)', 'Priority Scheduling'],
        correctAnswer: 2,
        explanation: 'SJF gives the minimum average waiting time because scheduling shorter jobs ahead reduces cumulative wait times.'
      },
      {
        id: 3,
        question: 'What is the Turnaround Time (TAT) formula?',
        options: ['TAT = Burst Time - Arrival Time', 'TAT = Completion Time - Arrival Time', 'TAT = Waiting Time + Arrival Time', 'TAT = Completion Time - Burst Time'],
        correctAnswer: 1,
        explanation: 'Turnaround time is the total interval from process submission (Arrival Time) to its completion (Completion Time).'
      },
      {
        id: 4,
        question: 'What is the preemptive counterpart of Shortest Job First (SJF)?',
        options: ['Multi-Level Feedback Queue', 'Shortest Remaining Time First (SRTF)', 'Round Robin', 'Earliest Deadline First'],
        correctAnswer: 1,
        explanation: 'SRTF evaluates remaining burst times upon new arrivals and preempts if a shorter remaining job arrives.'
      }
    ]
  },
  {
    id: 'cpu-scheduling-rr-priority',
    num: 3,
    subjectId: 'os',
    title: 'Round Robin (RR) & Priority CPU Scheduling',
    subtitle: 'Time Quantum Slicing, Context Switch Overhead, and Preemptive/Non-Preemptive Priority',
    category: 'CPU Scheduling',
    iitReference: 'Autonomous Curriculum Standards/ Autonomous Curriculum StandardsVirtual Lab: Interactive CPU Scheduling',
    iitLabUrl: 'https://vlabs.ac.in',
    aim: 'To implement and evaluate Round Robin (RR) scheduling with variable time quantum and Priority Scheduling (both preemptive and non-preemptive), observing ready queue rotation and context switch overhead.',
    theory: {
      overview: [
        'Round Robin (RR) is designed specifically for time-sharing systems. The CPU scheduler goes around the ready queue, allocating the CPU to each process for a time interval of up to 1 time quantum (q).',
        'If a process burst time exceeds q, the process is preempted and placed at the tail of the ready queue. If q is very large, RR degenerates into FCFS. If q is very small, RR causes excessive context switching overhead.',
        'Priority Scheduling assigns an integer priority rank to each process. The CPU is allocated to the process with the highest priority (lowest integer or highest integer depending on convention).',
        'A major drawback of priority scheduling is indefinite blocking (Starvation) of low-priority processes. This is solved by Aging, where process priority is gradually incremented over time.'
      ],
      complexityTable: [
        { parameter: 'Round Robin Time Complexity', value: 'O(Total Burst / q) dispatch events' },
        { parameter: 'Priority Queue Scheduling', value: 'O(log N) insert & extract-min per arrival' },
        { parameter: 'Optimal Time Quantum (Rule of Thumb)', value: '80% of CPU bursts should be shorter than q' },
        { parameter: 'Context Switch Latency', value: 'Typically 1-10 microseconds on modern CPUs' }
      ],
      keyPoints: [
        'Round Robin provides fair sharing and guarantees low response times for interactive user processes.',
        'Excessive context switching in RR wastes CPU clock cycles saving and restoring PCB register states.',
        'Priority scheduling can lead to Priority Inversion, which is resolved in real-time kernels using Priority Inheritance.'
      ],
      realWorldApplications: [
        'Modern Linux Completely Fair Scheduler (CFS) and Windows thread schedulers.',
        'Interactive desktop operating systems providing responsive GUI event loops.',
        'Real-time operating systems (RTOS) with hard deadline priority queues.'
      ]
    },
    algorithm: [
      '1. Round Robin: Initialize Ready Queue Q with processes sorted by Arrival Time.',
      '2. Push arrived processes into Q. While Q is not empty:',
      '   a. Pop front process P from Q.',
      '   b. Run P for slice = min(P.remaining_time, time_quantum).',
      '   c. Advance current time by slice. Push any new processes arriving during this window into Q.',
      '   d. If P.remaining_time > 0, push P back to the end of Q.',
      '   e. Else P is complete; record Completion Time (CT), compute TAT and WT.',
      '3. For Priority: Select arrived uncompleted process with highest priority value. Handle preemption if higher priority process arrives.',
      '4. Generate Gantt chart and compute performance metrics.'
    ],
    procedure: [
      'Step 1: Set process parameters (AT, BT, Priority) and configure the Time Quantum (q = 1 to 10).',
      'Step 2: Select "Round Robin" or "Priority (Preemptive/Non-Preemptive)".',
      'Step 3: Step through the execution tick-by-tick to observe Ready Queue state changes and Gantt chart construction.',
      'Step 4: Analyze how varying the Time Quantum impacts Context Switches and Average Waiting Time.'
    ],
    code: {
      c: `#include <stdio.h>
#include <stdbool.h>

struct Process {
    int pid, at, bt, rem_bt, ct, tat, wt;
};

void roundRobin(struct Process p[], int n, int quantum) {
    int time = 0, completed = 0;
    int queue[100], front = 0, rear = 0;
    bool in_queue[100] = {false};

    // Push initial processes arriving at t=0
    for (int i = 0; i < n; i++) {
        p[i].rem_bt = p[i].bt;
        if (p[i].at <= time) {
            queue[rear++] = i;
            in_queue[i] = true;
        }
    }

    while (completed < n) {
        if (front == rear) {
            time++;
            for (int i = 0; i < n; i++) {
                if (p[i].at <= time && !in_queue[i] && p[i].rem_bt > 0) {
                    queue[rear++] = i;
                    in_queue[i] = true;
                }
            }
            continue;
        }

        int curr = queue[front++];
        int exec_time = (p[curr].rem_bt > quantum) ? quantum : p[curr].rem_bt;
        p[curr].rem_bt -= exec_time;
        time += exec_time;

        for (int i = 0; i < n; i++) {
            if (p[i].at <= time && !in_queue[i] && p[i].rem_bt > 0) {
                queue[rear++] = i;
                in_queue[i] = true;
            }
        }

        if (p[curr].rem_bt > 0) {
            queue[rear++] = curr;
        } else {
            completed++;
            p[curr].ct = time;
            p[curr].tat = p[curr].ct - p[curr].at;
            p[curr].wt = p[curr].tat - p[curr].bt;
        }
    }
}`,
      cpp: `#include <iostream>
#include <queue>
#include <vector>

// Priority & Round Robin Scheduler in C++
int main() {
    std::cout << "Round Robin & Priority Scheduling Simulator\\n";
    return 0;
}`,
      python: `def round_robin(processes, quantum):
    # processes: [(pid, at, bt), ...]
    time = 0
    queue = []
    # Implementation of RR queue simulation
    pass`,
      java: `public class RoundRobinScheduler {
    public static void main(String[] args) {
        System.out.println("RR Scheduler");
    }
}`
    },
    sampleInput: `Processes: P1(AT=0, BT=5), P2(AT=1, BT=3), P3(AT=2, BT=8), P4(AT=3, BT=6), Time Quantum = 2`,
    expectedOutput: `Gantt Chart: [P1: 0-2][P2: 2-4][P3: 4-6][P1: 6-8][P4: 8-10][P2: 10-11][P3: 11-13]...
Average Turnaround Time: 14.25
Average Waiting Time: 8.75`,
    references: [
      'Silberschatz, Galvin, Gagne - Operating System Concepts, Chapter 5: Scheduling Algorithms',
      'Autonomous Curriculum StandardsVirtual Labs - Round Robin Scheduling'
    ],
    conclusion: 'Demonstrated Round Robin scheduling fair-share dispatching and evaluated the trade-off between time quantum length, context switch frequency, and responsiveness.',
    quiz: [
      {
        id: 1,
        question: 'What happens if the Round Robin time quantum is set to an extremely large value (larger than any burst time)?',
        options: ['It causes an infinite loop', 'It degenerates into First-Come First-Served (FCFS)', 'It behaves identically to Shortest Job First', 'It doubles context switches'],
        correctAnswer: 1,
        explanation: 'When the time quantum exceeds all burst times, every process runs to completion on its first turn, behaving like FCFS.'
      },
      {
        id: 2,
        question: 'What technique is used in Priority Scheduling to prevent low-priority processes from starving indefinitely?',
        options: ['Thrashing', 'Compaction', 'Aging', 'Preemption'],
        correctAnswer: 2,
        explanation: 'Aging gradually increases the priority of processes that wait in the system for a long time.'
      },
      {
        id: 3,
        question: 'What is the primary trade-off when selecting a very small time quantum in Round Robin?',
        options: ['High CPU throughput vs low memory usage', 'High responsiveness vs high context-switching CPU overhead', 'Lower latency vs starvation', 'Deadlock susceptibility'],
        correctAnswer: 1,
        explanation: 'A very small quantum gives excellent interactive response time but wastes significant CPU time on context switches.'
      },
      {
        id: 4,
        question: 'Which component performs the actual saving of registers and switching of processor context between threads?',
        options: ['Long-term Scheduler', 'Dispatcher', 'Swapper', 'Memory Management Unit'],
        correctAnswer: 1,
        explanation: 'The Dispatcher is the kernel module that gives control of the CPU to the process selected by the short-term scheduler.'
      }
    ]
  },
  {
    id: 'ipc-pipes-shared-memory',
    num: 4,
    subjectId: 'os',
    title: 'Inter-Process Communication (IPC): Pipes & Shared Memory',
    subtitle: 'UNIX Anonymous & Named Pipes (FIFOs), POSIX Shared Memory (shmget/shmat), and Circular Ring Buffers',
    category: 'Inter-Process Communication',
    iitReference: 'Autonomous Curriculum Standards/ Autonomous Curriculum StandardsVirtual Lab: Interprocess Communication',
    iitLabUrl: 'https://vlabs.ac.in',
    aim: 'To simulate and explore Inter-Process Communication (IPC) mechanisms in UNIX/Linux including anonymous unidirectional pipes (pipe()), named pipes (mkfifo()), and high-throughput POSIX shared memory buffers.',
    theory: {
      overview: [
        'Inter-Process Communication (IPC) allows cooperating processes to exchange data, synchronize actions, and notify events.',
        'Anonymous Pipes provide a unidirectional byte stream communication channel between related processes (e.g. parent and child). The pipe() system call creates two file descriptors: fd[0] for reading and fd[1] for writing.',
        'Named Pipes (FIFOs) extend pipes across unrelated processes by associating a special FIFO file node in the filesystem via mkfifo().',
        'Shared Memory is the fastest IPC mechanism because processes map a common physical memory segment directly into their virtual address spaces without kernel-space memory copying.'
      ],
      complexityTable: [
        { parameter: 'Pipe Throughput', value: 'Limited by kernel buffer size (typically 64KB on Linux)' },
        { parameter: 'Shared Memory Overhead', value: 'Zero kernel copies (Fastest IPC method)' },
        { parameter: 'Pipe Synchronization', value: 'Implicit blocking I/O (read blocks on empty pipe)' },
        { parameter: 'Shared Memory Sync', value: 'Requires explicit Semaphores or Mutexes' }
      ],
      keyPoints: [
        'Reading from an empty pipe blocks until data is written; writing to a full pipe blocks until space is freed.',
        'Pipes automatically handle synchronization and flow control via kernel buffers.',
        'Shared memory bypasses kernel context switches for I/O but requires mutexes to prevent race conditions.'
      ],
      realWorldApplications: [
        'UNIX command pipelines (`cat access.log | grep 404 | wc -l`).',
        'High-frequency trading architectures utilizing lock-free shared memory rings.',
        'Inter-process messaging in database engines (PostgreSQL shared buffers, Oracle SGA).'
      ]
    },
    algorithm: [
      '1. Pipe Setup: Parent creates pipe array int fd[2] via pipe(fd).',
      '2. Parent invokes fork() to spawn child.',
      '3. Child closes unused write-end fd[1] and reads from fd[0] into a buffer.',
      '4. Parent closes unused read-end fd[0] and writes message string to fd[1].',
      '5. Kernel transfers bytes through internal circular buffer. Child prints received message and exits.',
      '6. Shared Memory alternative: shm_open() creates memory object, ftruncate() sets size, and mmap() maps into memory.'
    ],
    procedure: [
      'Step 1: Inspect the interactive IPC buffer pipeline with Producer Process (PID A) and Consumer Process (PID B).',
      'Step 2: Type a message payload and click "Write to Pipe (fd[1])".',
      'Step 3: Watch the kernel byte buffer fill and observe the consumer process reading from fd[0].',
      'Step 4: Switch to "POSIX Shared Memory" mode to examine zero-copy memory segment access.'
    ],
    code: {
      c: `#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

int main() {
    int fd[2];
    char write_msg[] = "KJSIT Virtual Lab: IPC Message via Pipe";
    char read_msg[100];
    pid_t pid;

    if (pipe(fd) == -1) {
        perror("Pipe creation failed");
        return 1;
    }

    pid = fork();
    if (pid < 0) {
        perror("fork failed");
        return 1;
    }

    if (pid > 0) {
        // Parent Process: Producer
        close(fd[0]); // Close read end
        printf("[PARENT] Writing message to pipe: '%s'\\n", write_msg);
        write(fd[1], write_msg, strlen(write_msg) + 1);
        close(fd[1]);
    } else {
        // Child Process: Consumer
        close(fd[1]); // Close write end
        read(fd[0], read_msg, sizeof(read_msg));
        printf("[CHILD] Received message from pipe: '%s'\\n", read_msg);
        close(fd[0]);
    }
    return 0;
}`,
      cpp: `#include <iostream>
#include <unistd.h>
#include <cstring>

int main() {
    int pipefd[2];
    pipe(pipefd);
    if (fork() == 0) {
        close(pipefd[1]);
        char buf[128];
        read(pipefd[0], buf, sizeof(buf));
        std::cout << "[Child] Read: " << buf << std::endl;
        close(pipefd[0]);
    } else {
        close(pipefd[0]);
        const char* msg = "Hello from Parent";
        write(pipefd[1], msg, strlen(msg)+1);
        close(pipefd[1]);
    }
    return 0;
}`,
      python: `import os

r_fd, w_fd = os.pipe()
pid = os.fork()

if pid == 0:
    os.close(w_fd)
    r_stream = os.fdopen(r_fd, 'r')
    print(f"[CHILD] Received: {r_stream.read()}")
else:
    os.close(r_fd)
    w_stream = os.fdopen(w_fd, 'w')
    w_stream.write("IPC Data Stream from Python")
    w_stream.close()`,
      java: `import java.io.*;

public class PipeDemo {
    public static void main(String[] args) throws IOException {
        PipedOutputStream pout = new PipedOutputStream();
        PipedInputStream pin = new PipedInputStream(pout);
        pout.write("Piped Java Stream".getBytes());
        byte[] buf = new byte[50];
        int len = pin.read(buf);
        System.out.println(new String(buf, 0, len));
    }
}`
    },
    sampleInput: `Write payload "Operating Systems Virtual Lab" to pipefd[1].`,
    expectedOutput: `[PARENT] Writing message to pipe: 'KJSIT Virtual Lab: IPC Message via Pipe'
[CHILD] Received message from pipe: 'KJSIT Virtual Lab: IPC Message via Pipe'`,
    references: [
      'W. Richard Stevens - UNIX Network Programming: Interprocess Communications (Vol 2)',
      'Autonomous Curriculum StandardsVirtual Labs - IPC & Pipes'
    ],
    conclusion: 'Demonstrated anonymous pipe byte streaming and compared throughput characteristics between kernel-buffered pipes and zero-copy POSIX shared memory.',
    quiz: [
      {
        id: 1,
        question: 'Which file descriptor index represents the read-end of a UNIX anonymous pipe created by pipe(int fd[2])?',
        options: ['fd[0]', 'fd[1]', 'fd[2]', 'fd[-1]'],
        correctAnswer: 0,
        explanation: 'By convention, fd[0] is opened for reading, and fd[1] is opened for writing.'
      },
      {
        id: 2,
        question: 'Why is Shared Memory considered the fastest IPC mechanism available in operating systems?',
        options: [
          'It uses hardware DMA controllers',
          'It avoids copying data through the kernel memory space between communicating processes',
          'It uses encrypted high-speed sockets',
          'It compresses messages automatically'
        ],
        correctAnswer: 1,
        explanation: 'Shared memory maps the same physical frames into the virtual address spaces of both processes, completely eliminating kernel-space copy overhead.'
      },
      {
        id: 3,
        question: 'What signal is raised in Linux when a process attempts to write to a pipe whose read-end has been closed by all readers?',
        options: ['SIGINT', 'SIGSEGV', 'SIGPIPE', 'SIGKILL'],
        correctAnswer: 2,
        explanation: 'Writing to a pipe with no active readers sends a SIGPIPE signal to the writer process, typically terminating it unless caught.'
      },
      {
        id: 4,
        question: 'What is the primary difference between standard anonymous pipes and Named Pipes (FIFOs)?',
        options: [
          'Named pipes use shared memory',
          'Named pipes exist as distinct filesystem nodes and can communicate between unrelated processes',
          'Anonymous pipes are bidirectional',
          'Named pipes cannot block on read'
        ],
        correctAnswer: 1,
        explanation: 'Named pipes (created via mkfifo) appear in the filesystem directory tree and allow communication between unrelated processes.'
      }
    ]
  },
  {
    id: 'process-synchronization-semaphores',
    num: 5,
    subjectId: 'os',
    title: 'Process Synchronization: Semaphores & Dining Philosophers',
    subtitle: 'Mutual Exclusion, Counting Semaphores, Deadlock Avoidance, and Producer-Consumer Buffer',
    category: 'Process Synchronization',
    iitReference: 'Autonomous Curriculum Standards/ Autonomous Curriculum StandardsVirtual Lab: Classical Synchronization Problems',
    iitLabUrl: 'https://vlabs.ac.in',
    aim: 'To simulate classical synchronization problems including the Dining Philosophers Problem and Bounded Buffer (Producer-Consumer) using Mutex locks and Counting Semaphores (wait() / signal()), analyzing race conditions and deadlock prevention.',
    theory: {
      overview: [
        'Process Synchronization coordinates concurrent execution to ensure that shared data structures are accessed in a controlled manner, preventing race conditions.',
        'A Critical Section is a segment of code where shared resources (memory, files) are accessed. A valid synchronization solution must satisfy Mutual Exclusion, Progress, and Bounded Waiting.',
        'A Semaphore is a synchronization tool with an integer value manipulated solely by atomic operations: wait() (also called P() or sem_wait()) which decrements, and signal() (also called V() or sem_post()) which increments.',
        'The Dining Philosophers Problem illustrates synchronization challenges: 5 philosophers sit around a table with 5 chopsticks. Each philosopher needs both adjacent chopsticks to eat. If every philosopher picks up their left chopstick simultaneously, a circular wait deadlock occurs.'
      ],
      complexityTable: [
        { parameter: 'Semaphore wait() / signal()', value: 'Atomic O(1) test-and-set operation' },
        { parameter: 'Deadlock Conditions (Coffman)', value: 'Mutual Exclusion, Hold & Wait, No Preemption, Circular Wait' },
        { parameter: 'Producer-Consumer Bounded Capacity', value: 'N buffer slots controlled by empty & full semaphores' }
      ],
      keyPoints: [
        'Binary Semaphores (Mutexes) take values 0 or 1 to enforce mutual exclusion.',
        'Counting Semaphores manage access to a finite pool of identical resource instances.',
        'Deadlock in Dining Philosophers is broken by asymmetric chopstick acquisition (odd philosophers pick left first, even pick right first) or limiting dining concurrency to N-1.'
      ],
      realWorldApplications: [
        'Database connection pooling and worker thread dispatchers.',
        'Device driver buffer management and print spoolers.',
        'Kernel locks (spinlocks, reader-writer semaphores) guarding memory allocators.'
      ]
    },
    algorithm: [
      '1. Dining Philosophers Deadlock-Free Solution:',
      '   a. Initialize 5 binary semaphores (chopstick[0..4] = 1).',
      '   b. Philosopher i thinks. When hungry:',
      '   c. If i is odd: wait(chopstick[(i+1)%5]); wait(chopstick[i]);',
      '   d. If i is even: wait(chopstick[i]); wait(chopstick[(i+1)%5]);',
      '   e. Eat for a duration.',
      '   f. Put down both chopsticks: signal(chopstick[i]); signal(chopstick[(i+1)%5]);',
      '   g. Return to Thinking state.',
      '2. Producer-Consumer Algorithm:',
      '   a. mutex = 1, empty = N, full = 0.',
      '   b. Producer: wait(empty); wait(mutex); insert_item(); signal(mutex); signal(full);',
      '   c. Consumer: wait(full); wait(mutex); remove_item(); signal(mutex); signal(empty);'
    ],
    procedure: [
      'Step 1: Launch the interactive Dining Philosophers circular dining table with 5 philosophers and chopsticks.',
      'Step 2: Click on any philosopher to request chopsticks (Thinking -> Hungry -> Eating).',
      'Step 3: Toggle "Trigger Circular Deadlock" to observe all 5 philosophers holding 1 chopstick simultaneously.',
      'Step 4: Enable the "Asymmetric Semaphore Protocol" and observe smooth, deadlock-free dining concurrency.'
    ],
    code: {
      c: `#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define N 5
sem_t chopsticks[N];

void* philosopher(void* num) {
    int id = *(int*)num;
    while (1) {
        printf("Philosopher %d is Thinking\\n", id);
        sleep(1);

        if (id % 2 == 0) { // Even picks left then right
            sem_wait(&chopsticks[id]);
            sem_wait(&chopsticks[(id + 1) % N]);
        } else { // Odd picks right then left (Deadlock prevention)
            sem_wait(&chopsticks[(id + 1) % N]);
            sem_wait(&chopsticks[id]);
        }

        printf("--> Philosopher %d is EATING\\n", id);
        sleep(2);

        sem_post(&chopsticks[id]);
        sem_post(&chopsticks[(id + 1) % N]);
        printf("Philosopher %d finished eating\\n", id);
        break;
    }
    return NULL;
}

int main() {
    pthread_t threads[N];
    int ids[N];
    for (int i = 0; i < N; i++) sem_init(&chopsticks[i], 0, 1);
    for (int i = 0; i < N; i++) {
        ids[i] = i;
        pthread_create(&threads[i], NULL, philosopher, &ids[i]);
    }
    for (int i = 0; i < N; i++) pthread_join(threads[i], NULL);
    return 0;
}`,
      cpp: `#include <iostream>
#include <thread>
#include <mutex>
#include <vector>

std::mutex forks[5];

void dine(int id) {
    int left = id;
    int right = (id + 1) % 5;
    std::scoped_lock lock(forks[left], forks[right]);
    std::cout << "Philosopher " << id << " eating\\n";
}`,
      python: `import threading
import time

forks = [threading.Semaphore(1) for _ in range(5)]

def philosopher(i):
    first, second = (i, (i + 1) % 5) if i % 2 == 0 else ((i + 1) % 5, i)
    with forks[first]:
        with forks[second]:
            print(f"Philosopher {i} is EATING")
            time.sleep(1)`,
      java: `import java.util.concurrent.Semaphore;

class DiningPhilosophers {
    private static final int N = 5;
    private static final Semaphore[] forks = new Semaphore[N];
}`
    },
    sampleInput: `5 philosophers concurrent access with asymmetric semaphore acquisition.`,
    expectedOutput: `Philosopher 0 is Thinking
Philosopher 1 is Thinking
--> Philosopher 0 is EATING
--> Philosopher 2 is EATING
Philosopher 0 finished eating
--> Philosopher 1 is EATING`,
    references: [
      'Silberschatz, Galvin, Gagne - Operating System Concepts, Chapter 6: Synchronization Tools',
      'Autonomous Curriculum StandardsVirtual Labs - Semaphores & Dining Philosophers'
    ],
    conclusion: 'Demonstrated critical section mutual exclusion and proved that breaking circular wait conditions through asymmetric semaphore ordering prevents deadlocks.',
    quiz: [
      {
        id: 1,
        question: 'Which of the following is NOT one of the four necessary Coffman conditions for deadlock?',
        options: ['Mutual Exclusion', 'Hold and Wait', 'Preemptive Resource Allocation', 'Circular Wait'],
        correctAnswer: 2,
        explanation: 'No Preemption is a deadlock condition; preemptive resource allocation actively prevents or breaks deadlocks.'
      },
      {
        id: 2,
        question: 'What is the atomic operation performed by sem_wait() (or P()) on a semaphore S?',
        options: [
          'If S > 0 then decrement S; else block calling thread',
          'Increment S and wake up a waiting thread',
          'Reset S to 0',
          'Read S without modifying it'
        ],
        correctAnswer: 0,
        explanation: 'wait() atomically tests if S > 0, decrements S, and suspends the caller if S was <= 0.'
      },
      {
        id: 3,
        question: 'In the Producer-Consumer problem with buffer size N, what initial value should the empty semaphore have?',
        options: ['0', '1', 'N', '-1'],
        correctAnswer: 2,
        explanation: 'The empty counting semaphore begins with value N, indicating all N buffer slots are initially unoccupied.'
      },
      {
        id: 4,
        question: 'How does asymmetric chopstick picking prevent deadlock in the Dining Philosophers problem?',
        options: [
          'It eliminates mutual exclusion',
          'It breaks the Circular Wait condition',
          'It allows philosophers to eat without chopsticks',
          'It forces all philosophers to eat at once'
        ],
        correctAnswer: 1,
        explanation: 'By having odd and even philosophers pick up opposite sides first, the circular chain of dependencies is broken, eliminating circular wait.'
      }
    ]
  },
  {
    id: 'bankers-deadlock-avoidance',
    num: 6,
    subjectId: 'os',
    title: "Deadlock Avoidance: Banker's Algorithm",
    subtitle: 'Allocation, Max, Available, Need Matrices, Safe Sequence Detection, and Resource Requests',
    category: 'Deadlocks',
    iitReference: "Autonomous Curriculum Standards/ KJSIT IT Department Virtual Lab: Banker's Deadlock Avoidance Algorithm",
    iitLabUrl: 'https://vlabs.ac.in',
    aim: "To implement Dijkstra's Banker's Algorithm for deadlock avoidance, evaluating whether a given resource allocation state is in a Safe State, discovering valid Safe Execution Sequences, and validating dynamic resource requests.",
    theory: {
      overview: [
        "Banker's Algorithm is a classic deadlock avoidance method developed by Edsger Dijkstra. It models a banker dealing with cash credit lines for clients.",
        'The algorithm requires each process to declare its Maximum Resource Claim upon entering the system.',
        'Data Structures maintained by the system:',
        '  - Available[m]: Vector of available instances of each resource type.',
        '  - Max[n][m]: Maximum demand matrix for each process.',
        '  - Allocation[n][m]: Currently allocated resource instances.',
        '  - Need[n][m]: Remaining resources needed: Need[i][j] = Max[i][j] - Allocation[i][j].',
        'A state is Safe if there exists at least one Safe Sequence <P0, P1, ..., Pn-1> such that for each Pi, its remaining needs can be satisfied by currently available resources plus resources freed by preceding completed processes.'
      ],
      complexityTable: [
        { parameter: 'Safety Algorithm Time Complexity', value: 'O(m × n²) operations' },
        { parameter: 'Resource-Request Algorithm Complexity', value: 'O(m × n²) validation check' },
        { parameter: 'Space Complexity', value: 'O(n × m) for allocation matrices' }
      ],
      keyPoints: [
        'An Unsafe state does NOT mean deadlock has occurred; it means the system cannot guarantee avoidance of potential future deadlock.',
        'If a process requests resources and granting them leads to an unsafe state, the process is forced to wait.',
        'All resources must be claimed in advance, which is difficult in dynamic modern systems.'
      ],
      realWorldApplications: [
        'High-reliability industrial automation controllers allocating physical robotic actuators.',
        'Database transaction managers preventing lock-ordering deadlocks.',
        'Cloud resource orchestrators validating virtual machine and GPU cluster allocations.'
      ]
    },
    algorithm: [
      '1. Calculate Need Matrix: For each i in [0..n-1], j in [0..m-1]: Need[i][j] = Max[i][j] - Allocation[i][j].',
      '2. Safety Algorithm:',
      '   a. Initialize Work = Available, and Finish[i] = false for all i in [0..n-1].',
      '   b. Find an index i such that Finish[i] == false AND Need[i] <= Work.',
      '   c. If such an i exists: Work = Work + Allocation[i], Finish[i] = true, append Pi to safe_sequence, repeat step 2b.',
      '   d. If all Finish[i] == true, the system is in a SAFE STATE with safe_sequence. Otherwise, UNSAFE STATE.',
      '3. Resource-Request Algorithm:',
      '   a. If Request[i] <= Need[i] AND Request[i] <= Available:',
      '   b. Temporarily simulate: Available = Available - Request[i], Allocation[i] = Allocation[i] + Request[i], Need[i] = Need[i] - Request[i].',
      '   c. Run Safety Algorithm. If safe, grant immediately; else roll back and force Pi to wait.'
    ],
    procedure: [
      'Step 1: Inspect the 5 processes (P0-P4) and 3 resource types (A, B, C) Allocation & Max tables.',
      'Step 2: Click "Calculate Need Matrix" to auto-derive the remaining requirements.',
      'Step 3: Click "Run Safety Algorithm" to trace step-by-step vector comparisons and generate the Safe Sequence.',
      'Step 4: Test a dynamic resource request (e.g. P1 requests (1, 0, 2)) and verify whether the Banker grants or denies it.'
    ],
    code: {
      c: `#include <stdio.h>
#include <stdbool.h>

#define P 5 // Number of processes
#define R 3 // Number of resources

void calculateNeed(int need[P][R], int max[P][R], int alloc[P][R]) {
    for (int i = 0; i < P; i++)
        for (int j = 0; j < R; j++)
            need[i][j] = max[i][j] - alloc[i][j];
}

bool isSafe(int processes[], int avail[], int max[][R], int alloc[][R]) {
    int need[P][R];
    calculateNeed(need, max, alloc);

    bool finish[P] = {0};
    int safeSeq[P];
    int work[R];
    for (int i = 0; i < R; i++) work[i] = avail[i];

    int count = 0;
    while (count < P) {
        bool found = false;
        for (int p = 0; p < P; p++) {
            if (!finish[p]) {
                int j;
                for (j = 0; j < R; j++)
                    if (need[p][j] > work[j]) break;

                if (j == R) {
                    for (int k = 0; k < R; k++) work[k] += alloc[p][k];
                    safeSeq[count++] = p;
                    finish[p] = true;
                    found = true;
                }
            }
        }
        if (!found) {
            printf("System is NOT in a safe state!\\n");
            return false;
        }
    }

    printf("System is in a SAFE state.\\nSafe Sequence: ");
    for (int i = 0; i < P; i++) printf("P%d ", safeSeq[i]);
    printf("\\n");
    return true;
}

int main() {
    int processes[] = {0, 1, 2, 3, 4};
    int avail[] = {3, 3, 2};
    int max[P][R] = {
        {7, 5, 3},
        {3, 2, 2},
        {9, 0, 2},
        {2, 2, 2},
        {4, 3, 3}
    };
    int alloc[P][R] = {
        {0, 1, 0},
        {2, 0, 0},
        {3, 0, 2},
        {2, 1, 1},
        {0, 0, 2}
    };
    isSafe(processes, avail, max, alloc);
    return 0;
}`,
      cpp: `#include <iostream>
#include <vector>

// Banker's Algorithm in C++
int main() {
    std::cout << "Banker's Algorithm Simulator\\n";
    return 0;
}`,
      python: `def bankers_algorithm(alloc, max_claim, avail):
    n, m = len(alloc), len(avail)
    need = [[max_claim[i][j] - alloc[i][j] for j in range(m)] for i in range(n)]
    work = list(avail)
    finish = [False] * n
    safe_seq = []

    for _ in range(n):
        found = False
        for i in range(n):
            if not finish[i] and all(need[i][j] <= work[j] for j in range(m)):
                for j in range(m):
                    work[j] += alloc[i][j]
                finish[i] = True
                safe_seq.append(f"P{i}")
                found = True
                break
        if not found:
            return False, []
    return True, safe_seq`,
      java: `public class BankersAlgorithm {
    public static void main(String[] args) {
        System.out.println("Banker's Algorithm Safety Check");
    }
}`
    },
    sampleInput: `Allocation: P0(0,1,0), P1(2,0,0), P2(3,0,2), P3(2,1,1), P4(0,0,2)
Max: P0(7,5,3), P1(3,2,2), P2(9,0,2), P3(2,2,2), P4(4,3,3)
Available: (3, 3, 2)`,
    expectedOutput: `System is in a SAFE state.
Safe Sequence: P1 P3 P4 P0 P2`,
    references: [
      "Dijkstra, E. W. - Cooperating Sequential Processes (1965)",
      "Silberschatz, Galvin, Gagne - Operating System Concepts, Chapter 8: Deadlocks",
      "Autonomous Curriculum StandardsVirtual Labs - Deadlock Avoidance (vlabs.ac.in)"
    ],
    conclusion: "Validated the Banker's safety state criteria, proving that satisfying resource requests while maintaining a valid safe sequence prevents circular-wait deadlocks.",
    quiz: [
      {
        id: 1,
        question: "How is the Need matrix calculated in Banker's Algorithm?",
        options: [
          'Need = Allocation + Available',
          'Need = Max - Allocation',
          'Need = Max - Available',
          'Need = Allocation - Max'
        ],
        correctAnswer: 1,
        explanation: 'The remaining need of a process is its declared maximum claim minus its currently allocated resources: Need[i] = Max[i] - Allocation[i].'
      },
      {
        id: 2,
        question: 'Does an "Unsafe State" in Banker\'s Algorithm imply that the system is currently deadlocked?',
        options: [
          'Yes, unsafe and deadlocked are completely synonymous',
          'No, an unsafe state only means that deadlock is possible if all processes request their maximum resources',
          'Yes, the kernel immediately halts all processes',
          'No, an unsafe state is actually optimal for high throughput'
        ],
        correctAnswer: 1,
        explanation: 'An unsafe state means the operating system can no longer guarantee deadlock prevention if processes request their maximum claims; it is not yet deadlocked.'
      },
      {
        id: 3,
        question: 'What is the worst-case time complexity of the Banker’s Safety Algorithm for n processes and m resource types?',
        options: ['O(n + m)', 'O(m × n²)', 'O(2^n)', 'O(n!)'],
        correctAnswer: 1,
        explanation: 'In the worst case, checking need vectors for each of the n processes across n passes requires O(m × n²) operations.'
      },
      {
        id: 4,
        question: 'When a process Pi requests resources Request[i], what is the first validation check performed by Banker’s Algorithm?',
        options: [
          'Request[i] <= Available',
          'Request[i] <= Need[i]',
          'Request[i] >= Max[i]',
          'Need[i] == 0'
        ],
        correctAnswer: 1,
        explanation: 'The system first checks Request[i] <= Need[i] to ensure the process has not exceeded its declared maximum claim.'
      }
    ]
  },
  {
    id: 'memory-allocation-strategies',
    num: 7,
    subjectId: 'os',
    title: 'Memory Management: Dynamic Partition Allocation Strategies',
    subtitle: 'First Fit, Best Fit, Worst Fit, Next Fit, and Fragmentation Analysis',
    category: 'Memory Management',
    iitReference: 'Autonomous Curriculum Standards/ Autonomous Curriculum StandardsVirtual Lab: Memory Management',
    iitLabUrl: 'https://vlabs.ac.in',
    aim: 'To simulate and contrast dynamic contiguous memory allocation algorithms: First Fit, Best Fit, Worst Fit, and Next Fit, calculating internal and external fragmentation.',
    theory: {
      overview: [
        'Memory management is responsible for allocating primary physical RAM blocks to requesting processes and reclaiming them upon termination.',
        'In variable partition contiguous memory allocation, free memory holes are managed in a list. When a process arrives requesting size S, the OS uses an allocation strategy to find an adequate hole:',
        '  - First Fit: Allocates the first hole in memory that is large enough (Fastest search).',
        '  - Best Fit: Searches the entire memory list to find the smallest hole that is >= S (Leaves smallest remaining unusable sliver).',
        '  - Worst Fit: Allocates the largest available hole, aiming to leave a reasonably large remaining partition.',
        '  - Next Fit: Similar to First Fit, but starts scanning from the location of the previous allocation.',
        'External Fragmentation occurs when total free memory is sufficient to satisfy a request, but the memory is fragmented into non-contiguous slices.'
      ],
      complexityTable: [
        { parameter: 'First Fit Search Complexity', value: 'O(N) search through memory hole list' },
        { parameter: 'Best Fit Search Complexity', value: 'O(N) or O(log N) with balanced tree/min-heap' },
        { parameter: 'Worst Fit Search Complexity', value: 'O(N) or O(log N) with max-heap' },
        { parameter: 'Compaction Overhead', value: 'O(Total Allocated Bytes) heavy memory relocation' }
      ],
      keyPoints: [
        'First Fit and Best Fit generally outperform Worst Fit in storage utilization and speed.',
        'Best Fit tends to create tiny unusable memory fragments (external fragmentation).',
        'Compaction (shuffling memory blocks to combine free space) requires dynamic relocation hardware (base/limit registers).'
      ],
      realWorldApplications: [
        'C/C++ runtime heap allocators (malloc/free, Doug Lea malloc, jemalloc).',
        'Kernel physical page frame allocators and slab allocators.',
        'Embedded systems with fixed or non-paged microcontroller RAM.'
      ]
    },
    algorithm: [
      '1. Initialize memory block array with block sizes [B1, B2, ..., Bm].',
      '2. Input process memory requests [P1, P2, ..., Pn].',
      '3. For First Fit: For each process Pi, iterate from block 0. Find first block Bj with size >= Pi.size. Allocate Pi to Bj, update Bj.size = Bj.size - Pi.size.',
      '4. For Best Fit: For each process Pi, scan all blocks. Find block Bj with minimum (Bj.size - Pi.size) where Bj.size >= Pi.size. Allocate to Bj.',
      '5. For Worst Fit: Scan all blocks. Find block Bj with maximum Bj.size where Bj.size >= Pi.size. Allocate to Bj.',
      '6. Compute Total Allocated Memory, Remaining Block Sizes, and External Fragmentation.'
    ],
    procedure: [
      'Step 1: Set memory block sizes (e.g. 100KB, 500KB, 200KB, 300KB, 600KB).',
      'Step 2: Set process requests (e.g. P1: 212KB, P2: 417KB, P3: 112KB, P4: 426KB).',
      'Step 3: Select an allocation strategy (First Fit / Best Fit / Worst Fit / Next Fit).',
      'Step 4: Execute allocation and inspect the visual memory map and fragmentation totals.'
    ],
    code: {
      c: `#include <stdio.h>

void firstFit(int blockSize[], int m, int processSize[], int n) {
    int allocation[n];
    for (int i = 0; i < n; i++) allocation[i] = -1;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (blockSize[j] >= processSize[i]) {
                allocation[i] = j;
                blockSize[j] -= processSize[i];
                break;
            }
        }
    }

    printf("\\nProcess No.\\tProcess Size\\tBlock no.\\n");
    for (int i = 0; i < n; i++) {
        printf(" %d\\t\\t%d\\t\\t", i + 1, processSize[i]);
        if (allocation[i] != -1)
            printf("%d\\n", allocation[i] + 1);
        else
            printf("Not Allocated\\n");
    }
}

int main() {
    int blockSize[] = {100, 500, 200, 300, 600};
    int processSize[] = {212, 417, 112, 426};
    firstFit(blockSize, 5, processSize, 4);
    return 0;
}`,
      cpp: `#include <iostream>
#include <vector>

// Best Fit Memory Allocation
void bestFit(std::vector<int>& blocks, const std::vector<int>& procs) {
    for (size_t i = 0; i < procs.size(); i++) {
        int bestIdx = -1;
        for (size_t j = 0; j < blocks.size(); j++) {
            if (blocks[j] >= procs[i]) {
                if (bestIdx == -1 || blocks[j] < blocks[bestIdx]) bestIdx = j;
            }
        }
        if (bestIdx != -1) {
            std::cout << "P" << i+1 << " -> Block " << bestIdx+1 << std::endl;
            blocks[bestIdx] -= procs[i];
        }
    }
}`,
      python: `def simulate_first_fit(blocks, processes):
    b = list(blocks)
    alloc = []
    for p in processes:
        placed = False
        for i in range(len(b)):
            if b[i] >= p:
                b[i] -= p
                alloc.append(i)
                placed = True
                break
        if not placed:
            alloc.append(-1)
    return alloc, b`,
      java: `public class MemoryAllocator {
    public static void main(String[] args) {
        System.out.println("First Fit & Best Fit Allocator");
    }
}`
    },
    sampleInput: `Blocks: 100KB, 500KB, 200KB, 300KB, 600KB
Processes: P1(212KB), P2(417KB), P3(112KB), P4(426KB)`,
    expectedOutput: `Process No.	Process Size	Block no.
 1		212		2 (500KB block)
 2		417		5 (600KB block)
 3		112		2 (Remaining 288KB)
 4		426		Not Allocated (External Fragmentation)`,
    references: [
      'Silberschatz, Galvin, Gagne - Operating System Concepts, Chapter 9: Main Memory',
      'Autonomous Curriculum StandardsVirtual Labs - Dynamic Memory Partitioning'
    ],
    conclusion: 'Compared contiguous memory placement strategies and demonstrated how external fragmentation can prevent process allocation even when total free memory is adequate.',
    quiz: [
      {
        id: 1,
        question: 'Which memory allocation strategy searches for the smallest partition that is large enough to hold the requesting process?',
        options: ['First Fit', 'Best Fit', 'Worst Fit', 'Next Fit'],
        correctAnswer: 1,
        explanation: 'Best Fit finds the smallest free hole that satisfies the process request size, leaving the smallest possible remainder.'
      },
      {
        id: 2,
        question: 'What is External Fragmentation?',
        options: [
          'Memory allocated inside a partition that remains unused by the process',
          'Total free memory space is adequate to satisfy a request, but it is non-contiguous',
          'Memory corrupted by buffer overflow',
          'Unused page table entry frames'
        ],
        correctAnswer: 1,
        explanation: 'External fragmentation exists when there is enough total memory space to satisfy a request, but the available spaces are fragmented into scattered small blocks.'
      },
      {
        id: 3,
        question: 'What technique can consolidate non-contiguous free memory holes into one large contiguous block?',
        options: ['Paging', 'Compaction', 'Swapping', 'Spooling'],
        correctAnswer: 1,
        explanation: 'Compaction relocates occupied memory blocks to one end of memory, merging all free spaces into a single large hole.'
      },
      {
        id: 4,
        question: 'Why does Worst Fit often produce larger usable remaining holes than Best Fit?',
        options: [
          'Worst fit allocates from the largest available block, leaving a relatively large remainder rather than tiny unusable slivers',
          'Worst fit compresses data in RAM',
          'Worst fit uses virtual memory swapping',
          'Worst fit prevents internal fragmentation completely'
        ],
        correctAnswer: 0,
        explanation: 'Worst Fit leaves the largest leftover piece after allocation, which has a higher probability of being large enough to fit another future process.'
      }
    ]
  },
  {
    id: 'page-replacement-algorithms',
    num: 8,
    subjectId: 'os',
    title: 'Virtual Memory: Page Replacement (FIFO, LRU, Optimal, Clock)',
    subtitle: 'Demand Paging, Page Fault Analysis, Belady’s Anomaly, and Frame Allocation',
    category: 'Virtual Memory',
    iitReference: 'Autonomous Curriculum Standards/ Autonomous Curriculum StandardsVirtual Lab: Page Replacement Algorithms',
    iitLabUrl: 'https://vlabs.ac.in',
    aim: 'To simulate and analyze virtual memory page replacement algorithms: FIFO, Least Recently Used (LRU), Optimal (OPT), and Second Chance (Clock), tracking page hits, page faults, hit ratio, and demonstrating Belady’s Anomaly.',
    theory: {
      overview: [
        'Virtual Memory allows the execution of processes that may not be completely in physical memory, providing an illusion of vast addressable memory.',
        'Demand Paging loads a page into physical memory only when a reference is made to it. If the page is not in RAM, the hardware raises a Page Fault trap to the OS.',
        'When physical memory frames are exhausted, the Page Replacement Algorithm chooses which victim page to evict:',
        '  - FIFO (First-In, First-Out): Evicts the oldest page brought into memory. Subject to Belady’s Anomaly (page faults can increase with more frames!).',
        '  - LRU (Least Recently Used): Evicts the page that has not been referenced for the longest period of time (approximates Optimal).',
        '  - Optimal (OPT / MIN): Evicts the page that will not be used for the longest period in the future (Provably optimal lowest fault rate; theoretical benchmark).',
        '  - Clock / Second Chance: Uses a circular queue with reference bits to approximate LRU with low hardware overhead.'
      ],
      complexityTable: [
        { parameter: 'FIFO Replacement Overhead', value: 'O(1) queue shift' },
        { parameter: 'LRU Complexity', value: 'O(1) with Doubly Linked List + Hash Map, or O(F) search' },
        { parameter: 'Optimal (OPT) Complexity', value: 'O(F × L) future reference scan' },
        { parameter: 'Page Fault Rate', value: 'Faults / Total References' }
      ],
      keyPoints: [
        'Belady’s Anomaly: For some page reference strings, FIFO generates MORE page faults when given MORE memory frames.',
        'LRU and Optimal are "Stack Algorithms" and are mathematically immune to Belady’s Anomaly.',
        'The Clock algorithm inspects reference bits: if bit=0 evict; if bit=1 clear bit to 0 and advance hand.'
      ],
      realWorldApplications: [
        'Linux kernel Page Cache management and swap subsystem.',
        'Web browser cache and CDN edge cache replacement policies.',
        'Database buffer pool management (InnoDB buffer pool, Redis cache eviction).'
      ]
    },
    algorithm: [
      '1. Input Page Reference String [r1, r2, ..., rL] and number of physical frames F.',
      '2. For each page reference r_i in the string:',
      '   a. Check if r_i is already present in current frames (Page Hit). If hit, update usage timestamp (for LRU) or reference bit (for Clock).',
      '   b. If r_i is NOT present (Page Fault):',
      '      - If an empty frame exists, place r_i in empty frame.',
      '      - Else select victim page based on chosen algorithm (FIFO: oldest arrival, LRU: earliest last use, OPT: latest next use, Clock: first page with ref_bit=0).',
      '      - Replace victim page with r_i and increment Page Fault Counter.',
      '3. Calculate Hit Ratio = Hits / Total References, Miss/Fault Ratio = Faults / Total References.'
    ],
    procedure: [
      'Step 1: Choose or edit a Page Reference String (e.g. 7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1).',
      'Step 2: Adjust the number of available physical page frames (3 to 6 frames).',
      'Step 3: Select algorithm (FIFO / LRU / Optimal / Clock) or run Belady Anomaly test.',
      'Step 4: Step through references to watch the visual frame memory matrix, hit/fault indicators, and replacement decisions.'
    ],
    code: {
      c: `#include <stdio.h>
#include <stdbool.h>

int findLRU(int time[], int n) {
    int min = time[0], pos = 0;
    for (int i = 1; i < n; ++i) {
        if (time[i] < min) {
            min = time[i];
            pos = i;
        }
    }
    return pos;
}

void simulateLRU(int pages[], int n, int total_frames) {
    int frames[total_frames], time[total_frames];
    int count = 0, page_faults = 0;

    for (int i = 0; i < total_frames; ++i) frames[i] = -1;

    for (int i = 0; i < n; ++i) {
        bool flag1 = false, flag2 = false;

        for (int j = 0; j < total_frames; ++j) {
            if (frames[j] == pages[i]) {
                count++;
                time[j] = count;
                flag1 = flag2 = true;
                break;
            }
        }

        if (!flag1) {
            for (int j = 0; j < total_frames; ++j) {
                if (frames[j] == -1) {
                    count++;
                    page_faults++;
                    frames[j] = pages[i];
                    time[j] = count;
                    flag2 = true;
                    break;
                }
            }
        }

        if (!flag2) {
            int pos = findLRU(time, total_frames);
            count++;
            page_faults++;
            frames[pos] = pages[i];
            time[pos] = count;
        }
    }
    printf("Total Page Faults (LRU): %d\\n", page_faults);
}

int main() {
    int pages[] = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2};
    simulateLRU(pages, 13, 4);
    return 0;
}`,
      cpp: `#include <iostream>
#include <vector>
#include <unordered_set>
#include <unordered_map>

int lruPageFaults(const std::vector<int>& pages, int capacity) {
    std::unordered_set<int> s;
    std::unordered_map<int, int> indexes;
    int page_faults = 0;

    for (int i = 0; i < pages.size(); i++) {
        if (s.size() < capacity) {
            if (s.find(pages[i]) == s.end()) {
                s.insert(pages[i]);
                page_faults++;
            }
            indexes[pages[i]] = i;
        } else {
            if (s.find(pages[i]) == s.end()) {
                int lru = 1e9, val;
                for (auto it : s) {
                    if (indexes[it] < lru) {
                        lru = indexes[it];
                        val = it;
                    }
                }
                s.erase(val);
                s.insert(pages[i]);
                page_faults++;
            }
            indexes[pages[i]] = i;
        }
    }
    return page_faults;
}`,
      python: `def simulate_fifo(pages, capacity):
    memory = []
    faults = 0
    for p in pages:
        if p not in memory:
            if len(memory) < capacity:
                memory.append(p)
            else:
                memory.pop(0)
                memory.append(p)
            faults += 1
    return faults`,
      java: `public class PageReplacement {
    public static void main(String[] args) {
        System.out.println("Page Replacement Simulator");
    }
}`
    },
    sampleInput: `Reference String: 7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1 | Frames: 3`,
    expectedOutput: `FIFO Faults: 15 | Hits: 5 (Hit Ratio: 25.0%)
LRU Faults: 12  | Hits: 8 (Hit Ratio: 40.0%)
Optimal Faults: 9 | Hits: 11 (Hit Ratio: 55.0%)`,
    references: [
      'Silberschatz, Galvin, Gagne - Operating System Concepts, Chapter 10: Virtual Memory',
      'Autonomous Curriculum StandardsVirtual Labs - Page Replacement (vlabs.ac.in)'
    ],
    conclusion: 'Simulated FIFO, LRU, Optimal, and Clock replacement algorithms, verifying that Optimal provides the theoretical lower bound on page faults and demonstrating Belady’s anomaly on FIFO.',
    quiz: [
      {
        id: 1,
        question: 'What is Belady’s Anomaly in page replacement algorithms?',
        options: [
          'Page faults decrease when CPU speed increases',
          'Page fault count increases when the number of allocated page frames is increased',
          'A page fault triggers a kernel panic',
          'LRU replaces the most recently used page'
        ],
        correctAnswer: 1,
        explanation: 'Belady’s Anomaly occurs in FIFO where increasing the number of physical frames paradoxically results in MORE page faults for specific reference strings.'
      },
      {
        id: 2,
        question: 'Which page replacement algorithm achieves the provably lowest page fault rate for any given reference string?',
        options: ['Least Recently Used (LRU)', 'First-In First-Out (FIFO)', 'Optimal Page Replacement (OPT / MIN)', 'Second Chance (Clock)'],
        correctAnswer: 2,
        explanation: 'Optimal Page Replacement replaces the page that will not be used for the longest period of time in the future, giving the minimal fault rate.'
      },
      {
        id: 3,
        question: 'Why are Stack Algorithms (such as LRU and Optimal) immune to Belady’s Anomaly?',
        options: [
          'They use hardware call stacks',
          'The set of pages in memory for N frames is always a subset of the pages in memory for N+1 frames',
          'They do not allow swapping',
          'They execute in constant O(1) time'
        ],
        correctAnswer: 1,
        explanation: 'A stack algorithm guarantees that the set of pages in an n-frame memory is always a subset of the set of pages in an (n+1)-frame memory.'
      },
      {
        id: 4,
        question: 'How does the Second-Chance (Clock) page replacement algorithm decide whether to replace a page?',
        options: [
          'It checks process priority',
          'If the page reference bit is 1, it clears it to 0 and moves forward; if 0, the page is selected as victim',
          'It compares timestamps down to the nanosecond',
          'It evicts the largest page in RAM'
        ],
        correctAnswer: 1,
        explanation: 'The Clock algorithm inspects the reference bit: if 1, the page gets a second chance (bit set to 0) and the clock hand advances; if 0, it is immediately evicted.'
      }
    ]
  },
  {
    id: 'disk-scheduling-algorithms',
    num: 9,
    subjectId: 'os',
    title: 'Secondary Storage: Disk Scheduling Algorithms',
    subtitle: 'FCFS, SSTF, SCAN (Elevator), C-SCAN, LOOK, and C-LOOK Head Seek Simulation',
    category: 'Secondary Storage & Disk I/O',
    iitReference: 'Autonomous Curriculum Standards/ Autonomous Curriculum StandardsVirtual Lab: Disk Head Scheduling',
    iitLabUrl: 'https://vlabs.ac.in',
    aim: 'To simulate and analyze magnetic disk arm scheduling algorithms (FCFS, SSTF, SCAN/Elevator, C-SCAN, LOOK, C-LOOK), calculating Total Head Movement (THM) and seek time across cylinder tracks (0 to 199).',
    theory: {
      overview: [
        'Disk scheduling is responsible for ordering I/O cylinder requests to minimize seek time—the physical mechanical latency of moving the disk read/write head arm to the desired cylinder track.',
        'Algorithms evaluated:',
        '  - FCFS: Services disk requests in strict arrival order. Simple and fair, but produces wild mechanical arm oscillations.',
        '  - SSTF (Shortest Seek Time First): Selects the request with the minimum seek distance from the current head position. Can lead to starvation of distant tracks.',
        '  - SCAN (Elevator Algorithm): The arm starts at one end of the disk and moves toward the other end, servicing requests as it reaches each cylinder, reversing direction at the boundary.',
        '  - C-SCAN (Circular SCAN): Moves in only one direction servicing requests. When reaching the end, it immediately returns to the beginning without servicing requests on the return trip, providing uniform wait times.',
        '  - LOOK / C-LOOK: Variations of SCAN / C-SCAN that only travel as far as the final request in each direction before reversing, avoiding travel to physical disk boundaries (0 and 199).'
      ],
      complexityTable: [
        { parameter: 'FCFS Head Movement', value: 'Highest seek distance and mechanical wear' },
        { parameter: 'SSTF Complexity', value: 'O(N²) without spatial indexing, O(log N) with BST' },
        { parameter: 'SCAN / LOOK Complexity', value: 'O(N log N) sorting cylinder tracks' },
        { parameter: 'Total Head Movement (THM)', value: 'Sum of |Cylinder_{i} - Cylinder_{i-1}|' }
      ],
      keyPoints: [
        'Seek time accounts for the largest component of disk access time compared to rotational latency and transfer time.',
        'SSTF is susceptible to starvation when a steady stream of requests clusters near the current arm position.',
        'C-SCAN provides more uniform waiting times across all disk cylinders compared to standard bi-directional SCAN.'
      ],
      realWorldApplications: [
        'Traditional magnetic hard disk drive (HDD) controller firmware.',
        'Linux kernel I/O Schedulers: Deadline Scheduler, BFQ (Budget Fair Queueing), and Kyber.',
        'Storage Area Network (SAN) array controllers reordering block-level I/O.'
      ]
    },
    algorithm: [
      '1. Input Track Request Queue [t1, t2, ..., tn], Initial Head Position H, and Initial Seek Direction (UP / DOWN).',
      '2. For FCFS: Current = H. For each req in queue: THM += |req - Current|, Current = req.',
      '3. For SSTF: While unserviced requests remain: find request with min |req - Current|. Service req, THM += |req - Current|, Current = req.',
      '4. For SCAN: Sort requests. Move in initial direction up to boundary (199 or 0), servicing requests on path. Reverse direction and service remaining requests.',
      '5. For LOOK: Same as SCAN, but only travels up to max/min requested track rather than physical boundaries 0 / 199.',
      '6. For C-SCAN / C-LOOK: Travel in one direction, jump to other extreme without servicing, and continue in original direction.',
      '7. Plot Seek Path Graph and output Total Head Movement (THM).'
    ],
    procedure: [
      'Step 1: Set the Disk Request Queue (e.g. 98, 183, 37, 122, 14, 124, 65, 67) and Initial Head position (e.g. 53).',
      'Step 2: Choose seek direction (Towards Higher Cylinders vs Lower Cylinders).',
      'Step 3: Select algorithm (FCFS / SSTF / SCAN / C-SCAN / LOOK / C-LOOK).',
      'Step 4: Click "Run Simulation" to watch the animated disk seek arm and compare Total Head Movement curves.'
    ],
    code: {
      c: `#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void calculateFCFS(int req[], int n, int head) {
    int total_movement = 0;
    int curr = head;

    printf("FCFS Seek Sequence: %d", head);
    for (int i = 0; i < n; i++) {
        total_movement += abs(req[i] - curr);
        curr = req[i];
        printf(" -> %d", curr);
    }
    printf("\\nTotal Head Movement (FCFS): %d cylinders\\n", total_movement);
}

int main() {
    int req[] = {98, 183, 37, 122, 14, 124, 65, 67};
    int head = 53;
    calculateFCFS(req, 8, head);
    return 0;
}`,
      cpp: `#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

int runSCAN(std::vector<int> req, int head, std::string dir, int disk_size = 200) {
    int thm = 0;
    std::vector<int> left, right;
    if (dir == "left") left.push_back(0);
    else if (dir == "right") right.push_back(disk_size - 1);

    for (int r : req) {
        if (r < head) left.push_back(r);
        else right.push_back(r);
    }
    std::sort(left.begin(), left.end());
    std::sort(right.begin(), right.end());
    // Traverse sequence and compute total distance
    return thm;
}`,
      python: `def simulate_sstf(requests, head):
    reqs = list(requests)
    curr = head
    thm = 0
    seq = [head]
    while reqs:
        closest = min(reqs, key=lambda x: abs(x - curr))
        thm += abs(closest - curr)
        curr = closest
        seq.append(curr)
        reqs.remove(closest)
    return thm, seq`,
      java: `public class DiskScheduler {
    public static void main(String[] args) {
        System.out.println("Disk Scheduling Simulation");
    }
}`
    },
    sampleInput: `Requests: 98, 183, 37, 122, 14, 124, 65, 67 | Initial Head: 53 | Direction: Right (199)`,
    expectedOutput: `FCFS THM: 640 cylinders
SSTF THM: 236 cylinders (Sequence: 53->65->67->37->14->98->122->124->183)
SCAN THM: 208 cylinders (Sequence: 53->65->67->98->122->124->183->199->37->14)
LOOK THM: 299 cylinders`,
    references: [
      'Silberschatz, Galvin, Gagne - Operating System Concepts, Chapter 11: Mass-Storage Structure',
      'Autonomous Curriculum StandardsVirtual Labs - Disk Scheduling (vlabs.ac.in)'
    ],
    conclusion: 'Compared FCFS, SSTF, SCAN, C-SCAN, and LOOK disk head movement paths, proving that elevator (SCAN/LOOK) and SSTF algorithms drastically reduce mechanical arm movement over naive FCFS.',
    quiz: [
      {
        id: 1,
        question: 'Which component of magnetic disk access time accounts for the largest mechanical latency?',
        options: ['Seek Time (Arm movement to track)', 'Rotational Latency (Platter rotation)', 'Transfer Time', 'Controller Bus Latency'],
        correctAnswer: 0,
        explanation: 'Seek time requires physical mechanical acceleration and deceleration of the read/write head arm across physical disk platters, making it the most significant latency.'
      },
      {
        id: 2,
        question: 'What is the primary advantage of C-SCAN (Circular SCAN) over standard bi-directional SCAN?',
        options: [
          'It provides faster maximum seek speed',
          'It provides a more uniform waiting time for all cylinders across the disk surface',
          'It never needs to reverse head direction',
          'It eliminates rotational delay completely'
        ],
        correctAnswer: 1,
        explanation: 'C-SCAN treats cylinders as a circular list, preventing cylinders at the edges from waiting twice as long on average as cylinders in the center.'
      },
      {
        id: 3,
        question: 'How does LOOK scheduling differ from standard SCAN (Elevator) scheduling?',
        options: [
          'LOOK does not service write requests',
          'LOOK only travels as far as the final request in the current direction rather than going all the way to cylinder 0 or 199',
          'LOOK uses an optical laser sensor',
          'LOOK is strictly non-preemptive'
        ],
        correctAnswer: 1,
        explanation: 'LOOK "looks ahead" and reverses direction immediately after servicing the highest or lowest requested track, avoiding unnecessary arm movement to physical boundary tracks.'
      },
      {
        id: 4,
        question: 'What vulnerability does Shortest Seek Time First (SSTF) suffer from under heavy I/O workloads?',
        options: ['Convoy Effect', 'Starvation of distant cylinder requests', 'Belady’s Anomaly', 'Thrashing'],
        correctAnswer: 1,
        explanation: 'If new requests continue to arrive near the current head position, distant requests on the inner or outer tracks may starve indefinitely.'
      }
    ]
  },
  {
    id: 'thread-concurrency-pthreads',
    num: 10,
    subjectId: 'os',
    title: 'Thread Concurrency & POSIX Pthreads Synchronization',
    subtitle: 'Multithreading, Race Conditions, Mutex Locks, and Critical Section Protection',
    category: 'Concurrency & Multithreading',
    iitReference: 'Autonomous Curriculum Standards/ Autonomous Curriculum StandardsVirtual Lab: Multithreading & Synchronization',
    iitLabUrl: 'https://vlabs.ac.in',
    aim: 'To demonstrate multithreaded concurrency using POSIX Threads (pthreads), illustrating race conditions on shared memory counters, and implementing mutual exclusion via pthread_mutex_lock() / pthread_mutex_unlock().',
    theory: {
      overview: [
        'A thread is a lightweight unit of CPU execution within a process, sharing code, data, and open files with sibling threads while maintaining its own private stack, registers, and Program Counter (PC).',
        'When multiple threads concurrently read, modify, and write a shared variable without synchronization, a Race Condition occurs: the final value depends unpredictably on the arbitrary interleaving of thread execution order.',
        'POSIX Threads (pthreads) provides standardized API routines for thread creation (`pthread_create`), joining (`pthread_join`), and mutual exclusion locking (`pthread_mutex_t`).',
        'A Mutex (Mutual Exclusion) Lock ensures that only one thread can execute within the designated Critical Section at any instant.'
      ],
      complexityTable: [
        { parameter: 'pthread_create() Overhead', value: 'Significantly lighter than fork() (shares address space)' },
        { parameter: 'pthread_mutex_lock() Speed', value: 'O(1) atomic compare-and-swap (CAS) fast path' },
        { parameter: 'Thread Context Switch Latency', value: '100-500 nanoseconds (no TLB invalidation required)' }
      ],
      keyPoints: [
        'Threads share heap and global variables, making data sharing efficient but error-prone without locking.',
        'Unsynchronized shared counter increments (counter++) compile into 3 separate assembly instructions: LOAD, ADD, STORE, creating race windows.',
        'Mutex locks serialize critical section access, ensuring atomicity at the expense of potential lock contention.'
      ],
      realWorldApplications: [
        'Multi-core web servers (Nginx worker threads, Node.js libuv thread pool).',
        'Game engines running graphics, physics, and AI on separate worker threads.',
        'High-performance scientific computing and parallel matrix multiplication.'
      ]
    },
    algorithm: [
      '1. Initialize shared variable counter = 0, and pthread_mutex_t lock.',
      '2. Without Synchronization (Race Condition):',
      '   a. Spawn Thread T1 and Thread T2, each executing a loop: { temp = counter; temp = temp + 1; counter = temp; } for N iterations.',
      '   b. Join T1 and T2. Observe final counter < 2*N due to overwritten updates.',
      '3. With Mutex Synchronization:',
      '   a. For each iteration: pthread_mutex_lock(&lock); counter++; pthread_mutex_unlock(&lock);',
      '   b. Join T1 and T2. Verify final counter == 2*N exactly.',
      '4. Output thread execution timeline and shared memory states.'
    ],
    procedure: [
      'Step 1: Set the number of worker threads (2 to 4) and loop iteration count (e.g. 10,000 to 100,000).',
      'Step 2: Toggle "Unsynchronized (Race Condition)" mode and click "Run Concurrency Experiment".',
      'Step 3: Observe interleaved thread execution and inspect the corrupted counter value.',
      'Step 4: Toggle "POSIX Mutex Lock Protection" and run again to verify consistent atomic execution.'
    ],
    code: {
      c: `#include <stdio.h>
#include <pthread.h>

#define NUM_ITERATIONS 100000

int counter = 0;
pthread_mutex_t lock;

void* thread_func_unsafe(void* arg) {
    for (int i = 0; i < NUM_ITERATIONS; i++) {
        counter++; // Non-atomic race condition
    }
    return NULL;
}

void* thread_func_safe(void* arg) {
    for (int i = 0; i < NUM_ITERATIONS; i++) {
        pthread_mutex_lock(&lock);
        counter++; // Protected critical section
        pthread_mutex_unlock(&lock);
    }
    return NULL;
}

int main() {
    pthread_t t1, t2;
    pthread_mutex_init(&lock, NULL);

    printf("Running synchronized pthreads test (Target: %d)...\\n", NUM_ITERATIONS * 2);
    pthread_create(&t1, NULL, thread_func_safe, NULL);
    pthread_create(&t2, NULL, thread_func_safe, NULL);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    printf("Final Counter Value: %d (PASSED)\\n", counter);
    pthread_mutex_destroy(&lock);
    return 0;
}`,
      cpp: `#include <iostream>
#include <thread>
#include <mutex>

int counter = 0;
std::mutex mtx;

void increment(int iters) {
    for (int i = 0; i < iters; i++) {
        std::lock_guard<std::mutex> lock(mtx);
        counter++;
    }
}

int main() {
    std::thread t1(increment, 100000);
    std::thread t2(increment, 100000);
    t1.join();
    t2.join();
    std::cout << "Counter: " << counter << std::endl;
    return 0;
}`,
      python: `import threading

counter = 0
lock = threading.Lock()

def worker(safe=True):
    global counter
    for _ in range(50000):
        if safe:
            with lock:
                counter += 1
        else:
            temp = counter
            counter = temp + 1

t1 = threading.Thread(target=worker, args=(True,))
t2 = threading.Thread(target=worker, args=(True,))
t1.start(); t2.start()
t1.join(); t2.join()
print(f"Final Count: {counter}")`,
      java: `public class ThreadSyncDemo {
    private static int counter = 0;
    public static synchronized void increment() { counter++; }

    public static void main(String[] args) throws InterruptedException {
        Thread t1 = new Thread(() -> { for(int i=0; i<10000; i++) increment(); });
        Thread t2 = new Thread(() -> { for(int i=0; i<10000; i++) increment(); });
        t1.start(); t2.start();
        t1.join(); t2.join();
        System.out.println("Counter: " + counter);
    }
}`
    },
    sampleInput: `2 threads incrementing shared counter 100,000 times each (Target: 200,000).`,
    expectedOutput: `[Without Mutex]: Final Counter = 138,492 (Race Condition Detected!)
[With Mutex Lock]: Final Counter = 200,000 (100% Accurate & Synchronized)`,
    references: [
      'Silberschatz, Galvin, Gagne - Operating System Concepts, Chapter 4: Threads & Concurrency',
      'David R. Butenhof - Programming with POSIX Threads',
      'Autonomous Curriculum StandardsVirtual Labs - Multithreading & Synchronization'
    ],
    conclusion: 'Demonstrated multithreaded race conditions on shared memory and proved that POSIX Mutex locking provides complete atomicity and mutual exclusion.',
    quiz: [
      {
        id: 1,
        question: 'Which of the following resources is NOT shared between threads belonging to the same process?',
        options: ['Heap memory', 'Global variables', 'Thread Private Stack and Registers', 'Open File Descriptors'],
        correctAnswer: 2,
        explanation: 'Each thread has its own private call stack, Program Counter (PC), and CPU register state; heap, globals, and file descriptors are shared across the process.'
      },
      {
        id: 2,
        question: 'Why does the simple statement counter++ produce a race condition when accessed by concurrent threads without locks?',
        options: [
          'It executes in kernel space',
          'It compiles to multiple machine instructions (read, modify, write) that can be interleaved by context switches',
          'It consumes all CPU registers',
          'It disables hardware interrupts'
        ],
        correctAnswer: 1,
        explanation: 'counter++ decomposes into: LOAD register from memory, ADD 1 to register, and STORE register back to memory. Context switching between these instructions causes lost updates.'
      },
      {
        id: 3,
        question: 'What is the purpose of pthread_join(thread_id, NULL)?',
        options: [
          'It cancels the specified thread immediately',
          'It suspends the calling thread until the target thread terminates and reaps its resources',
          'It creates a new thread group',
          'It locks the thread mutex'
        ],
        correctAnswer: 1,
        explanation: 'pthread_join() blocks the calling thread until the specified thread finishes execution, similar to wait() for child processes.'
      },
      {
        id: 4,
        question: 'Why is context switching between threads of the same process faster than context switching between two different processes?',
        options: [
          'Threads run at higher clock speeds',
          'Thread context switching does not require invalidating the Translation Lookaside Buffer (TLB) or switching the virtual address space',
          'Threads do not use CPU registers',
          'Process context switches require rebooting the kernel'
        ],
        correctAnswer: 1,
        explanation: 'Threads share the same virtual memory address space (Page Tables), so the CPU avoids expensive TLB flushes during thread context switches.'
      }
    ]
  }
];
