import { LabExperiment } from '../types';
import { enrichExperimentQuiz } from '../utils/quizEnricher';
import { DAA_EXPERIMENTS } from './daaExperiments';
import { DSA_EXPERIMENTS } from './dsaExperiments';
import { ML_EXPERIMENTS } from './mlExperiments';
import { DBMS_EXPERIMENTS } from './dbmsExperiments';
import { OS_EXPERIMENTS } from './osExperiments';
import { OOPM_EXPERIMENTS } from './oopmExperiments';
import { AOA_EXPERIMENTS } from './aoaExperiments';
import { AI_EXPERIMENTS } from './aiExperiments';
import { DWM_EXPERIMENTS } from './dwmExperiments';
import { SE_EXPERIMENTS } from './seExperiments';
import { ANN_EXPERIMENTS } from './annExperiments';
import { DAV_EXPERIMENTS } from './davExperiments';
import { NLP_EXPERIMENTS } from './nlpExperiments';
import { DL_EXPERIMENTS } from './dlExperiments';
import { RPA_EXPERIMENTS } from './rpaExperiments';
import { RL_EXPERIMENTS } from './rlExperiments';

const RAW_LAB_EXPERIMENTS_MAP: Record<string, LabExperiment[]> = {
  daa: DAA_EXPERIMENTS as LabExperiment[],
  dsa: DSA_EXPERIMENTS as LabExperiment[],
  aiml: ML_EXPERIMENTS as LabExperiment[],
  ml: ML_EXPERIMENTS as LabExperiment[],
  dbms: DBMS_EXPERIMENTS as LabExperiment[],
  os: OS_EXPERIMENTS as LabExperiment[],
  oopm: OOPM_EXPERIMENTS,
  aoa: AOA_EXPERIMENTS,
  ai: AI_EXPERIMENTS,
  dwm: DWM_EXPERIMENTS,
  se: SE_EXPERIMENTS,
  ann: ANN_EXPERIMENTS,
  dav: DAV_EXPERIMENTS,
  nlp: NLP_EXPERIMENTS,
  dl: DL_EXPERIMENTS,
  rpa: RPA_EXPERIMENTS,
  rl: RL_EXPERIMENTS
};

// Ensure all experiments across every subject have at least 8 to 10 comprehensive self-evaluation questions
export const ALL_LAB_EXPERIMENTS_MAP: Record<string, LabExperiment[]> = Object.fromEntries(
  Object.entries(RAW_LAB_EXPERIMENTS_MAP).map(([subj, list]) => [
    subj,
    list.map((exp) => enrichExperimentQuiz(exp, 10))
  ])
);

export const ALL_EXPERIMENTS: LabExperiment[] = Object.values(ALL_LAB_EXPERIMENTS_MAP).flat();

export function getExperimentsForSubject(subjectId: string): LabExperiment[] {
  return ALL_LAB_EXPERIMENTS_MAP[subjectId] || [];
}

const EXP_ALIASES: Record<string, string> = {
  // DBMS Lab Aliases
  'er-modeling': 'er-model-design',
  'er-diagram': 'er-model-design',
  'ddl-dml-sql': 'table-constraints',
  'ddl-dml-fundamentals': 'dml-operations',
  'sql-fundamentals': 'dml-operations',
  'sql-joins-subqueries': 'joins-and-subqueries',
  'sql-joins': 'joins-and-subqueries',
  'normalization-lossless': 'views-and-indexes',
  'normalization': 'views-and-indexes',
  'bplus-tree-indexing': 'views-and-indexes',
  'b-plus-tree-indexing': 'views-and-indexes',
  'transaction-concurrency': 'transactions-and-dcl',
  'transactions-concurrency': 'transactions-and-dcl',
  'db-frontend-connectivity': 'frontend-connectivity',
  'dbms-capstone-project': 'capstone-project',

  // DSA Lab Aliases
  'stack-operations': 'stack-adt-linked-list',
  'stack': 'stack-adt-linked-list',
  'queue-circular-queue': 'linear-queue-adt',
  'queue': 'linear-queue-adt',
  'circular-queue': 'linear-queue-adt',
  'singly-linked-list': 'polynomial-arithmetic',
  'linked-list': 'polynomial-arithmetic',
  'binary-tree': 'binary-tree-traversals',
  'avl-tree': 'binary-tree-traversals',
  'avl': 'binary-tree-traversals',
  'binary-search-tree': 'binary-search-tree-operations',
  'bst': 'binary-search-tree-operations',
  'graph-traversals': 'graph-traversals-dfs-bfs',
  'bfs-dfs': 'graph-traversals-dfs-bfs',
  'binary-heap': 'sorting-algorithms-application',
  'heap': 'sorting-algorithms-application',
  'hash-table': 'sorting-algorithms-application',
  'hashing': 'sorting-algorithms-application',
  'search-analysis': 'sorting-algorithms-application'
};

export function findExperimentById(expId: string): {
  experiment: LabExperiment;
  subjectId: string;
  experimentList: LabExperiment[];
} | null {
  const targetId = EXP_ALIASES[expId] || expId;
  for (const [subjId, list] of Object.entries(ALL_LAB_EXPERIMENTS_MAP)) {
    const found = list.find((e) => e.id === targetId || e.id === expId);
    if (found) {
      return {
        experiment: found,
        subjectId: subjId,
        experimentList: list
      };
    }
  }
  return null;
}
