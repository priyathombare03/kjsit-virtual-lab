export type LabSubjectId =
  | 'daa'
  | 'dbms'
  | 'os'
  | 'cn'
  | 'aiml'
  | 'cybersec'
  | 'webtech'
  | 'fswc'
  | 'dsa'
  | 'oopm'
  | 'aoa'
  | 'ai'
  | 'dwm'
  | 'se'
  | 'ann'
  | 'dav'
  | 'nlp'
  | 'dl'
  | 'rpa'
  | 'rl'
  | string;

export interface LabSubject {
  id: LabSubjectId;
  name: string;
  code: string;
  department: string;
  semester: string;
  description: string;
  iconName: string;
  isFunctional: boolean;
  experimentCount: number;
  tags: string[];
  bannerColor: string;
  iitReference?: string;
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface ExperimentCode {
  c?: string;
  cpp?: string;
  python?: string;
  java?: string;
  r?: string;
  sql?: string;
  bash?: string;
  javascript?: string;
  typescript?: string;
  js?: string;
  ts?: string;
  html?: string;
  css?: string;
  json?: string;
  [key: string]: string | undefined;
}

export interface ComplexityParam {
  parameter: string;
  value: string;
}

export interface CodingPuzzleTestCase {
  id: string;
  name: string;
  input: string;
  expectedOutput: string;
  explanation?: string;
}

export interface CodinGamePuzzle {
  id: string;
  title: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  topic: string;
  codingameUrl: string;
  summary: string;
  statement: string;
  inputFormat: string[];
  outputFormat: string[];
  constraints: string[];
  starterCode: {
    c?: string;
    cpp?: string;
    python?: string;
    java?: string;
    javascript?: string;
    [key: string]: string | undefined;
  };
  solutionCode: {
    c?: string;
    cpp?: string;
    python?: string;
    java?: string;
    javascript?: string;
    [key: string]: string | undefined;
  };
  solutionExplanation?: string;
  testCases: CodingPuzzleTestCase[];
}

export interface LabExperiment {
  id: string;
  num: number;
  subjectId?: LabSubjectId;
  title: string;
  subtitle: string;
  category: string;
  iitReference?: string;
  iitLabUrl?: string;
  aim: string;
  objective?: string;
  labObjectives?: string[];
  software?: string;
  postLabQuestions?: { question: string; answer?: string }[];
  theory: {
    overview: string[];
    complexityTable: ComplexityParam[];
    keyPoints: string[];
    realWorldApplications: string[];
  };
  algorithm: string[];
  procedure: string[];
  code: ExperimentCode;
  sampleInput: string;
  expectedOutput: string;
  references: string[];
  conclusion: string;
  quiz: QuizQuestion[];
  codingamePuzzles?: CodinGamePuzzle[];
}

export type DAAExperiment = LabExperiment;
export type DSAExperiment = LabExperiment;
export type MLExperiment = LabExperiment;
export type DBMSExperiment = LabExperiment;
export type OSExperiment = LabExperiment;
export type CNExperiment = LabExperiment;
export type CNSExperiment = LabExperiment;
export type FSWCExperiment = LabExperiment;

export interface CompletedExperimentRecord {
  experimentId: string;
  subjectId: string;
  title: string;
  activeSeconds: number;
  completedAt: string;
  score?: number;
}

export interface UserSession {
  id?: string;
  name: string;
  email: string;
  studentId: string; // Somaiya Roll No / SVVNet ID (e.g. 16010123045)
  department?: string;
  year?: 'FY' | 'SY' | 'TY' | 'LY' | string;
  role: 'student' | 'faculty' | 'admin' | 'hod' | 'guest';
  idNumber?: string; // backwards compatibility
  totalActiveSeconds: number;
  currentStreak: number;
  longestStreak: number;
  lastCompletionDate: string | null; // YYYY-MM-DD
  completionDates?: string[];
  completedExperiments: (string | CompletedExperimentRecord)[];
}

export type LabActivityStatus = 'active' | 'paused' | 'idle';

export interface LabSessionMetrics {
  experimentId: string;
  subjectId: string;
  title: string;
  sessionActiveSeconds: number;
  status: LabActivityStatus;
  hasExecutedSimulation: boolean;
  hasVerifiedCode: boolean;
  hasPassedQuiz: boolean;
  quizScore?: number;
}


