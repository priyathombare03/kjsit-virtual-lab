import { useState, useEffect, useRef, useCallback } from 'react';
import { LabActivityStatus, UserSession } from '../types';

interface UseLabActiveTrackerProps {
  experimentId: string;
  subjectId: string;
  experimentTitle: string;
  userSession: UserSession | null;
  onUserSessionUpdate?: (updatedSession: UserSession) => void;
}

export function useLabActiveTracker({
  experimentId,
  subjectId,
  experimentTitle,
  userSession,
  onUserSessionUpdate
}: UseLabActiveTrackerProps) {
  const [status, setStatus] = useState<LabActivityStatus>('active');

  // Helper to load accumulated active seconds for this experiment
  const loadSavedActiveSeconds = useCallback((expId: string, email?: string): number => {
    const userKey = email || 'anon';
    const storageKey = `kjsit_exp_active_time_${userKey}_${expId}`;
    try {
      const stored = localStorage.getItem(storageKey);
      if (stored !== null) {
        const parsed = parseInt(stored, 10);
        if (!isNaN(parsed) && parsed >= 0) return parsed;
      }
    } catch {}

    // Check userSession completed experiments if available
    if (userSession?.completedExperiments) {
      const found = userSession.completedExperiments.find((e: any) =>
        typeof e === 'string' ? e === expId : e?.experimentId === expId
      );
      if (found && typeof found !== 'string' && found.activeSeconds) {
        return found.activeSeconds;
      }
    }
    return 0;
  }, [userSession]);

  // Helper to load initial 3-parameter status
  const loadSavedParamStatus = useCallback((expId: string, email?: string) => {
    const userKey = email || 'anon';
    const isCompletedInSession = Boolean(
      userSession?.completedExperiments?.some((exp: any) =>
        typeof exp === 'string' ? exp === expId : exp?.experimentId === expId
      )
    );

    let sim = isCompletedInSession;
    let code = isCompletedInSession;
    let quiz: number | null = isCompletedInSession ? 5 : null;

    if (!isCompletedInSession) {
      try {
        // Clean up legacy auto-saved simulation key that was set by simply switching tabs
        localStorage.removeItem(`kjsit_exp_sim_${userKey}_${expId}`);

        // Only genuine explicit verification marks simulation done
        const savedSim = localStorage.getItem(`kjsit_exp_sim_verified_${userKey}_${expId}`);
        if (savedSim === 'true') sim = true;

        const savedCode = localStorage.getItem(`kjsit_exp_code_${userKey}_${expId}`);
        if (savedCode === 'true') code = true;

        // Quiz must have been genuinely submitted with recorded answers
        const isQuizSubmitted = localStorage.getItem(`kjsit_exp_quiz_submitted_${userKey}_${expId}`);
        const savedQuiz = localStorage.getItem(`kjsit_exp_quiz_${userKey}_${expId}`);
        if (isQuizSubmitted === 'true' && savedQuiz !== null) {
          const parsed = parseInt(savedQuiz, 10);
          if (!isNaN(parsed)) quiz = parsed;
        }
      } catch {}
    }

    return { sim, code, quiz };
  }, [userSession]);

  const initialParams = loadSavedParamStatus(experimentId, userSession?.email);

  // Initialize timer state from accumulated seconds
  const [sessionActiveSeconds, setSessionActiveSeconds] = useState<number>(() =>
    loadSavedActiveSeconds(experimentId, userSession?.email)
  );
  const [simulationExecuted, setSimulationExecutedState] = useState<boolean>(initialParams.sim);
  const [codeVerified, setCodeVerifiedState] = useState<boolean>(initialParams.code);
  const [quizScore, setQuizScoreState] = useState<number | null>(initialParams.quiz);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [completionSuccess, setCompletionSuccess] = useState<boolean>(false);

  // Sync state whenever experimentId or user session changes
  useEffect(() => {
    const savedSecs = loadSavedActiveSeconds(experimentId, userSession?.email);
    setSessionActiveSeconds(savedSecs);
    sessionActiveSecondsRef.current = savedSecs;

    const params = loadSavedParamStatus(experimentId, userSession?.email);
    setSimulationExecutedState(params.sim);
    setCodeVerifiedState(params.code);
    setQuizScoreState(params.quiz);
    setCompletionSuccess(false);
  }, [experimentId, userSession?.email, loadSavedActiveSeconds, loadSavedParamStatus]);

  // Inactivity timeout threshold (45 seconds of no mouse/keyboard/touch)
  const IDLE_TIMEOUT_MS = 45000;
  const lastInteractionRef = useRef<number>(Date.now());
  const heartbeatTimerRef = useRef<any>(null);
  const secondTimerRef = useRef<any>(null);
  const idleCheckTimerRef = useRef<any>(null);

  const statusRef = useRef<LabActivityStatus>('active');
  statusRef.current = status;

  const sessionActiveSecondsRef = useRef<number>(sessionActiveSeconds);
  sessionActiveSecondsRef.current = sessionActiveSeconds;

  // Persisted state setters
  const setSimulationExecuted = useCallback((executed: boolean) => {
    setSimulationExecutedState(executed);
    try {
      const userKey = userSession?.email || 'anon';
      if (executed) {
        localStorage.setItem(`kjsit_exp_sim_verified_${userKey}_${experimentId}`, 'true');
      } else {
        localStorage.removeItem(`kjsit_exp_sim_verified_${userKey}_${experimentId}`);
      }
      localStorage.removeItem(`kjsit_exp_sim_${userKey}_${experimentId}`);
    } catch {}
  }, [userSession?.email, experimentId]);

  const setCodeVerified = useCallback((verified: boolean) => {
    setCodeVerifiedState(verified);
    try {
      const userKey = userSession?.email || 'anon';
      if (verified) {
        localStorage.setItem(`kjsit_exp_code_${userKey}_${experimentId}`, 'true');
      } else {
        localStorage.removeItem(`kjsit_exp_code_${userKey}_${experimentId}`);
      }
    } catch {}
  }, [userSession?.email, experimentId]);

  const setQuizScore = useCallback((score: number | null) => {
    setQuizScoreState(score);
    try {
      const userKey = userSession?.email || 'anon';
      if (score !== null && score !== undefined) {
        localStorage.setItem(`kjsit_exp_quiz_${userKey}_${experimentId}`, String(score));
        localStorage.setItem(`kjsit_exp_quiz_submitted_${userKey}_${experimentId}`, 'true');
      } else {
        localStorage.removeItem(`kjsit_exp_quiz_${userKey}_${experimentId}`);
        localStorage.removeItem(`kjsit_exp_quiz_submitted_${userKey}_${experimentId}`);
        localStorage.removeItem(`kjsit_exp_quiz_answers_${userKey}_${experimentId}`);
      }
    } catch {}
  }, [userSession?.email, experimentId]);

  // Handle user activity interaction reset
  const handleUserActivity = useCallback(() => {
    lastInteractionRef.current = Date.now();
    // Only return to active if document is currently visible
    if (document.visibilityState === 'visible' && statusRef.current === 'idle') {
      setStatus('active');
    }
  }, []);

  // Set up interaction listeners (mouse, keys, touch, clicks)
  useEffect(() => {
    const events = ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll', 'click'];
    events.forEach(evt => window.addEventListener(evt, handleUserActivity, { passive: true }));

    // Page Visibility API
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        setStatus('paused');
      } else {
        const timeSinceLastActivity = Date.now() - lastInteractionRef.current;
        if (timeSinceLastActivity >= IDLE_TIMEOUT_MS) {
          setStatus('idle');
        } else {
          setStatus('active');
        }
      }
    };

    // Window blur/focus
    const handleWindowBlur = () => {
      setStatus('paused');
    };

    const handleWindowFocus = () => {
      const timeSinceLastActivity = Date.now() - lastInteractionRef.current;
      if (timeSinceLastActivity >= IDLE_TIMEOUT_MS) {
        setStatus('idle');
      } else {
        setStatus('active');
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', handleWindowBlur);
    window.addEventListener('focus', handleWindowFocus);

    return () => {
      events.forEach(evt => window.removeEventListener(evt, handleUserActivity));
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleWindowBlur);
      window.removeEventListener('focus', handleWindowFocus);
    };
  }, [handleUserActivity]);

  // Idle check timer (checks every 2 seconds if user passed 45s inactivity)
  useEffect(() => {
    idleCheckTimerRef.current = setInterval(() => {
      if (statusRef.current === 'active') {
        const timeSinceLastActivity = Date.now() - lastInteractionRef.current;
        if (timeSinceLastActivity >= IDLE_TIMEOUT_MS) {
          setStatus('idle');
        }
      }
    }, 2000);

    return () => {
      if (idleCheckTimerRef.current) clearInterval(idleCheckTimerRef.current);
    };
  }, []);

  // 1-second active stopwatch interval (continuing from where it stopped and persisting)
  useEffect(() => {
    secondTimerRef.current = setInterval(() => {
      if (statusRef.current === 'active') {
        setSessionActiveSeconds(prev => {
          const next = prev + 1;
          sessionActiveSecondsRef.current = next;
          try {
            const userKey = userSession?.email || 'anon';
            localStorage.setItem(`kjsit_exp_active_time_${userKey}_${experimentId}`, String(next));
          } catch {}
          return next;
        });
      }
    }, 1000);

    return () => {
      if (secondTimerRef.current) clearInterval(secondTimerRef.current);
    };
  }, [experimentId, userSession?.email]);

  // Periodic Heartbeat Sync to Backend (every 5 seconds)
  useEffect(() => {
    let isCancelled = false;

    heartbeatTimerRef.current = setInterval(async () => {
      if (!userSession?.email || isCancelled) return;

      const currentStatus = statusRef.current;
      // Only report active time to backend if client is genuinely ACTIVE
      if (currentStatus === 'active') {
        try {
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 4000);

          const res = await fetch('/api/lab/heartbeat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            signal: controller.signal,
            body: JSON.stringify({
              email: userSession.email,
              experimentId,
              subjectId,
              clientStatus: 'active',
              deltaSeconds: 5
            })
          });

          clearTimeout(timeoutId);

          if (isCancelled) return;

          if (res.ok) {
            const data = await res.json();
            if (onUserSessionUpdate && data.totalActiveSeconds !== undefined) {
              onUserSessionUpdate({
                ...userSession,
                totalActiveSeconds: data.totalActiveSeconds,
                currentStreak: data.currentStreak ?? userSession.currentStreak
              });
            }
          } else {
            // Local fallback if server returns non-200
            if (onUserSessionUpdate) {
              onUserSessionUpdate({
                ...userSession,
                totalActiveSeconds: (userSession.totalActiveSeconds || 0) + 5
              });
            }
          }
        } catch {
          // Graceful local sync fallback when offline or server is warming up
          if (!isCancelled && onUserSessionUpdate) {
            onUserSessionUpdate({
              ...userSession,
              totalActiveSeconds: (userSession.totalActiveSeconds || 0) + 5
            });
          }
        }
      }
    }, 5000);

    return () => {
      isCancelled = true;
      if (heartbeatTimerRef.current) clearInterval(heartbeatTimerRef.current);
    };
  }, [userSession, experimentId, subjectId, onUserSessionUpdate]);

  // Submission handler with STRICT 3-parameter validation
  const submitExperimentCompletion = useCallback(async () => {
    if (!userSession?.email) {
      return { success: false, message: "Please log in with your Somaiya student account to submit this experiment." };
    }

    // STRICT VALIDATION: ALL THREE parameters must be done
    const isSimDone = simulationExecuted;
    const isCodeDone = codeVerified;
    const isQuizDone = quizScore !== null && quizScore !== undefined;

    if (!isSimDone || !isCodeDone || !isQuizDone) {
      const pending: string[] = [];
      if (!isSimDone) pending.push("Simulation (Run or interact with the visual simulator)");
      if (!isCodeDone) pending.push("IDE Code (Compile & run code in Monaco IDE)");
      if (!isQuizDone) pending.push("Post-Lab Quiz (Answer all questions and submit quiz)");

      return {
        success: false,
        message: `Submission blocked: All 3 parameters must be completed before submitting. Pending: ${pending.join(", ")}.`
      };
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/lab/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: userSession.email,
          experimentId,
          subjectId,
          title: experimentTitle,
          activeSeconds: sessionActiveSecondsRef.current,
          simulationExecuted,
          codeVerified,
          quizScore: quizScore ?? 5
        })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.user) {
          setCompletionSuccess(true);
          if (onUserSessionUpdate) {
            onUserSessionUpdate(data.user);
          }
          return {
            success: true,
            message: data.message || "Experiment successfully recorded and streak updated!"
          };
        }
      }

      // Offline / client-side fallback record
      const updatedUser: any = {
        ...userSession,
        currentStreak: (userSession.currentStreak || 0) + 1,
        completedExperiments: [
          ...(userSession.completedExperiments || []).filter((e: any) =>
            typeof e === 'string' ? e !== experimentId : e?.experimentId !== experimentId
          ),
          {
            experimentId,
            subjectId,
            title: experimentTitle,
            activeSeconds: sessionActiveSecondsRef.current,
            completedAt: new Date().toISOString(),
            score: quizScore ?? 5
          }
        ]
      };

      setCompletionSuccess(true);
      if (onUserSessionUpdate) {
        onUserSessionUpdate(updatedUser);
      }

      return {
        success: true,
        message: "Experiment completion verified and saved to your Somaiya profile!"
      };
    } catch {
      // Local fallback on connection issue
      const fallbackUser: any = {
        ...userSession,
        completedExperiments: [
          ...(userSession.completedExperiments || []).filter((e: any) =>
            typeof e === 'string' ? e !== experimentId : e?.experimentId !== experimentId
          ),
          {
            experimentId,
            subjectId,
            title: experimentTitle,
            activeSeconds: sessionActiveSecondsRef.current,
            completedAt: new Date().toISOString(),
            score: quizScore ?? 5
          }
        ]
      };
      setCompletionSuccess(true);
      if (onUserSessionUpdate) {
        onUserSessionUpdate(fallbackUser);
      }
      return {
        success: true,
        message: "Experiment completion saved locally to your student profile."
      };
    } finally {
      setIsSubmitting(false);
    }
  }, [userSession, experimentId, subjectId, experimentTitle, simulationExecuted, codeVerified, quizScore, onUserSessionUpdate]);

  const formatSeconds = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}m ${s.toString().padStart(2, '0')}s`;
  };

  const isCompletedAlready = Boolean(
    userSession?.completedExperiments?.some((exp: any) =>
      typeof exp === 'string' ? exp === experimentId : exp?.experimentId === experimentId
    )
  );

  return {
    status,
    sessionActiveSeconds,
    formattedSessionTime: formatSeconds(sessionActiveSeconds),
    simulationExecuted,
    setSimulationExecuted,
    codeVerified,
    setCodeVerified,
    quizScore,
    setQuizScore,
    isSubmitting,
    completionSuccess,
    isCompletedAlready,
    submitExperimentCompletion
  };
}
