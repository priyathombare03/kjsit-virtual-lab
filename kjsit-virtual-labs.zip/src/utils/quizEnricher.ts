import { QuizQuestion, LabExperiment } from '../types';

// Curated bank of comprehensive self-evaluation questions categorized by subject & keywords
interface QuestionTemplate {
  keywords: string[];
  subjects: string[];
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

const QUESTION_BANK: QuestionTemplate[] = [
  // --- STACK & LINEAR STRUCTURES ---
  {
    keywords: ['stack', 'lifo', 'push', 'pop'],
    subjects: ['dsa', 'aoa', 'daa'],
    question: 'Which of the following applications inherently utilizes a stack data structure?',
    options: ['Breadth-First Search (BFS)', 'Round-Robin CPU scheduling', 'Function call recursion and activation records', 'Print spooler queue'],
    correctAnswer: 2,
    explanation: 'Function call management uses a call stack to preserve local variables, return addresses, and execution state across function invocations.'
  },
  {
    keywords: ['stack', 'infix', 'postfix', 'prefix', 'expression'],
    subjects: ['dsa', 'aoa'],
    question: 'When converting the infix expression "A + B * C" to postfix, what is the resulting expression?',
    options: ['+ A * B C', 'A B C * +', 'A B + C *', 'A B C + *'],
    correctAnswer: 1,
    explanation: 'Multiplication (*) has higher precedence than addition (+), so B * C evaluates first to BC*, and is then added to A giving ABC*+.'
  },
  {
    keywords: ['stack', 'underflow', 'overflow'],
    subjects: ['dsa', 'aoa'],
    question: 'In an array-based stack initialized with top = -1, what condition triggers stack underflow?',
    options: ['Attempting pop() when top == -1', 'Attempting push() when top == N - 1', 'Attempting peek() when top == 0', 'Attempting push() when top == 0'],
    correctAnswer: 0,
    explanation: 'Stack underflow occurs when an algorithm attempts to pop or inspect an element from an empty stack (top == -1).'
  },
  {
    keywords: ['stack', 'peek', 'top'],
    subjects: ['dsa'],
    question: 'What is the key difference between the pop() and peek() operations on a stack?',
    options: ['pop() inserts an item; peek() removes it', 'peek() returns the top element without removing it; pop() removes and returns it', 'peek() takes O(N) time; pop() takes O(1) time', 'peek() is only supported in linked lists'],
    correctAnswer: 1,
    explanation: 'peek() (or top) inspects the topmost element without altering the stack size or top pointer, whereas pop() removes the topmost element.'
  },
  {
    keywords: ['stack', 'parentheses', 'balanced'],
    subjects: ['dsa'],
    question: 'What is the auxiliary space complexity of verifying balanced parentheses in a string of length N using a stack?',
    options: ['O(1)', 'O(log N)', 'O(N)', 'O(N^2)'],
    correctAnswer: 2,
    explanation: 'In the worst case (e.g. a string of all opening brackets "((((..."), all N characters are pushed onto the stack, requiring O(N) memory.'
  },
  {
    keywords: ['stack', 'linked list'],
    subjects: ['dsa'],
    question: 'In a linked-list implementation of a stack, where are new elements inserted to achieve O(1) time complexity?',
    options: ['At the tail of the linked list', 'At the head (top) of the linked list', 'In the middle of the linked list', 'At a randomly hashed index'],
    correctAnswer: 1,
    explanation: 'Inserting at the head takes O(1) constant time because no traversal is required. Inserting at the tail of a singly linked list without a tail pointer would require O(N) traversal.'
  },
  {
    keywords: ['stack', 'array', 'capacity'],
    subjects: ['dsa'],
    question: 'What is the primary drawback of implementing a stack using a fixed-size static array versus a linked list?',
    options: ['Static array has slower push/pop operations', 'Static array has fixed capacity causing potential overflow', 'Static array requires extra pointer memory per node', 'Static array cannot store integers'],
    correctAnswer: 1,
    explanation: 'A static array stack has a fixed size allocated at creation time and cannot dynamically expand, risking stack overflow when full.'
  },
  {
    keywords: ['stack', 'evaluation', 'postfix'],
    subjects: ['dsa'],
    question: 'What is the value of the postfix expression "5 3 + 2 *" evaluated using an operand stack?',
    options: ['11', '16', '25', '30'],
    correctAnswer: 1,
    explanation: '5 and 3 are pushed, "+" pops both and computes 5 + 3 = 8. Then 2 is pushed, "*" pops 8 and 2 and computes 8 * 2 = 16.'
  },

  // --- QUEUES & CIRCULAR QUEUES ---
  {
    keywords: ['queue', 'fifo', 'enqueue', 'dequeue'],
    subjects: ['dsa'],
    question: 'In a standard linear queue implemented using an array, what issue arises when elements are dequeued repeatedly?',
    options: ['Memory fragmentation occurs', 'Index drift causes false overflow even though spaces are available at the front', 'Dequeuing takes O(N^2) time', 'Stack overflow is triggered'],
    correctAnswer: 1,
    explanation: 'As elements are dequeued, the front pointer moves forward. When rear reaches the array end, the queue appears full even if earlier slots are empty.'
  },
  {
    keywords: ['queue', 'circular queue'],
    subjects: ['dsa'],
    question: 'In a circular queue of capacity N, what formula calculates the next position for the rear pointer?',
    options: ['rear = rear + 1', 'rear = (rear + 1) % N', 'rear = (rear - 1) % N', 'rear = (rear + N) / 2'],
    correctAnswer: 1,
    explanation: 'The modulo operator % wraps the rear pointer back to 0 when it reaches the end of the buffer: (rear + 1) % N.'
  },
  {
    keywords: ['queue', 'priority queue', 'heap'],
    subjects: ['dsa', 'daa'],
    question: 'What is the time complexity of extracting the minimum element from a Min-Heap priority queue of size N?',
    options: ['O(1)', 'O(log N)', 'O(N)', 'O(N log N)'],
    correctAnswer: 1,
    explanation: 'While accessing the minimum root element takes O(1), restoring the heap property (heapify-down) after removal takes O(log N) time.'
  },
  {
    keywords: ['queue', 'deque', 'double ended'],
    subjects: ['dsa'],
    question: 'What characterizes a Double-Ended Queue (Deque)?',
    options: ['Elements can only be inserted at front and removed at rear', 'Elements can be inserted and removed from both ends (front and rear)', 'Elements are automatically sorted upon insertion', 'It uses two separate CPU cores'],
    correctAnswer: 1,
    explanation: 'A deque allows insertion and deletion operations at both the front and rear ends in O(1) time.'
  },

  // --- LINKED LISTS & TREES ---
  {
    keywords: ['linked list', 'singly', 'doubly'],
    subjects: ['dsa'],
    question: 'What is a major advantage of a Doubly Linked List over a Singly Linked List?',
    options: ['Lower memory usage per node', 'Bidirectional traversal and O(1) deletion of a node when its pointer is known', 'Automatic cache locality', 'Constant-time random access by index'],
    correctAnswer: 1,
    explanation: 'Each node maintains both next and prev pointers, allowing backward traversal and O(1) deletion without needing a pointer to the preceding node.'
  },
  {
    keywords: ['binary tree', 'bst', 'traversal'],
    subjects: ['dsa', 'daa'],
    question: 'Which tree traversal order processes elements of a Binary Search Tree (BST) in strictly ascending sorted order?',
    options: ['Preorder (Root, Left, Right)', 'Inorder (Left, Root, Right)', 'Postorder (Left, Right, Root)', 'Level Order (BFS)'],
    correctAnswer: 1,
    explanation: 'Inorder traversal recursively visits the Left subtree, current Root, and Right subtree, yielding values in ascending sorted sequence for any valid BST.'
  },
  {
    keywords: ['binary tree', 'height', 'balance', 'avl'],
    subjects: ['dsa', 'daa'],
    question: 'In an AVL tree, what is the valid range of the balance factor (height(left) - height(right)) for every node?',
    options: ['0 only', '-1, 0, or +1', '-2 to +2', 'Any positive integer'],
    correctAnswer: 1,
    explanation: 'An AVL tree maintains the height-balance invariant where the height difference between left and right subtrees of any node is strictly in {-1, 0, +1}.'
  },
  {
    keywords: ['tree', 'binary search tree', 'search'],
    subjects: ['dsa', 'daa'],
    question: 'What is the worst-case search time complexity in an unbalanced, skewed Binary Search Tree with N nodes?',
    options: ['O(1)', 'O(log N)', 'O(N)', 'O(N log N)'],
    correctAnswer: 2,
    explanation: 'If items are inserted in sorted order, the BST degenerates into a linear linked list (skewed tree), causing worst-case search to degrade to O(N).'
  },

  // --- SORTING & SEARCHING (DAA / DSA) ---
  {
    keywords: ['sort', 'bubble', 'selection', 'insertion'],
    subjects: ['dsa', 'daa'],
    question: 'Which sorting algorithm has a best-case time complexity of O(N) when the input array is already sorted?',
    options: ['Selection Sort', 'Insertion Sort with early exit flag', 'Standard Quick Sort', 'Merge Sort'],
    correctAnswer: 1,
    explanation: 'Insertion Sort (and optimized Bubble Sort with a swapped flag) runs in O(N) linear time on already sorted arrays because each element requires only 1 comparison.'
  },
  {
    keywords: ['quick sort', 'pivot', 'partition'],
    subjects: ['dsa', 'daa'],
    question: 'What is the worst-case time complexity of standard Quick Sort and when does it typically occur?',
    options: ['O(N log N) when pivot is median', 'O(N^2) when array is already sorted and first/last element is chosen as pivot', 'O(N) when elements are identical', 'O(2^N) in recursion'],
    correctAnswer: 1,
    explanation: 'When the partition is extremely unbalanced (e.g. 0 elements on one side and N - 1 on the other), recursion depth is N, yielding O(N^2) worst-case time.'
  },
  {
    keywords: ['merge sort', 'divide and conquer'],
    subjects: ['dsa', 'daa'],
    question: 'What is the auxiliary space complexity of standard top-down Merge Sort on an array of size N?',
    options: ['O(1)', 'O(log N)', 'O(N)', 'O(N log N)'],
    correctAnswer: 2,
    explanation: 'Merge Sort requires an auxiliary array of size O(N) to temporarily hold merged subarrays during the merge phase.'
  },
  {
    keywords: ['binary search', 'search', 'divide'],
    subjects: ['dsa', 'daa'],
    question: 'What is the prerequisite condition for applying Binary Search on a collection of elements?',
    options: ['Collection must be stored in a linked list', 'Collection must be sorted in monotonic order', 'Collection must have an even number of elements', 'Collection must be loaded in cache'],
    correctAnswer: 1,
    explanation: 'Binary Search relies on dividing the search space based on sorted order, so elements must be sorted (and support O(1) random access for O(log N) efficiency).'
  },

  // --- DAA: GREEDY, DP, GRAPH ---
  {
    keywords: ['greedy', 'fractional knapsack', 'knapsack'],
    subjects: ['daa', 'aoa'],
    question: 'Why does the Greedy algorithm fail to guarantee an optimal solution for the 0/1 Knapsack problem?',
    options: ['Greedy choices cannot be undone and items cannot be divided', 'Greedy requires O(2^N) time', 'Items have equal weights', 'Greedy cannot sort items by value'],
    correctAnswer: 0,
    explanation: 'In 0/1 knapsack, items cannot be broken into fractions. Taking the highest value-to-weight item may leave unusable capacity that prevents an optimal total.'
  },
  {
    keywords: ['dynamic programming', 'memoization', 'tabulation'],
    subjects: ['daa', 'aoa'],
    question: 'What two fundamental properties must a problem satisfy to be solvable via Dynamic Programming?',
    options: ['Greedy choice property and polynomial bounds', 'Optimal substructure and overlapping subproblems', 'Divide and conquer with independent subproblems', 'Linear time and constant memory'],
    correctAnswer: 1,
    explanation: 'DP applies when an optimal global solution can be composed of optimal subproblem solutions (optimal substructure) and subproblems recur repeatedly (overlapping subproblems).'
  },
  {
    keywords: ['graph', 'dijkstra', 'shortest path'],
    subjects: ['daa', 'dsa'],
    question: 'What is the limitation of Dijkstra’s single-source shortest path algorithm?',
    options: ['Cannot handle undirected graphs', 'Cannot handle graphs with negative edge weights', 'Has exponential time complexity', 'Only works on trees'],
    correctAnswer: 1,
    explanation: 'Dijkstra greedily assumes once a vertex distance is finalized it cannot be improved; negative weight cycles or edges violate this greedy invariant.'
  },
  {
    keywords: ['graph', 'bfs', 'dfs', 'traversal'],
    subjects: ['daa', 'dsa'],
    question: 'Which graph traversal algorithm finds the shortest path in an unweighted graph?',
    options: ['Depth-First Search (DFS)', 'Breadth-First Search (BFS)', 'Inorder Traversal', 'Topological Sort'],
    correctAnswer: 1,
    explanation: 'BFS explores vertices in order of increasing distance (edges) from the source vertex, guaranteeing the shortest path in unweighted graphs.'
  },
  {
    keywords: ['minimum spanning tree', 'kruskal', 'prim'],
    subjects: ['daa', 'dsa'],
    question: 'Which data structure is essential for efficiently detecting cycles in Kruskal’s Minimum Spanning Tree algorithm?',
    options: ['Binary Heap', 'Disjoint Set Union (Union-Find)', 'Hash Map', 'Red-Black Tree'],
    correctAnswer: 1,
    explanation: 'Disjoint Set Union (DSU) with path compression and union by rank provides near O(1) cycle detection when considering edges in ascending order of weight.'
  },
  {
    keywords: ['np-complete', 'p vs np', 'complexity'],
    subjects: ['daa'],
    question: 'What does it mean for a decision problem to be in class NP?',
    options: ['It cannot be solved by any computer', 'A proposed solution can be verified in polynomial time by a deterministic Turing machine', 'It requires non-polynomial space', 'It runs in O(N!) time always'],
    correctAnswer: 1,
    explanation: 'The complexity class NP (Nondeterministic Polynomial time) contains decision problems where a candidate certificate/solution can be checked in polynomial time.'
  },

  // --- DBMS & SQL ---
  {
    keywords: ['sql', 'ddl', 'dml', 'create', 'alter'],
    subjects: ['dbms'],
    question: 'Which SQL command is classified as a Data Definition Language (DDL) command?',
    options: ['SELECT', 'INSERT', 'ALTER', 'UPDATE'],
    correctAnswer: 2,
    explanation: 'ALTER modifies table schema definitions (adding columns, constraints) and is therefore a DDL command, whereas SELECT is DQL and INSERT/UPDATE are DML.'
  },
  {
    keywords: ['acid', 'transaction', 'atomicity'],
    subjects: ['dbms'],
    question: 'Which ACID property guarantees that either all operations of a transaction execute successfully or none do?',
    options: ['Atomicity', 'Consistency', 'Isolation', 'Durability'],
    correctAnswer: 0,
    explanation: 'Atomicity ensures the "all-or-nothing" execution of database transactions, rolling back partial operations upon failure.'
  },
  {
    keywords: ['normalization', '1nf', '2nf', '3nf', 'bcnf'],
    subjects: ['dbms'],
    question: 'A relation is in Third Normal Form (3NF) if it is in 2NF and has no:',
    options: ['Multivalued attributes', 'Partial functional dependencies', 'Transitive functional dependencies on candidate keys', 'Foreign key constraints'],
    correctAnswer: 2,
    explanation: '3NF eliminates transitive dependencies (non-prime attribute determining another non-prime attribute), ensuring attributes depend only on candidate keys.'
  },
  {
    keywords: ['join', 'inner join', 'outer join', 'sql'],
    subjects: ['dbms'],
    question: 'Which SQL JOIN returns all rows from the left table even if there are no matching rows in the right table?',
    options: ['INNER JOIN', 'LEFT OUTER JOIN', 'RIGHT OUTER JOIN', 'CROSS JOIN'],
    correctAnswer: 1,
    explanation: 'LEFT OUTER JOIN preserves all records from the left table, populating NULL values for columns from the right table where no join condition matches.'
  },
  {
    keywords: ['index', 'b+ tree', 'b tree', 'indexing'],
    subjects: ['dbms'],
    question: 'Why are B+ Trees preferred over standard B Trees for relational database indexing?',
    options: ['B+ Trees have lower height and all data records reside in linked leaf nodes for fast range scans', 'B+ Trees do not require disk storage', 'B+ Trees guarantee O(1) lookups', 'B+ Trees store duplicate keys randomly'],
    correctAnswer: 0,
    explanation: 'In B+ Trees, internal nodes only store navigation keys and all leaf nodes form a doubly linked list, enabling highly efficient sequential range scans on disk.'
  },
  {
    keywords: ['deadlock', 'concurrency', 'two phase locking'],
    subjects: ['dbms'],
    question: 'What does the Strict Two-Phase Locking (Strict 2PL) protocol guarantee in transaction management?',
    options: ['Deadlock-free execution', 'Conflict serializability and avoidance of cascading aborts', 'Instant query execution', 'Zero disk I/O'],
    correctAnswer: 1,
    explanation: 'Strict 2PL holds all exclusive (X) locks until the transaction commits or aborts, ensuring serializability and preventing cascading rollbacks.'
  },

  // --- OPERATING SYSTEMS ---
  {
    keywords: ['process', 'thread', 'os', 'pcb'],
    subjects: ['os'],
    question: 'Which of the following resources is shared between multiple threads belonging to the same process?',
    options: ['Stack and register state', 'Program counter', 'Code segment, data segment, and open file descriptors', 'Thread control block'],
    correctAnswer: 2,
    explanation: 'Threads of a single process share the address space (code and data segments) and OS resources (open files), while maintaining private stacks and registers.'
  },
  {
    keywords: ['scheduling', 'cpu', 'round robin', 'sjf'],
    subjects: ['os'],
    question: 'Which CPU scheduling algorithm can suffer from the convoy effect when a CPU-intensive process blocks shorter I/O processes?',
    options: ['Round Robin (RR)', 'First-Come, First-Served (FCFS)', 'Shortest Job First (SJF)', 'Priority Preemptive Scheduling'],
    correctAnswer: 1,
    explanation: 'In non-preemptive FCFS, a long CPU-bound process causes all subsequent short and I/O bound processes to wait, creating the convoy effect.'
  },
  {
    keywords: ['semaphore', 'mutex', 'synchronization'],
    subjects: ['os'],
    question: 'What are the two atomic operations permitted on a Counting Semaphore variable S?',
    options: ['read() and write()', 'wait() (or P) and signal() (or V)', 'lock() and release()', 'push() and pop()'],
    correctAnswer: 1,
    explanation: 'Semaphores are controlled solely via wait() (decrementing S and blocking if S <= 0) and signal() (incrementing S and waking up waiting processes).'
  },
  {
    keywords: ['deadlock', 'banker', 'safety'],
    subjects: ['os'],
    question: 'Which condition is NOT one of the four Coffman conditions necessary for deadlock to occur?',
    options: ['Mutual Exclusion', 'Hold and Wait', 'Preemption allowed by system', 'Circular Wait'],
    correctAnswer: 2,
    explanation: 'Deadlock requires "No Preemption"—resources cannot be forcibly confiscated from a process holding them until completion.'
  },
  {
    keywords: ['paging', 'virtual memory', 'page fault'],
    subjects: ['os'],
    question: 'What triggers a Page Fault in an operating system with demand paging?',
    options: ['A CPU register overflow', 'Accessing a virtual address whose corresponding page is not currently in physical RAM', 'Writing to a read-only disk file', 'A process terminating normally'],
    correctAnswer: 1,
    explanation: 'When the valid/invalid bit in the page table entry indicates the requested page is not in physical RAM, hardware traps to the OS page fault handler to load it from swap.'
  },

  // --- MACHINE LEARNING & AI ---
  {
    keywords: ['machine learning', 'supervised', 'unsupervised'],
    subjects: ['ml', 'aiml', 'ai'],
    question: 'Which of the following is an example of an Unsupervised Learning algorithm?',
    options: ['Linear Regression', 'Support Vector Machine (SVM)', 'K-Means Clustering', 'Random Forest Classifier'],
    correctAnswer: 2,
    explanation: 'K-Means clustering groups unlabeled input patterns based on geometric feature distance without predefined target labels.'
  },
  {
    keywords: ['overfitting', 'regularization', 'bias variance'],
    subjects: ['ml', 'aiml', 'ai'],
    question: 'What does L2 regularization (Ridge regression) add to the loss function to mitigate overfitting?',
    options: ['Sum of absolute values of weights (L1 penalty)', 'Sum of squared magnitudes of weights (L2 penalty)', 'Random Gaussian noise to labels', 'Log-likelihood of test errors'],
    correctAnswer: 1,
    explanation: 'L2 regularization penalizes large weights by adding λ * Σ(w_i^2) to the objective function, shrinking weights toward zero and reducing model variance.'
  },
  {
    keywords: ['neural network', 'activation', 'gradient'],
    subjects: ['ml', 'aiml', 'ann', 'dl'],
    question: 'Why is the ReLU (Rectified Linear Unit) activation function commonly preferred over Sigmoid in deep hidden layers?',
    options: ['ReLU outputs values bounded between 0 and 1', 'ReLU mitigates the vanishing gradient problem for positive inputs (derivative is 1)', 'ReLU is smooth and differentiable everywhere including 0', 'ReLU requires matrix inversion'],
    correctAnswer: 1,
    explanation: 'Sigmoid saturates at both tails with derivatives near zero, causing vanishing gradients in deep backpropagation. ReLU maintains constant gradient 1 for x > 0.'
  },
  {
    keywords: ['confusion matrix', 'precision', 'recall', 'f1'],
    subjects: ['ml', 'aiml', 'ai'],
    question: 'In model evaluation, what is the formula for Precision?',
    options: ['TP / (TP + FN)', 'TP / (TP + FP)', '(TP + TN) / Total', '2 * (Precision * Recall) / (Precision + Recall)'],
    correctAnswer: 1,
    explanation: 'Precision measures the proportion of positive identifications that were actually correct: True Positives divided by total predicted positives (TP + FP).'
  },

  // --- GENERAL COMPUTER SCIENCE & ALGORITHMS ---
  {
    keywords: ['time complexity', 'big o', 'asymptotic'],
    subjects: ['dsa', 'daa', 'aoa'],
    question: 'What does Big-O notation O(g(n)) formally represent in algorithmic analysis?',
    options: ['The strict lower bound of running time', 'The asymptotic upper bound of running time for large input sizes', 'The exact average execution time in seconds', 'The memory cache miss rate'],
    correctAnswer: 1,
    explanation: 'Big-O notation describes an asymptotic upper bound: f(n) <= c * g(n) for all n >= n0, guaranteeing the algorithm will not grow faster than g(n).'
  },
  {
    keywords: ['recursion', 'base case', 'stack overflow'],
    subjects: ['dsa', 'daa'],
    question: 'What is the primary role of the base case in a recursive algorithm?',
    options: ['To increase execution speed', 'To terminate the recursive chain and prevent infinite recursion or stack overflow', 'To allocate dynamic heap memory', 'To compute the asymptotic complexity'],
    correctAnswer: 1,
    explanation: 'Without an unreachable or missing base case, a recursive function calls itself indefinitely until the call stack memory is exhausted (stack overflow).'
  }
];

/**
 * Enriches an experiment's quiz questions so it has at least `targetCount` (default: 10)
 * high-quality, relevant questions.
 */
export function enrichExperimentQuiz(experiment: LabExperiment, targetCount: number = 10): LabExperiment {
  const existingQuestions = experiment.quiz || [];
  if (existingQuestions.length >= targetCount) {
    return experiment;
  }

  const existingTexts = new Set(existingQuestions.map((q) => q.question.toLowerCase().trim()));
  const newQuestions: QuizQuestion[] = [...existingQuestions];

  const searchBag = [
    experiment.title,
    experiment.category,
    experiment.aim,
    experiment.subtitle,
    experiment.subjectId || '',
    ...(experiment.theory?.keyPoints || []),
    ...(experiment.theory?.overview || [])
  ]
    .join(' ')
    .toLowerCase();

  // Score candidate questions based on keyword relevance
  const scored = QUESTION_BANK.map((candidate) => {
    let score = 0;
    if (experiment.subjectId && candidate.subjects.includes(experiment.subjectId)) {
      score += 5;
    }
    candidate.keywords.forEach((kw) => {
      if (searchBag.includes(kw.toLowerCase())) {
        score += 8;
      }
    });
    return { candidate, score };
  });

  // Sort candidates by highest score
  scored.sort((a, b) => b.score - a.score);

  for (const item of scored) {
    if (newQuestions.length >= targetCount) break;

    const qText = item.candidate.question;
    if (!existingTexts.has(qText.toLowerCase().trim())) {
      existingTexts.add(qText.toLowerCase().trim());
      newQuestions.push({
        id: newQuestions.length + 1,
        question: item.candidate.question,
        options: [...item.candidate.options],
        correctAnswer: item.candidate.correctAnswer,
        explanation: item.candidate.explanation
      });
    }
  }

  // Fallback: If still under targetCount, renumber and add general analytical questions
  let fallbackId = 1;
  while (newQuestions.length < targetCount) {
    newQuestions.push({
      id: newQuestions.length + 1,
      question: `Question ${newQuestions.length + 1}: In the implementation of ${experiment.title}, what is the primary factor governing runtime efficiency?`,
      options: [
        'Minimizing repetitive inner-loop operations and pointer dereferencing',
        'Increasing total variable declaration count',
        'Running solely on 32-bit operating systems',
        'Replacing local memory variables with disk file writes'
      ],
      correctAnswer: 0,
      explanation: `Optimizing ${experiment.title} requires minimizing unnecessary traversals and memory allocations to preserve optimal asymptotic bounds.`
    });
    fallbackId++;
  }

  // Ensure 1-based contiguous IDs
  const finalized = newQuestions.map((q, idx) => ({
    ...q,
    id: idx + 1
  }));

  return {
    ...experiment,
    quiz: finalized
  };
}
