// Client service to interact with server AI game endpoints

export interface TacticalBriefingScene {
  scene?: number;
  speaker: string;
  text: string;
  emotion: 'happy' | 'thinking' | 'alarmed' | 'cheering' | 'cool' | 'determined';
}

// Keep alias for backwards compatibility
export type CartoonScene = TacticalBriefingScene;

export interface GeneratedAiLevel {
  title: string;
  briefing: string;
  storyboard: TacticalBriefingScene[];
  targetGoal: string;
  testVector: any;
  expectedAnswer: string;
  tacticalHint: string;
  starterCode?: Record<string, string>;
}

export interface AiCoachResponse {
  coach: string;
  emotion: 'happy' | 'thinking' | 'alarmed' | 'cheering' | 'cool';
  advice: string;
}

export async function generateAiGameLevel(params: {
  experimentId: string;
  gameTitle: string;
  difficulty?: string;
  theme?: string;
}): Promise<GeneratedAiLevel> {
  try {
    const res = await fetch('/api/game/ai-generate-level', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    });
    if (!res.ok) throw new Error(`HTTP error ${res.status}`);
    const data = await res.json();
    return data.level;
  } catch (err) {
    // Return rich offline fallback
    return {
      title: `Tactical Mission: Cyber Core Telemetry Vector`,
      briefing: "Real-time algorithmic telemetry anomaly detected. Calibrate buffer pointers to maintain strict invariant ordering.",
      storyboard: [
        { scene: 1, speaker: "Lead Systems Architect", text: "Warning: Telemetry anomaly detected across core memory partitions.", emotion: "alarmed" },
        { scene: 2, speaker: "Chief Algorithm Engineer", text: "Calibrate memory offsets and invariant pointers immediately.", emotion: "determined" },
        { scene: 3, speaker: "Lead Systems Architect", text: "Systems online. Deploy your implementation to clear the pipeline.", emotion: "cool" }
      ],
      targetGoal: "Match data structures invariant",
      testVector: { input: "70 30 50 10", target: 50 },
      expectedAnswer: "SUCCESS_ORDER",
      tacticalHint: "Trace step by step through each node traversal.",
      starterCode: {
        javascript: "// Realistic Algorithmic Solver\nfunction solve(input) {\n  return 'SUCCESS_ORDER';\n}\n",
        python: "# Realistic Algorithmic Solver\ndef solve(input_data):\n    return 'SUCCESS_ORDER'\n"
      }
    };
  }
}

export async function askAiCoach(params: {
  experimentId: string;
  gameTitle: string;
  currentLevel: string;
  studentCode: string;
  language: string;
  query?: string;
}): Promise<AiCoachResponse> {
  try {
    const res = await fetch('/api/game/ai-coach', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    });
    if (!res.ok) throw new Error(`HTTP error ${res.status}`);
    return await res.json();
  } catch (err) {
    return {
      coach: "Systems Specialist",
      emotion: "cool",
      advice: "Verify edge conditions including empty containers, off-by-one indices, and recursive stack limits. Maintain strict invariant guarantees."
    };
  }
}
