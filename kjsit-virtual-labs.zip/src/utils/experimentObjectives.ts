import { LabExperiment } from '../types';

/**
 * Returns distinct, domain-specific laboratory objectives for an experiment.
 * Prioritizes explicit `labObjectives`, then falls back to synthesizing
 * precise, authentic objectives tailored to the specific experiment title, aim, and category.
 */
export function getExperimentLaboratoryObjectives(experiment: LabExperiment): string[] {
  // If explicitly defined on the experiment object, use those directly
  if (experiment.labObjectives && experiment.labObjectives.length > 0) {
    return experiment.labObjectives;
  }

  const titleLower = experiment.title.toLowerCase();
  const aimLower = experiment.aim.toLowerCase();
  const categoryLower = experiment.category.toLowerCase();
  const idLower = experiment.id.toLowerCase();

  // Stack ADT
  if (idLower.includes('stack') || titleLower.includes('stack')) {
    return [
      'Understand the Last-In-First-Out (LIFO) operational principle and stack abstraction.',
      'Implement fundamental stack primitives (Push, Pop, Peek, isEmpty, isFull) handling boundary conditions.',
      'Compare memory layout, pointer overhead, and dynamic allocation differences between array-backed and linked list-backed stacks.',
      'Analyze constant-time O(1) operational bounds and identify real-world system applications (call stacks, undo buffers).'
    ];
  }

  // Queue ADT / Circular Queue
  if (idLower.includes('queue') || titleLower.includes('queue')) {
    return [
      'Understand First-In-First-Out (FIFO) queue service discipline and process scheduling applications.',
      'Implement linear queue operations (Enqueue, Dequeue, Peek) using front and rear indices/pointers.',
      'Analyze index drift and false overflow conditions in linear arrays and evaluate circular buffer wrap-around solutions.',
      'Verify O(1) constant-time insertion and deletion mechanics across test vectors.'
    ];
  }

  // Infix to Postfix
  if (idLower.includes('postfix') || titleLower.includes('postfix') || titleLower.includes('infix')) {
    return [
      'Master operator precedence, associativity rules, and parenthetical expression evaluation.',
      'Implement an operator stack buffering mechanism to generate unambiguous Reverse Polish Notation (RPN).',
      'Trace expression parsing step-by-step from left to right, isolating operands from operator tokens.',
      'Evaluate postfix expressions efficiently without recursive operator precedence lookahead.'
    ];
  }

  // Linked List / Polynomial
  if (idLower.includes('polynomial') || titleLower.includes('polynomial')) {
    return [
      'Represent multi-term algebraic polynomials dynamically using linked list nodes with coefficient and exponent fields.',
      'Design two-pointer merge routines to combine like terms (exp1 == exp2) while preserving descending exponent order.',
      'Handle zero-coefficient cancellation, dynamic node allocation, and boundary condition traversal.',
      'Evaluate memory savings of linked list representations over sparse arrays for high-degree polynomials.'
    ];
  }

  // Binary Tree Traversals
  if (idLower.includes('binary-tree') || titleLower.includes('binary tree') || titleLower.includes('tree traversal')) {
    return [
      'Understand hierarchical non-linear tree structures, node degrees, depth, and mathematical tree properties.',
      'Implement recursive tree traversals: Pre-order (DLR), In-order (LDR), and Post-order (LRD).',
      'Verify mathematical binary tree properties including maximum nodes per level (2^L) and total node bounds.',
      'Trace and reconstruct tree topology and visiting sequences across balanced and skewed trees.'
    ];
  }

  // Binary Search Tree (BST)
  if (idLower.includes('bst') || titleLower.includes('binary search tree') || idLower.includes('search-tree')) {
    return [
      'Enforce the BST invariant property (Left Subtree < Node < Right Subtree) for strictly unique keys.',
      'Implement efficient search and insertion algorithms with average O(log n) time complexity.',
      'Handle 3-case node deletion: leaf node, single child, and two children using in-order successor.',
      'Demonstrate that in-order traversal of a BST consistently yields keys in ascending sorted sequence.'
    ];
  }

  // Graph Traversals (BFS & DFS)
  if (idLower.includes('graph') || idLower.includes('bfs') || idLower.includes('dfs') || titleLower.includes('graph')) {
    return [
      'Construct graph structures using both V x V Adjacency Matrix and dynamic Adjacency List representations.',
      'Implement Breadth First Search (BFS) using a FIFO queue to discover level-order shortest paths in unweighted graphs.',
      'Implement Depth First Search (DFS) using recursion or explicit stack for deep exploratory traversal.',
      'Maintain a boolean visited array to prevent infinite cycles and redundant node exploration.'
    ];
  }

  // Selection Sort
  if (idLower.includes('selection-sort') || titleLower.includes('selection sort')) {
    return [
      'Understand the comparison-based in-place sorting mechanism of Selection Sort.',
      'Trace passes finding the minimum element in the unsorted partition and performing at most (n - 1) swaps.',
      'Analyze the quadratic O(n²) time complexity across best, average, and worst cases with O(1) auxiliary space.',
      'Evaluate suitability for memory-constrained embedded sensors and telemetry datasets.'
    ];
  }

  // Insertion Sort
  if (idLower.includes('insertion-sort') || titleLower.includes('insertion sort')) {
    return [
      'Understand the adaptive, stable in-place sorting mechanism of Insertion Sort.',
      'Trace the incremental placement of each key into its correct sorted subarray position.',
      'Demonstrate linear O(n) best-case performance on nearly-sorted data versus O(n²) worst-case on reversed data.',
      'Analyze applicability to real-time streaming data and online record arrivals.'
    ];
  }

  // Merge Sort
  if (idLower.includes('merge-sort') || titleLower.includes('merge sort')) {
    return [
      'Master the Divide and Conquer algorithmic paradigm: divide array into halves, conquer recursively, and merge.',
      'Implement the two-finger linear merge routine with stable element ordering.',
      'Formulate and solve the recurrence relation T(n) = 2T(n/2) + O(n) yielding guaranteed O(n log n) time.',
      'Evaluate auxiliary space tradeoff (O(n) memory) versus asymptotic execution stability.'
    ];
  }

  // Quick Sort
  if (idLower.includes('quick-sort') || titleLower.includes('quick sort')) {
    return [
      'Understand Divide and Conquer in-place partitioning algorithms (Lomuto or Hoare schemes).',
      'Trace pivot selection, partitioning indices, and sub-problem recursion trees.',
      'Analyze average-case O(n log n) performance versus O(n²) worst-case when partitions are highly unbalanced.',
      'Apply randomized pivot selection or median-of-three heuristics to prevent degenerate execution.'
    ];
  }

  // Kruskal / Minimum Spanning Tree
  if (idLower.includes('kruskal') || titleLower.includes('kruskal') || titleLower.includes('spanning tree') || titleLower.includes('mst')) {
    return [
      'Understand greedy Minimum Spanning Tree (MST) construction on weighted undirected graphs.',
      'Implement Disjoint Set Union (DSU / Union-Find) with path compression and union by rank.',
      'Sort edge weights and iteratively greedily select minimum edges that do not form cycles.',
      'Analyze O(E log E) time complexity and evaluate infrastructure wiring and telecommunication network routing.'
    ];
  }

  // Traveling Salesperson Problem (TSP) / Dynamic Programming
  if (idLower.includes('tsp') || titleLower.includes('traveling sales') || titleLower.includes('dynamic programming')) {
    return [
      'Understand NP-hard combinatorial optimization and Hamiltonian cycle formulation for TSP.',
      'Formulate the Bellman-Held-Karp dynamic programming recurrence using bitmask subset states.',
      'Demonstrate memoization of overlapping subproblems to reduce complexity from O(n!) to O(n² 2^n).',
      'Analyze practical route optimization in logistics, drone delivery, and inspection missions.'
    ];
  }

  // N-Queens / Backtracking
  if (idLower.includes('n-queens') || titleLower.includes('n-queens') || titleLower.includes('backtracking')) {
    return [
      'Master the Backtracking state-space exploration paradigm and recursive depth-first trial-and-error.',
      'Implement row, column, and diagonal conflict detection bounding functions for non-attacking queen placement.',
      'Prune dead-end search branches early to avoid exhaustive combinatorial explosion.',
      'Trace solution space generation and compare performance across varying board dimensions (N = 4, 8, 12).'
    ];
  }

  // Sum of Subsets
  if (idLower.includes('sum-of-subsets') || titleLower.includes('subsets') || titleLower.includes('subset sum')) {
    return [
      'Model subset selection as a binary state-space decision tree (include vs exclude element).',
      'Implement bounding and pruning conditions using prefix sums and remaining sum bounds.',
      'Identify all subsets whose values sum precisely to the target threshold value.',
      'Analyze exponential worst-case complexity O(2^n) and benchmark effective pruning efficiency.'
    ];
  }

  // KMP String Matching
  if (idLower.includes('kmp') || titleLower.includes('kmp') || titleLower.includes('knuth-morris') || titleLower.includes('string matching')) {
    return [
      'Understand linear-time string search and the inefficiency of naive backtracking re-comparisons.',
      'Construct the Longest Proper Prefix which is also Suffix (LPS / π) preprocessing table in O(m) time.',
      'Utilize the LPS table to shift pattern pointers intelligently upon character mismatch without rewinding text index.',
      'Achieve deterministic O(n + m) worst-case time complexity for genomics, climate telemetry, and log search.'
    ];
  }

  // Sorting Applications (General)
  if (idLower.includes('sorting') || titleLower.includes('sorting')) {
    return [
      'Select and implement the appropriate sorting algorithm for real-world numerical datasets (marks, salaries, prices).',
      'Analyze comparative performance, stability, and in-place memory characteristics.',
      'Evaluate pass-by-pass execution and verify sorted monotonic ascending or descending ordering.',
      'Demonstrate how sorted data accelerates subsequent binary searching and rank-based statistical queries.'
    ];
  }

  // SQL / Database Systems
  if (categoryLower.includes('database') || categoryLower.includes('sql') || idLower.includes('sql') || idLower.includes('dbms')) {
    return [
      `Formulate and execute structured database queries and schema definitions for ${experiment.title}.`,
      'Enforce primary key, foreign key, uniqueness, and referential integrity constraints.',
      'Analyze query execution plans, indexing strategies, and relational algebra operations.',
      'Verify transaction ACID guarantees (Atomicity, Consistency, Isolation, Durability) and serializability.'
    ];
  }

  // Operating Systems
  if (categoryLower.includes('operating system') || categoryLower.includes('process') || idLower.includes('os') || idLower.includes('scheduling')) {
    return [
      `Analyze system kernel primitives, process control structures, and concurrency for ${experiment.title}.`,
      'Simulate resource allocation, process scheduling, and synchronization protocols step-by-step.',
      'Measure quantitative performance indicators: throughput, average waiting time, turnaround time, or miss ratios.',
      'Diagnose and prevent synchronization anomalies, race conditions, starvation, and deadlock states.'
    ];
  }

  // Machine Learning / AI
  if (categoryLower.includes('machine learning') || categoryLower.includes('artificial intelligence') || categoryLower.includes('ai') || categoryLower.includes('neural')) {
    return [
      `Formulate the mathematical model, objective loss function, and parameter update rules for ${experiment.title}.`,
      'Implement model training, gradient optimization, and hyperparameter tuning.',
      'Evaluate predictive accuracy, error convergence, and generalization across training and test datasets.',
      'Analyze bias-variance tradeoffs, feature representations, and decision boundary behaviors.'
    ];
  }

  // High-quality contextual fallback based on title and category
  return [
    `Understand the core theoretical foundation and algorithmic principles governing ${experiment.title}.`,
    `Analyze step-by-step execution, data transformations, and state transitions in the ${experiment.category} paradigm.`,
    'Evaluate asymptotic time and auxiliary space complexities under best, average, and worst-case scenarios.',
    'Execute and verify implementation outputs against standard benchmark test vectors.'
  ];
}
